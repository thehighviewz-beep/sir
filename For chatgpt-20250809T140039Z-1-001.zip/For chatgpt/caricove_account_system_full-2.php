<?php
/*
Plugin Name: Caricove Account System
Description: Creates a custom Caricove-branded account portal with split‑step login, registration, password reset and a dashboard of account actions including orders, addresses and payment methods.
Shortcode: [caricove_account_system]
*/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

/**
 * Register the [caricove_account_system] shortcode.
 * This shortcode renders a complete account portal: login/register/forgot password flows and a dashboard once logged in.
 */
add_shortcode('caricove_account_system', 'caricove_render_account_system');

/**
 * Render the Caricove account system.
 *
 * @return string HTML output
 */
function caricove_render_account_system() {
    ob_start();

    // Handle form submissions for login, registration and password reset.
    caricove_handle_account_actions();

    // Output inline CSS for Caricove styling.
    caricove_account_system_styles();

    echo '<div class="caricove-account-wrapper">';

    if (!is_user_logged_in()) {
        // Show login / register / forgot password forms
        $action = isset($_GET['action']) ? sanitize_text_field($_GET['action']) : 'login';
        switch ($action) {
            case 'register':
                caricove_render_register_form();
                break;
            case 'lostpassword':
                caricove_render_forgot_password_form();
                break;
            default:
                caricove_render_login_form();
        }
    } else {
        // Show the account dashboard
        caricove_render_account_dashboard();
    }

    echo '</div>';
    return ob_get_clean();
}

/**
 * Handle login, registration and password reset submissions.
 */
function caricove_handle_account_actions() {
    if ('POST' === $_SERVER['REQUEST_METHOD']) {
        if (isset($_POST['caricove_login_nonce']) && wp_verify_nonce($_POST['caricove_login_nonce'], 'caricove_login')) {
            $username = sanitize_user($_POST['username']);
            $password = $_POST['password'];
            $credentials = array(
                'user_login'    => $username,
                'user_password' => $password,
                'remember'      => true,
            );
            $user = wp_signon($credentials, false);
            if (is_wp_error($user)) {
                echo '<div class="caricove-error">' . esc_html($user->get_error_message()) . '</div>';
            } else {
                wp_set_current_user($user->ID);
                wp_set_auth_cookie($user->ID, true);
                // Redirect to account dashboard after login
                wp_safe_redirect(add_query_arg('login', 'success', get_permalink()));
                exit;
            }
        }
        if (isset($_POST['caricove_register_nonce']) && wp_verify_nonce($_POST['caricove_register_nonce'], 'caricove_register')) {
            $username = sanitize_user($_POST['username']);
            $email    = sanitize_email($_POST['email']);
            $password = $_POST['password'];
            if (username_exists($username) || email_exists($email)) {
                echo '<div class="caricove-error">User already exists with that email or username.</div>';
            } else {
                $user_id = wp_create_user($username, $password, $email);
                if (!is_wp_error($user_id)) {
                    wp_set_current_user($user_id);
                    wp_set_auth_cookie($user_id, true);
                    wp_safe_redirect(add_query_arg('register', 'success', get_permalink()));
                    exit;
                } else {
                    echo '<div class="caricove-error">' . esc_html($user_id->get_error_message()) . '</div>';
                }
            }
        }
        if (isset($_POST['caricove_reset_nonce']) && wp_verify_nonce($_POST['caricove_reset_nonce'], 'caricove_reset')) {
            $user_login = sanitize_text_field($_POST['user_login']);
            $user = get_user_by('login', $user_login);
            if (!$user) {
                $user = get_user_by('email', $user_login);
            }
            if ($user) {
                $reset_key = get_password_reset_key($user);
                $reset_url = wp_lostpassword_url() . '?key=' . $reset_key . '&login=' . rawurlencode($user->user_login);
                // Send a basic email with reset link
                wp_mail(
                    $user->user_email,
                    'Password Reset Request',
                    'Hello,\n\nPlease reset your password using the following link:\n' . $reset_url . '\n\nThank you.'
                );
                echo '<div class="caricove-success">Password reset link sent to your email.</div>';
            } else {
                echo '<div class="caricove-error">No user found with that username or email.</div>';
            }
        }
    }
}

/**
 * Render the login form.
 */
function caricove_render_login_form() {
    ?>
    <div class="caricove-form-wrapper">
        <h2 class="caricove-form-title">Sign In</h2>
        <form method="post" class="caricove-form">
            <div class="caricove-field">
                <label for="username">Username or Email</label>
                <input type="text" id="username" name="username" required placeholder="Enter your username or email" />
            </div>
            <div class="caricove-field">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required placeholder="Enter your password" />
            </div>
            <?php wp_nonce_field('caricove_login', 'caricove_login_nonce'); ?>
            <button type="submit" class="caricove-submit">Login</button>
        </form>
        <div class="caricove-links">
            <a href="?action=register">Create Account</a> |
            <a href="?action=lostpassword">Forgot Password?</a>
        </div>
    </div>
    <?php
}

/**
 * Render the registration form.
 */
function caricove_render_register_form() {
    ?>
    <div class="caricove-form-wrapper">
        <h2 class="caricove-form-title">Create Account</h2>
        <form method="post" class="caricove-form">
            <div class="caricove-field">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required placeholder="Choose a username" />
            </div>
            <div class="caricove-field">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" required placeholder="Enter your email" />
            </div>
            <div class="caricove-field">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required placeholder="Choose a password" />
            </div>
            <?php wp_nonce_field('caricove_register', 'caricove_register_nonce'); ?>
            <button type="submit" class="caricove-submit">Register</button>
        </form>
        <div class="caricove-links">
            <a href="?action=login">Already have an account? Sign In</a>
        </div>
    </div>
    <?php
}

/**
 * Render the password reset form.
 */
function caricove_render_forgot_password_form() {
    ?>
    <div class="caricove-form-wrapper">
        <h2 class="caricove-form-title">Forgot Password</h2>
        <p>Enter your username or email and we will send you a link to reset your password.</p>
        <form method="post" class="caricove-form">
            <div class="caricove-field">
                <label for="user_login">Username or Email</label>
                <input type="text" id="user_login" name="user_login" required placeholder="Enter username or email" />
            </div>
            <?php wp_nonce_field('caricove_reset', 'caricove_reset_nonce'); ?>
            <button type="submit" class="caricove-submit">Send Reset Link</button>
        </form>
        <div class="caricove-links">
            <a href="?action=login">Back to Login</a>
        </div>
    </div>
    <?php
}

/**
 * Render the account dashboard with key sections.
 */
function caricove_render_account_dashboard() {
    $user = wp_get_current_user();
    ?>
    <div class="caricove-dashboard">
        <h2 class="caricove-dashboard-title">My Account</h2>
        <p class="caricove-welcome">Welcome back, <?php echo esc_html($user->display_name); ?>!</p>
        <div class="caricove-dashboard-grid">
            <!-- Orders card -->
            <div class="caricove-card">
                <h3>Orders</h3>
                <p>View your past orders and track current orders.</p>
                <a class="caricove-card-link" href="<?php echo esc_url(add_query_arg('section', 'orders')); ?>">View Orders</a>
            </div>
            <!-- Addresses card -->
            <div class="caricove-card">
                <h3>Addresses</h3>
                <p>Manage your shipping and billing addresses.</p>
                <a class="caricove-card-link" href="<?php echo esc_url(add_query_arg('section', 'addresses')); ?>">Manage Addresses</a>
            </div>
            <!-- Payment Methods card -->
            <div class="caricove-card">
                <h3>Payment Methods</h3>
                <p>Update your saved payment methods.</p>
                <a class="caricove-card-link" href="<?php echo esc_url(add_query_arg('section', 'payments')); ?>">Manage Payments</a>
            </div>
            <!-- Profile Settings card -->
            <div class="caricove-card">
                <h3>Account Details</h3>
                <p>Update your profile and password.</p>
                <a class="caricove-card-link" href="<?php echo esc_url(add_query_arg('section', 'account-details')); ?>">Edit Profile</a>
            </div>
            <!-- Logout card -->
            <div class="caricove-card">
                <h3>Log Out</h3>
                <p>Sign out from your account.</p>
                <a class="caricove-card-link" href="<?php echo wp_logout_url(get_permalink()); ?>">Logout</a>
            </div>
        </div>
        <?php
        // Render the selected section
        if (isset($_GET['section'])) {
            $section = sanitize_text_field($_GET['section']);
            switch ($section) {
                case 'orders':
                    caricove_render_orders_section();
                    break;
                case 'addresses':
                    caricove_render_addresses_section();
                    break;
                case 'payments':
                    caricove_render_payments_section();
                    break;
                case 'account-details':
                    caricove_render_account_details_section();
                    break;
                default:
                    // Unknown section, ignore
            }
        }
        ?>
    </div>
    <?php
}

/**
 * Render the orders section using WooCommerce orders data.
 */
function caricove_render_orders_section() {
    $customer_id = get_current_user_id();
    $orders = wc_get_orders(array(
        'customer' => $customer_id,
        'limit'    => 5,
        'orderby'  => 'date',
        'order'    => 'DESC',
    ));
    ?>
    <div class="caricove-section">
        <h3>Your Recent Orders</h3>
        <?php if (!empty($orders)) : ?>
            <table class="caricove-orders-table">
                <thead>
                    <tr>
                        <th>Order</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Total</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($orders as $order) : ?>
                        <tr>
                            <td>#<?php echo esc_html($order->get_id()); ?></td>
                            <td><?php echo esc_html(wc_format_datetime($order->get_date_created())); ?></td>
                            <td><?php echo esc_html(wc_get_order_status_name($order->get_status())); ?></td>
                            <td><?php echo wp_kses_post($order->get_formatted_order_total()); ?></td>
                            <td><a href="<?php echo esc_url($order->get_view_order_url()); ?>">View</a></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else : ?>
            <p>You have no recent orders.</p>
        <?php endif; ?>
    </div>
    <?php
}

/**
 * Render the addresses section to manage billing and shipping addresses.
 */
function caricove_render_addresses_section() {
    ?>
    <div class="caricove-section">
        <h3>Your Addresses</h3>
        <?php wc_get_template('myaccount/my-address.php'); ?>
    </div>
    <?php
}

/**
 * Render the payment methods section using WooCommerce templates.
 */
function caricove_render_payments_section() {
    ?>
    <div class="caricove-section">
        <h3>Your Payment Methods</h3>
        <?php wc_get_template('myaccount/payment-methods.php'); ?>
    </div>
    <?php
}

/**
 * Render the account details section to update profile and password.
 */
function caricove_render_account_details_section() {
    ?>
    <div class="caricove-section">
        <h3>Edit Your Account Details</h3>
        <?php wc_get_template('myaccount/form-edit-account.php'); ?>
    </div>
    <?php
}

/**
 * Output inline styles for Caricove account system.
 */
function caricove_account_system_styles() {
    ?>
    <style>
    .caricove-account-wrapper {
        max-width: 800px;
        margin: 0 auto;
        padding: 20px;
        background: #0d0d0d;
        border-radius: 16px;
        box-shadow: 0 0 15px rgba(0, 255, 255, 0.2);
        color: #f2f2f2;
    }
    .caricove-form-wrapper,
    .caricove-section {
        background: #141414;
        padding: 20px;
        border-radius: 12px;
        box-shadow: 0 0 10px rgba(0, 255, 255, 0.1);
        margin-bottom: 20px;
    }
    .caricove-form-title {
        margin-bottom: 15px;
        font-size: 24px;
        font-weight: bold;
        color: #00e0ff;
    }
    .caricove-field {
        margin-bottom: 15px;
    }
    .caricove-field label {
        display: block;
        margin-bottom: 5px;
    }
    .caricove-field input {
        width: 100%;
        padding: 10px;
        border: 1px solid #333;
        border-radius: 6px;
        background: #1e1e1e;
        color: #fff;
    }
    .caricove-submit {
        background: linear-gradient(90deg, #00c3ff, #005eff);
        color: #fff;
        border: none;
        padding: 10px 20px;
        border-radius: 6px;
        cursor: pointer;
        font-weight: bold;
        text-transform: uppercase;
        transition: background 0.3s;
    }
    .caricove-submit:hover {
        background: linear-gradient(90deg, #005eff, #00c3ff);
    }
    .caricove-links {
        margin-top: 15px;
    }
    .caricove-links a {
        color: #00e0ff;
        text-decoration: none;
    }
    .caricove-links a:hover {
        text-decoration: underline;
    }
    .caricove-error {
        background: #ff4d4d;
        color: #fff;
        padding: 10px;
        border-radius: 6px;
        margin-bottom: 15px;
    }
    .caricove-success {
        background: #4caf50;
        color: #fff;
        padding: 10px;
        border-radius: 6px;
        margin-bottom: 15px;
    }
    .caricove-dashboard-title {
        font-size: 28px;
        margin-bottom: 10px;
        color: #00e0ff;
    }
    .caricove-welcome {
        margin-bottom: 20px;
    }
    .caricove-dashboard-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }
    .caricove-card {
        background: #1c1c1c;
        padding: 20px;
        border-radius: 12px;
        box-shadow: 0 0 15px rgba(0, 255, 255, 0.05);
        transition: transform 0.3s, box-shadow 0.3s;
    }
    .caricove-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 0 25px rgba(0, 255, 255, 0.2);
    }
    .caricove-card h3 {
        margin-top: 0;
        color: #00e0ff;
        margin-bottom: 10px;
    }
    .caricove-card p {
        margin-bottom: 15px;
    }
    .caricove-card-link {
        display: inline-block;
        background: linear-gradient(90deg, #00c3ff, #005eff);
        color: #fff;
        padding: 8px 16px;
        border-radius: 6px;
        text-decoration: none;
        font-weight: bold;
    }
    .caricove-card-link:hover {
        background: linear-gradient(90deg, #005eff, #00c3ff);
    }
    .caricove-orders-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 10px;
    }
    .caricove-orders-table th,
    .caricove-orders-table td {
        border: 1px solid #333;
        padding: 10px;
        text-align: left;
    }
    .caricove-orders-table th {
        background: #222;
    }
    .caricove-orders-table td {
        background: #1e1e1e;
    }
    .caricove-section h3 {
        margin-top: 0;
        color: #00e0ff;
        margin-bottom: 15px;
    }
    </style>
    <?php
}