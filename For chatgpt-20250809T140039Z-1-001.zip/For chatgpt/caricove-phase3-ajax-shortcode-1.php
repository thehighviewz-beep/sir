<?php
/*
 * Caricove AJAX Product Category Page with Load More - Full Shortcode
 * Use shortcode: [caricove_category_page]
 */

add_shortcode('caricove_category_page', function () {
    ob_start(); ?>

    <div id="caricove-category-container">
        <div class="caricove-filters">
            <label>Price Range:</label><br>
            <input type="range" id="price_min" min="0" max="1000" value="0">
            <input type="range" id="price_max" min="0" max="1000" value="1000">
            <div>From $<span id="minVal">0</span> to $<span id="maxVal">1000</span></div>

            <label>Rating:</label><br>
            <select id="rating_filter">
                <option value="">All</option>
                <option value="4">4★ & up</option>
                <option value="3">3★ & up</option>
                <option value="2">2★ & up</option>
                <option value="1">1★ & up</option>
            </select>

            <label><input type="checkbox" id="stock_only"> In Stock Only</label>
            <button id="apply_filters">Apply Filters</button>
        </div>

        <div id="caricove-product-grid"></div>
        <button id="load_more_btn">Load More</button>
    </div>

    <style>
        #caricove-category-container {
            color: #fff;
            background: #0c0c0c;
            padding: 1rem;
        }
        .caricove-filters {
            background: #111;
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1rem;
        }
        #caricove-product-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
            gap: 1rem;
        }
        .caricove-product {
            background: #1a1a1a;
            padding: 1rem;
            border-radius: 10px;
            transition: 0.3s ease;
        }
        .caricove-product:hover {
            box-shadow: 0 0 12px rgba(0,194,255,0.4);
        }
        .buy-now {
            background: linear-gradient(90deg, #00c2ff, #0073ff);
            color: white;
            padding: 0.5rem;
            border-radius: 6px;
            display: inline-block;
            text-align: center;
            margin-top: 0.5rem;
        }
        #load_more_btn {
            background: #0073ff;
            color: #fff;
            padding: 0.5rem 1rem;
            border: none;
            border-radius: 5px;
            margin-top: 1rem;
            display: block;
            margin-left: auto;
            margin-right: auto;
        }
    </style>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            let page = 1;

            function loadProducts(reset = false) {
                const min = document.getElementById('price_min').value;
                const max = document.getElementById('price_max').value;
                const rating = document.getElementById('rating_filter').value;
                const stock = document.getElementById('stock_only').checked ? 1 : 0;

                const data = {
                    action: 'caricove_filter_products',
                    price_min: min,
                    price_max: max,
                    rating: rating,
                    in_stock: stock,
                    paged: page
                };

                fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: new URLSearchParams(data)
                })
                .then(res => res.text())
                .then(html => {
                    if (reset) {
                        document.getElementById('caricove-product-grid').innerHTML = html;
                    } else {
                        document.getElementById('caricove-product-grid').insertAdjacentHTML('beforeend', html);
                    }
                });
            }

            document.getElementById('apply_filters').addEventListener('click', function () {
                page = 1;
                loadProducts(true);
            });

            document.getElementById('load_more_btn').addEventListener('click', function () {
                page++;
                loadProducts();
            });

            document.getElementById('price_min').addEventListener('input', function () {
                document.getElementById('minVal').textContent = this.value;
            });
            document.getElementById('price_max').addEventListener('input', function () {
                document.getElementById('maxVal').textContent = this.value;
            });

            loadProducts(true);
        });
    </script>

<?php
    return ob_get_clean();
});

// AJAX handler
add_action('wp_ajax_caricove_filter_products', 'caricove_filter_products');
add_action('wp_ajax_nopriv_caricove_filter_products', 'caricove_filter_products');
function caricove_filter_products() {
    $args = array(
        'post_type' => 'product',
        'posts_per_page' => 8,
        'paged' => intval($_POST['paged']),
        'meta_query' => array(),
        'tax_query' => array(),
    );

    if (!empty($_POST['price_min']) && !empty($_POST['price_max'])) {
        $args['meta_query'][] = array(
            'key' => '_price',
            'value' => array($_POST['price_min'], $_POST['price_max']),
            'compare' => 'BETWEEN',
            'type' => 'NUMERIC'
        );
    }

    if (!empty($_POST['in_stock'])) {
        $args['meta_query'][] = array(
            'key' => '_stock_status',
            'value' => 'instock'
        );
    }

    $query = new WP_Query($args);
    if ($query->have_posts()) :
        while ($query->have_posts()) : $query->the_post();
            global $product;
            ?>
            <div class="caricove-product">
                <a href="<?php the_permalink(); ?>">
                    <?php echo woocommerce_get_product_thumbnail(); ?>
                    <h3><?php the_title(); ?></h3>
                </a>
                <div class="price"><?php echo $product->get_price_html(); ?></div>
                <div class="rating"><?php echo wc_get_rating_html($product->get_average_rating()); ?></div>
                <a class="buy-now" href="<?php echo esc_url(wc_get_checkout_url() . '?add-to-cart=' . $product->get_id()); ?>">Buy Now</a>
            </div>
            <?php
        endwhile;
        wp_reset_postdata();
    else :
        echo "<p>No products found.</p>";
    endif;
    wp_die();
}
?>