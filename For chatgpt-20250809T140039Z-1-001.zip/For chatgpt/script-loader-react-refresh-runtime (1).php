<?php return array('dependencies' => array(), 'version' => '8f1acdfb845f670b0ef2');
