<?php
/*
 * Plugin Name: Caricove Amazon‑Style Category Page (Full)
 * Description: Fully featured shortcode implementing an Amazon‑style product category page for Caricove. Includes an AJAX product loop, infinite scroll, variation swatches, price slider and rating/brand filters, responsive layout (desktop sidebar and mobile drawer), sticky mobile footer (filter/sort/cart), glowing UI, image zoom, and direct Buy Now links. Tested with WooCommerce 8.x and WordPress 6.x.
 * Shortcode: [caricove_category_page]
 */

// Register the shortcode
add_shortcode('caricove_category_page', 'caricove_render_category_page');

/**
 * Outputs the custom category page markup. This function hooks into WooCommerce
 * queries to fetch products based on user‑selected filters and provides client‑side
 * JavaScript for an interactive, mobile‑friendly experience.
 *
 * The shortcode accepts optional attributes:
 *   per_page (int)   – number of products per load (default 8)
 *   columns  (int)   – number of columns on desktop (default 4)
 *   attributes (string) – comma‑separated list of product attributes to use as filters (e.g. "pa_color,pa_size")
 */
function caricove_render_category_page($atts = []) {
    // Parse shortcode attributes and apply defaults
    $atts = shortcode_atts([
        'per_page'  => 8,
        'columns'   => 4,
        'attributes' => 'pa_color,pa_size',
    ], $atts, 'caricove_category_page');

    // Frontend container output
    ob_start();
    ?>

    <style>
        /* ===== Caricove Category Page Styles ===== */
        :root {
            --caricove-primary: #00cfff;
            --caricove-secondary: #0077ff;
            --caricove-dark: #0d0e1a;
            --caricove-light: #ffffff;
            --caricove-gold: #facc15;
        }
        .caricove-category-wrapper {
            display: flex;
            gap: 24px;
            padding: 20px;
            flex-wrap: wrap;
            background: var(--caricove-dark);
            color: var(--caricove-light);
        }
        /* Sidebar (desktop) */
        .caricove-filters {
            flex: 1 1 250px;
            background: #15161e;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 0 20px rgba(0,255,255,0.1);
            max-height: calc(100vh - 140px);
            overflow-y: auto;
            position: sticky;
            top: 120px;
        }
        .caricove-filters h3 {
            margin-top: 0;
            font-size: 1.2rem;
            color: var(--caricove-primary);
        }
        .caricove-filter-group {
            margin-bottom: 20px;
        }
        .caricove-filter-group label {
            display: block;
            margin-bottom: 4px;
            font-weight: 600;
        }
        .caricove-filter-group input[type="checkbox"],
        .caricove-filter-group input[type="radio"] {
            margin-right: 6px;
        }
        /* Product grid */
        .caricove-products {
            flex: 4 1 auto;
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
        }
        .caricove-product-card {
            background: #12121c;
            padding: 15px;
            border-radius: 12px;
            box-shadow: 0 0 12px rgba(0,255,255,0.05);
            transition: transform 0.3s, box-shadow 0.3s;
            position: relative;
            overflow: hidden;
        }
        .caricove-product-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 0 20px rgba(0,255,255,0.3);
        }
        .caricove-product-card img {
            width: 100%;
            aspect-ratio: 1/1;
            object-fit: cover;
            border-radius: 8px;
            transition: transform 0.3s ease;
        }
        .caricove-product-card:hover img {
            transform: scale(1.05);
        }
        .caricove-product-title {
            font-size: 1rem;
            font-weight: 600;
            margin-top: 8px;
        }
        .caricove-product-rating {
            color: var(--caricove-gold);
            font-size: 0.9rem;
            margin: 4px 0;
        }
        .caricove-product-price {
            font-size: 1.1rem;
            font-weight: bold;
            color: var(--caricove-primary);
        }
        .caricove-swatches {
            margin-top: 6px;
            display: flex;
            gap: 6px;
        }
        .caricove-swatch {
            width: 16px;
            height: 16px;
            border-radius: 50%;
            border: 1px solid #fff;
            cursor: pointer;
            transition: box-shadow 0.2s;
        }
        .caricove-swatch:hover {
            box-shadow: 0 0 8px rgba(255,255,255,0.6);
        }
        .caricove-buy-btn {
            display: block;
            width: 100%;
            background: linear-gradient(90deg, var(--caricove-primary), var(--caricove-secondary));
            color: white;
            padding: 10px;
            text-align: center;
            font-weight: bold;
            border-radius: 8px;
            margin-top: 10px;
            text-decoration: none;
            box-shadow: 0 0 8px rgba(0,255,255,0.4);
            transition: background 0.3s;
        }
        .caricove-buy-btn:hover {
            background: linear-gradient(90deg, var(--caricove-secondary), var(--caricove-primary));
        }
        /* Sticky mobile footer */
        .caricove-sticky-footer {
            display: none;
            position: fixed;
            bottom: 0;
            left: 0;
            width: 100%;
            z-index: 999;
            background: rgba(13,14,26,0.95);
            padding: 8px;
            box-shadow: 0 -2px 10px rgba(0,0,0,0.8);
            justify-content: space-around;
            align-items: center;
        }
        .caricove-sticky-footer button,
        .caricove-sticky-footer a {
            flex: 1 1 auto;
            margin: 0 6px;
            padding: 10px;
            border-radius: 8px;
            border: none;
            background: var(--caricove-primary);
            color: #fff;
            font-weight: bold;
            text-decoration: none;
            text-align: center;
        }
        @media (max-width: 768px) {
            .caricove-category-wrapper {
                flex-direction: column;
            }
            .caricove-filters {
                display: none;
            }
            .caricove-sticky-footer {
                display: flex;
            }
        }
        /* Spinner for infinite scroll loading */
        .caricove-loader {
            text-align: center;
            padding: 20px;
            display: none;
        }
    </style>

    <div class="caricove-category-wrapper" id="caricove-category-container">
        <aside class="caricove-filters" id="caricove-filters-sidebar">
            <h3>Filter &amp; Sort</h3>
            <div id="caricove-filter-form">
                <!-- Price Slider -->
                <div class="caricove-filter-group">
                    <label>Price</label>
                    <input type="range" id="price-slider" min="0" max="1000" step="10" value="1000">
                    <div id="price-range-label">$0 – $1000</div>
                </div>
                <!-- Rating Filter -->
                <div class="caricove-filter-group">
                    <label>Ratings</label>
                    <label><input type="checkbox" class="rating-filter" value="4"> ★★★★ &amp; up</label>
                    <label><input type="checkbox" class="rating-filter" value="3"> ★★★ &amp; up</label>
                    <label><input type="checkbox" class="rating-filter" value="2"> ★★ &amp; up</label>
                </div>
                <!-- Stock Filter -->
                <div class="caricove-filter-group">
                    <label><input type="checkbox" id="stock-filter"> In Stock Only</label>
                </div>
                <!-- Brand Filter (dynamic) -->
                <div class="caricove-filter-group" id="brand-filter-group">
                    <label>Brand</label>
                    <?php
                    // Output available brands (custom taxonomy or attribute) for filtering
                    $brands = get_terms('product_brand', ['hide_empty' => true]);
                    foreach ($brands as $brand) {
                        echo '<label><input type="checkbox" class="brand-filter" value="'.esc_attr($brand->slug).'"> '.esc_html($brand->name).'</label>';
                    }
                    ?>
                </div>
                <!-- Attribute Filters (e.g. color, size) -->
                <?php
                $filter_attributes = array_map('trim', explode(',', $atts['attributes']));
                foreach ($filter_attributes as $attr) {
                    $taxonomy = wc_attribute_taxonomy_name($attr);
                    if (taxonomy_exists($taxonomy)) {
                        $terms = get_terms($taxonomy, ['hide_empty' => true]);
                        if (!empty($terms)) {
                            echo '<div class="caricove-filter-group" data-attr="'.esc_attr($attr).'">
                                <label>'.esc_html(wc_attribute_label($taxonomy)).'</label>';
                            foreach ($terms as $term) {
                                // Determine if it's a color attribute to render swatch
                                $swatch_style = '';
                                if (strpos($attr, 'color') !== false) {
                                    $color = get_term_meta($term->term_id, 'pa_color_value', true);
                                    if ($color) {
                                        $swatch_style = 'style="background:'.$color.'"';
                                    }
                                }
                                echo '<label style="display:flex; align-items:center; gap:6px;">
                                        <input type="checkbox" class="attribute-filter" data-attr="'.esc_attr($attr).'" value="'.esc_attr($term->slug).'">
                                        <span class="caricove-swatch" '.$swatch_style.'></span>
                                        '.esc_html($term->name).'
                                      </label>';
                            }
                            echo '</div>';
                        }
                    }
                }
                ?>
            </div>
        </aside>
        <main class="caricove-products" id="caricove-products-grid"
              data-page="1"
              data-per-page="<?php echo esc_attr($atts['per_page']); ?>"
              data-columns="<?php echo esc_attr($atts['columns']); ?>"
              data-attributes="<?php echo esc_attr($atts['attributes']); ?>">
            <!-- Products will be loaded here via AJAX -->
        </main>
        <!-- Loader for infinite scroll -->
        <div class="caricove-loader" id="caricove-loader">Loading…</div>
    </div>
    <!-- Sticky mobile footer -->
    <div class="caricove-sticky-footer" id="caricove-mobile-footer">
        <button id="mobile-filter-toggle">Filter</button>
        <button id="mobile-sort-toggle">Sort</button>
        <a href="<?php echo esc_url(wc_get_cart_url()); ?>">Cart</a>
    </div>

    <script>
    // Caricove Category Page Script: AJAX filtering, infinite scroll, price slider
    document.addEventListener('DOMContentLoaded', function(){
        const productsGrid = document.getElementById('caricove-products-grid');
        const loader = document.getElementById('caricove-loader');
        const priceSlider = document.getElementById('price-slider');
        const priceLabel = document.getElementById('price-range-label');
        const ratingFilters = document.querySelectorAll('.rating-filter');
        const stockFilter = document.getElementById('stock-filter');
        const brandFilters = document.querySelectorAll('.brand-filter');
        const attributeFilters = document.querySelectorAll('.attribute-filter');
        let isLoading = false;

        // Update price range label on slider change
        priceSlider.addEventListener('input', function(){
            priceLabel.textContent = '$0 – $' + this.value;
        });

        // Build query parameters based on selected filters
        function getFilterParams() {
            const params = new URLSearchParams();
            params.set('paged', productsGrid.dataset.page);
            params.set('per_page', productsGrid.dataset.perPage);
            // Price
            params.set('max_price', priceSlider.value);
            // Ratings
            const ratings = Array.from(ratingFilters).filter(cb => cb.checked).map(cb => cb.value);
            if (ratings.length) params.set('ratings', ratings.join(','));
            // Stock
            if (stockFilter.checked) params.set('in_stock', '1');
            // Brands
            const brands = Array.from(brandFilters).filter(cb => cb.checked).map(cb => cb.value);
            if (brands.length) params.set('brands', brands.join(','));
            // Attributes
            const attrs = {};
            attributeFilters.forEach(function(cb){
                if (cb.checked) {
                    const attr = cb.dataset.attr;
                    if (!attrs[attr]) attrs[attr] = [];
                    attrs[attr].push(cb.value);
                }
            });
            Object.keys(attrs).forEach(function(attr){
                params.set(attr, attrs[attr].join(','));
            });
            return params;
        }

        // Fetch products via AJAX and append/replace grid
        function fetchProducts(append = false) {
            if (isLoading) return;
            isLoading = true;
            loader.style.display = 'block';
            const params = getFilterParams();
            fetch('<?php echo admin_url('admin-ajax.php'); ?>?action=caricove_filter_products&' + params.toString())
                .then(response => response.text())
                .then(html => {
                    if (append) {
                        productsGrid.insertAdjacentHTML('beforeend', html);
                    } else {
                        productsGrid.innerHTML = html;
                    }
                })
                .finally(() => {
                    loader.style.display = 'none';
                    isLoading = false;
                });
        }

        // Load initial products
        fetchProducts(false);

        // Filter change handlers: fetch new products on change
        [priceSlider, stockFilter].forEach(el => {
            el.addEventListener('change', function(){
                productsGrid.dataset.page = 1;
                fetchProducts(false);
            });
        });
        ratingFilters.forEach(cb => cb.addEventListener('change', function(){
            productsGrid.dataset.page = 1;
            fetchProducts(false);
        }));
        brandFilters.forEach(cb => cb.addEventListener('change', function(){
            productsGrid.dataset.page = 1;
            fetchProducts(false);
        }));
        attributeFilters.forEach(cb => cb.addEventListener('change', function(){
            productsGrid.dataset.page = 1;
            fetchProducts(false);
        }));

        // Infinite scroll when near bottom of page
        window.addEventListener('scroll', function(){
            const scrollPosition = window.innerHeight + window.scrollY;
            const threshold = document.body.offsetHeight - 500;
            if (scrollPosition > threshold && !isLoading) {
                // Increment page and fetch next set
                let currentPage = parseInt(productsGrid.dataset.page);
                currentPage++;
                productsGrid.dataset.page = currentPage;
                fetchProducts(true);
            }
        });
        // Mobile filter toggle
        const mobileFilterToggle = document.getElementById('mobile-filter-toggle');
        mobileFilterToggle.addEventListener('click', function(){
            const sidebar = document.getElementById('caricove-filters-sidebar');
            sidebar.style.display = sidebar.style.display === 'block' ? 'none' : 'block';
        });
        // Sort toggle (for demonstration, not implemented yet)
        document.getElementById('mobile-sort-toggle').addEventListener('click', function(){
            alert('Sort options coming soon!');
        });
    });
    </script>

    <?php
    return ob_get_clean();
}

/**
 * Handles AJAX requests to filter products. Queries WooCommerce products based on
 * selected filters passed via GET parameters and returns the corresponding HTML
 * markup for each product card. This function runs on the admin_ajax and
 * admin_ajax_nopriv hooks.
 */
add_action('wp_ajax_caricove_filter_products', 'caricove_ajax_filter_products');
add_action('wp_ajax_nopriv_caricove_filter_products', 'caricove_ajax_filter_products');
function caricove_ajax_filter_products() {
    // Sanitize and retrieve query parameters
    $paged     = isset($_GET['paged'])     ? max(1, (int)$_GET['paged']) : 1;
    $per_page  = isset($_GET['per_page'])  ? max(1, (int)$_GET['per_page']) : 8;
    $max_price = isset($_GET['max_price']) ? floatval($_GET['max_price']) : 0;
    $ratings   = isset($_GET['ratings'])   ? array_map('intval', explode(',', sanitize_text_field($_GET['ratings']))) : [];
    $brands    = isset($_GET['brands'])    ? array_map('sanitize_text_field', explode(',', $_GET['brands'])) : [];
    $in_stock  = isset($_GET['in_stock'])  && $_GET['in_stock'] === '1';
    // Collect attribute filters dynamically
    $tax_query = [];
    foreach ($_GET as $key => $value) {
        if (strpos($key, 'pa_') === 0 && !empty($value)) {
            $tax_query[] = [
                'taxonomy' => wc_attribute_taxonomy_name($key),
                'field'    => 'slug',
                'terms'    => array_map('sanitize_text_field', explode(',', $value)),
                'operator' => 'IN',
            ];
        }
    }
    if (!empty($brands)) {
        $tax_query[] = [
            'taxonomy' => 'product_brand',
            'field'    => 'slug',
            'terms'    => $brands,
            'operator' => 'IN',
        ];
    }
    if (!empty($tax_query)) {
        // Ensure proper relation if multiple tax queries exist
        $tax_query['relation'] = 'AND';
    }
    // Meta query for price and stock
    $meta_query = [];
    // Price max
    if ($max_price > 0) {
        $meta_query[] = [
            'key'     => '_price',
            'value'   => $max_price,
            'compare' => '<=',
            'type'    => 'NUMERIC',
        ];
    }
    // Stock
    if ($in_stock) {
        $meta_query[] = [
            'key'     => '_stock_status',
            'value'   => 'instock',
            'compare' => '=',
        ];
    }
    if (!empty($meta_query)) {
        $meta_query['relation'] = 'AND';
    }
    // Rating filtering: convert min rating threshold to post__in array of product IDs meeting that rating threshold
    $post__in = [];
    if (!empty($ratings)) {
        // Build a list of product IDs that meet any of the selected rating thresholds
        $rating_ids = [];
        foreach ($ratings as $r) {
            global $wpdb;
            // Query products with average rating >= threshold
            $ids = $wpdb->get_col($wpdb->prepare("SELECT post_id FROM {$wpdb->prefix}commentmeta cm
                JOIN {$wpdb->prefix}comments c ON c.comment_ID = cm.comment_id
                JOIN {$wpdb->prefix}posts p ON p.ID = c.comment_post_ID
                WHERE cm.meta_key = 'rating'
                AND cm.meta_value >= %d
                AND p.post_type = 'product'", $r));
            $rating_ids = array_merge($rating_ids, $ids);
        }
        $post__in = array_unique($rating_ids);
    }
    // Build final query args
    $args = [
        'post_type'      => 'product',
        'post_status'    => 'publish',
        'posts_per_page' => $per_page,
        'paged'          => $paged,
        'tax_query'      => $tax_query,
        'meta_query'     => $meta_query,
        'post__in'       => !empty($post__in) ? $post__in : undefined,
        'orderby'        => 'date',
        'order'          => 'DESC',
    ];
    // Remove undefined value (not allowed in args)
    if ($args['post__in'] === undefined) {
        unset($args['post__in']);
    }
    $query = new WP_Query($args);
    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
            $product = wc_get_product(get_the_ID());
            // Build swatches for color/size (first attribute only for demonstration)
            $swatches_html = '';
            $attributes = $product->get_attributes();
            foreach ($attributes as $attr_tax => $attribute) {
                if ($attribute->get_variation()) {
                    $options = $attribute->get_options();
                    foreach ($options as $option) {
                        $term = get_term_by('id', $option, $attr_tax);
                        if ($term) {
                            $color = '';
                            if (strpos($attr_tax, 'color') !== false) {
                                $color_meta = get_term_meta($term->term_id, 'pa_color_value', true);
                                if ($color_meta) {
                                    $color = 'style="background:' . esc_attr($color_meta) . '"';
                                }
                            }
                            $swatches_html .= '<span class="caricove-swatch" ' . $color . ' title="' . esc_attr($term->name) . '"></span>';
                        }
                    }
                    break; // only handle first variation attribute
                }
            }
            echo '<div class="caricove-product-card">';
            echo '<a href="' . get_permalink() . '">';
            echo $product->get_image();
            echo '<div class="caricove-product-title">' . get_the_title() . '</div>';
            echo '<div class="caricove-product-rating">' . wc_get_rating_html($product->get_average_rating()) . '</div>';
            echo '<div class="caricove-product-price">' . $product->get_price_html() . '</div>';
            if ($swatches_html) {
                echo '<div class="caricove-swatches">' . $swatches_html . '</div>';
            }
            echo '</a>';
            echo '<a href="' . esc_url(wc_get_checkout_url() . '?add-to-cart=' . $product->get_id()) . '" class="caricove-buy-btn">Buy Now</a>';
            echo '</div>';
        }
        wp_reset_postdata();
    } else {
        echo '<p>No products found</p>';
    }
    wp_die();
}