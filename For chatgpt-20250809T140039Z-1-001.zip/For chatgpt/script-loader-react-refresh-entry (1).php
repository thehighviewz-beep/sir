<?php return array('dependencies' => array('wp-react-refresh-runtime'), 'version' => '461b2e321e6e009f2209');
