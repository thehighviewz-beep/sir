
<?php
// Caricove Amazon-Style Category Page with Variations

add_shortcode('caricove_category_page', function() {
    ob_start();
    ?>
    <style>
    .caricove-container { display: flex; flex-wrap: wrap; gap: 20px; margin: 20px; font-family: 'Segoe UI', sans-serif; }
    .caricove-filters {
        flex: 1;
        min-width: 250px;
        max-width: 280px;
        background: linear-gradient(to bottom right, #0e0e0e, #1a1a1a);
        color: white;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 0 20px #00ffff55;
    }
    .caricove-filters h3 { font-size: 20px; margin-bottom: 15px; }
    .caricove-filters label, .caricove-filters select, .caricove-filters input[type="checkbox"], .caricove-filters button {
        display: block; width: 100%; margin-bottom: 12px;
    }
    .caricove-filters button {
        background: #00f0ff; color: black; font-weight: bold;
        border: none; padding: 10px; border-radius: 8px; cursor: pointer;
    }
    .caricove-products {
        flex: 3;
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
        gap: 20px;
    }
    .caricove-product {
        background: #fff; border-radius: 10px; padding: 15px;
        box-shadow: 0 0 10px #aaa; position: relative;
        transition: transform 0.3s ease;
    }
    .caricove-product:hover { transform: scale(1.03); }
    .caricove-product img {
        width: 100%; max-height: 200px; object-fit: contain;
        transition: transform 0.3s ease;
    }
    .caricove-product:hover img { transform: scale(1.1); }
    .caricove-product h4 { font-size: 16px; margin: 10px 0; }
    .caricove-product .price { font-size: 16px; font-weight: bold; color: #007b00; }
    .caricove-product .buy-btn {
        display: block; text-align: center; margin-top: 10px;
        background: linear-gradient(45deg, #00d9ff, #007bff); color: white;
        padding: 10px; border-radius: 8px; text-decoration: none;
        font-weight: bold; box-shadow: 0 0 10px #00f0ff;
    }
    .variation-swatches {
        margin-top: 10px;
        display: flex;
        flex-wrap: wrap;
        gap: 6px;
    }
    .swatch {
        display: inline-block;
        padding: 6px 10px;
        background: #eee;
        border-radius: 5px;
        font-size: 13px;
        cursor: pointer;
    }
    @media (max-width: 768px) {
        .caricove-container { flex-direction: column; }
        .caricove-filters { width: 100%; margin-bottom: 20px; }
    }
    </style>

    <div class="caricove-container">
        <div class="caricove-filters">
            <h3>Filter 🔍</h3>
            <label>Price Range</label>
            <select id="filter-price">
                <option value="">All</option>
                <option value="0-25">$0 – $25</option>
                <option value="25-50">$25 – $50</option>
                <option value="50-100">$50 – $100</option>
                <option value="100-9999">$100+</option>
            </select>
            <label>Rating</label>
            <select id="filter-rating">
                <option value="">All Ratings</option>
                <option value="3">3★ & up</option>
                <option value="4">4★ & up</option>
                <option value="5">5★ only</option>
            </select>
            <label><input type="checkbox" id="filter-stock"> In Stock Only</label>
            <button onclick="applyCaricoveFilters()">Apply Filters</button>
        </div>
        <div class="caricove-products" id="caricove-product-list"></div>
    </div>

    <script>
    let page = 1;
    let loading = false;

    function applyCaricoveFilters() {
        page = 1;
        document.getElementById('caricove-product-list').innerHTML = '';
        loadMoreCaricoveProducts();
    }

    function loadMoreCaricoveProducts() {
        if (loading) return;
        loading = true;
        const price = document.getElementById('filter-price').value;
        const rating = document.getElementById('filter-rating').value;
        const stock = document.getElementById('filter-stock').checked ? 1 : 0;
        fetch('/wp-admin/admin-ajax.php?action=caricove_load_products&page=' + page + '&price=' + price + '&rating=' + rating + '&stock=' + stock)
        .then(res => res.text())
        .then(data => {
            document.getElementById('caricove-product-list').insertAdjacentHTML('beforeend', data);
            page++;
            loading = false;
        });
    }

    window.addEventListener('scroll', () => {
        if ((window.innerHeight + window.scrollY) >= document.body.offsetHeight - 300) {
            loadMoreCaricoveProducts();
        }
    });

    document.addEventListener('DOMContentLoaded', () => {
        loadMoreCaricoveProducts();
    });
    </script>
    <?php
    return ob_get_clean();
});

add_action('wp_ajax_caricove_load_products', 'caricove_load_products');
add_action('wp_ajax_nopriv_caricove_load_products', 'caricove_load_products');

function caricove_load_products() {
    $page = intval($_GET['page'] ?? 1);
    $args = [
        'post_type' => 'product',
        'posts_per_page' => 8,
        'paged' => $page,
    ];
    $query = new WP_Query($args);
    while ($query->have_posts()) : $query->the_post();
        global $product;
        if (!$product) continue;
        $price_html = $product->get_price_html();
        ?>
        <div class="caricove-product">
            <img src="<?= get_the_post_thumbnail_url() ?>" alt="<?= get_the_title() ?>">
            <h4><?= get_the_title() ?></h4>
            <div class="price"><?= $price_html ?></div>
            <?php
            if ($product->is_type('variable')) {
                $available_variations = $product->get_available_variations();
                echo '<div class="variation-swatches">';
                foreach ($available_variations as $variation) {
                    $attributes = $variation['attributes'];
                    foreach ($attributes as $attr_val) {
                        echo '<div class="swatch">' . esc_html($attr_val) . '</div>';
                    }
                }
                echo '</div>';
            }
            ?>
            <a class="buy-btn" href="<?= esc_url( wc_get_checkout_url() . '?add-to-cart=' . $product->get_id() ) ?>">Buy Now</a>
        </div>
        <?php
    endwhile;
    wp_die();
}
?>
