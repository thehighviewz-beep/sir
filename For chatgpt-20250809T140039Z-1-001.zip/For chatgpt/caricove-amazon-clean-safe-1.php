<?php
add_shortcode('caricove_category_page', function() {
    ob_start();
    ?>
    <style>
        .caricove-wrapper {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }
        .caricove-filters {
            width: 25%;
            padding: 10px;
            background: #0f0f0f;
            border-radius: 10px;
        }
        .caricove-products {
            width: 70%;
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 20px;
        }
        .caricove-product {
            background: #1c1c1c;
            padding: 15px;
            border-radius: 10px;
            color: #fff;
            text-align: center;
            box-shadow: 0 0 15px #0ff4;
        }
        .caricove-product .buy-now {
            background: #0073ff;
            color: white;
            padding: 8px 16px;
            border-radius: 6px;
            text-decoration: none;
            display: inline-block;
            margin-top: 10px;
            box-shadow: 0 0 10px #00f9;
        }
        .zoom-container {
            overflow: hidden;
        }
        .zoom-container img {
            transition: transform 0.3s ease;
        }
        .zoom-container:hover img {
            transform: scale(1.3);
            cursor: zoom-in;
        }
        @media (max-width: 768px) {
            .caricove-wrapper {
                flex-direction: column;
            }
            .caricove-filters {
                width: 100%;
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                height: 100vh;
                z-index: 999;
                background: #111;
                overflow-y: auto;
                display: none;
            }
            .caricove-products {
                width: 100%;
            }
        }
    </style>

    <button id="toggle-filters" style="background:#0073ff;color:#fff;padding:10px 15px;border:none;border-radius:6px;margin-bottom:10px;">Filter 🔍</button>
    <div class="caricove-wrapper">
        <div class="caricove-filters">
            <input type="range" id="price_slider" min="0" max="1000" value="500">
            <select id="rating_filter">
                <option value="">Rating</option>
                <option value="1">1★ & up</option>
                <option value="2">2★ & up</option>
                <option value="3">3★ & up</option>
                <option value="4">4★ & up</option>
            </select>
            <label><input type="checkbox" id="in_stock"> In Stock Only</label>
            <button id="apply_filters">Apply Filters</button>
        </div>
        <div class="caricove-products" id="caricove-products"></div>
    </div>
    <div id="infinite-scroll-trigger" style="height:40px;"></div>

    <script>
    document.addEventListener("DOMContentLoaded", function() {
        let page = 1;
        const productsContainer = document.getElementById('caricove-products');

        function loadProducts(reset = false) {
            const price = document.getElementById('price_slider').value;
            const rating = document.getElementById('rating_filter').value;
            const stock = document.getElementById('in_stock').checked ? 1 : 0;

            const data = new FormData();
            data.append('action', 'caricove_load_products');
            data.append('page', page);
            data.append('price_max', price);
            data.append('rating', rating);
            data.append('in_stock', stock);

            fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                method: 'POST',
                body: data
            })
            .then(response => response.text())
            .then(html => {
                if (reset) productsContainer.innerHTML = '';
                productsContainer.insertAdjacentHTML('beforeend', html);
            });
        }

        loadProducts();

        document.getElementById('apply_filters').addEventListener('click', function () {
            page = 1;
            loadProducts(true);
        });

        document.getElementById('toggle-filters').addEventListener('click', function () {
            const filterBox = document.querySelector('.caricove-filters');
            filterBox.style.display = (filterBox.style.display === 'none' || filterBox.style.display === '') ? 'block' : 'none';
        });

        const observer = new IntersectionObserver(entries => {
            if (entries[0].isIntersecting) {
                page++;
                loadProducts();
            }
        }, {threshold: 1});
        observer.observe(document.getElementById('infinite-scroll-trigger'));
    });
    </script>
    <?php
    return ob_get_clean();
});

add_action('wp_ajax_caricove_load_products', 'caricove_load_products');
add_action('wp_ajax_nopriv_caricove_load_products', 'caricove_load_products');

function caricove_load_products() {
    $paged = isset($_POST['page']) ? intval($_POST['page']) : 1;
    $price = isset($_POST['price_max']) ? intval($_POST['price_max']) : 1000;
    $rating = isset($_POST['rating']) ? intval($_POST['rating']) : 0;
    $in_stock = isset($_POST['in_stock']) && $_POST['in_stock'] == 1;

    $args = array(
        'post_type' => 'product',
        'posts_per_page' => 8,
        'paged' => $paged,
        'meta_query' => array(
            array(
                'key' => '_price',
                'value' => array(0, $price),
                'compare' => 'BETWEEN',
                'type' => 'NUMERIC'
            )
        )
    );

    if ($rating) {
        $args['meta_query'][] = array(
            'key' => '_wc_average_rating',
            'value' => $rating,
            'compare' => '>=',
            'type' => 'NUMERIC'
        );
    }

    if ($in_stock) {
        $args['meta_query'][] = array(
            'key' => '_stock_status',
            'value' => 'instock'
        );
    }

    $query = new WP_Query($args);
    if ($query->have_posts()) :
        while ($query->have_posts()) : $query->the_post();
            global $product;
            ?>
            <div class="caricove-product">
                <a href="<?php the_permalink(); ?>">
                    <div class="zoom-container"><?php echo woocommerce_get_product_thumbnail(); ?></div>
                    <h3><?php the_title(); ?></h3>
                </a>
                <div class="price"><?php echo $product->get_price_html(); ?></div>
                <div class="rating"><?php echo wc_get_rating_html($product->get_average_rating()); ?></div>
                <a class="buy-now" href="<?php echo esc_url(wc_get_checkout_url() . '?add-to-cart=' . $product->get_id()); ?>">Buy Now</a>
            </div>
            <?php
        endwhile;
        wp_reset_postdata();
    else :
        echo "<p>No products found.</p>";
    endif;
    wp_die();
}
