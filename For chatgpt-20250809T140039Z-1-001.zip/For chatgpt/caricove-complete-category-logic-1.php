<?php
/*
 * Caricove: Full Amazon-Style Category Page – Unified Drop-In
 * Includes Phases 1, 2, and 3 – All Manual, All-in-One
 */

// ----------------------------
// 1. REMOVE COMPARE + READ MORE, ADD BUY NOW
// ----------------------------
add_action('init', function() {
    remove_action('woocommerce_after_shop_loop_item', 'YITH_WCQV_Frontend::print_button', 15);
    remove_action('woocommerce_after_shop_loop_item', 'yith_compare_button', 20);
});
add_filter('woocommerce_product_add_to_compare_enabled', '__return_false');

add_filter('woocommerce_loop_add_to_cart_link', function($button, $product) {
    if (!$product->is_in_stock() || !$product->is_purchasable()) return $button;
    $url = esc_url(wc_get_checkout_url() . '?add-to-cart=' . $product->get_id());
    return '<a href="' . $url . '" class="buy-now-button">Buy Now</a>';
}, 10, 2);

// ----------------------------
// 2. RENDER FILTERS + SHIPPING LOCATION + BREADCRUMBS
// ----------------------------
add_action('woocommerce_before_main_content', function() {
    if (function_exists('woocommerce_breadcrumb')) {
        woocommerce_breadcrumb();
    }
}, 5);

add_action('woocommerce_before_shop_loop', function() {
    $country = WC()->customer->get_shipping_country();
    echo '<div class="shipping-location-bar" style="margin: 1em 0; font-weight: bold; color: #00c2ff;">Now shipping to <strong>' . esc_html($country) . '</strong></div>';

    ?>
    <div class="caricove-filters">
        <h3>Filter Products</h3>
        <label for="min_price">Min Price</label>
        <input type="number" id="min_price" name="min_price" value="0" step="10">

        <label for="max_price">Max Price</label>
        <input type="number" id="max_price" name="max_price" value="1000" step="10">

        <div class="filter-group">
            <strong>Rating:</strong><br>
            <label><input type="radio" name="rating" value="4"> 4★ & up</label><br>
            <label><input type="radio" name="rating" value="3"> 3★ & up</label><br>
            <label><input type="radio" name="rating" value="2"> 2★ & up</label><br>
            <label><input type="radio" name="rating" value="1"> 1★ & up</label>
        </div>

        <label><input type="checkbox" id="in_stock" name="in_stock" value="1"> In Stock Only</label>
    </div>
    <?php
}, 9);

// ----------------------------
// 3. AJAX FILTER BACKEND
// ----------------------------
add_action('wp_ajax_caricove_ajax_filter', 'caricove_ajax_filter_handler');
add_action('wp_ajax_nopriv_caricove_ajax_filter', 'caricove_ajax_filter_handler');

function caricove_ajax_filter_handler() {
    $min_price = intval($_POST['min_price'] ?? 0);
    $max_price = intval($_POST['max_price'] ?? 10000);
    $rating = floatval($_POST['rating'] ?? 0);
    $in_stock = $_POST['in_stock'] ?? false;

    $args = array(
        'post_type' => 'product',
        'posts_per_page' => 12,
        'meta_query' => array(
            array(
                'key' => '_price',
                'value' => array($min_price, $max_price),
                'compare' => 'BETWEEN',
                'type' => 'NUMERIC'
            )
        )
    );

    if ($rating > 0) {
        $args['meta_query'][] = array(
            'key' => '_wc_average_rating',
            'value' => $rating,
            'compare' => '>=',
            'type' => 'NUMERIC'
        );
    }

    if ($in_stock) {
        $args['meta_query'][] = array(
            'key' => '_stock_status',
            'value' => 'instock'
        );
    }

    $query = new WP_Query($args);
    ob_start();
    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
            wc_get_template_part('content', 'product');
        }
    } else {
        echo '<p>No products found.</p>';
    }
    wp_reset_postdata();
    echo ob_get_clean();
    wp_die();
}

// ----------------------------
// 4. FRONTEND JS + HOVER ZOOM + CSS
// ----------------------------
add_action('wp_footer', function() {
    ?>
    <script>
    document.addEventListener("DOMContentLoaded", function() {
        const filters = document.querySelector(".caricove-filters");
        if (!filters) return;

        filters.addEventListener("change", function() {
            const min = document.getElementById("min_price").value;
            const max = document.getElementById("max_price").value;
            const rating = document.querySelector('input[name="rating"]:checked')?.value || '';
            const inStock = document.getElementById("in_stock").checked ? 1 : 0;

            const data = new FormData();
            data.append("action", "caricove_ajax_filter");
            data.append("min_price", min);
            data.append("max_price", max);
            data.append("rating", rating);
            data.append("in_stock", inStock);

            fetch("<?php echo admin_url('admin-ajax.php'); ?>", {
                method: "POST",
                body: data
            })
            .then(res => res.text())
            .then(html => {
                document.querySelector(".products").innerHTML = html;
            });
        });
    });
    </script>

    <style>
    .caricove-filters {
        background: #111;
        color: #f5f5f5;
        padding: 1rem;
        border-radius: 8px;
        margin-bottom: 1.5rem;
    }
    .caricove-filters input[type="number"] {
        width: 100%;
        padding: 0.5rem;
        margin-bottom: 1rem;
    }
    .buy-now-button {
        background: linear-gradient(to right, #00c2ff, #0073ff);
        color: white !important;
        padding: 10px 15px;
        border-radius: 6px;
        display: inline-block;
        font-weight: bold;
        text-align: center;
        box-shadow: 0 0 10px rgba(0, 174, 255, 0.6);
        text-decoration: none;
    }
    .buy-now-button:hover {
        background: linear-gradient(to right, #0073ff, #00c2ff);
    }
    .star-rating span::before {
        color: gold !important;
    }

    /* Hover Zoom */
    .woocommerce ul.products li.product .woocommerce-loop-product__link img {
        transition: transform 0.3s ease;
    }
    .woocommerce ul.products li.product:hover .woocommerce-loop-product__link img {
        transform: scale(1.08);
    }
    </style>
    <?php
});
