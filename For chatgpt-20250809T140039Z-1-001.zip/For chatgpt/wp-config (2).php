<?php
define('WP_MEMORY_LIMIT', '256M');
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the website, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'xruxdtmy_WPA4G');

/** Database username */
define('DB_USER', 'xruxdtmy_WPA4G');

/** Database password */
define('DB_PASSWORD', ']Qj{ydXC:{_6SN(/}');

/** Database hostname */
define('DB_HOST', 'localhost');

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY', '7b6ec17fa096bb8aa6de1d9e6f792366410db75c45c1747e3b9f134fda7595e9');
define('SECURE_AUTH_KEY', '41415967fa5054eeade1bc2c73ad1b76a386a515eb1d97fa0ad5044e4e5a120c');
define('LOGGED_IN_KEY', 'bfb56b1e99425e419988252275b180f61b5cbc8fa21cbb300252685e1cd03579');
define('NONCE_KEY', '690c31153cf79eb3914b381bc575ec52a535743f55ddd97cb2b0f9cfd4a4ad36');
define('AUTH_SALT', '5707e7fe9f66f767ad8c250dc89595e6dd3a9d1eae6ec6c5eff937885777938f');
define('SECURE_AUTH_SALT', '97d491aaad94c00f332f1d9f7c88c9dbab3b936d87b14942782a5fd876a78c85');
define('LOGGED_IN_SALT', '36be68a7b3cc816f788fb0a84a56f88aba58274942b32a4339754d02426cf837');
define('NONCE_SALT', 'ee9562890587a65e1fc12b31715ae852cfa62074345fd6f5e1efec7ac50a7ed3');

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 *
 * At the installation time, database tables are created with the specified prefix.
 * Changing this value after WordPress is installed will make your site think
 * it has not been installed.
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/#table-prefix
 */
$table_prefix = 'VzZ_';
define('WP_CRON_LOCK_TIMEOUT', 120);
define('AUTOSAVE_INTERVAL', 300);
define('WP_POST_REVISIONS', 20);
define('EMPTY_TRASH_DAYS', 7);
define('WP_AUTO_UPDATE_CORE', true);

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://developer.wordpress.org/advanced-administration/debug/debug-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */


define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
define('WP_DEBUG_DISPLAY', true);

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
