<?php
/*
 * Caricove Amazon-Style Product Category Page Shortcode
 * Paste this in functions.php and use [caricove_category_page]
 */

add_shortcode('caricove_category_page', function() {
    ob_start();
    ?>
    <div id="caricove-category-page">
        <!-- Breadcrumbs -->
        <div class="caricove-breadcrumbs">
            <?php if (function_exists('woocommerce_breadcrumb')) woocommerce_breadcrumb(); ?>
        </div>

        <!-- Shipping Location Row -->
        <div class="caricove-shipping-location">
            Now shipping to <strong><?php echo WC()->customer->get_shipping_country(); ?></strong>
        </div>

        <!-- Sticky Top Bar for Mobile -->
        <div class="caricove-topbar">
            <button class="toggle-filters">Filters</button>
            <div class="sort-options"><?php woocommerce_catalog_ordering(); ?></div>
            <div class="result-count"><?php woocommerce_result_count(); ?></div>
        </div>

        <div class="caricove-layout">
            <!-- Sidebar Filters -->
            <aside class="caricove-filters">
                <h3>Filter By</h3>
                <!-- Price Slider -->
                <label>Price Range ($)</label>
                <input type="range" id="price-min" min="0" max="1000" value="100">
                <input type="range" id="price-max" min="0" max="1000" value="800">
                <div class="price-values">From $<span id="price-min-val">100</span> to $<span id="price-max-val">800</span></div>

                <!-- Rating Filter -->
                <h4>Ratings</h4>
                <label><input type="radio" name="rating" value="4"> 4★ & up</label><br>
                <label><input type="radio" name="rating" value="3"> 3★ & up</label><br>
                <label><input type="radio" name="rating" value="2"> 2★ & up</label><br>
                <label><input type="radio" name="rating" value="1"> 1★ & up</label>

                <!-- Stock Filter -->
                <h4>Availability</h4>
                <label><input type="checkbox" id="in-stock" value="1"> In Stock Only</label>
            </aside>

            <!-- Product Grid -->
            <main class="caricove-products" id="caricove-product-grid">
                <?php if (woocommerce_product_loop()) : ?>
                    <ul class="products">
                        <?php while (have_posts()) : the_post(); global $product; ?>
                            <li class="product">
                                <div class="product-image">
                                    <a href="<?php the_permalink(); ?>">
                                        <?php echo woocommerce_get_product_thumbnail(); ?>
                                    </a>
                                </div>
                                <div class="product-details">
                                    <a class="product-title" href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                    <div class="rating"><?php echo wc_get_rating_html($product->get_average_rating()); ?></div>
                                    <div class="price"><?php echo $product->get_price_html(); ?></div>
                                    <a href="<?php echo esc_url( wc_get_checkout_url() . '?add-to-cart=' . $product->get_id() ); ?>" class="buy-now-button">Buy Now</a>
                                </div>
                            </li>
                        <?php endwhile; ?>
                    </ul>
                    <?php do_action('woocommerce_after_shop_loop'); ?>
                <?php else : ?>
                    <?php do_action('woocommerce_no_products_found'); ?>
                <?php endif; ?>
            </main>
        </div>
    </div>

    <style>
    /* Caricove Sexy Glowing Styles - Inline CSS */
    #caricove-category-page {
        font-family: 'Inter', sans-serif;
        color: #f5f5f5;
        padding: 1rem;
        background: #0c0c0c;
    }
    .caricove-breadcrumbs {
        font-size: 0.9rem;
        margin-bottom: 0.5rem;
        color: #ccc;
    }
    .caricove-shipping-location {
        font-weight: bold;
        margin-bottom: 1rem;
        color: #00c2ff;
    }
    .caricove-layout {
        display: flex;
        gap: 1rem;
    }
    @media (max-width: 768px) {
        .caricove-layout {
            flex-direction: column;
        }
    }
    .caricove-filters {
        background: #111;
        padding: 1rem;
        border-radius: 8px;
        width: 250px;
        flex-shrink: 0;
    }
    @media (max-width: 768px) {
        .caricove-filters {
            display: none;
        }
    }
    .caricove-filters input[type=range] {
        width: 100%;
        height: 6px;
        background: linear-gradient(to right, #0073ff, #00c2ff);
        border-radius: 4px;
        outline: none;
    }
    .caricove-filters input[type=range]::-webkit-slider-thumb {
        width: 20px;
        height: 20px;
        background: #fff;
        border: 2px solid #00c2ff;
        border-radius: 50%;
        box-shadow: 0 0 8px #00c2ff;
        cursor: pointer;
    }
    .caricove-products ul.products {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
        gap: 1rem;
        list-style: none;
        margin: 0;
        padding: 0;
    }
    .caricove-products .product {
        background: #1a1a1a;
        padding: 1rem;
        border-radius: 10px;
        transition: transform 0.2s, box-shadow 0.3s;
    }
    .caricove-products .product:hover {
        transform: translateY(-4px);
        box-shadow: 0 0 12px rgba(0, 194, 255, 0.4);
    }
    .caricove-products .product-image img {
        width: 100%;
        border-radius: 6px;
        transition: transform 0.3s ease;
    }
    .caricove-products .product-image:hover img {
        transform: scale(1.08);
    }
    .product-title {
        color: #fff;
        font-weight: bold;
        margin: 0.5rem 0;
        display: block;
        text-decoration: none;
    }
    .rating .star-rating span::before {
        color: gold !important;
    }
    .price {
        color: #00c2ff;
        font-size: 1.1rem;
        margin: 0.3rem 0;
    }
    .buy-now-button {
        background: linear-gradient(90deg, #00c2ff, #0073ff);
        color: #fff;
        padding: 0.5rem 1rem;
        border-radius: 6px;
        text-align: center;
        text-decoration: none;
        font-weight: bold;
        display: inline-block;
        margin-top: 0.5rem;
        box-shadow: 0 0 10px #00c2ff;
        transition: all 0.3s ease-in-out;
    }
    .buy-now-button:hover {
        background: linear-gradient(90deg, #0073ff, #00c2ff);
        box-shadow: 0 0 15px #00c2ff;
    }
    .caricove-topbar {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 1rem;
        padding: 0.5rem;
        background: #111;
        border-radius: 8px;
    }
    @media (max-width: 768px) {
        .caricove-topbar {
            position: sticky;
            top: 0;
            z-index: 100;
        }
    }
    .toggle-filters {
        background: #0073ff;
        color: #fff;
        padding: 0.4rem 0.8rem;
        border-radius: 4px;
        border: none;
        cursor: pointer;
    }
    .toggle-filters:hover {
        background: #00c2ff;
    }
    </style>

    <script>
    // Update displayed price values for slider
    document.addEventListener('DOMContentLoaded', function() {
        const minSlider = document.getElementById('price-min');
        const maxSlider = document.getElementById('price-max');
        const minVal = document.getElementById('price-min-val');
        const maxVal = document.getElementById('price-max-val');
        if (minSlider && maxSlider) {
            minSlider.addEventListener('input', () => minVal.textContent = minSlider.value);
            maxSlider.addEventListener('input', () => maxVal.textContent = maxSlider.value);
        }
    });
    </script>
    <?php
    return ob_get_clean();
});
?>