<?php
get_header();

$term = get_queried_object();
$term_name = $term->name;
$term_description = term_description($term);

?>
<style>
/* Reset & Container */
body {
  background: linear-gradient(to bottom right, #0a0f2c, #000);
  font-family: "Segoe UI", "Helvetica Neue", Arial, sans-serif;
  color: white;
  margin: 0;
  padding: 0;
}

.caricove-category-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 40px 20px;
}

/* Title */
.caricove-category-title {
  font-size: 2.5rem;
  font-weight: 700;
  color: white;
  margin-bottom: 10px;
  text-align: center;
}

/* Description */
.caricove-category-desc {
  font-size: 1rem;
  color: #ccc;
  text-align: center;
  margin-bottom: 40px;
}

/* Grid */
.caricove-product-grid {
  display: grid;
  gap: 30px;
  grid-template-columns: repeat(auto-fit, minmax(230px, 1fr));
}

/* Card */
.caricove-product {
  background: rgba(255, 255, 255, 0.05);
  border-radius: 15px;
  overflow: hidden;
  padding: 20px;
  transition: transform 0.3s ease, box-shadow 0.3s ease;
  position: relative;
  text-align: center;
}

.caricove-product:hover {
  transform: translateY(-5px);
  box-shadow: 0 0 30px rgba(0, 194, 255, 0.4);
}

/* Image */
.caricove-product img {
  max-width: 100%;
  height: 200px;
  object-fit: contain;
  margin-bottom: 15px;
}

/* Title */
.caricove-product-title {
  font-size: 1.1rem;
  color: white;
  font-weight: 600;
  margin-bottom: 10px;
}

/* Price */
.caricove-product-price {
  font-size: 1rem;
  color: #ffcc00;
  margin-bottom: 15px;
}

/* Buy Now Button */
.caricove-buy-now {
  background: linear-gradient(to right, #00d2ff, #3a47d5);
  color: white;
  padding: 10px 20px;
  border: none;
  font-weight: bold;
  text-transform: uppercase;
  border-radius: 50px;
  cursor: pointer;
  transition: background 0.3s ease;
  display: inline-block;
  text-decoration: none;
}

.caricove-buy-now:hover {
  background: linear-gradient(to right, #3a47d5, #00d2ff);
}

/* Mobile */
@media (max-width: 768px) {
  .caricove-category-title {
    font-size: 2rem;
  }

  .caricove-product-price {
    font-size: 0.95rem;
  }

  .caricove-buy-now {
    font-size: 0.9rem;
    padding: 8px 18px;
  }
}
</style>

<div class="caricove-category-container">
  <h1 class="caricove-category-title"><?php echo esc_html($term_name); ?></h1>
  <div class="caricove-category-desc"><?php echo esc_html($term_description); ?></div>

  <div class="caricove-product-grid">
    <?php if (have_posts()) : while (have_posts()) : the_post();
      global $product;
      if (!$product || !$product->is_visible()) continue;
    ?>
      <div class="caricove-product">
        <a href="<?php the_permalink(); ?>">
          <?php echo woocommerce_get_product_thumbnail(); ?>
          <div class="caricove-product-title"><?php the_title(); ?></div>
        </a>
        <div class="caricove-product-price"><?php echo $product->get_price_html(); ?></div>
        <a class="caricove-buy-now" href="<?php echo esc_url( wc_get_checkout_url() . '?add-to-cart=' . $product->get_id() ); ?>">Buy Now</a>
      </div>
    <?php endwhile; else : ?>
      <p style="color: white;">No products found in this category.</p>
    <?php endif; ?>
  </div>
</div>

<?php get_footer(); ?>
