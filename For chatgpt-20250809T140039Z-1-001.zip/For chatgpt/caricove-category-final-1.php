
<?php
// ===============================
// CARICOVE PRODUCT CATEGORY PAGE
// Amazon-style layout with cyberpunk Caribbean glowing UI
// ===============================

add_shortcode('caricove_category_page', 'caricove_category_page_shortcode');
function caricove_category_page_shortcode() {
    ob_start();
    ?>
    <style>
        /* Glowing Cyberpunk Product Cards */
        .caricove-product-card {
            background: #101010;
            border-radius: 16px;
            box-shadow: 0 0 10px rgba(0, 255, 255, 0.4);
            color: white;
            padding: 16px;
            margin: 16px 0;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }
        .caricove-product-card:hover {
            transform: scale(1.02);
            box-shadow: 0 0 20px rgba(0, 255, 255, 0.8);
        }
        .caricove-price-slider input[type=range] {
            width: 100%;
        }
        .caricove-buy-now {
            background: linear-gradient(90deg, #00f0ff, #0051ff);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 12px;
            font-weight: bold;
            cursor: pointer;
            box-shadow: 0 0 8px rgba(0, 240, 255, 0.5);
        }
        .caricove-buy-now:hover {
            box-shadow: 0 0 12px rgba(0, 240, 255, 1);
        }
        .caricove-loader {
            display: none;
            text-align: center;
            padding: 20px;
            color: #00ffff;
        }
    </style>

    <div id="caricove-category-page">
        <div id="caricove-filters">
            <h3>Filters</h3>
            <!-- Example: Price slider -->
            <div class="caricove-price-slider">
                <label>Price Range</label>
                <input type="range" min="10" max="500" />
            </div>
            <!-- Example: Ratings -->
            <div class="caricove-rating-filter">
                <label><input type="checkbox" /> ★★★★★</label><br>
                <label><input type="checkbox" /> ★★★★☆ & up</label><br>
            </div>
        </div>

        <div id="caricove-product-list">
            <?php
            $args = array('post_type' => 'product', 'posts_per_page' => 10);
            $loop = new WP_Query($args);
            while ($loop->have_posts()) : $loop->the_post(); global $product;
            ?>
                <div class="caricove-product-card">
                    <div class="caricove-product-image">
                        <img src="<?php echo get_the_post_thumbnail_url(); ?>" width="100%" />
                    </div>
                    <h2><?php the_title(); ?></h2>
                    <div class="caricove-price"><?php echo $product->get_price_html(); ?></div>
                    <button class="caricove-buy-now" onclick="location.href='<?php echo esc_url( $product->add_to_cart_url() ); ?>'">Buy Now</button>
                </div>
            <?php endwhile; wp_reset_query(); ?>
        </div>

        <div class="caricove-loader" id="caricove-loader">Loading more products…</div>
    </div>

    <script>
        // Infinite Scroll Logic
        let currentPage = 2;
        let loading = false;

        window.addEventListener('scroll', function() {
            if ((window.innerHeight + window.scrollY) >= document.body.offsetHeight - 500 && !loading) {
                loading = true;
                document.getElementById('caricove-loader').style.display = 'block';
                fetch(`/?paged=${currentPage}&action=infinite_scroll`, {
                    method: 'GET'
                }).then(response => response.text()).then(html => {
                    let parser = new DOMParser();
                    let doc = parser.parseFromString(html, 'text/html');
                    let products = doc.querySelectorAll('.caricove-product-card');
                    products.forEach(p => document.getElementById('caricove-product-list').appendChild(p));
                    document.getElementById('caricove-loader').style.display = 'none';
                    currentPage++;
                    loading = false;
                });
            }
        });
    </script>
    <?php
    return ob_get_clean();
}
?>
