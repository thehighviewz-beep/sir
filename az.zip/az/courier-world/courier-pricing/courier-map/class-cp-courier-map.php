<?php
if (!defined('ABSPATH')) { exit; }

final class CC_CP_Courier_Map {
    public static function init() {
        add_action('wp_ajax_cc_cp_get_courier_mode_data', array(__CLASS__, 'ajax_get_courier_mode_data'));
    }

    public static function ajax_get_courier_mode_data() {
        check_ajax_referer('cc_cp_admin_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Forbidden.'), 403);
        }
        wp_send_json_success(array('couriers' => self::get_active_couriers()));
    }

    public static function get_active_couriers() {
        $couriers = array();
        $shipmentsByCourier = self::get_active_shipments_by_courier();
        $userQuery = new WP_User_Query(array(
            'number' => 200,
            'meta_query' => array(
                array('key' => '_caricove_courier_gps_lat', 'compare' => 'EXISTS'),
                array('key' => '_caricove_courier_gps_lng', 'compare' => 'EXISTS'),
            ),
        ));
        foreach ((array) $userQuery->get_results() as $user) {
            $uid = (int) $user->ID;
            $profile = class_exists('\Caricove\Logistics\Core\CourierProfile')
                ? (array) \Caricove\Logistics\Core\CourierProfile::get_profile($uid)
                : array();

            $lat = $profile['last_lat'] ?? get_user_meta($uid, '_caricove_courier_gps_lat', true);
            $lng = $profile['last_lng'] ?? get_user_meta($uid, '_caricove_courier_gps_lng', true);
            if (!is_numeric($lat) || !is_numeric($lng)) continue;

            $mission = $shipmentsByCourier[$uid] ?? null;
            $couriers[] = array(
                'courier_id' => $uid,
                'name' => $user->display_name,
                'phone' => self::courier_phone($uid),
                'vehicle_type' => (string) ($profile['vehicle_type'] ?? get_user_meta($uid, '_caricove_courier_vehicle_type', true)),
                'status' => (string) ($profile['status'] ?? get_user_meta($uid, '_caricove_courier_status', true)),
                'last_seen' => (string) ($profile['last_seen_ts'] ?? get_user_meta($uid, '_caricove_courier_last_seen', true)),
                'coords' => array('lat' => (float) $lat, 'lng' => (float) $lng),
                'mission' => $mission,
            );
        }
        return $couriers;
    }

    private static function get_active_shipments_by_courier() {
        $statuses = class_exists('\Caricove\Logistics\Core\StatusMachine') && method_exists('\Caricove\Logistics\Core\StatusMachine', 'get_canonical_active_job_statuses')
            ? \Caricove\Logistics\Core\StatusMachine::get_canonical_active_job_statuses()
            : array('assigned','out_for_delivery','picked_up','in_transit','out_for_redelivery_day1','paid_redelivery_pending_confirmation','paid_redelivery_ready_for_dispatch');
        $query = new WP_Query(array(
            'post_type' => 'cc_shipment',
            'post_status' => 'any',
            'posts_per_page' => 200,
            'meta_query' => array(
                array('key' => '_cc_shipment_status', 'value' => $statuses, 'compare' => 'IN'),
            ),
        ));
        $map = array();
        foreach ((array) $query->posts as $post) {
            $shipmentId = (int) $post->ID;
            $summary = self::shipment_summary($shipmentId);
            $courierId = (int) ($summary['courier_id'] ?? get_post_meta($shipmentId, '_cc_shipment_courier_id', true));
            if (!$courierId) {
                $courierId = (int) get_post_meta($shipmentId, '_cc_assigned_courier_id', true);
            }
            if (!$courierId) continue;
            $map[$courierId] = array(
                'shipment_id' => $shipmentId,
                'status' => $summary['status'] ?? '',
                'pickup' => array(
                    'coords' => self::coords_array($summary['pickup_coords'] ?? get_post_meta($shipmentId, '_cc_shipment_pickup_coords', true)),
                    'address' => self::format_address($summary['pickup_address'] ?? json_decode((string) get_post_meta($shipmentId, '_cc_shipment_pickup_address', true), true)),
                    'name' => $summary['pickup_name'] ?? get_post_meta($shipmentId, '_cc_shipment_pickup_name', true),
                    'phone' => $summary['pickup_phone'] ?? get_post_meta($shipmentId, '_cc_shipment_pickup_phone', true),
                ),
                'dropoff' => array(
                    'coords' => self::coords_array($summary['dropoff_coords'] ?? get_post_meta($shipmentId, '_cc_shipment_dropoff_coords', true)),
                    'address' => self::format_address($summary['dropoff_address'] ?? json_decode((string) get_post_meta($shipmentId, '_cc_shipment_dropoff_address', true), true)),
                    'name' => $summary['dropoff_name'] ?? get_post_meta($shipmentId, '_cc_shipment_dropoff_name', true),
                    'phone' => $summary['dropoff_phone'] ?? get_post_meta($shipmentId, '_cc_shipment_dropoff_phone', true),
                ),
                'items' => self::shipment_items($summary),
                'weight_band' => (string) ($summary['weight_band'] ?? ''),
                'total_weight' => (float) ($summary['total_weight'] ?? 0),
                'recommended_vehicle' => (string) ($summary['recommended_vehicle'] ?? ''),
                'size_band' => (string) ($summary['size_band'] ?? ''),
                'payout_gyd' => self::shipment_payout($shipmentId),
                'route_points' => array_values(array_filter(array(
                    self::coords_array($summary['pickup_coords'] ?? get_post_meta($shipmentId, '_cc_shipment_pickup_coords', true)),
                    self::coords_array($summary['dropoff_coords'] ?? get_post_meta($shipmentId, '_cc_shipment_dropoff_coords', true)),
                ))),
            );
        }
        wp_reset_postdata();
        return $map;
    }

    private static function shipment_summary($shipmentId) {
        if (class_exists('\Caricove\Logistics\Core\ShipmentManager') && method_exists('\Caricove\Logistics\Core\ShipmentManager', 'get_shipment_summary')) {
            return (array) \Caricove\Logistics\Core\ShipmentManager::get_shipment_summary($shipmentId);
        }
        return array();
    }

    private static function shipment_items(array $summary) {
        $items = array();
        $orderId = (int) ($summary['order_id'] ?? 0);
        if ($orderId && function_exists('wc_get_order')) {
            $order = wc_get_order($orderId);
            if ($order) {
                foreach ($order->get_items() as $item) {
                    $items[] = $item->get_name();
                }
            }
        }
        if (!$items) {
            $count = (int) ($summary['item_count'] ?? 0);
            if ($count > 0) {
                $items[] = sprintf('%d item(s)', $count);
            }
        }
        return array_values(array_slice($items, 0, 8));
    }

    private static function shipment_payout($shipmentId) {
        $stored = get_post_meta($shipmentId, '_cc_cp_quote_total_gyd', true);
        if (is_numeric($stored)) return (float) $stored;
        if (class_exists('CC_CP_Engine')) {
            $quote = CC_CP_Engine::quote_for_shipment($shipmentId);
            if (!is_wp_error($quote)) {
return (float) (isset($quote['total']) ? $quote['total'] : ($quote['total_shipping_fee'] ?? 0));            }
        }
        return 0;
    }

    private static function coords_array($value) {
        if (is_array($value) && isset($value['lat'], $value['lng'])) return array('lat'=>(float)$value['lat'],'lng'=>(float)$value['lng']);
        if (!is_string($value) || strpos($value, ',') === false) return null;
        list($lat, $lng) = array_map('trim', explode(',', $value, 2));
        if (!is_numeric($lat) || !is_numeric($lng)) return null;
        return array('lat'=>(float)$lat,'lng'=>(float)$lng);
    }

    private static function format_address($value) {
        if (is_array($value)) {
            return trim(implode(', ', array_filter(array_map('strval', $value))));
        }
        return trim((string) $value);
    }

    private static function courier_phone($userId) {
        foreach (array('billing_phone','phone','mobile_number','mobile_phone','_cc_phone') as $key) {
            $v = (string) get_user_meta($userId, $key, true);
            if ($v !== '') return $v;
        }
        return '';
    }
}
