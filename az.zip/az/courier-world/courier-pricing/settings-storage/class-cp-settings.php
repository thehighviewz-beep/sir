<?php
if (!defined('ABSPATH')) { exit; }

final class CC_CP_Settings {
    const OPT_PRICING = 'cc_cp_pricing_settings_v1';
    const OPT_INTELLIGENCE = 'cc_cp_intelligence_settings_v1';
    const OPT_KNOB_MODES = 'cc_cp_knob_modes_v1';
    const OPT_KNOB_META = 'cc_cp_knob_meta_v1';

    public static function init() {
        add_action('admin_init', array(__CLASS__, 'maybe_seed_defaults'));
    }

    public static function maybe_seed_defaults() {
        self::seed_option(self::OPT_PRICING, self::pricing_defaults());
        self::seed_option(self::OPT_INTELLIGENCE, self::intelligence_defaults());
        self::seed_option(self::OPT_KNOB_MODES, self::knob_mode_defaults());
        self::seed_option(self::OPT_KNOB_META, array());
    }

    private static function seed_option($key, $default) {
        if (false === get_option($key, false)) {
            add_option($key, $default, '', false);
        }
    }

    public static function zone_type_choices() {
        return array(
            'dense_urban' => 'Dense Urban',
            'suburban'    => 'Suburban',
            'linear'      => 'Linear',
            'rural'       => 'Rural',
            'remote'      => 'Remote',
        );
    }

    public static function block_type_choices() {
        return array(
            'easy_roadside' => 'Easy / Roadside',
            'standard'      => 'Standard',
            'interior'      => 'Interior',
            'hard_access'   => 'Hard Access',
        );
    }

    public static function pricing_defaults() {
        return array(
            'trip_bands' => array(
                'extra_short' => array('max_km' => 3, 'base_fee' => 200, 'first_2_km_rate' => 125, 'next_3_km_rate' => 120, 'remaining_km_rate' => 120, 'platform_spread' => 150),
                'short'       => array('max_km' => 7, 'base_fee' => 300, 'first_2_km_rate' => 125, 'next_3_km_rate' => 120, 'remaining_km_rate' => 115, 'platform_spread' => 150),
                'medium'      => array('max_km' => 15, 'base_fee' => 400, 'first_2_km_rate' => 120, 'next_3_km_rate' => 115, 'remaining_km_rate' => 110, 'platform_spread' => 150, 'haul_threshold_km' => 8, 'haul_buffer' => 250),
                'long'        => array('base_fee' => 500, 'first_2_km_rate' => 120, 'next_3_km_rate' => 115, 'remaining_km_rate' => 110, 'platform_spread' => 150, 'haul_threshold_km' => 17, 'haul_buffer' => 1100),
            ),
            'minimum_fee' => 400,
            'zone_adjustments' => array(
                'dense_urban' => 75,
                'suburban'    => 0,
                'linear'      => -50,
                'rural'       => 250,
                'remote'      => 700,
            ),
            'block_modifiers' => array(
                'easy_roadside' => 0,
                'standard'      => 0,
                'interior'      => 200,
                'hard_access'   => 400,
            ),
        );
    }

    public static function intelligence_defaults() {
        return array(
            'confidence_threshold_pct' => 80,
            'sample_threshold' => 100,
            'adjustment_step' => 50,
            'cooldown_hours' => 6,
            'cooldown_shipments' => 50,
            'max_adjustment_limit' => 1000,
            'acceptance_weight' => 0.5,
            'duration_weight' => 0.3,
            'acceptance_time_weight' => 0.2,
        );
    }

    public static function knob_mode_defaults() {
        $manual = array(
            'global.minimum_fee' => 'manual',
        );
        foreach (array('extra_short','short','medium','long') as $key) {
            $manual['band.' . $key . '.base_fee'] = 'manual';
            $manual['band.' . $key . '.first_2_km_rate'] = 'manual';
            $manual['band.' . $key . '.next_3_km_rate'] = 'manual';
            $manual['band.' . $key . '.remaining_km_rate'] = 'manual';
            if ($key !== 'long') $manual['band.' . $key . '.max_km'] = 'manual';
                        $manual['band.' . $key . '.platform_spread'] = 'manual';
            if (in_array($key, array('medium','long'), true)) {
                $manual['band.' . $key . '.haul_threshold_km'] = 'manual';
                $manual['band.' . $key . '.haul_buffer'] = 'manual';
            }
        }
        foreach (array_keys(self::zone_type_choices()) as $key) {
            $manual['zone.' . $key] = 'manual';
        }
        foreach (array_keys(self::block_type_choices()) as $key) {
            $manual['block.' . $key] = 'manual';
        }
        return $manual;
    }

    public static function get_pricing() {
        return self::sanitize_pricing((array) get_option(self::OPT_PRICING, self::pricing_defaults()));
    }

    public static function get_intelligence() {
        return self::sanitize_intelligence((array) get_option(self::OPT_INTELLIGENCE, self::intelligence_defaults()));
    }

    public static function get_knob_modes() {
        $saved = (array) get_option(self::OPT_KNOB_MODES, self::knob_mode_defaults());
        return array_replace(self::knob_mode_defaults(), array_map(function($v){ return $v === 'auto' ? 'auto' : 'manual'; }, $saved));
    }

    public static function get_knob_meta() {
        $saved = get_option(self::OPT_KNOB_META, array());
        return is_array($saved) ? $saved : array();
    }

    public static function all() {
        return array(
            'pricing' => self::get_pricing(),
            'intelligence' => self::get_intelligence(),
            'knob_modes' => self::get_knob_modes(),
            'zone_types' => self::zone_type_choices(),
            'block_types' => self::block_type_choices(),
        );
    }

    public static function save_all(array $payload) {
        if (isset($payload['pricing'])) {
            update_option(self::OPT_PRICING, self::sanitize_pricing((array) $payload['pricing']), false);
        }
        if (isset($payload['intelligence'])) {
            update_option(self::OPT_INTELLIGENCE, self::sanitize_intelligence((array) $payload['intelligence']), false);
        }
        if (isset($payload['knob_modes'])) {
            $modes = self::get_knob_modes();
            foreach ((array) $payload['knob_modes'] as $key => $mode) {
                $modes[sanitize_key($key)] = ($mode === 'auto') ? 'auto' : 'manual';
            }
            update_option(self::OPT_KNOB_MODES, $modes, false);
        }
    }

    public static function set_knob_mode($knob, $mode) {
        $modes = self::get_knob_modes();
        $modes[sanitize_key($knob)] = ($mode === 'auto') ? 'auto' : 'manual';
        update_option(self::OPT_KNOB_MODES, $modes, false);
        return $modes;
    }

    public static function get_knob_mode($knob) {
        $modes = self::get_knob_modes();
        $knob = sanitize_key($knob);
        return isset($modes[$knob]) && $modes[$knob] === 'auto' ? 'auto' : 'manual';
    }

 public static function touch_knob_meta($knob, array $payload = array()) {
    $meta = self::get_knob_meta();
    $knob = sanitize_key($knob);
    $current = isset($meta[$knob]) && is_array($meta[$knob]) ? $meta[$knob] : array();

    $current['last_adjusted_at'] = current_time('timestamp', true);

    if (isset($payload['last_samples'])) {
        $current['last_samples'] = absint($payload['last_samples']);
    }

    if (isset($payload['last_direction'])) {
        $current['last_direction'] = sanitize_key($payload['last_direction']);
    }

    if (isset($payload['last_event_id'])) {
        $current['last_event_id'] = absint($payload['last_event_id']);
    }

    $meta[$knob] = $current;
    update_option(self::OPT_KNOB_META, $meta, false);

    return $current;
}

    public static function get_zone_adjustment($type) {
        $pricing = self::get_pricing();
        return CC_CP_Storage::money($pricing['zone_adjustments'][self::normalize_zone_type($type)] ?? 0);
    }

    public static function get_block_modifier($type) {
        $pricing = self::get_pricing();
        return CC_CP_Storage::money($pricing['block_modifiers'][self::normalize_block_type($type)] ?? 0);
    }

    public static function normalize_zone_type($type) {
        $type = sanitize_key((string) $type);
        return array_key_exists($type, self::zone_type_choices()) ? $type : 'suburban';
    }

    public static function normalize_block_type($type) {
        $type = sanitize_key((string) $type);
        return array_key_exists($type, self::block_type_choices()) ? $type : 'standard';
    }

    private static function sanitize_pricing(array $raw) {
        $defaults = self::pricing_defaults();
        $raw = array_replace_recursive($defaults, $raw);
        $out = array(
            'trip_bands' => array(),
            'minimum_fee' => max(0, CC_CP_Storage::money($raw['minimum_fee'] ?? $defaults['minimum_fee'])),
            'zone_adjustments' => array(),
            'block_modifiers' => array(),
        );

        foreach (array('extra_short','short','medium','long') as $band_key) {
            $band = isset($raw['trip_bands'][$band_key]) && is_array($raw['trip_bands'][$band_key]) ? $raw['trip_bands'][$band_key] : array();
            $default_band = $defaults['trip_bands'][$band_key];
            $clean = array(
                'base_fee' => CC_CP_Storage::money($band['base_fee'] ?? $default_band['base_fee']),
                'first_2_km_rate' => CC_CP_Storage::money($band['first_2_km_rate'] ?? $default_band['first_2_km_rate']),
                'next_3_km_rate' => CC_CP_Storage::money($band['next_3_km_rate'] ?? $default_band['next_3_km_rate']),
                'remaining_km_rate' => CC_CP_Storage::money($band['remaining_km_rate'] ?? $default_band['remaining_km_rate']),
                'platform_spread' => CC_CP_Storage::money($band['platform_spread'] ?? ($default_band['platform_spread'] ?? 0)),
            );
            if ($band_key !== 'long') {
                $clean['max_km'] = max(0, (float)($band['max_km'] ?? $default_band['max_km']));
            }
            if (in_array($band_key, array('medium','long'), true)) {
                $clean['haul_threshold_km'] = max(0, (float)($band['haul_threshold_km'] ?? ($default_band['haul_threshold_km'] ?? 0)));
                $clean['haul_buffer'] = CC_CP_Storage::money($band['haul_buffer'] ?? ($default_band['haul_buffer'] ?? 0));
            }
            $out['trip_bands'][$band_key] = $clean;
        }
        foreach (self::zone_type_choices() as $key => $label) {
            $out['zone_adjustments'][$key] = CC_CP_Storage::money($raw['zone_adjustments'][$key] ?? $defaults['zone_adjustments'][$key]);
        }
        foreach (self::block_type_choices() as $key => $label) {
            $out['block_modifiers'][$key] = CC_CP_Storage::money($raw['block_modifiers'][$key] ?? $defaults['block_modifiers'][$key]);
        }
        return $out;
    }

    private static function sanitize_intelligence(array $raw) {
        $defaults = self::intelligence_defaults();
        $raw = array_replace($defaults, $raw);
        return array(
            'confidence_threshold_pct' => max(1, min(100, absint($raw['confidence_threshold_pct']))),
            'sample_threshold' => max(1, absint($raw['sample_threshold'])),
            'adjustment_step' => max(1, CC_CP_Storage::money($raw['adjustment_step'])),
            'cooldown_hours' => max(1, absint($raw['cooldown_hours'])),
            'cooldown_shipments' => max(1, absint($raw['cooldown_shipments'])),
            'max_adjustment_limit' => max(1, CC_CP_Storage::money($raw['max_adjustment_limit'])),
            'acceptance_weight' => max(0, min(1, (float) $raw['acceptance_weight'])),
            'duration_weight' => max(0, min(1, (float) $raw['duration_weight'])),
            'acceptance_time_weight' => max(0, min(1, (float) $raw['acceptance_time_weight'])),
        );
    }
}
