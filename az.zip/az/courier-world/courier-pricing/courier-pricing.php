<?php
/**
 * Plugin Name: Caricove Courier Pricing Planner
 * Description: Shipping Fee Planner with persistent Map UI, zones, blocks, anchors, manual overrides, automatic pricing, intelligence, and courier-mode admin map.
 * Version: 0.2.0
 * Author: OpenAI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! defined( 'CC_CP_VERSION' ) ) {
	define( 'CC_CP_VERSION', '0.2.0' );
}

if ( ! defined( 'CC_CP_FILE' ) ) {
	define( 'CC_CP_FILE', __FILE__ );
}

if ( ! defined( 'CC_CP_DIR' ) ) {
	define( 'CC_CP_DIR', __DIR__ . '/' );
}

if ( ! defined( 'CC_CP_URL' ) ) {
	$mu_base = trailingslashit( WPMU_PLUGIN_URL );
	$mu_dir  = wp_normalize_path( WPMU_PLUGIN_DIR );
	$mod_dir = wp_normalize_path( __DIR__ );
	$rel     = ltrim( str_replace( $mu_dir, '', $mod_dir ), '/' );
	define( 'CC_CP_URL', trailingslashit( $mu_base . $rel ) );
}

require_once CC_CP_DIR . 'includes/class-cp-storage.php';
require_once CC_CP_DIR . 'settings-storage/class-cp-settings.php';
require_once CC_CP_DIR . 'routing-client/class-cp-routing-client.php';
require_once CC_CP_DIR . 'pricing-calculator/class-cp-pricing-calculator.php';
require_once CC_CP_DIR . 'intelligence-module/class-cp-intelligence.php';
require_once CC_CP_DIR . 'courier-map/class-cp-courier-map.php';
require_once CC_CP_DIR . 'includes/class-cp-engine.php';
require_once CC_CP_DIR . 'includes/class-cp-checkout-shipping.php';
require_once CC_CP_DIR . 'includes/class-cp-admin.php';
require_once CC_CP_DIR . 'admin-ui/class-cp-admin-upgrade.php';

if ( ! class_exists( 'CC_Courier_Pricing_Planner' ) ) {
	final class CC_Courier_Pricing_Planner {
		public static function init() {
			if ( class_exists( 'CC_CP_Storage' ) ) {
				CC_CP_Storage::init();
			}
			if ( class_exists( 'CC_CP_Settings' ) ) {
				CC_CP_Settings::init();
			}
			if ( class_exists( 'CC_CP_Intelligence' ) ) {
				CC_CP_Intelligence::init();
			}
			if ( class_exists( 'CC_CP_Courier_Map' ) ) {
				CC_CP_Courier_Map::init();
			}
			if ( class_exists( 'CC_CP_Checkout_Shipping' ) ) {
				CC_CP_Checkout_Shipping::init();
			}
			if ( class_exists( 'CC_CP_Admin' ) ) {
				CC_CP_Admin::init();
			}
			if ( class_exists( 'CC_CP_Admin_Upgrade' ) ) {
				CC_CP_Admin_Upgrade::init();
			}
		}
	}
}

CC_Courier_Pricing_Planner::init();