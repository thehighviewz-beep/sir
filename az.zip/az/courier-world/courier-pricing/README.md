# Caricove Courier Pricing Planner

Initial scaffold for a `courier-pricing` plugin/folder.

## What it includes

- Admin page: **Shipping Fee Planner**
- Tabs:
  - **Map UI**
  - **Pricing Table**
  - **Lane Intelligence** (scaffold)
- Persistent storage for:
  - zones
  - blocks
  - anchors
  - lanes
- Full-screen map mode
- Map-driven lane creation that writes directly into the pricing table
- Fee engine helper that resolves seller/customer coordinates into blocks, then calculates:
  - manual pricing
  - size modifier
  - weight modifier
  - buffer cost
  - platform spread
  - total shipping fee

## Files

- `courier-pricing.php` — plugin bootstrap
- `includes/class-cp-storage.php` — persistent storage + block/zone/anchor/lane helpers
- `includes/class-cp-engine.php` — shipping fee calculation helper
- `includes/class-cp-admin.php` — admin UI + AJAX handlers
- `assets/admin.js` — map and table UI logic
- `assets/admin.css` — planner styles

## Current storage keys

- `cc_cp_zones`
- `cc_cp_blocks`
- `cc_cp_anchors`
- `cc_cp_lanes`

Also mirrors into compatibility options for the wider logistics universe:

- `_cc_zone_definitions`
- `_cc_anchor_definitions`
- `_cc_block_definitions`
- `_cc_lane_pricing_definitions`

## Notes

- The map is built with **MapLibre GL**.
- The style URL is filterable with:
  - `cc_cp_map_style_url`
- The map center is filterable with:
  - `cc_cp_map_center`
- The map zoom is filterable with:
  - `cc_cp_map_zoom`

## Example fee calculation

```php
$result = CC_CP_Engine::calculate_shipping_fee(array(
    'seller_lat'   => 6.8043,
    'seller_lng'   => -58.1558,
    'customer_lat' => 6.7891,
    'customer_lng' => -58.1322,
    'size_class'   => 'standard',
    'weight_class' => 'heavy',
));
```

## What is intentionally left for the next step

- checkout hook-in
- telemetry overlays / usage counts
- richer polygon editing handles
- fallback zone-to-zone pricing
- courier dispatch scoring integration against these saved entities
