<?php
if (!defined('ABSPATH')) { exit; }

final class CC_CP_Intelligence {
    const DB_VERSION = '1.0.0';
    const OPT_DB_VERSION = 'cc_cp_intel_db_version';
    const TABLE_EVENTS = 'cc_cp_intel_events';
    const TABLE_ADJUST = 'cc_cp_intel_adjustments';

    public static function init() {
        add_action('init', array(__CLASS__, 'maybe_install'));
        add_action('cc_cp_quote_computed', array(__CLASS__, 'record_quote'), 10, 2);
        add_action('cc_shipment_created', array(__CLASS__, 'sync_shipment_quote'), 20, 3);
        add_action('cc_shipment_ready_for_assignment', array(__CLASS__, 'sync_shipment_quote'), 20, 3);
        add_action('cc_shipment_assigned_to_courier', array(__CLASS__, 'mark_assigned'), 20, 3);
        add_action('cc_shipment_status_changed', array(__CLASS__, 'mark_status'), 20, 4);
        add_action('cc_cp_logistics_intelligence_event', array(__CLASS__, 'record_dispatch_signal'), 20, 1);
    }

    public static function maybe_install() {
        if (get_option(self::OPT_DB_VERSION) === self::DB_VERSION) return;
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $events = $wpdb->prefix . self::TABLE_EVENTS;
        $adjust = $wpdb->prefix . self::TABLE_ADJUST;
        dbDelta("CREATE TABLE {$events} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            shipment_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            order_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            quote_source VARCHAR(32) NOT NULL DEFAULT 'automatic',
            seller_lat DOUBLE NULL,
            seller_lng DOUBLE NULL,
            customer_lat DOUBLE NULL,
            customer_lng DOUBLE NULL,
            distance_km DOUBLE NOT NULL DEFAULT 0,
            duration_estimated_seconds INT NOT NULL DEFAULT 0,
            duration_actual_seconds INT NOT NULL DEFAULT 0,
            price_total DOUBLE NOT NULL DEFAULT 0,
            base_fee DOUBLE NOT NULL DEFAULT 0,
            distance_fee DOUBLE NOT NULL DEFAULT 0,
            traffic_adjustment DOUBLE NOT NULL DEFAULT 0,
            zone_adjustment DOUBLE NOT NULL DEFAULT 0,
            pickup_block_modifier DOUBLE NOT NULL DEFAULT 0,
            dropoff_block_modifier DOUBLE NOT NULL DEFAULT 0,
            long_haul_buffer DOUBLE NOT NULL DEFAULT 0,
            platform_spread DOUBLE NOT NULL DEFAULT 0,
            seller_zone_id VARCHAR(128) NOT NULL DEFAULT '',
            customer_zone_id VARCHAR(128) NOT NULL DEFAULT '',
            seller_zone_type VARCHAR(64) NOT NULL DEFAULT '',
            customer_zone_type VARCHAR(64) NOT NULL DEFAULT '',
            pickup_block_id VARCHAR(128) NOT NULL DEFAULT '',
            dropoff_block_id VARCHAR(128) NOT NULL DEFAULT '',
            pickup_block_type VARCHAR(64) NOT NULL DEFAULT '',
            dropoff_block_type VARCHAR(64) NOT NULL DEFAULT '',
            manual_lane_id VARCHAR(128) NOT NULL DEFAULT '',
            courier_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            accepted TINYINT(1) NOT NULL DEFAULT 0,
            acceptance_seconds INT NOT NULL DEFAULT 0,
            status VARCHAR(32) NOT NULL DEFAULT 'quoted',
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY shipment_id (shipment_id),
            KEY status (status),
            KEY seller_zone_type (seller_zone_type),
            KEY customer_zone_type (customer_zone_type)
        ) {$charset};");
        dbDelta("CREATE TABLE {$adjust} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            knob_key VARCHAR(191) NOT NULL,
            direction VARCHAR(16) NOT NULL DEFAULT '',
            amount DOUBLE NOT NULL DEFAULT 0,
            reason_code VARCHAR(64) NOT NULL DEFAULT '',
            sample_count INT NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY knob_key (knob_key)
        ) {$charset};");
        update_option(self::OPT_DB_VERSION, self::DB_VERSION, false);
    }

    public static function events_table() {
        global $wpdb; return $wpdb->prefix . self::TABLE_EVENTS;
    }
    public static function adjust_table() {
        global $wpdb; return $wpdb->prefix . self::TABLE_ADJUST;
    }

    public static function record_quote($quote, $args = array()) {
        if (!is_array($quote)) return;
        global $wpdb;
        $table = self::events_table();
        $data = array(
            'shipment_id' => absint($quote['shipment_id'] ?? 0),
            'order_id' => absint($args['order_id'] ?? 0),
            'quote_source' => sanitize_key($quote['quote_source'] ?? 'automatic'),
            'seller_lat' => (float) ($quote['seller_lat'] ?? 0),
            'seller_lng' => (float) ($quote['seller_lng'] ?? 0),
            'customer_lat' => (float) ($quote['customer_lat'] ?? 0),
            'customer_lng' => (float) ($quote['customer_lng'] ?? 0),
            'distance_km' => (float) ($quote['distance_km'] ?? 0),
            'duration_estimated_seconds' => (int) ($quote['duration_seconds'] ?? 0),
'price_total' => (float) (isset($quote['total']) ? $quote['total'] : ($quote['total_shipping_fee'] ?? 0)),            'base_fee' => (float) ($quote['base_fee'] ?? 0),
            'distance_fee' => (float) ($quote['distance_fee'] ?? 0),
            'traffic_adjustment' => (float) ($quote['traffic_adjustment'] ?? 0),
            'zone_adjustment' => (float) ($quote['zone_adjustment'] ?? 0),
            'pickup_block_modifier' => (float) ($quote['pickup_block_modifier'] ?? 0),
            'dropoff_block_modifier' => (float) ($quote['dropoff_block_modifier'] ?? 0),
            'long_haul_buffer' => (float) ($quote['long_haul_buffer'] ?? 0),
            'platform_spread' => (float) ($quote['platform_spread'] ?? 0),
            'seller_zone_id' => sanitize_key($quote['origin_zone']['id'] ?? ''),
            'customer_zone_id' => sanitize_key($quote['destination_zone']['id'] ?? ''),
            'seller_zone_type' => sanitize_key($quote['origin_zone']['zone_type'] ?? ''),
            'customer_zone_type' => sanitize_key($quote['destination_zone']['zone_type'] ?? ''),
            'pickup_block_id' => sanitize_key($quote['origin_block']['id'] ?? ''),
            'dropoff_block_id' => sanitize_key($quote['destination_block']['id'] ?? ''),
            'pickup_block_type' => sanitize_key($quote['origin_block']['block_type'] ?? ''),
            'dropoff_block_type' => sanitize_key($quote['destination_block']['block_type'] ?? ''),
            'manual_lane_id' => sanitize_key($quote['lane']['id'] ?? ''),
            'updated_at' => current_time('mysql'),
        );
        $formats = array('%d','%d','%s','%f','%f','%f','%f','%f','%d','%f','%f','%f','%f','%f','%f','%f','%f','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s');
        if (!empty($data['shipment_id'])) {
            $existing = (int) $wpdb->get_var($wpdb->prepare("SELECT id FROM {$table} WHERE shipment_id=%d LIMIT 1", $data['shipment_id']));
            if ($existing) {
                $wpdb->update($table, $data, array('id' => $existing));
                return;
            }
        }
        $data['created_at'] = current_time('mysql');
        $formats[] = '%s';
        $wpdb->insert($table, $data, $formats);
    }

    public static function sync_shipment_quote($shipment_id) {
        if (!class_exists('CC_CP_Engine')) return;
        CC_CP_Engine::quote_for_shipment($shipment_id);
    }

    public static function mark_assigned($shipment_id, $courier_id, $context = array()) {
        if (!empty($context['skip_intelligence_assignment'])) {
            return;
        }
        global $wpdb;
        $table = self::events_table();
        $shipment_id = absint($shipment_id);
        if (!$shipment_id) return;
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE shipment_id=%d LIMIT 1", $shipment_id), ARRAY_A);
        if (!$row) return;
        $createdTs = strtotime($row['created_at'] ?? '');
        $acc = $createdTs ? max(0, current_time('timestamp', true) - $createdTs) : 0;
        $wpdb->update($table, array(
            'courier_id' => absint($courier_id),
            'accepted' => 1,
            'acceptance_seconds' => $acc,
            'status' => 'assigned',
            'updated_at' => current_time('mysql'),
        ), array('id' => $row['id']), array('%d','%d','%d','%s','%s'), array('%d'));
    }

    public static function record_dispatch_signal($payload) {
        if (!is_array($payload)) {
            return;
        }

        $shipment_id = absint($payload['shipment_id'] ?? 0);
        if (!$shipment_id) {
            return;
        }

        $clean = array(
            'event' => sanitize_key($payload['event'] ?? ''),
            'shipment_id' => $shipment_id,
            'courier_id' => absint($payload['courier_id'] ?? 0),
            'timestamp' => absint($payload['timestamp'] ?? current_time('timestamp', true)),
            'distance_band' => sanitize_key($payload['distance_band'] ?? ''),
            'vehicle_type' => sanitize_key($payload['vehicle_type'] ?? ''),
            'active_jobs' => (int) ($payload['active_jobs'] ?? 0),
            'quote_total' => (float) ($payload['quote_total'] ?? 0),
            'zone' => sanitize_key($payload['zone'] ?? ''),
            'shipment_zone' => sanitize_key($payload['shipment_zone'] ?? ''),
            'queue_bucket' => sanitize_key($payload['queue_bucket'] ?? ''),
            'recorded_at' => current_time('mysql'),
        );

        $existing = get_post_meta($shipment_id, '_cc_cp_logistics_intel_events', true);
        if (!is_array($existing)) {
            $existing = array();
        }
        $existing[] = $clean;
        if (count($existing) > 100) {
            $existing = array_slice($existing, -100);
        }
        update_post_meta($shipment_id, '_cc_cp_logistics_intel_events', $existing);

        global $wpdb;
        $table = self::events_table();
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE shipment_id=%d LIMIT 1", $shipment_id), ARRAY_A);
        if (!$row) {
            return;
        }

        $status = $clean['event'];
        $accepted = 0;
        if (in_array($status, array('accept', 'offer_accepted'), true)) {
            $status = 'assigned';
            $accepted = 1;
        } elseif (in_array($status, array('timeout', 'offer_timed_out'), true)) {
            $status = 'expired';
        } elseif (in_array($status, array('rejected', 'offer_rejected'), true)) {
            $status = 'rejected';
        } elseif ($status === 'offer_sent') {
            $status = 'offered';
        }

        $update = array(
            'courier_id' => $clean['courier_id'],
            'accepted' => $accepted,
            'status' => $status,
            'updated_at' => current_time('mysql'),
        );
        $formats = array('%d','%d','%s','%s');

        if ($clean['quote_total'] > 0) {
            $update['price_total'] = (float) $clean['quote_total'];
            $formats[] = '%f';
        }

        $wpdb->update($table, $update, array('id' => $row['id']), $formats, array('%d'));
    }

    public static function mark_status($shipment_id, $old_status, $new_status, $context = array()) {
        global $wpdb;
        $table = self::events_table();
        $shipment_id = absint($shipment_id);
        if (!$shipment_id) return;
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE shipment_id=%d LIMIT 1", $shipment_id), ARRAY_A);
        if (!$row) return;
        $createdTs = strtotime($row['created_at'] ?? '');
        $actual = $createdTs ? max(0, current_time('timestamp', true) - $createdTs) : 0;
        $update = array(
            'status' => sanitize_key($new_status),
            'updated_at' => current_time('mysql'),
        );
        $formats = array('%s','%s');
        if (in_array($new_status, array('delivered','completed'), true)) {
            $update['duration_actual_seconds'] = $actual;
            $formats[] = '%d';
        }
        $wpdb->update($table, $update, array('id' => $row['id']), $formats, array('%d'));
    }

    public static function reset_all_data() {
        global $wpdb;
        $wpdb->query('TRUNCATE TABLE ' . self::events_table());
        $wpdb->query('TRUNCATE TABLE ' . self::adjust_table());
    }

    public static function get_dashboard() {
        self::maybe_auto_adjust();
        global $wpdb;
        $table = self::events_table();
        $rows = $wpdb->get_results("SELECT * FROM {$table} ORDER BY id DESC LIMIT 1000", ARRAY_A);
        if (!is_array($rows)) $rows = array();
        return array(
            'overview' => self::overview($rows),
            'distance_buckets' => self::distance_buckets($rows),
            'zone_type_performance' => self::zone_type_performance($rows),
            'block_performance' => self::block_performance($rows),
            'problem_routes' => self::problem_routes($rows),
            'recent_shipments' => self::recent_shipments($rows),
            'knobs' => self::knob_intelligence($rows),
            'settings' => CC_CP_Settings::all(),
        );
    }

    private static function overview(array $rows) {
        $count = count($rows);
        $avg = function($field) use ($rows, $count) {
            if (!$count) return 0;
            $sum = 0; $n = 0;
            foreach ($rows as $r) { if (isset($r[$field])) { $sum += (float) $r[$field]; $n++; } }
            return $n ? round($sum / $n, 2) : 0;
        };
        $accepted = 0; $completed = 0;
        foreach ($rows as $r) { if (!empty($r['accepted'])) $accepted++; if (($r['status'] ?? '') === 'delivered') $completed++; }
        return array(
            'total_shipments' => $count,
            'avg_price' => $avg('price_total'),
            'avg_distance_km' => $avg('distance_km'),
            'avg_duration_min' => round($avg('duration_estimated_seconds') / 60, 1),
            'acceptance_rate' => $count ? round(($accepted / $count) * 100, 1) : 0,
            'completion_rate' => $count ? round(($completed / $count) * 100, 1) : 0,
        );
    }

    private static function distance_buckets(array $rows) {
        $buckets = array(
            '0-5 km' => array('min'=>0,'max'=>5,'rows'=>array()),
            '5-10 km' => array('min'=>5,'max'=>10,'rows'=>array()),
            '10-20 km' => array('min'=>10,'max'=>20,'rows'=>array()),
            '20+ km' => array('min'=>20,'max'=>INF,'rows'=>array()),
        );
        foreach ($rows as $row) {
            $km = (float) ($row['distance_km'] ?? 0);
            foreach ($buckets as $label => $cfg) {
                if ($km >= $cfg['min'] && $km < $cfg['max']) {
                    $buckets[$label]['rows'][] = $row; break;
                }
            }
        }
        $out = array();
        foreach ($buckets as $label => $cfg) {
            $out[] = array('label' => $label, 'samples' => count($cfg['rows']), 'avg_price' => self::avg_field($cfg['rows'], 'price_total'), 'acceptance_rate' => self::acceptance_rate($cfg['rows']), 'avg_duration_min' => round(self::avg_field($cfg['rows'], 'duration_estimated_seconds') / 60, 1));
        }
        return $out;
    }

    private static function zone_type_performance(array $rows) {
        $types = array_keys(CC_CP_Settings::zone_type_choices());
        $out = array();
        foreach ($types as $type) {
            $subset = array_values(array_filter($rows, function($r) use ($type){ return ($r['customer_zone_type'] ?? '') === $type || ($r['seller_zone_type'] ?? '') === $type; }));
            $out[] = self::metric_row('zone.' . $type, CC_CP_Settings::zone_type_choices()[$type], $subset, CC_CP_Settings::get_zone_adjustment($type));
        }
        return $out;
    }

    private static function block_performance(array $rows) {
        $types = array_keys(CC_CP_Settings::block_type_choices());
        $out = array();
        foreach ($types as $type) {
            $subset = array_values(array_filter($rows, function($r) use ($type){ return ($r['pickup_block_type'] ?? '') === $type || ($r['dropoff_block_type'] ?? '') === $type; }));
            $out[] = self::metric_row('block.' . $type, CC_CP_Settings::block_type_choices()[$type], $subset, CC_CP_Settings::get_block_modifier($type));
        }
        return $out;
    }

    private static function problem_routes(array $rows) {
        $groups = array();
        foreach ($rows as $r) {
            $key = trim(($r['seller_zone_id'] ?: 'none') . ' → ' . ($r['customer_zone_id'] ?: 'none'));
            if (!isset($groups[$key])) $groups[$key] = array();
            $groups[$key][] = $r;
        }
        $out = array();
        foreach ($groups as $label => $subset) {
            if (count($subset) < 2) continue;
            $status = self::derive_status($subset);
            if ($status === 'Stable') continue;
            $out[] = array('label' => $label, 'samples' => count($subset), 'status' => $status, 'avg_price' => self::avg_field($subset, 'price_total'), 'acceptance_rate' => self::acceptance_rate($subset));
        }
        usort($out, function($a,$b){ return $b['samples'] <=> $a['samples']; });
        return $out;
    }

    private static function recent_shipments(array $rows) {
        return array_map(function($r){
            return array(
                'shipment_id' => (int) $r['shipment_id'],
                'seller_zone' => $r['seller_zone_id'],
                'customer_zone' => $r['customer_zone_id'],
                'distance_km' => (float) $r['distance_km'],
                'price_total' => (float) $r['price_total'],
                'duration_min' => round(((float) $r['duration_estimated_seconds']) / 60, 1),
                'status' => $r['status'],
                'courier_id' => (int) $r['courier_id'],
                'accepted' => !empty($r['accepted']),
                'created_at' => $r['created_at'],
            );
        }, $rows);
    }

    private static function knob_intelligence(array $rows) {
        $pricing = CC_CP_Settings::get_pricing();
        $globals = array(
            self::metric_row('global.base_fee', 'Base Fee', $rows, $pricing['base_fee']),
            self::metric_row('global.per_km_rate', 'Per KM Rate', array_values(array_filter($rows, function($r){ return (float) ($r['distance_km'] ?? 0) > 0; })), $pricing['per_km_rate']),
            self::metric_row('global.long_haul_buffer', 'Long-Haul Buffer', array_values(array_filter($rows, function($r) use ($pricing){ return (float) ($r['distance_km'] ?? 0) >= (float) $pricing['long_haul_threshold_km']; })), $pricing['long_haul_buffer']),
            self::metric_row('global.minimum_fee', 'Minimum Fee', $rows, $pricing['minimum_fee']),
            self::metric_row('global.platform_spread_default', 'Platform Spread Default', $rows, $pricing['platform_spread_default']),
        );
        return array('global' => $globals, 'zone' => self::zone_type_performance($rows), 'block' => self::block_performance($rows));
    }

    private static function metric_row($knobKey, $label, array $rows, $value) {
        $settings = CC_CP_Settings::get_intelligence();
        $samples = count($rows);
        $consistency = self::consistency_factor($rows);
        $confidence = round(min(1, $samples / max(1, $settings['sample_threshold'])) * $consistency * 100, 1);
        $status = self::derive_status($rows);
        return array(
            'knob_key' => $knobKey,
            'label' => $label,
            'value' => CC_CP_Storage::money($value),
            'samples' => $samples,
            'confidence_pct' => $confidence,
            'status' => $status,
            'mode' => CC_CP_Settings::get_knob_mode($knobKey),
            'acceptance_rate' => self::acceptance_rate($rows),
            'avg_acceptance_seconds' => self::avg_field($rows, 'acceptance_seconds'),
            'avg_delay_ratio' => self::avg_delay_ratio($rows),
        );
    }

    private static function derive_status(array $rows) {
        if (!$rows) return 'Awaiting data';
        $acceptance = self::acceptance_rate($rows) / 100;
        $delay = self::avg_delay_ratio($rows);
        $acceptSeconds = self::avg_field($rows, 'acceptance_seconds');
        if ($acceptance < 0.45) return 'High rejection';
        if ($delay > 0.35) return 'High delay';
        if ($acceptance < 0.7 || $acceptSeconds > 300) return 'Underpriced';
        if ($acceptance > 0.92 && $delay < 0.08 && ($acceptSeconds > 0 && $acceptSeconds < 60)) return 'Overpriced';
        return 'Stable';
    }

    private static function consistency_factor(array $rows) {
        if (!$rows) return 0;
        $outcomeRows = 0;
        foreach ($rows as $r) {
            if (!empty($r['accepted']) || !empty($r['duration_actual_seconds'])) $outcomeRows++;
        }
        return max(0.35, min(1, 0.55 + (($outcomeRows / max(1, count($rows))) * 0.45)));
    }

    private static function avg_delay_ratio(array $rows) {
        $sum = 0; $n = 0;
        foreach ($rows as $r) {
            $est = (int) ($r['duration_estimated_seconds'] ?? 0);
            $act = (int) ($r['duration_actual_seconds'] ?? 0);
            if ($est > 0 && $act > 0) {
                $sum += max(0, ($act - $est) / $est);
                $n++;
            }
        }
        return $n ? round($sum / $n, 3) : 0;
    }

    private static function acceptance_rate(array $rows) {
        if (!$rows) return 0;
        $accepted = 0;
        foreach ($rows as $r) { if (!empty($r['accepted'])) $accepted++; }
        return round(($accepted / count($rows)) * 100, 1);
    }

    private static function avg_field(array $rows, $field) {
        $sum = 0; $n = 0;
        foreach ($rows as $r) { if (isset($r[$field])) { $sum += (float) $r[$field]; $n++; } }
        return $n ? round($sum / $n, 2) : 0;
    }

  public static function maybe_auto_adjust() {
    global $wpdb;

    $settings = CC_CP_Settings::get_intelligence();
    $pricing  = CC_CP_Settings::get_pricing();
    $knobMeta = CC_CP_Settings::get_knob_meta();

    $rows = $wpdb->get_results(
        "SELECT * FROM " . self::events_table() . " ORDER BY id DESC LIMIT 1000",
        ARRAY_A
    );

    if (!is_array($rows) || !$rows) {
        return;
    }

    $latestEventId = absint($rows[0]['id'] ?? 0);

    $intel = self::knob_intelligence($rows);
    $targets = array_merge(
        $intel['global'],
        $intel['zone'],
        $intel['block']
    );

    foreach ($targets as $metric) {
        $knob = $metric['knob_key'];

        if (CC_CP_Settings::get_knob_mode($knob) !== 'auto') {
            continue;
        }

        if ($metric['confidence_pct'] < $settings['confidence_threshold_pct']) {
            continue;
        }

        $meta   = $knobMeta[$knob] ?? array();
        $lastTs = isset($meta['last_adjusted_at']) ? absint($meta['last_adjusted_at']) : 0;

        if (
            $lastTs &&
            (current_time('timestamp', true) - $lastTs) < ($settings['cooldown_hours'] * HOUR_IN_SECONDS)
        ) {
            continue;
        }

        $lastEventId = isset($meta['last_event_id']) ? absint($meta['last_event_id']) : 0;

        if ($lastEventId > 0) {
            $shipmentsSinceLastAdjustment = (int) $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM " . self::events_table() . " WHERE id > %d",
                    $lastEventId
                )
            );

            if ($shipmentsSinceLastAdjustment < absint($settings['cooldown_shipments'])) {
                continue;
            }
        }

        $step = self::step_for_knob($knob, $settings['adjustment_step']);
        $direction = self::direction_for_metric($metric);

        if (!$direction) {
            continue;
        }

        $newValue = self::apply_knob_adjustment(
            $pricing,
            $knob,
            $direction,
            $step,
            $settings['max_adjustment_limit']
        );

        if ($newValue === null) {
            continue;
        }

        update_option(CC_CP_Settings::OPT_PRICING, $pricing, false);

        CC_CP_Settings::touch_knob_meta($knob, array(
            'last_samples'   => $metric['samples'],
            'last_direction' => $direction,
            'last_event_id'  => $latestEventId,
        ));

        $wpdb->insert(
            self::adjust_table(),
            array(
                'knob_key'     => $knob,
                'direction'    => $direction,
                'amount'       => $step,
                'reason_code'  => sanitize_key($metric['status']),
                'sample_count' => absint($metric['samples']),
                'created_at'   => current_time('mysql'),
            ),
            array('%s','%s','%f','%s','%d','%s')
        );

        $knobMeta = CC_CP_Settings::get_knob_meta();
    }
}

    private static function direction_for_metric(array $metric) {
        $status = $metric['status'];
        if (in_array($status, array('Underpriced','High rejection','High delay'), true)) return 'increase';
        if ($status === 'Overpriced') return 'decrease';
        return '';
    }

    private static function step_for_knob($knob, $defaultStep) {
        return strpos($knob, 'global.per_km_rate') === 0 ? max(1, round($defaultStep / 10, 2)) : $defaultStep;
    }

    private static function apply_knob_adjustment(array &$pricing, $knob, $direction, $step, $limit) {
        $delta = ($direction === 'increase') ? $step : -$step;
        if (strpos($knob, 'global.') === 0) {
            $field = substr($knob, 7);
            if (!isset($pricing[$field])) return null;
            $pricing[$field] = max(0, CC_CP_Storage::money($pricing[$field] + $delta));
            if ($field !== 'per_km_rate' && $pricing[$field] > $limit) $pricing[$field] = $limit;
            return $pricing[$field];
        }
        if (strpos($knob, 'zone.') === 0) {
            $field = substr($knob, 5);
            if (!isset($pricing['zone_adjustments'][$field])) return null;
            $pricing['zone_adjustments'][$field] = max(0, min($limit, CC_CP_Storage::money($pricing['zone_adjustments'][$field] + $delta)));
            return $pricing['zone_adjustments'][$field];
        }
        if (strpos($knob, 'block.') === 0) {
            $field = substr($knob, 6);
            if (!isset($pricing['block_modifiers'][$field])) return null;
            $pricing['block_modifiers'][$field] = max(0, min($limit, CC_CP_Storage::money($pricing['block_modifiers'][$field] + $delta)));
            return $pricing['block_modifiers'][$field];
        }
        return null;
    }
}
