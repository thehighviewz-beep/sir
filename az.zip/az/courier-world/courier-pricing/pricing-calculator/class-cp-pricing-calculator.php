<?php
if (!defined('ABSPATH')) exit;

if (!function_exists('cc_cp_normalize_band')) {
    /**
     * Normalize planner trip bands so dispatch can treat pricing as distance truth.
     */
    function cc_cp_normalize_band($band) {
        $band = sanitize_key((string) $band);
        if ($band === 'extra_short') {
            return 'very_short';
        }
        if (in_array($band, array('very_short', 'short', 'medium', 'long'), true)) {
            return $band;
        }
        return 'medium';
    }
}

if (!function_exists('cc_cp_get_band')) {
    /**
     * Public normalized planner band helper used by dispatch + UX layers.
     */
    function cc_cp_get_band($distance_km) {
        $distance_km = max(0.0, (float) $distance_km);
        $settings = class_exists('CC_CP_Settings') ? CC_CP_Settings::get_pricing() : array();
        $bands = is_array($settings['trip_bands'] ?? null) ? $settings['trip_bands'] : array();

        $extraMax  = (float) ($bands['extra_short']['max_km'] ?? 3.0);
        $shortMax  = (float) ($bands['short']['max_km'] ?? max($extraMax, 7.0));
        $mediumMax = (float) ($bands['medium']['max_km'] ?? max($shortMax, 15.0));

        if ($distance_km <= $extraMax) {
            return 'very_short';
        }
        if ($distance_km <= $shortMax) {
            return 'short';
        }
        if ($distance_km <= $mediumMax) {
            return 'medium';
        }
        return 'long';
    }
}

final class CC_CP_Pricing_Calculator {
    private static function tier_distance_fee(float $distance_km, array $band): float {
        $first = min($distance_km, 2.0) * (float)($band['first_2_km_rate'] ?? 0);
        $nextKm = max(0.0, min($distance_km - 2.0, 3.0)) * (float)($band['next_3_km_rate'] ?? 0);
        $remainingKm = max(0.0, $distance_km - 5.0) * (float)($band['remaining_km_rate'] ?? 0);
        return $first + $nextKm + $remainingKm;
    }

    private static function pick_band(float $distance_km, array $bands): array {
        $extra = $bands['extra_short'] ?? array();
        $short = $bands['short'] ?? array();
        $medium = $bands['medium'] ?? array();
        $long = $bands['long'] ?? array();
        if ($distance_km <= (float)($extra['max_km'] ?? 0)) return array('extra_short', $extra);
        if ($distance_km <= (float)($short['max_km'] ?? 0)) return array('short', $short);
        if ($distance_km <= (float)($medium['max_km'] ?? 0)) return array('medium', $medium);
        return array('long', $long);
    }


    public static function calculate_manual_lane(array $lane, array $args = array()) : array {
        $sellerLat   = isset($args['seller_lat']) ? (float) $args['seller_lat'] : 0.0;
        $sellerLng   = isset($args['seller_lng']) ? (float) $args['seller_lng'] : 0.0;
        $customerLat = isset($args['customer_lat']) ? (float) $args['customer_lat'] : 0.0;
        $customerLng = isset($args['customer_lng']) ? (float) $args['customer_lng'] : 0.0;

        $metrics = array(
            'distance_km' => 0,
            'duration_seconds' => 0,
            'static_duration_seconds' => 0,
        );

        if ($sellerLat && $sellerLng && $customerLat && $customerLng && class_exists('CC_CP_Routing_Client')) {
            $route_metrics = CC_CP_Routing_Client::get_metrics(
                array('lat' => $sellerLat, 'lng' => $sellerLng),
                array('lat' => $customerLat, 'lng' => $customerLng)
            );
            if (!is_wp_error($route_metrics) && is_array($route_metrics)) {
                $metrics = array_merge($metrics, $route_metrics);
            }
        }

        $manual_price    = CC_CP_Storage::money($lane['manual_price'] ?? 0);
        $size_modifier   = CC_CP_Storage::money($lane['size_modifier'] ?? 0);
        $weight_modifier = CC_CP_Storage::money($lane['weight_modifier'] ?? 0);
        $buffer_cost     = CC_CP_Storage::money($lane['buffer_cost'] ?? 0);
        $platform_spread = CC_CP_Storage::money($lane['platform_spread'] ?? 0);
        $subtotal        = CC_CP_Storage::money($manual_price + $size_modifier + $weight_modifier + $buffer_cost + $platform_spread);
        $total           = CC_CP_Storage::money($lane['total_shipping_fee'] ?? $subtotal);
        $distance_km     = max(0.0, (float) ($metrics['distance_km'] ?? 0));
        $band            = cc_cp_get_band($distance_km);

        return array(
            'pricing_mode' => 'manual_lane',
            'quote_source' => 'manual_lane',
            'trip_band' => $band,
            'distance_band' => $band,
            'distance_km' => round($distance_km, 3),
            'distance_fee' => CC_CP_Storage::money(0),
            'base_fee' => $manual_price,
            'manual_price' => $manual_price,
            'size_modifier' => $size_modifier,
            'weight_modifier' => $weight_modifier,
            'zone_adjustment' => CC_CP_Storage::money(0),
            'origin_zone_adjustment' => CC_CP_Storage::money(0),
            'destination_zone_adjustment' => CC_CP_Storage::money(0),
            'pickup_block_modifier' => CC_CP_Storage::money(0),
            'dropoff_block_modifier' => CC_CP_Storage::money(0),
            'traffic_adjustment' => CC_CP_Storage::money(0),
            'platform_spread' => $platform_spread,
            'buffer_cost' => $buffer_cost,
            'long_haul_buffer' => $buffer_cost,
            'applied_haul_type' => '',
            'applied_haul_buffer' => CC_CP_Storage::money(0),
            'minimum_fee' => $total,
            'subtotal' => $subtotal,
            'total' => $total,
            'duration_seconds' => max(0, (int) ($metrics['duration_seconds'] ?? 0)),
            'static_duration_seconds' => max(0, (int) ($metrics['static_duration_seconds'] ?? 0)),
            'route_metrics' => $metrics,
            'lane_notes' => sanitize_textarea_field($lane['notes'] ?? ''),
        );
    }

    public static function calculate(array $context, array $metrics, array $settings = array()) : array {
        $distance_km = max(0, (float)($metrics['distance_km'] ?? 0));
        $duration_seconds = max(0, (int)($metrics['duration_seconds'] ?? 0));
        $static_duration_seconds = max(0, (int)($metrics['static_duration_seconds'] ?? 0));
        $bands = is_array($settings['trip_bands'] ?? null) ? $settings['trip_bands'] : array();
        list($bandKey, $band) = self::pick_band($distance_km, $bands);
        $base_fee = (float)($band['base_fee'] ?? 0);
        $distance_fee = self::tier_distance_fee($distance_km, $band);
        $minimum_fee = (float)($settings['minimum_fee'] ?? 0);
        $platform_spread = (float)($band['platform_spread'] ?? 0);

        $zone_adjustments = is_array($settings['zone_adjustments'] ?? null) ? $settings['zone_adjustments'] : array();
        $origin_zone_type = sanitize_key((string)($context['origin_zone_type'] ?? ''));
        $destination_zone_type = sanitize_key((string)($context['destination_zone_type'] ?? ''));
        $origin_zone_adjustment = (float)($zone_adjustments[$origin_zone_type] ?? 0);
        $destination_zone_adjustment = (float)($zone_adjustments[$destination_zone_type] ?? 0);
        $zone_adjustment = max($origin_zone_adjustment, $destination_zone_adjustment);

        $block_modifiers = is_array($settings['block_modifiers'] ?? null) ? $settings['block_modifiers'] : array();
        $pickup_block_type = sanitize_key((string)($context['origin_block_type'] ?? ''));
        $dropoff_block_type = sanitize_key((string)($context['destination_block_type'] ?? ''));
        $pickup_block_modifier = (float)($block_modifiers[$pickup_block_type] ?? 0);
        $dropoff_block_modifier = (float)($block_modifiers[$dropoff_block_type] ?? 0);

        $traffic_adjustment = 0.0;
        if ($duration_seconds > 0 && $static_duration_seconds > 0 && $duration_seconds > $static_duration_seconds) {
            $delta_minutes = ($duration_seconds - $static_duration_seconds) / 60;
            $traffic_adjustment = max(0, round($delta_minutes * 10, 2));
        }

        $applied_haul_buffer = 0.0;
        $applied_haul_type = '';
        if (in_array($bandKey, array('medium','long'), true)) {
            $threshold = (float)($band['haul_threshold_km'] ?? 0);
            $buffer = (float)($band['haul_buffer'] ?? 0);
            if ($threshold > 0 && $distance_km >= $threshold) {
                $applied_haul_buffer = $buffer;
                $applied_haul_type = $bandKey;
            }
        }

        $subtotal = $base_fee + $distance_fee + $zone_adjustment + $pickup_block_modifier + $dropoff_block_modifier + $traffic_adjustment + $platform_spread + $applied_haul_buffer;
        $total = max($minimum_fee, $subtotal);

        return array(
            'pricing_mode' => 'trip_band_v3',
            'trip_band' => $bandKey,
            'distance_band' => cc_cp_normalize_band($bandKey),
            'distance_km' => round($distance_km, 3),
            'distance_fee' => CC_CP_Storage::money($distance_fee),
            'base_fee' => CC_CP_Storage::money($base_fee),
            'zone_adjustment' => CC_CP_Storage::money($zone_adjustment),
            'origin_zone_adjustment' => CC_CP_Storage::money($origin_zone_adjustment),
            'destination_zone_adjustment' => CC_CP_Storage::money($destination_zone_adjustment),
            'pickup_block_modifier' => CC_CP_Storage::money($pickup_block_modifier),
            'dropoff_block_modifier' => CC_CP_Storage::money($dropoff_block_modifier),
            'traffic_adjustment' => CC_CP_Storage::money($traffic_adjustment),
            'platform_spread' => CC_CP_Storage::money($platform_spread),
            'applied_haul_type' => $applied_haul_type,
            'applied_haul_buffer' => CC_CP_Storage::money($applied_haul_buffer),
            'minimum_fee' => CC_CP_Storage::money($minimum_fee),
            'subtotal' => CC_CP_Storage::money($subtotal),
            'total' => CC_CP_Storage::money($total),
            'duration_seconds' => $duration_seconds,
            'static_duration_seconds' => $static_duration_seconds,
        );
    }
}
