<?php

if (!defined('ABSPATH')) {
    exit;
}

final class CC_CP_Admin {
    const SLUG = 'cc-shipping-fee-planner';

    public static function init() {
        add_action('admin_menu', array(__CLASS__, 'register_menu'));
        add_action('admin_enqueue_scripts', array(__CLASS__, 'enqueue_assets'));

        add_action('wp_ajax_cc_cp_save_zone', array(__CLASS__, 'ajax_save_zone'));
        add_action('wp_ajax_cc_cp_save_block', array(__CLASS__, 'ajax_save_block'));
        add_action('wp_ajax_cc_cp_save_anchor', array(__CLASS__, 'ajax_save_anchor'));
        add_action('wp_ajax_cc_cp_save_lane', array(__CLASS__, 'ajax_save_lane'));
        add_action('wp_ajax_cc_cp_update_entity', array(__CLASS__, 'ajax_update_entity'));
        add_action('wp_ajax_cc_cp_update_lane', array(__CLASS__, 'ajax_update_lane'));
        add_action('wp_ajax_cc_cp_get_data', array(__CLASS__, 'ajax_get_data'));
        add_action('wp_ajax_cc_cp_delete_entity', array(__CLASS__, 'ajax_delete_entity'));
    }

    public static function register_menu() {
        $parent = (string) apply_filters('cc_cp_admin_parent_slug', '');

        if ($parent) {
            add_submenu_page(
                $parent,
                __('Shipping Fee Planner', 'cc-cp'),
                __('Shipping Fee Planner', 'cc-cp'),
                'manage_options',
                self::SLUG,
                array(__CLASS__, 'render_page')
            );
            return;
        }

        add_menu_page(
            __('Shipping Fee Planner', 'cc-cp'),
            __('Shipping Fee Planner', 'cc-cp'),
            'manage_options',
            self::SLUG,
            array(__CLASS__, 'render_page'),
            'dashicons-location-alt',
            58
        );
    }

    public static function enqueue_assets($hook) {
        if (strpos((string) $hook, self::SLUG) === false) {
            return;
        }

        $has_google_key = defined('CARICOVE_MAPS_BROWSER_KEY') && CARICOVE_MAPS_BROWSER_KEY;

        if ($has_google_key) {
            $maps_url = add_query_arg(
                array(
                    'key'      => CARICOVE_MAPS_BROWSER_KEY,
                    'callback' => 'CaricoveCourierPricingPlannerMapInit',
                ),
                'https://maps.googleapis.com/maps/api/js'
            );

            wp_register_script('cc-cp-google-maps', $maps_url, array(), null, true);
            wp_add_inline_script(
                'cc-cp-google-maps',
                'window.CC_CP_GMAP_READY = false;'
                . 'window.CaricoveCourierPricingPlannerMapInit = function(){'
                . 'window.CC_CP_GMAP_READY = true;'
                . 'document.dispatchEvent(new Event("cc_cp_gmaps_ready"));'
                . '};',
                'before'
            );
            wp_enqueue_script('cc-cp-google-maps');
        }

      wp_enqueue_style(
    'cc-cp-admin',
    CC_CP_URL . 'assets/admin.css',
    array(),
    file_exists(CC_CP_DIR . 'assets/admin.css') ? filemtime(CC_CP_DIR . 'assets/admin.css') : time()
);

wp_enqueue_script(
    'cc-cp-admin',
    CC_CP_URL . 'assets/admin.js',
    array('jquery'),
    file_exists(CC_CP_DIR . 'assets/admin.js') ? filemtime(CC_CP_DIR . 'assets/admin.js') : time(),
    true
);

        wp_localize_script('cc-cp-admin', 'CC_CP_DATA', array(
            'ajaxUrl'          => admin_url('admin-ajax.php'),
            'nonce'            => wp_create_nonce('cc_cp_admin_nonce'),
            'plannerData'      => self::planner_data(),
            'hasGoogleMapsKey' => (bool) $has_google_key,
            'mapCenter'        => apply_filters('cc_cp_map_center', array('lng' => -58.1553, 'lat' => 6.8013)),
            'mapZoom'          => (float) apply_filters('cc_cp_map_zoom', 13.0),
            'googleMapStyles'  => self::google_map_styles(),
            'strings'          => array(
                'saveLane'      => __('Save this lane to pricing?', 'cc-cp'),
                'saveAnchor'    => __('Save this anchor pin?', 'cc-cp'),
                'saveZone'      => __('Save this zone?', 'cc-cp'),
                'saveBlock'     => __('Save this block?', 'cc-cp'),
                'pickZone'      => __('Select a parent zone first when saving a block.', 'cc-cp'),
                'labelNeeded'   => __('Enter a label first.', 'cc-cp'),
                'shapeNeeded'   => __('Add at least 3 points before saving a polygon.', 'cc-cp'),
                'laneNeedTwo'   => __('Select an origin block and a destination block.', 'cc-cp'),
                'saved'         => __('Saved.', 'cc-cp'),
                'saveFailed'    => __('Could not save. Check the response below.', 'cc-cp'),
                'mapKeyMissing' => __('Google Maps key is missing. Define CARICOVE_MAPS_BROWSER_KEY so the Shipping Fee Planner can load the same road-level map as the courier console.', 'cc-cp'),
                'mapLoading'    => __('Loading street map…', 'cc-cp'),
                'deleteConfirm' => __('Delete this item? This cannot be undone.', 'cc-cp'),
                'deleteBlocked' => __('This item cannot be deleted yet because it still has dependent records.', 'cc-cp'),
                'noneYet'       => __('None yet.', 'cc-cp'),
                'nothingSelected' => __('Nothing selected yet.', 'cc-cp'),
            ),
        ));
    }

    private static function google_map_styles() {
        return array(
            array('elementType' => 'labels.text.fill', 'stylers' => array(array('color' => '#ffffff'))),
            array('elementType' => 'labels.text.stroke', 'stylers' => array(array('color' => '#000000'))),
            array('featureType' => 'poi', 'elementType' => 'labels.icon', 'stylers' => array(array('visibility' => 'off'))),
            array('featureType' => 'poi.business', 'elementType' => 'labels.icon', 'stylers' => array(array('visibility' => 'off'))),
            array('featureType' => 'poi.park', 'elementType' => 'labels.icon', 'stylers' => array(array('visibility' => 'off'))),
            array('featureType' => 'poi', 'elementType' => 'labels.text.fill', 'stylers' => array(array('color' => '#cccccc'))),
            array('elementType' => 'geometry', 'stylers' => array(array('color' => '#030614'))),
            array('featureType' => 'road', 'elementType' => 'geometry', 'stylers' => array(array('color' => '#0d152c'))),
            array('featureType' => 'road', 'elementType' => 'geometry.stroke', 'stylers' => array(array('color' => '#050815'))),
            array('featureType' => 'road.arterial', 'elementType' => 'geometry', 'stylers' => array(array('color' => '#15264e'))),
            array('featureType' => 'road.arterial', 'elementType' => 'geometry.stroke', 'stylers' => array(array('color' => '#091429'))),
            array('featureType' => 'road.highway', 'elementType' => 'geometry', 'stylers' => array(array('color' => '#1a3c71'))),
            array('featureType' => 'road.highway', 'elementType' => 'geometry.stroke', 'stylers' => array(array('color' => '#0b1f3e'))),
            array('featureType' => 'water', 'elementType' => 'geometry', 'stylers' => array(array('color' => '#020b17'))),
        );
    }

    public static function planner_data() {
    $data = CC_CP_Storage::all();

    $data['zones'] = array_values(array_map(function ($zone) {
        return self::normalize_entity('zone', $zone);
    }, isset($data['zones']) && is_array($data['zones']) ? $data['zones'] : array()));

    $data['blocks'] = array_values(array_map(function ($block) {
        return self::normalize_entity('block', $block);
    }, isset($data['blocks']) && is_array($data['blocks']) ? $data['blocks'] : array()));

    $data['anchors'] = array_values(array_map(function ($anchor) {
        return self::normalize_entity('anchor', $anchor);
    }, isset($data['anchors']) && is_array($data['anchors']) ? $data['anchors'] : array()));

    $data['lanes'] = array_values(array_map(function ($lane) {
        return self::normalize_entity('lane', $lane);
    }, isset($data['lanes']) && is_array($data['lanes']) ? $data['lanes'] : array()));

    $data['zoneChoices'] = array_map(function ($zone) {
        return array(
            'id'    => $zone['id'],
            'label' => $zone['label'],
        );
    }, $data['zones']);

    $data['blockChoices'] = array_map(function ($block) {
        return array(
            'id'    => $block['id'],
            'label' => $block['label'],
        );
    }, $data['blocks']);

    return $data;
}

    public static function render_page() {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('You do not have permission to access this page.', 'cc-cp'));
        }

        $planner = self::planner_data();
        ?>
        <div class="wrap cc-cp-wrap">
            <h1><?php esc_html_e('Shipping Fee Planner', 'cc-cp'); ?></h1>
            <p class="description cc-cp-description"><?php esc_html_e('Use the map as the geography source of truth. Save zones, blocks, anchors, and lanes here, then let the pricing table drive shipping fees per shipment.', 'cc-cp'); ?></p>

            <nav class="nav-tab-wrapper cc-cp-tabs" id="cc-cp-tabs">
                <button type="button" class="nav-tab nav-tab-active" data-tab="map"><?php esc_html_e('Map UI', 'cc-cp'); ?></button>
                <button type="button" class="nav-tab" data-tab="pricing"><?php esc_html_e('Pricing Table', 'cc-cp'); ?></button>
                <button type="button" class="nav-tab" data-tab="intelligence"><?php esc_html_e('Lane Intelligence', 'cc-cp'); ?></button>
            </nav>

            <section class="cc-cp-panel is-active" data-panel="map">
                <div class="cc-cp-top-grid">
                    <aside class="cc-cp-sidebar">
                        <div class="cc-cp-card">
                            <h2><?php esc_html_e('Map Tools', 'cc-cp'); ?></h2>
                            <div class="cc-cp-field-grid">
                                <label><span><?php esc_html_e('Mode', 'cc-cp'); ?></span><select id="cc-cp-mode"><option value="select"><?php esc_html_e('Select', 'cc-cp'); ?></option><option value="zone"><?php esc_html_e('Draw Zone', 'cc-cp'); ?></option><option value="block"><?php esc_html_e('Draw Block', 'cc-cp'); ?></option><option value="anchor"><?php esc_html_e('Drop Anchor', 'cc-cp'); ?></option><option value="lane"><?php esc_html_e('Create Lane', 'cc-cp'); ?></option></select></label>
                                <label><span><?php esc_html_e('Label', 'cc-cp'); ?></span><input type="text" id="cc-cp-label" placeholder="<?php esc_attr_e('Example: Duncan Block A', 'cc-cp'); ?>"></label>
                                <label><span><?php esc_html_e('Color', 'cc-cp'); ?></span><input type="color" id="cc-cp-color" value="#3b82f6"></label>
                                <label>
                                    <span><?php esc_html_e('Parent Zone', 'cc-cp'); ?></span>
                                    <select id="cc-cp-zone-id">
                                        <option value=""><?php esc_html_e('None / top-level', 'cc-cp'); ?></option>
                                        <?php foreach (($planner['zoneChoices'] ?? array()) as $zone_choice) : ?>
                                            <option value="<?php echo esc_attr($zone_choice['id']); ?>"><?php echo esc_html($zone_choice['label']); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </label>
                                <label class="cc-cp-checkbox"><input type="checkbox" id="cc-cp-active" checked><span><?php esc_html_e('Active', 'cc-cp'); ?></span></label>
                            </div>
                            <div class="cc-cp-toolbar-actions">
                                <button type="button" class="button button-primary" id="cc-cp-finish-shape"><?php esc_html_e('Finish Shape', 'cc-cp'); ?></button>
                                <button type="button" class="button" id="cc-cp-clear-draft"><?php esc_html_e('Clear Draft', 'cc-cp'); ?></button>
                                <button type="button" class="button" id="cc-cp-fullscreen"><?php esc_html_e('Expand Map', 'cc-cp'); ?></button>
                            </div>
                            <p class="cc-cp-help" id="cc-cp-help-text"><?php esc_html_e('Draw zones/blocks with clicks on the map. In lane mode, click one block, then another block, and save the pricing row.', 'cc-cp'); ?></p>
                        </div>

                        <div class="cc-cp-card">
                            <h2><?php esc_html_e('Draft + Inspector', 'cc-cp'); ?></h2>
                            <div id="cc-cp-draft-points" class="cc-cp-mini-log"></div>
                            <div id="cc-cp-selection" class="cc-cp-selection"></div>
                        </div>
                    </aside>

                    <div class="cc-cp-main">
                        <div class="cc-cp-card cc-cp-map-card">
                            <div id="cc-cp-map"><div class="cc-cp-map-loading"><?php esc_html_e('Loading street map…', 'cc-cp'); ?></div></div>
                        </div>
                    </div>
                </div>

                <div class="cc-cp-manager-grid" id="cc-cp-manager-grid">
                    <section class="cc-cp-card cc-cp-manager-card cc-cp-manager-card--zones">
                        <div class="cc-cp-manager-card__header">
                            <h2><?php esc_html_e('Zones', 'cc-cp'); ?></h2>
                            <span class="cc-cp-count" id="cc-cp-zones-count">0</span>
                        </div>
                        <div class="cc-cp-manager-card__body" id="cc-cp-zones-list"></div>
                    </section>

                    <section class="cc-cp-card cc-cp-manager-card cc-cp-manager-card--blocks">
                        <div class="cc-cp-manager-card__header">
                            <h2><?php esc_html_e('Blocks', 'cc-cp'); ?></h2>
                            <span class="cc-cp-count" id="cc-cp-blocks-count">0</span>
                        </div>
                        <div class="cc-cp-manager-card__body" id="cc-cp-blocks-list"></div>
                    </section>

                    <section class="cc-cp-card cc-cp-manager-card cc-cp-manager-card--anchors">
                        <div class="cc-cp-manager-card__header">
                            <h2><?php esc_html_e('Anchors', 'cc-cp'); ?></h2>
                            <span class="cc-cp-count" id="cc-cp-anchors-count">0</span>
                        </div>
                        <div class="cc-cp-manager-card__body" id="cc-cp-anchors-list"></div>
                    </section>
                </div>
            </section>

            <section class="cc-cp-panel" data-panel="pricing">
                <div class="cc-cp-card"><h2><?php esc_html_e('Manual Pricing Table', 'cc-cp'); ?></h2><p class="description"><?php esc_html_e('The map writes lane rows here. Edit manual pricing, size/weight modifiers, buffer cost, platform spread, labels, and active state. Total shipping fee is recalculated automatically.', 'cc-cp'); ?></p><div id="cc-cp-lanes-table"></div></div>
            </section>

            <section class="cc-cp-panel" data-panel="intelligence">
                <div class="cc-cp-card"><h2><?php esc_html_e('Lane Intelligence (scaffold)', 'cc-cp'); ?></h2><p><?php esc_html_e('This tab is ready for telemetry overlays later. It already lists lane labels, totals, and active state so you can grow into usage counts, ETA medians, late rates, and pricing validation.', 'cc-cp'); ?></p><div id="cc-cp-lane-intelligence"></div></div>
            </section>
        </div>

        <div class="cc-cp-modal" id="cc-cp-lane-modal" aria-hidden="true">
            <div class="cc-cp-modal__backdrop" data-close="1"></div>
            <div class="cc-cp-modal__dialog">
                <div class="cc-cp-modal__header"><h2><?php esc_html_e('Save Lane Pricing', 'cc-cp'); ?></h2><button type="button" class="cc-cp-modal__close" data-close="1">×</button></div>
                <div class="cc-cp-modal__body">
                    <div id="cc-cp-lane-title" class="cc-cp-lane-title"></div>
                    <div class="cc-cp-field-grid cc-cp-lane-grid">
                        <label><span><?php esc_html_e('Manual Pricing', 'cc-cp'); ?></span><input type="number" step="0.01" id="cc-cp-lane-manual" value="0"></label>
                        <label><span><?php esc_html_e('Size Modifier', 'cc-cp'); ?></span><input type="number" step="0.01" id="cc-cp-lane-size" value="0"></label>
                        <label><span><?php esc_html_e('Weight Modifier', 'cc-cp'); ?></span><input type="number" step="0.01" id="cc-cp-lane-weight" value="0"></label>
                        <label><span><?php esc_html_e('Buffer Cost', 'cc-cp'); ?></span><input type="number" step="0.01" id="cc-cp-lane-buffer" value="0"></label>
                        <label><span><?php esc_html_e('Platform Spread', 'cc-cp'); ?></span><input type="number" step="0.01" id="cc-cp-lane-platform" value="0"></label>
                        <label class="cc-cp-checkbox"><input type="checkbox" id="cc-cp-lane-active" checked><span><?php esc_html_e('Active', 'cc-cp'); ?></span></label>
                    </div>
                    <label><span><?php esc_html_e('Notes', 'cc-cp'); ?></span><textarea id="cc-cp-lane-notes" rows="4"></textarea></label>
                </div>
                <div class="cc-cp-modal__footer"><button type="button" class="button" data-close="1"><?php esc_html_e('Cancel', 'cc-cp'); ?></button><button type="button" class="button button-primary" id="cc-cp-save-lane"><?php esc_html_e('Save Lane', 'cc-cp'); ?></button></div>
            </div>
        </div>
        <?php
    }


private static function normalized_entity_id($type, $id, $label) {
    $id = sanitize_key((string) $id);
    if ($id !== '') {
        return $id;
    }

    $slug = sanitize_title((string) $label);
    if ($slug === '') {
        $slug = 'item';
    }

    return sanitize_key('cccp_' . $type . '_' . $slug);
}

private static function normalize_entity($type, $entity) {
    $entity = is_array($entity) ? $entity : array();

    $label = isset($entity['label']) ? (string) $entity['label'] : '';
    $entity['id'] = self::normalized_entity_id($type, $entity['id'] ?? '', $label);

    if (empty($entity['slug'])) {
        $entity['slug'] = sanitize_title($label);
    }

    return $entity;
}








    private static function require_access() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Forbidden.'), 403);
        }
        check_ajax_referer('cc_cp_admin_nonce', 'nonce');
    }

    private static function json_success($payload = array()) {
        wp_send_json_success(array_merge(array('plannerData' => self::planner_data()), $payload));
    }

    public static function ajax_get_data() { self::require_access(); self::json_success(); }

   public static function ajax_save_zone() {
    self::require_access();

    $label = wp_unslash($_POST['label'] ?? '');
    $id    = self::normalized_entity_id('zone', $_POST['id'] ?? '', $label);

    $zone = CC_CP_Storage::upsert_zone(array(
        'id'      => $id,
        'label'   => $label,
        'slug'    => wp_unslash($_POST['slug'] ?? ''),
        'color'   => wp_unslash($_POST['color'] ?? ''),
        'active'  => !empty($_POST['active']) ? 1 : 0,
        'polygon' => self::decode_json_array($_POST['polygon'] ?? '[]'),
        'anchor'  => self::decode_json_object($_POST['anchor'] ?? '{}'),
        'zone_type' => sanitize_key($_POST['zone_type'] ?? 'suburban'),
    ));

    self::json_success(array('entity' => self::normalize_entity('zone', $zone)));
}

  public static function ajax_save_block() {
    self::require_access();

    $label   = wp_unslash($_POST['label'] ?? '');
    $id      = self::normalized_entity_id('block', $_POST['id'] ?? '', $label);
    $zone_id = sanitize_key($_POST['zone_id'] ?? '');

    if ($zone_id === '') {
        $planner = self::planner_data();
        if (!empty($planner['zones'][0]['id'])) {
            $zone_id = sanitize_key($planner['zones'][0]['id']);
        }
    }

    $block = CC_CP_Storage::upsert_block(array(
        'id'      => $id,
        'label'   => $label,
        'slug'    => wp_unslash($_POST['slug'] ?? ''),
        'zone_id' => $zone_id,
        'color'   => wp_unslash($_POST['color'] ?? ''),
        'active'  => !empty($_POST['active']) ? 1 : 0,
        'polygon' => self::decode_json_array($_POST['polygon'] ?? '[]'),
        'anchor'  => self::decode_json_object($_POST['anchor'] ?? '{}'),
        'block_type' => sanitize_key($_POST['block_type'] ?? 'standard'),
    ));

    self::json_success(array('entity' => self::normalize_entity('block', $block)));
}

   public static function ajax_save_anchor() {
    self::require_access();

    $label = wp_unslash($_POST['label'] ?? '');
    $id    = self::normalized_entity_id('anchor', $_POST['id'] ?? '', $label);

    $anchor = CC_CP_Storage::upsert_anchor(array(
        'id'       => $id,
        'label'    => $label,
        'slug'     => wp_unslash($_POST['slug'] ?? ''),
        'zone_id'  => sanitize_key($_POST['zone_id'] ?? ''),
        'block_id' => sanitize_key($_POST['block_id'] ?? ''),
        'lat'      => (float) ($_POST['lat'] ?? 0),
        'lng'      => (float) ($_POST['lng'] ?? 0),
        'radius_m' => (int) ($_POST['radius_m'] ?? 150),
        'active'   => !empty($_POST['active']) ? 1 : 0,
    ));

    self::json_success(array('entity' => self::normalize_entity('anchor', $anchor)));
}

  public static function ajax_save_lane() {
    self::require_access();

    $label = wp_unslash($_POST['label'] ?? '');
    $id    = self::normalized_entity_id('lane', $_POST['id'] ?? '', $label);

    $lane = CC_CP_Storage::upsert_lane(array(
        'id'                   => $id,
        'origin_block_id'      => sanitize_key($_POST['origin_block_id'] ?? ''),
        'destination_block_id' => sanitize_key($_POST['destination_block_id'] ?? ''),
        'label'                => $label,
        'manual_price'         => (float) ($_POST['manual_price'] ?? 0),
        'size_modifier'        => (float) ($_POST['size_modifier'] ?? 0),
        'weight_modifier'      => (float) ($_POST['weight_modifier'] ?? 0),
        'buffer_cost'          => (float) ($_POST['buffer_cost'] ?? 0),
        'platform_spread'      => (float) ($_POST['platform_spread'] ?? 0),
        'notes'                => wp_unslash($_POST['notes'] ?? ''),
        'active'               => !empty($_POST['active']) ? 1 : 0,
    ));

    self::json_success(array('lane' => self::normalize_entity('lane', $lane)));
}
    public static function ajax_update_entity() {
        self::require_access();
        $entityType = sanitize_key($_POST['entity_type'] ?? '');
        $payload = array('id' => sanitize_key($_POST['id'] ?? ''), 'label' => wp_unslash($_POST['label'] ?? ''), 'slug' => wp_unslash($_POST['slug'] ?? ''), 'color' => wp_unslash($_POST['color'] ?? ''), 'active' => !empty($_POST['active']) ? 1 : 0);
        if ('zone' === $entityType) {
            $existing = CC_CP_Storage::find_zone_by_id($payload['id']);
            $entity = CC_CP_Storage::upsert_zone(array_merge((array) $existing, $payload, array('zone_type' => sanitize_key($_POST['zone_type'] ?? ($existing['zone_type'] ?? 'suburban')))));
            self::json_success(array('entity' => $entity));
        }
        if ('block' === $entityType) {
            $existing = CC_CP_Storage::find_block_by_id($payload['id']);
            $entity = CC_CP_Storage::upsert_block(array_merge((array) $existing, $payload, array('zone_id' => sanitize_key($_POST['zone_id'] ?? ($existing['zone_id'] ?? '')), 'block_type' => sanitize_key($_POST['block_type'] ?? ($existing['block_type'] ?? 'standard')))));
            self::json_success(array('entity' => $entity));
        }
        if ('anchor' === $entityType) {
            $anchors = CC_CP_Storage::get_anchors();
            foreach ($anchors as $anchor) {
                if ((string) $anchor['id'] === (string) $payload['id']) {
                    $entity = CC_CP_Storage::upsert_anchor(array_merge($anchor, $payload, array('zone_id' => sanitize_key($_POST['zone_id'] ?? ($anchor['zone_id'] ?? '')), 'block_id' => sanitize_key($_POST['block_id'] ?? ($anchor['block_id'] ?? '')))));
                    self::json_success(array('entity' => $entity));
                }
            }
        }
        wp_send_json_error(array('message' => 'Unknown entity type.'), 400);
    }

    public static function ajax_delete_entity() {
        self::require_access();

        $entity_type = sanitize_key($_POST['entity_type'] ?? '');
        $id = sanitize_key($_POST['id'] ?? '');

        if ($entity_type === '' || $id === '') {
            wp_send_json_error(array('message' => 'Missing delete target.'), 400);
        }

        if ('zone' === $entity_type) {
            $deleted = CC_CP_Storage::delete_zone($id);
            if (is_wp_error($deleted)) {
                wp_send_json_error(array('message' => $deleted->get_error_message()), 409);
            }
            self::json_success(array('deleted' => true));
        }

        if ('block' === $entity_type) {
            $deleted = CC_CP_Storage::delete_block($id);
            if (is_wp_error($deleted)) {
                wp_send_json_error(array('message' => $deleted->get_error_message()), 409);
            }
            self::json_success(array('deleted' => true));
        }

        if ('anchor' === $entity_type) {
            $deleted = CC_CP_Storage::delete_anchor($id);
            if (is_wp_error($deleted)) {
                wp_send_json_error(array('message' => $deleted->get_error_message()), 409);
            }
            self::json_success(array('deleted' => true));
        }

        wp_send_json_error(array('message' => 'Unknown entity type.'), 400);
    }

    public static function ajax_update_lane() {
        self::require_access();
        $lanes = CC_CP_Storage::get_lanes();
        foreach ($lanes as $lane) {
            if ((string) $lane['id'] === (string) sanitize_key($_POST['id'] ?? '')) {
                $updated = CC_CP_Storage::upsert_lane(array_merge($lane, array('label' => wp_unslash($_POST['label'] ?? $lane['label']), 'manual_price' => (float) ($_POST['manual_price'] ?? $lane['manual_price']), 'size_modifier' => (float) ($_POST['size_modifier'] ?? $lane['size_modifier']), 'weight_modifier' => (float) ($_POST['weight_modifier'] ?? $lane['weight_modifier']), 'buffer_cost' => (float) ($_POST['buffer_cost'] ?? $lane['buffer_cost']), 'platform_spread' => (float) ($_POST['platform_spread'] ?? $lane['platform_spread']), 'notes' => wp_unslash($_POST['notes'] ?? $lane['notes']), 'active' => !empty($_POST['active']) ? 1 : 0)));
                self::json_success(array('lane' => $updated));
            }
        }
        wp_send_json_error(array('message' => 'Lane not found.'), 404);
    }

    private static function decode_json_array($value) { $decoded = json_decode(wp_unslash((string) $value), true); return is_array($decoded) ? $decoded : array(); }
    private static function decode_json_object($value) { $decoded = json_decode(wp_unslash((string) $value), true); return is_array($decoded) ? $decoded : array(); }
}
