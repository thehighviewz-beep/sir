<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class CC_CP_Checkout_Shipping {
    const RATE_METHOD_ID = 'cc_planner';
    const CACHE_TTL = 300;

    public static function init() {
        add_action( 'woocommerce_checkout_update_order_review', array( __CLASS__, 'capture_checkout_context' ), 5, 1 );
        add_filter( 'woocommerce_cart_shipping_packages', array( __CLASS__, 'split_packages_by_vendor' ), 20 );
        add_filter( 'woocommerce_package_rates', array( __CLASS__, 'override_package_rates' ), 9999, 2 );
        add_filter( 'woocommerce_cart_shipping_method_full_label', array( __CLASS__, 'filter_full_label' ), 20, 2 );
        add_action( 'woocommerce_checkout_create_order_shipping_item', array( __CLASS__, 'persist_shipping_meta' ), 20, 4 );
        add_action( 'woocommerce_review_order_after_order_total', array( __CLASS__, 'render_summary_shipping_data' ), 30 );
    }

    protected static function is_enabled() {
        if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
            return false;
        }

        $enabled = get_option( 'cc_planner_shipping_override_enabled', 'yes' );
        return (bool) apply_filters( 'cc_cp_checkout_shipping_override_enabled', 'no' !== (string) $enabled );
    }

    public static function capture_checkout_context( $posted_data ) {
        if ( ! function_exists( 'WC' ) || ! WC()->session ) {
            return;
        }

        $parsed = array();
        if ( is_string( $posted_data ) && $posted_data !== '' ) {
            parse_str( wp_unslash( $posted_data ), $parsed );
        }

        self::persist_location_to_session( $parsed );
    }

    protected static function persist_location_to_session( array $data ) {
        if ( ! function_exists( 'WC' ) || ! WC()->session ) {
            return;
        }

        foreach ( array( 'cc_location_lat', 'cc_location_lng', 'cc_location_confirmed', 'cc_location_user_typed', 'cc_location_source', 'cc_location_ts', 'cc_location_formatted', 'cc_location_place_id', 'cc_location_quality', 'cc_location_payload' ) as $key ) {
            if ( isset( $data[ $key ] ) ) {
                WC()->session->set( $key, wc_clean( wp_unslash( $data[ $key ] ) ) );
            }
        }
    }

    protected static function get_request_value( $key ) {
        if ( isset( $_POST[ $key ] ) ) {
            return wc_clean( wp_unslash( $_POST[ $key ] ) );
        }

        if ( isset( $_POST['post_data'] ) ) {
            $parsed = array();
            parse_str( wp_unslash( $_POST['post_data'] ), $parsed );
            if ( isset( $parsed[ $key ] ) ) {
                self::persist_location_to_session( $parsed );
                return wc_clean( wp_unslash( $parsed[ $key ] ) );
            }
        }

        if ( function_exists( 'WC' ) && WC()->session ) {
            return (string) WC()->session->get( $key, '' );
        }

        return '';
    }

    protected static function get_customer_location() {
        $lat = (float) self::get_request_value( 'cc_location_lat' );
        $lng = (float) self::get_request_value( 'cc_location_lng' );
        $confirmed = (string) self::get_request_value( 'cc_location_confirmed' );

        return array(
            'lat' => $lat,
            'lng' => $lng,
            'confirmed' => ( '1' === $confirmed && $lat && $lng ),
        );
    }

    protected static function get_customer_destination() {
        $customer = function_exists( 'WC' ) ? WC()->customer : null;
        if ( ! $customer ) {
            return array();
        }

        $country = $customer->get_shipping_country();
        $state = $customer->get_shipping_state();
        $postcode = $customer->get_shipping_postcode();
        $city = $customer->get_shipping_city();
        $address_1 = $customer->get_shipping_address_1();
        $address_2 = $customer->get_shipping_address_2();

        if ( '' === $country ) {
            $country = $customer->get_billing_country();
        }
        if ( '' === $state ) {
            $state = $customer->get_billing_state();
        }
        if ( '' === $postcode ) {
            $postcode = $customer->get_billing_postcode();
        }
        if ( '' === $city ) {
            $city = $customer->get_billing_city();
        }
        if ( '' === $address_1 ) {
            $address_1 = $customer->get_billing_address_1();
        }
        if ( '' === $address_2 ) {
            $address_2 = $customer->get_billing_address_2();
        }

        return array(
            'country' => $country,
            'state' => $state,
            'postcode' => $postcode,
            'city' => $city,
            'address' => $address_1,
            'address_1' => $address_1,
            'address_2' => $address_2,
        );
    }

    protected static function resolve_vendor_id_for_cart_item( array $cart_item ) {
        $item = new WC_Order_Item_Product();
        if ( ! empty( $cart_item['data'] ) && $cart_item['data'] instanceof WC_Product ) {
            $item->set_product( $cart_item['data'] );
        }

        $vendor_id = (int) apply_filters( 'cc_logistics_vendor_id_for_item', 0, null, $item );
        if ( $vendor_id > 0 ) {
            return $vendor_id;
        }

        $product_id = ! empty( $cart_item['product_id'] ) ? (int) $cart_item['product_id'] : 0;
        if ( $product_id > 0 ) {
            $author_id = (int) get_post_field( 'post_author', $product_id );
            if ( $author_id > 0 ) {
                return $author_id;
            }
        }

        return 0;
    }

    protected static function resolve_vendor_label( $vendor_id ) {
        $vendor_id = (int) $vendor_id;
        if ( $vendor_id <= 0 ) {
            return 'Caricove Marketplace';
        }

        if ( function_exists( 'dokan_get_store_info' ) ) {
            $info = dokan_get_store_info( $vendor_id );
            if ( is_array( $info ) && ! empty( $info['store_name'] ) ) {
                return (string) $info['store_name'];
            }
        }

        if ( function_exists( 'dokan_get_store_name' ) ) {
            $name = (string) dokan_get_store_name( $vendor_id );
            if ( '' !== $name ) {
                return $name;
            }
        }

        $display_name = (string) get_the_author_meta( 'display_name', $vendor_id );
        return '' !== $display_name ? $display_name : 'Vendor ' . $vendor_id;
    }

    protected static function resolve_vendor_coords( $vendor_id ) {
        return array(
            'lat' => (float) get_user_meta( (int) $vendor_id, '_cc_vendor_lat', true ),
            'lng' => (float) get_user_meta( (int) $vendor_id, '_cc_vendor_lng', true ),
        );
    }

    protected static function package_context_hash( $vendor_id, array $vendor_coords, array $customer_location, array $destination, array $contents ) {
        $items = array();
        foreach ( $contents as $key => $row ) {
            $items[ $key ] = array(
                'product_id' => (int) ( $row['product_id'] ?? 0 ),
                'variation_id' => (int) ( $row['variation_id'] ?? 0 ),
                'qty' => (int) ( $row['quantity'] ?? 0 ),
                'line_total' => (float) ( $row['line_total'] ?? 0 ),
            );
        }

        return md5( wp_json_encode( array(
            'vendor_id' => (int) $vendor_id,
            'vendor_lat' => (float) $vendor_coords['lat'],
            'vendor_lng' => (float) $vendor_coords['lng'],
            'customer_lat' => (float) $customer_location['lat'],
            'customer_lng' => (float) $customer_location['lng'],
            'destination' => $destination,
            'items' => $items,
        ) ) );
    }

    public static function split_packages_by_vendor( $packages ) {
        if ( ! self::is_enabled() ) {
            return $packages;
        }

        $location = self::get_customer_location();
        $destination = self::get_customer_destination();
        $grouped = array();

        foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
            if ( empty( $cart_item['data'] ) || ! $cart_item['data']->needs_shipping() ) {
                continue;
            }

            $vendor_id = self::resolve_vendor_id_for_cart_item( $cart_item );
            if ( ! isset( $grouped[ $vendor_id ] ) ) {
                $grouped[ $vendor_id ] = array();
            }
            $grouped[ $vendor_id ][ $cart_item_key ] = $cart_item;
        }

        if ( empty( $grouped ) ) {
            return $packages;
        }

        $out = array();
        foreach ( $grouped as $vendor_id => $contents ) {
            $vendor_coords = self::resolve_vendor_coords( $vendor_id );
            $vendor_label = self::resolve_vendor_label( $vendor_id );
            $context_hash = self::package_context_hash( $vendor_id, $vendor_coords, $location, $destination, $contents );

            $out[] = array(
                'contents' => $contents,
                'contents_cost' => array_sum( wp_list_pluck( $contents, 'line_total' ) ),
                'applied_coupons' => WC()->cart->get_applied_coupons(),
                'user' => array( 'ID' => get_current_user_id() ),
                'destination' => $destination,
                'package_name' => sprintf( 'Delivery - %s', $vendor_label ),
                'cc_vendor_id' => (int) $vendor_id,
                'seller_id' => $vendor_id,
                'cc_vendor_label' => $vendor_label,
                'cc_vendor_lat' => (float) $vendor_coords['lat'],
                'cc_vendor_lng' => (float) $vendor_coords['lng'],
                'cc_customer_lat' => (float) $location['lat'],
                'cc_customer_lng' => (float) $location['lng'],
                'cc_customer_confirmed' => ! empty( $location['confirmed'] ) ? 1 : 0,
                'cc_planner_context_hash' => $context_hash,
            );
        }

        self::log( 'debug', 'split_packages', array( 'packages' => array_map( array( __CLASS__, 'safe_package_log' ), $out ) ) );
        return $out;
    }

    public static function override_package_rates( $rates, $package ) {
        if ( ! self::is_enabled() || empty( $package['cc_planner_context_hash'] ) ) {
            return $rates;
        }

        $quote = self::get_quote_for_package( $package );
        if ( is_wp_error( $quote ) ) {
            self::log( 'error', 'planner_quote_failed', array(
                'error' => $quote->get_error_message(),
                'package' => self::safe_package_log( $package ),
            ) );
            return $rates;
        }

        $amount = isset( $quote['total'] ) ? (float) $quote['total'] : (float) ( $quote['amount'] ?? 0 );
        if ( $amount <= 0 ) {
            return $rates;
        }

        $vendor_label = ! empty( $package['cc_vendor_label'] ) ? (string) $package['cc_vendor_label'] : 'Delivery';
        $label = sprintf( 'Delivery - %s', $vendor_label );
        $rate_id = self::RATE_METHOD_ID . ':' . substr( md5( (string) $package['cc_planner_context_hash'] ), 0, 12 );

        $rate = new WC_Shipping_Rate(
            $rate_id,
            $label,
            wc_format_decimal( $amount ),
            array(),
            self::RATE_METHOD_ID
        );

        if ( method_exists( $rate, 'set_description' ) ) {
            $desc_parts = array();
            if ( ! empty( $quote['distance_km'] ) ) {
                $desc_parts[] = number_format_i18n( (float) $quote['distance_km'], 1 ) . ' km';
            }
            if ( ! empty( $quote['duration_seconds'] ) ) {
                $minutes = max( 1, (int) ceil( (int) $quote['duration_seconds'] / 60 ) );
                $desc_parts[] = $minutes . ' min';
            }
            if ( $desc_parts ) {
                $rate->set_description( 'Planner quote • ' . implode( ' • ', $desc_parts ) );
            }
        }

        $rate->add_meta_data( '_cc_vendor_id', (int) ( $package['cc_vendor_id'] ?? 0 ), true );
        $rate->add_meta_data( '_cc_vendor_label', $vendor_label, true );
        $rate->add_meta_data( '_cc_planner_context_hash', (string) $package['cc_planner_context_hash'], true );
        $rate->add_meta_data( '_cc_planner_quote', wp_json_encode( $quote ), true );

        self::log( 'debug', 'planner_rate_applied', array(
            'rate_id' => $rate_id,
            'amount' => $amount,
            'vendor_id' => (int) ( $package['cc_vendor_id'] ?? 0 ),
            'context_hash' => (string) $package['cc_planner_context_hash'],
        ) );

        return array( $rate_id => $rate );
    }

    protected static function get_quote_for_package( array $package ) {
        $cache_key = 'cc_planner_quote_' . ( $package['cc_planner_context_hash'] ?? md5( wp_json_encode( $package ) ) );
        $cached = get_transient( $cache_key );
        if ( false !== $cached && is_array( $cached ) ) {
            $cached['_cache_hit'] = true;
            return $cached;
        }

        $seller_lat = (float) ( $package['cc_vendor_lat'] ?? 0 );
        $seller_lng = (float) ( $package['cc_vendor_lng'] ?? 0 );
        $customer_lat = (float) ( $package['cc_customer_lat'] ?? 0 );
        $customer_lng = (float) ( $package['cc_customer_lng'] ?? 0 );

        if ( ! $seller_lat || ! $seller_lng || ! $customer_lat || ! $customer_lng ) {
            return new WP_Error( 'planner_missing_coords', 'Seller/customer coordinates missing for planner quote.' );
        }

        $args = array(
            'seller_lat' => $seller_lat,
            'seller_lng' => $seller_lng,
            'customer_lat' => $customer_lat,
            'customer_lng' => $customer_lng,
        );

        if ( class_exists( 'CC_CP_Engine' ) && method_exists( 'CC_CP_Engine', 'calculate_shipping_fee' ) ) {
            $result = CC_CP_Engine::calculate_shipping_fee( $args );
        } else {
            $result = self::quote_via_remote_api( $args, $package );
        }

        if ( ! is_wp_error( $result ) && is_array( $result ) ) {
            set_transient( $cache_key, $result, self::CACHE_TTL );
        }

        return $result;
    }

    protected static function quote_via_remote_api( array $args, array $package ) {
        $endpoint = trim( (string) get_option( 'cc_price_planner_endpoint', '' ) );
        $token = trim( (string) get_option( 'cc_price_planner_api_token', '' ) );

        if ( '' === $endpoint ) {
            return new WP_Error( 'planner_not_configured', 'No planner endpoint configured.' );
        }

        $response = wp_safe_remote_post( $endpoint, array(
            'timeout' => 8,
            'headers' => array_filter( array(
                'Content-Type' => 'application/json',
                'Authorization' => $token ? 'Bearer ' . $token : '',
            ) ),
            'body' => wp_json_encode( array(
                'origin' => array( 'lat' => $args['seller_lat'], 'lng' => $args['seller_lng'] ),
                'destination' => array( 'lat' => $args['customer_lat'], 'lng' => $args['customer_lng'] ),
                'vendor_id' => (int) ( $package['cc_vendor_id'] ?? 0 ),
                'currency' => function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : '',
            ) ),
        ) );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        $code = wp_remote_retrieve_response_code( $response );
        if ( $code < 200 || $code >= 300 || empty( $body['amount'] ) ) {
            return new WP_Error( 'planner_bad_response', 'Planner response invalid.', array(
                'http_code' => $code,
                'body' => $body,
            ) );
        }

        return array(
            'total' => (float) $body['amount'],
            'distance_km' => isset( $body['distance_km'] ) ? (float) $body['distance_km'] : 0,
            'duration_seconds' => isset( $body['duration_seconds'] ) ? (int) $body['duration_seconds'] : 0,
            'source' => 'remote_api',
            'raw' => $body,
        );
    }

    protected static function get_summary_shipping_lines() {
        if ( ! function_exists( 'WC' ) || ! WC()->cart || ! WC()->session ) {
            return array();
        }

        $packages = array();
        if ( WC()->shipping() && method_exists( WC()->shipping(), 'get_packages' ) ) {
            $packages = (array) WC()->shipping()->get_packages();
        }
        if ( empty( $packages ) && method_exists( WC()->cart, 'get_shipping_packages' ) ) {
            $packages = (array) WC()->cart->get_shipping_packages();
        }

        $chosen_methods = (array) WC()->session->get( 'chosen_shipping_methods', array() );
        $lines = array();

        foreach ( $packages as $index => $package ) {
            $rates = isset( $package['rates'] ) && is_array( $package['rates'] ) ? $package['rates'] : array();
            if ( empty( $rates ) ) {
                continue;
            }

            $chosen_id = isset( $chosen_methods[ $index ] ) ? (string) $chosen_methods[ $index ] : '';
            $rate = null;
            if ( $chosen_id && isset( $rates[ $chosen_id ] ) ) {
                $rate = $rates[ $chosen_id ];
            } else {
                $first = reset( $rates );
                if ( $first instanceof WC_Shipping_Rate ) {
                    $rate = $first;
                }
            }

            if ( ! $rate instanceof WC_Shipping_Rate ) {
                continue;
            }

            $vendor_label = '';
            if ( ! empty( $package['cc_vendor_label'] ) ) {
                $vendor_label = (string) $package['cc_vendor_label'];
            }
            if ( '' === $vendor_label ) {
                $rate_label = method_exists( $rate, 'get_label' ) ? (string) $rate->get_label() : '';
                $vendor_label = preg_replace( '/^\s*(Delivery|Shipping)\s*-\s*/i', '', $rate_label );
            }
            $vendor_label = trim( (string) $vendor_label );
            $label = $vendor_label ? sprintf( 'Shipping by %s', $vendor_label ) : 'Shipping';

            $amount = (float) $rate->get_cost();
            $taxes = method_exists( $rate, 'get_taxes' ) ? (array) $rate->get_taxes() : array();
            if ( WC()->cart && method_exists( WC()->cart, 'display_prices_including_tax' ) && WC()->cart->display_prices_including_tax() ) {
                $amount += array_sum( array_map( 'floatval', $taxes ) );
            }

            $lines[] = array(
                'label' => $label,
                'amount' => wp_strip_all_tags( html_entity_decode( wc_price( $amount ), ENT_QUOTES, get_bloginfo( 'charset' ) ) ),
            );
        }

        return $lines;
    }

    public static function render_summary_shipping_data() {
        $lines = self::get_summary_shipping_lines();
        if ( empty( $lines ) ) {
            return;
        }

        echo '<tr class="cc-summary-shipping-data" style="display:none !important;" aria-hidden="true"><td colspan="2"><div class="cc-summary-shipping-lines" data-count="' . esc_attr( count( $lines ) ) . '">';
        foreach ( $lines as $index => $line ) {
            echo '<span class="cc-summary-shipping-line" data-key="shipping-' . esc_attr( $index ) . '" data-label="' . esc_attr( $line['label'] ) . '" data-amount="' . esc_attr( $line['amount'] ) . '"></span>';
        }
        echo '</div></td></tr>';
    }

    public static function filter_full_label( $label, $method ) {
        if ( ! $method instanceof WC_Shipping_Rate ) {
            return $label;
        }

        if ( 0 !== strpos( $method->get_method_id(), self::RATE_METHOD_ID ) ) {
            return $label;
        }

        $description = method_exists( $method, 'get_description' ) ? trim( (string) $method->get_description() ) : '';
        if ( '' !== $description ) {
            $label .= '<br><small>' . esc_html( $description ) . '</small>';
        }
        return $label;
    }

    public static function persist_shipping_meta( $item, $package_key, $package, $order ) {
        if ( ! $item instanceof WC_Order_Item_Shipping ) {
            return;
        }

        $item->add_meta_data( '_cc_vendor_id', (int) ( $package['cc_vendor_id'] ?? 0 ), true );
        $item->add_meta_data( '_cc_vendor_label', (string) ( $package['cc_vendor_label'] ?? '' ), true );
        $item->add_meta_data( '_cc_planner_context_hash', (string) ( $package['cc_planner_context_hash'] ?? '' ), true );

        if ( ! empty( $package['cc_planner_context_hash'] ) ) {
            $quote = get_transient( 'cc_planner_quote_' . $package['cc_planner_context_hash'] );
            if ( is_array( $quote ) ) {
                $item->add_meta_data( '_cc_planner_quote_total', (float) ( $quote['total'] ?? 0 ), true );
                $item->add_meta_data( '_cc_planner_quote_distance_km', (float) ( $quote['distance_km'] ?? 0 ), true );
                $item->add_meta_data( '_cc_planner_quote_duration_seconds', (int) ( $quote['duration_seconds'] ?? 0 ), true );
                $item->add_meta_data( '_cc_planner_quote', wp_json_encode( $quote ), true );
            }
        }

        if ( $order instanceof WC_Order ) {
            $location = self::get_customer_location();
            if ( ! empty( $location['lat'] ) && ! $order->get_meta( '_cc_dropoff_lat' ) ) {
                $order->update_meta_data( '_cc_dropoff_lat', $location['lat'] );
            }
            if ( ! empty( $location['lng'] ) && ! $order->get_meta( '_cc_dropoff_lng' ) ) {
                $order->update_meta_data( '_cc_dropoff_lng', $location['lng'] );
            }
        }
    }

    protected static function log( $level, $message, array $context = array() ) {
        if ( ! function_exists( 'wc_get_logger' ) ) {
            return;
        }

        $logger = wc_get_logger();
        $context['source'] = 'cc-planner-shipping';
        $logger->log( $level, $message . ' ' . wp_json_encode( $context ), $context );
    }

    public static function safe_package_log( array $package ) {
        unset( $package['contents'] );
        return $package;
    }
}
