<?php
if (!defined('ABSPATH')) { exit; }
require_once dirname(__DIR__) . '/engine/class-cp-pricing-engine.php';

final class CC_CP_Engine {
    public static function calculate_shipping_fee(array $args) {
        return CC_CP_Pricing_Engine::calculate($args);
    }

    public static function quote_for_shipment($shipment_id) {
        return CC_CP_Pricing_Engine::quote_for_shipment($shipment_id);
    }

    public static function class_modifier($class, $type) {
        $defaults = array(
            'size' => array(
                'small'      => 0,
                'standard'   => 0,
                'bulky'      => 150,
                'oversized'  => 350,
            ),
            'weight' => array(
                'light'      => 0,
                'standard'   => 0,
                'heavy'      => 175,
                'very_heavy' => 425,
            ),
        );
        $map = apply_filters('cc_cp_class_modifiers', $defaults);
        return isset($map[$type][$class]) ? CC_CP_Storage::money($map[$type][$class]) : 0;
    }
}
