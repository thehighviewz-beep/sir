<?php

if (!defined('ABSPATH')) {
    exit;
}

final class CC_CP_Storage {
    const OPT_ZONES   = 'cc_cp_zones';
    const OPT_BLOCKS  = 'cc_cp_blocks';
    const OPT_ANCHORS = 'cc_cp_anchors';
    const OPT_LANES   = 'cc_cp_lanes';

    public static function init() {
        add_action('admin_init', array(__CLASS__, 'maybe_seed_defaults'));
    }

    public static function maybe_seed_defaults() {
        foreach (array(
            self::OPT_ZONES   => array(),
            self::OPT_BLOCKS  => array(),
            self::OPT_ANCHORS => array(),
            self::OPT_LANES   => array(),
        ) as $key => $default) {
            if (false === get_option($key, false)) {
                add_option($key, $default, '', false);
            }
        }
    }

    public static function all() {
        return array(
            'zones'   => self::get_zones(),
            'blocks'  => self::get_blocks(),
            'anchors' => self::get_anchors(),
            'lanes'   => self::get_lanes(),
        );
    }

    public static function get_zones() {
        return self::sanitize_zone_list((array) get_option(self::OPT_ZONES, array()));
    }

    public static function get_blocks() {
        return self::sanitize_block_list((array) get_option(self::OPT_BLOCKS, array()));
    }

    public static function get_anchors() {
        return self::sanitize_anchor_list((array) get_option(self::OPT_ANCHORS, array()));
    }

    public static function get_lanes() {
        return self::sanitize_lane_list((array) get_option(self::OPT_LANES, array()));
    }

    public static function upsert_zone(array $raw) {
        $zones = self::get_zones();
        $zone  = self::sanitize_zone($raw);

        $zones = self::upsert_by_id($zones, $zone);
        update_option(self::OPT_ZONES, array_values($zones), false);
        self::sync_existing_geo_registry();

        return $zone;
    }

    public static function upsert_block(array $raw) {
        $blocks = self::get_blocks();
        $block  = self::sanitize_block($raw);

        $blocks = self::upsert_by_id($blocks, $block);
        update_option(self::OPT_BLOCKS, array_values($blocks), false);
        self::sync_existing_geo_registry();

        return $block;
    }

    public static function upsert_anchor(array $raw) {
        $anchors = self::get_anchors();
        $anchor  = self::sanitize_anchor($raw);

        $anchors = self::upsert_by_id($anchors, $anchor);
        update_option(self::OPT_ANCHORS, array_values($anchors), false);
        self::sync_existing_geo_registry();

        return $anchor;
    }

    public static function upsert_lane(array $raw) {
        $lanes = self::get_lanes();
        $lane  = self::sanitize_lane($raw);

        $lanes = self::upsert_by_id($lanes, $lane);
        update_option(self::OPT_LANES, array_values($lanes), false);

        return $lane;
    }


    public static function delete_zone($zone_id) {
        $zone_id = sanitize_key($zone_id);

        foreach (self::get_blocks() as $block) {
            if ((string) ($block['zone_id'] ?? '') === (string) $zone_id) {
                return new WP_Error('zone_has_blocks', 'Delete the child blocks first.');
            }
        }

        foreach (self::get_anchors() as $anchor) {
            if ((string) ($anchor['zone_id'] ?? '') === (string) $zone_id) {
                return new WP_Error('zone_has_anchors', 'Delete or reassign the child anchors first.');
            }
        }

        update_option(self::OPT_ZONES, array_values(self::delete_by_id(self::get_zones(), $zone_id)), false);
        self::sync_existing_geo_registry();
        return true;
    }

    public static function delete_block($block_id) {
        $block_id = sanitize_key($block_id);

        foreach (self::get_anchors() as $anchor) {
            if ((string) ($anchor['block_id'] ?? '') === (string) $block_id) {
                return new WP_Error('block_has_anchors', 'Delete or reassign the child anchors first.');
            }
        }

        foreach (self::get_lanes() as $lane) {
            if ((string) ($lane['origin_block_id'] ?? '') === (string) $block_id || (string) ($lane['destination_block_id'] ?? '') === (string) $block_id) {
                return new WP_Error('block_has_lanes', 'Delete the connected lane rows first.');
            }
        }

        update_option(self::OPT_BLOCKS, array_values(self::delete_by_id(self::get_blocks(), $block_id)), false);
        self::sync_existing_geo_registry();
        return true;
    }

    public static function delete_anchor($anchor_id) {
        $anchor_id = sanitize_key($anchor_id);
        update_option(self::OPT_ANCHORS, array_values(self::delete_by_id(self::get_anchors(), $anchor_id)), false);
        self::sync_existing_geo_registry();
        return true;
    }

    public static function find_block_by_id($block_id) {
        foreach (self::get_blocks() as $block) {
            if ((string) $block['id'] === (string) $block_id) {
                return $block;
            }
        }
        return null;
    }

    public static function find_zone_by_id($zone_id) {
        foreach (self::get_zones() as $zone) {
            if ((string) $zone['id'] === (string) $zone_id) {
                return $zone;
            }
        }
        return null;
    }


    public static function find_lane($origin_block_id, $destination_block_id) {
        foreach (self::get_lanes() as $lane) {
            if (
                (string) $lane['origin_block_id'] === (string) $origin_block_id &&
                (string) $lane['destination_block_id'] === (string) $destination_block_id &&
                !empty($lane['active'])
            ) {
                return $lane;
            }
        }
        return null;
    }

    public static function resolve_point_to_zone($lat, $lng, $resolvedBlock = null) {
        if ($resolvedBlock && !empty($resolvedBlock['zone_id'])) {
            $zone = self::find_zone_by_id($resolvedBlock['zone_id']);
            if ($zone) {
                return $zone;
            }
        }
        foreach (self::get_zones() as $zone) {
            if (empty($zone['active'])) {
                continue;
            }
            if (self::point_in_polygon((float) $lat, (float) $lng, $zone['polygon'])) {
                return $zone;
            }
        }
        $nearest = null;
        $nearestMeters = INF;
        foreach (self::get_zones() as $zone) {
            if (empty($zone['polygon'])) continue;
            $anchor = self::sanitize_anchor_point(array(), $zone['polygon']);
            $meters = self::haversine_m($lat, $lng, $anchor['lat'], $anchor['lng']);
            if ($meters < $nearestMeters) {
                $nearestMeters = $meters;
                $nearest = $zone;
            }
        }
        return $nearest;
    }

    public static function resolve_point_to_block($lat, $lng) {
        foreach (self::get_blocks() as $block) {
            if (empty($block['active'])) {
                continue;
            }
            if (self::point_in_polygon((float) $lat, (float) $lng, $block['polygon'])) {
                return $block;
            }
        }

        // Fallback: nearest block anchor.
        $nearest       = null;
        $nearestMeters = INF;
        foreach (self::get_blocks() as $block) {
            if (empty($block['active']) || empty($block['anchor']['lat']) || empty($block['anchor']['lng'])) {
                continue;
            }
            $meters = self::haversine_m($lat, $lng, $block['anchor']['lat'], $block['anchor']['lng']);
            if ($meters < $nearestMeters) {
                $nearestMeters = $meters;
                $nearest       = $block;
            }
        }
        return $nearest;
    }

    public static function sync_existing_geo_registry() {
        $zones = array();
        foreach (self::get_zones() as $zone) {
            $zones[] = array(
                'zone_id' => $zone['slug'],
                'label'   => $zone['label'],
                'polygon' => array_map(function ($point) {
                    return array((float) $point['lat'], (float) $point['lng']);
                }, (array) $zone['polygon']),
                'anchors' => array_values(array_filter(wp_list_pluck(array_filter(self::get_anchors(), function ($anchor) use ($zone) {
                    return (string) $anchor['zone_id'] === (string) $zone['id'];
                }), 'slug'))),
                'zone_type' => $zone['zone_type'] ?? 'suburban',
            );
        }

        $anchors = array();
        foreach (self::get_anchors() as $anchor) {
            $anchors[] = array(
                'slug'     => $anchor['slug'],
                'label'    => $anchor['label'],
                'lat'      => (float) $anchor['lat'],
                'lng'      => (float) $anchor['lng'],
                'radius_m' => (int) $anchor['radius_m'],
                'zone_id'  => ($zone = self::find_zone_by_id($anchor['zone_id'])) ? $zone['slug'] : '',
            );
        }

        update_option('_cc_zone_definitions', $zones, false);
        update_option('_cc_anchor_definitions', $anchors, false);
        update_option('_cc_block_definitions', self::get_blocks(), false);
        update_option('_cc_lane_pricing_definitions', self::get_lanes(), false);
    }

    private static function delete_by_id(array $items, $id) {
        return array_values(array_filter($items, function($item) use ($id) {
            return (string) ($item['id'] ?? '') !== (string) $id;
        }));
    }

    private static function upsert_by_id(array $items, array $item) {
        $found = false;
        foreach ($items as $index => $existing) {
            if ((string) $existing['id'] === (string) $item['id']) {
                $items[$index] = $item;
                $found         = true;
                break;
            }
        }
        if (!$found) {
            $items[] = $item;
        }
        return $items;
    }

    private static function sanitize_zone_list(array $zones) {
        return array_values(array_map(array(__CLASS__, 'sanitize_zone'), $zones));
    }

    private static function sanitize_block_list(array $blocks) {
        return array_values(array_map(array(__CLASS__, 'sanitize_block'), $blocks));
    }

    private static function sanitize_anchor_list(array $anchors) {
        return array_values(array_map(array(__CLASS__, 'sanitize_anchor'), $anchors));
    }

    private static function sanitize_lane_list(array $lanes) {
        return array_values(array_map(array(__CLASS__, 'sanitize_lane'), $lanes));
    }

    private static function sanitize_zone(array $raw) {
        $label = sanitize_text_field($raw['label'] ?? '');
        $slug  = sanitize_title($raw['slug'] ?? $label);
        $id    = sanitize_key($raw['id'] ?? ('zone_' . $slug . '_' . substr(md5(wp_json_encode($raw)), 0, 8)));

        return array(
            'id'         => $id,
            'slug'       => $slug ?: $id,
            'label'      => $label ?: 'Unnamed Zone',
            'color'      => self::sanitize_hex_color($raw['color'] ?? '#3b82f6'),
            'active'     => !empty($raw['active']) ? 1 : 0,
            'polygon'    => self::sanitize_polygon($raw['polygon'] ?? array()),
            'zone_type'  => class_exists('CC_CP_Settings') ? CC_CP_Settings::normalize_zone_type($raw['zone_type'] ?? 'suburban') : sanitize_key($raw['zone_type'] ?? 'suburban'),
            'created_at' => sanitize_text_field($raw['created_at'] ?? current_time('mysql')),
            'updated_at' => current_time('mysql'),
        );
    }

    private static function sanitize_block(array $raw) {
        $label   = sanitize_text_field($raw['label'] ?? '');
        $slug    = sanitize_title($raw['slug'] ?? $label);
        $id      = sanitize_key($raw['id'] ?? ('block_' . $slug . '_' . substr(md5(wp_json_encode($raw)), 0, 8)));
        $polygon = self::sanitize_polygon($raw['polygon'] ?? array());
        $anchor  = self::sanitize_anchor_point($raw['anchor'] ?? array(), $polygon);

        return array(
            'id'         => $id,
            'slug'       => $slug ?: $id,
            'label'      => $label ?: 'Unnamed Block',
            'zone_id'    => sanitize_key($raw['zone_id'] ?? ''),
            'color'      => self::sanitize_hex_color($raw['color'] ?? '#22c55e'),
            'active'     => !empty($raw['active']) ? 1 : 0,
            'polygon'    => $polygon,
            'anchor'     => $anchor,
            'block_type' => class_exists('CC_CP_Settings') ? CC_CP_Settings::normalize_block_type($raw['block_type'] ?? 'standard') : sanitize_key($raw['block_type'] ?? 'standard'),
            'created_at' => sanitize_text_field($raw['created_at'] ?? current_time('mysql')),
            'updated_at' => current_time('mysql'),
        );
    }

    private static function sanitize_anchor(array $raw) {
        $label = sanitize_text_field($raw['label'] ?? '');
        $slug  = sanitize_title($raw['slug'] ?? $label);
        $id    = sanitize_key($raw['id'] ?? ('anchor_' . $slug . '_' . substr(md5(wp_json_encode($raw)), 0, 8)));

        return array(
            'id'         => $id,
            'slug'       => $slug ?: $id,
            'label'      => $label ?: 'Unnamed Anchor',
            'lat'        => round((float) ($raw['lat'] ?? 0), 6),
            'lng'        => round((float) ($raw['lng'] ?? 0), 6),
            'radius_m'   => max(25, (int) ($raw['radius_m'] ?? 150)),
            'zone_id'    => sanitize_key($raw['zone_id'] ?? ''),
            'block_id'   => sanitize_key($raw['block_id'] ?? ''),
            'active'     => !empty($raw['active']) ? 1 : 0,
            'created_at' => sanitize_text_field($raw['created_at'] ?? current_time('mysql')),
            'updated_at' => current_time('mysql'),
        );
    }

    private static function sanitize_lane(array $raw) {
        $id            = sanitize_key($raw['id'] ?? ('lane_' . substr(md5(wp_json_encode($raw)), 0, 12)));
        $originBlockId = sanitize_key($raw['origin_block_id'] ?? '');
        $destBlockId   = sanitize_key($raw['destination_block_id'] ?? '');
        $manualPrice   = self::money($raw['manual_price'] ?? 0);
        $sizeModifier  = self::money($raw['size_modifier'] ?? 0);
        $weightMod     = self::money($raw['weight_modifier'] ?? 0);
        $bufferCost    = self::money($raw['buffer_cost'] ?? 0);
        $platform      = self::money($raw['platform_spread'] ?? 0);
        $total         = self::money($manualPrice + $sizeModifier + $weightMod + $bufferCost + $platform);

        return array(
            'id'                   => $id,
            'origin_block_id'      => $originBlockId,
            'destination_block_id' => $destBlockId,
            'label'                => sanitize_text_field($raw['label'] ?? self::build_lane_label($originBlockId, $destBlockId)),
            'manual_price'         => $manualPrice,
            'size_modifier'        => $sizeModifier,
            'weight_modifier'      => $weightMod,
            'buffer_cost'          => $bufferCost,
            'platform_spread'      => $platform,
            'total_shipping_fee'   => $total,
            'notes'                => sanitize_textarea_field($raw['notes'] ?? ''),
            'active'               => !empty($raw['active']) ? 1 : 0,
            'created_at'           => sanitize_text_field($raw['created_at'] ?? current_time('mysql')),
            'updated_at'           => current_time('mysql'),
        );
    }

    public static function build_lane_label($originBlockId, $destBlockId) {
        $origin = self::find_block_by_id($originBlockId);
        $dest   = self::find_block_by_id($destBlockId);
        return trim(($origin['label'] ?? 'Unknown Origin') . ' → ' . ($dest['label'] ?? 'Unknown Destination'));
    }

    public static function money($value) {
        return round((float) $value, 2);
    }

    public static function sanitize_hex_color($value) {
        $value = is_string($value) ? trim($value) : '';
        return preg_match('/^#[0-9a-fA-F]{6}$/', $value) ? $value : '#3b82f6';
    }

    public static function sanitize_polygon($polygon) {
        $clean = array();
        if (!is_array($polygon)) {
            return $clean;
        }

        foreach ($polygon as $point) {
            if (is_array($point) && isset($point['lat'], $point['lng'])) {
                $clean[] = array(
                    'lat' => round((float) $point['lat'], 6),
                    'lng' => round((float) $point['lng'], 6),
                );
            } elseif (is_array($point) && isset($point[0], $point[1])) {
                $clean[] = array(
                    'lat' => round((float) $point[0], 6),
                    'lng' => round((float) $point[1], 6),
                );
            }
        }

        return $clean;
    }

    private static function sanitize_anchor_point($anchor, array $polygon) {
        if (is_array($anchor) && isset($anchor['lat'], $anchor['lng'])) {
            return array(
                'lat' => round((float) $anchor['lat'], 6),
                'lng' => round((float) $anchor['lng'], 6),
            );
        }

        if (empty($polygon)) {
            return array('lat' => 0, 'lng' => 0);
        }

        $sumLat = 0;
        $sumLng = 0;
        foreach ($polygon as $point) {
            $sumLat += (float) $point['lat'];
            $sumLng += (float) $point['lng'];
        }

        return array(
            'lat' => round($sumLat / count($polygon), 6),
            'lng' => round($sumLng / count($polygon), 6),
        );
    }

    public static function haversine_m($lat1, $lng1, $lat2, $lng2) {
        $earth = 6371000;
        $dLat  = deg2rad((float) $lat2 - (float) $lat1);
        $dLng  = deg2rad((float) $lng2 - (float) $lng1);
        $a     = sin($dLat / 2) * sin($dLat / 2) + cos(deg2rad((float) $lat1)) * cos(deg2rad((float) $lat2)) * sin($dLng / 2) * sin($dLng / 2);
        $c     = 2 * atan2(sqrt($a), sqrt(1 - $a));
        return (float) ($earth * $c);
    }

    public static function point_in_polygon($lat, $lng, array $polygon) {
        $inside = false;
        $j      = count($polygon) - 1;
        if ($j < 2) {
            return false;
        }

        for ($i = 0; $i < count($polygon); $i++) {
            $xi = (float) $polygon[$i]['lng'];
            $yi = (float) $polygon[$i]['lat'];
            $xj = (float) $polygon[$j]['lng'];
            $yj = (float) $polygon[$j]['lat'];

            $intersect = (($yi > $lat) !== ($yj > $lat)) && ($lng < ($xj - $xi) * ($lat - $yi) / (($yj - $yi) ?: 0.0000001) + $xi);
            if ($intersect) {
                $inside = !$inside;
            }
            $j = $i;
        }

        return $inside;
    }
}
