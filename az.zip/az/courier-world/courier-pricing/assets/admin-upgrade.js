(function($){
    'use strict';

    const upgradeState = {
        settings: JSON.parse(JSON.stringify((window.CC_CP_UPGRADE && CC_CP_UPGRADE.settings) || {})),
        courierMode: false,
        courierMarkers: {},
        courierSelection: null,
        courierPolyline: null,
        pickupMarker: null,
        dropoffMarker: null,
        courierTimer: null,
        dashboard: null,
    };

    function api(){ return window.CC_CP_PLANNER_API || null; }
    function ajax(action, payload){
        return $.post(CC_CP_UPGRADE.ajaxUrl, Object.assign({ action: action, nonce: CC_CP_UPGRADE.nonce }, payload || {}));
    }

    function waitForPlanner(){
        if (api() && api().getData && api().getAjaxMeta) {
            boot();
            return;
        }
        setTimeout(waitForPlanner, 150);
    }

    function boot(){
        injectUi();
        bindUi();
        renderControlCenter();
        refreshIntelligence();
        hydrateEntityExtras();
        document.addEventListener('cc_cp_planner_updated', hydrateEntityExtras);
        document.addEventListener('cc_cp_map_ready', function(){ if (upgradeState.courierMode) refreshCouriers(); });
    }

    function injectUi(){
        renameTabs();
        injectMapMode();
        injectPricingControlCenter();
        injectIntelligenceShell();
        injectCourierModal();
        $('.cc-cp-panel[data-panel="pricing"] .description').first().text(CC_CP_UPGRADE.strings.manualOverrideNote);
    }

    function renameTabs(){
        $('#cc-cp-tabs .nav-tab[data-tab="intelligence"]').text(CC_CP_UPGRADE.strings.logisticsIntelligence || 'Logistics Intelligence');
        $('.cc-cp-panel[data-panel="intelligence"] h2').first().text(CC_CP_UPGRADE.strings.logisticsIntelligence || 'Logistics Intelligence');
    }

    function injectMapMode(){
        if ($('#cc-cp-map-mode').length) return;
        const $modeLabel = $('#cc-cp-mode').closest('label');
        if (!$modeLabel.length) return;
        const html = '<label class="cc-cp-dynamic-control"><span>Map Mode</span><select id="cc-cp-map-mode"><option value="draw">Draw Mode</option><option value="courier">Courier Mode</option></select></label>';
        $modeLabel.before(html);
    }

    function injectPricingControlCenter(){
        const $pricingPanel = $('.cc-cp-panel[data-panel="pricing"] .cc-cp-card').first();
        if (!$pricingPanel.length || $('#cc-cp-control-center').length) return;
        $('<div id="cc-cp-control-center" class="cc-cp-control-center"></div>').prependTo($pricingPanel);
    }

    function injectIntelligenceShell(){
        const $intPanel = $('.cc-cp-panel[data-panel="intelligence"] .cc-cp-card').first();
        if (!$intPanel.length) return;
        const $legacy = $('#cc-cp-lane-intelligence');
        if ($legacy.length) { $legacy.hide().attr('aria-hidden', 'true'); }
        if (!$('#cc-cp-logistics-intelligence').length) {
            $('<div id="cc-cp-logistics-intelligence"></div>').appendTo($intPanel);
        }
    }

    function injectCourierModal(){
        if ($('#cc-cp-courier-modal').length) return;
        $('body').append(
            '<div class="cc-cp-modal" id="cc-cp-courier-modal" aria-hidden="true">' +
                '<div class="cc-cp-modal__backdrop" data-close="1"></div>' +
                '<div class="cc-cp-modal__dialog cc-cp-modal__dialog--courier">' +
                    '<div class="cc-cp-modal__header"><h2>Courier Mission</h2><button type="button" class="cc-cp-modal__close" data-close="1">×</button></div>' +
                    '<div class="cc-cp-modal__body" id="cc-cp-courier-modal-body"></div>' +
                '</div>' +
            '</div>'
        );
    }

    function bindUi(){
        $(document).on('change', '#cc-cp-map-mode', function(){
            upgradeState.courierMode = $(this).val() === 'courier';
            toggleCourierMode();
        });

        $(document).on('click', '#cc-cp-save-control-center', function(e){
            e.preventDefault();
            const payload = collectControlCenterPayload();
            ajax('cc_cp_save_control_center', { payload: JSON.stringify(payload) }).done(function(res){
                if (res && res.success && res.data && res.data.settings) {
                    upgradeState.settings = res.data.settings;
                    renderControlCenter();
                    refreshIntelligence();
                } else {
                    alert((res && res.data && res.data.message) || 'Could not save settings.');
                }
            });
        });

        $(document).on('click', '.cc-cp-knob-mode', function(e){
            e.preventDefault();
            const knob = $(this).data('knob');
            const mode = $(this).data('mode');
            ajax('cc_cp_set_knob_mode', { knob_key: knob, mode: mode }).done(function(res){
                if (res && res.success && res.data && res.data.dashboard) {
                    upgradeState.dashboard = res.data.dashboard;
                    renderIntelligence();
                } else {
                    alert((res && res.data && res.data.message) || 'Could not update knob mode.');
                }
            });
        });

        document.addEventListener('click', handleEntitySaveCapture, true);

$(document).on('click', '#cc-cp-courier-modal [data-close="1"]', function(){ closeCourierModal(); });

    $(document).on('input', '#cc-cp-zones-search, #cc-cp-blocks-search, #cc-cp-anchors-search', function(){
        window.requestAnimationFrame(function(){
            hydrateEntityExtras();
        });
    });

    const managerLists = document.querySelectorAll('#cc-cp-zones-list, #cc-cp-blocks-list');
    managerLists.forEach(function(node){
        if (!node) return;
        const observer = new MutationObserver(function(){
            hydrateEntityExtras();
        });
        observer.observe(node, { childList: true, subtree: false });
    });
    
    }

    function handleEntitySaveCapture(e){
        const target = e.target;
        if (!target || !target.classList || !target.classList.contains('cc-cp-entity-save')) return;
        const row = target.closest('.cc-cp-entity-row');
        if (!row) return;
        const entityType = row.getAttribute('data-entity_type');
        if (entityType !== 'zone' && entityType !== 'block') return;
        e.preventDefault();
        e.stopPropagation();
        if (e.stopImmediatePropagation) e.stopImmediatePropagation();

        const payload = {
            id: row.getAttribute('data-id'),
            entity_type: entityType,
            label: $(row).find('.cc-cp-entity-label').val(),
            color: $(row).find('.cc-cp-entity-color').val() || '#3b82f6',
            zone_id: $(row).find('.cc-cp-entity-zone').val() || '',
            block_id: $(row).find('.cc-cp-entity-block').val() || '',
            active: $(row).find('.cc-cp-entity-active').is(':checked') ? 1 : 0,
            zone_type: $(row).find('.cc-cp-entity-zone-type').val() || 'suburban',
            block_type: $(row).find('.cc-cp-entity-block-type').val() || 'standard'
        };
        ajax('cc_cp_update_entity', payload).done(function(res){
            if (res && res.success && res.data && res.data.plannerData) {
                api().refresh(res.data.plannerData);
                hydrateEntityExtras();
            } else {
                alert((res && res.data && res.data.message) || 'Could not save entity.');
            }
        });
    }

    function hydrateEntityExtras(){
        const planner = api().getData() || {};
        const zoneTypes = CC_CP_UPGRADE.zoneTypes || {};
        const blockTypes = CC_CP_UPGRADE.blockTypes || {};
        $('#cc-cp-zones-list .cc-cp-entity-row').each(function(){
            const $row = $(this); const id = String($row.data('id'));
            const entity = (planner.zones || []).find(z => String(z.id) === id) || {};
            if (!$row.find('.cc-cp-entity-zone-type').length) {
                const opts = optionsMarkup(zoneTypes, entity.zone_type || 'suburban');
                $('<label class="cc-cp-upgrade-extra"><span>Zone Type</span><select class="cc-cp-entity-zone-type">' + opts + '</select></label>').insertBefore($row.find('.cc-cp-entity-actions'));
            } else {
                $row.find('.cc-cp-entity-zone-type').val(entity.zone_type || 'suburban');
            }
        });
        $('#cc-cp-blocks-list .cc-cp-entity-row').each(function(){
            const $row = $(this); const id = String($row.data('id'));
            const entity = (planner.blocks || []).find(z => String(z.id) === id) || {};
            if (!$row.find('.cc-cp-entity-block-type').length) {
                const opts = optionsMarkup(blockTypes, entity.block_type || 'standard');
                $('<label class="cc-cp-upgrade-extra"><span>Block Type</span><select class="cc-cp-entity-block-type">' + opts + '</select></label>').insertBefore($row.find('.cc-cp-entity-actions'));
            } else {
                $row.find('.cc-cp-entity-block-type').val(entity.block_type || 'standard');
            }
        });
    }

    function optionsMarkup(map, selected){
        return Object.keys(map || {}).map(function(key){
            return '<option value="' + esc(key) + '" ' + (String(key) === String(selected) ? 'selected' : '') + '>' + esc(map[key]) + '</option>';
        }).join('');
    }

    function collectControlCenterPayload(){
        const pricing = {
            trip_bands: {
                extra_short: {
                    max_km: valNum('[name="cccp_band_extra_short_max_km"]'),
                    base_fee: valNum('[name="cccp_band_extra_short_base_fee"]'),
                    first_2_km_rate: valNum('[name="cccp_band_extra_short_first_2_km_rate"]'),
                    next_3_km_rate: valNum('[name="cccp_band_extra_short_next_3_km_rate"]'),
                    remaining_km_rate: valNum('[name="cccp_band_extra_short_remaining_km_rate"]'),
                    platform_spread: valNum('[name="cccp_band_extra_short_platform_spread"]')
                },
                short: {
                    max_km: valNum('[name="cccp_band_short_max_km"]'),
                    base_fee: valNum('[name="cccp_band_short_base_fee"]'),
                    first_2_km_rate: valNum('[name="cccp_band_short_first_2_km_rate"]'),
                    next_3_km_rate: valNum('[name="cccp_band_short_next_3_km_rate"]'),
                    remaining_km_rate: valNum('[name="cccp_band_short_remaining_km_rate"]'),
                    platform_spread: valNum('[name="cccp_band_short_platform_spread"]')
                },
                medium: {
                    max_km: valNum('[name="cccp_band_medium_max_km"]'),
                    base_fee: valNum('[name="cccp_band_medium_base_fee"]'),
                    first_2_km_rate: valNum('[name="cccp_band_medium_first_2_km_rate"]'),
                    next_3_km_rate: valNum('[name="cccp_band_medium_next_3_km_rate"]'),
                    remaining_km_rate: valNum('[name="cccp_band_medium_remaining_km_rate"]'),
                    platform_spread: valNum('[name="cccp_band_medium_platform_spread"]'),
                    haul_threshold_km: valNum('[name="cccp_band_medium_haul_threshold_km"]'),
                    haul_buffer: valNum('[name="cccp_band_medium_haul_buffer"]')
                },
                long: {
                    base_fee: valNum('[name="cccp_band_long_base_fee"]'),
                    first_2_km_rate: valNum('[name="cccp_band_long_first_2_km_rate"]'),
                    next_3_km_rate: valNum('[name="cccp_band_long_next_3_km_rate"]'),
                    remaining_km_rate: valNum('[name="cccp_band_long_remaining_km_rate"]'),
                    platform_spread: valNum('[name="cccp_band_long_platform_spread"]'),
                    haul_threshold_km: valNum('[name="cccp_band_long_haul_threshold_km"]'),
                    haul_buffer: valNum('[name="cccp_band_long_haul_buffer"]')
                }
            },
            minimum_fee: valNum('[name="cccp_minimum_fee"]'),
            zone_adjustments: {},
            block_modifiers: {}
        };
        Object.keys(CC_CP_UPGRADE.zoneTypes || {}).forEach(function(key){ pricing.zone_adjustments[key] = valNum('[name="zone_' + key + '"]'); });
        Object.keys(CC_CP_UPGRADE.blockTypes || {}).forEach(function(key){ pricing.block_modifiers[key] = valNum('[name="block_' + key + '"]'); });
        const intelligence = {
            confidence_threshold_pct: valNum('[name="cci_confidence_threshold_pct"]'),
            sample_threshold: valNum('[name="cci_sample_threshold"]'),
            adjustment_step: valNum('[name="cci_adjustment_step"]'),
            cooldown_hours: valNum('[name="cci_cooldown_hours"]'),
            cooldown_shipments: valNum('[name="cci_cooldown_shipments"]'),
            max_adjustment_limit: valNum('[name="cci_max_adjustment_limit"]'),
            acceptance_weight: parseFloat($('[name="cci_acceptance_weight"]').val() || $('[name="cci_acceptance_weight"]').attr('placeholder') || 0.5),
            duration_weight: parseFloat($('[name="cci_duration_weight"]').val() || $('[name="cci_duration_weight"]').attr('placeholder') || 0.3),
            acceptance_time_weight: parseFloat($('[name="cci_acceptance_time_weight"]').val() || $('[name="cci_acceptance_time_weight"]').attr('placeholder') || 0.2)
        };
        return { pricing: pricing, intelligence: intelligence };
    }

function renderControlCenter(){
        const settings = upgradeState.settings || {};
        const pricing = settings.pricing || {};
        const intel = settings.intelligence || {};
        const zoneTypes = CC_CP_UPGRADE.zoneTypes || {};
        const blockTypes = CC_CP_UPGRADE.blockTypes || {};
        const bands = pricing.trip_bands || {};
        const html = [
            '<div class="cc-cp-upgrade-grid">',
                '<section class="cc-cp-card cc-cp-upgrade-card"><h3>Global Pricing Settings</h3><p class="description">Trip-band pricing only. No legacy fields.</p>',
                    bandFieldV3('Extra Short Trip', 'extra_short', bands.extra_short || {}, {max_km:2, base_fee:200, first_2_km_rate:125, next_3_km_rate:120, remaining_km_rate:120}, true, false),
                    bandFieldV3('Short Trip', 'short', bands.short || {}, {max_km:5, base_fee:300, first_2_km_rate:125, next_3_km_rate:120, remaining_km_rate:115}, true, false),
                    bandFieldV3('Medium Trip', 'medium', bands.medium || {}, {max_km:12, base_fee:400, first_2_km_rate:120, next_3_km_rate:115, remaining_km_rate:110, haul_threshold_km:13, haul_buffer:300}, true, true),
                    bandFieldV3('Long Trip', 'long', bands.long || {}, {base_fee:500, first_2_km_rate:120, next_3_km_rate:115, remaining_km_rate:110, haul_threshold_km:17, haul_buffer:1100}, false, true),
                    field('Minimum Fee','cccp_minimum_fee', pricing.minimum_fee, 400, 'Automatic quotes will never fall below this value.'),
                '</section>',
                '<section class="cc-cp-card cc-cp-upgrade-card"><h3>Zone Type Adjustments</h3><p class="description">Broad environment modifiers applied from zone types.</p>',
                    Object.keys(zoneTypes).map(key => field(zoneTypes[key] + ' Adjustment', 'zone_' + key, ((pricing.zone_adjustments||{})[key]), ((CC_CP_UPGRADE.settings.pricing||{}).zone_adjustments||{})[key], zoneHelp(key))).join(''),
                '</section>',
                '<section class="cc-cp-card cc-cp-upgrade-card"><h3>Block Modifiers</h3><p class="description">Local access difficulty modifiers applied at pickup and dropoff.</p>',
                    Object.keys(blockTypes).map(key => field(blockTypes[key] + ' Modifier', 'block_' + key, ((pricing.block_modifiers||{})[key]), ((CC_CP_UPGRADE.settings.pricing||{}).block_modifiers||{})[key], blockHelp(key))).join(''),
                '</section>',
                '<section class="cc-cp-card cc-cp-upgrade-card"><h3>Auto Adjustment Settings</h3><p class="description">Controls how intelligence bars unlock and how auto-tuning behaves.</p>',
                    field('Confidence Threshold (%)','cci_confidence_threshold_pct', intel.confidence_threshold_pct, 80, 'Minimum confidence required before auto-adjustments activate.'),
                    field('Minimum Samples Required','cci_sample_threshold', intel.sample_threshold, 100, 'Number of deliveries required before a metric is trusted.'),
                    field('Adjustment Step','cci_adjustment_step', intel.adjustment_step, 50, 'Amount each pricing knob shifts per adjustment cycle.'),
                    field('Adjustment Cooldown (Hours)','cci_cooldown_hours', intel.cooldown_hours, 6, 'Minimum time between automatic adjustments.'),
                    field('Adjustment Cooldown (Shipments)','cci_cooldown_shipments', intel.cooldown_shipments, 50, 'Minimum shipment volume between adjustment cycles.'),
                    field('Max Adjustment Limit','cci_max_adjustment_limit', intel.max_adjustment_limit, 1000, 'Safety ceiling for auto-adjusted modifiers.'),
                    field('Acceptance Influence','cci_acceptance_weight', intel.acceptance_weight, 0.5, 'How strongly courier acceptance affects underpricing decisions.', '0.1'),
                    field('Duration Influence','cci_duration_weight', intel.duration_weight, 0.3, 'How strongly delivery delays affect tuning.', '0.1'),
                    field('Acceptance Time Influence','cci_acceptance_time_weight', intel.acceptance_time_weight, 0.2, 'How strongly slow acceptance affects tuning.', '0.1'),
                '</section>',
            '</div>',
            '<div class="cc-cp-upgrade-actions"><button type="button" class="button button-primary" id="cc-cp-save-control-center">Save Pricing & Intelligence Settings</button></div>'
        ].join('');
        $('#cc-cp-control-center').html(html);
    }

    function bandFieldV3(label, key, value, defaults, hasMaxKm, hasHaul){
        value = value || {}; defaults = defaults || {};
        let html = '<div class="cc-cp-band-box"><h4>' + esc(label) + '</h4>';
        if (hasMaxKm) html += field(label + ' Max KM','cccp_band_' + key + '_max_km', value.max_km, defaults.max_km, 'Maximum distance for this trip type.');
        html += field('Base','cccp_band_' + key + '_base_fee', value.base_fee, defaults.base_fee, 'Base fee for this trip type.');
        html += '<div class="cc-cp-rate-3grid">' +
            field('First 2 KM Rate','cccp_band_' + key + '_first_2_km_rate', value.first_2_km_rate, defaults.first_2_km_rate, 'Applied to the first 2 km.') +
            field('Next 3 KM Rate','cccp_band_' + key + '_next_3_km_rate', value.next_3_km_rate, defaults.next_3_km_rate, 'Applied to the next 3 km.') +
            field('Remaining KM Rate','cccp_band_' + key + '_remaining_km_rate', value.remaining_km_rate, defaults.remaining_km_rate, 'Applied to all remaining km after the first 5 km.') +
            '</div>' +
            '<div class="cc-cp-platform-row">' +
            field('Platform Spread','cccp_band_' + key + '_platform_spread', value.platform_spread, defaults.platform_spread, 'Platform fee for this trip type.') +
            '</div>';
        if (hasHaul) {
            html += field(label + ' Haul Threshold (KM)','cccp_band_' + key + '_haul_threshold_km', value.haul_threshold_km, defaults.haul_threshold_km, 'Distance after which this trip-type buffer is added.');
            html += field(label + ' Haul Buffer','cccp_band_' + key + '_haul_buffer', value.haul_buffer, defaults.haul_buffer, 'Replacement-only buffer for this trip type.');
        }
        html += '</div>';
        return html;
    }
function checkboxField(label, name, checked, help){
        return '<label class="cc-cp-upgrade-field cc-cp-upgrade-checkbox"><span>' + esc(label) + '</span><input type="checkbox" name="' + esc(name) + '" ' + (checked ? 'checked' : '') + '><small>' + esc(help || '') + '</small></label>';
    }
    function bandField(label, key, value, defaults){
        value = value || {}; defaults = defaults || {};
        return '<div class="cc-cp-band-box"><h4>' + esc(label) + '</h4>' +
            field('Max KM','cccp_band_' + key + '_max_km', value.max_km, defaults.max_km, 'Maximum distance for this band.') +
            field('Base Fee','cccp_band_' + key + '_base_fee', value.base_fee, defaults.base_fee, 'Base fee used for this band.') +
            field('Per KM Rate','cccp_band_' + key + '_per_km_rate', value.per_km_rate, defaults.per_km_rate, 'Per-km rate used for this band.') +
            '</div>';
    }
    function field(label, name, value, placeholder, help, step){
        return '<label class="cc-cp-upgrade-field"><span>' + esc(label) + '</span><input type="number" step="' + esc(step || '0.01') + '" name="' + esc(name) + '" value="' + escNumMaybe(value) + '" placeholder="' + esc(placeholder) + '"><small>' + esc(help || '') + '</small></label>';
    }
    function zoneHelp(key){
        const map = {
            dense_urban: 'Adds cost for dense, high-friction urban areas where delivery is slower and more difficult.',
            suburban: 'Baseline adjustment for regular housing areas with normal delivery conditions.',
            linear: 'Adds a small corridor adjustment for long roadside or strip-style settlements.',
            rural: 'Adds cost for lower-density rural areas where deliveries are more spread out.',
            remote: 'Adds a remote-area buffer for isolated zones that are harder and riskier to serve.'
        }; return map[key] || '';
    }
    function blockHelp(key){
        const map = {
            easy_roadside: 'Used for easy-access roadside blocks with quick pickup or dropoff.',
            standard: 'Used for normal blocks with typical access and delivery effort.',
            interior: 'Adds cost for deeper interior blocks that take more time to reach than roadside areas.',
            hard_access: 'Adds extra cost for hard-access blocks where pickup or dropoff is slower or more difficult.'
        }; return map[key] || '';
    }

    function refreshIntelligence(){
        ajax('cc_cp_get_logistics_intelligence').done(function(res){
            if (res && res.success && res.data && res.data.dashboard) {
                upgradeState.dashboard = res.data.dashboard;
                renderIntelligence();
            } else {
                $('#cc-cp-logistics-intelligence').html('<p class="description">Could not load logistics intelligence.</p>');
            }
        });
    }

    function renderIntelligence(){
        const dash = upgradeState.dashboard;
        if (!dash) return;
        const o = dash.overview || {};
        const distanceRows = (dash.distance_buckets || []).map(function(r){ return [r.label, r.samples, money(r.avg_price), (r.acceptance_rate || 0) + '%', (r.avg_duration_min || 0) + ' min']; });
        const problemRows = (dash.problem_routes || []).map(function(r){ return [r.label, r.samples, r.status, money(r.avg_price), (r.acceptance_rate||0) + '%']; });
        const shipmentRows = (dash.recent_shipments || []).map(function(r){ return [r.shipment_id || '—', r.seller_zone || '—', r.customer_zone || '—', (r.distance_km||0) + ' km', money(r.price_total||0), (r.duration_min||0) + ' min', r.status || '—', r.accepted ? 'Yes' : 'No']; });
        const html = [
            '<div class="cc-cp-intel-overview-grid ccp-intel-overview-with-reset">',
                '<div class="ccp-intel-reset-wrap"><button type="button" class="button button-secondary" id="cc-cp-reset-intelligence">Reset Data</button></div>',
                metricCard('Total Shipments', o.total_shipments || 0),
                metricCard('Avg Price', money(o.avg_price || 0)),
                metricCard('Avg Distance', (o.avg_distance_km || 0) + ' km'),
                metricCard('Avg Duration', (o.avg_duration_min || 0) + ' min'),
                metricCard('Acceptance Rate', (o.acceptance_rate || 0) + '%'),
                metricCard('Completion Rate', (o.completion_rate || 0) + '%'),
            '</div>',
            tableSection('Distance Performance', ['Band','Samples','Avg Price','Acceptance','Avg Duration'], distanceRows, 'distance', true),
            knobSection('Zone Type Performance', dash.zone_type_performance || []),
            knobSection('Block Performance', dash.block_performance || []),
            knobSection('Global Pricing Knobs', (dash.knobs && dash.knobs.global) || []),
            tableSection('Problem Routes', ['Route','Samples','Status','Avg Price','Acceptance'], problemRows, 'problems', true),
            tableSection('Recent Shipments', ['Shipment','Seller Zone','Customer Zone','Distance','Price','Duration','Status','Accepted'], shipmentRows, 'shipments', true)
        ].join('');
        $('#cc-cp-logistics-intelligence').html(html);
        const limits = upgradeState.intelLimits || {};
        $('#cc-cp-logistics-intelligence .cc-cp-intel-limit').each(function(){ const k=$(this).data('section'); if(limits[k]) $(this).val(limits[k]); });
    }

    function tableSection(title, headers, rows, key, allowLimit){
        const limit = allowLimit ? 4 : 0;
        const chosen = (upgradeState.intelLimits && upgradeState.intelLimits[key]) ? upgradeState.intelLimits[key] : limit;
        return '<div class="cc-cp-intel-section"><div class="cc-cp-intel-section-head"><h3>' + esc(title) + '</h3>' + (allowLimit ? sectionSelect(key) : '') + '</div>' + renderSimpleTable(headers, rows, chosen) + '</div>';
    }

    function sectionSelect(key){
        return '<label class="ccp-mini-select">Show <select class="cc-cp-intel-limit" data-section="' + esc(key) + '"><option value="4">Recent 4</option><option value="10">Recent 10</option><option value="all">Show All</option></select></label>';
    }

    function knobSection(title, rows){
        return '<div class="cc-cp-intel-section"><h3>' + esc(title) + '</h3>' + (rows && rows.length ? rows.map(knobRow).join('') : '<p class="description">No data yet.</p>') + '</div>';
    }

    function knobRow(row){
        const pct = Math.max(0, Math.min(100, Number(row.confidence_pct || 0)));
        const locked = pct < Number(((upgradeState.settings.intelligence||{}).confidence_threshold_pct || 80));
        const autoOn = row.mode === 'auto';
        return '<div class="cc-cp-knob-row">' +
            '<div class="cc-cp-knob-row__header"><strong>' + esc(row.label) + '</strong><span class="cc-cp-chip-pill">Value: ' + money(row.value || 0) + '</span></div>' +
            '<div class="cc-cp-knob-bar"><span style="width:' + pct + '%"></span></div>' +
            '<div class="cc-cp-knob-meta"><span>Confidence: ' + pct.toFixed(1) + '%</span><span>Samples: ' + esc(row.samples || 0) + '</span><span>Status: ' + esc(row.status || 'Awaiting data') + '</span></div>' +
            '<div class="cc-cp-knob-actions">' +
                '<button type="button" class="button cc-cp-knob-mode ' + (autoOn ? '' : 'button-primary') + '" data-knob="' + esc(row.knob_key) + '" data-mode="manual">Manual</button>' +
                '<button type="button" class="button cc-cp-knob-mode ' + (autoOn ? 'button-primary' : '') + '" data-knob="' + esc(row.knob_key) + '" data-mode="auto" ' + (locked ? 'disabled title="' + esc(CC_CP_UPGRADE.strings.notEnoughData) + '"' : '') + '>Auto</button>' +
                (autoOn ? '<span class="cc-cp-auto-state">' + esc(CC_CP_UPGRADE.strings.autoTuningActive) + '</span>' : '') +
            '</div>' +
        '</div>';
    }

    function metricCard(label, value){ return '<div class="cc-cp-intel-card ccp-metric-card"><div class="ccp-metric-card__label">' + esc(label) + '</div><div class="ccp-metric-card__value">' + esc(value) + '</div></div>'; }
    function renderSimpleTable(headers, rows, limit){
        if (!rows || !rows.length) return '<p class="description">No data yet.</p>';
        const shown = limit && limit !== 'all' ? rows.slice(0, Number(limit)) : rows;
        return '<div class="cc-cp-table-wrap"><table class="widefat striped cc-cp-table"><thead><tr>' + headers.map(h => '<th>' + esc(h) + '</th>').join('') + '</tr></thead><tbody>' + shown.map(r => '<tr>' + r.map(c => '<td>' + esc(c) + '</td>').join('') + '</tr>').join('') + '</tbody></table></div>';
    }


    $(document).on('change', '.cc-cp-intel-limit', function(){
        refreshIntelligence();
        const section = $(this).data('section');
        const value = $(this).val();
        upgradeState.intelLimits = upgradeState.intelLimits || {};
        upgradeState.intelLimits[section] = value;
    });

    $(document).on('click', '#cc-cp-reset-intelligence', function(){
        if (!window.confirm('Reset all saved logistics intelligence data? This will wipe recent shipments, problem routes, distance performance samples, and related analytics.')) return;
        ajax('cc_cp_reset_logistics_intelligence').done(function(res){
            if (res && res.success && res.data && res.data.dashboard) {
                upgradeState.dashboard = res.data.dashboard;
                renderIntelligence();
            }
        });
    });

    function toggleCourierMode(){
        const $mode = $('#cc-cp-mode');
        if (upgradeState.courierMode) {
            $mode.val('select').trigger('change').prop('disabled', true);
            $('#cc-cp-finish-shape,#cc-cp-clear-draft,#cc-cp-precision-toggle').prop('disabled', true);
            refreshCouriers();
            if (upgradeState.courierTimer) clearInterval(upgradeState.courierTimer);
            upgradeState.courierTimer = setInterval(refreshCouriers, 10000);
        } else {
            $mode.prop('disabled', false);
            $('#cc-cp-finish-shape,#cc-cp-clear-draft,#cc-cp-precision-toggle').prop('disabled', false);
            if (upgradeState.courierTimer) clearInterval(upgradeState.courierTimer);
            upgradeState.courierTimer = null;
            clearCourierOverlays();
        }
    }

    function refreshCouriers(){
        if (!upgradeState.courierMode) return;
        const map = api().getMap();
        if (!map || !(window.google && google.maps)) return;
        ajax('cc_cp_get_courier_mode_data').done(function(res){
            if (!(res && res.success && res.data && Array.isArray(res.data.couriers))) return;
            renderCouriers(res.data.couriers);
        });
    }

    function renderCouriers(couriers){
        const map = api().getMap();
        const seen = {};
        couriers.forEach(function(c){
            seen[c.courier_id] = true;
            const pos = c.coords;
            if (!pos) return;
            let marker = upgradeState.courierMarkers[c.courier_id];
            if (!marker) {
                marker = new google.maps.Marker({
                    map: map,
                    position: pos,
                    label: { text: vehicleEmoji(c.vehicle_type), color: '#ffffff', fontSize: '16px' },
                    icon: pinSvg('#1f6feb'),
                    title: c.name || 'Courier'
                });
                marker.addListener('click', function(){ focusCourier(marker.__courier); });
                upgradeState.courierMarkers[c.courier_id] = marker;
            } else {
                marker.setPosition(pos);
                marker.__courier = c;
                marker.setTitle(c.name || 'Courier');
                marker.setLabel({ text: vehicleEmoji(c.vehicle_type), color: '#ffffff', fontSize: '16px' });
            }
            marker.__courier = c;
        });
        Object.keys(upgradeState.courierMarkers).forEach(function(id){
            if (!seen[id]) {
                upgradeState.courierMarkers[id].setMap(null);
                delete upgradeState.courierMarkers[id];
            }
        });
        if (upgradeState.courierSelection) {
            const match = couriers.find(c => String(c.courier_id) === String(upgradeState.courierSelection.courier_id));
            if (match) focusCourier(match, true);
        }
    }

    function focusCourier(courier, silent){
        const map = api().getMap();
        if (!map || !courier) return;
        upgradeState.courierSelection = courier;
        clearRouteObjectsOnly();
        const points = [courier.coords, courier.mission && courier.mission.pickup && courier.mission.pickup.coords, courier.mission && courier.mission.dropoff && courier.mission.dropoff.coords].filter(Boolean);
        if (points.length >= 2) {
            upgradeState.courierPolyline = new google.maps.Polyline({
                map: map,
                path: points,
                geodesic: true,
                strokeColor: '#8b5cf6',
                strokeOpacity: 0.95,
                strokeWeight: 3
            });
        }
        if (courier.mission && courier.mission.pickup && courier.mission.pickup.coords) {
            upgradeState.pickupMarker = new google.maps.Marker({ map: map, position: courier.mission.pickup.coords, label: { text: '🏨', color: '#ffffff', fontSize: '16px' }, icon: pinSvg('#0ea5e9') });
        }
        if (courier.mission && courier.mission.dropoff && courier.mission.dropoff.coords) {
            upgradeState.dropoffMarker = new google.maps.Marker({ map: map, position: courier.mission.dropoff.coords, label: { text: '🏠', color: '#ffffff', fontSize: '16px' }, icon: pinSvg('#16a34a') });
        }
        const bounds = new google.maps.LatLngBounds();
        points.forEach(function(p){ bounds.extend(p); });
        if (!bounds.isEmpty()) map.fitBounds(bounds, 60);
        if (!silent) openCourierModal(courier);
    }

    function clearRouteObjectsOnly(){
        if (upgradeState.courierPolyline) { upgradeState.courierPolyline.setMap(null); upgradeState.courierPolyline = null; }
        if (upgradeState.pickupMarker) { upgradeState.pickupMarker.setMap(null); upgradeState.pickupMarker = null; }
        if (upgradeState.dropoffMarker) { upgradeState.dropoffMarker.setMap(null); upgradeState.dropoffMarker = null; }
    }
    function clearCourierOverlays(){
        clearRouteObjectsOnly();
        Object.keys(upgradeState.courierMarkers).forEach(function(id){ upgradeState.courierMarkers[id].setMap(null); delete upgradeState.courierMarkers[id]; });
        upgradeState.courierSelection = null;
        closeCourierModal();
    }

    function openCourierModal(c){
        const mission = c.mission || {};
        const body = [
            '<div class="cc-cp-courier-grid">',
                '<div><strong>Courier</strong><div>' + esc(c.name || '—') + '</div><div class="mono">' + esc(c.phone || '—') + '</div><div>' + esc(c.vehicle_type || 'vehicle') + '</div></div>',
                '<div><strong>Mission Payout</strong><div>' + money(mission.payout_gyd || 0) + '</div><div>Status: ' + esc(mission.status || '—') + '</div></div>',
                '<div class="cc-cp-courier-colspan"><strong>Items</strong><div>' + ((mission.items || []).length ? '<ul><li>' + (mission.items || []).map(esc).join('</li><li>') + '</li></ul>' : 'No item detail yet.') + '</div></div>',
                '<div><strong>Pickup</strong><div>' + esc((mission.pickup && mission.pickup.address) || '—') + '</div><div class="mono">' + esc((mission.pickup && mission.pickup.phone) || '—') + '</div></div>',
                '<div><strong>Dropoff</strong><div>' + esc((mission.dropoff && mission.dropoff.address) || '—') + '</div><div class="mono">' + esc((mission.dropoff && mission.dropoff.phone) || '—') + '</div></div>',
            '</div>',
            '<div class="cc-cp-call-actions">',
                phoneButton((mission.pickup && mission.pickup.phone) || '', '🏨 Call Seller'),
                phoneButton(c.phone || '', vehicleEmoji(c.vehicle_type) + ' Call Courier'),
                phoneButton((mission.dropoff && mission.dropoff.phone) || '', '🏠 Call Customer'),
            '</div>'
        ].join('');
        $('#cc-cp-courier-modal-body').html(body);
        $('#cc-cp-courier-modal').addClass('is-open').attr('aria-hidden', 'false');
    }
    function closeCourierModal(){ $('#cc-cp-courier-modal').removeClass('is-open').attr('aria-hidden', 'true'); }

    function phoneButton(number, label){
        const clean = String(number || '').replace(/[^0-9+]/g, '');
        if (!clean) return '<button type="button" class="button" disabled>' + esc(label) + '</button>';
        return '<a class="button button-primary" href="tel:' + esc(clean) + '">' + esc(label) + '</a>';
    }

    function valNum(selector){ const $el = $(selector); const raw = $el.val() || $el.attr('placeholder') || 0; return parseFloat(raw || 0); }
    function esc(v){ return String(v == null ? '' : v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;'); }
    function escNumMaybe(v){ return (v === null || v === undefined || v === '') ? '' : esc(Number(v)); }
    function money(v){ return Number(v || 0).toFixed(2); }
    function vehicleEmoji(type){ const t = String(type || '').toLowerCase(); if (t.indexOf('bike') !== -1) return '🚲'; if (t.indexOf('truck') !== -1 || t.indexOf('lorry') !== -1) return '🚚'; if (t.indexOf('van') !== -1) return '🚐'; return '🚗'; }
    function pinSvg(color){
        return { url: 'data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="34" height="46" viewBox="0 0 34 46"><path fill="' + color + '" d="M17 0C7.61 0 0 7.61 0 17c0 12.75 17 29 17 29s17-16.25 17-29C34 7.61 26.39 0 17 0z"/><circle cx="17" cy="17" r="9" fill="rgba(255,255,255,0.18)"/></svg>'), labelOrigin: new google.maps.Point(17,17) };
    }

    waitForPlanner();
})(jQuery);