(function($){
    'use strict';


    const state = {
        data: JSON.parse(JSON.stringify(CC_CP_DATA.plannerData || {})),
        map: null,
        draftPoints: [],
        draftMarkers: [],
        draftPolyline: null,
        draftPolygon: null,
        anchorMarkers: [],
        zonePolygons: [],
        blockPolygons: [],
        laneSelection: { origin: null, destination: null },
        selection: null,
        inspectorFeature: null,
        contextFeature: null,
        initialized: false,
        lastCenter: null,
        lastZoom: null,
        precisionMode: false,
        contextMenuOpenedAt: 0
    };

    const els = {};
    const CC_CP_ALLOWED_MAP_TYPES = ['roadmap', 'satellite', 'hybrid', 'terrain'];
    const CC_CP_DEFAULT_MAP_TYPE = 'satellite';

    function bootWhenReady() {
        cacheEls();
        ensureEnhancementUi();
        cacheEls();
        bindTabs();
        bindSidebar();
        bindModal();
        renderEverything();

        if (!CC_CP_DATA.hasGoogleMapsKey) {
            $('#cc-cp-map').html('<div class="cc-cp-map-error">' + escapeHtml(CC_CP_DATA.strings.mapKeyMissing) + '</div>');
            return;
        }

        if (window.google && google.maps) {
            init();
            return;
        }

        document.addEventListener('cc_cp_gmaps_ready', init, { once: true });
    }

    function init() {
        if (state.initialized) {
            resizeMap();
            return;
        }
        state.initialized = true;
        populateZoneSelect();
        initMap();
        renderEverything();
    }

    function cacheEls() {
        els.mode = $('#cc-cp-mode');
        els.label = $('#cc-cp-label');
        els.color = $('#cc-cp-color');
        els.zone = $('#cc-cp-zone-id');
        els.active = $('#cc-cp-active');
        els.finishShape = $('#cc-cp-finish-shape');
        els.clearDraft = $('#cc-cp-clear-draft');
        els.fullscreen = $('#cc-cp-fullscreen');
        els.help = $('#cc-cp-help-text');
        els.draft = $('#cc-cp-draft-points');
        els.selection = $('#cc-cp-selection');
        els.managerGrid = $('#cc-cp-manager-grid');
        els.zonesList = $('#cc-cp-zones-list');
        els.blocksList = $('#cc-cp-blocks-list');
        els.anchorsList = $('#cc-cp-anchors-list');
        els.zonesCount = $('#cc-cp-zones-count');
        els.blocksCount = $('#cc-cp-blocks-count');
        els.anchorsCount = $('#cc-cp-anchors-count');
        els.lanesTable = $('#cc-cp-lanes-table');
        els.intelligence = $('#cc-cp-lane-intelligence');
        els.modal = $('#cc-cp-lane-modal');
        els.modalTitle = $('#cc-cp-lane-title');
        els.modalManual = $('#cc-cp-lane-manual');
        els.modalSize = $('#cc-cp-lane-size');
        els.modalWeight = $('#cc-cp-lane-weight');
        els.modalBuffer = $('#cc-cp-lane-buffer');
        els.modalPlatform = $('#cc-cp-lane-platform');
        els.modalActive = $('#cc-cp-lane-active');
        els.modalNotes = $('#cc-cp-lane-notes');
        els.saveLane = $('#cc-cp-save-lane');
        els.wrap = $('.cc-cp-wrap');
        els.map = $('#cc-cp-map');
        els.mapType = $('#cc-cp-map-type');
        els.precisionToggle = $('#cc-cp-precision-toggle');
        els.zoneSearch = $('#cc-cp-zones-search');
        els.blockSearch = $('#cc-cp-blocks-search');
        els.anchorSearch = $('#cc-cp-anchors-search');
        els.precisionTip = $('#cc-cp-precision-tip');
        els.contextMenu = $('#cc-cp-context-menu');
        els.contextMenuTitle = $('#cc-cp-context-menu-title');
        els.contextMenuMeta = $('#cc-cp-context-menu-meta');
        els.contextDelete = $('#cc-cp-context-delete');
    }

    function ensureEnhancementUi() {
        const $fieldGrid = $('.cc-cp-field-grid').first();
        const $toolbar = $('.cc-cp-toolbar-actions').first();

        if ($fieldGrid.length && !$('#cc-cp-map-type').length) {
            const $modeLabel = $fieldGrid.find('#cc-cp-mode').closest('label');
            const $mapTypeLabel = $(
                '<label class="cc-cp-dynamic-control">' +
                    '<span>Map Layer</span>' +
                    '<select id="cc-cp-map-type">' +
                        '<option value="roadmap">Roadmap</option>' +
                        '<option value="satellite">Satellite</option>' +
                        '<option value="hybrid">Hybrid</option>' +
                        '<option value="terrain">Terrain</option>' +
                    '</select>' +
                '</label>'
            );

            if ($modeLabel.length) {
                $modeLabel.after($mapTypeLabel);
            } else {
                $fieldGrid.prepend($mapTypeLabel);
            }
        }

        if ($toolbar.length && !$('#cc-cp-precision-toggle').length) {
            const $precisionButton = $('<button type="button" class="button" id="cc-cp-precision-toggle" title="Double-click for fine tip mode. Single-click returns to map scroller.">Precision Tip: OFF</button>');
            const $fullscreen = $('#cc-cp-fullscreen');
            if ($fullscreen.length) {
                $fullscreen.before($precisionButton);
            } else {
                $toolbar.append($precisionButton);
            }
        }

        [
            { card: '.cc-cp-manager-card--zones', id: 'cc-cp-zones-search', placeholder: 'Filter zones by label…' },
            { card: '.cc-cp-manager-card--blocks', id: 'cc-cp-blocks-search', placeholder: 'Filter blocks by label…' },
            { card: '.cc-cp-manager-card--anchors', id: 'cc-cp-anchors-search', placeholder: 'Filter anchors by label…' }
        ].forEach(function(config){
            const $card = $(config.card);
            if (!$card.length || $('#' + config.id).length) return;
            const $search = $(
                '<div class="cc-cp-manager-search">' +
                    '<input type="search" id="' + config.id + '" placeholder="' + config.placeholder + '" autocomplete="off">' +
                '</div>'
            );
            const $header = $card.find('.cc-cp-manager-card__header').first();
            if ($header.length) {
                $header.after($search);
            } else {
                $card.prepend($search);
            }
        });

        if (!$('#cc-cp-precision-tip').length && $('#cc-cp-map').length) {
            $('#cc-cp-map').append('<div id="cc-cp-precision-tip" class="cc-cp-precision-tip" aria-hidden="true"></div>');
        }

        if (!$('#cc-cp-context-menu').length) {
            $('body').append(
                '<div id="cc-cp-context-menu" class="cc-cp-context-menu" aria-hidden="true">' +
                    '<div class="cc-cp-context-menu__title" id="cc-cp-context-menu-title">Item</div>' +
                    '<div class="cc-cp-context-menu__meta" id="cc-cp-context-menu-meta"></div>' +
                    '<div class="cc-cp-context-menu__actions">' +
                        '<button type="button" class="button cc-cp-context-menu__delete" id="cc-cp-context-delete">Delete</button>' +
                    '</div>' +
                '</div>'
            );
        }
    }

    function bindTabs() {
        $('#cc-cp-tabs').on('click', '.nav-tab', function(){
            const tab = $(this).data('tab');
            $('#cc-cp-tabs .nav-tab').removeClass('nav-tab-active');
            $(this).addClass('nav-tab-active');
            $('.cc-cp-panel').removeClass('is-active');
            $('.cc-cp-panel[data-panel="' + tab + '"]').addClass('is-active');
            setTimeout(resizeMap, 120);
        });
    }

    function bindSidebar() {
        els.mode.on('change', function(){
            clearDraft();
            state.laneSelection = { origin: null, destination: null };
            updateHelp();
            renderSelection();
            applyInteractionMode();
        });

        els.finishShape.on('click', function(){
            const mode = getMode();
            if (mode !== 'zone' && mode !== 'block') return;
            saveDraftShape(mode);
        });

        els.clearDraft.on('click', clearDraft);

        els.fullscreen.on('click', function(){
            els.wrap.toggleClass('cc-cp-fullscreen-mode');
            $('body').toggleClass('cc-cp-body-lock', els.wrap.hasClass('cc-cp-fullscreen-mode'));
            setTimeout(resizeMap, 150);
        });

        els.mapType.on('change', function(){
            applyMapType($(this).val(), true);
        });

        els.precisionToggle.on('click', function(e){
            e.preventDefault();
            setPrecisionMode(false);
        });

        els.precisionToggle.on('dblclick', function(e){
            e.preventDefault();
            setPrecisionMode(true);
        });

        els.zoneSearch.on('input', renderEntityList);
        els.blockSearch.on('input', renderEntityList);
        els.anchorSearch.on('input', renderEntityList);

        $(document).on('mousedown.ccCpContextMenu touchstart.ccCpContextMenu', function(e){
            if (!els.contextMenu || !els.contextMenu.length || !els.contextMenu.hasClass('is-open')) return;
            if ($(e.target).closest('#cc-cp-context-menu').length) return;
            if (Date.now() - (state.contextMenuOpenedAt || 0) < 120) return;
            hideContextMenu();
        });

        $(document).on('keydown.ccCpContextMenu', function(e){
            if (e.key === 'Escape') {
                hideContextMenu();
            }
        });

        els.map.on('contextmenu', function(e){
            if ($(e.target).closest('#cc-cp-context-menu').length) return;
            e.preventDefault();
        });

        if (els.contextDelete && els.contextDelete.length) {
            els.contextDelete.on('click', function(e){
                e.preventDefault();
                e.stopPropagation();

                if (!state.contextFeature || !state.contextFeature.id || !state.contextFeature.featureType) {
                    hideContextMenu();
                    return;
                }

                const contextId = state.contextFeature.id;
                const entityType = normalizeEntityType(state.contextFeature.featureType);

                if (!entityType || !contextId) {
                    hideContextMenu();
                    return;
                }

                hideContextMenu();
                deleteEntity({
                    id: contextId,
                    entity_type: entityType
                });
            });
        }

        els.managerGrid.on('click', '.cc-cp-entity-save', function(){
            const $row = $(this).closest('.cc-cp-entity-row');
            updateEntity({ id: $row.data('id'), entity_type: $row.data('entity_type') });
        });

        els.managerGrid.on('click', '.cc-cp-entity-delete', function(){
            const $row = $(this).closest('.cc-cp-entity-row');
            deleteEntity({ id: $row.data('id'), entity_type: $row.data('entity_type') });
        });

        els.lanesTable.on('click', '.cc-cp-lane-save-row', function(){
            const $row = $(this).closest('tr');
            updateLane({ id: $row.data('id') });
        });
    }

    function bindModal() {
        els.modal.on('click', '[data-close="1"]', closeLaneModal);
        els.saveLane.on('click', saveLaneFromModal);
    }

    function getMode() {
        return els.mode.val() || 'select';
    }

    function updateHelp() {
        const textMap = {
            select: 'Click a saved zone or block to inspect it.',
            zone: state.precisionMode ? 'Precision Tip is ON. Double-clicked mode gives you the fine tip. Single-click the Precision button to go back to map scroller.' : 'Click the map to add zone points, then use Finish Shape. Double-click Precision Tip for finer placement.',
            block: state.precisionMode ? 'Precision Tip is ON. Double-clicked mode gives you the fine tip. Single-click the Precision button to go back to map scroller.' : 'Click the map to add block points, then use Finish Shape. Double-click Precision Tip for finer placement.',
            anchor: 'Click the map once to place an anchor pin and save it.',
            lane: 'Click one block for origin, then another block for destination. The pricing modal will open.'
        };
        els.help.text(textMap[getMode()] || '');
    }

    function normalizeMapType(type) {
        const normalized = String(type || '').toLowerCase();
        return CC_CP_ALLOWED_MAP_TYPES.indexOf(normalized) !== -1 ? normalized : CC_CP_DEFAULT_MAP_TYPE;
    }

    function getStoredMapType() {
        try {
            return normalizeMapType(window.localStorage.getItem('cc_cp_admin_map_type') || CC_CP_DEFAULT_MAP_TYPE);
        } catch (err) {
            return CC_CP_DEFAULT_MAP_TYPE;
        }
    }

    function persistMapType(type) {
        try {
            window.localStorage.setItem('cc_cp_admin_map_type', normalizeMapType(type));
        } catch (err) {}
    }

    function applyMapType(type, persistChoice) {
        const nextType = normalizeMapType(type);

        if (persistChoice !== false) {
            persistMapType(nextType);
        }

        if (els.mapType.length) {
            els.mapType.val(nextType);
        }

        if (!state.map || !(window.google && google.maps)) {
            return;
        }

        if (state.map.getMapTypeId() !== nextType) {
            state.map.setMapTypeId(nextType);
        }

        state.map.setOptions({
            styles: nextType === 'roadmap' ? (CC_CP_DATA.googleMapStyles || []) : null
        });
    }

    function updatePrecisionToggle() {
        if (!els.precisionToggle.length) return;
        els.precisionToggle.toggleClass('is-active', !!state.precisionMode);
        els.precisionToggle.text(state.precisionMode ? 'Precision Tip: ON (click = map scroller)' : 'Precision Tip: OFF (double-click = fine tip)');
    }

    function hidePrecisionTip() {
        if (els.precisionTip && els.precisionTip.length) {
            els.precisionTip.removeClass('is-visible').css({ left: '', top: '' }).text('');
        }
    }

    function setPrecisionMode(enabled) {
        state.precisionMode = !!enabled;
        updatePrecisionToggle();
        applyInteractionMode();
        updateHelp();
        if (!state.precisionMode) {
            hidePrecisionTip();
        }
    }

    function applyInteractionMode() {
        const mode = getMode();
        const drawingMode = mode === 'zone' || mode === 'block';

        if (!drawingMode && state.precisionMode) {
            state.precisionMode = false;
        }

        const precisionOn = drawingMode && state.precisionMode;

        updatePrecisionToggle();

        if (!state.map || !(window.google && google.maps)) {
            return;
        }

        els.map.toggleClass('cc-cp-map--draw', drawingMode);
        els.map.toggleClass('cc-cp-map--precision', precisionOn);

        state.map.setOptions({
            draggable: !precisionOn,
            draggableCursor: drawingMode ? 'crosshair' : null,
            draggingCursor: drawingMode ? 'crosshair' : null,
            disableDoubleClickZoom: precisionOn,
            gestureHandling: precisionOn ? 'greedy' : 'greedy'
        });
    }

    function updatePrecisionTip(e) {
        const mode = getMode();
        const drawingMode = mode === 'zone' || mode === 'block';
        if (!state.precisionMode || !drawingMode || !els.precisionTip.length || !e || !e.latLng) {
            hidePrecisionTip();
            return;
        }

        const rect = els.map[0].getBoundingClientRect();
        const clientX = e.domEvent && typeof e.domEvent.clientX === 'number' ? e.domEvent.clientX : rect.left + 16;
        const clientY = e.domEvent && typeof e.domEvent.clientY === 'number' ? e.domEvent.clientY : rect.top + 16;
        const left = Math.max(10, Math.min(rect.width - 180, clientX - rect.left + 16));
        const top = Math.max(10, Math.min(rect.height - 44, clientY - rect.top + 16));
        const text = 'Fine tip · ' + Number(e.latLng.lat()).toFixed(6) + ', ' + Number(e.latLng.lng()).toFixed(6) + ' · z' + state.map.getZoom();

        els.precisionTip
            .text(text)
            .css({ left: left + 'px', top: top + 'px' })
            .addClass('is-visible');
    }

    function initMap() {
        const center = {
            lat: Number(CC_CP_DATA.mapCenter.lat),
            lng: Number(CC_CP_DATA.mapCenter.lng)
        };
        const initialMapType = getStoredMapType();

        state.map = new google.maps.Map(document.getElementById('cc-cp-map'), {
            center: center,
            zoom: Number(CC_CP_DATA.mapZoom || 13),
            styles: initialMapType === 'roadmap' ? (CC_CP_DATA.googleMapStyles || []) : null,
            disableDefaultUI: false,
            mapTypeControl: true,
            mapTypeControlOptions: {
                mapTypeIds: CC_CP_ALLOWED_MAP_TYPES,
                style: google.maps.MapTypeControlStyle.DROPDOWN_MENU,
                position: google.maps.ControlPosition.TOP_RIGHT
            },
            mapTypeId: initialMapType,
            streetViewControl: false,
            fullscreenControl: false,
            clickableIcons: false,
            gestureHandling: 'greedy'
        });

        if (els.mapType.length) {
            els.mapType.val(initialMapType);
        }

        state.lastCenter = center;
        state.lastZoom = Number(CC_CP_DATA.mapZoom || 13);

        state.map.addListener('click', function(e){
            if (e && e.latLng) onMapClick(e.latLng);
        });

        state.map.addListener('mousemove', function(e){
            updatePrecisionTip(e);
        });

        state.map.addListener('mouseout', function(){
            hidePrecisionTip();
        });

        state.map.addListener('dragstart', function(){
            hidePrecisionTip();
        });

        state.map.addListener('maptypeid_changed', function(){
            const currentType = normalizeMapType(state.map.getMapTypeId());
            if (els.mapType.length) {
                els.mapType.val(currentType);
            }
            persistMapType(currentType);
            state.map.setOptions({
                styles: currentType === 'roadmap' ? (CC_CP_DATA.googleMapStyles || []) : null
            });
        });

        window.CC_CP_PLANNER_API = {
            getMap: function(){ return state.map; },
            getData: function(){ return state.data; },
            refresh: function(plannerData){ if (plannerData) { state.data = plannerData; } renderEverything(); redrawAllFeatures(); document.dispatchEvent(new CustomEvent('cc_cp_planner_updated', { detail: state.data })); },
            getAjaxMeta: function(){ return { ajaxUrl: CC_CP_DATA.ajaxUrl, nonce: CC_CP_DATA.nonce }; }
        };
        document.dispatchEvent(new CustomEvent('cc_cp_map_ready'));

        state.map.addListener('idle', function(){
            const c = state.map.getCenter();
            state.lastCenter = { lat: c.lat(), lng: c.lng() };
            state.lastZoom = state.map.getZoom();
        });

        els.map.find('.cc-cp-map-loading').remove();
        applyInteractionMode();
        redrawAllFeatures();
    }

    function onMapClick(latLng) {
        hideContextMenu();
        const mode = getMode();

        if (mode === 'anchor') {
            saveAnchorAt(latLng);
            return;
        }

        if (mode === 'zone' || mode === 'block') {
            state.draftPoints.push({
                lat: Number(latLng.lat().toFixed(6)),
                lng: Number(latLng.lng().toFixed(6))
            });
            drawDraftMarkers();
            updateDraftLog();
            redrawDraft();
        }
    }

    function saveAnchorAt(latLng) {
        if (!els.label.val()) {
            alert(CC_CP_DATA.strings.labelNeeded);
            return;
        }

        if (!window.confirm(CC_CP_DATA.strings.saveAnchor)) return;

        ajaxPost('cc_cp_save_anchor', {
            label: els.label.val(),
            color: els.color.val(),
            zone_id: els.zone.val(),
            active: els.active.is(':checked') ? 1 : 0,
            lat: latLng.lat(),
            lng: latLng.lng(),
            radius_m: 150
        });
    }

function saveDraftShape(type) {
    if (!els.label.val()) {
        alert(CC_CP_DATA.strings.labelNeeded);
        return;
    }

    if (state.draftPoints.length < 3) {
        alert(CC_CP_DATA.strings.shapeNeeded);
        return;
    }

    let resolvedZoneId = '';

    if (type === 'block') {
        const zones = (state.data && state.data.zones) ? state.data.zones : [];
        const rawVal = (els.zone.val() || '').toString().trim();
        const selectedText = $.trim(els.zone.find('option:selected').text() || '');

        if (rawVal && rawVal !== 'None / top-level') {
            resolvedZoneId = rawVal;
        }

        if (!resolvedZoneId && selectedText && selectedText !== 'None / top-level') {
            const match = zones.find(function(zone){
                return $.trim(zone.label) === selectedText;
            });
            if (match && match.id) {
                resolvedZoneId = match.id;
            }
        }

        if (!resolvedZoneId && zones.length > 0 && zones[0].id) {
            resolvedZoneId = zones[0].id;
        }

        if (!resolvedZoneId && CC_CP_DATA.plannerData && CC_CP_DATA.plannerData.zones && CC_CP_DATA.plannerData.zones.length > 0) {
            resolvedZoneId = CC_CP_DATA.plannerData.zones[0].id || '';
        }

        if (!resolvedZoneId) {
            alert('No saved zone exists yet. Save a zone first, then save the block.');
            return;
        }

        els.zone.val(resolvedZoneId);
    }

    const okMessage = type === 'zone' ? CC_CP_DATA.strings.saveZone : CC_CP_DATA.strings.saveBlock;
    if (!window.confirm(okMessage)) return;

    const anchor = computeCenter(state.draftPoints);

    ajaxPost(
        type === 'zone' ? 'cc_cp_save_zone' : 'cc_cp_save_block',
        {
            label: els.label.val(),
            color: els.color.val(),
            zone_id: resolvedZoneId,
            active: els.active.is(':checked') ? 1 : 0,
            polygon: JSON.stringify(state.draftPoints),
            anchor: JSON.stringify(anchor)
        },
        function(){
            clearDraft();
        }
    );
}

    function handleLaneFeatureClick(blockId) {
        const block = findById(state.data.blocks, blockId);
        if (!block) return;

        if (!state.laneSelection.origin) {
            state.laneSelection.origin = block;
        } else if (!state.laneSelection.destination) {
            state.laneSelection.destination = block;
            openLaneModal();
        } else {
            state.laneSelection = { origin: block, destination: null };
        }

        renderSelection();
    }

    function openLaneModal() {
        if (!state.laneSelection.origin || !state.laneSelection.destination) {
            alert(CC_CP_DATA.strings.laneNeedTwo);
            return;
        }

        els.modalTitle.text(state.laneSelection.origin.label + ' → ' + state.laneSelection.destination.label);
        els.modal.addClass('is-open').attr('aria-hidden', 'false');
    }

    function closeLaneModal() {
        els.modal.removeClass('is-open').attr('aria-hidden', 'true');
        els.modal.find('input[type="number"]').val('0');
        els.modalNotes.val('');
        els.modalActive.prop('checked', true);
    }

    function saveLaneFromModal() {
        if (!state.laneSelection.origin || !state.laneSelection.destination) return;

        ajaxPost('cc_cp_save_lane', {
            label: state.laneSelection.origin.label + ' → ' + state.laneSelection.destination.label,
            origin_block_id: state.laneSelection.origin.id,
            destination_block_id: state.laneSelection.destination.id,
            manual_price: els.modalManual.val(),
            size_modifier: els.modalSize.val(),
            weight_modifier: els.modalWeight.val(),
            buffer_cost: els.modalBuffer.val(),
            platform_spread: els.modalPlatform.val(),
            notes: els.modalNotes.val(),
            active: els.modalActive.is(':checked') ? 1 : 0
        }, function(){
            closeLaneModal();
            state.laneSelection = { origin: null, destination: null };
            renderSelection();
        });
    }

    function selectFeature(properties) {
        hideContextMenu();
        state.selection = properties || null;
        renderSelection();
    }

    function inspectFeature(properties) {
        state.inspectorFeature = properties || null;
        renderSelection();
    }

    function stopContextEvent(evt) {
        if (!evt) return;
        if (typeof evt.stop === 'function') {
            evt.stop();
        }
        if (evt.domEvent) {
            if (typeof evt.domEvent.preventDefault === 'function') evt.domEvent.preventDefault();
            if (typeof evt.domEvent.stopPropagation === 'function') evt.domEvent.stopPropagation();
        }
    }

    function normalizeEntityType(featureType) {
        const normalized = String(featureType || '').toLowerCase();
        if (normalized === 'zone' || normalized === 'block' || normalized === 'anchor') {
            return normalized;
        }
        return '';
    }


    function getEntityStore(featureType) {
        const normalized = normalizeEntityType(featureType);
        if (normalized === 'zone') return state.data.zones || [];
        if (normalized === 'block') return state.data.blocks || [];
        if (normalized === 'anchor') return state.data.anchors || [];
        return [];
    }

    function toFeaturePayload(entity, featureType) {
        if (!entity) return null;
        return {
            id: entity.id,
            label: entity.label,
            featureType: normalizeEntityType(featureType),
            active: entity.active ? '1' : '0'
        };
    }

    function eventPoint(evt) {
        if (!evt || !evt.latLng) return null;
        return {
            lat: Number(evt.latLng.lat()),
            lng: Number(evt.latLng.lng())
        };
    }

    function pointInPolygon(point, polygon) {
        if (!point || !polygon || polygon.length < 3) return false;
        let inside = false;
        const x = Number(point.lng);
        const y = Number(point.lat);

        for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
            const xi = Number(polygon[i].lng);
            const yi = Number(polygon[i].lat);
            const xj = Number(polygon[j].lng);
            const yj = Number(polygon[j].lat);

            const intersect = ((yi > y) !== (yj > y)) &&
                (x < ((xj - xi) * (y - yi)) / ((yj - yi) || 1e-12) + xi);

            if (intersect) inside = !inside;
        }

        return inside;
    }

    function polygonAreaScore(polygon) {
        if (!polygon || polygon.length < 3) return Number.MAX_SAFE_INTEGER;
        let area = 0;
        for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
            area += (Number(polygon[j].lng) + Number(polygon[i].lng)) * (Number(polygon[j].lat) - Number(polygon[i].lat));
        }
        return Math.abs(area);
    }

    function distanceMeters(a, b) {
        if (!a || !b) return Number.MAX_SAFE_INTEGER;
        const toRad = function(v){ return v * Math.PI / 180; };
        const R = 6371000;
        const dLat = toRad(Number(b.lat) - Number(a.lat));
        const dLng = toRad(Number(b.lng) - Number(a.lng));
        const lat1 = toRad(Number(a.lat));
        const lat2 = toRad(Number(b.lat));
        const sinLat = Math.sin(dLat / 2);
        const sinLng = Math.sin(dLng / 2);
        const q = sinLat * sinLat + Math.cos(lat1) * Math.cos(lat2) * sinLng * sinLng;
        return 2 * R * Math.atan2(Math.sqrt(q), Math.sqrt(1 - q));
    }

    function resolveFeatureAtEvent(feature, evt) {
        const normalized = normalizeEntityType(feature && feature.featureType);
        if (!normalized) return feature;

        const entities = getEntityStore(normalized);
        if (!entities.length) return feature;

        const pt = eventPoint(evt);
        if (!pt) return feature;

        if (normalized === 'anchor') {
            let bestAnchor = null;
            let bestDistance = Number.MAX_SAFE_INTEGER;
            entities.forEach(function(anchor){
                const d = distanceMeters(pt, { lat: Number(anchor.lat), lng: Number(anchor.lng) });
                if (d < bestDistance) {
                    bestDistance = d;
                    bestAnchor = anchor;
                }
            });
            if (bestAnchor && bestDistance <= 60) {
                return toFeaturePayload(bestAnchor, normalized);
            }
            return feature;
        }

        const containing = entities.filter(function(entity){
            return pointInPolygon(pt, entity.polygon || []);
        });

        if (!containing.length) {
            return feature;
        }

        containing.sort(function(a, b){
            const aArea = polygonAreaScore(a.polygon || []);
            const bArea = polygonAreaScore(b.polygon || []);
            if (aArea !== bArea) return aArea - bArea;
            if (feature && String(a.id) === String(feature.id)) return -1;
            if (feature && String(b.id) === String(feature.id)) return 1;
            return String(a.label || '').localeCompare(String(b.label || ''));
        });

        return toFeaturePayload(containing[0], normalized) || feature;
    }

    function hideContextMenu() {
        state.contextFeature = null;
        if (!els.contextMenu || !els.contextMenu.length) return;
        els.contextMenu.removeClass('is-open').attr('aria-hidden', 'true').css({ left: '', top: '', display: '' });
    }

    function showContextMenu(feature, evt) {
        stopContextEvent(evt);
        inspectFeature(feature);
        state.contextFeature = feature || null;

        if (!els.contextMenu || !els.contextMenu.length) return;

        if (!els.contextMenu.parent().is('body')) {
            $('body').append(els.contextMenu.detach());
        }

        const domEvt = evt && evt.domEvent ? evt.domEvent : evt;
        const viewportWidth = window.innerWidth || document.documentElement.clientWidth || 1280;
        const viewportHeight = window.innerHeight || document.documentElement.clientHeight || 800;
        const clientX = domEvt && typeof domEvt.clientX === 'number' ? domEvt.clientX : 24;
        const clientY = domEvt && typeof domEvt.clientY === 'number' ? domEvt.clientY : 24;
        const menuWidth = 210;
        const menuHeight = 132;
        const left = Math.max(10, Math.min(viewportWidth - menuWidth - 10, clientX + 10));
        const top = Math.max(10, Math.min(viewportHeight - menuHeight - 10, clientY + 10));
        const typeLabel = normalizeEntityType(feature && feature.featureType) || 'item';

        if (els.contextMenuTitle && els.contextMenuTitle.length) {
            els.contextMenuTitle.text(feature && feature.label ? feature.label : 'Unnamed');
        }
        if (els.contextMenuMeta && els.contextMenuMeta.length) {
            els.contextMenuMeta.text(typeLabel.charAt(0).toUpperCase() + typeLabel.slice(1));
        }
        if (els.contextDelete && els.contextDelete.length) {
            els.contextDelete.text('Delete ' + typeLabel);
        }

        state.contextMenuOpenedAt = Date.now();

        els.contextMenu
            .css({ left: left + 'px', top: top + 'px', display: 'block' })
            .addClass('is-open')
            .attr('aria-hidden', 'false');
    }

    function renderSelection() {
        let html = '';

        if (state.inspectorFeature) {
            html += '<div class="cc-cp-chip cc-cp-chip--inspector"><strong>Inspector:</strong> ' +
                escapeHtml(state.inspectorFeature.label || '') +
                ' <em>(' + escapeHtml(state.inspectorFeature.featureType || '') + ')</em></div>';
        }

        if (state.selection) {
            html += '<div class="cc-cp-chip"><strong>Selected:</strong> ' +
                escapeHtml(state.selection.label || '') +
                ' <em>(' + escapeHtml(state.selection.featureType || '') + ')</em></div>';
        }

        if (state.laneSelection.origin || state.laneSelection.destination) {
            html += '<div class="cc-cp-chip"><strong>Lane:</strong> ' +
                escapeHtml((state.laneSelection.origin && state.laneSelection.origin.label) || 'Origin') +
                ' → ' +
                escapeHtml((state.laneSelection.destination && state.laneSelection.destination.label) || 'Destination') +
                '</div>';
        }

        if (!html) {
            html = '<p class="description">' + escapeHtml(CC_CP_DATA.strings.nothingSelected || 'Nothing selected yet.') + '</p>';
        }

        els.selection.html(html);
    }

    function renderEverything() {
        updateHelp();
        updatePrecisionToggle();
        populateZoneSelect();
        updateDraftLog();
        renderEntityList();
        renderLanesTable();
        renderIntelligence();
    }

    function redrawAllFeatures() {
        if (!state.map || !(window.google && google.maps)) return;

        clearPolygons(state.zonePolygons);
        clearPolygons(state.blockPolygons);
        state.zonePolygons = [];
        state.blockPolygons = [];

        (state.data.zones || []).forEach(function(zone){
            if (!zone.polygon || zone.polygon.length < 3) return;

            const polygon = new google.maps.Polygon({
                paths: toLatLngLiteralPath(zone.polygon),
                strokeColor: zone.color || '#3b82f6',
                strokeOpacity: 0.95,
                strokeWeight: 2,
                fillColor: zone.color || '#3b82f6',
                fillOpacity: zone.active ? 0.20 : 0.08,
                map: state.map,
                clickable: true,
                zIndex: 2
            });

            polygon.addListener('click', function(evt){
                const mode = getMode();

                if (mode === 'zone' || mode === 'block') {
                    if (evt && evt.latLng) {
                        state.draftPoints.push({
                            lat: Number(evt.latLng.lat().toFixed(6)),
                            lng: Number(evt.latLng.lng().toFixed(6))
                        });
                        drawDraftMarkers();
                        updateDraftLog();
                        redrawDraft();
                    }
                    if (evt && typeof evt.stop === 'function') evt.stop();
                    return;
                }

                if (evt && typeof evt.stop === 'function') evt.stop();
                selectFeature(resolveFeatureAtEvent({
                    id: zone.id,
                    label: zone.label,
                    featureType: 'zone',
                    active: zone.active ? '1' : '0'
                }, evt));
            });

            polygon.addListener('rightclick', function(evt){
                showContextMenu(resolveFeatureAtEvent({
                    id: zone.id,
                    label: zone.label,
                    featureType: 'zone',
                    active: zone.active ? '1' : '0'
                }, evt), evt);
            });

            state.zonePolygons.push(polygon);
        });

        (state.data.blocks || []).forEach(function(block){
            if (!block.polygon || block.polygon.length < 3) return;

            const polygon = new google.maps.Polygon({
                paths: toLatLngLiteralPath(block.polygon),
                strokeColor: block.color || '#3b82f6',
                strokeOpacity: 1,
                strokeWeight: 2,
                fillColor: block.color || '#3b82f6',
                fillOpacity: block.active ? 0.28 : 0.10,
                map: state.map,
                clickable: true,
                zIndex: 4
            });

            polygon.addListener('click', function(evt){
                const mode = getMode();

                if (mode === 'zone' || mode === 'block') {
                    if (evt && evt.latLng) {
                        state.draftPoints.push({
                            lat: Number(evt.latLng.lat().toFixed(6)),
                            lng: Number(evt.latLng.lng().toFixed(6))
                        });
                        drawDraftMarkers();
                        updateDraftLog();
                        redrawDraft();
                    }
                    if (evt && typeof evt.stop === 'function') evt.stop();
                    return;
                }

                if (evt && typeof evt.stop === 'function') evt.stop();

                if (mode === 'lane') {
                    handleLaneFeatureClick(block.id);
                    return;
                }

                selectFeature(resolveFeatureAtEvent({
                    id: block.id,
                    label: block.label,
                    featureType: 'block',
                    active: block.active ? '1' : '0'
                }, evt));
            });

            polygon.addListener('rightclick', function(evt){
                showContextMenu(resolveFeatureAtEvent({
                    id: block.id,
                    label: block.label,
                    featureType: 'block',
                    active: block.active ? '1' : '0'
                }, evt), evt);
            });

            state.blockPolygons.push(polygon);
        });

        redrawAnchors();
        redrawDraft();
    }

    function redrawAnchors() {
        state.anchorMarkers.forEach(function(marker){
            marker.setMap(null);
        });
        state.anchorMarkers = [];

        (state.data.anchors || []).forEach(function(anchor){
            if (!anchor.active) return;

            const marker = new google.maps.Marker({
                position: {
                    lat: Number(anchor.lat),
                    lng: Number(anchor.lng)
                },
                map: state.map,
                title: anchor.label,
                icon: {
                    path: google.maps.SymbolPath.CIRCLE,
                    scale: 7,
                    fillColor: '#fcfcff',
                    fillOpacity: 1,
                    strokeColor: '#6fbaff',
                    strokeWeight: 2
                },
                zIndex: 6
            });

            marker.addListener('click', function(){
                selectFeature(resolveFeatureAtEvent({
                    id: anchor.id,
                    label: anchor.label,
                    featureType: 'anchor',
                    active: anchor.active ? '1' : '0'
                }, null));
            });

            marker.addListener('rightclick', function(evt){
                showContextMenu(resolveFeatureAtEvent({
                    id: anchor.id,
                    label: anchor.label,
                    featureType: 'anchor',
                    active: anchor.active ? '1' : '0'
                }, evt), evt);
            });

            state.anchorMarkers.push(marker);
        });
    }

    function redrawDraft() {
        if (!(window.google && google.maps) || !state.map) return;

        if (state.draftPolyline) {
            state.draftPolyline.setMap(null);
            state.draftPolyline = null;
        }

        if (state.draftPolygon) {
            state.draftPolygon.setMap(null);
            state.draftPolygon = null;
        }

        if (!state.draftPoints.length) return;

        const path = toLatLngLiteralPath(state.draftPoints);

        state.draftPolyline = new google.maps.Polyline({
            path: path,
            map: state.map,
            strokeColor: '#f59e0b',
            strokeOpacity: 1,
            strokeWeight: 3,
            zIndex: 8
        });

        if (path.length >= 3) {
            state.draftPolygon = new google.maps.Polygon({
                paths: path,
                map: state.map,
                strokeColor: '#f59e0b',
                strokeOpacity: 1,
                strokeWeight: 2,
                fillColor: '#f59e0b',
                fillOpacity: 0.16,
                zIndex: 7
            });
        }
    }

    function drawDraftMarkers() {
        state.draftMarkers.forEach(function(marker){
            marker.setMap(null);
        });
        state.draftMarkers = [];

        state.draftPoints.forEach(function(point, index){
            const marker = new google.maps.Marker({
                position: {
                    lat: Number(point.lat),
                    lng: Number(point.lng)
                },
                map: state.map,
                title: 'Point ' + (index + 1),
                label: {
                    text: String(index + 1),
                    color: '#120b03',
                    fontWeight: '700'
                },
                icon: {
                    path: google.maps.SymbolPath.CIRCLE,
                    scale: 10,
                    fillColor: '#f59e0b',
                    fillOpacity: 1,
                    strokeColor: '#ffffff',
                    strokeWeight: 2
                },
                zIndex: 9
            });
            state.draftMarkers.push(marker);
        });
    }

    function clearDraft() {
        state.draftPoints = [];

        state.draftMarkers.forEach(function(marker){
            marker.setMap(null);
        });
        state.draftMarkers = [];

        if (state.draftPolyline) {
            state.draftPolyline.setMap(null);
            state.draftPolyline = null;
        }

        if (state.draftPolygon) {
            state.draftPolygon.setMap(null);
            state.draftPolygon = null;
        }

        updateDraftLog();
    }

   function updateDraftLog() {
    window.CC_CP_LIVE_DRAFT_POINTS = Array.isArray(state.draftPoints)
        ? state.draftPoints.map(function(point){
            return {
                lat: Number(point.lat),
                lng: Number(point.lng)
            };
        })
        : [];

    if (!state.draftPoints.length) {
        els.draft.html('<p class="description">No draft points yet.</p>');
        return;
    }

    els.draft.html(state.draftPoints.map(function(point, index){
        return '<div class="cc-cp-draft-row">#' + (index + 1) + ' &nbsp; ' + point.lat + ', ' + point.lng + '</div>';
    }).join(''));
}

  function populateZoneSelect() {
    const current = els.zone.val() || '';
    const currentText = $.trim(els.zone.find('option:selected').text() || '');
    const zones = state.data.zones || [];

    const options = ['<option value="">None / top-level</option>'].concat(zones.map(function(zone){
        return '<option value="' + escapeHtml(zone.id) + '">' + escapeHtml(zone.label) + '</option>';
    }));

    els.zone.html(options.join(''));

    if (current && zones.some(function(zone){ return String(zone.id) === String(current); })) {
        els.zone.val(current);
        return;
    }

    if (currentText && currentText !== 'None / top-level') {
        const match = zones.find(function(zone){
            return $.trim(zone.label) === currentText;
        });
        if (match && match.id) {
            els.zone.val(match.id);
            return;
        }
    }

    if (zones.length === 1) {
        els.zone.val(zones[0].id);
    }
}

    function renderEntityList() {
        const zones = state.data.zones || [];
        const blocks = state.data.blocks || [];
        const anchors = state.data.anchors || [];
        const zoneQuery = (els.zoneSearch.val() || '').trim();
        const blockQuery = (els.blockSearch.val() || '').trim();
        const anchorQuery = (els.anchorSearch.val() || '').trim();
        const filteredZones = filterEntityItems(zones, zoneQuery);
        const filteredBlocks = filterEntityItems(blocks, blockQuery);
        const filteredAnchors = filterEntityItems(anchors, anchorQuery);

        els.zonesCount.text(formatManagerCount(filteredZones.length, zones.length, zoneQuery));
        els.blocksCount.text(formatManagerCount(filteredBlocks.length, blocks.length, blockQuery));
        els.anchorsCount.text(formatManagerCount(filteredAnchors.length, anchors.length, anchorQuery));

        els.zonesList.html(renderEntityRows('zone', filteredZones, zoneQuery));
        els.blocksList.html(renderEntityRows('block', filteredBlocks, blockQuery));
        els.anchorsList.html(renderEntityRows('anchor', filteredAnchors, anchorQuery));
    }

    function filterEntityItems(items, query) {
        const needle = String(query || '').trim().toLowerCase();
        if (!needle) return items;
        return (items || []).filter(function(item){
            return String(item.label || '').toLowerCase().indexOf(needle) !== -1;
        });
    }

    function formatManagerCount(filteredCount, totalCount, query) {
        return query ? (String(filteredCount) + '/' + String(totalCount)) : String(totalCount);
    }

    function renderEntityRows(type, items, query) {
        if (!items.length) {
            if (query) {
                return '<p class="description">No ' + escapeHtml(type) + ' labels matched "' + escapeHtml(query) + '".</p>';
            }
            return '<p class="description">' + escapeHtml(CC_CP_DATA.strings.noneYet || 'None yet.') + '</p>';
        }

        return items.map(function(item){
            let extra = '';

            if (type === 'block') {
                extra = '<label><span>Parent Zone</span><select class="cc-cp-entity-zone">' + zoneOptions(item.zone_id || '') + '</select></label>';
            } else if (type === 'anchor') {
                extra = '<label><span>Parent Zone</span><select class="cc-cp-entity-zone">' + zoneOptions(item.zone_id || '') + '</select></label>' +
                    '<label><span>Parent Block</span><select class="cc-cp-entity-block">' + blockOptions(item.block_id || '') + '</select></label>';
            }

            return '<div class="cc-cp-entity-row" data-id="' + escapeHtml(item.id) + '" data-entity_type="' + type + '">' +
                '<div class="cc-cp-entity-row__top"><strong>' + escapeHtml(item.label) + '</strong><span>' + escapeHtml(type) + '</span></div>' +
                '<label><span>Label</span><input type="text" class="cc-cp-entity-label" value="' + escapeHtml(item.label) + '"></label>' +
                (type !== 'anchor' ? '<label><span>Color</span><input type="color" class="cc-cp-entity-color" value="' + escapeHtml(item.color || '#3b82f6') + '"></label>' : '') +
                extra +
                '<label class="cc-cp-checkbox"><input type="checkbox" class="cc-cp-entity-active" ' + (item.active ? 'checked' : '') + '><span>Active</span></label>' +
                '<div class="cc-cp-entity-actions">' +
                    '<button type="button" class="button button-primary cc-cp-entity-save">Save</button>' +
                    '<button type="button" class="button cc-cp-entity-delete">Delete</button>' +
                '</div>' +
            '</div>';
        }).join('');
    }

    function zoneOptions(selectedId) {
        const zones = state.data.zones || [];
        const options = ['<option value="">None / top-level</option>'].concat(zones.map(function(zone){
            return '<option value="' + escapeHtml(zone.id) + '" ' + (String(zone.id) === String(selectedId) ? 'selected' : '') + '>' + escapeHtml(zone.label) + '</option>';
        }));
        return options.join('');
    }

    function blockOptions(selectedId) {
        const blocks = state.data.blocks || [];
        const options = ['<option value="">None</option>'].concat(blocks.map(function(block){
            return '<option value="' + escapeHtml(block.id) + '" ' + (String(block.id) === String(selectedId) ? 'selected' : '') + '>' + escapeHtml(block.label) + '</option>';
        }));
        return options.join('');
    }


    function renderLanesTable() {
        const lanes = state.data.lanes || [];

        if (!lanes.length) {
            els.lanesTable.html('<p class="description">No lane rows yet. Create them from the map in Lane mode.</p>');
            return;
        }

        const rows = lanes.map(function(lane){
            return '<tr data-id="' + escapeHtml(lane.id) + '">' +
                '<td><input type="text" class="cc-cp-lane-label" value="' + escapeHtml(lane.label) + '"></td>' +
                '<td>' + escapeHtml(blockLabel(lane.origin_block_id)) + '</td>' +
                '<td>' + escapeHtml(blockLabel(lane.destination_block_id)) + '</td>' +
                '<td><input type="number" step="0.01" class="cc-cp-lane-manual-price" value="' + escNum(lane.manual_price) + '"></td>' +
                '<td><input type="number" step="0.01" class="cc-cp-lane-size-modifier" value="' + escNum(lane.size_modifier) + '"></td>' +
                '<td><input type="number" step="0.01" class="cc-cp-lane-weight-modifier" value="' + escNum(lane.weight_modifier) + '"></td>' +
                '<td><input type="number" step="0.01" class="cc-cp-lane-buffer-cost" value="' + escNum(lane.buffer_cost) + '"></td>' +
                '<td><input type="number" step="0.01" class="cc-cp-lane-platform-spread" value="' + escNum(lane.platform_spread) + '"></td>' +
                '<td><strong>' + escNum(lane.total_shipping_fee) + '</strong></td>' +
                '<td><label class="cc-cp-checkbox"><input type="checkbox" class="cc-cp-lane-active" ' + (lane.active ? 'checked' : '') + '><span>Active</span></label></td>' +
                '<td><textarea class="cc-cp-lane-notes" rows="2">' + escapeHtml(lane.notes || '') + '</textarea></td>' +
                '<td><button type="button" class="button button-primary cc-cp-lane-save-row">Save</button></td>' +
            '</tr>';
        }).join('');

        els.lanesTable.html(
            '<div class="cc-cp-table-wrap"><table class="widefat striped cc-cp-table">' +
            '<thead><tr><th>Lane</th><th>Origin</th><th>Destination</th><th>Manual</th><th>Size</th><th>Weight</th><th>Buffer</th><th>Spread</th><th>Total</th><th>Active</th><th>Notes</th><th>Save</th></tr></thead>' +
            '<tbody>' + rows + '</tbody></table></div>'
        );
    }

    function renderIntelligence() {
        const lanes = state.data.lanes || [];

        if (!lanes.length) {
            els.intelligence.html('<p class="description">No lane data yet.</p>');
            return;
        }

        els.intelligence.html(lanes.map(function(lane){
            return '<div class="cc-cp-intel-card"><strong>' + escapeHtml(lane.label) + '</strong><div>Total fee: ' + escNum(lane.total_shipping_fee) + '</div><div>Status: ' + (lane.active ? 'Active' : 'Inactive') + '</div><div>Telemetry slot: ready for usage_count / ETA stats.</div></div>';
        }).join(''));
    }

    function updateEntity(data) {
        const $row = els.managerGrid.find('.cc-cp-entity-row[data-id="' + data.id + '"]');

        ajaxPost('cc_cp_update_entity', {
            id: data.id,
            entity_type: data.entity_type,
            label: $row.find('.cc-cp-entity-label').val(),
            color: $row.find('.cc-cp-entity-color').val() || '#3b82f6',
            zone_id: $row.find('.cc-cp-entity-zone').val() || '',
            block_id: $row.find('.cc-cp-entity-block').val() || '',
            active: $row.find('.cc-cp-entity-active').is(':checked') ? 1 : 0
        });
    }

    function deleteEntity(data) {
        if (!window.confirm(CC_CP_DATA.strings.deleteConfirm || 'Delete this item? This cannot be undone.')) {
            return;
        }

        ajaxPost('cc_cp_delete_entity', {
            id: data.id,
            entity_type: data.entity_type
        });
    }

    function updateLane(data) {
        const $row = els.lanesTable.find('tr[data-id="' + data.id + '"]');

        ajaxPost('cc_cp_update_lane', {
            id: data.id,
            label: $row.find('.cc-cp-lane-label').val(),
            manual_price: $row.find('.cc-cp-lane-manual-price').val(),
            size_modifier: $row.find('.cc-cp-lane-size-modifier').val(),
            weight_modifier: $row.find('.cc-cp-lane-weight-modifier').val(),
            buffer_cost: $row.find('.cc-cp-lane-buffer-cost').val(),
            platform_spread: $row.find('.cc-cp-lane-platform-spread').val(),
            notes: $row.find('.cc-cp-lane-notes').val(),
            active: $row.find('.cc-cp-lane-active').is(':checked') ? 1 : 0
        });
    }

    function ajaxPost(action, payload, onSuccess) {
        $.post(CC_CP_DATA.ajaxUrl, Object.assign({
            action: action,
            nonce: CC_CP_DATA.nonce
        }, payload || {})).done(function(response){
            if (!response || !response.success) {
                alert((response && response.data && response.data.message) ? response.data.message : CC_CP_DATA.strings.saveFailed);
                return;
            }

            if (response.data && response.data.plannerData) {
                state.data = response.data.plannerData;
                renderEverything();
                redrawAllFeatures();
                document.dispatchEvent(new CustomEvent('cc_cp_planner_updated', { detail: state.data }));
            }

            if (typeof onSuccess === 'function') {
                onSuccess(response);
            }
        }).fail(function(xhr){
            console.error(xhr);
            const message = xhr && xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message ? xhr.responseJSON.data.message : CC_CP_DATA.strings.saveFailed;
            alert(message);
        });
    }

    function resizeMap() {
        if (!state.map || !(window.google && google.maps)) return;

        const center = state.lastCenter || {
            lat: Number(CC_CP_DATA.mapCenter.lat),
            lng: Number(CC_CP_DATA.mapCenter.lng)
        };
        const zoom = state.lastZoom || Number(CC_CP_DATA.mapZoom || 13);

        google.maps.event.trigger(state.map, 'resize');
        state.map.setCenter(center);
        state.map.setZoom(zoom);
    }

    function clearPolygons(polygons) {
        (polygons || []).forEach(function(poly){
            poly.setMap(null);
        });
    }

    function toLatLngLiteralPath(points) {
        return (points || []).map(function(point){
            return { lat: Number(point.lat), lng: Number(point.lng) };
        });
    }

    function computeCenter(points) {
        let lat = 0;
        let lng = 0;

        points.forEach(function(point){
            lat += Number(point.lat);
            lng += Number(point.lng);
        });

        return {
            lat: Number((lat / points.length).toFixed(6)),
            lng: Number((lng / points.length).toFixed(6))
        };
    }

    function findById(items, id) {
        return (items || []).find(function(item){
            return String(item.id) === String(id);
        }) || null;
    }

    function blockLabel(id) {
        const block = findById(state.data.blocks, id);
        return block ? block.label : 'Unknown';
    }

    function escapeHtml(value) {
        return String(value == null ? '' : value)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    function escNum(value) {
        return escapeHtml(Number(value || 0).toFixed(2));
    }

    window.CC_CP_PLANNER_API = window.CC_CP_PLANNER_API || { getMap: function(){ return null; }, getData: function(){ return (CC_CP_DATA.plannerData || {}); }, refresh: function(){} };
    $(bootWhenReady);
})(jQuery);