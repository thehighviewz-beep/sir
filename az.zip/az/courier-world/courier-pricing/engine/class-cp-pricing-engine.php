<?php
if (!defined('ABSPATH')) { exit; }

final class CC_CP_Pricing_Engine {
    public static function calculate(array $args) {
        $sellerLat = isset($args['seller_lat']) ? (float) $args['seller_lat'] : 0;
        $sellerLng = isset($args['seller_lng']) ? (float) $args['seller_lng'] : 0;
        $customerLat = isset($args['customer_lat']) ? (float) $args['customer_lat'] : 0;
        $customerLng = isset($args['customer_lng']) ? (float) $args['customer_lng'] : 0;

        if (!$sellerLat || !$sellerLng || !$customerLat || !$customerLng) {
            return new WP_Error('cp_missing_coords', 'Seller/customer coordinates are required.');
        }

        $originBlock = CC_CP_Storage::resolve_point_to_block($sellerLat, $sellerLng);
        $destBlock   = CC_CP_Storage::resolve_point_to_block($customerLat, $customerLng);
        $originZone  = CC_CP_Storage::resolve_point_to_zone($sellerLat, $sellerLng, $originBlock);
        $destZone    = CC_CP_Storage::resolve_point_to_zone($customerLat, $customerLng, $destBlock);

        $context = array(
            'origin_block' => $originBlock,
            'destination_block' => $destBlock,
            'origin_zone' => $originZone,
            'destination_zone' => $destZone,
            'origin_block_type' => $originBlock['block_type'] ?? 'standard',
            'destination_block_type' => $destBlock['block_type'] ?? 'standard',
            'origin_zone_type' => $originZone['zone_type'] ?? 'suburban',
            'destination_zone_type' => $destZone['zone_type'] ?? 'suburban',
        );

        $lane = null;
        if ($originBlock && $destBlock) {
            $lane = CC_CP_Storage::find_lane($originBlock['id'], $destBlock['id']);
        }

        if ($lane) {
            $result = CC_CP_Pricing_Calculator::calculate_manual_lane($lane, $args);
            $result['origin_block'] = $originBlock;
            $result['destination_block'] = $destBlock;
            $result['origin_zone'] = $originZone;
            $result['destination_zone'] = $destZone;
            $result['lane'] = $lane;
        } else {
            $metrics = CC_CP_Routing_Client::get_metrics(
                array('lat' => $sellerLat, 'lng' => $sellerLng),
                array('lat' => $customerLat, 'lng' => $customerLng)
            );
            if (is_wp_error($metrics)) {
                return $metrics;
            }
            $result = CC_CP_Pricing_Calculator::calculate($context, $metrics, CC_CP_Settings::get_pricing());
            $result['route_metrics'] = $metrics;
            $result['origin_block'] = $originBlock;
            $result['destination_block'] = $destBlock;
            $result['origin_zone'] = $originZone;
            $result['destination_zone'] = $destZone;
            $result['lane'] = null;
        }

        $result['seller_lat'] = $sellerLat;
        $result['seller_lng'] = $sellerLng;
        $result['customer_lat'] = $customerLat;
        $result['customer_lng'] = $customerLng;
        $result['shipment_id'] = isset($args['shipment_id']) ? absint($args['shipment_id']) : 0;
        $result['settings_snapshot'] = CC_CP_Settings::all();

        do_action('cc_cp_quote_computed', $result, $args);
        return apply_filters('cc_cp_calculated_shipping_fee', $result, $args);
    }

    public static function quote_for_shipment($shipment_id) {
        $shipment_id = absint($shipment_id);
        if (!$shipment_id) {
            return new WP_Error('cc_cp_missing_shipment', 'Shipment required.');
        }
        $pickup = get_post_meta($shipment_id, '_cc_shipment_pickup_coords', true);
        $dropoff = get_post_meta($shipment_id, '_cc_shipment_dropoff_coords', true);
        $vendorLat = (float) get_post_meta($shipment_id, '_cc_vendor_lat', true);
        $vendorLng = (float) get_post_meta($shipment_id, '_cc_vendor_lng', true);
        if (strpos((string) $pickup, ',') !== false) {
            list($plat, $plng) = array_map('trim', explode(',', $pickup, 2));
            $vendorLat = (float) $plat; $vendorLng = (float) $plng;
        }
        $dropLat = (float) get_post_meta($shipment_id, '_cc_dropoff_lat', true);
        $dropLng = (float) get_post_meta($shipment_id, '_cc_dropoff_lng', true);
        if (strpos((string) $dropoff, ',') !== false) {
            list($dlat, $dlng) = array_map('trim', explode(',', $dropoff, 2));
            $dropLat = (float) $dlat; $dropLng = (float) $dlng;
        }
        if (!$vendorLat || !$vendorLng || !$dropLat || !$dropLng) {
            return new WP_Error('cc_cp_missing_shipment_coords', 'Shipment missing pickup/dropoff coords.');
        }
        $quote = self::calculate(array(
            'shipment_id' => $shipment_id,
            'seller_lat' => $vendorLat,
            'seller_lng' => $vendorLng,
            'customer_lat' => $dropLat,
            'customer_lng' => $dropLng,
        ));
        if (!is_wp_error($quote)) {
           update_post_meta(
    $shipment_id,
    '_cc_cp_quote_total_gyd',
    isset($quote['total']) ? $quote['total'] : ($quote['total_shipping_fee'] ?? 0)
);
            update_post_meta($shipment_id, '_cc_cp_quote_breakdown', wp_json_encode($quote));
            update_post_meta($shipment_id, '_cc_cp_quote_distance_km', $quote['distance_km'] ?? 0);
            update_post_meta($shipment_id, '_cc_cp_quote_duration_seconds', $quote['duration_seconds'] ?? 0);
            update_post_meta($shipment_id, '_cc_cp_quote_recorded_at', current_time('mysql'));
        }
        return $quote;
    }
}
