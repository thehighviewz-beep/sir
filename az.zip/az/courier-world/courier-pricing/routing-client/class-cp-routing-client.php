<?php
if (!defined('ABSPATH')) { exit; }

final class CC_CP_Routing_Client {
    const TRANSIENT_PREFIX = 'cc_cp_route_';

    public static function get_metrics($origin, $destination) {
        $origin = self::normalize_point($origin);
        $destination = self::normalize_point($destination);
        if (!$origin || !$destination) {
            return new WP_Error('cc_cp_route_missing_points', 'Missing route points.');
        }

        $cacheKey = self::TRANSIENT_PREFIX . md5(wp_json_encode(array($origin, $destination)));
        $cached = get_transient($cacheKey);
        if (is_array($cached) && !empty($cached['distance_km'])) {
            $cached['cache_hit'] = true;
            return $cached;
        }

        $result = self::request_google_route($origin, $destination);
        if (is_wp_error($result)) {
            $fallback = self::fallback_metrics($origin, $destination, $result->get_error_message());
            set_transient($cacheKey, $fallback, 10 * MINUTE_IN_SECONDS);
            return $fallback;
        }

        set_transient($cacheKey, $result, 15 * MINUTE_IN_SECONDS);
        return $result;
    }

    private static function request_google_route($origin, $destination) {
        $apiKey = '';
        if (defined('CARICOVE_GOOGLE_MAPS_API_KEY') && CARICOVE_GOOGLE_MAPS_API_KEY) {
            $apiKey = trim((string) CARICOVE_GOOGLE_MAPS_API_KEY);
        } elseif (defined('CARICOVE_MAPS_SERVER_KEY') && CARICOVE_MAPS_SERVER_KEY) {
            $apiKey = trim((string) CARICOVE_MAPS_SERVER_KEY);
        }
        if ($apiKey === '') {
            return new WP_Error('cc_cp_google_route_key_missing', 'Google Routes key missing.');
        }

        $body = array(
            'origin' => array('location' => array('latLng' => array('latitude' => $origin['lat'], 'longitude' => $origin['lng']))),
            'destination' => array('location' => array('latLng' => array('latitude' => $destination['lat'], 'longitude' => $destination['lng']))),
            'travelMode' => 'DRIVE',
            'routingPreference' => 'TRAFFIC_AWARE',
            'computeAlternativeRoutes' => false,
            'languageCode' => 'en-US',
        );

        $res = wp_remote_post('https://routes.googleapis.com/directions/v2:computeRoutes', array(
            'timeout' => 12,
            'headers' => array(
                'Content-Type' => 'application/json',
                'X-Goog-Api-Key' => $apiKey,
                'X-Goog-FieldMask' => 'routes.distanceMeters,routes.duration,routes.staticDuration',
            ),
            'body' => wp_json_encode($body),
        ));

        if (is_wp_error($res)) {
            return $res;
        }
        $code = wp_remote_retrieve_response_code($res);
        $data = json_decode(wp_remote_retrieve_body($res), true);
        if ($code < 200 || $code >= 300 || empty($data['routes'][0]['distanceMeters'])) {
            return new WP_Error('cc_cp_google_route_failed', 'Google route lookup failed.', array('code' => $code, 'body' => $data));
        }
        $route = $data['routes'][0];
        return array(
            'distance_km' => round(((float) $route['distanceMeters']) / 1000, 3),
            'duration_seconds' => self::parse_duration_seconds($route['duration'] ?? ''),
            'static_duration_seconds' => self::parse_duration_seconds($route['staticDuration'] ?? ''),
            'source' => 'google_routes',
            'cache_hit' => false,
            'error' => '',
        );
    }

    private static function fallback_metrics($origin, $destination, $message = '') {
        $straight = CC_CP_Storage::haversine_m($origin['lat'], $origin['lng'], $destination['lat'], $destination['lng']) / 1000;
        $distance = round($straight * 1.4, 3);
        $duration = (int) round(($distance / 28) * HOUR_IN_SECONDS);
        return array(
            'distance_km' => $distance,
            'duration_seconds' => $duration,
            'static_duration_seconds' => $duration,
            'source' => 'haversine_fallback',
            'cache_hit' => false,
            'error' => (string) $message,
        );
    }

    private static function normalize_point($point) {
        if (!is_array($point) || !isset($point['lat'], $point['lng'])) {
            return null;
        }
        return array(
            'lat' => round((float) $point['lat'], 6),
            'lng' => round((float) $point['lng'], 6),
        );
    }

    private static function parse_duration_seconds($value) {
        if (!is_string($value) || $value === '') return 0;
        if (preg_match('/^([0-9]+(?:\.[0-9]+)?)s$/', trim($value), $m)) {
            return (int) round((float) $m[1]);
        }
        return 0;
    }
}
