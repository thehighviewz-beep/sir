<?php
/**
 * Plugin Name: Caricove Courier Pricing Loader
 * Description: MU loader for the courier-pricing module.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$cp_main_file = WPMU_PLUGIN_DIR . '/courier-world/courier-pricing/courier-pricing.php';

if ( file_exists( $cp_main_file ) ) {
	require_once $cp_main_file;
}