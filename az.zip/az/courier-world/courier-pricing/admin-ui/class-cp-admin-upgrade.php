<?php
if (!defined('ABSPATH')) { exit; }

final class CC_CP_Admin_Upgrade {
    public static function init() {
        add_action('admin_enqueue_scripts', array(__CLASS__, 'enqueue_assets'), 30);
        add_action('wp_ajax_cc_cp_get_control_center', array(__CLASS__, 'ajax_get_control_center'));
        add_action('wp_ajax_cc_cp_save_control_center', array(__CLASS__, 'ajax_save_control_center'));
        add_action('wp_ajax_cc_cp_get_logistics_intelligence', array(__CLASS__, 'ajax_get_logistics_intelligence'));
        add_action('wp_ajax_cc_cp_set_knob_mode', array(__CLASS__, 'ajax_set_knob_mode'));
        add_action('wp_ajax_cc_cp_save_entity_extras', array(__CLASS__, 'ajax_save_entity_extras'));
        add_action('wp_ajax_cc_cp_reset_logistics_intelligence', array(__CLASS__, 'ajax_reset_logistics_intelligence'));
    }

    public static function enqueue_assets($hook) {
        if (strpos((string) $hook, CC_CP_Admin::SLUG) === false) {
            return;
        }
        wp_enqueue_style('cc-cp-admin-upgrade', CC_CP_URL . 'assets/admin-upgrade.css', array('cc-cp-admin'), file_exists(CC_CP_DIR . 'assets/admin-upgrade.css') ? filemtime(CC_CP_DIR . 'assets/admin-upgrade.css') : CC_CP_VERSION);
        wp_enqueue_script('cc-cp-admin-upgrade', CC_CP_URL . 'assets/admin-upgrade.js', array('jquery', 'cc-cp-admin'), file_exists(CC_CP_DIR . 'assets/admin-upgrade.js') ? filemtime(CC_CP_DIR . 'assets/admin-upgrade.js') : CC_CP_VERSION, true);
        wp_localize_script('cc-cp-admin-upgrade', 'CC_CP_UPGRADE', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('cc_cp_admin_nonce'),
            'settings' => CC_CP_Settings::all(),
            'zoneTypes' => CC_CP_Settings::zone_type_choices(),
            'blockTypes' => CC_CP_Settings::block_type_choices(),
            'strings' => array(
                'controlCenter' => 'Pricing Control Center',
                'logisticsIntelligence' => 'Logistics Intelligence',
                'manualOverrideNote' => 'Automatic pricing is used by default. Manual lanes remain available as route-specific overrides.',
                'notEnoughData' => 'Not enough data yet',
                'autoTuningActive' => 'Auto tuning active',
            ),
        ));
    }

    private static function require_access() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Forbidden.'), 403);
        }
        check_ajax_referer('cc_cp_admin_nonce', 'nonce');
    }

    public static function ajax_get_control_center() {
        self::require_access();
        wp_send_json_success(array('settings' => CC_CP_Settings::all()));
    }

    public static function ajax_save_control_center() {
        self::require_access();
        $payload = json_decode(wp_unslash($_POST['payload'] ?? '{}'), true);
        if (!is_array($payload)) $payload = array();
        CC_CP_Settings::save_all($payload);
        wp_send_json_success(array('settings' => CC_CP_Settings::all()));
    }

    public static function ajax_get_logistics_intelligence() {
        self::require_access();
        wp_send_json_success(array('dashboard' => CC_CP_Intelligence::get_dashboard()));
    }

    public static function ajax_set_knob_mode() {
        self::require_access();
        $knob = sanitize_key($_POST['knob_key'] ?? '');
        $mode = sanitize_key($_POST['mode'] ?? 'manual');
        if ($knob === '') {
            wp_send_json_error(array('message' => 'Missing knob.'), 400);
        }
        CC_CP_Settings::set_knob_mode($knob, $mode);
        wp_send_json_success(array('dashboard' => CC_CP_Intelligence::get_dashboard()));
    }


    public static function ajax_reset_logistics_intelligence() {
        self::require_access();
        CC_CP_Intelligence::reset_all_data();
        wp_send_json_success(array('dashboard' => CC_CP_Intelligence::get_dashboard()));
    }

    public static function ajax_save_entity_extras() {
        self::require_access();
        $entityType = sanitize_key($_POST['entity_type'] ?? '');
        $id = sanitize_key($_POST['id'] ?? '');
        if (!$entityType || !$id) {
            wp_send_json_error(array('message' => 'Missing entity target.'), 400);
        }
        if ($entityType === 'zone') {
            $existing = CC_CP_Storage::find_zone_by_id($id);
            if (!$existing) wp_send_json_error(array('message' => 'Zone not found.'), 404);
            $updated = CC_CP_Storage::upsert_zone(array_merge($existing, array('zone_type' => sanitize_key($_POST['zone_type'] ?? ($existing['zone_type'] ?? 'suburban')))));
            wp_send_json_success(array('entity' => $updated, 'plannerData' => CC_CP_Admin::planner_data()));
        }
        if ($entityType === 'block') {
            $existing = CC_CP_Storage::find_block_by_id($id);
            if (!$existing) wp_send_json_error(array('message' => 'Block not found.'), 404);
            $updated = CC_CP_Storage::upsert_block(array_merge($existing, array('block_type' => sanitize_key($_POST['block_type'] ?? ($existing['block_type'] ?? 'standard')))));
            wp_send_json_success(array('entity' => $updated, 'plannerData' => CC_CP_Admin::planner_data()));
        }
        wp_send_json_error(array('message' => 'Unsupported entity type.'), 400);
    }
}
