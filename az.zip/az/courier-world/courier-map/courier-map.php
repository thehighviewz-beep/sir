<?php
/**
 * Plugin Name: Caricove Logistics — Courier Map
 * Description: Folderized courier map renderer for the Caricove logistics universe.
 * Author: Caricove
 * Version: 3.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'CARICOVE_COURIER_MAP_FILE', __FILE__ );
define( 'CARICOVE_COURIER_MAP_DIR', plugin_dir_path( __FILE__ ) );
define( 'CARICOVE_COURIER_MAP_URL', plugin_dir_url( __FILE__ ) );

require_once CARICOVE_COURIER_MAP_DIR . 'includes/helpers-courier-map.php';
require_once CARICOVE_COURIER_MAP_DIR . 'includes/class-courier-map-animator.php';
require_once CARICOVE_COURIER_MAP_DIR . 'includes/class-courier-map-assets.php';
require_once CARICOVE_COURIER_MAP_DIR . 'includes/class-courier-map-camera.php';
require_once CARICOVE_COURIER_MAP_DIR . 'includes/class-courier-map-data.php';
require_once CARICOVE_COURIER_MAP_DIR . 'includes/class-courier-map-markers.php';
require_once CARICOVE_COURIER_MAP_DIR . 'includes/class-courier-map-module.php';
require_once CARICOVE_COURIER_MAP_DIR . 'includes/class-courier-map-route.php';
require_once CARICOVE_COURIER_MAP_DIR . 'includes/class-courier-map-shortcode.php';
require_once CARICOVE_COURIER_MAP_DIR . 'includes/class-courier-map-state.php';

Caricove_Courier_Map_Module::boot();
