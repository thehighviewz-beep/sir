<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<div class="ccv-courier-map-empty" id="ccv-map-empty">Map unavailable until Google Maps is configured.</div>
