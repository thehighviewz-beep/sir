<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<div class="ccv-courier-map-shell">
    <?php echo $empty; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
    <?php echo $panel; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
    <div id="ccv-map-canvas"></div>
</div>
