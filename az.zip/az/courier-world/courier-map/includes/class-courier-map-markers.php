<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Caricove_Courier_Map_Markers {
    public static function defaults() {
        return array(
            'vehicle_image' => 'https://caricove.com/wp-content/uploads/black-car.jpeg?v=5',
        );
    }
}
