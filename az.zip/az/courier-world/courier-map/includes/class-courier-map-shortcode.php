<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Caricove_Courier_Map_Shortcode {
    public static function boot() {
        add_shortcode( 'caricove_courier_map', array( __CLASS__, 'render' ) );
    }

    public static function render() {
        Caricove_Courier_Map_Assets::enqueue();

        return caricove_courier_map_render_template(
            'courier-map-shell.php',
            array(
                'panel' => caricove_courier_map_render_template( 'courier-map-panel.php' ),
                'empty' => caricove_courier_map_render_template( 'courier-map-empty.php' ),
            )
        );
    }
}
