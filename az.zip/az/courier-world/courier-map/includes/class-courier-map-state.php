<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Caricove_Courier_Map_State {
    public static function empty_state() {
        return array(
            'courier_id'   => 0,
            'generated_at' => time(),
            'jobs'         => array(
                'incoming' => array(),
                'assigned' => array(),
                'queued'   => array(),
            ),
            'balances'     => array(),
            'settings'     => array(),
            'mission'      => array(),
            'focus_job_id' => 0,
        );
    }
}
