<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Caricove_Courier_Map_Module {
    public static function boot() {
        add_action( 'wp_enqueue_scripts', array( 'Caricove_Courier_Map_Assets', 'register' ), 20 );
        Caricove_Courier_Map_Shortcode::boot();
    }
}
