<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Caricove_Courier_Map_Camera {
    public static function default_options() {
        return array(
            'center' => array( 'lat' => 6.8013, 'lng' => -58.1551 ),
            'zoom'   => 13,
        );
    }
}
