<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Caricove_Courier_Map_Assets {
    public static function register() {
        wp_register_style(
            'caricove-courier-map',
            CARICOVE_COURIER_MAP_URL . 'assets/css/courier-map.css',
            array(),
            '3.0.1'
        );

        if ( function_exists( 'ccv_ccb_register_runtime_script' ) ) {
            ccv_ccb_register_runtime_script();
        }

        wp_register_script(
            'caricove-courier-map-runtime',
            CARICOVE_COURIER_MAP_URL . 'assets/js/courier-map.js',
            array( 'ccv-courier-bridge-runtime' ),
            '3.0.1',
            true
        );

        $maps_url = '';
        if ( defined( 'CARICOVE_MAPS_BROWSER_KEY' ) && CARICOVE_MAPS_BROWSER_KEY ) {
          $maps_url = add_query_arg(
    array(
        'key'       => CARICOVE_MAPS_BROWSER_KEY,
        'callback'  => 'CaricoveCourierMapInit',
        'libraries' => 'marker',
    ),
    'https://maps.googleapis.com/maps/api/js'
);

            wp_register_script(
                'caricove-courier-google-maps',
                $maps_url,
                array(),
                null,
                true
            );
        }

        $config = array(
            'animator' => array(
                'duration_ms' => Caricove_Courier_Map_Animator::default_duration_ms(),
            ),
            'camera'   => Caricove_Courier_Map_Camera::default_options(),
            'markers'  => Caricove_Courier_Map_Markers::defaults(),
            'route'    => Caricove_Courier_Map_Route::defaults(),
            'maps_enabled'    => defined( 'CARICOVE_MAPS_BROWSER_KEY' ) && CARICOVE_MAPS_BROWSER_KEY,
            'google_maps_url' => $maps_url,
        );

        wp_add_inline_script(
            'caricove-courier-map-runtime',
            'window.CaricoveCourierMapConfig = ' . wp_json_encode( $config ) . ';',
            'before'
        );
    }

    public static function enqueue() {
        self::register();

        if ( function_exists( 'ccv_ccb_enqueue_runtime_script' ) ) {
            ccv_ccb_enqueue_runtime_script();
        }

        wp_enqueue_style( 'caricove-courier-map' );
        wp_enqueue_script( 'caricove-courier-map-runtime' );
    }
}
