<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Caricove_Courier_Map_Animator {
    public static function default_duration_ms() {
        return 2200;
    }
}
