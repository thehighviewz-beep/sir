<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Caricove_Courier_Map_Route {
    public static function defaults() {
        return array(
            'travel_mode' => 'DRIVING',
        );
    }
}
