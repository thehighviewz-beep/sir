<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! function_exists( 'caricove_courier_map_template_path' ) ) {
    function caricove_courier_map_template_path( $template_name ) {
        return trailingslashit( CARICOVE_COURIER_MAP_DIR . 'templates' ) . ltrim( $template_name, '/' );
    }
}

if ( ! function_exists( 'caricove_courier_map_render_template' ) ) {
    function caricove_courier_map_render_template( $template_name, array $vars = array() ) {
        $template_path = caricove_courier_map_template_path( $template_name );
        if ( ! file_exists( $template_path ) ) {
            return '';
        }

        if ( ! empty( $vars ) ) {
            extract( $vars, EXTR_SKIP );
        }

        ob_start();
        include $template_path;
        return ob_get_clean();
    }
}
