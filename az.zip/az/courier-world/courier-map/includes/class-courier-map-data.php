<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Caricove_Courier_Map_Data {
    public static function get_initial_state( $courier_id ) {
        if ( function_exists( 'ccv_ccb_get_runtime_payload' ) ) {
            return ccv_ccb_get_runtime_payload( $courier_id );
        }

        $state = Caricove_Courier_Map_State::empty_state();
        $state['courier_id'] = intval( $courier_id );
        return $state;
    }
}
