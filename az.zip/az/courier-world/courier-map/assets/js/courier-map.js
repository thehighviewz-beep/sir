(function(window, document){
  'use strict';

  var config = window.CaricoveCourierMapConfig || {};
  var app = {
    googleReady: !!(window.google && window.google.maps),
    bridgeBound: false,
    latestState: null,
    map: null,
    directions: null,
    courierMarker: null,
    pickupMarker: null,
    dropoffMarker: null,
    routeGlow: null,
    routeMain: null,
    routeKey: '',
    pulseTimer: null,
    lastCourierPosition: null,
    currentJobId: '',
    lastSceneKey: '',
    lastGeometryKey: '',
    hasDoneInitialFit: false,
    googleLoading: false,
    pulsePhase: 0
  };

  function qs(sel, ctx){ return (ctx || document).querySelector(sel); }
  function qsa(sel, ctx){ return Array.prototype.slice.call((ctx || document).querySelectorAll(sel)); }
  function bridge(){ return window.CaricoveCourierBridge || null; }
  function canvas(){ return document.getElementById('ccv-map-canvas'); }
  function mapPanel(){ return document.getElementById('ccv-map-panel'); }
  function mapEmpty(){ return document.getElementById('ccv-map-empty'); }
  function isObject(value){ return !!value && typeof value === 'object' && !Array.isArray(value); }
  function stringVal(value){ return value == null ? '' : String(value); }
  function numberVal(value){ var num = Number(value); return isFinite(num) ? num : null; }
  function cameraDefaults(){ return isObject(config.camera) ? config.camera : { center: { lat: 6.8013, lng: -58.1551 }, zoom: 13 }; }
  function animationDuration(){ return Number(config.animator && config.animator.duration_ms) || 1600; }
  function travelMode(){
    return google.maps.TravelMode[(config.route && config.route.travel_mode) || 'DRIVING'] || google.maps.TravelMode.DRIVING;
  }

  function hasConsoleMapView(){
    return !!qs('.ccv-console-body[data-view="map"]');
  }

  function isMapViewActive(){
    var body = qs('.ccv-console-body[data-view="map"]');
    return !body || !body.classList.contains('ccv-console-body--hidden');
  }

  function shouldSyncMap(kind){
    if (!canvas()) return false;
    if (!hasConsoleMapView()) return true;
    if (isMapViewActive()) return true;
    return kind === 'tab' || kind === 'manual' || kind === 'google_ready' || kind === 'focus_map' || kind === 'transition';
  }

  function mapEmptyMessage(message){
    var empty = mapEmpty();
    if (!empty) return;
    empty.textContent = message;
    empty.hidden = false;
  }

  function ensureGoogleMapsLoaded(){
    if (app.googleReady) return true;
    if (window.google && window.google.maps) {
      app.googleReady = true;
      return true;
    }
    if (!config.maps_enabled) {
      mapEmptyMessage('Map unavailable until Google Maps is configured.');
      return false;
    }
    if (app.googleLoading) return false;

    var src = stringVal(config.google_maps_url || '');
    if (!src) {
      mapEmptyMessage('Map unavailable until Google Maps is configured.');
      return false;
    }

    var existing = document.querySelector('script[data-ccv-google-maps="1"]');
    if (existing) {
      app.googleLoading = true;
      mapEmptyMessage('Loading map…');
      return false;
    }

    app.googleLoading = true;
    mapEmptyMessage('Loading map…');

    var script = document.createElement('script');
    script.src = src;
    script.async = true;
    script.defer = true;
    script.setAttribute('data-ccv-google-maps', '1');
    script.onerror = function(){
      app.googleLoading = false;
      mapEmptyMessage('Unable to load the courier map right now.');
    };
    document.body.appendChild(script);
    return false;
  }

  function latLng(lat, lng){
    lat = numberVal(lat);
    lng = numberVal(lng);
    if (lat === null || lng === null) return null;
    return { lat: lat, lng: lng };
  }

  function easeInOut(t){
    return t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t;
  }

  function allJobs(state){
    state = isObject(state) ? state : {};
    var jobs = state.jobs || {};
    return [].concat(jobs.assigned || []).concat(jobs.incoming || []).concat(jobs.queued || []);
  }

  function findJobById(state, jobId){
    jobId = stringVal(jobId);
    if (!jobId) return null;
    var jobs = allJobs(state);
    for (var i = 0; i < jobs.length; i++) {
      if (stringVal(jobs[i] && jobs[i].job_id) === jobId) return jobs[i];
    }
    return null;
  }

  function focusedJob(state){
    state = isObject(state) ? state : {};
    var focused = findJobById(state, state.focus_job_id || '');
    if (focused) return focused;
    var jobs = state.jobs || {};
    return (jobs.assigned && jobs.assigned[0]) || (jobs.incoming && jobs.incoming[0]) || (jobs.queued && jobs.queued[0]) || null;
  }

  function buildPulseSymbol(fillColor, strokeColor, scale, fillOpacity){
    return {
      path: google.maps.SymbolPath.CIRCLE,
      scale: scale,
      fillColor: fillColor,
      fillOpacity: fillOpacity,
      strokeColor: strokeColor || fillColor,
      strokeOpacity: 0.98,
      strokeWeight: 2
    };
  }

  function buildCourierSymbol(scale){
    return buildPulseSymbol('#ffffff', '#dff5ff', scale, 0.96);
  }

  function buildPickupSymbol(scale){
    return buildPulseSymbol('#59c6ff', '#b9ebff', scale, 0.82);
  }

  function buildDropoffSymbol(scale){
    return buildPulseSymbol('#ffcf57', '#fff0b5', scale, 0.84);
  }

  function clearMapVisuals(){
    if (app.routeGlow) app.routeGlow.setPath([]);
    if (app.routeMain) app.routeMain.setPath([]);
    if (app.pickupMarker) app.pickupMarker.setMap(null);
    if (app.dropoffMarker) app.dropoffMarker.setMap(null);
    app.routeKey = '';
    app.currentJobId = '';
    app.lastSceneKey = '';
    app.lastGeometryKey = '';
    app.hasDoneInitialFit = false;
  }

  function startPulse(){
    if (app.pulseTimer) return;
    app.pulseTimer = window.setInterval(function(){
      app.pulsePhase += 0.18;
      var wave = (Math.sin(app.pulsePhase) + 1) / 2;

      if (app.pickupMarker) {
        app.pickupMarker.setIcon(buildPickupSymbol(8 + (wave * 2.2)));
      }
      if (app.dropoffMarker) {
        app.dropoffMarker.setIcon(buildDropoffSymbol(8 + (wave * 2.2)));
      }
      if (app.courierMarker) {
        app.courierMarker.setIcon(buildCourierSymbol(8.5 + (wave * 2.6)));
      }
    }, 90);
  }

  function ensureMap(){
    if (app.map) return true;
    if (!app.googleReady || !window.google || !google.maps || !canvas()) return false;

    var defaults = cameraDefaults();
    app.map = new google.maps.Map(canvas(), {
      center: defaults.center || { lat: 6.8013, lng: -58.1551 },
      zoom: defaults.zoom || 13,
      mapTypeId: 'hybrid',
      disableDefaultUI: false,
      gestureHandling: 'greedy',
      tilt: 0,
      heading: 0,
      clickableIcons: false,
      streetViewControl: false,
      fullscreenControl: false,
      mapTypeControl: false
    });

    app.directions = new google.maps.DirectionsService();

    app.routeGlow = new google.maps.Polyline({
      map: app.map,
      strokeColor: '#4ab8ff',
      strokeOpacity: 0.22,
      strokeWeight: 10,
      clickable: false
    });

    app.routeMain = new google.maps.Polyline({
      map: app.map,
      strokeColor: '#f6fbff',
      strokeOpacity: 0.92,
      strokeWeight: 4,
      clickable: false,
      icons: [{
        icon: {
          path: google.maps.SymbolPath.FORWARD_CLOSED_ARROW,
          scale: 2.1,
          strokeColor: '#8fd3ff',
          strokeOpacity: 0.9,
          fillColor: '#8fd3ff',
          fillOpacity: 0.9
        },
        offset: '0%',
        repeat: '42px'
      }]
    });

    startPulse();
    if (mapEmpty()) mapEmpty().hidden = true;
    return true;
  }

  function ensureMarkers(){
    if (!app.map) return;

    if (!app.pickupMarker) {
      app.pickupMarker = new google.maps.Marker({
        map: app.map,
        zIndex: 20,
        optimized: true,
        icon: buildPickupSymbol(9)
      });
    }

    if (!app.dropoffMarker) {
      app.dropoffMarker = new google.maps.Marker({
        map: app.map,
        zIndex: 20,
        optimized: true,
        icon: buildDropoffSymbol(9)
      });
    }

    if (!app.courierMarker) {
      app.courierMarker = new google.maps.Marker({
        map: app.map,
        zIndex: 30,
        optimized: true,
        icon: buildCourierSymbol(9.5)
      });
    }
  }

  function setMarkerPosition(marker, point){
    if (!marker) return;
    marker.setPosition(point || null);
  }

  function setMarkerVisible(marker, visible){
    if (!marker) return;
    marker.setMap(visible ? app.map : null);
  }

  function animateCourier(to){
    ensureMarkers();
    if (!to) {
      setMarkerVisible(app.courierMarker, false);
      return;
    }

    setMarkerVisible(app.courierMarker, true);

    var from = app.lastCourierPosition || to;
    var start = performance.now();
    var duration = animationDuration();

    function tick(now){
      var t = Math.min(1, (now - start) / duration);
      var eased = easeInOut(t);
      var pos = {
        lat: from.lat + ((to.lat - from.lat) * eased),
        lng: from.lng + ((to.lng - from.lng) * eased)
      };
      setMarkerPosition(app.courierMarker, pos);
      if (t < 1) {
        requestAnimationFrame(tick);
      }
    }

    requestAnimationFrame(tick);
    app.lastCourierPosition = to;
  }

  function routePathFromResult(result){
    if (!result || !result.routes || !result.routes.length) return [];
    return result.routes[0].overview_path || [];
  }

  function setRoute(path){
    if (app.routeGlow) app.routeGlow.setPath(path || []);
    if (app.routeMain) app.routeMain.setPath(path || []);
  }

  function simulateCourier(scene, realCourier){
    if (!scene.pickup) return realCourier;
    var state = app.latestState || {};
    var simEnabled = !!(
      (config.simulation && config.simulation.enabled) ||
      state.map_simulation_enabled ||
      scene.simulated_courier === true
    );
    if (!simEnabled) return realCourier;

    var target = scene.phase === 'to_dropoff' && scene.dropoff ? scene.dropoff : scene.pickup;
    if (!target) return realCourier;

    var anchor = latLng(scene.sim_courier_lat, scene.sim_courier_lng)
      || latLng(state.sim_courier_lat, state.sim_courier_lng)
      || realCourier
      || scene.pickup;

    if (!anchor) return realCourier;

    var factor = Number(
      scene.sim_near_factor != null ? scene.sim_near_factor :
      state.sim_near_factor != null ? state.sim_near_factor :
      0.12
    );
    if (!isFinite(factor)) factor = 0.12;
    factor = Math.max(0.02, Math.min(0.35, factor));

    return {
      lat: target.lat + ((anchor.lat - target.lat) * factor),
      lng: target.lng + ((anchor.lng - target.lng) * factor)
    };
  }

  function buildScene(job){
    if (!job) return null;

    var phase = stringVal(job.phase || 'to_pickup');
    var realCourier = latLng(job.courier_lat, job.courier_lng);
    var pickup = latLng(job.pickup_lat, job.pickup_lng);
    var dropoff = latLng(job.dropoff_lat, job.dropoff_lng);
    var courier = simulateCourier({
      pickup: pickup,
      dropoff: dropoff,
      phase: phase,
      sim_courier_lat: job.sim_courier_lat,
      sim_courier_lng: job.sim_courier_lng,
      sim_near_factor: job.sim_near_factor,
      simulated_courier: job.simulated_courier
    }, realCourier);

    return {
      jobId: stringVal(job.job_id),
      label: stringVal(job.label),
      status: stringVal(job.status),
      phase: phase,
      courier: courier,
      pickup: pickup,
      dropoff: dropoff,
      routeText: [stringVal(job.pickup_city || job.pickup_text), stringVal(job.dropoff_city || job.dropoff_text)].filter(Boolean).join(' → '),
      distanceLabel: stringVal(job.distance_label),
      payLabel: stringVal(job.currency || 'GYD') + ' ' + stringVal(job.pay_label || '0.00')
    };
  }

  function updatePanel(scene){
    var panel = mapPanel();
    if (!panel) return;
    if (!scene) {
      panel.hidden = true;
      panel.innerHTML = '';
      return;
    }
    panel.hidden = false;
    panel.innerHTML = '<strong>' + scene.label + '</strong><br>' + (scene.routeText || 'Route loading') + '<br>' + (scene.distanceLabel || scene.payLabel || '');
  }

  function renderRoute(scene){
    if (!app.map || !app.directions || !scene) return;

    if (scene.phase === 'done') {
      app.routeKey = 'done';
      setRoute([]);
      return;
    }

    var origin = scene.courier || scene.pickup;
    if (!origin) {
      setRoute([]);
      return;
    }

    var request;
    if (scene.phase === 'to_dropoff') {
      if (!scene.dropoff) {
        setRoute([]);
        return;
      }
      request = {
        origin: origin,
        destination: scene.dropoff,
        travelMode: travelMode()
      };
    } else {
      if (!scene.pickup || !scene.dropoff) {
        setRoute([]);
        return;
      }
      request = {
        origin: origin,
        destination: scene.dropoff,
        waypoints: [{ location: scene.pickup, stopover: true }],
        travelMode: travelMode(),
        optimizeWaypoints: false
      };
    }

    var routeKey = JSON.stringify(request);
    if (routeKey === app.routeKey) return;
    app.routeKey = routeKey;

    app.directions.route(request, function(result, status){
      if (status !== 'OK' || !result) return;
      setRoute(routePathFromResult(result));
      maybeAdjustCamera(scene, 'route_changed');
    });
  }

  function boundsForScene(scene){
    var bounds = new google.maps.LatLngBounds();
    var points = [];

    if (scene.phase === 'done') {
      if (scene.courier) points.push(scene.courier);
    } else if (scene.phase === 'to_dropoff') {
      if (scene.courier) points.push(scene.courier);
      if (scene.dropoff) points.push(scene.dropoff);
    } else {
      if (scene.courier) points.push(scene.courier);
      if (scene.pickup) points.push(scene.pickup);
    }

    if (!points.length) return null;
    points.forEach(function(point){ bounds.extend(point); });
    return bounds;
  }

  function sceneKey(scene){
    return [
      scene.jobId,
      scene.phase,
      scene.status
    ].join('|');
  }

  function geometryKey(scene){
    var pts = [
      scene.courier ? (scene.courier.lat + ',' + scene.courier.lng) : '',
      scene.pickup ? (scene.pickup.lat + ',' + scene.pickup.lng) : '',
      scene.dropoff ? (scene.dropoff.lat + ',' + scene.dropoff.lng) : ''
    ];
    return pts.join('|');
  }

  function shouldRefit(scene, reason){
    var nextSceneKey = sceneKey(scene);
    var nextGeometryKey = geometryKey(scene);

    if (!app.hasDoneInitialFit) return true;
    if (reason === 'tab' || reason === 'focus_map' || reason === 'transition' || reason === 'google_ready') return true;
    if (app.lastSceneKey !== nextSceneKey) return true;
    if (app.currentJobId !== scene.jobId) return true;

    var oldCourier = app.lastCourierPosition;
    if (!oldCourier || !scene.courier) return false;

    var latDelta = Math.abs(oldCourier.lat - scene.courier.lat);
    var lngDelta = Math.abs(oldCourier.lng - scene.courier.lng);

    if ((latDelta + lngDelta) > 0.01) return true;
    if (reason === 'route_changed' && app.lastGeometryKey !== nextGeometryKey) return true;

    return false;
  }

  function maybeAdjustCamera(scene, reason){
    if (!app.map || !scene) return;

    var nextSceneKey = sceneKey(scene);
    var nextGeometryKey = geometryKey(scene);

    if (shouldRefit(scene, reason)) {
      var bounds = boundsForScene(scene);
      if (bounds) {
        app.map.fitBounds(bounds, 80);
        app.hasDoneInitialFit = true;
      }
    }

    app.lastSceneKey = nextSceneKey;
    app.lastGeometryKey = nextGeometryKey;
  }

  function resolveIdleCourier(state){
    state = isObject(state) ? state : {};

    return latLng(state.courier_lat, state.courier_lng) ||
      latLng(state.profile_lat, state.profile_lng) ||
      latLng(state.last_lat, state.last_lng) ||
      latLng(state.heartbeat_lat, state.heartbeat_lng) ||
      latLng(state.sim_courier_lat, state.sim_courier_lng);
  }

  function syncScene(state, kind){
    app.latestState = state || app.latestState;

    if (!shouldSyncMap(kind || 'state')) {
      return;
    }

    if (!app.googleReady) {
      ensureGoogleMapsLoaded();
      return;
    }

    var scene = buildScene(focusedJob(app.latestState || {}));
    updatePanel(scene);

    if (!ensureMap()) {
      ensureGoogleMapsLoaded();
      return;
    }

    ensureMarkers();

    if (!scene) {
      clearMapVisuals();

      var idleCourier = resolveIdleCourier(app.latestState || {});
      if (idleCourier) {
        setMarkerPosition(app.courierMarker, idleCourier);
        setMarkerVisible(app.courierMarker, true);
        app.lastCourierPosition = idleCourier;

        if (!app.hasDoneInitialFit) {
          app.map.setCenter(idleCourier);
          app.map.setZoom(16);
          app.hasDoneInitialFit = true;
        }
      } else {
        setMarkerVisible(app.courierMarker, false);
      }

      return;
    }

    if (mapEmpty()) mapEmpty().hidden = true;
    app.currentJobId = scene.jobId;

    var phase = scene.phase || 'to_pickup';
    var showPickup = (phase === 'to_pickup');
    var showDropoff = (phase === 'to_pickup' || phase === 'to_dropoff');
    var showCourier = !!scene.courier;

    if (scene.pickup) {
      setMarkerPosition(app.pickupMarker, scene.pickup);
      setMarkerVisible(app.pickupMarker, showPickup);
    } else {
      setMarkerVisible(app.pickupMarker, false);
    }

    if (scene.dropoff) {
      setMarkerPosition(app.dropoffMarker, scene.dropoff);
      setMarkerVisible(app.dropoffMarker, showDropoff);
    } else {
      setMarkerVisible(app.dropoffMarker, false);
    }

    setMarkerVisible(app.courierMarker, showCourier);

    animateCourier(scene.courier);
    renderRoute(scene);
    maybeAdjustCamera(scene, kind || 'state');
  }

  function bindBridge(){
    if (app.bridgeBound || !bridge()) return;
    app.bridgeBound = true;
    bridge().subscribe(function(state, kind){
      syncScene(state, kind || 'state');
    });
  }

  function bindTabResize(){
    qsa('.ccv-console-tab[data-view="map"]').forEach(function(tab){
      tab.addEventListener('click', function(){
        ensureGoogleMapsLoaded();
        window.setTimeout(function(){
          if (app.map && window.google && google.maps && google.maps.event) {
            google.maps.event.trigger(app.map, 'resize');
          }
          syncScene(bridge() ? bridge().getState() : app.latestState, 'tab');
        }, 120);
      });
    });
  }

  function boot(){
    bindBridge();
    bindTabResize();

    if (!shouldSyncMap('bootstrap')) {
      return;
    }

    if (app.googleReady) {
      syncScene(bridge() ? bridge().getState() : app.latestState, 'bootstrap');
    } else {
      ensureGoogleMapsLoaded();
    }
  }

  window.CaricoveCourierMap = {
    ensureLoaded: function(){
      ensureGoogleMapsLoaded();
      syncScene(bridge() ? bridge().getState() : app.latestState, 'manual');
    },
    onGoogleReady: function(){
      app.googleLoading = false;
      app.googleReady = true;
      syncScene(bridge() ? bridge().getState() : app.latestState, 'google_ready');
    },
    refresh: function(){
      syncScene(bridge() ? bridge().getState() : app.latestState, 'manual');
    }
  };

  window.CaricoveCourierMapInit = function(){
    app.googleLoading = false;
    app.googleReady = true;
    if (window.CaricoveCourierMap && typeof window.CaricoveCourierMap.onGoogleReady === 'function') {
      window.CaricoveCourierMap.onGoogleReady();
    }
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})(window, document);