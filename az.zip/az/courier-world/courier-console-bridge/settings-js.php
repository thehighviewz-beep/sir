<?php
/**
 * Bridge-owned settings runtime for the courier console.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

add_action(
    'wp_footer',
    function() {
        if ( is_admin() ) {
            return;
        }
        ?>
<script>
(function(window, document){
  'use strict';

  var booted = false;
  var inflight = false;
  var queuedPayload = null;

  function qs(sel, ctx){ return (ctx || document).querySelector(sel); }
  function qsa(sel, ctx){ return Array.prototype.slice.call((ctx || document).querySelectorAll(sel)); }
  function bridge(){ return window.CaricoveCourierBridge || null; }
  function stringVal(value){ return value == null ? '' : String(value); }
  function intVal(value){ var num = parseInt(value || 0, 10); return isFinite(num) ? num : 0; }

  function hasSettingsShell(){
    return !!qs('#ccv-settings-shell') && !!bridge();
  }

  function rangeLabel(value){
    value = stringVal(value || 'local_area');
    if (value === 'very_close') return 'Very Close';
    if (value === 'across_georgetown') return 'Across Georgetown';
    if (value === 'extended_routes') return 'Extended Routes';
    return 'Local Area';
  }

  function toast(message, isError){
    var el = qs('#ccv-settings-toast');
    if (!el) return;
    el.textContent = stringVal(message || (isError ? 'Unable to save settings.' : 'Settings updated — dispatcher adjusted.'));
    el.classList.add('is-show');
    el.classList.toggle('is-error', !!isError);
    window.clearTimeout(window.__ccvSettingsToastTimer);
    window.__ccvSettingsToastTimer = window.setTimeout(function(){
      el.classList.remove('is-show');
      el.classList.remove('is-error');
    }, isError ? 2200 : 1600);
  }

  function syncSettingsUi(settings){
    settings = settings && typeof settings === 'object' ? settings : {};
    var availability = stringVal(settings.availability || 'online');
    if (availability !== 'offline') availability = 'online';
    var maxJobs = intVal(settings.max_jobs || 3);
    if ([1, 3, 5].indexOf(maxJobs) === -1) maxJobs = 3;
    var range = stringVal(settings.range || 'local_area');

    qsa('[data-setting="availability"]').forEach(function(el){
      var active = stringVal(el.getAttribute('data-value')) === availability;
      el.classList.toggle('is-active', active);
      if (el.classList.contains('ccv-set-chip')) {
        el.classList.toggle('is-online', active && availability === 'online');
        el.classList.toggle('is-offline', active && availability === 'offline');
      }
    });

    qsa('[data-setting="max_jobs"]').forEach(function(el){
      el.classList.toggle('is-active', intVal(el.getAttribute('data-value')) === maxJobs);
    });

    qsa('[data-setting="range"]').forEach(function(el){
      el.classList.toggle('is-active', stringVal(el.getAttribute('data-value')) === range);
    });

    var availabilityBadge = qs('[data-bind="availability-badge"]');
    if (availabilityBadge) availabilityBadge.textContent = availability === 'offline' ? 'OFFLINE' : 'ONLINE';

    var maxJobsLabel = qs('[data-bind="maxjobs-label"]');
    if (maxJobsLabel) {
      maxJobsLabel.textContent = maxJobs === 1 ? 'Focused' : (maxJobs === 5 ? 'High Capacity' : 'Balanced');
    }

    var rangeMini = qs('[data-bind="range-label"]');
    if (rangeMini) rangeMini.textContent = rangeLabel(range);
  }

  function getActiveSettingValue(setting){
    var active = qs('[data-setting="' + setting + '"].is-active');
    return active ? stringVal(active.getAttribute('data-value')) : '';
  }

  function queueSave(payload){
    queuedPayload = {
      availability: stringVal(payload.availability || 'online'),
      max_jobs: stringVal(payload.max_jobs || '3'),
      range: stringVal(payload.range || 'local_area')
    };
    if (inflight) return;
    flush();
  }

  function flush(){
    var runtime = bridge();
    if (!runtime || inflight || !queuedPayload) return;

    inflight = true;
    var payload = queuedPayload;
    queuedPayload = null;

    runtime.saveSettings(payload).then(function(resp){
      var nextState = runtime.getState ? runtime.getState() : {};
      if (!resp || !resp.success) {
        syncSettingsUi((nextState && nextState.settings) || payload);
        toast(resp && resp.data && resp.data.message ? resp.data.message : 'Unable to save settings.', true);
        return;
      }

      syncSettingsUi((nextState && nextState.settings) || payload);
      toast(resp && resp.data && resp.data.message ? resp.data.message : 'Settings updated — dispatcher adjusted.', false);

      var activeAvailability = (nextState && nextState.settings && nextState.settings.availability) || payload.availability;
      if (activeAvailability === 'online' && runtime.nudgeHeartbeat) {
        runtime.nudgeHeartbeat('settings_online');
      }
    }).catch(function(){
      var runtimeState = runtime.getState ? runtime.getState() : {};
      syncSettingsUi((runtimeState && runtimeState.settings) || payload);
      toast('Network error — try again.', true);
    }).finally(function(){
      inflight = false;
      if (queuedPayload) flush();
    });
  }

  function bindClicks(){
    var shell = qs('#ccv-settings-shell');
    if (!shell) return;
    shell.addEventListener('click', function(e){
      var btn = e.target.closest('[data-setting]');
      if (!btn) return;

      var setting = stringVal(btn.getAttribute('data-setting'));
      var value = stringVal(btn.getAttribute('data-value'));
      if (!setting || !value) return;

      var preview = {
        availability: getActiveSettingValue('availability') || 'online',
        max_jobs: getActiveSettingValue('max_jobs') || '3',
        range: getActiveSettingValue('range') || 'local_area'
      };
      preview[setting] = value;

      syncSettingsUi(preview);
      queueSave(preview);
    });
  }

  function boot(){
    if (booted || !hasSettingsShell()) return;
    booted = true;

    var runtime = bridge();
    if (!runtime) return;

    syncSettingsUi((runtime.getState() || {}).settings || {});
    bindClicks();
    runtime.subscribe(function(nextState){
      syncSettingsUi((nextState && nextState.settings) || {});
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }

  window.addEventListener('load', boot);

  var tries = 0;
  var timer = window.setInterval(function(){
    tries += 1;
    if (hasSettingsShell()) {
      boot();
      window.clearInterval(timer);
      return;
    }
    if (tries >= 20) {
      window.clearInterval(timer);
    }
  }, 1000);
})(window, document);
</script>
        <?php
    },
    999
);
