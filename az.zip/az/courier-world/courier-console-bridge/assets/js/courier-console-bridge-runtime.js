(function(window, document){
  'use strict';

  function parseBootstrap(){
    var el = document.getElementById('ccv-courier-bridge-bootstrap');
    if (!el) return null;
    try {
      return JSON.parse(el.textContent || '{}');
    } catch (err) {
      return null;
    }
  }

  function isObject(value){
    return !!value && typeof value === 'object' && !Array.isArray(value);
  }

  function clone(value){
    return JSON.parse(JSON.stringify(value));
  }

  var bootstrap = parseBootstrap();
  if (!bootstrap) return;

  var listeners = [];
  var refreshTimer = null;
  var heartbeatTimer = null;
  var heartbeatWatchId = null;
  var lastBeatAt = 0;
  var started = false;
  var refreshInFlight = false;
  var actionInFlight = 0;
  var queuedRefreshReason = '';
  var refreshRequestId = 0;
  var latestAppliedRefreshId = 0;

  function normalizeJobs(rawJobs){
    var buckets = { incoming: [], assigned: [], queued: [] };
    rawJobs = isObject(rawJobs) ? rawJobs : {};
    ['incoming','assigned','queued'].forEach(function(bucket){
      buckets[bucket] = Array.isArray(rawJobs[bucket]) ? rawJobs[bucket].map(normalizeJob) : [];
    });
    return buckets;
  }

  function normalizeJob(job){
    job = isObject(job) ? job : {};
    var normalized = clone(job);
    normalized.job_id = String(job.job_id || '');
    normalized.status = String(job.status || '');
    normalized.status_label = String(job.status_label || '');
    normalized.queue_bucket = String(job.queue_bucket || '');
    normalized.next_state = String(job.next_state || '');
    normalized.next_state_label = String(job.next_state_label || '');
    normalized.offer_is_live = !!job.offer_is_live;
    normalized.requires_code = !!job.requires_code;
    normalized.offer_expires_at = Number(job.offer_expires_at || 0);
    normalized.deadline_ts = Number(job.deadline_ts || 0);
    normalized.quote_total_gyd = Number(job.quote_total_gyd || 0);
    return normalized;
  }

  function firstAvailableJobId(jobs){
    var preferred = jobs.assigned[0] || jobs.incoming[0] || jobs.queued[0] || null;
    return preferred ? String(preferred.job_id || '') : '';
  }

  function normalizeState(rawState){
    rawState = isObject(rawState) ? rawState : {};
    var jobs = normalizeJobs(rawState.jobs || {});
    var state = {
      courier_id: Number(rawState.courier_id || 0),
      generated_at: Number(rawState.generated_at || 0),
      jobs: jobs,
      balances: isObject(rawState.balances) ? rawState.balances : { available: 0, clearing: 0, held: 0, currency: 'GYD' },
      settings: isObject(rawState.settings) ? rawState.settings : { availability: 'online', max_jobs: 3, range: 'local_area', radius_km: 7 },
      payout_method: isObject(rawState.payout_method) ? rawState.payout_method : { configured: false, type: '', destination_label: 'No payout method saved' },
      mission: isObject(rawState.mission) ? rawState.mission : { active_job_id: 0, active_job: null, incoming_count: 0, assigned_count: 0, queued_count: 0, has_live_offer: false },
      focus_job_id: String(rawState.focus_job_id || ''),
    };

    if (!state.focus_job_id) {
      state.focus_job_id = firstAvailableJobId(jobs);
    }

    if (state.focus_job_id && !findJobById(state, state.focus_job_id)) {
      state.focus_job_id = firstAvailableJobId(jobs);
    }

    return state;
  }

  var state = normalizeState(bootstrap.state || {});

  function emit(kind){
    var snapshot = bridge.getState();
    listeners.slice().forEach(function(listener){
      try { listener(snapshot, kind || 'state'); } catch (err) {}
    });
    try {
      window.dispatchEvent(new CustomEvent('caricove:courier-bridge-state', { detail: { state: snapshot, kind: kind || 'state' } }));
    } catch (err) {}
  }

  function setState(nextState, kind){
    state = normalizeState(nextState || {});
    emit(kind || 'state');
    return bridge.getState();
  }

  function findJobById(currentState, jobId){
    jobId = String(jobId || '');
    if (!jobId) return null;
    var buckets = currentState.jobs || {};
    var list = []
      .concat(buckets.assigned || [])
      .concat(buckets.incoming || [])
      .concat(buckets.queued || []);
    for (var i = 0; i < list.length; i++) {
      if (String(list[i].job_id || '') === jobId) return list[i];
    }
    return null;
  }

  function ajax(action, payload, nonce){
    var form = new FormData();
    form.append('action', action);
    if (nonce) form.append('nonce', nonce);
    payload = isObject(payload) ? payload : {};
    Object.keys(payload).forEach(function(key){
      if (payload[key] === null || typeof payload[key] === 'undefined') return;
      form.append(key, payload[key]);
    });

    return fetch(bootstrap.ajax_url, {
      method: 'POST',
      credentials: 'same-origin',
      body: form,
    }).then(function(response){
      return response.json();
    });
  }


  function refreshIntervalMs(){
    return document.visibilityState === 'hidden' ? 15000 : 5000;
  }

  function queueRefresh(reason){
    reason = String(reason || 'deferred');
    if (!queuedRefreshReason || reason === 'visible' || reason === 'focus' || reason === 'deferred') {
      queuedRefreshReason = reason;
    }
  }

  function flushQueuedRefresh(){
    if (!queuedRefreshReason || refreshInFlight || actionInFlight > 0) return Promise.resolve(bridge.getState());
    var reason = queuedRefreshReason;
    queuedRefreshReason = '';
    return refresh(reason);
  }

  function beginAction(){
    actionInFlight += 1;
  }

  function endAction(){
    actionInFlight = Math.max(0, actionInFlight - 1);
    flushQueuedRefresh();
  }

  function withActionLock(work){
    beginAction();
    return work.finally(function(){
      endAction();
    });
  }

  function setFocusedJob(jobId){
    jobId = String(jobId || '');
    if (jobId && !findJobById(state, jobId)) return bridge.getState();
    state.focus_job_id = jobId || firstAvailableJobId(state.jobs);
    emit('focus');
    return bridge.getState();
  }

  function refresh(reason){
    reason = String(reason || 'poll');

    if (refreshInFlight) {
      queueRefresh(reason);
      return Promise.resolve(bridge.getState());
    }

    if (actionInFlight > 0 && (reason === 'interval' || reason === 'poll' || reason === 'boot' || reason === 'visible' || reason === 'focus')) {
      queueRefresh(reason);
      return Promise.resolve(bridge.getState());
    }

    if (document.visibilityState === 'hidden' && (reason === 'interval' || reason === 'poll')) {
      return Promise.resolve(bridge.getState());
    }

    refreshInFlight = true;
    var requestId = ++refreshRequestId;

    return ajax(bootstrap.actions.state, { reason: reason }, bootstrap.nonces.state).then(function(resp){
      if (!resp || !resp.success || !resp.data || !resp.data.state) {
        return bridge.getState();
      }
      if (requestId < latestAppliedRefreshId) {
        return bridge.getState();
      }
      latestAppliedRefreshId = requestId;
      var next = resp.data.state;
      next.focus_job_id = state.focus_job_id || next.focus_job_id || '';
      return setState(next, 'refresh');
    }).catch(function(){
      return bridge.getState();
    }).finally(function(){
      refreshInFlight = false;
      flushQueuedRefresh();
    });
  }

  function applyActionResponse(resp, kind){
    if (!resp || !resp.success) return resp;
    if (resp.data && resp.data.state) {
      var next = resp.data.state;
      next.focus_job_id = state.focus_job_id || next.focus_job_id || '';
      setState(next, kind || 'action');
    }
    return resp;
  }

  function acceptOffer(jobId){
    return withActionLock(
      ajax(bootstrap.actions.accept_offer, { job_id: String(jobId || '') }, bootstrap.nonces.trip).then(function(resp){
        return applyActionResponse(resp, 'offer_accept');
      })
    );
  }

  function rejectOffer(jobId){
    return withActionLock(
      ajax(bootstrap.actions.reject_offer, { job_id: String(jobId || '') }, bootstrap.nonces.trip).then(function(resp){
        return applyActionResponse(resp, 'offer_reject');
      })
    );
  }

  function transition(payload){
    payload = isObject(payload) ? payload : {};
    var action = '';
    var formPayload = { job_id: String(payload.job_id || '') };
    if (payload.to_state === 'en_route') action = bootstrap.actions.start_trip;
    if (payload.to_state === 'pickup_code') action = bootstrap.actions.verify_pickup;
    if (payload.to_state === 'delivered') action = bootstrap.actions.verify_delivery;
    if (!action) return Promise.resolve({ success: false, data: { message: 'Unknown transition.' } });
    if ((payload.to_state === 'pickup_code' || payload.to_state === 'delivered') && payload.code) {
      formPayload.code = String(payload.code || '');
    }

    try {
      window.dispatchEvent(new CustomEvent('caricove:courier-status-change', { detail: payload }));
    } catch (err) {}

    return withActionLock(
      ajax(action, formPayload, bootstrap.nonces.trip).then(function(resp){
        return applyActionResponse(resp, 'transition');
      })
    );
  }

  function saveSettings(payload){
    payload = isObject(payload) ? payload : {};
    return withActionLock(
      ajax(bootstrap.actions.save_settings, payload, bootstrap.nonces.settings).then(function(resp){
        return applyActionResponse(resp, 'settings');
      })
    );
  }

  function savePayoutMethod(payload){
    payload = isObject(payload) ? payload : {};
    return withActionLock(
      ajax(bootstrap.actions.save_payout_method, payload, bootstrap.nonces.payout_method).then(function(resp){
        return applyActionResponse(resp, 'payout_method');
      })
    );
  }

  function requestPayout(payload){
    payload = isObject(payload) ? payload : {};
    return withActionLock(
      ajax(bootstrap.actions.payout, {
        amount: String(payload.amount || ''),
        type: String(payload.type || 'scheduled')
      }, bootstrap.nonces.payout).then(function(resp){
        if (resp && resp.success && (!resp.data || !resp.data.state)) {
          queueRefresh('payout');
        }
        return applyActionResponse(resp, 'payout');
      })
    );
  }

  function sendHeartbeat(lat, lng, reason){
    var now = Date.now();
    if (now - lastBeatAt < Number(bootstrap.heartbeat.minimum_gap_ms || 3000)) {
      return;
    }
    lastBeatAt = now;

    var restPayload = { reason: reason || 'tick' };
    if (typeof lat === 'number' && typeof lng === 'number') {
      restPayload.lat = lat;
      restPayload.lng = lng;
    }

    var restHeaders = {
      'Content-Type': 'application/json',
      'X-WP-Nonce': bootstrap.nonces.rest
    };

    function ajaxFallback(fallbackReason){
      ajax(bootstrap.actions.heartbeat_ajax, {
        lat: typeof lat === 'number' ? String(lat) : '',
        lng: typeof lng === 'number' ? String(lng) : '',
        reason: fallbackReason || reason || 'fallback'
      }, bootstrap.nonces.heartbeat).catch(function(){});
    }

    fetch(bootstrap.heartbeat.core_url, {
      method: 'POST',
      credentials: 'same-origin',
      headers: restHeaders,
      body: JSON.stringify(restPayload)
    }).then(function(resp){
      if (resp && (resp.status === 200 || resp.status === 201)) return true;
      return fetch(bootstrap.heartbeat.proxy_url, {
        method: 'POST',
        credentials: 'same-origin',
        headers: restHeaders,
        body: JSON.stringify(restPayload)
      }).then(function(proxyResp){
        if (proxyResp && (proxyResp.status === 200 || proxyResp.status === 201)) return true;
        ajaxFallback('rest_failed');
        return false;
      }).catch(function(){
        ajaxFallback('proxy_failed');
        return false;
      });
    }).catch(function(){
      ajaxFallback('core_failed');
      return false;
    });
  }

  function heartbeatTick(reason){
    if (!navigator.geolocation || !navigator.geolocation.getCurrentPosition) {
      sendHeartbeat(null, null, reason || 'no_geo');
      return;
    }

    navigator.geolocation.getCurrentPosition(function(position){
      sendHeartbeat(position.coords.latitude, position.coords.longitude, reason || 'gps_tick');
    }, function(){
      sendHeartbeat(null, null, reason || 'gps_denied');
    }, {
      enableHighAccuracy: true,
      maximumAge: 5000,
      timeout: 8000
    });
  }

  function startHeartbeat(){
    if (heartbeatTimer) window.clearInterval(heartbeatTimer);
    heartbeatTick('boot');
    heartbeatTimer = window.setInterval(function(){
      heartbeatTick('interval');
    }, Number(bootstrap.heartbeat.interval_ms || 15000));

    if (navigator.geolocation && navigator.geolocation.watchPosition) {
      try {
        if (heartbeatWatchId) navigator.geolocation.clearWatch(heartbeatWatchId);
        heartbeatWatchId = navigator.geolocation.watchPosition(function(position){
          sendHeartbeat(position.coords.latitude, position.coords.longitude, 'watch_move');
        }, function(){}, {
          enableHighAccuracy: true,
          maximumAge: 2000,
          timeout: 12000
        });
      } catch (err) {}
    }
  }

  function startRefreshLoop(runImmediate){
    if (refreshTimer) window.clearInterval(refreshTimer);
    refreshTimer = window.setInterval(function(){
      refresh(document.visibilityState === 'hidden' ? 'poll' : 'interval');
    }, refreshIntervalMs());
    if (runImmediate !== false) {
      refresh('boot');
    }
  }

  function start(){
    if (started) return bridge.getState();
    started = true;
    emit('bootstrap');
    startHeartbeat();
    startRefreshLoop(true);
    document.addEventListener('visibilitychange', function(){
      startRefreshLoop(false);
      if (document.visibilityState === 'visible') {
        refresh('visible');
        heartbeatTick('visible');
      }
    });
    window.addEventListener('focus', function(){
      refresh('focus');
      heartbeatTick('focus');
    });
    return bridge.getState();
  }

  var bridge = {
    start: start,
    getState: function(){ return clone(state); },
    subscribe: function(listener){
      if (typeof listener !== 'function') return function(){};
      listeners.push(listener);
      try { listener(bridge.getState(), 'subscribe'); } catch (err) {}
      return function(){
        listeners = listeners.filter(function(item){ return item !== listener; });
      };
    },
    refresh: refresh,
    setFocusedJob: setFocusedJob,
    findJobById: function(jobId){
      var found = findJobById(state, jobId);
      return found ? clone(found) : null;
    },
    acceptOffer: acceptOffer,
    rejectOffer: rejectOffer,
    transition: transition,
    saveSettings: saveSettings,
    savePayoutMethod: savePayoutMethod,
    requestPayout: requestPayout,
    nudgeHeartbeat: heartbeatTick,
    ajax: ajax
  };

  window.CaricoveCourierBridge = bridge;
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function(){ bridge.start(); });
  } else {
    bridge.start();
  }
})(window, document);
