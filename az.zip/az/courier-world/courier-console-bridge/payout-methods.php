<?php
/**
 * Caricove Courier Console Bridge — Payout Method Profiles.
 *
 * Pre-live payout destination layer for couriers:
 * - MMG mobile payout profile
 * - Bank transfer profile
 * - Card payout placeholder/token profile
 *
 * This file stores courier payout destinations and exposes them to the courier
 * console + Caricove Bank payout queue. It does not move money.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! function_exists( 'ccv_ccb_payout_method_meta_key' ) ) {
    function ccv_ccb_payout_method_meta_key() {
        return '_ccv_courier_payout_method_v1';
    }
}

if ( ! function_exists( 'ccv_ccb_payout_method_types' ) ) {
    function ccv_ccb_payout_method_types() {
        return array(
            'mmg'  => 'MMG mobile money',
            'card' => 'Card payout',
            'bank' => 'Bank transfer',
        );
    }
}

if ( ! function_exists( 'ccv_ccb_payout_method_type_label' ) ) {
    function ccv_ccb_payout_method_type_label( $type ) {
        $type  = sanitize_key( (string) $type );
        $types = ccv_ccb_payout_method_types();
        return (string) ( $types[ $type ] ?? 'Not set' );
    }
}

if ( ! function_exists( 'ccv_ccb_payout_digits' ) ) {
    function ccv_ccb_payout_digits( $value ) {
        return preg_replace( '/\D+/', '', (string) $value );
    }
}

if ( ! function_exists( 'ccv_ccb_payout_last4' ) ) {
    function ccv_ccb_payout_last4( $value ) {
        $digits = ccv_ccb_payout_digits( $value );
        if ( strlen( $digits ) < 4 ) {
            return '';
        }
        return substr( $digits, -4 );
    }
}

if ( ! function_exists( 'ccv_ccb_payout_mask' ) ) {
    function ccv_ccb_payout_mask( $last4 ) {
        $last4 = ccv_ccb_payout_last4( $last4 );
        return $last4 !== '' ? '••••' . $last4 : 'Not set';
    }
}

if ( ! function_exists( 'ccv_ccb_payout_clean_phone' ) ) {
    function ccv_ccb_payout_clean_phone( $value ) {
        $value = trim( (string) $value );
        $value = preg_replace( '/[^0-9+]/', '', $value );
        return substr( $value, 0, 32 );
    }
}

if ( ! function_exists( 'ccv_ccb_payout_clean_account' ) ) {
    function ccv_ccb_payout_clean_account( $value ) {
        $value = trim( (string) $value );
        $value = preg_replace( '/[^0-9A-Za-z\-\s]/', '', $value );
        return substr( $value, 0, 80 );
    }
}

if ( ! function_exists( 'ccv_ccb_payout_secret_key' ) ) {
    function ccv_ccb_payout_secret_key() {
        $salt = '';
        if ( defined( 'AUTH_KEY' ) && AUTH_KEY ) {
            $salt .= AUTH_KEY;
        }
        if ( defined( 'SECURE_AUTH_KEY' ) && SECURE_AUTH_KEY ) {
            $salt .= SECURE_AUTH_KEY;
        }
        if ( function_exists( 'wp_salt' ) ) {
            $salt .= wp_salt( 'auth' );
        }
        if ( '' === $salt ) {
            $salt = 'caricove-courier-payout-method-v1';
        }
        return hash( 'sha256', $salt . '|ccv-courier-payout-method-v1', true );
    }
}

if ( ! function_exists( 'ccv_ccb_payout_encrypt_secret' ) ) {
    function ccv_ccb_payout_encrypt_secret( $plain ) {
        $plain = (string) $plain;
        if ( '' === $plain || ! function_exists( 'openssl_encrypt' ) ) {
            return '';
        }

        try {
            $iv = function_exists( 'random_bytes' ) ? random_bytes( 16 ) : substr( hash( 'sha256', uniqid( '', true ), true ), 0, 16 );
        } catch ( Exception $e ) {
            $iv = substr( hash( 'sha256', uniqid( '', true ), true ), 0, 16 );
        }

        $cipher = openssl_encrypt( $plain, 'AES-256-CBC', ccv_ccb_payout_secret_key(), OPENSSL_RAW_DATA, $iv );
        if ( false === $cipher ) {
            return '';
        }

        return 'enc:v1:' . base64_encode( $iv . $cipher );
    }
}

if ( ! function_exists( 'ccv_ccb_payout_decrypt_secret' ) ) {
    function ccv_ccb_payout_decrypt_secret( $payload ) {
        $payload = (string) $payload;
        if ( '' === $payload || 0 !== strpos( $payload, 'enc:v1:' ) || ! function_exists( 'openssl_decrypt' ) ) {
            return '';
        }

        $raw = base64_decode( substr( $payload, 7 ), true );
        if ( ! is_string( $raw ) || strlen( $raw ) <= 16 ) {
            return '';
        }

        $iv     = substr( $raw, 0, 16 );
        $cipher = substr( $raw, 16 );
        $plain  = openssl_decrypt( $cipher, 'AES-256-CBC', ccv_ccb_payout_secret_key(), OPENSSL_RAW_DATA, $iv );

        return is_string( $plain ) ? $plain : '';
    }
}

if ( ! function_exists( 'ccv_ccb_payout_configured' ) ) {
    function ccv_ccb_payout_configured( array $profile ) {
        $type = sanitize_key( (string) ( $profile['type'] ?? '' ) );

        if ( 'mmg' === $type ) {
            return ! empty( $profile['holder_name'] ) && ! empty( $profile['phone_last4'] );
        }

        if ( 'bank' === $type ) {
            return ! empty( $profile['bank_name'] ) && ! empty( $profile['bank_account_name'] ) && ! empty( $profile['bank_account_last4'] );
        }

        if ( 'card' === $type ) {
            return ! empty( $profile['cardholder_name'] ) && ! empty( $profile['card_last4'] );
        }

        return false;
    }
}

if ( ! function_exists( 'ccv_ccb_payout_destination_label' ) ) {
    function ccv_ccb_payout_destination_label( array $profile ) {
        $type = sanitize_key( (string) ( $profile['type'] ?? '' ) );

        if ( 'mmg' === $type ) {
            return 'MMG • ' . ccv_ccb_payout_mask( (string) ( $profile['phone_last4'] ?? '' ) );
        }

        if ( 'bank' === $type ) {
            $bank = trim( (string) ( $profile['bank_name'] ?? 'Bank' ) );
            return 'Bank transfer • ' . $bank . ' • ' . ccv_ccb_payout_mask( (string) ( $profile['bank_account_last4'] ?? '' ) );
        }

        if ( 'card' === $type ) {
            $brand = trim( (string) ( $profile['card_brand'] ?? 'Card' ) );
            return 'Card payout • ' . $brand . ' • ' . ccv_ccb_payout_mask( (string) ( $profile['card_last4'] ?? '' ) );
        }

        return 'No payout method saved';
    }
}

if ( ! function_exists( 'ccv_ccb_sanitize_payout_profile' ) ) {
    function ccv_ccb_sanitize_payout_profile( $raw ) {
        $raw = is_array( $raw ) ? $raw : array();
        $type = sanitize_key( (string) ( $raw['type'] ?? '' ) );
        if ( ! array_key_exists( $type, ccv_ccb_payout_method_types() ) ) {
            $type = '';
        }

        $profile = array(
            'schema'                => 'courier_payout_method_v1',
            'type'                  => $type,
            'type_label'            => ccv_ccb_payout_method_type_label( $type ),
            'holder_name'           => sanitize_text_field( (string) ( $raw['holder_name'] ?? '' ) ),
            'phone'                 => ccv_ccb_payout_clean_phone( (string) ( $raw['phone'] ?? '' ) ),
            'phone_last4'           => ccv_ccb_payout_last4( (string) ( $raw['phone_last4'] ?? $raw['phone'] ?? '' ) ),
            'bank_name'             => sanitize_text_field( (string) ( $raw['bank_name'] ?? '' ) ),
            'bank_account_name'     => sanitize_text_field( (string) ( $raw['bank_account_name'] ?? '' ) ),
            'bank_account_last4'    => ccv_ccb_payout_last4( (string) ( $raw['bank_account_last4'] ?? '' ) ),
            'bank_account_secret'   => sanitize_text_field( (string) ( $raw['bank_account_secret'] ?? '' ) ),
            'bank_account_type'     => sanitize_key( (string) ( $raw['bank_account_type'] ?? 'savings' ) ),
            'cardholder_name'       => sanitize_text_field( (string) ( $raw['cardholder_name'] ?? '' ) ),
            'card_brand'            => sanitize_text_field( (string) ( $raw['card_brand'] ?? '' ) ),
            'card_last4'            => ccv_ccb_payout_last4( (string) ( $raw['card_last4'] ?? '' ) ),
            'processor_token_ref'   => sanitize_text_field( (string) ( $raw['processor_token_ref'] ?? '' ) ),
            'processor_status'      => sanitize_key( (string) ( $raw['processor_status'] ?? 'standby' ) ),
            'updated_at'            => sanitize_text_field( (string) ( $raw['updated_at'] ?? '' ) ),
            'updated_by'            => intval( $raw['updated_by'] ?? 0 ),
        );

        if ( ! in_array( $profile['bank_account_type'], array( 'savings', 'chequing', 'current', 'other' ), true ) ) {
            $profile['bank_account_type'] = 'savings';
        }

        $profile['configured']        = ccv_ccb_payout_configured( $profile );
        $profile['destination_label'] = ccv_ccb_payout_destination_label( $profile );
        $profile['money_movement']    = 'standby_until_provider_rails_live';

        return $profile;
    }
}

if ( ! function_exists( 'ccv_ccb_get_payout_method_for_courier' ) ) {
    function ccv_ccb_get_payout_method_for_courier( $courier_id ) {
        $courier_id = intval( $courier_id );
        $raw        = $courier_id > 0 ? get_user_meta( $courier_id, ccv_ccb_payout_method_meta_key(), true ) : array();
        $profile    = ccv_ccb_sanitize_payout_profile( is_array( $raw ) ? $raw : array() );

        unset( $profile['bank_account_secret'] );
        unset( $profile['phone'] );

        return $profile;
    }
}

if ( ! function_exists( 'ccv_ccb_payout_method_request_snapshot' ) ) {
    function ccv_ccb_payout_method_request_snapshot( $courier_id ) {
        $profile = ccv_ccb_get_payout_method_for_courier( $courier_id );
        return array(
            'schema'            => 'courier_payout_request_method_snapshot_v1',
            'type'              => (string) ( $profile['type'] ?? '' ),
            'type_label'        => (string) ( $profile['type_label'] ?? '' ),
            'destination_label' => (string) ( $profile['destination_label'] ?? '' ),
            'configured'        => ! empty( $profile['configured'] ),
            'processor_status'  => (string) ( $profile['processor_status'] ?? 'standby' ),
            'money_movement'    => (string) ( $profile['money_movement'] ?? 'standby_until_provider_rails_live' ),
            'updated_at'        => (string) ( $profile['updated_at'] ?? '' ),
        );
    }
}

if ( ! function_exists( 'ccv_ccb_update_payout_method_for_courier' ) ) {
    function ccv_ccb_update_payout_method_for_courier( $courier_id, array $payload ) {
        $courier_id = intval( $courier_id );
        if ( $courier_id <= 0 ) {
            return new WP_Error( 'bad_courier', 'Courier profile unavailable.' );
        }

        $existing_raw = get_user_meta( $courier_id, ccv_ccb_payout_method_meta_key(), true );
        $existing     = is_array( $existing_raw ) ? $existing_raw : array();

        $type = sanitize_key( (string) ( $payload['method_type'] ?? $payload['type'] ?? '' ) );
        if ( ! array_key_exists( $type, ccv_ccb_payout_method_types() ) ) {
            return new WP_Error( 'bad_type', 'Choose MMG, card payout, or bank transfer.' );
        }

        $next = array(
            'schema'           => 'courier_payout_method_v1',
            'type'             => $type,
            'processor_status' => 'standby',
            'updated_at'       => current_time( 'mysql' ),
            'updated_by'       => $courier_id,
        );

        if ( 'mmg' === $type ) {
            $holder = sanitize_text_field( wp_unslash( (string) ( $payload['holder_name'] ?? '' ) ) );
            $phone  = ccv_ccb_payout_clean_phone( wp_unslash( (string) ( $payload['phone'] ?? '' ) ) );
            $digits = ccv_ccb_payout_digits( $phone );

            if ( '' === $holder ) {
                return new WP_Error( 'missing_holder', 'Enter the registered MMG name.' );
            }
            if ( strlen( $digits ) < 6 ) {
                return new WP_Error( 'missing_phone', 'Enter a valid MMG mobile number.' );
            }

            $next['holder_name'] = $holder;
            $next['phone']       = $phone;
            $next['phone_last4'] = substr( $digits, -4 );
        }

        if ( 'bank' === $type ) {
            $bank_name    = sanitize_text_field( wp_unslash( (string) ( $payload['bank_name'] ?? '' ) ) );
            $account_name = sanitize_text_field( wp_unslash( (string) ( $payload['bank_account_name'] ?? '' ) ) );
            $account_type = sanitize_key( wp_unslash( (string) ( $payload['bank_account_type'] ?? 'savings' ) ) );
            $account      = ccv_ccb_payout_clean_account( wp_unslash( (string) ( $payload['bank_account_number'] ?? '' ) ) );

            if ( '' === $bank_name ) {
                return new WP_Error( 'missing_bank', 'Enter the bank name.' );
            }
            if ( '' === $account_name ) {
                return new WP_Error( 'missing_account_name', 'Enter the account holder name.' );
            }
            if ( ! in_array( $account_type, array( 'savings', 'chequing', 'current', 'other' ), true ) ) {
                $account_type = 'savings';
            }

            $secret = '';
            $last4  = '';
            if ( '' !== $account ) {
                $secret = ccv_ccb_payout_encrypt_secret( $account );
                $last4  = ccv_ccb_payout_last4( $account );
            } elseif ( 'bank' === (string) ( $existing['type'] ?? '' ) ) {
                $secret = sanitize_text_field( (string) ( $existing['bank_account_secret'] ?? '' ) );
                $last4  = ccv_ccb_payout_last4( (string) ( $existing['bank_account_last4'] ?? '' ) );
            }

            if ( '' === $last4 ) {
                return new WP_Error( 'missing_account', 'Enter the bank account number.' );
            }

            $next['bank_name']           = $bank_name;
            $next['bank_account_name']   = $account_name;
            $next['bank_account_type']   = $account_type;
            $next['bank_account_last4']  = $last4;
            $next['bank_account_secret'] = $secret;
        }

        if ( 'card' === $type ) {
            $cardholder = sanitize_text_field( wp_unslash( (string) ( $payload['cardholder_name'] ?? '' ) ) );
            $brand      = sanitize_text_field( wp_unslash( (string) ( $payload['card_brand'] ?? '' ) ) );
            $last4      = ccv_ccb_payout_last4( wp_unslash( (string) ( $payload['card_last4'] ?? '' ) ) );
            $token_ref  = sanitize_text_field( wp_unslash( (string) ( $payload['processor_token_ref'] ?? '' ) ) );

            if ( '' === $cardholder ) {
                return new WP_Error( 'missing_cardholder', 'Enter the cardholder name.' );
            }
            if ( '' === $brand ) {
                $brand = 'Card';
            }
            if ( '' === $last4 && 'card' === (string) ( $existing['type'] ?? '' ) ) {
                $last4 = ccv_ccb_payout_last4( (string) ( $existing['card_last4'] ?? '' ) );
            }
            if ( '' === $last4 ) {
                return new WP_Error( 'missing_card_last4', 'Enter the last 4 digits of the payout card.' );
            }

            $next['cardholder_name']     = $cardholder;
            $next['card_brand']          = $brand;
            $next['card_last4']          = $last4;
            $next['processor_token_ref'] = $token_ref;
            $next['processor_status']    = $token_ref !== '' ? 'token_reference_saved' : 'token_pending';
        }

        $next = ccv_ccb_sanitize_payout_profile( $next );

        if ( empty( $next['configured'] ) ) {
            return new WP_Error( 'incomplete_profile', 'Payout method is incomplete.' );
        }

        update_user_meta( $courier_id, ccv_ccb_payout_method_meta_key(), $next );

        return ccv_ccb_get_payout_method_for_courier( $courier_id );
    }
}

if ( ! function_exists( 'ccv_ccb_ajax_save_payout_method' ) ) {
    function ccv_ccb_ajax_save_payout_method() {
        if ( ! is_user_logged_in() ) {
            wp_send_json_error( array( 'message' => 'Not logged in' ), 401 );
        }

        $nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
        if ( ! wp_verify_nonce( $nonce, 'caricove_courier_payout_method' ) ) {
            wp_send_json_error( array( 'message' => 'Bad nonce' ), 403 );
        }

        $courier_id = get_current_user_id();
        $method     = ccv_ccb_update_payout_method_for_courier( $courier_id, $_POST );

        if ( is_wp_error( $method ) ) {
            wp_send_json_error( array( 'message' => $method->get_error_message() ), 400 );
        }

        $response = array(
            'message'       => 'Payout method saved. Courier payouts are processor-ready.',
            'payout_method' => $method,
        );

        if ( function_exists( 'ccv_ccb_get_runtime_payload' ) ) {
            $response['state'] = ccv_ccb_get_runtime_payload( $courier_id );
        }

        wp_send_json_success( $response );
    }
}
add_action( 'wp_ajax_caricove_courier_save_payout_method', 'ccv_ccb_ajax_save_payout_method' );

add_action(
    'caricove_logistics_scaffold_payout_method',
    function( $courier_id ) {
        $courier_id = intval( $courier_id );
        if ( ! $courier_id ) {
            return;
        }

        $profile = ccv_ccb_get_payout_method_for_courier( $courier_id );
        $type    = sanitize_key( (string) ( $profile['type'] ?? 'mmg' ) );
        if ( ! array_key_exists( $type, ccv_ccb_payout_method_types() ) ) {
            $type = 'mmg';
        }
        ?>
        <div class="ccv-payout-method-shell" id="ccv-payout-method-shell" data-current-type="<?php echo esc_attr( $type ); ?>">
            <div class="ccv-pm-hero">
                <div>
                    <div class="ccv-pm-kicker">Courier receiving profile</div>
                    <div class="ccv-pm-title"></div>
                    <div class="ccv-pm-sub"></div>
                </div>
                <div class="ccv-pm-status <?php echo ! empty( $profile['configured'] ) ? 'is-ready' : 'is-missing'; ?>">
                    <span data-pm-status-word><?php echo ! empty( $profile['configured'] ) ? 'READY' : 'NEEDS SETUP'; ?></span>
                    <small data-pm-active-label><?php echo esc_html( (string) ( $profile['destination_label'] ?? 'No payout method saved' ) ); ?></small>
                </div>
            </div>

            <div class="ccv-pm-rail-note">
                Money movement is still locked until Caricove Bank receives live provider credentials. This tab saves the destination profile now so payouts can be powered up later without redesigning the courier console.
            </div>

            <div class="ccv-pm-options" role="tablist" aria-label="Payout method choices">
                <button type="button" class="ccv-pm-option <?php echo 'mmg' === $type ? 'is-active' : ''; ?>" data-pm-type="mmg">
                    <strong>MMG</strong><span>Mobile money payout</span>
                </button>
                <button type="button" class="ccv-pm-option <?php echo 'card' === $type ? 'is-active' : ''; ?>" data-pm-type="card">
                    <strong>Card</strong><span>Debit/card payout profile</span>
                </button>
                <button type="button" class="ccv-pm-option <?php echo 'bank' === $type ? 'is-active' : ''; ?>" data-pm-type="bank">
                    <strong>Bank</strong><span>Bank transfer</span>
                </button>
            </div>

            <form class="ccv-pm-form" id="ccv-payout-method-form" autocomplete="off">
                <input type="hidden" name="method_type" id="ccv-pm-method-type" value="<?php echo esc_attr( $type ); ?>">

                <div class="ccv-pm-panel" data-pm-panel="mmg">
                    <label>Registered MMG name
                        <input type="text" name="holder_name" value="<?php echo esc_attr( (string) ( $profile['holder_name'] ?? '' ) ); ?>" placeholder="Name on MMG account">
                    </label>
                    <label>MMG mobile number
                        <input type="tel" name="phone" value="" placeholder="+592 mobile number">
                        <small>Saved number is displayed masked. Re-enter it only when changing the MMG destination.</small>
                    </label>
                </div>

                <div class="ccv-pm-panel" data-pm-panel="card">
                    <label>Cardholder name
                        <input type="text" name="cardholder_name" value="<?php echo esc_attr( (string) ( $profile['cardholder_name'] ?? '' ) ); ?>" placeholder="Name on payout card">
                    </label>
                    <label>Card brand
                        <select name="card_brand">
                            <?php
                            $brand = (string) ( $profile['card_brand'] ?? '' );
                            foreach ( array( 'Visa', 'Mastercard', 'Debit Card', 'Other Card' ) as $opt ) {
                                echo '<option value="' . esc_attr( $opt ) . '" ' . selected( $brand, $opt, false ) . '>' . esc_html( $opt ) . '</option>';
                            }
                            ?>
                        </select>
                    </label>
                    <label>Last 4 digits only
                        <input type="text" name="card_last4" inputmode="numeric" maxlength="4" value="<?php echo esc_attr( (string) ( $profile['card_last4'] ?? '' ) ); ?>" placeholder="1234">
                        <small>Do not enter full card numbers or CVV. Provider token wiring comes later.</small>
                    </label>
                    <label>Processor token/reference
                        <input type="text" name="processor_token_ref" value="<?php echo esc_attr( (string) ( $profile['processor_token_ref'] ?? '' ) ); ?>" placeholder="Optional after provider setup">
                    </label>
                </div>

                <div class="ccv-pm-panel" data-pm-panel="bank">
                    <label>Bank name
                        <input type="text" name="bank_name" value="<?php echo esc_attr( (string) ( $profile['bank_name'] ?? '' ) ); ?>" placeholder="Bank name">
                    </label>
                    <label>Account holder name
                        <input type="text" name="bank_account_name" value="<?php echo esc_attr( (string) ( $profile['bank_account_name'] ?? '' ) ); ?>" placeholder="Name on bank account">
                    </label>
                    <label>Account number
                        <input type="text" name="bank_account_number" value="" placeholder="Enter/update account number">
                        <small>Stored encrypted when server crypto is available; shown to staff only as masked last 4.</small>
                    </label>
                    <label>Account type
                        <select name="bank_account_type">
                            <?php
                            $acct_type = (string) ( $profile['bank_account_type'] ?? 'savings' );
                            $acct_opts = array( 'savings' => 'Savings', 'chequing' => 'Chequing', 'current' => 'Current', 'other' => 'Other' );
                            foreach ( $acct_opts as $key => $label ) {
                                echo '<option value="' . esc_attr( $key ) . '" ' . selected( $acct_type, $key, false ) . '>' . esc_html( $label ) . '</option>';
                            }
                            ?>
                        </select>
                    </label>
                </div>

                <div class="ccv-pm-actions">
                    <button type="submit" class="ccv-btn ccv-btn--primary">Save Payout Method</button>
                    <div class="ccv-pm-toast" id="ccv-payout-method-toast" aria-live="polite"></div>
                </div>
            </form>
        </div>

        <style>
        .ccv-payout-method-shell{max-width:920px;margin-top:6px;padding:16px;border-radius:22px;border:1px solid rgba(120,180,255,.2);background:radial-gradient(900px 420px at 12% 0%,rgba(40,150,255,.2),transparent),linear-gradient(180deg,rgba(7,11,22,.94),rgba(3,6,14,.95));box-shadow:0 20px 60px rgba(0,0,0,.65),inset 0 0 0 1px rgba(80,160,255,.06);color:#fff!important;isolation:isolate}.ccv-payout-method-shell *{box-sizing:border-box}.ccv-pm-hero{display:flex;justify-content:space-between;gap:14px;align-items:flex-start;margin-bottom:14px}.ccv-pm-kicker{font-size:11px;letter-spacing:.14em;text-transform:uppercase;opacity:.7;color:#fff!important}.ccv-pm-title{font-size:24px;font-weight:800;letter-spacing:.02em;color:#fff!important}.ccv-pm-sub{margin-top:4px;font-size:13px;line-height:1.4;opacity:.78;max-width:620px;color:#fff!important}.ccv-pm-status{min-width:210px;border-radius:18px;padding:12px 14px;border:1px solid rgba(255,255,255,.12);background:rgba(6,14,30,.72);box-shadow:inset 0 0 0 1px rgba(255,255,255,.04)}.ccv-pm-status span{display:block;font-size:11px;letter-spacing:.14em;font-weight:900;color:#fff!important}.ccv-pm-status small{display:block;margin-top:5px;font-size:12px;line-height:1.35;color:#fff!important;opacity:.86}.ccv-pm-status.is-ready{border-color:rgba(40,220,140,.45);box-shadow:0 0 18px rgba(40,220,140,.14),inset 0 0 0 1px rgba(40,220,140,.08)}.ccv-pm-status.is-missing{border-color:rgba(255,190,80,.42);box-shadow:0 0 18px rgba(255,190,80,.12),inset 0 0 0 1px rgba(255,190,80,.08)}.ccv-pm-rail-note{margin:0 0 14px;padding:12px 14px;border-radius:16px;border:1px solid rgba(80,150,255,.22);background:rgba(8,22,48,.72);font-size:12px;line-height:1.45;color:#fff!important;opacity:.9}.ccv-pm-options{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px;margin-bottom:14px}.ccv-pm-option{cursor:pointer;text-align:left;appearance:none!important;-webkit-appearance:none!important;border-radius:18px;border:1px solid rgba(120,180,255,.18)!important;background:linear-gradient(180deg,rgba(10,30,68,.86),rgba(6,16,36,.82))!important;padding:14px;color:#fff!important;transition:transform .18s ease,border-color .18s ease,box-shadow .18s ease,background .18s ease;outline:none!important}.ccv-pm-option strong{display:block;font-size:15px;color:#fff!important}.ccv-pm-option span{display:block;margin-top:4px;font-size:12px;opacity:.74;color:#fff!important}.ccv-pm-option:hover,.ccv-pm-option:focus,.ccv-pm-option.is-active{transform:translateY(-1px);border-color:rgba(80,190,255,.78)!important;background:linear-gradient(135deg,rgba(20,85,165,.92),rgba(5,24,60,.94))!important;box-shadow:0 0 22px rgba(20,150,255,.24),inset 0 0 0 1px rgba(110,210,255,.18)}.ccv-pm-form{display:grid;gap:12px}
        
  .ccv-pm-panel{display:none;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}
  
.ccv-pm-panel.is-active{display:grid}

.ccv-pm-panel input[name="processor_token_ref"]{
  margin-top:-20px!important;
}
.ccv-pm-panel select[name="bank_account_type"]{
  margin-top:-36px!important;
}
        
        .ccv-pm-panel label{display:grid;gap:7px;color:#fff!important;font-size:12px;font-weight:800;letter-spacing:.03em}
       .ccv-pm-panel input,
.ccv-pm-panel select{
  width:100%;
  height:38px!important;
  min-height:38px!important;
  max-height:38px!important;
  border-radius:12px;
  padding:6px 12px!important;
  line-height:1.1!important;
  font-size:14px;
}
        .ccv-pm-panel input::placeholder{color:rgba(0,0,0,.52)!important}

/* 🔥 pull MMG name field UP */
.ccv-pm-panel[data-pm-panel="mmg"] label:first-child input{
    margin-top:-30px !important;
}

/* keep your mobile number spacing intact */
.ccv-pm-panel[data-pm-panel="mmg"] label:nth-child(2) input{
    margin-top:10px;
}

.ccv-pm-panel small{font-size:11px;line-height:1.35;color:#fff!important;opacity:.68;font-weight:500}

.ccv-pm-actions{display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-top:4px}.ccv-pm-toast{font-size:13px;color:#fff!important;opacity:.86}.ccv-pm-toast.is-error{color:#ffb4c0!important}.ccv-pm-toast.is-success{color:#b9ffd8!important}@media(max-width:720px){.ccv-pm-hero{display:grid}.ccv-pm-status{min-width:0}.ccv-pm-options,.ccv-pm-panel{grid-template-columns:1fr}}
        </style>

        <script>
        (function(window, document){
          'use strict';
          function qs(sel, ctx){ return (ctx || document).querySelector(sel); }
          function qsa(sel, ctx){ return Array.prototype.slice.call((ctx || document).querySelectorAll(sel)); }
          function val(x){ return x == null ? '' : String(x); }
          function bridge(){ return window.CaricoveCourierBridge || null; }
          function shell(){ return qs('#ccv-payout-method-shell'); }
          function toast(msg, err){ var t=qs('#ccv-payout-method-toast'); if(!t) return; t.textContent=val(msg); t.classList.toggle('is-error', !!err); t.classList.toggle('is-success', !err && !!msg); }
          function activeType(){ var input=qs('#ccv-pm-method-type'); return input ? val(input.value || 'mmg') : 'mmg'; }
          function setType(type){
            type = val(type || 'mmg');
            var input=qs('#ccv-pm-method-type'); if(input) input.value = type;
            qsa('.ccv-pm-option').forEach(function(btn){ btn.classList.toggle('is-active', val(btn.getAttribute('data-pm-type')) === type); });
            qsa('.ccv-pm-panel').forEach(function(panel){ panel.classList.toggle('is-active', val(panel.getAttribute('data-pm-panel')) === type); });
          }
          function sync(profile){
            profile = profile && typeof profile === 'object' ? profile : {};
            var status = qs('.ccv-pm-status');
            var word = qs('[data-pm-status-word]');
            var label = qs('[data-pm-active-label]');
            var configured = !!profile.configured;
            if(status){ status.classList.toggle('is-ready', configured); status.classList.toggle('is-missing', !configured); }
            if(word) word.textContent = configured ? 'READY' : 'NEEDS SETUP';
            if(label) label.textContent = val(profile.destination_label || 'No payout method saved');
            if(profile.type) setType(profile.type);
            var modalDest = qs('#ccv-payout-destination-display');
            if(modalDest) modalDest.textContent = configured ? val(profile.destination_label) : 'Add payout method first';
          }
          function collect(form){
            var fd = new FormData(form);
            var out = {};
            fd.forEach(function(value, key){ out[key] = value; });
            out.type = out.method_type || activeType();
            return out;
          }
          function boot(){
            if(!shell()) return;
            setType(shell().getAttribute('data-current-type') || 'mmg');
            qsa('.ccv-pm-option').forEach(function(btn){ btn.addEventListener('click', function(){ setType(btn.getAttribute('data-pm-type')); toast('', false); }); });
            var form = qs('#ccv-payout-method-form');
            if(form){
              form.addEventListener('submit', function(e){
                e.preventDefault();
                var runtime = bridge();
                if(!runtime || typeof runtime.savePayoutMethod !== 'function'){ toast('Payout method bridge is not loaded.', true); return; }
                var btn = form.querySelector('button[type="submit"]');
                if(btn) btn.disabled = true;
                toast('Saving payout method…', false);
                runtime.savePayoutMethod(collect(form)).then(function(resp){
                  if(btn) btn.disabled = false;
                  if(!resp || !resp.success){ toast(resp && resp.data && resp.data.message ? resp.data.message : 'Unable to save payout method.', true); return; }
                  sync((resp.data && resp.data.payout_method) || ((runtime.getState() || {}).payout_method || {}));
                  toast(resp.data && resp.data.message ? resp.data.message : 'Payout method saved.', false);
                  form.reset();
                  setType(((runtime.getState() || {}).payout_method || {}).type || activeType());
                }).catch(function(){ if(btn) btn.disabled = false; toast('Network error — try again.', true); });
              });
            }
            var runtime = bridge();
            if(runtime && runtime.getState) sync((runtime.getState() || {}).payout_method || {});
            if(runtime && runtime.subscribe){ runtime.subscribe(function(state){ sync((state || {}).payout_method || {}); }); }
          }
          if(document.readyState === 'loading'){ document.addEventListener('DOMContentLoaded', boot); } else { boot(); }
          window.addEventListener('load', boot);
        })(window, document);
        </script>
        <?php
    },
    10,
    1
);
