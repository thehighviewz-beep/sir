<?php
/**
 * Canonical courier actions.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! class_exists( '\Caricove\Logistics\Core\ShipmentManager' ) || ! class_exists( '\Caricove\Logistics\Core\Schema' ) ) {
    ccv_ccb_log_loader_error( 'ShipmentManager/Schema unavailable; bridge action handlers not registered.' );
    return;
}

if ( ! function_exists( 'ccv_ccb_core_ok_or_fail' ) ) {
    function ccv_ccb_core_ok_or_fail() {
        if ( ! class_exists( '\Caricove\Logistics\Core\ShipmentManager' ) ) {
            wp_send_json_error( array( 'message' => 'Core ShipmentManager missing' ), 500 );
        }
        if ( ! class_exists( '\Caricove\Logistics\Core\Schema' ) ) {
            wp_send_json_error( array( 'message' => 'Core Schema missing' ), 500 );
        }
    }
}

if ( ! function_exists( 'ccv_ccb_leg_start_meta_key' ) ) {
    function ccv_ccb_leg_start_meta_key( $leg ) {
        $leg = sanitize_key( (string) $leg );
        if ( 'pickup' === $leg ) {
            return '_cc_telemetry_leg_pickup_started_at';
        }
        if ( 'dropoff' === $leg ) {
            return '_cc_telemetry_leg_dropoff_started_at';
        }
        return '';
    }
}

if ( ! function_exists( 'ccv_ccb_leg_done_meta_key' ) ) {
    function ccv_ccb_leg_done_meta_key( $leg ) {
        $leg = sanitize_key( (string) $leg );
        if ( 'pickup' === $leg ) {
            return '_cc_telemetry_leg_pickup_completed_at';
        }
        if ( 'dropoff' === $leg ) {
            return '_cc_telemetry_leg_dropoff_completed_at';
        }
        return '';
    }
}

if ( ! function_exists( 'ccv_ccb_append_quality_flag' ) ) {
    function ccv_ccb_append_quality_flag( $shipment_id, $flag ) {
        $shipment_id = intval( $shipment_id );
        $flag        = sanitize_key( (string) $flag );

        if ( ! $shipment_id || '' === $flag ) {
            return;
        }

        $raw  = get_post_meta( $shipment_id, '_cc_telemetry_quality_flags', true );
        $list = is_array( $raw ) ? $raw : ( is_string( $raw ) && '' !== $raw ? array( $raw ) : array() );
        if ( ! in_array( $flag, $list, true ) ) {
            $list[] = $flag;
            update_post_meta( $shipment_id, '_cc_telemetry_quality_flags', $list );
        }
    }
}

if ( ! function_exists( 'ccv_ccb_build_telemetry_context' ) ) {
    function ccv_ccb_build_telemetry_context( $shipment_id, $courier_id, array $summary, $leg, $event, $reason = '' ) {
        $context = array(
            'bridge_ver'    => '3.0.0',
            'event'         => sanitize_key( (string) $event ),
            'leg'           => sanitize_key( (string) $leg ),
            'ts_utc'        => time(),
            'shipment_id'   => intval( $shipment_id ),
            'courier_id'    => intval( $courier_id ),
            'reason'        => sanitize_key( (string) $reason ),
            'status'        => (string) ( $summary['status'] ?? '' ),
            'type'          => (string) ( $summary['type'] ?? '' ),
            'origin_anchor' => (string) ( $summary['origin_anchor'] ?? '' ),
            'dest_anchor'   => (string) ( $summary['destination_anchor'] ?? '' ),
            'pickup_coords' => (string) ( $summary['pickup_coords'] ?? '' ),
            'dropoff_coords'=> (string) ( $summary['dropoff_coords'] ?? '' ),
            'size_band'     => (string) ( $summary['size_band'] ?? '' ),
            'weight_band'   => (string) ( $summary['weight_band'] ?? '' ),
            'bundle_id'     => (string) ( $summary['bundle_id'] ?? '' ),
            'bundle_seq'    => intval( $summary['bundle_seq'] ?? 0 ),
        );

        if ( class_exists( '\Caricove\Logistics\Core\CourierProfile' ) && method_exists( '\Caricove\Logistics\Core\CourierProfile', 'get_profile' ) ) {
            $profile = \Caricove\Logistics\Core\CourierProfile::get_profile( intval( $courier_id ) );
            if ( is_array( $profile ) ) {
                $context['vehicle_type']   = (string) ( $profile['vehicle_type'] ?? '' );
                $context['capacity_class'] = (string) ( $profile['capacity_class'] ?? '' );
                $context['region']         = (string) ( $profile['region'] ?? '' );
            }
        }

        return $context;
    }
}

if ( ! function_exists( 'ccv_ccb_emit_leg_started_once' ) ) {
    function ccv_ccb_emit_leg_started_once( $shipment_id, $courier_id, array $summary, $leg, $reason = '' ) {
        $meta_key = ccv_ccb_leg_start_meta_key( $leg );
        if ( '' === $meta_key ) {
            return;
        }

        if ( intval( get_post_meta( $shipment_id, $meta_key, true ) ) > 0 ) {
            return;
        }

        $now = time();
        update_post_meta( $shipment_id, $meta_key, $now );
        update_post_meta( $shipment_id, '_cc_telemetry_last_ping_ts', $now );

        do_action(
            'cc_telemetry_leg_started',
            $shipment_id,
            $courier_id,
            ccv_ccb_build_telemetry_context( $shipment_id, $courier_id, $summary, $leg, 'leg_started', $reason )
        );
    }
}

if ( ! function_exists( 'ccv_ccb_emit_leg_completed' ) ) {
    function ccv_ccb_emit_leg_completed( $shipment_id, $courier_id, array $summary, $leg, $reason = '' ) {
        $start_key = ccv_ccb_leg_start_meta_key( $leg );
        $done_key  = ccv_ccb_leg_done_meta_key( $leg );
        if ( '' === $start_key || '' === $done_key ) {
            return;
        }

        $done_ts = intval( get_post_meta( $shipment_id, $done_key, true ) );
        if ( $done_ts > 0 ) {
            return;
        }

        $start_ts = intval( get_post_meta( $shipment_id, $start_key, true ) );
        if ( $start_ts <= 0 ) {
            ccv_ccb_append_quality_flag( $shipment_id, 'missing_leg_start_' . sanitize_key( $leg ) );
            $start_ts = time();
            update_post_meta( $shipment_id, $start_key, $start_ts );
        }

        $now     = time();
        $minutes = max( 0.0, ( $now - $start_ts ) / 60.0 );
        update_post_meta( $shipment_id, $done_key, $now );
        update_post_meta( $shipment_id, '_cc_telemetry_last_leg_minutes', $minutes );
        update_post_meta( $shipment_id, '_cc_telemetry_last_ping_ts', $now );

        $context            = ccv_ccb_build_telemetry_context( $shipment_id, $courier_id, $summary, $leg, 'leg_completed', $reason );
        $context['minutes'] = $minutes;

        do_action( 'cc_telemetry_leg_completed', $shipment_id, $courier_id, $context );
    }
}

if ( ! function_exists( 'ccv_ccb_require_owned_shipment' ) ) {
    function ccv_ccb_require_owned_shipment( $shipment_id ) {
        if ( ! is_user_logged_in() ) {
            wp_send_json_error( array( 'message' => 'Not logged in' ), 401 );
        }

        ccv_ccb_core_ok_or_fail();

        $shipment_id = intval( $shipment_id );
        if ( ! $shipment_id ) {
            wp_send_json_error( array( 'message' => 'Missing job_id' ), 400 );
        }

        $summary = \Caricove\Logistics\Core\ShipmentManager::get_shipment_summary( $shipment_id );
        if ( ! is_array( $summary ) || empty( $summary ) ) {
            wp_send_json_error( array( 'message' => 'Shipment not found' ), 404 );
        }

        $assigned = intval( $summary['courier_id'] ?? 0 );
        $me       = get_current_user_id();
        if ( $assigned && $assigned !== $me && ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Not assigned to this shipment' ), 403 );
        }

        return array( $shipment_id, $assigned ?: $me, $summary );
    }
}

if ( ! function_exists( 'ccv_ccb_require_live_offer' ) ) {
    function ccv_ccb_require_live_offer( $shipment_id ) {
        if ( ! is_user_logged_in() ) {
            wp_send_json_error( array( 'message' => 'Not logged in' ), 401 );
        }

        ccv_ccb_core_ok_or_fail();

        $shipment_id = intval( $shipment_id );
        if ( ! $shipment_id ) {
            wp_send_json_error( array( 'message' => 'Missing job_id' ), 400 );
        }

        $me      = get_current_user_id();
        $summary = \Caricove\Logistics\Core\ShipmentManager::get_shipment_summary( $shipment_id );
        if ( ! is_array( $summary ) || empty( $summary ) ) {
            wp_send_json_error( array( 'message' => 'Shipment not found' ), 404 );
        }

        $offer_courier = intval( $summary['offer_courier_id'] ?? 0 );
        if ( $offer_courier !== $me && ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'Offer is not assigned to you' ), 403 );
        }

        if ( ! class_exists( '\Caricove\Logistics\Core\AutoAssign' ) || ! method_exists( '\Caricove\Logistics\Core\AutoAssign', 'offer_is_live' ) ) {
            wp_send_json_error( array( 'message' => 'Offer engine unavailable' ), 500 );
        }

        if ( ! \Caricove\Logistics\Core\AutoAssign::offer_is_live( $shipment_id, $offer_courier ?: $me ) ) {
            \Caricove\Logistics\Core\AutoAssign::handle_offer_timeout( $shipment_id, $offer_courier ?: $me );
            wp_send_json_error( array( 'message' => 'Offer expired' ), 409 );
        }

        return array( $shipment_id, $me, $summary );
    }
}

if ( ! function_exists( 'ccv_ccb_ajax_success_job' ) ) {
    function ccv_ccb_ajax_success_job( $shipment_id, $courier_id, $message = 'OK' ) {
        $summary = \Caricove\Logistics\Core\ShipmentManager::get_shipment_summary( $shipment_id );
        $job     = is_array( $summary ) ? ccv_ccb_build_job_payload( $shipment_id, $summary, $courier_id ) : array();

        wp_send_json_success(
            array(
                'message' => $message,
                'job'     => $job,
                'summary' => $summary,
                'state'   => ccv_ccb_get_runtime_payload( $courier_id ),
            )
        );
    }
}

add_action(
    'wp_ajax_caricove_courier_accept_offer',
    function() {
        check_ajax_referer( 'caricove_courier_start_trip', 'nonce' );

        list( $shipment_id, $courier_id ) = ccv_ccb_require_live_offer( $_POST['job_id'] ?? 0 );

        if ( ! class_exists( '\Caricove\Logistics\Core\AutoAssign' ) || ! method_exists( '\Caricove\Logistics\Core\AutoAssign', 'accept_job' ) ) {
            wp_send_json_error( array( 'message' => 'Offer engine unavailable' ), 500 );
        }

        $result = \Caricove\Logistics\Core\AutoAssign::accept_job(
            $shipment_id,
            $courier_id,
            array( 'source' => 'courier_console' )
        );

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ), 409 );
        }

        ccv_ccb_ajax_success_job( $shipment_id, $courier_id );
    }
);

add_action(
    'wp_ajax_caricove_courier_reject_offer',
    function() {
        check_ajax_referer( 'caricove_courier_start_trip', 'nonce' );

        list( $shipment_id, $courier_id ) = ccv_ccb_require_live_offer( $_POST['job_id'] ?? 0 );

        if ( ! class_exists( '\Caricove\Logistics\Core\AutoAssign' ) || ! method_exists( '\Caricove\Logistics\Core\AutoAssign', 'reject_job' ) ) {
            wp_send_json_error( array( 'message' => 'Offer engine unavailable' ), 500 );
        }

        $result = \Caricove\Logistics\Core\AutoAssign::reject_job( $shipment_id, $courier_id, 'offer_rejected' );
        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ), 409 );
        }

        wp_send_json_success(
            array(
                'message' => 'Offer rejected.',
                'job_id'  => $shipment_id,
                'state'   => ccv_ccb_get_runtime_payload( $courier_id ),
            )
        );
    }
);

add_action(
    'wp_ajax_caricove_courier_start_trip',
    function() {
        check_ajax_referer( 'caricove_courier_start_trip', 'nonce' );

        list( $shipment_id, $courier_id, $summary ) = ccv_ccb_require_owned_shipment( $_POST['job_id'] ?? 0 );
        $status = (string) ( $summary['status'] ?? 'assigned' );
        if ( ! in_array( $status, array( 'assigned', 'picked_up', 'in_transit' ), true ) ) {
            wp_send_json_error( array( 'message' => 'Cannot start trip from status ' . $status ), 400 );
        }

        $pickup_verified = ! empty( $summary['pickup_code_verified'] );
        $leg             = $pickup_verified ? 'dropoff' : 'pickup';

        if ( 'in_transit' !== $status ) {
            \Caricove\Logistics\Core\ShipmentManager::set_shipment_status(
                $shipment_id,
                'in_transit',
                array(
                    'source'     => 'courier_console',
                    'reason'     => 'start_trip',
                    'courier_id' => $courier_id,
                    'leg'        => $leg,
                )
            );
        }

        $refreshed = \Caricove\Logistics\Core\ShipmentManager::get_shipment_summary( $shipment_id );
        if ( is_array( $refreshed ) && ! empty( $refreshed ) ) {
            $summary = $refreshed;
        }

        ccv_ccb_emit_leg_started_once( $shipment_id, $courier_id, $summary, $leg, 'start_trip' );
        ccv_ccb_ajax_success_job( $shipment_id, $courier_id );
    }
);

add_action(
    'wp_ajax_caricove_courier_verify_pickup',
    function() {
        check_ajax_referer( 'caricove_courier_start_trip', 'nonce' );

        $code = trim( sanitize_text_field( wp_unslash( $_POST['code'] ?? '' ) ) );
        if ( '' === $code ) {
            wp_send_json_error( array( 'message' => 'Pickup code required' ), 400 );
        }

        ccv_ccb_core_ok_or_fail();
        list( $shipment_id, $courier_id, $summary ) = ccv_ccb_require_owned_shipment( $_POST['job_id'] ?? 0 );

        $stored = trim( (string) ( $summary['pickup_code'] ?? '' ) );
        if ( '' === $stored ) {
            wp_send_json_error( array( 'message' => 'No pickup code stored' ), 400 );
        }
        if ( $stored !== $code ) {
            wp_send_json_error( array( 'message' => 'Pickup code incorrect' ), 400 );
        }

        ccv_ccb_emit_leg_started_once( $shipment_id, $courier_id, $summary, 'pickup', 'pickup_confirm_start_selfheal' );

        update_post_meta( $shipment_id, \Caricove\Logistics\Core\Schema::META_SHIPMENT_PICKUP_CODE_VERIFIED, 'yes' );
        update_post_meta( $shipment_id, \Caricove\Logistics\Core\Schema::META_SHIPMENT_PICKUP_CODE_VERIFIED_AT, gmdate( 'c' ) );

        \Caricove\Logistics\Core\ShipmentManager::set_shipment_status(
            $shipment_id,
            'picked_up',
            array(
                'source'     => 'courier_console',
                'reason'     => 'pickup_code_verified',
                'courier_id' => $courier_id,
            )
        );

        $refreshed = \Caricove\Logistics\Core\ShipmentManager::get_shipment_summary( $shipment_id );
        if ( is_array( $refreshed ) && ! empty( $refreshed ) ) {
            $summary = $refreshed;
        }

        ccv_ccb_emit_leg_completed( $shipment_id, $courier_id, $summary, 'pickup', 'pickup_confirmed' );
        ccv_ccb_emit_leg_started_once( $shipment_id, $courier_id, $summary, 'dropoff', 'on_the_way' );

        ccv_ccb_ajax_success_job( $shipment_id, $courier_id );
    }
);

add_action(
    'wp_ajax_caricove_courier_verify_delivery',
    function() {
        check_ajax_referer( 'caricove_courier_start_trip', 'nonce' );

        $code = trim( sanitize_text_field( wp_unslash( $_POST['code'] ?? '' ) ) );
        if ( '' === $code ) {
            wp_send_json_error( array( 'message' => 'Delivery code required' ), 400 );
        }

        ccv_ccb_core_ok_or_fail();
        list( $shipment_id, $courier_id, $summary ) = ccv_ccb_require_owned_shipment( $_POST['job_id'] ?? 0 );

        $stored = trim( (string) ( $summary['delivery_code'] ?? '' ) );
        if ( '' === $stored ) {
            wp_send_json_error( array( 'message' => 'No delivery code stored' ), 400 );
        }
        if ( $stored !== $code ) {
            wp_send_json_error( array( 'message' => 'Delivery code incorrect' ), 400 );
        }

        ccv_ccb_emit_leg_started_once( $shipment_id, $courier_id, $summary, 'dropoff', 'dropoff_start_selfheal' );

        update_post_meta( $shipment_id, \Caricove\Logistics\Core\Schema::META_SHIPMENT_DELIVERY_CODE_VERIFIED, 'yes' );
        update_post_meta( $shipment_id, \Caricove\Logistics\Core\Schema::META_SHIPMENT_DELIVERY_CODE_VERIFIED_AT, gmdate( 'c' ) );

        \Caricove\Logistics\Core\ShipmentManager::set_shipment_status(
            $shipment_id,
            'delivered',
            array(
                'source'     => 'courier_console',
                'reason'     => 'delivery_code_verified',
                'courier_id' => $courier_id,
            )
        );

        $refreshed = \Caricove\Logistics\Core\ShipmentManager::get_shipment_summary( $shipment_id );
        if ( is_array( $refreshed ) && ! empty( $refreshed ) ) {
            $summary = $refreshed;
        }

        ccv_ccb_emit_leg_completed( $shipment_id, $courier_id, $summary, 'dropoff', 'delivery_confirmed' );
        ccv_ccb_ajax_success_job( $shipment_id, $courier_id );
    }
);
