<?php
/**
 * Canonical courier settings payload + save endpoint.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! function_exists( 'ccv_ccb_allowed_ranges' ) ) {
    function ccv_ccb_allowed_ranges() {
        return array( 'very_close', 'local_area', 'across_georgetown', 'extended_routes' );
    }
}

if ( ! function_exists( 'ccv_ccb_range_radius_km' ) ) {
    function ccv_ccb_range_radius_km( $range ) {
        $range = sanitize_key( (string) $range );

        if ( 'very_close' === $range ) {
            return 3;
        }

        if ( 'across_georgetown' === $range || 'extended_routes' === $range ) {
            return 15;
        }

        return 7;
    }
}

if ( ! function_exists( 'ccv_ccb_get_settings_for_courier' ) ) {
    function ccv_ccb_get_settings_for_courier( $courier_id ) {
        $courier_id = intval( $courier_id );

        $availability = sanitize_key( (string) get_user_meta( $courier_id, '_ccv_availability', true ) );
        if ( '' === $availability && class_exists( '\Caricove\Logistics\Core\CourierProfile' ) ) {
            $availability = sanitize_key( (string) get_user_meta( $courier_id, \Caricove\Logistics\Core\CourierProfile::META_STATUS, true ) );
        }
        if ( 'offline' !== $availability ) {
            $availability = 'online';
        }

        $max_jobs = intval( get_user_meta( $courier_id, '_ccv_max_active_jobs', true ) );
        if ( $max_jobs <= 0 && class_exists( '\Caricove\Logistics\Core\CourierProfile' ) ) {
            $max_jobs = intval( get_user_meta( $courier_id, \Caricove\Logistics\Core\CourierProfile::META_MAX_ACTIVE_JOBS, true ) );
        }
        if ( ! in_array( $max_jobs, array( 1, 3, 5 ), true ) ) {
            $max_jobs = 3;
        }

        $range = sanitize_key( (string) get_user_meta( $courier_id, '_ccv_range_pref', true ) );
        if ( ! in_array( $range, ccv_ccb_allowed_ranges(), true ) ) {
            $range = 'local_area';
        }

        $radius_km = 0;
        if ( class_exists( '\Caricove\Logistics\Core\CourierProfile' ) ) {
            $radius_km = floatval( get_user_meta( $courier_id, \Caricove\Logistics\Core\CourierProfile::META_RADIUS_KM, true ) );
        }
        if ( $radius_km <= 0 ) {
            $radius_km = ccv_ccb_range_radius_km( $range );
        }

        return array(
            'availability' => $availability,
            'max_jobs'     => $max_jobs,
            'range'        => $range,
            'radius_km'    => $radius_km,
        );
    }
}

if ( ! function_exists( 'ccv_ccb_update_settings_for_courier' ) ) {
    function ccv_ccb_update_settings_for_courier( $courier_id, array $payload ) {
        $courier_id = intval( $courier_id );

        $availability = sanitize_key( (string) ( $payload['availability'] ?? 'online' ) );
        if ( 'offline' !== $availability ) {
            $availability = 'online';
        }

        $max_jobs = intval( $payload['max_jobs'] ?? 3 );
        if ( ! in_array( $max_jobs, array( 1, 3, 5 ), true ) ) {
            $max_jobs = 3;
        }

        $range = sanitize_key( (string) ( $payload['range'] ?? 'local_area' ) );
        if ( ! in_array( $range, ccv_ccb_allowed_ranges(), true ) ) {
            $range = 'local_area';
        }

        $radius_km = ccv_ccb_range_radius_km( $range );

        update_user_meta( $courier_id, '_ccv_availability', $availability );
        update_user_meta( $courier_id, '_ccv_max_active_jobs', $max_jobs );
        update_user_meta( $courier_id, '_ccv_range_pref', $range );

        if ( class_exists( '\Caricove\Logistics\Core\CourierProfile' ) ) {
            update_user_meta( $courier_id, \Caricove\Logistics\Core\CourierProfile::META_STATUS, $availability );
            update_user_meta( $courier_id, \Caricove\Logistics\Core\CourierProfile::META_RADIUS_KM, $radius_km );
            update_user_meta( $courier_id, \Caricove\Logistics\Core\CourierProfile::META_MAX_ACTIVE_JOBS, $max_jobs );

            if ( 'online' === $availability ) {
                update_user_meta( $courier_id, \Caricove\Logistics\Core\CourierProfile::META_LAST_SEEN_TS, time() );
            }
        }

        return ccv_ccb_get_settings_for_courier( $courier_id );
    }
}

if ( ! function_exists( 'ccv_ccb_ajax_save_settings' ) ) {
    function ccv_ccb_ajax_save_settings() {
        if ( ! is_user_logged_in() ) {
            wp_send_json_error( array( 'message' => 'Not logged in' ), 401 );
        }

        $nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
        if ( ! wp_verify_nonce( $nonce, 'caricove_courier_settings' ) ) {
            wp_send_json_error( array( 'message' => 'Bad nonce' ), 403 );
        }

        $courier_id = get_current_user_id();
        $settings   = ccv_ccb_update_settings_for_courier(
            $courier_id,
            array(
                'availability' => isset( $_POST['availability'] ) ? wp_unslash( $_POST['availability'] ) : 'online',
                'max_jobs'     => isset( $_POST['max_jobs'] ) ? wp_unslash( $_POST['max_jobs'] ) : 3,
                'range'        => isset( $_POST['range'] ) ? wp_unslash( $_POST['range'] ) : 'local_area',
            )
        );

        $response = array(
            'message'      => 'Settings updated — dispatcher adjusted.',
            'availability' => $settings['availability'],
            'max_jobs'     => $settings['max_jobs'],
            'range'        => $settings['range'],
            'radius_km'    => $settings['radius_km'],
        );

        if ( function_exists( 'ccv_ccb_get_runtime_payload' ) ) {
            $response['state'] = ccv_ccb_get_runtime_payload( $courier_id );
        }

        wp_send_json_success( $response );
    }
}

add_action( 'wp_ajax_caricove_courier_save_settings', 'ccv_ccb_ajax_save_settings' );

add_filter(
    'cc_courier_profile',
    function( $meta, $courier_id ) {
        if ( ! is_array( $meta ) ) {
            $meta = array();
        }

        $meta['ccv_settings'] = ccv_ccb_get_settings_for_courier( $courier_id );
        return $meta;
    },
    20,
    2
);
