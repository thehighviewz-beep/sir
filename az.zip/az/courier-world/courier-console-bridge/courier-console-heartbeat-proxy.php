<?php
/**
 * Heartbeat proxy with dedicated nonce ownership.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

do_action( 'caricove_logistics_maybe_boot_core' );

if ( ! function_exists( 'ccv_bridge_has_core_heartbeat' ) ) {
    function ccv_bridge_has_core_heartbeat() {
        return class_exists( '\Caricove\Logistics\Core\HeartbeatAPI' )
            && method_exists( '\Caricove\Logistics\Core\HeartbeatAPI', 'handle_heartbeat' );
    }
}

if ( ! function_exists( 'ccv_bridge_handle_heartbeat_fallback_ajax' ) ) {
    function ccv_bridge_handle_heartbeat_fallback_ajax() {
        if ( ! is_user_logged_in() ) {
            wp_send_json_error( array( 'message' => 'Not logged in' ), 401 );
        }

        $nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
        if ( ! wp_verify_nonce( $nonce, 'caricove_courier_heartbeat' ) ) {
            wp_send_json_error( array( 'message' => 'Bad nonce' ), 403 );
        }

        $courier_id = get_current_user_id();
        $lat        = isset( $_POST['lat'] ) && '' !== $_POST['lat'] ? floatval( wp_unslash( $_POST['lat'] ) ) : null;
        $lng        = isset( $_POST['lng'] ) && '' !== $_POST['lng'] ? floatval( wp_unslash( $_POST['lng'] ) ) : null;

        if ( ccv_bridge_has_core_heartbeat() ) {
            $request = new WP_REST_Request( 'POST', '/caricove-logistics/v1/heartbeat' );
            $request->set_param( 'courier_id', $courier_id );
            if ( null !== $lat ) {
                $request->set_param( 'lat', $lat );
            }
            if ( null !== $lng ) {
                $request->set_param( 'lng', $lng );
            }

            $response = \Caricove\Logistics\Core\HeartbeatAPI::handle_heartbeat( $request );
            if ( $response instanceof WP_REST_Response ) {
                wp_send_json_success( $response->get_data() );
            }

            wp_send_json_success( array( 'ok' => true, 'courier_id' => $courier_id ) );
        }

        if ( class_exists( '\Caricove\Logistics\Core\CourierProfile' ) ) {
            if ( null !== $lat ) {
                update_user_meta( $courier_id, \Caricove\Logistics\Core\CourierProfile::META_LAST_LAT, $lat );
            }
            if ( null !== $lng ) {
                update_user_meta( $courier_id, \Caricove\Logistics\Core\CourierProfile::META_LAST_LNG, $lng );
            }
            update_user_meta( $courier_id, \Caricove\Logistics\Core\CourierProfile::META_LAST_SEEN_TS, time() );
            if ( method_exists( '\Caricove\Logistics\Core\CourierProfile', 'ensure_region_for_courier' ) ) {
                \Caricove\Logistics\Core\CourierProfile::ensure_region_for_courier( $courier_id );
            }
        }

        do_action(
            'cc_telemetry_courier_ping',
            $courier_id,
            array(
                'ts'     => time(),
                'lat'    => $lat,
                'lng'    => $lng,
                'source' => 'bridge_ajax_fallback',
            )
        );

        wp_send_json_success( array( 'ok' => true, 'courier_id' => $courier_id ) );
    }
}

add_action( 'wp_ajax_caricove_courier_heartbeat_fallback', 'ccv_bridge_handle_heartbeat_fallback_ajax' );

add_action(
    'rest_api_init',
    function() {
        register_rest_route(
            'caricove-logistics-bridge/v1',
            '/heartbeat',
            array(
                'methods'             => 'POST',
                'permission_callback' => function() {
                    return is_user_logged_in();
                },
                'callback'            => function( WP_REST_Request $request ) {
                    do_action( 'caricove_logistics_maybe_boot_core' );

                    if ( ccv_bridge_has_core_heartbeat() ) {
                        try {
                            return \Caricove\Logistics\Core\HeartbeatAPI::handle_heartbeat( $request );
                        } catch ( Throwable $throwable ) {
                            ccv_ccb_log_loader_error( 'Heartbeat proxy exception: ' . $throwable->getMessage() );
                            return new WP_REST_Response(
                                array(
                                    'ok'      => false,
                                    'message' => 'Heartbeat failed inside Core.',
                                ),
                                500
                            );
                        }
                    }

                    return new WP_REST_Response(
                        array(
                            'ok'      => false,
                            'message' => 'Core HeartbeatAPI missing.',
                        ),
                        503
                    );
                },
            )
        );
    },
    5
);
