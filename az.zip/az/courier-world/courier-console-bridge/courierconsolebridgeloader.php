<?php
/**
 * Plugin Name: Caricove Courier Console Bridge Loader
 * Description: Canonical bridge bootstrap for the Caricove courier console runtime.
 * Author: Caricove
 * Version: 3.0.0
 * MU Plugin: true
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}










if ( defined( 'CCV_COURIER_BRIDGE_BOOTSTRAPPED' ) ) {
	return;
}
define( 'CCV_COURIER_BRIDGE_BOOTSTRAPPED', true );

define( 'CCV_COURIER_BRIDGE_DIR', __DIR__ );
define( 'CCV_COURIER_BRIDGE_URL', '' );

$files = array(
	'scourier-console-balances.php',
	'settings-save.php',
	'payout-methods.php',
	'scourier-console-jobs.php',
	'scourier-console-actions.php',
	'courier-console-heartbeat-proxy.php',
	'courier-console-js.php',
	'setting-ui.php',
	'settings-js.php',
);

foreach ( $files as $file ) {
	$path = CCV_COURIER_BRIDGE_DIR . '/' . $file;

	if ( file_exists( $path ) ) {
		require_once $path;
	} else {
		error_log( '[CCV_COURIER_BRIDGE] Missing file: ' . $file );
	}
}