<?php
/**
 * Registers the canonical bridge runtime script.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! function_exists( 'ccv_ccb_register_runtime_script' ) ) {
    function ccv_ccb_register_runtime_script() {
        wp_register_script(
            'ccv-courier-bridge-runtime',
            plugins_url( 'assets/js/courier-console-bridge-runtime.js', __FILE__ ),
            array(),
            '3.0.1',
            true
        );
    }
}
add_action( 'wp_enqueue_scripts', 'ccv_ccb_register_runtime_script', 5 );

if ( ! function_exists( 'ccv_ccb_enqueue_runtime_script' ) ) {
    function ccv_ccb_enqueue_runtime_script() {
        ccv_ccb_register_runtime_script();
        wp_enqueue_script( 'ccv-courier-bridge-runtime' );
    }
}
