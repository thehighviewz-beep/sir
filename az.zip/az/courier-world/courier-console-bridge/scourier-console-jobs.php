<?php
/**
 * Canonical courier jobs/state payload.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! function_exists( 'ccv_ccb_parse_coords' ) ) {
    function ccv_ccb_parse_coords( $coords ) {
        $coords = is_string( $coords ) ? trim( $coords ) : '';
        if ( '' === $coords || false === strpos( $coords, ',' ) ) {
            return array( null, null );
        }

        list( $lat, $lng ) = array_map( 'trim', explode( ',', $coords, 2 ) );
        if ( ! is_numeric( $lat ) || ! is_numeric( $lng ) ) {
            return array( null, null );
        }

        return array( (float) $lat, (float) $lng );
    }
}

if ( ! function_exists( 'ccv_ccb_format_addr_line' ) ) {
    function ccv_ccb_format_addr_line( array $address ) {
        return trim(
            (string) ( $address['street'] ?? '' ) . ' ' .
            (string) ( $address['street_2'] ?? '' ) . ' ' .
            (string) ( $address['village'] ?? '' )
        );
    }
}

if ( ! function_exists( 'ccv_ccb_haversine_km' ) ) {
    function ccv_ccb_haversine_km( $lat1, $lng1, $lat2, $lng2 ) {
        if ( ! is_numeric( $lat1 ) || ! is_numeric( $lng1 ) || ! is_numeric( $lat2 ) || ! is_numeric( $lng2 ) ) {
            return null;
        }

        $earth = 6371.0;
        $lat1  = deg2rad( (float) $lat1 );
        $lng1  = deg2rad( (float) $lng1 );
        $lat2  = deg2rad( (float) $lat2 );
        $lng2  = deg2rad( (float) $lng2 );
        $dlat  = $lat2 - $lat1;
        $dlng  = $lng2 - $lng1;
        $a     = sin( $dlat / 2 ) ** 2 + cos( $lat1 ) * cos( $lat2 ) * sin( $dlng / 2 ) ** 2;
        $c     = 2 * atan2( sqrt( $a ), sqrt( 1 - $a ) );
        $dist  = $earth * $c;

        return ( is_finite( $dist ) && $dist >= 0 ) ? $dist : null;
    }
}

if ( ! function_exists( 'ccv_ccb_offer_is_live_for_summary' ) ) {
    function ccv_ccb_offer_is_live_for_summary( $shipment_id, array $summary, $courier_id = 0 ) {
        $shipment_id      = intval( $shipment_id );
        $courier_id       = intval( $courier_id );
        $offer_courier_id = intval( $summary['offer_courier_id'] ?? 0 );

        if ( $courier_id && $offer_courier_id && $offer_courier_id !== $courier_id ) {
            return false;
        }

        if ( class_exists( '\Caricove\Logistics\Core\AutoAssign' ) && method_exists( '\Caricove\Logistics\Core\AutoAssign', 'offer_is_live' ) ) {
            $probe_courier_id = $courier_id ?: $offer_courier_id;
            if ( $probe_courier_id > 0 ) {
                return (bool) \Caricove\Logistics\Core\AutoAssign::offer_is_live( $shipment_id, $probe_courier_id );
            }
        }

        $offer_expires_at = intval( $summary['offer_expires_at'] ?? 0 );
        if ( $offer_courier_id <= 0 || $offer_expires_at <= time() ) {
            return false;
        }

        $assigned_courier = intval( $summary['courier_id'] ?? $summary['assigned_courier_id'] ?? 0 );
        return $assigned_courier <= 0;
    }
}

if ( ! function_exists( 'ccv_ccb_offer_is_expired_for_summary' ) ) {
    function ccv_ccb_offer_is_expired_for_summary( $shipment_id, array $summary, $courier_id = 0 ) {
        $shipment_id      = intval( $shipment_id );
        $courier_id       = intval( $courier_id );
        $offer_courier_id = intval( $summary['offer_courier_id'] ?? 0 );

        if ( $courier_id && $offer_courier_id && $offer_courier_id !== $courier_id ) {
            return false;
        }

        if ( class_exists( '\Caricove\Logistics\Core\AutoAssign' ) && method_exists( '\Caricove\Logistics\Core\AutoAssign', 'shipment_has_expired_offer' ) ) {
            return (bool) \Caricove\Logistics\Core\AutoAssign::shipment_has_expired_offer(
                $shipment_id,
                $summary,
                $courier_id ?: $offer_courier_id
            );
        }

        $offer_expires_at = intval( $summary['offer_expires_at'] ?? 0 );
        if ( $offer_courier_id <= 0 || $offer_expires_at <= 0 ) {
            return false;
        }

        $assigned_courier = intval( $summary['courier_id'] ?? $summary['assigned_courier_id'] ?? 0 );
        if ( $assigned_courier > 0 && ! empty( $summary['assignment_accepted_at'] ) ) {
            return false;
        }

        return time() >= $offer_expires_at;
    }
}

if ( ! function_exists( 'ccv_ccb_normalize_status_label' ) ) {
    function ccv_ccb_normalize_status_label( $status, $status_label, $offer_is_live = false ) {
        $status       = sanitize_key( (string) $status );
        $status_label = trim( (string) $status_label );

        if ( '' !== $status_label ) {
            return $status_label;
        }

        if ( $offer_is_live ) {
            return 'Incoming Offer';
        }

        return ucwords( str_replace( '_', ' ', $status ) );
    }
}

if ( ! function_exists( 'ccv_ccb_build_job_payload' ) ) {
    function ccv_ccb_build_job_payload( $shipment_id, array $summary, $courier_id ) {
        $shipment_id = intval( $shipment_id );
        $courier_id  = intval( $courier_id );

        $status        = (string) ( $summary['status'] ?? 'assigned' );
        $offer_is_live = ! empty( $summary['offer_is_live'] );
        $status_label  = ccv_ccb_normalize_status_label( $status, (string) ( $summary['status_label'] ?? '' ), $offer_is_live );

        $pickup  = ( isset( $summary['pickup_address'] ) && is_array( $summary['pickup_address'] ) ) ? $summary['pickup_address'] : array();
        $dropoff = ( isset( $summary['dropoff_address'] ) && is_array( $summary['dropoff_address'] ) ) ? $summary['dropoff_address'] : array();

        $pickup_city = (string) ( $pickup['city'] ?? '' );
        $drop_city   = (string) ( $dropoff['city'] ?? '' );
        $pickup_text = ccv_ccb_format_addr_line( $pickup );
        $drop_text   = ccv_ccb_format_addr_line( $dropoff );

        $pickup_name  = (string) ( $summary['pickup_name'] ?? '' );
        $pickup_phone = (string) ( $summary['pickup_phone'] ?? '' );
        $drop_name    = (string) ( $summary['dropoff_name'] ?? '' );
        $drop_phone   = (string) ( $summary['dropoff_phone'] ?? '' );

        $dropoff_instructions = '';
        foreach ( array( 'dropoff_instructions', 'delivery_instructions' ) as $instruction_key ) {
            if ( '' === $dropoff_instructions && isset( $summary[ $instruction_key ] ) && is_scalar( $summary[ $instruction_key ] ) ) {
                $dropoff_instructions = trim( (string) $summary[ $instruction_key ] );
            }
        }
        foreach ( array( 'instructions', 'delivery_instructions' ) as $instruction_key ) {
            if ( '' === $dropoff_instructions && isset( $dropoff[ $instruction_key ] ) && is_scalar( $dropoff[ $instruction_key ] ) ) {
                $dropoff_instructions = trim( (string) $dropoff[ $instruction_key ] );
            }
        }

        $vendor_id = intval( $summary['vendor_id'] ?? 0 );
        if ( $vendor_id ) {
            if ( '' === $pickup_name ) {
                $pickup_name = (string) get_user_meta( $vendor_id, '_cc_vendor_storefront_name', true );
            }

            if ( '' === $pickup_name ) {
                $vendor_user = get_userdata( $vendor_id );
                if ( $vendor_user ) {
                    $pickup_name = $vendor_user->display_name;
                }
            }

            if ( '' === $pickup_text ) {
                $pickup_text = (string) get_user_meta( $vendor_id, '_cc_vendor_formatted_address', true );
            }
        }

        $offer_expires_at      = intval( $summary['offer_expires_at'] ?? 0 );
        $offer_created_at      = intval( $summary['offer_created_at'] ?? 0 );
        $offer_response_window = intval( $summary['offer_response_window'] ?? 0 );
        $offer_seconds_left    = $offer_expires_at ? max( 0, $offer_expires_at - time() ) : 0;

        list( $pickup_lat, $pickup_lng ) = ccv_ccb_parse_coords( (string) ( $summary['pickup_coords'] ?? '' ) );
        list( $dropoff_lat, $dropoff_lng ) = ccv_ccb_parse_coords( (string) ( $summary['dropoff_coords'] ?? '' ) );

        $courier_lat          = isset( $summary['courier_last_lat'] ) && is_numeric( $summary['courier_last_lat'] ) ? (float) $summary['courier_last_lat'] : null;
        $courier_lng          = isset( $summary['courier_last_lng'] ) && is_numeric( $summary['courier_last_lng'] ) ? (float) $summary['courier_last_lng'] : null;
        $courier_vehicle_type = (string) ( $summary['courier_vehicle_type'] ?? $summary['vehicle_type'] ?? '' );

        if ( class_exists( '\Caricove\Logistics\Core\CourierProfile' ) ) {
            $profile = \Caricove\Logistics\Core\CourierProfile::get_profile( $courier_id );
            if ( is_array( $profile ) ) {
                if ( null === $courier_lat && isset( $profile['last_lat'] ) && is_numeric( $profile['last_lat'] ) ) {
                    $courier_lat = (float) $profile['last_lat'];
                }
                if ( null === $courier_lng && isset( $profile['last_lng'] ) && is_numeric( $profile['last_lng'] ) ) {
                    $courier_lng = (float) $profile['last_lng'];
                }
                if ( '' === $courier_vehicle_type ) {
                    $courier_vehicle_type = (string) ( $profile['vehicle_type'] ?? '' );
                }
            }
        }

        $eta_label = '';
        if ( ! empty( $summary['eta'] ) ) {
            $eta_label = 'ETA ' . wp_date( 'H:i', strtotime( (string) $summary['eta'] ) );
        }

        $deadline_label = '';
        $deadline_ts    = 0;
        if ( ! empty( $summary['sla_deadline'] ) ) {
            $deadline_ts = strtotime( (string) $summary['sla_deadline'] );
            if ( $deadline_ts > 0 ) {
                $deadline_label = 'Deliver by ' . wp_date( 'H:i', $deadline_ts );
            }
        }

        $pickup_verified   = ! empty( $summary['pickup_code_verified'] );
        $delivery_verified = ! empty( $summary['delivery_code_verified'] );
        $phase             = 'to_pickup';
        if ( $delivery_verified || in_array( $status, array( 'delivered', 'returned', 'cancelled' ), true ) ) {
            $phase = 'done';
        } elseif ( $pickup_verified ) {
            $phase = 'to_dropoff';
        }

        $target_lat = null;
        $target_lng = null;
        if ( 'to_pickup' === $phase ) {
            $target_lat = $pickup_lat;
            $target_lng = $pickup_lng;
        } elseif ( 'to_dropoff' === $phase ) {
            $target_lat = $dropoff_lat;
            $target_lng = $dropoff_lng;
        }

        $distance_label = (string) ( $summary['distance_label'] ?? '' );
        if ( '' === $distance_label && null !== $courier_lat && null !== $courier_lng && null !== $target_lat && null !== $target_lng ) {
            $distance_km = ccv_ccb_haversine_km( $courier_lat, $courier_lng, $target_lat, $target_lng );
            if ( null !== $distance_km ) {
                if ( $distance_km < 0.3 ) {
                    $distance_label = ( 'to_pickup' === $phase ) ? 'Near pickup' : 'Near dropoff';
                } else {
                    $distance_label = ( 'to_pickup' === $phase )
                        ? sprintf( '%.1f km from pickup', $distance_km )
                        : sprintf( '%.1f km from dropoff', $distance_km );
                }
            }
        }

        $currency  = 'GYD';
        $pay_total = 0.0;
        if ( isset( $summary['quote_total_gyd'] ) && is_numeric( $summary['quote_total_gyd'] ) ) {
            $pay_total = (float) $summary['quote_total_gyd'];
        }
        $pay_label = number_format_i18n( $pay_total, 2 );

        $queue_bucket = sanitize_key( (string) ( $summary['queue_bucket'] ?? '' ) );
        if ( ! in_array( $queue_bucket, array( 'incoming', 'assigned', 'queued' ), true ) ) {
            $queue_bucket = 'queued';
        }

        $next_state       = '';
        $next_state_label = '';
        $requires_code    = false;

        if ( $offer_is_live ) {
            $next_state       = 'accept_offer';
            $next_state_label = 'Accept';
        } elseif ( 'assigned' === $status ) {
            $next_state       = 'en_route';
            $next_state_label = 'Start Trip';
        } elseif ( 'in_transit' === $status && ! $pickup_verified ) {
            $next_state       = 'pickup_code';
            $next_state_label = 'Confirm Pickup';
            $requires_code    = true;
        } elseif ( 'picked_up' === $status ) {
            $next_state       = 'en_route';
            $next_state_label = 'On The Way';
        } elseif ( 'in_transit' === $status && $pickup_verified && ! $delivery_verified ) {
            $next_state       = 'delivered';
            $next_state_label = 'Complete Delivery';
            $requires_code    = true;
        }

        $map_url = '';
        $nav_url = '';

        if ( 'to_dropoff' === $phase ) {
            if ( null !== $dropoff_lat && null !== $dropoff_lng ) {
                $map_url = 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( $dropoff_lat . ',' . $dropoff_lng );
                $nav_url = 'https://www.google.com/maps/dir/?api=1&destination=' . rawurlencode( $dropoff_lat . ',' . $dropoff_lng );
            }
        } elseif ( null !== $pickup_lat && null !== $pickup_lng ) {
            $map_url = 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( $pickup_lat . ',' . $pickup_lng );
            $nav_url = 'https://www.google.com/maps/dir/?api=1&destination=' . rawurlencode( $pickup_lat . ',' . $pickup_lng );
        }

        $job = array(
            'job_id'               => $shipment_id,
            'label'                => 'Shipment #' . $shipment_id,
            'status'               => $status,
            'status_label'         => $status_label,
            'pay_label'            => $pay_label,
            'currency'             => $currency,
            'pickup_title'         => 'Pickup',
            'pickup_text'          => $pickup_text,
            'pickup_city'          => $pickup_city,
            'pickup_name'          => $pickup_name,
            'pickup_phone'         => $pickup_phone,
            'dropoff_title'        => 'Dropoff',
            'dropoff_text'         => $drop_text,
            'dropoff_city'         => $drop_city,
            'dropoff_name'         => $drop_name,
            'dropoff_phone'        => $drop_phone,
            'dropoff_instructions' => $dropoff_instructions,
            'delivery_instructions'=> $dropoff_instructions,
            'eta_label'            => $eta_label,
            'distance_label'       => $distance_label,
            'deadline_label'       => $deadline_label,
            'deadline_ts'          => $deadline_ts,
            'map_url'              => $map_url,
            'nav_url'              => $nav_url,
            'phase'                => $phase,
            'pickup_lat'           => $pickup_lat,
            'pickup_lng'           => $pickup_lng,
            'dropoff_lat'          => $dropoff_lat,
            'dropoff_lng'          => $dropoff_lng,
            'mission_id'           => (string) ( $summary['bundle_id'] ?? '' ),
            'mission_seq'          => intval( $summary['bundle_seq'] ?? 0 ),
            'next_state'           => $next_state,
            'next_state_label'     => $next_state_label,
            'requires_code'        => $requires_code,
            'offer_is_live'        => $offer_is_live,
            'offer_created_at'     => $offer_created_at,
            'offer_expires_at'     => $offer_expires_at,
            'offer_response_window'=> $offer_response_window,
            'offer_seconds_left'   => $offer_seconds_left,
            'courier_lat'          => $courier_lat,
            'courier_lng'          => $courier_lng,
            'courier_vehicle_type' => $courier_vehicle_type,
            'distance_band'        => (string) ( $summary['distance_band'] ?? $summary['trip_band'] ?? '' ),
            'quote_total_gyd'      => round( $pay_total, 2 ),
            'queue_bucket'         => $queue_bucket,
        );

        return apply_filters( 'caricove_courier_bridge_job', $job, $shipment_id, $summary, $courier_id );
    }
}

if ( ! function_exists( 'ccv_ccb_collect_jobs_for_courier' ) ) {
    function ccv_ccb_collect_jobs_for_courier( $courier_id ) {
        $courier_id = intval( $courier_id );
        $jobs       = array(
            'incoming' => array(),
            'assigned' => array(),
            'queued'   => array(),
        );

        if ( ! $courier_id ) {
            return $jobs;
        }

        if ( ! class_exists( '\Caricove\Logistics\Core\ShipmentManager' ) || ! class_exists( '\Caricove\Logistics\Core\Schema' ) ) {
            return $jobs;
        }

        $cpt      = apply_filters( 'cc_logistics_shipment_cpt', 'cc_shipment' );
        $meta_key = \Caricove\Logistics\Core\Schema::META_SHIPMENT_COURIER_ID;
        $all_ids  = array();

        $owned = new WP_Query(
            array(
                'post_type'      => $cpt,
                'post_status'    => 'any',
                'posts_per_page' => 120,
                'orderby'        => 'date',
                'order'          => 'DESC',
                'fields'         => 'ids',
                'no_found_rows'  => true,
                'meta_query'     => array(
                    array(
                        'key'   => $meta_key,
                        'value' => $courier_id,
                    ),
                ),
            )
        );

        foreach ( (array) $owned->posts as $shipment_id ) {
            $all_ids[ intval( $shipment_id ) ] = intval( $shipment_id );
        }

        $offer_query = new WP_Query(
            array(
                'post_type'      => $cpt,
                'post_status'    => 'any',
                'posts_per_page' => 60,
                'orderby'        => 'date',
                'order'          => 'DESC',
                'fields'         => 'ids',
                'no_found_rows'  => true,
                'meta_query'     => array(
                    array(
                        'key'   => \Caricove\Logistics\Core\Schema::META_SHIPMENT_OFFER_COURIER_ID,
                        'value' => $courier_id,
                    ),
                ),
            )
        );

        foreach ( (array) $offer_query->posts as $shipment_id ) {
            $all_ids[ intval( $shipment_id ) ] = intval( $shipment_id );
        }

        $rows = array();
        foreach ( array_values( $all_ids ) as $shipment_id ) {
            $summary = \Caricove\Logistics\Core\ShipmentManager::get_shipment_summary( $shipment_id );
            if ( ! is_array( $summary ) || empty( $summary ) ) {
                continue;
            }

            if ( ccv_ccb_offer_is_expired_for_summary( $shipment_id, $summary, $courier_id ) ) {
                if ( class_exists( '\Caricove\Logistics\Core\AutoAssign' ) && method_exists( '\Caricove\Logistics\Core\AutoAssign', 'handle_offer_timeout' ) ) {
                    $timeout_courier_id = intval( $summary['offer_courier_id'] ?? $courier_id );
                    if ( $timeout_courier_id > 0 ) {
                        \Caricove\Logistics\Core\AutoAssign::handle_offer_timeout( $shipment_id, $timeout_courier_id );
                    }
                }
                continue;
            }

            $status        = (string) ( $summary['status'] ?? '' );
            $offer_is_live = ccv_ccb_offer_is_live_for_summary( $shipment_id, $summary, $courier_id );
            if ( in_array( $status, array( 'delivered', 'returned', 'cancelled' ), true ) ) {
                continue;
            }

            $summary['offer_is_live'] = $offer_is_live;
            $rows[ $shipment_id ]     = $summary;
        }

        $assigned_job_id = 0;
        $assigned_rank   = null;
        foreach ( $rows as $shipment_id => $summary ) {
            if ( ! empty( $summary['offer_is_live'] ) ) {
                continue;
            }

            $status = (string) ( $summary['status'] ?? '' );
            $rank   = 99;
            if ( in_array( $status, array( 'in_transit', 'picked_up' ), true ) ) {
                $rank = 1;
            } elseif ( 'assigned' === $status ) {
                $rank = 2;
            }

            if ( 99 === $rank ) {
                continue;
            }

            $accepted_at  = ! empty( $summary['assignment_accepted_at'] ) ? strtotime( (string) $summary['assignment_accepted_at'] ) : 0;
            $last_changed = ! empty( $summary['last_status_change_at'] ) ? strtotime( (string) $summary['last_status_change_at'] ) : 0;
            $sort_ts      = $accepted_at ?: $last_changed ?: time();

            if ( null === $assigned_rank || $rank < $assigned_rank || ( $rank === $assigned_rank && $sort_ts < ( $rows[ $assigned_job_id ]['_sort_ts'] ?? PHP_INT_MAX ) ) ) {
                $assigned_job_id                = $shipment_id;
                $assigned_rank                  = $rank;
                $rows[ $shipment_id ]['_sort_ts'] = $sort_ts;
            }
        }

        foreach ( $rows as $shipment_id => $summary ) {
            if ( ! empty( $summary['offer_is_live'] ) ) {
                $summary['queue_bucket'] = 'incoming';
            } elseif ( $shipment_id === $assigned_job_id ) {
                $summary['queue_bucket'] = 'assigned';
            } else {
                $summary['queue_bucket'] = 'queued';
            }

            $jobs[ $summary['queue_bucket'] ][] = ccv_ccb_build_job_payload( $shipment_id, $summary, $courier_id );
        }

        return $jobs;
    }
}

if ( ! function_exists( 'ccv_ccb_build_mission_payload' ) ) {
    function ccv_ccb_build_mission_payload( array $jobs ) {
        $assigned = isset( $jobs['assigned'][0] ) && is_array( $jobs['assigned'][0] ) ? $jobs['assigned'][0] : null;

        return array(
            'active_job_id'   => $assigned ? intval( $assigned['job_id'] ?? 0 ) : 0,
            'active_job'      => $assigned,
            'incoming_count'  => count( (array) ( $jobs['incoming'] ?? array() ) ),
            'assigned_count'  => count( (array) ( $jobs['assigned'] ?? array() ) ),
            'queued_count'    => count( (array) ( $jobs['queued'] ?? array() ) ),
            'has_live_offer'  => ! empty( $jobs['incoming'] ),
        );
    }
}

if ( ! function_exists( 'ccv_ccb_get_runtime_payload' ) ) {
    function ccv_ccb_get_runtime_payload( $courier_id ) {
        $courier_id = intval( $courier_id );
        $jobs       = ccv_ccb_collect_jobs_for_courier( $courier_id );

        return array(
            'courier_id'   => $courier_id,
            'generated_at' => time(),
            'jobs'         => $jobs,
            'balances'     => function_exists( 'ccv_ccb_get_balances_for_courier' ) ? ccv_ccb_get_balances_for_courier( $courier_id ) : array(),
            'settings'     => function_exists( 'ccv_ccb_get_settings_for_courier' ) ? ccv_ccb_get_settings_for_courier( $courier_id ) : array(),
            'payout_method'=> function_exists( 'ccv_ccb_get_payout_method_for_courier' ) ? ccv_ccb_get_payout_method_for_courier( $courier_id ) : array( 'configured' => false, 'destination_label' => 'No payout method saved' ),
            'mission'      => ccv_ccb_build_mission_payload( $jobs ),
            'focus_job_id' => 0,
        );
    }
}

if ( ! function_exists( 'ccv_ccb_get_bootstrap_config' ) ) {
    function ccv_ccb_get_bootstrap_config( $courier_id ) {
        $courier_id = intval( $courier_id );

        return array(
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'state'    => ccv_ccb_get_runtime_payload( $courier_id ),
            'actions'  => array(
                'state'            => 'caricove_courier_bridge_state',
                'accept_offer'     => 'caricove_courier_accept_offer',
                'reject_offer'     => 'caricove_courier_reject_offer',
                'start_trip'       => 'caricove_courier_start_trip',
                'verify_pickup'    => 'caricove_courier_verify_pickup',
                'verify_delivery'  => 'caricove_courier_verify_delivery',
                'save_settings'    => 'caricove_courier_save_settings',
                'save_payout_method'=> 'caricove_courier_save_payout_method',
                'payout'           => 'caricove_courier_request_payout',
                'heartbeat_ajax'   => 'caricove_courier_heartbeat_fallback',
            ),
            'nonces'   => array(
                'trip'      => wp_create_nonce( 'caricove_courier_start_trip' ),
                'settings'  => wp_create_nonce( 'caricove_courier_settings' ),
                'payout_method' => wp_create_nonce( 'caricove_courier_payout_method' ),
                'state'     => wp_create_nonce( 'caricove_courier_bridge_state' ),
                'heartbeat' => wp_create_nonce( 'caricove_courier_heartbeat' ),
                'payout'    => wp_create_nonce( 'caricove_courier_payout' ),
                'rest'      => wp_create_nonce( 'wp_rest' ),
            ),
            'heartbeat' => array(
                'core_url'       => rest_url( 'caricove-logistics/v1/heartbeat' ),
                'proxy_url'      => rest_url( 'caricove-logistics-bridge/v1/heartbeat' ),
                'interval_ms'    => 15000,
                'minimum_gap_ms' => 3000,
            ),
        );
    }
}

if ( ! function_exists( 'ccv_ccb_render_bootstrap_script' ) ) {
    function ccv_ccb_render_bootstrap_script( $courier_id ) {
        $payload = wp_json_encode( ccv_ccb_get_bootstrap_config( $courier_id ) );
        if ( ! $payload ) {
            return '';
        }

        return '<script type="application/json" id="ccv-courier-bridge-bootstrap">' . $payload . '</script>';
    }
}

if ( ! function_exists( 'ccv_ccb_ajax_state' ) ) {
    function ccv_ccb_ajax_state() {
        if ( ! is_user_logged_in() ) {
            wp_send_json_error( array( 'message' => 'Not logged in' ), 401 );
        }

        $nonce = isset( $_REQUEST['nonce'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['nonce'] ) ) : '';
        if ( ! wp_verify_nonce( $nonce, 'caricove_courier_bridge_state' ) ) {
            wp_send_json_error( array( 'message' => 'Bad nonce' ), 403 );
        }

        $state = ccv_ccb_get_runtime_payload( get_current_user_id() );
        wp_send_json_success(
            array(
                'state' => $state,
                'jobs'  => $state['jobs'],
            )
        );
    }
}

add_action( 'wp_ajax_caricove_courier_bridge_state', 'ccv_ccb_ajax_state' );
add_action( 'wp_ajax_caricove_courier_fetch_jobs', 'ccv_ccb_ajax_state' );
