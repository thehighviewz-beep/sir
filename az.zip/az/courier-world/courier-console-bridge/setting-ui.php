<?php
/**
 * Plugin Name: Caricove Courier Console Bridge — Settings UI (Cinematic)
 * Description: Cinematic, scoped Settings UI injected into the courier console Settings tab (no theme bleed).
 * Version: 2.0.1
 */

if ( ! defined('ABSPATH') ) exit;

add_action('caricove_logistics_scaffold_settings', function($courier_id){

    $courier_id = intval($courier_id);
    if ( ! $courier_id ) return;

    // Stored prefs
    $availability = get_user_meta($courier_id, '_ccv_availability', true);
    if ( $availability !== 'offline' ) $availability = 'online';

    $max_jobs = intval(get_user_meta($courier_id, '_ccv_max_active_jobs', true));
    if ( ! in_array($max_jobs, array(1,3,5), true) ) $max_jobs = 3;

    $range = get_user_meta($courier_id, '_ccv_range_pref', true);
    if ( ! in_array($range, array('very_close','local_area','across_georgetown','extended_routes'), true) ) {
        $range = 'local_area';
    }

    ?>
    <div class="ccv-settings-shell" id="ccv-settings-shell"
         data-initial-availability="<?php echo esc_attr($availability); ?>"
         data-initial-maxjobs="<?php echo esc_attr($max_jobs); ?>"
         data-initial-range="<?php echo esc_attr($range); ?>">

        <div class="ccv-settings-hero">
            <div class="ccv-settings-hero-title">Courier Settings</div>
            <div class="ccv-settings-hero-sub">
                Tune how Caricove assigns work to you — availability, workload, and travel comfort.
            </div>
        </div>

        <div class="ccv-settings-grid">

            <section class="ccv-set-card ccv-set-card--availability">
                <div class="ccv-set-head">
                    <div>
                        <div class="ccv-set-title">Availability</div>
                        <div class="ccv-set-sub">Control when you can receive assignments.</div>
                    </div>
                    <div class="ccv-set-badge" data-bind="availability-badge">
                        <?php echo $availability === 'online' ? 'ONLINE' : 'OFFLINE'; ?>
                    </div>
                </div>

                <div class="ccv-set-toggle-row">
                    <button type="button"
                        class="ccv-set-chip <?php echo $availability==='online' ? 'is-active is-online' : ''; ?>"
                        data-setting="availability" data-value="online">
                        Online
                    </button>

                    <button type="button"
                        class="ccv-set-chip <?php echo $availability==='offline' ? 'is-active is-offline' : ''; ?>"
                        data-setting="availability" data-value="offline">
                        Offline
                    </button>
                </div>

                <div class="ccv-set-note">
                    Going offline pauses new assignments. Your active jobs remain visible.
                </div>
            </section>

            <section class="ccv-set-card ccv-set-card--workload">
                <div class="ccv-set-head">
                    <div>
                        <div class="ccv-set-title">Workload</div>
                        <div class="ccv-set-sub">How many active deliveries should we assign you at once?</div>
                    </div>
                    <div class="ccv-set-mini" data-bind="maxjobs-label">
                        <?php echo $max_jobs === 1 ? 'Focused' : ($max_jobs === 5 ? 'High Capacity' : 'Balanced'); ?>
                    </div>
                </div>

                <div class="ccv-set-pills">
                    <button type="button"
                        class="ccv-set-pill <?php echo $max_jobs===1 ? 'is-active' : ''; ?>"
                        data-setting="max_jobs" data-value="1">
                        <span class="t">Focused</span>
                        <span class="d">1 job</span>
                    </button>

                    <button type="button"
                        class="ccv-set-pill <?php echo $max_jobs===3 ? 'is-active' : ''; ?>"
                        data-setting="max_jobs" data-value="3">
                        <span class="t">Balanced</span>
                        <span class="d">Up to 3</span>
                    </button>

                    <button type="button"
                        class="ccv-set-pill <?php echo $max_jobs===5 ? 'is-active' : ''; ?>"
                        data-setting="max_jobs" data-value="5">
                        <span class="t">High Capacity</span>
                        <span class="d">Up to 5</span>
                    </button>
                </div>

                <div class="ccv-set-note">
                    Dispatcher won’t assign more than your selected limit.
                </div>
            </section>

            <section class="ccv-set-card ccv-set-card--range">
                <div class="ccv-set-head">
                    <div>
                        <div class="ccv-set-title">Travel Comfort Zone</div>
                        <div class="ccv-set-sub">How far are you comfortable travelling for a pickup?</div>
                    </div>
                    <div class="ccv-set-mini" data-bind="range-label">Preference</div>
                </div>

                <div class="ccv-range-stack">
                    <?php
                    $opts = array(
                        'very_close' => array('Very close', 'Short trips near your current area.'),
                        'local_area' => array('Local area', 'Normal deliveries around your usual area.'),
                        'across_georgetown' => array('Across Georgetown', 'Comfortable travelling across the city.'),
                        'extended_routes' => array('Extended routes', 'Open to longer-distance deliveries when it makes sense.'),
                    );
                    foreach ($opts as $key => $info):
                        $active = ($range === $key);
                    ?>
                    <button type="button"
                        class="ccv-range-card <?php echo $active ? 'is-active' : ''; ?>"
                        data-setting="range" data-value="<?php echo esc_attr($key); ?>">
                        <div class="ccv-range-card-left">
                            <div class="ccv-range-title"><?php echo esc_html($info[0]); ?></div>
                            <div class="ccv-range-desc"><?php echo esc_html($info[1]); ?></div>
                        </div>
                        <div class="ccv-range-dot" aria-hidden="true"></div>
                    </button>
                    <?php endforeach; ?>
                </div>

                <div class="ccv-set-note">
                    Caricove factors traffic, timing, and payout before assigning longer routes.
                </div>
            </section>

        </div>

        <div id="ccv-settings-toast" class="ccv-set-toast" aria-live="polite"></div>

    </div>

    <style>
    .ccv-settings-shell{
        position: relative;
        max-width: 860px;
        margin-top: 6px;
        padding: 14px;
        border-radius: 18px;
        border: 1px solid rgba(120,180,255,.18);
        background:
            radial-gradient(1200px 500px at 18% 0%, rgba(64,160,255,.22), rgba(0,0,0,0)),
            radial-gradient(900px 520px at 82% 10%, rgba(140,80,255,.16), rgba(0,0,0,0)),
            linear-gradient(180deg, rgba(7,11,20,.92), rgba(4,6,12,.92));
        box-shadow: 0 20px 60px rgba(0,0,0,.65), 0 0 0 1px rgba(80,160,255,.06) inset;
        animation: none;
        isolation: isolate;
    }
    @keyframes ccvSetEnter{
        from{ opacity:1; transform:none; filter:none; }
        to{ opacity:1; transform:none; filter:none; }
    }

    .ccv-settings-hero{ padding: 4px 6px 12px 6px; }
    .ccv-settings-hero-title{
        font-size: 16px;
        letter-spacing: .10em;
        text-transform: uppercase;
        font-weight: 700;
        opacity: .92;
    }
    .ccv-settings-hero-sub{
        margin-top: 6px;
        font-size: 12px;
        opacity: .74;
        max-width: 640px;
        line-height: 1.35;
    }

    .ccv-settings-grid{
        display: grid;
        gap: 12px;
    }

    .ccv-settings-shell,
    .ccv-settings-shell * {
        color: #eaf4ff !important;
    }

    .ccv-settings-shell *:hover {
        color: #eaf4ff !important;
    }

    .ccv-set-card {
        margin-bottom: 22px;
        padding: 18px 18px 20px;
    }

    .ccv-set-title {
        font-size: 13px;
        letter-spacing: 0.14em;
        text-transform: uppercase;
        color: #bfe6ff !important;
    }

    .ccv-set-sub {
        color: rgba(230, 245, 255, 0.75) !important;
    }

    .ccv-set-chip {
        background: rgba(6, 20, 48, 0.85) !important;
        border: 1px solid rgba(120, 190, 255, 0.45) !important;
        color: #eaf4ff !important;
    }

    .ccv-set-chip:hover {
        background: rgba(20, 90, 160, 0.9) !important;
        box-shadow: 0 0 14px rgba(60, 180, 255, 0.55) !important;
    }

    .ccv-set-chip.is-active {
        background: linear-gradient(135deg, #1fb6ff, #007bff) !important;
        color: #ffffff !important;
        box-shadow: 0 0 22px rgba(40, 170, 255, 0.9) !important;
    }

    .ccv-set-pill {
        background: rgba(8, 28, 64, 0.95) !important;
        border: 1px solid rgba(130, 200, 255, 0.4) !important;
        color: #eaf4ff !important;
    }

    .ccv-set-pill:hover {
        background: rgba(25, 110, 190, 0.95) !important;
        box-shadow: 0 0 18px rgba(70, 190, 255, 0.6) !important;
    }

    .ccv-set-pill.is-active {
        background: linear-gradient(135deg, #22c1ff, #0072ff) !important;
        color: #ffffff !important;
        box-shadow:
            0 0 26px rgba(60, 190, 255, 1),
            inset 0 0 18px rgba(255,255,255,0.15) !important;
    }

    .ccv-range-card {
        background: rgba(6, 22, 52, 0.9) !important;
        border: 1px solid rgba(120, 190, 255, 0.45) !important;
    }

    .ccv-range-card:hover {
        background: rgba(25, 120, 200, 0.95) !important;
        box-shadow:
            0 0 22px rgba(80, 200, 255, 0.85),
            inset 0 0 22px rgba(255,255,255,0.12) !important;
    }

    .ccv-range-card.is-active {
        background: linear-gradient(135deg, #1fb6ff, #006bff) !important;
        color: #ffffff !important;
        box-shadow:
            0 0 30px rgba(70, 200, 255, 1),
            inset 0 0 26px rgba(255,255,255,0.18) !important;
    }

    .ccv-range-dot {
        background: rgba(140, 200, 255, 0.45) !important;
    }

    .ccv-range-card.is-active .ccv-range-dot {
        background: #ffffff !important;
        box-shadow: 0 0 14px rgba(255,255,255,0.9) !important;
    }

    .ccv-set-note {
        color: rgba(220, 240, 255, 0.7) !important;
        font-size: 11px;
    }

    .ccv-set-badge,
    .ccv-set-mini {
        background: rgba(8, 26, 64, 0.85) !important;
        border-color: rgba(140, 200, 255, 0.55) !important;
        color: #eaf4ff !important;
    }

    @media (max-width: 900px) {
        .ccv-range-card {
            padding: 16px;
        }
    }

    .ccv-set-card{
        border-radius: 16px;
        padding: 14px;
        border: 1px solid rgba(90,150,255,.40);
        background: radial-gradient(circle at top left, rgba(8,32,80,.92), rgba(3,8,24,.96));
        box-shadow: 0 0 22px rgba(0,0,0,.55);
        position: relative;
        overflow: hidden;
    }
    .ccv-set-card:before{
        content:'';
        position:absolute;
        inset:-60px -40px auto -40px;
        height:120px;
        background: radial-gradient(circle at center, rgba(35,177,255,.18), rgba(0,0,0,0));
        filter: blur(1px);
        pointer-events:none;
    }

    .ccv-set-card--range{
        border-color: rgba(110,180,255,.70);
        box-shadow: 0 0 24px rgba(0,150,255,.28), 0 0 50px rgba(0,0,0,.70);
    }

    .ccv-set-head{
        display:flex;
        justify-content: space-between;
        align-items: flex-start;
        gap: 12px;
        margin-bottom: 10px;
    }
    .ccv-set-title{
        font-size: 12px;
        letter-spacing: .12em;
        text-transform: uppercase;
        opacity: .90;
        font-weight: 700;
    }
    .ccv-set-sub{
        margin-top: 4px;
        font-size: 12px;
        opacity: .72;
        line-height: 1.25;
    }

    .ccv-set-badge{
        border-radius: 999px;
        padding: 6px 10px;
        font-size: 11px;
        letter-spacing: .10em;
        text-transform: uppercase;
        border: 1px solid rgba(130,190,255,.65);
        background: rgba(1,6,18,.75);
        box-shadow: 0 0 14px rgba(0,150,255,.18);
        white-space: nowrap;
    }
    .ccv-set-mini{
        border-radius: 999px;
        padding: 6px 10px;
        font-size: 11px;
        letter-spacing: .08em;
        border: 1px solid rgba(120,185,255,.45);
        background: rgba(4,14,40,.75);
        opacity: .92;
        white-space: nowrap;
    }

    .ccv-set-note{
        margin-top: 10px;
        font-size: 11px;
        opacity: .72;
        line-height: 1.3;
    }

    .ccv-set-toggle-row{
        display:flex;
        gap: 10px;
        flex-wrap: wrap;
    }
    .ccv-set-chip{
        border-radius: 999px;
        padding: 8px 14px;
        border: 1px solid rgba(110,175,255,.65);
        background: rgba(6,22,52,.85);
        color: rgba(245,247,255,.92);
        font-size: 12px;
        letter-spacing: .08em;
        text-transform: uppercase;
        cursor:pointer;
        transition: transform .08s ease-out, box-shadow .08s ease-out, filter .08s ease-out;
    }
    .ccv-set-chip:hover{ transform: translateY(-1px); box-shadow: 0 0 16px rgba(0,200,255,.30); }
    .ccv-set-chip.is-active{
        background: linear-gradient(135deg, #23b1ff, #0067ff);
        color: #010208;
        box-shadow: 0 0 16px rgba(0,150,255,.85);
        border-color: rgba(110,190,255,.95);
    }
    .ccv-set-chip.is-active.is-offline{
        background: linear-gradient(135deg, rgba(190,200,220,.92), rgba(120,130,150,.92));
        box-shadow: 0 0 16px rgba(210,220,240,.35);
        color:#091225;
        border-color: rgba(220,230,245,.75);
    }

    .ccv-set-pills{
        display:flex;
        gap: 10px;
        flex-wrap: wrap;
    }
    .ccv-set-pill{
        flex: 1 1 180px;
        border-radius: 16px;
        padding: 10px 12px;
        border: 1px solid rgba(110,175,255,.65);
        background: rgba(6,22,52,.85);
        color: rgba(245,247,255,.92);
        cursor:pointer;
        text-align:left;
        transition: transform .08s ease-out, box-shadow .08s ease-out, filter .08s ease-out;
        position: relative;
        overflow: hidden;
    }
    .ccv-set-pill:after{
        content:'';
        position:absolute;
        inset:0;
        background: linear-gradient(120deg, rgba(255,255,255,0) 0%, rgba(255,255,255,.10) 20%, rgba(255,255,255,0) 45%);
        transform: translateX(-120%);
        transition: transform .12s ease-out;
        pointer-events:none;
        opacity:.55;
    }
    .ccv-set-pill:hover{ transform: translateY(-1px); box-shadow: 0 0 18px rgba(0,180,255,.28); }
    .ccv-set-pill:hover:after{ transform: translateX(120%); }

    .ccv-set-pill .t{ display:block; font-weight:700; font-size: 13px; }
    .ccv-set-pill .d{ display:block; margin-top: 2px; font-size: 11px; opacity:.78; }

    .ccv-set-pill.is-active{
        background: linear-gradient(135deg, #23b1ff, #0067ff);
        color: #010208;
        box-shadow: 0 0 18px rgba(0,150,255,.85);
        border-color: rgba(110,190,255,.95);
    }
    .ccv-set-pill.is-active .d{ opacity:.85; }

    .ccv-range-stack{ display:grid; gap: 8px; }

    .ccv-range-card{
        display:flex;
        align-items:center;
        justify-content: space-between;
        gap: 12px;
        border-radius: 16px;
        padding: 12px 12px;
        border: 1px solid rgba(110,175,255,.65);
        background: rgba(6,22,52,.78);
        cursor:pointer;
        text-align:left;
        transition: transform .08s ease-out, box-shadow .08s ease-out, filter .08s ease-out;
        position: relative;
        overflow:hidden;
    }
    .ccv-range-card:after{
        content:'';
        position:absolute;
        inset:0;
        background: radial-gradient(circle at 25% 50%, rgba(35,177,255,.18), rgba(0,0,0,0) 60%);
        opacity:.0;
        transition: opacity .10s ease-out;
        pointer-events:none;
    }
    .ccv-range-card:hover{
        transform: translateY(-1px);
        box-shadow: 0 0 18px rgba(0,180,255,.26);
    }
    .ccv-range-card:hover:after{ opacity: 1; }

    .ccv-range-title{ font-weight: 800; font-size: 13px; }
    .ccv-range-desc{ margin-top: 3px; font-size: 11px; opacity: .78; line-height: 1.25; }

    .ccv-range-dot{
        width: 10px; height: 10px; border-radius: 999px;
        background: rgba(140,190,255,.35);
        box-shadow: 0 0 10px rgba(0,150,255,.22);
        flex: 0 0 auto;
    }

    .ccv-range-card.is-active{
        background: linear-gradient(135deg, #23b1ff, #0067ff);
        border-color: rgba(110,190,255,.95);
        box-shadow: 0 0 18px rgba(0,150,255,.85);
        color: #010208;
    }
    .ccv-range-card.is-active .ccv-range-desc{ opacity: .88; }
    .ccv-range-card.is-active .ccv-range-dot{
        background: #010208;
        box-shadow: 0 0 14px rgba(255,255,255,.35);
    }

    .ccv-set-toast{
        position: fixed;
        right: 18px;
        bottom: 18px;
        min-width: 260px;
        max-width: 360px;
        padding: 10px 12px;
        border-radius: 14px;
        border: 1px solid rgba(120,190,255,.65);
        background: rgba(3,15,38,.92);
        color: rgba(245,247,255,.94);
        font-size: 12px;
        font-weight: 700;
        box-shadow: 0 0 22px rgba(0,150,255,.25), 0 0 60px rgba(0,0,0,.85);
        opacity: 0;
        transform: translateY(8px);
        pointer-events: none;
        transition: opacity .12s ease-out, transform .12s ease-out;
        z-index: 99999;
    }
    .ccv-set-toast.is-show{
        opacity: 1;
        transform: translateY(0);
    }

    @media (max-width: 960px){
        .ccv-settings-shell{ padding: 12px; }
        .ccv-set-pills{ gap: 8px; }
        .ccv-set-pill{ flex: 1 1 100%; }
    }
    </style>
    <?php

}, 10, 1);