<?php
/**
 * Canonical courier balances payload.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! function_exists( 'ccv_ccb_get_balances_for_courier' ) ) {
    function ccv_ccb_get_balances_for_courier( $courier_id ) {
        $courier_id = intval( $courier_id );

        $balances = array(
            'available' => 0.0,
            'clearing'  => 0.0,
            'held'      => 0.0,
            'paid'      => 0.0,
            'currency'  => 'GYD',
        );

        if ( ! $courier_id ) {
            return $balances;
        }

        /**
         * Primary truth: current courier earnings engine.
         */
        if (
            class_exists( 'Caricove_Courier_Earnings_Engine' ) &&
            method_exists( 'Caricove_Courier_Earnings_Engine', 'get_balances_for_courier' )
        ) {
            $engine = Caricove_Courier_Earnings_Engine::get_balances_for_courier( $courier_id );

            if ( is_array( $engine ) ) {
                $balances['available'] = floatval( $engine['available'] ?? 0 );
                $balances['clearing']  = floatval( $engine['clearing'] ?? 0 );
                $balances['held']      = floatval( $engine['held'] ?? 0 );
                $balances['paid']      = floatval( $engine['paid'] ?? 0 );
            }
        }
        /**
         * Legacy fallback only if the old class exists.
         */
        elseif (
            class_exists( 'Caricove_Logistics_Earnings' ) &&
            method_exists( 'Caricove_Logistics_Earnings', 'get_courier_balances' )
        ) {
            $engine = Caricove_Logistics_Earnings::get_courier_balances( $courier_id );

            if ( is_array( $engine ) ) {
                $balances['available'] = floatval( $engine['available'] ?? 0 );
                $balances['clearing']  = floatval( $engine['clearing'] ?? 0 );
                $balances['held']      = floatval( $engine['held'] ?? 0 );
                $balances['paid']      = floatval( $engine['paid'] ?? 0 );
            }
        }

        if ( function_exists( 'get_woocommerce_currency' ) ) {
            $balances['currency'] = (string) get_woocommerce_currency();
        }

        return apply_filters( 'caricove_courier_bridge_balances', $balances, $courier_id );
    }
}

if ( ! function_exists( 'ccv_ccb_ajax_get_balances' ) ) {
    function ccv_ccb_ajax_get_balances() {
        if ( ! is_user_logged_in() ) {
            wp_send_json_error( array( 'message' => 'Not logged in' ), 401 );
        }

        $nonce = isset( $_REQUEST['nonce'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['nonce'] ) ) : '';
        if ( ! wp_verify_nonce( $nonce, 'caricove_courier_bridge_state' ) ) {
            wp_send_json_error( array( 'message' => 'Bad nonce' ), 403 );
        }

        wp_send_json_success( ccv_ccb_get_balances_for_courier( get_current_user_id() ) );
    }
}

add_action( 'wp_ajax_caricove_courier_get_balances', 'ccv_ccb_ajax_get_balances' );