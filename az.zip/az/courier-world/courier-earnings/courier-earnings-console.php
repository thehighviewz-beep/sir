<?php
/**
 * Courier Earnings — Courier Console Integration (GYD only)
 * - Feeds balances to console pills
 * - Uses payout requests module (instant = admin approval)
 */

if ( ! defined('ABSPATH') ) { exit; }

if ( ! class_exists('Caricove_Courier_Earnings_Console') ) {

class Caricove_Courier_Earnings_Console {

    public static function boot() {
        add_filter('caricove_logistics_scaffold_balances', array(__CLASS__, 'filter_balances'), 10, 2);
    }

    public static function filter_balances($balances, $courier_id) {
        if ( ! $courier_id || ! class_exists('Caricove_Courier_Earnings_Engine') ) return $balances;

        $b = Caricove_Courier_Earnings_Engine::get_balances_for_courier($courier_id);

        $balances['available'] = floatval($b['available'] ?? 0);
        $balances['clearing']  = floatval($b['clearing'] ?? 0);
        $balances['held']      = floatval($b['held'] ?? 0);
        $balances['currency']  = 'GYD';

        return $balances;
    }
}

Caricove_Courier_Earnings_Console::boot();

}