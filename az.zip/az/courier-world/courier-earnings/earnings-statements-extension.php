<?php
/**
 * Caricove Courier Earnings — Statements Panel (ES2) [SEXY + PAGINATED + NO THEME BLEED]
 * - 10 rows per page + shimmering gold dot pagination
 * - Brighter placeholder text (#fff) + white date picker
 * - Hard scope reset to kill theme bleed + kill ALL red flashes
 * - Uses courier console meta ajax URL if present (fallback to admin-ajax.php)
 */

if ( ! defined('ABSPATH') ) exit;

if ( ! function_exists('ccv_es2_courier_debt_remaining_total') ) {
    function ccv_es2_courier_debt_remaining_total() {
        if ( ! is_user_logged_in() ) {
            return 0.0;
        }

        $courier_id = get_current_user_id();
        $store = get_option('caricove_bank_courier_recovery_v1', []);
        if ( ! is_array($store) ) {
            return 0.0;
        }

        $total = 0.0;
        foreach ( $store as $row ) {
            if ( ! is_array($row) ) {
                continue;
            }
            if ( (int) ($row['courier_id'] ?? 0) !== (int) $courier_id ) {
                continue;
            }

            $status = sanitize_key((string) ($row['status'] ?? 'open'));
            if ( in_array($status, array('recovered','waived'), true) ) {
                continue;
            }

            $total += abs((float) ($row['remaining_amount_total'] ?? 0));
        }

        return round((float) $total, 2);
    }
}
add_action('wp_footer', function(){
    if ( is_admin() ) return;
?>
<style>
/* =========================================================
   ES2 — HARD SCOPE RESET (kills theme bleed + red flashes)
========================================================= */
#ccv-es2, #ccv-es2 * { box-sizing:border-box !important; }
#ccv-es2 { all: initial; display:block; }
#ccv-es2, #ccv-es2 * {
  font-family: inherit !important;
  -webkit-tap-highlight-color: transparent !important;
  outline: none !important;
  text-decoration: none !important;
}
#ccv-es2 a, #ccv-es2 a:visited, #ccv-es2 a:hover { color: inherit !important; text-decoration:none !important; }
#ccv-es2 *:focus, #ccv-es2 *:focus-visible { outline:none !important; box-shadow:none !important; }
#ccv-es2 * { transition: none !important; } /* stop “red flash” transitions from themes */

/* Force neutralize common red “error” classes inside this panel only */
#ccv-es2 .error,
#ccv-es2 .woocommerce-error,
#ccv-es2 [class*="error"],
#ccv-es2 [id*="error"]{
  color:#eaf4ff !important;
  border-color: rgba(120,185,255,.35) !important;
  background: rgba(0,0,0,.22) !important;
  box-shadow:none !important;
}

/* =========================================================
   ES2 — PANEL SKIN
========================================================= */
#ccv-es2{
  margin-top:14px;
  border-radius:18px;
  padding:14px;
  border:1px solid rgba(90,150,255,.35);
  background:radial-gradient(circle at top left, rgba(8,32,80,.85), rgba(3,8,24,.98));
  box-shadow:0 0 22px rgba(0,0,0,.55);
  overflow:hidden;
  position:relative;
  isolation:isolate;
  color:#eaf4ff !important;
}
#ccv-es2:before{
  content:'';
  position:absolute; inset:-2px;
  background:
    radial-gradient(circle at 20% 10%, rgba(35,177,255,.18), transparent 55%),
    radial-gradient(circle at 85% 15%, rgba(140,80,255,.14), transparent 60%),
    radial-gradient(circle at 55% 95%, rgba(255,215,100,.08), transparent 55%);
  pointer-events:none;
  z-index:0;
}
#ccv-es2 > *{ position:relative; z-index:1; }

.ccv-es2-head{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap}
.ccv-es2-title{font-size:13px;letter-spacing:.12em;text-transform:uppercase;opacity:.92;font-weight:900}
.ccv-es2-actions{display:flex;gap:10px;flex-wrap:wrap;align-items:center}

.ccv-es2-btn{
  border-radius:999px;
  padding:8px 12px;
  border:1px solid rgba(120,185,255,.55);
  background:rgba(0,0,0,.18);
  color:#eaf4ff !important;
  font-size:12px;
  font-weight:900;
  letter-spacing:.08em;
  text-transform:uppercase;
  cursor:pointer;
}
.ccv-es2-btn:hover{
  border-color: rgba(56,189,248,.95) !important;
  box-shadow:0 0 0 4px rgba(0,150,255,.18) !important;
}
.ccv-es2-btn.primary{
  background:linear-gradient(135deg,#23b1ff,#0067ff);
  color:#06101a !important;
  border-color:rgba(120,185,255,.75);
  box-shadow:0 0 16px rgba(0,150,255,.55);
}
.ccv-es2-btn.primary:hover{
  box-shadow:0 0 22px rgba(0,170,255,.55) !important;
}

/* Panel visibility */
.ccv-es2-panel{margin-top:12px}
.ccv-es2-hidden{display:none}

/* Controls layout */
.ccv-es2-controls{
  display:grid;
  grid-template-columns: 1.2fr 1fr;
  gap:10px;
}
@media (max-width: 980px){ .ccv-es2-controls{grid-template-columns:1fr;} }

.ccv-es2-box{
  border-radius:16px;
  border:1px solid rgba(255,255,255,.10);
  background:rgba(0,0,0,.18);
  padding:12px;
}
.ccv-es2-box h4{
  margin:0 0 10px 0;
  font-size:11px;
  letter-spacing:.12em;
  text-transform:uppercase;
  opacity:.85;
  font-weight:900;
}

.ccv-es2-chips{display:flex;gap:8px;flex-wrap:wrap}
.ccv-es2-chip{
  border-radius:999px;
  padding:7px 10px;
  border:1px solid rgba(120,185,255,.45);
  background:transparent;
  color:#eaf4ff !important;
  font-size:11px;
  letter-spacing:.09em;
  text-transform:uppercase;
  font-weight:900;
  cursor:pointer;
}
.ccv-es2-chip:hover{
  border-color: rgba(56,189,248,.95) !important;
  box-shadow:0 0 0 4px rgba(0,150,255,.18) !important;
}
.ccv-es2-chip.is-on{
  background:linear-gradient(135deg,#23b1ff,#0067ff);
  color:#06101a !important;
  border-color:rgba(120,185,255,.75);
  box-shadow:0 0 16px rgba(0,150,255,.55);
}

.ccv-es2-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px}
@media (max-width: 980px){ .ccv-es2-grid{grid-template-columns:1fr;} }

.ccv-es2-field{display:flex;flex-direction:column;gap:6px}
.ccv-es2-field label{
  font-size:11px;letter-spacing:.10em;text-transform:uppercase;
  opacity:.78;font-weight:900;
}

.ccv-es2-input{
  border-radius:999px;
  padding:9px 12px;
  border:1px solid rgba(120,185,255,.45);
  background:rgba(3,15,38,.96);
  color:#ffffff !important;
  outline:none;
  font-size:12px;
}
.ccv-es2-input::placeholder{
  color:#ffffff !important;
  opacity: .92 !important;
}
.ccv-es2-input:hover,
.ccv-es2-input:focus{
  border-color:#38bdf8 !important;
  box-shadow:0 0 0 4px rgba(0,150,255,.22) !important;
}

/* Date icon + calendar UI */
.ccv-es2-input[type="date"]{ color:#ffffff !important; color-scheme: dark !important; }
.ccv-es2-input[type="date"]::-webkit-calendar-picker-indicator{
  filter: invert(1) brightness(1.35) !important;
  opacity: .95 !important;
  cursor:pointer !important;
}

/* KPIs */
.ccv-es2-kpis{margin-top:10px;display:flex;flex-wrap:wrap;gap:8px}
.ccv-es2-kpi{
  border-radius:14px;
  padding:10px 12px;
  border:1px solid rgba(120,185,255,.25);
  background:rgba(0,0,0,.20);
  min-width:170px;
}
.ccv-es2-kpi .l{font-size:11px;opacity:.78;text-transform:uppercase;letter-spacing:.08em;font-weight:900}
.ccv-es2-kpi .v{margin-top:4px;font-size:14px;font-weight:900}

/* Table */
.ccv-es2-tablewrap{
  margin-top:12px;
  border-radius:14px;
  overflow:auto;
  border:1px solid rgba(120,185,255,.20);
}
.ccv-es2-table{width:100%;border-collapse:collapse}
.ccv-es2-table th,.ccv-es2-table td{
  padding:10px 8px;
  border-bottom:1px solid rgba(255,255,255,.08);
  font-size:12px;white-space:nowrap;
  color:#eaf4ff !important;
}
.ccv-es2-table th{
  font-size:11px;letter-spacing:.1em;text-transform:uppercase;opacity:.85;font-weight:900;
}
.ccv-es2-table tr:hover td{ background: rgba(0,160,255,.06) !important; }
.ccv-es2-empty{opacity:.78}

/* Status badge */
.ccv-es2-badge{
  display:inline-flex;align-items:center;gap:6px;
  padding:3px 8px;border-radius:999px;
  border:1px solid rgba(120,185,255,.45);
  background:rgba(0,0,0,.22);
  font-weight:900;font-size:11px;
}
.ccv-es2-badge[data-st="available"]{border-color:rgba(0,255,170,.45)}
.ccv-es2-badge[data-st="clearing"]{border-color:rgba(255,210,85,.45)}
.ccv-es2-badge[data-st="held"]{border-color:rgba(255,120,160,.45)}
.ccv-es2-badge[data-st="paid"]{border-color:rgba(160,110,255,.45)}

/* =========================================================
   Pagination — shimmering gold dots
========================================================= */
.ccv-es2-pager{
  margin-top:12px;
  display:flex;
  justify-content:space-between;
  align-items:center;
  gap:10px;
  flex-wrap:wrap;
}
.ccv-es2-pageinfo{
  font-size:11px;
  letter-spacing:.08em;
  text-transform:uppercase;
  opacity:.85;
  font-weight:900;
}
.ccv-es2-dots{display:flex;gap:8px;align-items:center;flex-wrap:wrap}
.ccv-es2-dot{
  width:10px;height:10px;border-radius:999px;
  border:1px solid rgba(255,215,100,.55);
  background: radial-gradient(circle at 30% 30%, rgba(255,255,255,.65), rgba(255,215,100,.18));
  box-shadow: 0 0 10px rgba(255,215,100,.20);
  cursor:pointer;
  position:relative;
}
.ccv-es2-dot:before{
  content:'';
  position:absolute; inset:-6px;
  border-radius:999px;
  background: radial-gradient(circle, rgba(255,215,100,.22), transparent 60%);
  opacity:0;
}
.ccv-es2-dot:hover:before{ opacity:1; }
.ccv-es2-dot.is-on{
  background: radial-gradient(circle at 30% 30%, rgba(255,255,255,.85), rgba(255,215,100,.55));
  box-shadow: 0 0 18px rgba(255,215,100,.45);
}

.ccv-es2-input[type="date"] {
  color: #ffffff !important;
}

/* =========================================================
   ES2 — TARGETED “NO BLEED” for Buttons + Pills + Date Picker
   (uses YOUR actual classes)
========================================================= */

/* 1) Buttons (View / Print / Load) */
#ccv-es2 .ccv-es2-btn,
#ccv-es2 .ccv-es2-btn:visited{
  color: #eaf4ff !important;
  background: rgba(0,0,0,.18) !important;
  border: 1px solid rgba(120,185,255,.55) !important;
  box-shadow: none !important;
  text-decoration: none !important;
}

#ccv-es2 .ccv-es2-btn:hover,
#ccv-es2 .ccv-es2-btn:focus,
#ccv-es2 .ccv-es2-btn:active{
  color: #ffffff !important;
  border-color: rgba(56,189,248,.95) !important;
  background: rgba(3,15,38,.96) !important;
  box-shadow: 0 0 0 4px rgba(56,189,248,.18) !important;
}

/* Primary button stays blue, never theme-red */
#ccv-es2 .ccv-es2-btn.primary{
  background: linear-gradient(135deg,#23b1ff,#0067ff) !important;
  border-color: rgba(120,185,255,.85) !important;
  color:#06101a !important;
  box-shadow: 0 0 16px rgba(0,150,255,.55) !important;
}
#ccv-es2 .ccv-es2-btn.primary:hover{
  filter: brightness(1.06) !important;
  box-shadow: 0 0 22px rgba(0,170,255,.55) !important;
}

/* 2) Status pills/chips (Available / Clearing / Held / Paid) */
#ccv-es2 .ccv-es2-chip{
  color: #eaf4ff !important;
  background: rgba(0,0,0,.10) !important;
  border: 1px solid rgba(120,185,255,.45) !important;
  box-shadow: none !important;
}

#ccv-es2 .ccv-es2-chip:hover{
  /* sexy hover (blue) – never red */
  color: #ffffff !important;
  border-color: rgba(56,189,248,.95) !important;
  background: rgba(0,160,255,.08) !important;
  box-shadow: 0 0 0 4px rgba(56,189,248,.16) !important;
}

/* “Selected” chip (is-on) stays blue */
#ccv-es2 .ccv-es2-chip.is-on{
  background: linear-gradient(135deg,#23b1ff,#0067ff) !important;
  color: #06101a !important;
  border-color: rgba(120,185,255,.85) !important;
  box-shadow: 0 0 18px rgba(0,150,255,.55) !important;
}

/* Optional: Gold hover variant (uncomment if you prefer gold instead of blue)
#ccv-es2 .ccv-es2-chip:hover{
  border-color: rgba(255,215,100,.95) !important;
  background: rgba(255,215,100,.06) !important;
  box-shadow: 0 0 0 4px rgba(255,215,100,.14) !important;
}
*/




/* ================================
   CCV ES2 DATE INPUT — PREMIUM ICON
   ================================ */

/* Base date input */
#ccv-es2 .ccv-es2-input[type="date"]{
  -webkit-appearance: none !important;
  appearance: none !important;

  width: 100%;
  padding: 10px 46px 10px 14px !important;
  border-radius: 999px !important;

  background: rgba(5,18,44,.98) !important;
  border: 1px solid rgba(56,189,248,.7) !important;

  color: #ffffff !important;
  font-weight: 900 !important;
  letter-spacing: .04em !important;

  cursor: pointer !important;

  box-shadow:
    0 0 0 1px rgba(0,0,0,.4) inset,
    0 0 18px rgba(56,189,248,.25),
    0 0 36px rgba(0,120,255,.18) !important;
}

/* Hover / focus — NO RED */
#ccv-es2 .ccv-es2-input[type="date"]:hover,
#ccv-es2 .ccv-es2-input[type="date"]:focus,
#ccv-es2 .ccv-es2-input[type="date"]:focus-visible{
  border-color: #38bdf8 !important;
  outline: none !important;
  box-shadow:
    0 0 0 2px rgba(56,189,248,.25),
    0 0 28px rgba(56,189,248,.35),
    0 0 60px rgba(0,120,255,.25) !important;
}

/* Kill native icon but keep click target */
#ccv-es2 .ccv-es2-input[type="date"]::-webkit-calendar-picker-indicator{
  opacity: 0 !important;
  position: absolute !important;
  right: 0;
  top: 0;
  width: 100%;
  height: 100%;
  cursor: pointer !important;
}

/* Field wrapper required for icon */
#ccv-es2 .ccv-es2-field{
  position: relative !important;
}

/* Custom glowing calendar icon */
#ccv-es2 .ccv-es2-field:has(input[type="date"])::after{
  content: "";
  position: absolute;
  right: 14px;
  top: 50%;
  transform: translateY(-50%);
  margin-bottom:100px;
  width: 18px;
  height: 18px;

  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none'%3E%3Crect x='3' y='5' width='18' height='16' rx='3' stroke='%23bfe9ff' stroke-width='2'/%3E%3Cpath d='M3 9h18' stroke='%23bfe9ff' stroke-width='2'/%3E%3Cpath d='M8 3v4M16 3v4' stroke='%23bfe9ff' stroke-width='2'/%3E%3C/svg%3E");

  background-size: contain;
  background-repeat: no-repeat;

  filter:
    drop-shadow(0 0 6px rgba(56,189,248,.6))
    drop-shadow(0 0 14px rgba(0,120,255,.35));

  pointer-events: none;
}

/* Force white calendar text (Chrome) */
#ccv-es2 .ccv-es2-input[type="date"]{
  color-scheme: dark !important;
}





/* Kill any theme “red” focus/hover on inputs */
#ccv-es2 .ccv-es2-input:hover,
#ccv-es2 .ccv-es2-input:focus,
#ccv-es2 .ccv-es2-input:active{
  border-color: rgba(56,189,248,.95) !important;
  box-shadow: 0 0 0 4px rgba(56,189,248,.18) !important;
  outline: none !important;
}

/* 4) Absolute “no red” override inside ES2 (last line of defense) */
#ccv-es2 *{
  caret-color: #ffffff !important;
}
#ccv-es2 *[style*="red"],
#ccv-es2 *[style*="#f00"],
#ccv-es2 *[style*="#ff0000"]{
  color: #ffffff !important;
  border-color: rgba(120,185,255,.55) !important;
}

.ccv-es2-dot.is-on:after{
  content:'';
  position:absolute; inset:-2px;
  border-radius:999px;
  background: conic-gradient(from 180deg, rgba(255,215,100,0), rgba(255,215,100,.55), rgba(255,215,100,0));
  filter: blur(1px);
  animation: ccvGoldSpin 1.6s linear infinite;
  opacity:.75;
}
@keyframes ccvGoldSpin{
  0%{ transform: rotate(0deg); }
  100%{ transform: rotate(360deg); }
}

/* Print */
@media print{
  body * { visibility:hidden !important; }
  #ccv-es2, #ccv-es2 * { visibility:visible !important; }
  #ccv-es2{ position:absolute; left:0; top:0; width:100%; box-shadow:none; }
  .ccv-es2-actions, .ccv-es2-controls, .ccv-es2-pager { display:none !important; }
  .ccv-es2-tablewrap{ border:1px solid #ddd !important; }
  .ccv-es2-table th,.ccv-es2-table td{ color:#000 !important; }
  .ccv-es2-title{ color:#000 !important; }
}
</style>

<script>
(function(){
  function qs(s,c){return (c||document).querySelector(s);}
  function qsa(s,c){return Array.prototype.slice.call((c||document).querySelectorAll(s));}
  function meta(){ return document.getElementById('ccv-courier-js-meta'); }
  function ajaxUrl(){
    var u = meta()?.getAttribute('data-ajax-url') || '';
    if (!u) u = '<?php echo esc_js( admin_url("admin-ajax.php") ); ?>';
    return u;
  }

  function ymd(d){ return d.toISOString().slice(0,10); }
  function fmt(n){ try { return Number(n||0).toFixed(2); } catch(e){ return '0.00'; } }

  function badge(st){
    st = (st||'').toLowerCase();
    var label = st.replaceAll('_',' ');
    return '<span class="ccv-es2-badge" data-st="'+st+'">'+label.toUpperCase()+'</span>';
  }

window.CCV_COURIER_DEBT_REMAINING = <?php echo json_encode( (float) ccv_es2_courier_debt_remaining_total() ); ?>;

  var ES2 = {
    rows: [],
    currency: 'GYD',
    pageSize: 10,
    page: 1
  };

  function renderKpis(currency, totals){
    var el = qs('#ccv-es2-kpis');
    if (!el) return;
   el.innerHTML =
      '<div class="ccv-es2-kpi"><div class="l">Entries</div><div class="v">'+(totals.count||0)+'</div></div>'+
      '<div class="ccv-es2-kpi"><div class="l">Gross</div><div class="v">'+currency+' '+fmt(totals.gross)+'</div></div>'+
      '<div class="ccv-es2-kpi"><div class="l">Debt Balance Remaining</div><div class="v">'+currency+' '+fmt(totals.debt_remaining)+'</div></div>'+
      '<div class="ccv-es2-kpi"><div class="l">Net</div><div class="v">'+currency+' '+fmt(totals.net)+'</div></div>';
  }

  function slicePage(rows, page, pageSize){
    var total = rows.length;
    var pages = Math.max(1, Math.ceil(total / pageSize));
    page = Math.min(Math.max(1, page), pages);
    var start = (page - 1) * pageSize;
    var end = start + pageSize;
    return { page: page, pages: pages, total: total, items: rows.slice(start, end) };
  }

  function renderPager(total, page, pages){
    var host = qs('#ccv-es2-pager');
    if (!host) return;

    // Dots: if lots of pages, show a window around current
    var maxDots = 11;
    var start = Math.max(1, page - Math.floor(maxDots/2));
    var end = Math.min(pages, start + maxDots - 1);
    start = Math.max(1, end - maxDots + 1);

    var dots = '';
    for (var p = start; p <= end; p++){
      dots += '<div class="ccv-es2-dot '+(p===page?'is-on':'')+'" data-page="'+p+'" title="Page '+p+'"></div>';
    }

    host.innerHTML =
      '<div class="ccv-es2-pageinfo">Page <span class="mono">'+page+'</span> / <span class="mono">'+pages+'</span> • <span class="mono">'+total+'</span> rows</div>' +
      '<div class="ccv-es2-dots" id="ccv-es2-dots">'+dots+'</div>';

    qsa('#ccv-es2-dots .ccv-es2-dot').forEach(function(d){
      d.addEventListener('click', function(){
        ES2.page = parseInt(d.getAttribute('data-page')||'1',10) || 1;
        renderTable();
      });
    });
  }

  function renderTable(){
    var body = qs('#ccv-es2-body');
    if (!body) return;

    var paged = slicePage(ES2.rows, ES2.page, ES2.pageSize);
    ES2.page = paged.page;

    if (!paged.items.length){
      body.innerHTML = '<tr><td colspan="8" class="ccv-es2-empty">No entries match your filters.</td></tr>';
      renderPager(0, 1, 1);
      return;
    }

    body.innerHTML = paged.items.map(function(r){
      return '<tr>'
        + '<td>'+(r.date||'')+'</td>'
        + '<td>#'+(r.shipment_id||'')+'</td>'
        + '<td>'+(r.route||'')+'</td>'
        + '<td>'+badge(r.status)+'</td>'
        + '<td>'+ES2.currency+' '+fmt(r.gross_gyd)+'</td>'
        + '<td>'+ES2.currency+' '+fmt(r.fee_gyd)+'</td>'
        + '<td>'+ES2.currency+' '+fmt(r.net_gyd)+'</td>'
        + '<td>'+(r.clears_on||'—')+'</td>'
        + '</tr>';
    }).join('');

    renderPager(paged.total, paged.page, paged.pages);
  }

  function ensureInjected(){
    var col = qs('.ccv-console-body[data-view="earnings"] .ccv-console-col--full');
    if (!col) return;
    if (qs('#ccv-es2')) return;

    var wrap = document.createElement('div');
    wrap.id = 'ccv-es2';
    wrap.innerHTML =
      '<div class="ccv-es2-head">' +
        '<div class="ccv-es2-title">Monthly Statements</div>' +
        '<div class="ccv-es2-actions">' +
          '<button class="ccv-es2-btn" id="ccv-es2-toggle" type="button">View</button>' +
          '<button class="ccv-es2-btn" id="ccv-es2-print" type="button">Print</button>' +
          '<button class="ccv-es2-btn primary" id="ccv-es2-load" type="button">Load</button>' +
        '</div>' +
      '</div>' +

      '<div class="ccv-es2-panel ccv-es2-hidden" id="ccv-es2-panel">' +

        '<div class="ccv-es2-controls">' +
          '<div class="ccv-es2-box">' +
            '<h4>Status</h4>' +
            '<div class="ccv-es2-chips" id="ccv-es2-status">' +
              '<button class="ccv-es2-chip is-on" data-st="all" type="button">All</button>' +
              '<button class="ccv-es2-chip" data-st="available" type="button">Available</button>' +
              '<button class="ccv-es2-chip" data-st="clearing" type="button">Clearing</button>' +
              '<button class="ccv-es2-chip" data-st="held" type="button">Held</button>' +
              '<button class="ccv-es2-chip" data-st="paid" type="button">Paid</button>' +
              '<button class="ccv-es2-chip" data-st="recovery" type="button">Recovery</button>' +
              '<button class="ccv-es2-chip" data-st="partially_recovered" type="button">Partially Recovered</button>' +
              '<button class="ccv-es2-chip" data-st="recovered" type="button">Recovered</button>' +
            '</div>' +
          '</div>' +

          '<div class="ccv-es2-box">' +
            '<h4>Filters</h4>' +
            '<div class="ccv-es2-grid">' +
              '<div class="ccv-es2-field"><label>Date start</label><input class="ccv-es2-input" type="date" id="ccv-es2-start"></div>' +
              '<div class="ccv-es2-field"><label>Date end</label><input class="ccv-es2-input" type="date" id="ccv-es2-end"></div>' +
              '<div class="ccv-es2-field"><label>Search</label><input class="ccv-es2-input" type="text" id="ccv-es2-q" placeholder="Shipment #, route, case…"></div>' +
              '<div class="ccv-es2-field"><label>Net min</label><input class="ccv-es2-input" type="number" step="0.01" id="ccv-es2-min" placeholder="0.00"></div>' +
            '</div>' +
          '</div>' +
        '</div>' +

        '<div class="ccv-es2-kpis" id="ccv-es2-kpis"></div>' +

        '<div class="ccv-es2-tablewrap">' +
          '<table class="ccv-es2-table">' +
            '<thead><tr><th>Date</th><th>Shipment</th><th>Route</th><th>Status</th><th>Gross</th><th>Fee</th><th>Net</th><th>Clears</th></tr></thead>' +
            '<tbody id="ccv-es2-body"><tr><td colspan="8" class="ccv-es2-empty">Click Load.</td></tr></tbody>' +
          '</table>' +
        '</div>' +

        '<div class="ccv-es2-pager" id="ccv-es2-pager"></div>' +

      '</div>';

    col.appendChild(wrap);

    // Default date range: this month -> today
    var now = new Date();
    var start = new Date(now.getFullYear(), now.getMonth(), 1);
    qs('#ccv-es2-start').value = ymd(start);
    qs('#ccv-es2-end').value = ymd(now);

    qs('#ccv-es2-toggle').addEventListener('click', function(){
      var p = qs('#ccv-es2-panel');
      p.classList.toggle('ccv-es2-hidden');
      this.textContent = p.classList.contains('ccv-es2-hidden') ? 'View' : 'Hide';
    });

    qs('#ccv-es2-print').addEventListener('click', function(){
      qs('#ccv-es2-panel').classList.remove('ccv-es2-hidden');
      qs('#ccv-es2-toggle').textContent = 'Hide';
      window.print();
    });

    qsa('#ccv-es2-status .ccv-es2-chip').forEach(function(b){
      b.addEventListener('click', function(){
        qsa('#ccv-es2-status .ccv-es2-chip').forEach(x=>x.classList.remove('is-on'));
        b.classList.add('is-on');
        ES2.page = 1;
        load(); // refresh
      });
    });

    qs('#ccv-es2-load').addEventListener('click', function(){ ES2.page = 1; load(); });

    // “live” filter updates
    ['ccv-es2-q','ccv-es2-min','ccv-es2-start','ccv-es2-end'].forEach(function(id){
      var el = qs('#'+id);
      if (!el) return;
      el.addEventListener('change', function(){ ES2.page = 1; load(); });
      el.addEventListener('keyup', function(){
        if (id === 'ccv-es2-q') { ES2.page = 1; load(); }
      });
    });

    function load(){
      var body = qs('#ccv-es2-body');
      if (body) body.innerHTML = '<tr><td colspan="8" class="ccv-es2-empty">Loading…</td></tr>';

      var start = qs('#ccv-es2-start').value;
      var end   = qs('#ccv-es2-end').value;

      if (!start || !end){
        var n = new Date();
        qs('#ccv-es2-start').value = ymd(new Date(n.getFullYear(), n.getMonth(), 1));
        qs('#ccv-es2-end').value   = ymd(n);
        start = qs('#ccv-es2-start').value;
        end   = qs('#ccv-es2-end').value;
      }

      var url = ajaxUrl()
        + '?action=cc_courier_get_statements'
        + '&start=' + encodeURIComponent(start)
        + '&end=' + encodeURIComponent(end)
        + '&_=' + Date.now();

      fetch(url, { credentials:'same-origin' })
        .then(r => r.json().then(j => ({ok:r.ok, status:r.status, j:j})))
        .then(function(x){
          var resp = x.j;

          if (!x.ok || !resp || !resp.success || !resp.data){
            var msg = (resp && resp.data && resp.data.message)
              ? resp.data.message
              : ('Load failed. HTTP: ' + x.status);
            if (body) body.innerHTML = '<tr><td colspan="8" class="ccv-es2-empty">'+msg+'</td></tr>';
            renderPager(0,1,1);
            return;
          }

          ES2.currency = resp.data.currency || 'GYD';

          var rows = resp.data.rows || [];
          var st = qs('#ccv-es2-status .ccv-es2-chip.is-on')?.getAttribute('data-st') || 'all';
          var q  = (qs('#ccv-es2-q').value || '').trim().toLowerCase();
          var minNet = parseFloat(qs('#ccv-es2-min').value || '0') || 0;

          var filtered = rows.filter(function(r){
            if (st !== 'all' && (String(r.status||'').toLowerCase() !== st)) return false;
            if (minNet > 0 && Number(r.net_gyd||0) < minNet) return false;
            if (q){
              var hay = (String(r.shipment_id||'')+' '+String(r.route||'')+' '+String(r.note||'')).toLowerCase();
              if (!hay.includes(q)) return false;
            }
            return true;
          });

         // KPI totals for what you SEE
          var debtRemaining = 0;
          try {
            debtRemaining = Number((window.CCV_COURIER_DEBT_REMAINING || 0));
          } catch(e) {
            debtRemaining = 0;
          }

          var t = {count:0,gross:0,debt_remaining:debtRemaining,net:0};
          filtered.forEach(function(r){
            t.count++;
            t.gross += Number(r.gross_gyd||0);
            t.net   += Number(r.net_gyd||0);
          });

          renderKpis(ES2.currency, t);

          ES2.rows = filtered;
          renderTable(); // ✅ pagination happens AFTER rows exist (in memory)
        })
        .catch(function(){
          if (body) body.innerHTML = '<tr><td colspan="8" class="ccv-es2-empty">Network error.</td></tr>';
          renderPager(0,1,1);
        });
    }
  }

  document.addEventListener('DOMContentLoaded', ensureInjected);
})();
</script>
<?php
}, 999);