<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$files = array(
	'ajax.php',
	'ajaxrefresh-console.php',
	'backfill.php',
	'courier-admin.php',
	'courier-earnings-console.php',
	'earnings-cron.php',
	'earnings-engine.php',
	'earnings-statements-extension.php',
	'payout-requests.php',
);

foreach ( $files as $file ) {
	$path = __DIR__ . '/' . $file;

	if ( file_exists( $path ) ) {
		require_once $path;
	} else {
		error_log( '[courier-earnings-loader] Missing file: ' . $path );
	}
}