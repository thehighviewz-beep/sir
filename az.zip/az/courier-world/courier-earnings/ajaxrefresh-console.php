<?php
/**
 * Plugin Name: Caricove Courier Console Bridge — Live State
 * Description: REST endpoint that returns live Jobs + Earnings balances for the logged-in courier. (No admin-ajax.)
 * Version: 1.0.0
 */

if ( ! defined('ABSPATH') ) exit;

add_action('rest_api_init', function(){

    register_rest_route('caricove-logistics-bridge/v1', '/console-state', array(
        'methods'  => 'GET',
        'permission_callback' => function(){ return is_user_logged_in(); },
        'callback' => function( WP_REST_Request $req ){

            $courier_id = get_current_user_id();
            if ( ! $courier_id ) {
                return new WP_REST_Response(array('ok'=>false,'message'=>'Not logged in'), 401);
            }

            // --- Earnings balances ---
            $balances = array('available'=>0,'clearing'=>0,'held'=>0,'paid'=>0,'currency'=>'GYD');
            if ( class_exists('Caricove_Courier_Earnings_Engine') && method_exists('Caricove_Courier_Earnings_Engine','get_balances_for_courier') ) {
                $b = Caricove_Courier_Earnings_Engine::get_balances_for_courier($courier_id);
                if ( is_array($b) ) {
                    $balances['available'] = (float)($b['available'] ?? 0);
                    $balances['clearing']  = (float)($b['clearing'] ?? 0);
                    $balances['held']      = (float)($b['held'] ?? 0);
                    $balances['paid']      = (float)($b['paid'] ?? 0);
                }
            }

            // --- Jobs: Active vs History (Delivered/Returned/Cancelled) ---
            $cpt = apply_filters('cc_logistics_shipment_cpt', 'cc_shipment');

            $courier_key = class_exists('\Caricove\Logistics\Core\Schema')
                ? \Caricove\Logistics\Core\Schema::META_SHIPMENT_COURIER_ID
                : '_cc_shipment_courier_id';

            $status_key  = class_exists('\Caricove\Logistics\Core\Schema')
                ? \Caricove\Logistics\Core\Schema::META_SHIPMENT_STATUS
                : '_cc_shipment_status';

            $active_statuses = apply_filters('cc_dispatcher_active_statuses', array(
                'assigned','picked_up','in_transit','out_for_delivery',
                'out_for_redelivery_day1','paid_redelivery_ready_for_dispatch','paid_redelivery_pending_confirmation',
            ), $courier_id);

            $history_statuses = array('delivered','returned','cancelled');

            $q = new WP_Query(array(
                'post_type'      => $cpt,
                'post_status'    => 'any',
                'posts_per_page' => 200,
                'fields'         => 'ids',
                'no_found_rows'  => true,
                'meta_query'     => array(
                    array('key' => $courier_key, 'value' => $courier_id),
                ),
                'orderby' => 'date',
                'order'   => 'DESC',
            ));

            $active = array();
            $history = array();

            foreach ( (array)$q->posts as $sid ) {
                $sid = (int)$sid;
                $st  = (string)get_post_meta($sid, $status_key, true);
                $st  = sanitize_key($st);

                $last_change = '';
                if ( class_exists('\Caricove\Logistics\Core\Schema') ) {
                    $lc_key = \Caricove\Logistics\Core\Schema::META_SHIPMENT_LAST_STATUS_CHANGE_AT;
                    $last_change = (string)get_post_meta($sid, $lc_key, true);
                }

                $row = array(
                    'shipment_id' => $sid,
                    'status'      => $st,
                    'last_change' => $last_change,
                );

                if ( in_array($st, $history_statuses, true) ) {
                    $history[] = $row;
                } elseif ( in_array($st, (array)$active_statuses, true) ) {
                    $active[] = $row;
                }
            }

            // “Version” for cheap diffing (front-end only re-renders if it changes)
            $version = md5( wp_json_encode(array(
                'b' => $balances,
                'a' => array_slice($active, 0, 30),
                'h' => array_slice($history, 0, 30),
            )) );

            return new WP_REST_Response(array(
                'ok'       => true,
                'courier'  => $courier_id,
                'version'  => $version,
                'utc_ts'   => time(),
                'balances' => $balances,
                'jobs'     => array(
                    'active'  => $active,
                    'history' => $history,
                ),
            ), 200);
        }
    ));

});