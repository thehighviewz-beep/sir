<?php
/**
 * Courier Earnings — Backfill Patch (Admin-only)
 * Fixes existing ledger rows where amount_gyd / gross_gyd were saved blank/0.
 *
 * What it does:
 * - Finds cc_courier_earning entries for a date range (or last N)
 * - If META_AMOUNT_GYD or META_GROSS_GYD is missing/0, it recomputes using the shipment summary
 * - Writes:
 *   _cc_earning_gross_gyd
 *   _cc_earning_amount_gyd
 *   _cc_earning_route_key
 *   _cc_earning_distance_km
 *   _cc_earning_components
 *
 * Safe guards:
 * - Admin-only + nonce
 * - Does NOT touch entries already having non-zero amounts (unless forced)
 * - Does NOT change status
 */

if ( ! defined('ABSPATH') ) { exit; }

if ( ! class_exists('Caricove_Courier_Earnings_Backfill') ) {

class Caricove_Courier_Earnings_Backfill {

    const PAGE_SLUG = 'cc-earnings-backfill';

    public static function boot() {
        add_action('admin_menu', array(__CLASS__, 'menu'), 90);
        add_action('admin_post_cc_earnings_backfill_run', array(__CLASS__, 'handle_run'));
    }

    public static function menu() {
        // Put under “Courier Earnings” if you have it, otherwise under Tools.
        $parent = 'cc-earnings';
        if ( ! self::menu_slug_exists($parent) ) {
            $parent = 'tools.php';
        }

        add_submenu_page(
            $parent,
            'Earnings Backfill',
            'Earnings Backfill',
            'manage_options',
            self::PAGE_SLUG,
            array(__CLASS__, 'render')
        );
    }

    private static function menu_slug_exists($slug) {
        global $menu, $submenu;
        if ( $slug === 'tools.php' ) return true;

        foreach ( (array) $menu as $m ) {
            if ( isset($m[2]) && $m[2] === $slug ) return true;
        }
        if ( isset($submenu[$slug]) ) return true;
        return false;
    }

    public static function render() {
        if ( ! current_user_can('manage_options') ) return;

        $msg = isset($_GET['cc_msg']) ? sanitize_text_field(wp_unslash($_GET['cc_msg'])) : '';
        $last = isset($_GET['last']) ? max(1, intval($_GET['last'])) : 250;

        ?>
        <div class="wrap">
            <h1>Courier Earnings — Backfill Patch</h1>
            <p class="description">
                This fixes old ledger entries where <code>amount_gyd</code> / <code>gross_gyd</code> were saved empty/0.
                It recomputes from the shipment summary and writes the missing metas.
            </p>

            <?php if ( $msg ) : ?>
                <div class="notice notice-success"><p><strong><?php echo esc_html($msg); ?></strong></p></div>
            <?php endif; ?>

            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="max-width:720px;">
                <?php wp_nonce_field('cc_earnings_backfill_run','_cc_nonce'); ?>
                <input type="hidden" name="action" value="cc_earnings_backfill_run" />

                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="last">Scan last N ledger rows</label></th>
                        <td>
                            <input name="last" id="last" type="number" min="1" max="5000" value="<?php echo esc_attr($last); ?>" />
                            <p class="description">Starts with most recent ledger entries.</p>
                        </td>
                    </tr>

                    <tr>
                        <th scope="row">Only fix zeros/missing</th>
                        <td>
                            <label>
                                <input type="checkbox" name="only_missing" value="1" checked />
                                Yes (recommended)
                            </label>
                            <p class="description">If unchecked, it will overwrite even non-zero amounts (not recommended).</p>
                        </td>
                    </tr>

                    <tr>
                        <th scope="row">Dry-run</th>
                        <td>
                            <label>
                                <input type="checkbox" name="dry_run" value="1" checked />
                                Dry-run (preview only)
                            </label>
                            <p class="description">Dry-run shows how many it would fix, without saving.</p>
                        </td>
                    </tr>
                </table>

                <?php submit_button('Run Backfill'); ?>
            </form>

            <hr />

            <p class="description">
                After you run this (non-dry-run), reload the courier console Earnings tab — your totals should stop showing GYD 0.00.
            </p>
        </div>
        <?php
    }

    public static function handle_run() {
        if ( ! current_user_can('manage_options') ) wp_die('Unauthorized');
        check_admin_referer('cc_earnings_backfill_run','_cc_nonce');

        // Hard deps
        if ( ! class_exists('Caricove_Courier_Earnings_Engine') ) {
            self::redir('Earnings engine missing (Caricove_Courier_Earnings_Engine).');
        }
        if ( ! class_exists('Caricove_Shipment_Manager') ) {
            self::redir('Shipment manager missing (Caricove_Shipment_Manager).');
        }

        $last         = isset($_POST['last']) ? max(1, intval($_POST['last'])) : 250;
        $only_missing = ! empty($_POST['only_missing']);
        $dry_run      = ! empty($_POST['dry_run']);

        $cpt = Caricove_Courier_Earnings_Engine::CPT_EARNING;

        $ids = get_posts(array(
            'post_type'      => $cpt,
            'post_status'    => 'any',
            'posts_per_page' => min(5000, $last),
            'orderby'        => 'date',
            'order'          => 'DESC',
            'fields'         => 'ids',
            'no_found_rows'  => true,
        ));

        $fixed = 0;
        $skipped = 0;
        $errors = 0;

        foreach ( $ids as $eid ) {
            $eid = intval($eid);
            if ( ! $eid ) continue;

            $shipment_id = intval(get_post_meta($eid, Caricove_Courier_Earnings_Engine::META_SHIPMENT_ID, true));

            $amount = get_post_meta($eid, Caricove_Courier_Earnings_Engine::META_AMOUNT_GYD, true);
            $gross  = get_post_meta($eid, Caricove_Courier_Earnings_Engine::META_GROSS_GYD, true);

            $amount_f = floatval($amount);
            $gross_f  = floatval($gross);

            if ( $only_missing ) {
                // Treat empty OR 0.0 as missing, because your bug saved blanks/0.
                if ( $amount !== '' && $gross !== '' && $amount_f > 0 && $gross_f > 0 ) {
                    $skipped++;
                    continue;
                }
            }

            if ( ! $shipment_id ) {
                $errors++;
                continue;
            }

            $summary = Caricove_Shipment_Manager::get_shipment_summary($shipment_id);
            if ( empty($summary) || ! is_array($summary) ) {
                $errors++;
                continue;
            }

            $calc = Caricove_Courier_Earnings_Engine::compute_for_summary($summary);
            if ( empty($calc) || ! is_array($calc) ) {
                $errors++;
                continue;
            }

            $new_gross  = floatval($calc['gross_fare_gyd'] ?? 0);
            $new_amount = floatval($calc['courier_amount_gyd'] ?? 0);
            $route_key  = (string)($calc['route_key'] ?? '');
            $dist_km    = floatval($calc['distance_km'] ?? 0);
            $components = isset($calc['components']) ? $calc['components'] : array();

            // If compute returns 0, don’t write trash — count as error so you notice.
            if ( $new_gross <= 0 || $new_amount <= 0 ) {
                $errors++;
                continue;
            }

            if ( ! $dry_run ) {
                update_post_meta($eid, Caricove_Courier_Earnings_Engine::META_GROSS_GYD, $new_gross);
                update_post_meta($eid, Caricove_Courier_Earnings_Engine::META_AMOUNT_GYD, $new_amount);
                update_post_meta($eid, Caricove_Courier_Earnings_Engine::META_ROUTE_KEY, $route_key);
                update_post_meta($eid, Caricove_Courier_Earnings_Engine::META_DISTANCE_KM, $dist_km);
                update_post_meta($eid, Caricove_Courier_Earnings_Engine::META_COMPONENTS, $components);
            }

            $fixed++;
        }

        $mode = $dry_run ? 'DRY-RUN' : 'APPLIED';
        self::redir("{$mode}: fixed={$fixed}, skipped={$skipped}, errors={$errors} (scanned={$last}).");
    }

    private static function redir($msg) {
        $url = add_query_arg(
            array(
                'page'   => self::PAGE_SLUG,
                'cc_msg' => rawurlencode($msg),
            ),
            admin_url('admin.php')
        );
        wp_safe_redirect($url);
        exit;
    }
}

Caricove_Courier_Earnings_Backfill::boot();

}