<?php
/**
 * Courier Earnings — Cron wiring (bulletproof)
 * - Registers the cron hook callback early (muplugins_loaded) so Proof panels can see it
 * - Schedules the cron if missing
 * - Records proof options on every run
 */

if ( ! defined('ABSPATH') ) { exit; }

// Use define() so we never hit “const redeclare” edge cases across includes.
if ( ! defined('CC_EARNINGS_CRON_HOOK') ) {
    define('CC_EARNINGS_CRON_HOOK', 'cc_earnings_daily_cron');
}
if ( ! defined('CC_EARNINGS_OPT_LAST_RUN') ) {
    define('CC_EARNINGS_OPT_LAST_RUN', '_cc_earnings_last_clearing_run_ts');
}
if ( ! defined('CC_EARNINGS_OPT_LAST_MOVED') ) {
    define('CC_EARNINGS_OPT_LAST_MOVED', '_cc_earnings_last_clearing_moved');
}

/**
 * 1) Register the cron hook callback ASAP (MU-safe).
 * Your Proof Panel should see has_action(CC_EARNINGS_CRON_HOOK) > 0.
 */
add_action('muplugins_loaded', function () {

    // Register callback for the cron hook (closure is OK)
    add_action(CC_EARNINGS_CRON_HOOK, function () {

        // proof: last run in UTC epoch
        update_option(CC_EARNINGS_OPT_LAST_RUN, time(), false);

        $moved = 0;

        if ( class_exists('Caricove_Courier_Earnings_Engine') && method_exists('Caricove_Courier_Earnings_Engine', 'run_clearing_to_available') ) {
            $moved = (int) Caricove_Courier_Earnings_Engine::run_clearing_to_available();
        }

        // proof: how many rows we moved
        update_option(CC_EARNINGS_OPT_LAST_MOVED, $moved, false);

    }, 10, 0);

}, 1);

/**
 * 2) Ensure WP-Cron schedule exists.
 * Use muplugins_loaded so it runs even if init is weird on some admin screens.
 */
add_action('muplugins_loaded', function () {

    // schedule if missing
    if ( ! wp_next_scheduled(CC_EARNINGS_CRON_HOOK) ) {
        wp_schedule_event(time() + 300, 'daily', CC_EARNINGS_CRON_HOOK);
    }

}, 5);

/**
 * 3) Optional manual trigger for testing:
 * /wp-admin/?cc_run_earnings_clearing=1
 */
add_action('admin_init', function () {

    if ( ! current_user_can('manage_options') ) return;
    if ( empty($_GET['cc_run_earnings_clearing']) ) return;

    do_action(CC_EARNINGS_CRON_HOOK);

    wp_safe_redirect( remove_query_arg('cc_run_earnings_clearing') );
    exit;

});