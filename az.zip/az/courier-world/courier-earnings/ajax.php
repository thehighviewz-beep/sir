<?php
/**
 * Courier Earnings — AJAX (always-on)
 * Ensures wp_ajax_* handlers are registered on every request (admin + front-end).
 */
if ( ! defined('ABSPATH') ) exit;

add_action('init', function () {
    // Intentionally quiet; this file must load both front-end and admin requests.
}, 1);

add_action('wp_ajax_cc_courier_get_statements', function () {
    if ( ! is_user_logged_in() ) {
        wp_send_json_error(array('message' => 'Not logged in'), 401);
    }

    $courier_id = get_current_user_id();
    $start = sanitize_text_field($_GET['start'] ?? '');
    $end   = sanitize_text_field($_GET['end'] ?? '');

    if ( ! $start || ! $end ) {
        wp_send_json_error(array('message' => 'Missing date range'), 400);
    }

    if ( ! class_exists('Caricove_Courier_Earnings_Engine') || ! method_exists('Caricove_Courier_Earnings_Engine', 'list_statements') ) {
        wp_send_json_error(array('message' => 'Earnings engine missing'), 500);
    }

    $rows = Caricove_Courier_Earnings_Engine::list_statements($courier_id, $start, $end);
    $rows = is_array($rows) ? $rows : [];

    $start_ts = strtotime($start . ' 00:00:00');
    $end_ts   = strtotime($end . ' 23:59:59');
    $recovery_store = get_option('caricove_bank_courier_recovery_v1', []);
    $recovery_store = is_array($recovery_store) ? $recovery_store : [];

    foreach ($recovery_store as $recovery) {
        if (!is_array($recovery)) {
            continue;
        }
        if ((int) ($recovery['courier_id'] ?? 0) !== (int) $courier_id) {
            continue;
        }

        $created_ts = (int) ($recovery['created_at'] ?? $recovery['updated_at'] ?? 0);
        if ($created_ts <= 0) {
            $created_ts = time();
        }
        if (($start_ts && $created_ts < $start_ts) || ($end_ts && $created_ts > $end_ts)) {
            continue;
        }

        $status = sanitize_key((string) ($recovery['status'] ?? 'open'));
        $statement_status = $status;
        if (in_array($status, array('open', 'recovering'), true)) {
            $statement_status = 'recovery';
        }

        $amount = (float) ($recovery['shipping_liability_amount'] ?? $recovery['recoverable_amount_total'] ?? 0);
        if ($amount <= 0) {
            $amount = (float) ($recovery['remaining_amount_total'] ?? 0);
        }
        $amount = round(abs($amount), 2);
        if ($amount <= 0) {
            continue;
        }

        $note_bits = array_filter(array(
            !empty($recovery['source_case_id']) ? 'Case ' . $recovery['source_case_id'] : '',
            !empty($recovery['reason_text']) ? (string) $recovery['reason_text'] : (string) ($recovery['reason_code'] ?? ''),
        ));

        $rows[] = array(
            'date'        => gmdate('Y-m-d', $created_ts),
            '_sort_ts'    => $created_ts,
            'shipment_id' => (int) ($recovery['shipment_id'] ?? 0),
            'route'       => 'Shipping Fee Charge',
            'status'      => $statement_status,
            'gross_gyd'   => 0,
            'fee_gyd'     => $amount,
            'net_gyd'     => 0 - $amount,
            'clears_on'   => '—',
            'note'        => implode(' · ', $note_bits),
            'type'        => 'shipping_recovery',
        );
    }

    usort($rows, static function ($a, $b) {
        $ta = 0;
        $tb = 0;
        if (isset($a['_sort_ts'])) {
            $ta = (int) $a['_sort_ts'];
        } elseif (!empty($a['date'])) {
            $ta = strtotime((string) $a['date']) ?: 0;
        }
        if (isset($b['_sort_ts'])) {
            $tb = (int) $b['_sort_ts'];
        } elseif (!empty($b['date'])) {
            $tb = strtotime((string) $b['date']) ?: 0;
        }
        return $tb <=> $ta;
    });

    $totals = array('net'=>0,'gross'=>0,'fee'=>0,'count'=>0,'held'=>0,'clearing'=>0,'available'=>0,'paid'=>0,'recovery'=>0,'partially_recovered'=>0,'recovered'=>0,'waived'=>0);
    foreach ((array) $rows as $r) {
        $totals['count']++;
        $totals['net']   += (float)($r['net_gyd'] ?? 0);
        $totals['gross'] += (float)($r['gross_gyd'] ?? 0);
        $totals['fee']   += (float)($r['fee_gyd'] ?? 0);

        $st = (string)($r['status'] ?? '');
        if (isset($totals[$st])) $totals[$st]++;
    }

    wp_send_json_success(array(
        'currency' => 'GYD',
        'totals'   => $totals,
        'rows'     => array_values($rows),
    ));
});
