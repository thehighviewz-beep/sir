<?php
/**
 * MU Loader: Courier Earnings
 * Loads all PHP files inside /mu-plugins/courier-earnings/
 */
if ( ! defined('ABSPATH') ) { exit; }

$dir = __DIR__ . '/courier-earnings';
if ( ! is_dir( $dir ) ) {
    error_log('[Courier Earnings Loader] Folder not found: ' . $dir);
    return;
}

$files = glob( $dir . '/*.php' );
if ( empty($files) ) {
    error_log('[Courier Earnings Loader] No PHP files found in: ' . $dir);
    return;
}

// Stable load order (engine first, then cron/admin/console).
$priority = array(
  'earnings-engine.php'            => 10,
  'earnings-cron.php'              => 20,
  'ajax.php'                       => 25,
  'payout-requests.php'            => 30,
  'courier-admin.php'              => 40,
  'courier-earnings-console.php'   => 50,
  'ajaxrefresh-console.php'        => 60,
  'earnings-statements-extension.php' => 70,
  'backfill.php'                   => 80,
);

usort($files, function($a,$b) use ($priority){
    $an = basename($a); $bn = basename($b);
    $ap = isset($priority[$an]) ? $priority[$an] : 999;
    $bp = isset($priority[$bn]) ? $priority[$bn] : 999;
    if ( $ap === $bp ) return strcmp($an,$bn);
    return ($ap < $bp) ? -1 : 1;
});

foreach ( $files as $f ) {
    require_once $f;
}

/**
 * Bulletproof: ensure the earnings cron hook exists in WP-Cron.
 * (Does NOT require the engine class to be loaded.)
 */
if ( ! wp_next_scheduled('cc_earnings_daily_cron') ) {
    wp_schedule_event( time() + 300, 'daily', 'cc_earnings_daily_cron' ); // first run in 5 minutes
}

error_log('[Courier Earnings Loader] Loaded ' . count($files) . ' files from courier-earnings/');