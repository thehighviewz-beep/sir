<?php
/**
 * Plugin Name: Caricove Courier Console Bridge — Settings JS (Cinematic, Loader Fix)
 * Description: Auto-save + cinematic interactions for Settings UI. Loads safely on frontend and only boots when the real settings shell + courier meta are present.
 * Version: 2.1.0
 */

if ( ! defined('ABSPATH') ) exit;

add_action('wp_footer', function(){
    if ( is_admin() ) return;
?>
<script>
(function(){
  function meta(){ return document.getElementById('ccv-courier-js-meta'); }
  function ajaxUrl(){ return meta()?.getAttribute('data-ajax-url') || ''; }
  function nonce(){ return meta()?.getAttribute('data-start-nonce') || meta()?.getAttribute('data-start-trip-nonce') || ''; }

  function hasSettingsShell(){
    return !!document.getElementById('ccv-settings-shell') && !!meta();
  }

  function toast(msg){
    var t = document.getElementById('ccv-settings-toast');
    if (!t) return;

    t.textContent = msg || 'Settings updated — dispatcher adjusted.';
    t.classList.add('is-show');
    clearTimeout(window.__ccvSetToast);
    window.__ccvSetToast = setTimeout(function(){
      t.classList.remove('is-show');
    }, 1600);
  }

  function setBadgeAvailability(val){
    var badge = document.querySelector('[data-bind="availability-badge"]');
    if (!badge) return;
    badge.textContent = (val === 'offline') ? 'OFFLINE' : 'ONLINE';
  }

  function setWorkloadMini(val){
    var el = document.querySelector('[data-bind="maxjobs-label"]');
    if (!el) return;
    if (val === '1') el.textContent = 'Focused';
    else if (val === '5') el.textContent = 'High Capacity';
    else el.textContent = 'Balanced';
  }

  function saveSettings(payload){
    if (!ajaxUrl() || !nonce()) return;

    var f = new FormData();
    f.append('action', 'caricove_courier_save_settings');
    f.append('nonce', nonce());
    Object.keys(payload).forEach(function(k){ f.append(k, payload[k]); });

    fetch(ajaxUrl(), { method:'POST', credentials:'same-origin', body:f })
      .then(function(r){ return r.json(); })
      .then(function(resp){
        if (!resp || !resp.success){
          toast((resp && resp.data && resp.data.message) ? resp.data.message : 'Unable to save settings.');
          return;
        }

        toast(resp.data && resp.data.message ? resp.data.message : 'Settings updated — dispatcher adjusted.');

        if (resp.data && resp.data.availability) setBadgeAvailability(resp.data.availability);
        if (resp.data && resp.data.max_jobs) setWorkloadMini(String(resp.data.max_jobs));

        // Nudge heartbeat fallback if they turned online so dispatcher sees it fast.
        if (resp.data && resp.data.availability === 'online'){
          try{
            var hf = new FormData();
            hf.append('action','caricove_courier_heartbeat_fallback');
            hf.append('nonce', nonce());
            fetch(ajaxUrl(), { method:'POST', credentials:'same-origin', body:hf }).catch(function(){});
          } catch(e){}
        }
      })
      .catch(function(){
        toast('Network error — try again.');
      });
  }

  function getActive(setting){
    var a = document.querySelector('.ccv-set-chip.is-active[data-setting="'+setting+'"]');
    if (a) return a.getAttribute('data-value');

    var p = document.querySelector('.ccv-set-pill.is-active[data-setting="'+setting+'"]');
    if (p) return p.getAttribute('data-value');

    var r = document.querySelector('.ccv-range-card.is-active[data-setting="'+setting+'"]');
    if (r) return r.getAttribute('data-value');

    return '';
  }

  function setActive(setting, value){
    document.querySelectorAll('[data-setting="'+setting+'"]').forEach(function(el){
      if (
        el.classList.contains('ccv-set-chip') ||
        el.classList.contains('ccv-set-pill') ||
        el.classList.contains('ccv-range-card')
      ){
        el.classList.toggle('is-active', el.getAttribute('data-value') === value);
      }
    });

    if (setting === 'availability') setBadgeAvailability(value);
    if (setting === 'max_jobs') setWorkloadMini(String(value));
  }

  function bootSettingsBridge(){
    if (!hasSettingsShell()) return;
    if (window.__ccvSettingsBridgeBooted) return;
    window.__ccvSettingsBridgeBooted = true;

    var shell = document.getElementById('ccv-settings-shell');
    if (!shell) return;

    shell.addEventListener('click', function(e){
      var btn = e.target.closest('[data-setting]');
      if (!btn) return;

      var setting = btn.getAttribute('data-setting');
      var value = btn.getAttribute('data-value');
      if (!setting || value === null) return;

      setActive(setting, value);

      var availability = getActive('availability') || 'online';
      var max_jobs = getActive('max_jobs') || '3';
      var range = getActive('range') || 'local_area';

      saveSettings({
        availability: availability,
        max_jobs: String(max_jobs),
        range: range
      });
    });
  }

  document.addEventListener('DOMContentLoaded', bootSettingsBridge);
  window.addEventListener('load', bootSettingsBridge);

  // Late boot in case settings shell/meta are injected after DOM ready
  var tries = 0;
  var timer = setInterval(function(){
    tries++;
    if (hasSettingsShell()){
      bootSettingsBridge();
      clearInterval(timer);
      return;
    }
    if (tries >= 20){
      clearInterval(timer);
    }
  }, 1000);

})();
</script>
<?php
}, 999);