<?php
/**
 * Plugin Name: Caricove Courier Console Bridge — Jobs
 * Description: Feeds scaffold-compatible jobs (active/handover/completed) using Core ShipmentManager summary.
 * Version: 2.0.2
 *
 * CHANGE:
 * - Force job cards currency to GYD (do NOT use WooCommerce store currency)
 * - Prefer your GYD earnings engine (Caricove_Courier_Earnings_Engine) for pay_label
 * - Fallback to legacy Caricove_Logistics_Earnings if present
 * - Lock map_url to exact ShipmentManager stored coords first (1:1 pin behavior), with text fallback only if coords are absent
 */

if ( ! defined('ABSPATH') ) exit;

function ccv_ccb_parse_coords( $coords ) {
    $coords = is_string($coords) ? trim($coords) : '';
    if ( $coords === '' || strpos($coords, ',') === false ) return array(null, null);
    list($a,$b) = array_map('trim', explode(',', $coords, 2));
    if ( ! is_numeric($a) || ! is_numeric($b) ) return array(null, null);
    return array((float)$a, (float)$b);
}

function ccv_ccb_format_addr_line( array $addr ) {
    return trim(
        (string)($addr['street'] ?? '') . ' ' .
        (string)($addr['street_2'] ?? '') . ' ' .
        (string)($addr['village'] ?? '')
    );
}

function ccv_ccb_haversine_km($lat1,$lng1,$lat2,$lng2){
    if (!is_numeric($lat1)||!is_numeric($lng1)||!is_numeric($lat2)||!is_numeric($lng2)) return null;
    $earth=6371.0;
    $lat1=deg2rad((float)$lat1); $lng1=deg2rad((float)$lng1);
    $lat2=deg2rad((float)$lat2); $lng2=deg2rad((float)$lng2);
    $dlat=$lat2-$lat1; $dlng=$lng2-$lng1;
    $a=sin($dlat/2)**2 + cos($lat1)*cos($lat2)*sin($dlng/2)**2;
    $c=2*atan2(sqrt($a), sqrt(1-$a));
    $d=$earth*$c;
    return (is_finite($d) && $d>=0) ? $d : null;
}


function ccv_ccb_offer_is_live_for_summary( $shipment_id, array $summary, $courier_id = 0 ) {
    $shipment_id = intval($shipment_id);
    $courier_id = intval($courier_id);
    $offer_courier_id = intval($summary['offer_courier_id'] ?? 0);

    if ( $courier_id && $offer_courier_id && $offer_courier_id !== $courier_id ) {
        return false;
    }

    if ( class_exists('\Caricove\Logistics\Core\AutoAssign') && method_exists('\Caricove\Logistics\Core\AutoAssign', 'offer_is_live') ) {
        $probe_courier_id = $courier_id ?: $offer_courier_id;
        if ( $probe_courier_id > 0 ) {
            return (bool) \Caricove\Logistics\Core\AutoAssign::offer_is_live( $shipment_id, $probe_courier_id );
        }
    }

    $offer_expires_at = intval($summary['offer_expires_at'] ?? 0);
    if ( $offer_courier_id <= 0 || $offer_expires_at <= time() ) {
        return false;
    }

    $assigned_courier = intval($summary['courier_id'] ?? $summary['assigned_courier_id'] ?? 0);
    return $assigned_courier <= 0;
}


function ccv_ccb_offer_is_expired_for_summary( $shipment_id, array $summary, $courier_id = 0 ) {
    $shipment_id = intval($shipment_id);
    $courier_id = intval($courier_id);
    $offer_courier_id = intval($summary['offer_courier_id'] ?? 0);

    if ( $courier_id && $offer_courier_id && $offer_courier_id !== $courier_id ) {
        return false;
    }

    if ( class_exists('\Caricove\Logistics\Core\AutoAssign') && method_exists('\Caricove\Logistics\Core\AutoAssign', 'shipment_has_expired_offer') ) {
        return (bool) \Caricove\Logistics\Core\AutoAssign::shipment_has_expired_offer(
            $shipment_id,
            $summary,
            $courier_id ?: $offer_courier_id
        );
    }

    $offer_expires_at = intval($summary['offer_expires_at'] ?? 0);
    if ( $offer_courier_id <= 0 || $offer_expires_at <= 0 ) {
        return false;
    }

    $assigned_courier = intval($summary['courier_id'] ?? $summary['assigned_courier_id'] ?? 0);
    if ( $assigned_courier > 0 && ! empty($summary['assignment_accepted_at']) ) {
        return false;
    }

    return time() >= $offer_expires_at;
}


function ccv_ccb_build_scaffold_job( $shipment_id, array $s, $courier_id ) {
    $shipment_id = intval($shipment_id);
    $courier_id  = intval($courier_id);

    $status = (string)($s['status'] ?? 'assigned');
    $offer_is_live = ccv_ccb_offer_is_live_for_summary( $shipment_id, $s, $courier_id );
    $state_label = (string)($s['status_label'] ?? '');
    if ($state_label==='') {
        if ($offer_is_live) {
            $state_label = 'Incoming Offer';
        } else {
            $state_label = ucwords(str_replace('_',' ',$status));
        }
    }

    $pickup  = (isset($s['pickup_address']) && is_array($s['pickup_address'])) ? $s['pickup_address'] : array();
    $dropoff = (isset($s['dropoff_address']) && is_array($s['dropoff_address'])) ? $s['dropoff_address'] : array();

    $pickup_city = (string)($pickup['city'] ?? '');
    $drop_city   = (string)($dropoff['city'] ?? '');

    $pickup_text = ccv_ccb_format_addr_line($pickup);
    $drop_text   = ccv_ccb_format_addr_line($dropoff);

    $pickup_name  = (string)($s['pickup_name'] ?? '');
    $pickup_phone = (string)($s['pickup_phone'] ?? '');
    $drop_name    = (string)($s['dropoff_name'] ?? '');
    $drop_phone   = (string)($s['dropoff_phone'] ?? '');

    $dropoff_instructions = '';
    if ( isset($s['dropoff_instructions']) && is_scalar($s['dropoff_instructions']) ) {
        $dropoff_instructions = trim((string) $s['dropoff_instructions']);
    }
    if ( $dropoff_instructions === '' && isset($s['delivery_instructions']) && is_scalar($s['delivery_instructions']) ) {
        $dropoff_instructions = trim((string) $s['delivery_instructions']);
    }
    if ( $dropoff_instructions === '' && isset($dropoff['instructions']) && is_scalar($dropoff['instructions']) ) {
        $dropoff_instructions = trim((string) $dropoff['instructions']);
    }
    if ( $dropoff_instructions === '' && isset($dropoff['delivery_instructions']) && is_scalar($dropoff['delivery_instructions']) ) {
        $dropoff_instructions = trim((string) $dropoff['delivery_instructions']);
    }

    $delivery_instructions = $dropoff_instructions;

    // Prefer storefront/vendor name; keep formatted address as fallback only.
    $vendor_id = intval($s['vendor_id'] ?? 0);
    if ( $vendor_id ) {
        if ( $pickup_name === '' ) {
            $pickup_name = (string) get_user_meta($vendor_id, '_cc_vendor_storefront_name', true);
        }

        if ( $pickup_name === '' ) {
            $vu = get_userdata($vendor_id);
            if ($vu) $pickup_name = $vu->display_name;
        }

        if ( $pickup_text === '' ) {
            $formatted = (string)get_user_meta($vendor_id, '_cc_vendor_formatted_address', true);
            if ( $formatted ) $pickup_text = $formatted;
        }
    }

    $offer_expires_at = intval($s['offer_expires_at'] ?? 0);
    $offer_created_at = intval($s['offer_created_at'] ?? 0);
    $offer_window     = intval($s['offer_response_window'] ?? 0);
    $offer_seconds_left = $offer_expires_at ? max(0, $offer_expires_at - time()) : 0;

    // Parse coords from Core summary (strings like "lat,lng")
    list($pickup_lat,$pickup_lng) = ccv_ccb_parse_coords((string)($s['pickup_coords'] ?? ''));
    list($drop_lat,$drop_lng)     = ccv_ccb_parse_coords((string)($s['dropoff_coords'] ?? ''));

    $courier_lat = isset($s['courier_last_lat']) && is_numeric($s['courier_last_lat']) ? (float) $s['courier_last_lat'] : null;
    $courier_lng = isset($s['courier_last_lng']) && is_numeric($s['courier_last_lng']) ? (float) $s['courier_last_lng'] : null;
    $courier_vehicle_type = (string)($s['courier_vehicle_type'] ?? $s['vehicle_type'] ?? '');

    // ETA label
    $eta_label = '';
    if ( ! empty($s['eta']) ) {
        $eta_label = 'ETA ' . wp_date('H:i', strtotime((string)$s['eta']));
    }

    // Deadline label + ts (scaffold countdown uses sla_deadline_ts)
    $deadline_label = '';
    $deadline_ts = 0;
    if ( ! empty($s['sla_deadline']) ) {
        $deadline_ts = strtotime((string)$s['sla_deadline']);
        if ($deadline_ts > 0) $deadline_label = 'Deliver by ' . wp_date('H:i', $deadline_ts);
    }

    // Determine phase
    $pickup_verified   = ! empty($s['pickup_code_verified']);
    $delivery_verified = ! empty($s['delivery_code_verified']);
    $phase = 'to_pickup';
    if ($delivery_verified || in_array($status, array('delivered','returned','cancelled'), true)) $phase='done';
    elseif ($pickup_verified) $phase='to_dropoff';

    // Target coords for distance label (pickup vs dropoff)
    $target_lat = null; $target_lng = null;
    if ($phase==='to_pickup') { $target_lat=$pickup_lat; $target_lng=$pickup_lng; }
    if ($phase==='to_dropoff'){ $target_lat=$drop_lat;   $target_lng=$drop_lng;   }

    // Distance label (compute using courier last gps if available)
    $distance_label = (string)($s['distance_label'] ?? '');
    $distance_km = null;

    if ( $distance_label === '' && $target_lat!==null && $target_lng!==null ) {
        $clat = $courier_lat;
        $clng = $courier_lng;
        if ($clat === null || $clng === null) {
            $p = class_exists('\Caricove\Logistics\Core\CourierProfile') ? \Caricove\Logistics\Core\CourierProfile::get_profile($courier_id) : array();
            if (is_array($p)) {
                $clat = $p['last_lat'] ?? null;
                $clng = $p['last_lng'] ?? null;
                if ($courier_vehicle_type === '') {
                    $courier_vehicle_type = (string)($p['vehicle_type'] ?? '');
                }
            }
        }
        if ($clat !== null && $clng !== null) {
            $distance_km = ccv_ccb_haversine_km($clat,$clng,$target_lat,$target_lng);
            if ($distance_km !== null) {
                $distance_label = ($phase==='to_pickup')
                    ? sprintf('%.1f km from pickup', $distance_km)
                    : sprintf('%.1f km from dropoff', $distance_km);
                if ($distance_km < 0.3) {
                    $distance_label = ($phase==='to_pickup') ? 'Near pickup' : 'Near dropoff';
                }
            }
        }
    }

    /* -----------------------------
     * Pay label + currency
     * -------------------------- */

    // ✅ FORCE GYD on job cards (courier pay is Guyana-local)
    $currency = 'GYD';

    $pay_label = (string)($s['pay_label'] ?? '');

    // Prefer your GYD engine if present
    if ( $pay_label === '' && class_exists('Caricove_Courier_Earnings_Engine') ) {
        $calc = Caricove_Courier_Earnings_Engine::compute_for_summary($s);
        if ( is_array($calc) && isset($calc['courier_amount_gyd']) ) {
            $pay_label = number_format_i18n((float)$calc['courier_amount_gyd'], 2);
        }
    }

    // Fallback to legacy earnings engine if still present
    if ( $pay_label === '' && class_exists('Caricove_Logistics_Earnings') ) {
        $calc = Caricove_Logistics_Earnings::compute_tariff_for_shipment($s);
        if (is_array($calc) && isset($calc['courier_earning'])) {
            $pay_label = number_format_i18n((float)$calc['courier_earning'], 2);
        }
    }

    if ($pay_label === '') $pay_label = '—';

    // Next action logic MUST match your scaffold JS expectations
    $next_state = '';
    $next_state_label = '';
    $requires_code = false;

    if ($offer_is_live) {
        $next_state = 'accept_offer';
        $next_state_label = 'Accept Offer';
    } elseif ($status === 'assigned') {
        $next_state = 'en_route';
        $next_state_label = 'Start Trip';
    } elseif ($status === 'in_transit' && ! $pickup_verified) {
        $next_state = 'pickup_code';
        $next_state_label = 'Confirm Pickup';
        $requires_code = true;
    } elseif ($status === 'picked_up') {
        $next_state = 'en_route';
        $next_state_label = 'On the Way';
    } elseif ($status === 'in_transit' && $pickup_verified && ! $delivery_verified) {
        $next_state = 'delivered';
        $next_state_label = 'Complete Delivery';
        $requires_code = true;
    }

    // Map URL: exact ShipmentManager destination coords first (1:1 pin), text only as fallback.
    $map_url = (string)($s['map_url'] ?? '');
    if ($map_url === '') {
        if ($drop_lat !== null && $drop_lng !== null) {
            $map_url = 'https://www.google.com/maps/search/?api=1&query='
                . rawurlencode($drop_lat . ',' . $drop_lng);
        } elseif ($drop_text !== '') {
            $map_url = 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode($drop_text);
        } elseif ($pickup_lat !== null && $pickup_lng !== null) {
            $map_url = 'https://www.google.com/maps/search/?api=1&query='
                . rawurlencode($pickup_lat . ',' . $pickup_lng);
        } elseif ($pickup_text !== '') {
            $map_url = 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode($pickup_text);
        }
    }

    // Optional nav URL for later use if you want route mode separately.
    $nav_url = '';
    if ($pickup_lat!==null && $pickup_lng!==null && $drop_lat!==null && $drop_lng!==null) {
        $nav_url = 'https://www.google.com/maps/dir/?api=1'
            . '&origin=' . rawurlencode($pickup_lat.','.$pickup_lng)
            . '&destination=' . rawurlencode($drop_lat.','.$drop_lng);
    } elseif ($map_url !== '') {
        $nav_url = $map_url;
    }

    // EXACT scaffold contract keys
    $job = array(
        'id'             => $shipment_id,
        'label'          => 'Shipment #' . $shipment_id,
        'state'          => $status,
        'state_label'    => $state_label,
        'pay_label'      => $pay_label,
        'currency'       => $currency,

        'pickup_title'   => 'Pickup',
        'pickup_text'    => $pickup_text,
        'pickup_city'    => $pickup_city,
        'pickup_name'    => $pickup_name,
        'pickup_phone'   => $pickup_phone,

        'dropoff_title'  => 'Dropoff',
        'dropoff_text'   => $drop_text,
        'dropoff_city'   => $drop_city,
        'dropoff_name'   => $drop_name,
        'dropoff_phone'  => $drop_phone,
        'dropoff_instructions' => $dropoff_instructions,
        'delivery_instructions' => $delivery_instructions,

        'eta_label'      => $eta_label,
        'distance_label' => $distance_label,
        'weight_band' => (string)($s['weight_band'] ?? ''),
        'total_weight' => isset($s['total_weight']) ? (float)$s['total_weight'] : 0,
        'recommended_vehicle' => (string)($s['recommended_vehicle'] ?? ''),
        'deadline_label' => $deadline_label,
        'sla_deadline_ts'=> $deadline_ts,

        'map_url'        => $map_url,
        'nav_url'        => $nav_url,

        // fields your render_job_card already supports:
        'phase'          => $phase,
        'pickup_lat'     => $pickup_lat,
        'pickup_lng'     => $pickup_lng,
        'dropoff_lat'    => $drop_lat,
        'dropoff_lng'    => $drop_lng,
        'mission_id'     => (string)($s['bundle_id'] ?? ''),
        'mission_seq'    => intval($s['bundle_seq'] ?? 0),

        'next_state'       => $next_state,
        'next_state_label' => $next_state_label,
        'requires_code'    => $requires_code,
        'offer_is_live'    => $offer_is_live,

        'offer_created_at'      => $offer_created_at,
        'offer_expires_at'      => $offer_expires_at,
        'offer_response_window' => $offer_window,
        'offer_seconds_left'    => $offer_seconds_left,

        'courier_lat'          => $courier_lat,
        'courier_lng'          => $courier_lng,
        'courier_vehicle_type' => $courier_vehicle_type,
        'distance_band'        => (string)($s['distance_band'] ?? $s['trip_band'] ?? ''),
        'quote_total_gyd'      => (float)($s['quote_total_gyd'] ?? 0),
        'queue_bucket'         => (string)($s['queue_bucket'] ?? ''),
    );

    return apply_filters('caricove_logistics_bridge_job', $job, $shipment_id, $s, $courier_id);
}

add_filter('caricove_logistics_scaffold_jobs', function($jobs, $courier_id){
    return ccv_ccb_collect_jobs_for_courier($courier_id);
}, 10, 2);

function ccv_ccb_normalize_job_payload( array $job ) {
    $status = (string) ( $job['state'] ?? ( $job['status'] ?? '' ) );
    $status_label = (string) ( $job['state_label'] ?? ( $job['status_label'] ?? '' ) );
    if ( $status_label === '' && $status !== '' ) {
        $status_label = ucwords( str_replace( '_', ' ', $status ) );
    }

    return array_merge( $job, array(
        'job_id'       => intval( $job['job_id'] ?? ( $job['id'] ?? 0 ) ),
        'id'           => intval( $job['id'] ?? ( $job['job_id'] ?? 0 ) ),
        'status'       => $status,
        'state'        => $status,
        'status_label' => $status_label,
        'state_label'  => $status_label,
        'offer_is_live'=> ! empty( $job['offer_is_live'] ),
    ) );
}

function ccv_ccb_render_job_card_html( array $job, $bucket = 'active' ) {
    $job = ccv_ccb_normalize_job_payload( $job );

    $id             = $job['id'];
    $label          = (string) ( $job['label'] ?? '' );
    $state          = (string) ( $job['state'] ?? '' );
    $state_label    = (string) ( $job['state_label'] ?? '' );
    $pay_label      = (string) ( $job['pay_label'] ?? '' );
    $currency       = (string) ( $job['currency'] ?? 'GYD' );

    $pickup_title   = (string) ( $job['pickup_title'] ?? 'Pickup' );
    $pickup_text    = (string) ( $job['pickup_text'] ?? '' );
    $pickup_city    = (string) ( $job['pickup_city'] ?? '' );
    $pickup_name    = (string) ( $job['pickup_name'] ?? '' );
    $pickup_phone   = (string) ( $job['pickup_phone'] ?? '' );

    $dropoff_title  = (string) ( $job['dropoff_title'] ?? 'Dropoff' );
    $dropoff_text   = (string) ( $job['dropoff_text'] ?? '' );
    $dropoff_city   = (string) ( $job['dropoff_city'] ?? '' );
    $dropoff_name   = (string) ( $job['dropoff_name'] ?? '' );
    $dropoff_phone  = (string) ( $job['dropoff_phone'] ?? '' );
    $dropoff_instructions = (string) ( $job['dropoff_instructions'] ?? '' );
    $delivery_instructions = (string) ( $job['delivery_instructions'] ?? $dropoff_instructions );

    $eta_label      = (string) ( $job['eta_label'] ?? '' );
    $distance_label = (string) ( $job['distance_label'] ?? '' );
    $deadline_label = (string) ( $job['deadline_label'] ?? '' );
    $map_url        = (string) ( $job['map_url'] ?? '' );

    $phase          = (string) ( $job['phase'] ?? 'to_pickup' );
    $pickup_lat     = (string) ( $job['pickup_lat'] ?? '' );
    $pickup_lng     = (string) ( $job['pickup_lng'] ?? '' );
    $dropoff_lat    = (string) ( $job['dropoff_lat'] ?? '' );
    $dropoff_lng    = (string) ( $job['dropoff_lng'] ?? '' );
    $mission_id     = (string) ( $job['mission_id'] ?? '' );
    $mission_seq    = intval( $job['mission_seq'] ?? 0 );
    $deadline_ts    = intval( $job['sla_deadline_ts'] ?? 0 );
    $next_state       = (string) ( $job['next_state'] ?? '' );
    $next_state_label = (string) ( $job['next_state_label'] ?? '' );
    $requires_code    = ! empty( $job['requires_code'] ) ? '1' : '0';
    $offer_created_at = intval( $job['offer_created_at'] ?? 0 );
    $offer_expires_at = intval( $job['offer_expires_at'] ?? 0 );
    $offer_window     = intval( $job['offer_response_window'] ?? 0 );
    $offer_seconds_left = intval( $job['offer_seconds_left'] ?? 0 );
    $offer_is_live    = ! empty( $job['offer_is_live'] );
    $courier_lat      = (string) ( $job['courier_lat'] ?? '' );
    $courier_lng      = (string) ( $job['courier_lng'] ?? '' );
    $courier_vehicle  = (string) ( $job['courier_vehicle_type'] ?? '' );
    $distance_band    = (string) ( $job['distance_band'] ?? '' );
    $quote_total_gyd  = (float) ( $job['quote_total_gyd'] ?? 0 );
    $queue_bucket     = (string) ( $job['queue_bucket'] ?? $bucket );

    $from_area = $pickup_city ? $pickup_city : $pickup_text;
    $to_area   = $dropoff_city ? $dropoff_city : $dropoff_text;
    $route_summary = '';
    if ( $from_area && $to_area ) {
        $route_summary = $from_area . ' → ' . $to_area;
    } elseif ( $from_area ) {
        $route_summary = $from_area;
    } elseif ( $to_area ) {
        $route_summary = $to_area;
    }

    $time_chip = $deadline_label ? $deadline_label : $eta_label;
    if ( $offer_is_live && $offer_seconds_left > 0 ) {
        $time_chip = 'Respond in ' . intval( $offer_seconds_left ) . 's';
    }
    $bucket_class = in_array( $state, array( 'delivered', 'returned', 'cancelled' ), true ) ? 'ccv-job-card--completed' : 'ccv-job-card--active';

    ob_start();
    ?>
    <article class="ccv-job-card <?php echo esc_attr( $bucket_class ); ?>"
             data-job-id="<?php echo esc_attr( $id ); ?>"
             data-job-label="<?php echo esc_attr( $label ); ?>"
             data-job-state="<?php echo esc_attr( $state ); ?>"
             data-job-state-label="<?php echo esc_attr( $state_label ); ?>"
             data-job-pay="<?php echo esc_attr( $pay_label ); ?>"
             data-job-currency="<?php echo esc_attr( $currency ); ?>"
             data-pickup-title="<?php echo esc_attr( $pickup_title ); ?>"
             data-pickup-text="<?php echo esc_attr( $pickup_text ); ?>"
             data-pickup-city="<?php echo esc_attr( $pickup_city ); ?>"
             data-pickup-name="<?php echo esc_attr( $pickup_name ); ?>"
             data-pickup-phone="<?php echo esc_attr( $pickup_phone ); ?>"
             data-dropoff-title="<?php echo esc_attr( $dropoff_title ); ?>"
             data-dropoff-text="<?php echo esc_attr( $dropoff_text ); ?>"
             data-dropoff-city="<?php echo esc_attr( $dropoff_city ); ?>"
             data-dropoff-name="<?php echo esc_attr( $dropoff_name ); ?>"
             data-dropoff-phone="<?php echo esc_attr( $dropoff_phone ); ?>"
             data-dropoff-instructions="<?php echo esc_attr( $dropoff_instructions ); ?>"
             data-delivery-instructions="<?php echo esc_attr( $delivery_instructions ); ?>"
             data-eta-label="<?php echo esc_attr( $eta_label ); ?>"
             data-distance-label="<?php echo esc_attr( $distance_label ); ?>"
             data-deadline-label="<?php echo esc_attr( $deadline_label ); ?>"
             data-deadline-ts="<?php echo esc_attr( $deadline_ts ); ?>"
             data-map-url="<?php echo esc_url( $map_url ); ?>"
             data-nav-url="<?php echo esc_url( (string) ( $job['nav_url'] ?? '' ) ); ?>"
             data-next-state="<?php echo esc_attr( $next_state ); ?>"
             data-next-state-label="<?php echo esc_attr( $next_state_label ); ?>"
             data-requires-code="<?php echo esc_attr( $requires_code ); ?>"
             data-phase="<?php echo esc_attr( $phase ); ?>"
             data-pickup-lat="<?php echo esc_attr( $pickup_lat ); ?>"
             data-pickup-lng="<?php echo esc_attr( $pickup_lng ); ?>"
             data-dropoff-lat="<?php echo esc_attr( $dropoff_lat ); ?>"
             data-dropoff-lng="<?php echo esc_attr( $dropoff_lng ); ?>"
             data-mission-id="<?php echo esc_attr( $mission_id ); ?>"
             data-mission-seq="<?php echo esc_attr( $mission_seq ); ?>"
             data-bucket="<?php echo esc_attr( $bucket ); ?>"
             data-queue-bucket="<?php echo esc_attr( $queue_bucket ); ?>"
             data-offer-created-at="<?php echo esc_attr( $offer_created_at ); ?>"
             data-offer-expires-at="<?php echo esc_attr( $offer_expires_at ); ?>"
             data-offer-response-window="<?php echo esc_attr( $offer_window ); ?>"
             data-offer-seconds-left="<?php echo esc_attr( $offer_seconds_left ); ?>"
             data-offer-live="<?php echo esc_attr( $offer_is_live ? '1' : '0' ); ?>"
             data-courier-lat="<?php echo esc_attr( $courier_lat ); ?>"
             data-courier-lng="<?php echo esc_attr( $courier_lng ); ?>"
             data-courier-vehicle-type="<?php echo esc_attr( $courier_vehicle ); ?>"
             data-distance-band="<?php echo esc_attr( $distance_band ); ?>"
             data-quote-total-gyd="<?php echo esc_attr( $quote_total_gyd ); ?>">
        <div class="ccv-job-card-row ccv-job-card-row--thin-top">
            <div class="ccv-job-card-label"><?php echo esc_html( $label ); ?></div>
            <?php if ( $state_label ) : ?>
                <div class="ccv-job-card-state"><?php echo esc_html( $state_label ); ?></div>
            <?php endif; ?>
        </div>
        <div class="ccv-job-card-row ccv-job-card-row--thin-middle">
            <?php if ( $route_summary ) : ?>
                <div class="ccv-job-card-route"><?php echo esc_html( $route_summary ); ?></div>
            <?php endif; ?>
        </div>
        <div class="ccv-job-card-row ccv-job-card-row--thin-bottom">
            <div class="ccv-job-card-meta">
                <?php if ( $time_chip ) : ?>
                    <span class="ccv-job-pill ccv-job-pill--time"><?php echo esc_html( $time_chip ); ?></span>
                <?php endif; ?>
                <?php if ( $distance_label ) : ?>
                    <span class="ccv-job-pill ccv-job-pill--distance"><?php echo esc_html( $distance_label ); ?></span>
                <?php endif; ?>
            </div>
            <div class="ccv-job-card-pay">
                <span class="ccv-job-pay-currency"><?php echo esc_html( $currency ); ?></span>
                <span class="ccv-job-pay-amount"><?php echo esc_html( $pay_label ); ?></span>
            </div>
        </div>
    </article>
    <?php

    return ob_get_clean();
}

function ccv_ccb_collect_jobs_for_courier( $courier_id ) {
    $courier_id = intval( $courier_id );
    $jobs = array( 'active' => array(), 'handover' => array(), 'completed' => array() );

    if ( ! $courier_id ) {
        return $jobs;
    }

    if ( ! class_exists('\Caricove\Logistics\Core\ShipmentManager') || ! class_exists('\Caricove\Logistics\Core\Schema') ) {
        return $jobs;
    }

    $cpt = apply_filters('cc_logistics_shipment_cpt', 'cc_shipment');
    $meta_key = \Caricove\Logistics\Core\Schema::META_SHIPMENT_COURIER_ID;

    $all_ids = array();

    $owned = new WP_Query(array(
        'post_type'      => $cpt,
        'post_status'    => 'any',
        'posts_per_page' => 120,
        'orderby'        => 'date',
        'order'          => 'DESC',
        'fields'         => 'ids',
        'no_found_rows'  => true,
        'meta_query'     => array(
            array('key' => $meta_key, 'value' => $courier_id),
        ),
    ));

    foreach ( (array) $owned->posts as $sid ) {
        $all_ids[ intval($sid) ] = intval($sid);
    }

    $offer_query = new WP_Query(array(
        'post_type'      => $cpt,
        'post_status'    => 'any',
        'posts_per_page' => 60,
        'orderby'        => 'date',
        'order'          => 'DESC',
        'fields'         => 'ids',
        'no_found_rows'  => true,
        'meta_query'     => array(
            array('key' => \Caricove\Logistics\Core\Schema::META_SHIPMENT_OFFER_COURIER_ID, 'value' => $courier_id),
        ),
    ));

    foreach ( (array) $offer_query->posts as $sid ) {
        $all_ids[ intval($sid) ] = intval($sid);
    }

    $rows = array();
    foreach ( array_values($all_ids) as $sid ) {
        $summary = \Caricove\Logistics\Core\ShipmentManager::get_shipment_summary($sid);
        if ( ! is_array($summary) || empty($summary) ) continue;

        if ( ccv_ccb_offer_is_expired_for_summary( $sid, $summary, $courier_id ) ) {
            if ( class_exists('\Caricove\Logistics\Core\AutoAssign') && method_exists('\Caricove\Logistics\Core\AutoAssign', 'handle_offer_timeout') ) {
                $timeout_courier_id = intval($summary['offer_courier_id'] ?? $courier_id);
                if ( $timeout_courier_id > 0 ) {
                    \Caricove\Logistics\Core\AutoAssign::handle_offer_timeout($sid, $timeout_courier_id);
                }
            }
            continue;
        }

        $status = (string)($summary['status'] ?? '');
        $offer_is_live = ccv_ccb_offer_is_live_for_summary( $sid, $summary, $courier_id );

        if ( in_array($status, array('delivered','returned','cancelled'), true) ) {
            continue;
        }

        $summary['offer_is_live'] = $offer_is_live;
        $rows[$sid] = $summary;
    }

    $active_trip_id = 0;
    $active_priority = null;
    foreach ( $rows as $sid => $summary ) {
        $status = (string)($summary['status'] ?? '');
        if ( ! empty($summary['offer_is_live']) ) continue;

        $priority = 99;
        if ( in_array($status, array('in_transit','picked_up'), true) ) {
            $priority = 1;
        } elseif ( $status === 'assigned' ) {
            $priority = 2;
        }

        if ( $priority === 99 ) continue;

        $accepted_at = !empty($summary['assignment_accepted_at']) ? strtotime((string)$summary['assignment_accepted_at']) : 0;
        $last_change = !empty($summary['last_status_change_at']) ? strtotime((string)$summary['last_status_change_at']) : 0;
        $sort_ts = $accepted_at ?: $last_change ?: time();

        if ( $active_priority === null || $priority < $active_priority || ( $priority === $active_priority && $sort_ts < ($rows[$active_trip_id]['_sort_ts'] ?? PHP_INT_MAX) ) ) {
            $active_trip_id = $sid;
            $active_priority = $priority;
            $rows[$sid]['_sort_ts'] = $sort_ts;
        }
    }

    foreach ( $rows as $sid => $summary ) {
        $status = (string)($summary['status'] ?? 'assigned');
        if ( ! empty($summary['offer_is_live']) ) {
            $summary['queue_bucket'] = 'incoming';
            $bucket = 'active';
        } elseif ( $sid === $active_trip_id ) {
            $summary['queue_bucket'] = 'assigned';
            $bucket = 'handover';
        } else {
            $summary['queue_bucket'] = 'queued';
            $bucket = 'completed';
        }

        $job = ccv_ccb_build_scaffold_job($sid, $summary, $courier_id);
        $job = ccv_ccb_normalize_job_payload($job);
        $job['queue_bucket'] = $summary['queue_bucket'];
        $jobs[$bucket][] = $job;
    }

    return $jobs;
}

function ccv_ccb_ajax_fetch_jobs() {
    if ( ! is_user_logged_in() ) {
        wp_send_json_error(array('message' => 'Not logged in'), 401);
    }

    $nonce = isset($_REQUEST['nonce']) ? sanitize_text_field(wp_unslash($_REQUEST['nonce'])) : '';
    if ( ! wp_verify_nonce($nonce, 'caricove_courier_start_trip') ) {
        wp_send_json_error(array('message' => 'Bad nonce'), 403);
    }

    $courier_id = get_current_user_id();
    $jobs = ccv_ccb_collect_jobs_for_courier($courier_id);
    $html = array( 'active' => array(), 'handover' => array(), 'completed' => array() );

    foreach ( array('active','handover','completed') as $bucket ) {
        foreach ( (array) $jobs[$bucket] as $job ) {
            $normalized = ccv_ccb_normalize_job_payload($job);
            $html[$bucket][ (string) $normalized['id'] ] = ccv_ccb_render_job_card_html($normalized, $bucket);
        }
    }

    wp_send_json_success(array(
        'jobs' => $jobs,
        'html' => $html,
    ));
}
add_action('wp_ajax_caricove_courier_fetch_jobs', 'ccv_ccb_ajax_fetch_jobs');
