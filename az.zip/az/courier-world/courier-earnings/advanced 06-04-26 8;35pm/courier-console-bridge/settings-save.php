<?php
/**
 * Plugin Name: Caricove Courier Console Bridge — Settings Save
 * Description: AJAX save for courier settings (availability/max_jobs/range) + sync to CourierProfile keys if present.
 * Version: 1.0.0
 */

if ( ! defined('ABSPATH') ) exit;

add_action('wp_ajax_caricove_courier_save_settings', function(){

    if ( ! is_user_logged_in() ) {
        wp_send_json_error(array('message'=>'Not logged in'), 401);
    }

    // Reuse the existing start-trip nonce already in your meta div
    $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash($_POST['nonce'])) : '';
    if ( ! wp_verify_nonce($nonce, 'caricove_courier_start_trip') ) {
        wp_send_json_error(array('message'=>'Bad nonce'), 403);
    }

    $courier_id = get_current_user_id();

    $availability = isset($_POST['availability']) ? sanitize_key(wp_unslash($_POST['availability'])) : 'online';
    if ( $availability !== 'offline' ) $availability = 'online';

    $max_jobs = isset($_POST['max_jobs']) ? intval($_POST['max_jobs']) : 3;
    if ( ! in_array($max_jobs, array(1,3,5), true) ) $max_jobs = 3;

    $range = isset($_POST['range']) ? sanitize_key(wp_unslash($_POST['range'])) : 'local_area';
    $allowed_ranges = array('very_close','local_area','across_georgetown','extended_routes');
    if ( ! in_array($range, $allowed_ranges, true) ) $range = 'local_area';

    // Save simple prefs
    update_user_meta($courier_id, '_ccv_availability', $availability);
    update_user_meta($courier_id, '_ccv_max_active_jobs', $max_jobs);
    update_user_meta($courier_id, '_ccv_range_pref', $range);

    // Translate range → helper approach radius.
    // Planner band truth remains canonical; this is only the protected
    // courier-side pickup sanity helper mirrored into existing raw keys.
    $radius_km = 7;
    if ($range === 'very_close') $radius_km = 3;
    if ($range === 'local_area') $radius_km = 7;
    if ($range === 'across_georgetown') $radius_km = 15;
    if ($range === 'extended_routes') $radius_km = 15;

    // Sync to Core CourierProfile keys if present (so eligibility uses it)
    if ( class_exists('\Caricove\Logistics\Core\CourierProfile') ) {
        $CP = '\Caricove\Logistics\Core\CourierProfile';

        if ( defined($CP.'::META_STATUS') ) {
            update_user_meta($courier_id, $CP::META_STATUS, $availability === 'online' ? 'online' : 'offline');
        }
        if ( defined($CP.'::META_LAST_SEEN_TS') && $availability === 'online' ) {
            update_user_meta($courier_id, $CP::META_LAST_SEEN_TS, time());
        }
        if ( defined($CP.'::META_RADIUS_KM') ) {
            update_user_meta($courier_id, $CP::META_RADIUS_KM, $radius_km);
        }
        if ( defined($CP.'::META_MAX_ACTIVE_JOBS') ) {
            update_user_meta($courier_id, $CP::META_MAX_ACTIVE_JOBS, $max_jobs);
        }
    }

    wp_send_json_success(array(
        'message' => 'Settings updated — dispatcher adjusted.',
        'availability' => $availability,
        'max_jobs' => $max_jobs,
        'range' => $range,
        'radius_km' => $radius_km,
    ));
});

add_filter('cc_courier_profile', function($meta, $courier_id){
    if ( ! is_array($meta) ) {
        $meta = array();
    }

    $courier_id = intval($courier_id);
    if ( ! $courier_id ) {
        return $meta;
    }

    $range = sanitize_key((string) get_user_meta($courier_id, '_ccv_range_pref', true));
    $max_jobs = intval(get_user_meta($courier_id, '_ccv_max_active_jobs', true));

    $radius_key = class_exists('\Caricove\Logistics\Core\CourierProfile')
        ? \Caricove\Logistics\Core\CourierProfile::META_RADIUS_KM
        : '_caricove_courier_radius_km';

    $radius = floatval(get_user_meta($courier_id, $radius_key, true));

    if ( $radius <= 0 ) {
        if ( $range === 'very_close' ) $radius = 3;
        elseif ( $range === 'local_area' ) $radius = 7;
        elseif ( $range === 'across_georgetown' ) $radius = 15;
        else $radius = 15;
    }

    $meta['ccv_settings'] = array(
        'range_pref' => $range ?: 'local_area',
        'radius_km' => $radius,
        'max_jobs' => $max_jobs > 0 ? $max_jobs : 3,
        'availability' => sanitize_key((string) get_user_meta($courier_id, '_ccv_availability', true)),
    );

    return $meta;
}, 20, 2);
