<?php
/**
 * Plugin Name: Caricove Courier Console Bridge — JS (Dispatch UX Upgrade)
 * Description: Heartbeat, live offer modal, queued-job UX, and strict active-trip focus for courier console.
 * Version: 5.0.0
 */

if ( ! defined('ABSPATH') ) exit;

add_action('wp_footer', function(){
    if ( is_admin() ) return;

    $hb_core  = esc_js( rest_url('caricove-logistics/v1/heartbeat') );
    $hb_proxy = esc_js( rest_url('caricove-logistics-bridge/v1/heartbeat') );
?>
<script>
(function(){
  var HB_CORE  = "<?php echo $hb_core; ?>";
  var HB_PROXY = "<?php echo $hb_proxy; ?>";

  var jobsRefreshTimer = null;
  var hbTimer = null;
  var hbWatchId = null;
  var lastBeatAt = 0;
  var booted = false;
  var selectedJobId = '';
  var latestJobs = { active: [], handover: [], completed: [] };
  var currentListMode = 'handover';
  var manualListMode = '';
  var offerState = {
    jobId: '',
    expiresAt: 0,
    countdownTimer: null,
    active: false,
  };

  function meta(){ return document.getElementById('ccv-courier-js-meta'); }
  function getAttr(k){ var m=meta(); return m ? (m.getAttribute(k)||'') : ''; }
  function getAjaxUrl(){ return getAttr('data-ajax-url'); }
  function getStartNonce(){ return getAttr('data-start-nonce') || getAttr('data-start-trip-nonce') || ''; }
  function getRestNonce(){ return getAttr('data-rest-nonce') || ''; }
  function hasConsole(){ return !!document.querySelector('.ccv-courier-shell') && !!meta(); }

  function qs(sel, ctx){ return (ctx || document).querySelector(sel); }
  function qsa(sel, ctx){ return Array.prototype.slice.call((ctx || document).querySelectorAll(sel)); }

  function normalizeJob(job){
    if (!job) return null;
    var jobId = job.job_id || job.id || null;
    if (!jobId) return null;
    var status = job.status || job.state || '';
    var statusLabel = job.status_label || job.state_label || (status ? status.replace(/_/g,' ').replace(/\b\w/g, function(m){ return m.toUpperCase(); }) : '');
    return Object.assign({}, job, {
      job_id: String(jobId),
      id: String(jobId),
      status: status,
      state: status,
      status_label: statusLabel,
      state_label: statusLabel
    });
  }

  function doAjax(action, bodyObj, cb){
    var url = getAjaxUrl();
    if (!url || !window.fetch){ if(cb) cb(null); return; }

    var f = new FormData();
    f.append('action', action);
    if (bodyObj){
      Object.keys(bodyObj).forEach(function(k){
        f.append(k, bodyObj[k]);
      });
    }

    fetch(url, { method:'POST', credentials:'same-origin', body:f })
      .then(function(r){ return r.json(); })
      .then(function(resp){ if(cb) cb(resp); })
      .catch(function(){ if(cb) cb(null); });
  }

  function beatAjaxFallback(lat,lng,reason){
    doAjax('caricove_courier_heartbeat_fallback', {
      nonce: getStartNonce(),
      lat: (typeof lat==='number' ? String(lat) : ''),
      lng: (typeof lng==='number' ? String(lng) : ''),
      reason: reason || 'fallback'
    }, function(){});
  }

  function beatRest(url, payload, restNonce, done){
    fetch(url, {
      method:'POST',
      credentials:'same-origin',
      headers:{ 'Content-Type':'application/json', 'X-WP-Nonce': restNonce },
      body: JSON.stringify(payload || {})
    }).then(function(r){
      if (!r) return done(false);
      done(r.status === 200 || r.status === 201);
    }).catch(function(){ done(false); });
  }

  function sendHeartbeat(lat,lng,reason){
    if (!hasConsole()) return;
    var now = Date.now();
    if (now - lastBeatAt < 3000) return;
    lastBeatAt = now;

    var restNonce = getRestNonce();
    var payload = { reason: reason || 'tick' };
    if (typeof lat==='number' && typeof lng==='number') {
      payload.lat = lat;
      payload.lng = lng;
    }

    if (!restNonce) {
      beatAjaxFallback(lat,lng,'no_rest_nonce');
      return;
    }

    beatRest(HB_CORE, payload, restNonce, function(ok){
      if (ok) return;
      beatRest(HB_PROXY, payload, restNonce, function(ok2){
        if (ok2) return;
        beatAjaxFallback(lat,lng,'rest_failed');
      });
    });
  }

  function heartbeatTick(reason){
    if (!hasConsole()) return;
    if (!navigator.geolocation || !navigator.geolocation.getCurrentPosition){
      sendHeartbeat(null,null,reason || 'no_geo');
      return;
    }
    navigator.geolocation.getCurrentPosition(function(pos){
      sendHeartbeat(pos.coords.latitude, pos.coords.longitude, reason || 'gps_tick');
    }, function(){
      sendHeartbeat(null,null,reason || 'gps_denied');
    }, { enableHighAccuracy:true, maximumAge:5000, timeout:8000 });
  }

  function startHeartbeat(){
    if (!hasConsole()) return;
    if (hbTimer) clearInterval(hbTimer);
    heartbeatTick('boot');
    hbTimer = setInterval(function(){ heartbeatTick('interval'); }, 15000);

    if (navigator.geolocation && navigator.geolocation.watchPosition) {
      try {
        if (hbWatchId) navigator.geolocation.clearWatch(hbWatchId);
        hbWatchId = navigator.geolocation.watchPosition(function(pos){
          sendHeartbeat(pos.coords.latitude, pos.coords.longitude, 'watch_move');
        }, function(){}, { enableHighAccuracy:true, maximumAge:2000, timeout:12000 });
      } catch (e) {}
    }

    document.addEventListener('visibilitychange', function(){
      if (document.visibilityState === 'visible') heartbeatTick('visible');
    });
    window.addEventListener('focus', function(){ heartbeatTick('focus'); });
  }

  function emptyText(bucket){
    if (bucket === 'active') return 'No incoming offers right now. New dispatches will appear here instantly.';
    if (bucket === 'handover') return 'No active assigned trip right now. Your live trip appears here when you accept one.';
    return 'No queued jobs right now. Accepted follow-up jobs wait here until your active trip clears.';
  }

  function replaceBucketHtml(bucket, htmlMap){
    var list = document.getElementById('ccv-job-list-' + bucket);
    if (!list) return;

    var items = htmlMap && typeof htmlMap === 'object' ? Object.keys(htmlMap) : [];
    if (!items.length) {
      list.innerHTML = '<div class="ccv-job-empty">' + emptyText(bucket) + '</div>';
      return;
    }

    list.innerHTML = items.map(function(id){ return htmlMap[id] || ''; }).join('');
  }

  function semanticRelabel(){
    var title = qs('.ccv-list-header-title');
    var sub = qs('.ccv-list-header-sub');
    if (title) title.textContent = 'Dispatch';
    if (sub) sub.textContent = 'Incoming offers, your active assigned trip, and queued follow-up jobs.';

    qsa('.ccv-list-toggle-btn').forEach(function(btn){
      var target = btn.getAttribute('data-list-target') || '';
      if (target === 'active') btn.textContent = 'Incoming';
      if (target === 'handover') btn.textContent = 'Assigned';
      if (target === 'completed') btn.textContent = 'Queued';
    });
  }

  function clearSelectedJobCards(){
    qsa('.ccv-job-card').forEach(function(card){
      card.classList.remove('ccv-job-card--selected');
      card.classList.remove('is-active');
    });
  }

  function setListMode(mode){
    currentListMode = mode || currentListMode || 'handover';
    var activeList = qs('#ccv-job-list-active');
    var handoverList = qs('#ccv-job-list-handover');
    var completedList = qs('#ccv-job-list-completed');

    qsa('.ccv-list-toggle-btn').forEach(function(btn){
      if (btn.getAttribute('data-list-target') === mode) {
        btn.classList.add('ccv-list-toggle-btn--active');
      } else {
        btn.classList.remove('ccv-list-toggle-btn--active');
      }
    });

    [activeList, handoverList, completedList].forEach(function(list){
      if (list) list.classList.add('ccv-job-list--hidden');
    });

    if (mode === 'active' && activeList) activeList.classList.remove('ccv-job-list--hidden');
    if (mode === 'handover' && handoverList) handoverList.classList.remove('ccv-job-list--hidden');
    if (mode === 'completed' && completedList) completedList.classList.remove('ccv-job-list--hidden');
  }

  function findActiveAssignedCard(){
    return qs('#ccv-job-list-handover .ccv-job-card');
  }

  function activeTripEmptyState(){
    var detailShell = qs('#ccv-job-detail-shell');
    if (!detailShell) return;
    detailShell.innerHTML = '<div class="ccv-detail-empty">Your active assigned trip appears here. Incoming offers stay in the left panel until you accept or reject them.</div>';
  }

  function focusAssignedCard(){
    if (manualListMode && manualListMode !== 'handover') {
      return;
    }

    var activeCard = findActiveAssignedCard();
    if (!activeCard) {
      selectedJobId = '';
      clearSelectedJobCards();
      activeTripEmptyState();
      try {
        window.dispatchEvent(new CustomEvent('caricove:activeTripFocus', { detail: { jobId: '', card: null } }));
      } catch (e) {}
      return;
    }

    selectedJobId = activeCard.getAttribute('data-job-id') || '';
    clearSelectedJobCards();
    activeCard.classList.add('ccv-job-card--selected');
    if (typeof activeCard.click === 'function') {
      activeCard.click();
    }
    try {
      window.dispatchEvent(new CustomEvent('caricove:activeTripFocus', { detail: { jobId: selectedJobId, card: activeCard } }));
    } catch (e) {}
  }

  function preferredListMode(){
    if (manualListMode) return manualListMode;
    if (currentListMode && (latestJobs[currentListMode] || []).length) return currentListMode;
    if ((latestJobs.handover || []).length) return 'handover';
    if ((latestJobs.active || []).length) return 'active';
    if ((latestJobs.completed || []).length) return 'completed';
    return currentListMode || 'handover';
  }

  function clearOfferTimer(){
    if (offerState.countdownTimer) {
      clearInterval(offerState.countdownTimer);
      offerState.countdownTimer = null;
    }
  }

  function ensureOfferModal(){
    if (document.getElementById('ccv-offer-modal-backdrop')) return;

    var style = document.createElement('style');
    style.textContent = ''+
      '.ccv-offer-backdrop{position:fixed;inset:0;background:rgba(2,7,18,.78);backdrop-filter:blur(10px);display:none;align-items:center;justify-content:center;z-index:99999;padding:24px}'+
      '.ccv-offer-backdrop--show{display:flex}'+
      '.ccv-offer-modal{width:min(480px,100%);border:1px solid rgba(70,160,255,.35);background:linear-gradient(180deg,rgba(8,18,38,.98),rgba(4,10,22,.98));box-shadow:0 20px 80px rgba(0,0,0,.6),0 0 24px rgba(18,122,255,.22);border-radius:24px;padding:22px;color:#eef6ff}'+
      '.ccv-offer-title{font-size:20px;font-weight:700;letter-spacing:.02em;margin-bottom:8px}'+
      '.ccv-offer-route{font-size:14px;opacity:.86;line-height:1.45;margin-bottom:18px}'+
      '.ccv-offer-chip{display:inline-flex;align-items:center;gap:8px;padding:8px 12px;border-radius:999px;background:rgba(16,38,78,.92);border:1px solid rgba(64,140,255,.35);font-size:13px;font-weight:600;margin-bottom:16px}'+
      '.ccv-offer-actions{display:flex;gap:12px;margin-top:18px}'+
      '.ccv-offer-actions .ccv-btn{flex:1;min-height:52px;font-size:15px}'+
      '.ccv-offer-meta{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:10px}'+
      '.ccv-offer-meta-card{padding:12px 14px;border-radius:16px;background:rgba(9,20,42,.88);border:1px solid rgba(255,255,255,.06)}'+
      '.ccv-offer-meta-label{font-size:11px;letter-spacing:.08em;text-transform:uppercase;opacity:.6;margin-bottom:4px}'+
      '.ccv-offer-meta-value{font-size:14px;font-weight:600}'+
      '.ccv-btn--danger{background:linear-gradient(135deg,#7d1020,#ff465d);color:#fff;border:1px solid rgba(255,110,132,.5)}';
    document.head.appendChild(style);

    var backdrop = document.createElement('div');
    backdrop.id = 'ccv-offer-modal-backdrop';
    backdrop.className = 'ccv-offer-backdrop';
    backdrop.innerHTML = ''+
      '<div class="ccv-offer-modal" role="dialog" aria-modal="true" aria-labelledby="ccv-offer-modal-title">'+
      '  <div class="ccv-offer-title" id="ccv-offer-modal-title">Incoming Offer</div>'+
      '  <div class="ccv-offer-route" id="ccv-offer-modal-route"></div>'+
      '  <div class="ccv-offer-chip" id="ccv-offer-modal-countdown">Respond in 12s</div>'+
      '  <div class="ccv-offer-meta">'+
      '    <div class="ccv-offer-meta-card"><div class="ccv-offer-meta-label">Distance band</div><div class="ccv-offer-meta-value" id="ccv-offer-distance-band">—</div></div>'+
      '    <div class="ccv-offer-meta-card"><div class="ccv-offer-meta-label">Quote</div><div class="ccv-offer-meta-value" id="ccv-offer-quote">—</div></div>'+
      '  </div>'+
      '  <div class="ccv-offer-actions">'+
      '    <button type="button" class="ccv-btn ccv-btn--primary" id="ccv-offer-accept">Accept</button>'+
      '    <button type="button" class="ccv-btn ccv-btn--danger" id="ccv-offer-reject">Reject</button>'+
      '  </div>'+
      '</div>';
    document.body.appendChild(backdrop);
  }

  function closeOfferModal(){
    clearOfferTimer();
    offerState.jobId = '';
    offerState.expiresAt = 0;
    offerState.active = false;
    var backdrop = document.getElementById('ccv-offer-modal-backdrop');
    if (backdrop) backdrop.classList.remove('ccv-offer-backdrop--show');
  }

  function updateOfferCountdown(){
    var countdown = document.getElementById('ccv-offer-modal-countdown');
    var acceptBtn = document.getElementById('ccv-offer-accept');
    var rejectBtn = document.getElementById('ccv-offer-reject');
    if (!countdown) return;

    var secs = Math.max(0, Math.ceil(offerState.expiresAt - (Date.now()/1000)));
    countdown.textContent = 'Respond in ' + secs + 's';
    if (acceptBtn) acceptBtn.disabled = secs <= 0;
    if (rejectBtn) rejectBtn.disabled = secs <= 0;
    if (secs <= 0) {
      countdown.textContent = 'Offer expired';
      clearOfferTimer();
      setTimeout(function(){ refreshJobs('offer_timeout'); }, 600);
    }
  }

  function openOfferModal(job){
    if (!job) return;
    ensureOfferModal();

    var backdrop = document.getElementById('ccv-offer-modal-backdrop');
    var title = document.getElementById('ccv-offer-modal-title');
    var route = document.getElementById('ccv-offer-modal-route');
    var distanceBand = document.getElementById('ccv-offer-distance-band');
    var quote = document.getElementById('ccv-offer-quote');
    var acceptBtn = document.getElementById('ccv-offer-accept');
    var rejectBtn = document.getElementById('ccv-offer-reject');

    if (!backdrop || !title || !route || !distanceBand || !quote) return;

    var fromArea = job.pickup_city || job.pickup_text || 'Pickup';
    var toArea = job.dropoff_city || job.dropoff_text || 'Dropoff';
    title.textContent = job.label || ('Shipment #' + job.job_id);
    route.textContent = fromArea + ' → ' + toArea;
    distanceBand.textContent = (job.distance_band || '—').replace(/_/g,' ');
    quote.textContent = job.quote_total_gyd ? ('GYD ' + Number(job.quote_total_gyd).toFixed(2)) : '—';

    offerState.jobId = String(job.job_id || '');
    offerState.expiresAt = Number(job.offer_expires_at || 0);
    offerState.active = true;

    clearOfferTimer();
    offerState.countdownTimer = setInterval(updateOfferCountdown, 1000);
    updateOfferCountdown();

    if (acceptBtn) {
      acceptBtn.onclick = function(){
        acceptBtn.disabled = true;
        rejectBtn.disabled = true;
        doAjax('caricove_courier_accept_offer', {
          job_id: offerState.jobId,
          nonce: getStartNonce()
        }, function(resp){
          if (!resp || !resp.success) {
            acceptBtn.disabled = false;
            rejectBtn.disabled = false;
            updateOfferCountdown();
            return;
          }
          closeOfferModal();
          refreshJobs('offer_accept');
        });
      };
    }

    if (rejectBtn) {
      rejectBtn.onclick = function(){
        acceptBtn.disabled = true;
        rejectBtn.disabled = true;
        doAjax('caricove_courier_reject_offer', {
          job_id: offerState.jobId,
          nonce: getStartNonce()
        }, function(resp){
          closeOfferModal();
          refreshJobs('offer_reject');
        });
      };
    }

    backdrop.classList.add('ccv-offer-backdrop--show');
  }

  function maybeShowOfferModal(){
    var offers = (latestJobs.active || []).map(normalizeJob).filter(function(job){
      return job && !!job.offer_is_live && Number(job.offer_expires_at || 0) > (Date.now()/1000);
    }).sort(function(a,b){
      return Number(a.offer_expires_at || 0) - Number(b.offer_expires_at || 0);
    });

    if (!offers.length) {
      closeOfferModal();
      return;
    }

    var nextOffer = offers[0];
    if (offerState.active && offerState.jobId === String(nextOffer.job_id)) {
      offerState.expiresAt = Number(nextOffer.offer_expires_at || 0);
      updateOfferCountdown();
      return;
    }

    openOfferModal(nextOffer);
  }

  function refreshJobs(reason){
    if (!hasConsole()) return;
    doAjax('caricove_courier_fetch_jobs', { nonce: getStartNonce(), reason: reason || 'poll' }, function(resp){
      if (!resp || !resp.success || !resp.data) return;

      latestJobs = resp.data.jobs || { active: [], handover: [], completed: [] };
      var html = resp.data.html || {};

      ['active','handover','completed'].forEach(function(bucket){
        replaceBucketHtml(bucket, html[bucket] || {});
      });

      semanticRelabel();
      setListMode(preferredListMode());
      focusAssignedCard();
      maybeShowOfferModal();
    });
  }

  function scheduleJobsRefresh(){
    if (!hasConsole()) return;
    if (jobsRefreshTimer) clearInterval(jobsRefreshTimer);
    refreshJobs('boot');
    jobsRefreshTimer = setInterval(function(){ refreshJobs('interval'); }, 5000);
  }

  document.addEventListener('click', function(e){
    var toggle = e.target.closest('.ccv-list-toggle-btn');
    if (!toggle) return;
    var target = toggle.getAttribute('data-list-target') || 'handover';
    manualListMode = target;
    currentListMode = target;
    setListMode(target);
  }, true);

  function finishAction(resp){
    refreshJobs('action_finish');
  }

  document.addEventListener('click', function(e){
    var card = e.target.closest('.ccv-job-card');
    if (!card) return;
    var bucket = card.getAttribute('data-bucket') || '';

    if (bucket === 'active') {
      e.preventDefault();
      e.stopPropagation();
      var jobId = card.getAttribute('data-job-id') || '';
      var job = (latestJobs.active || []).map(normalizeJob).filter(function(item){
        return item && String(item.job_id) === String(jobId);
      })[0] || null;
      if (job) openOfferModal(job);
      else maybeShowOfferModal();
      return false;
    }

    if (bucket === 'completed') {
      e.preventDefault();
      e.stopPropagation();
      focusAssignedCard();
      return false;
    }

    selectedJobId = card.getAttribute('data-job-id') || '';
    clearSelectedJobCards();
    card.classList.add('ccv-job-card--selected');
  }, true);

  window.CaricoveCourierStatusHandler = function(payload){
    if (!payload || !payload.job_id || !payload.to_state) return;

    var jobId = payload.job_id;
    var toState = (payload.to_state || '').toLowerCase();
    var code = payload.code || '';

    if ((toState === 'pickup_code' || toState === 'delivered') && !code) {
      var back = document.getElementById('ccv-code-modal-backdrop');
      if (back) {
        back.classList.add('ccv-modal-backdrop--show');
        document.body.style.overflow = 'hidden';
      }
      return;
    }

    var btn = document.querySelector('#ccv-job-detail-shell [data-role="primary-action"]');
    if (btn){
      btn.disabled = true;
      btn.textContent = 'Working…';
    }

    function finish(resp, restoreLabel){
      if (btn){
        btn.disabled = false;
        btn.textContent = restoreLabel || 'Continue';
      }
      finishAction(resp);
    }

    if (toState === 'en_route') {
      doAjax('caricove_courier_start_trip', { job_id: String(jobId), nonce: getStartNonce() }, function(resp){
        finish(resp, payload.label || 'Start Trip');
      });
      return;
    }

    if (toState === 'pickup_code') {
      doAjax('caricove_courier_verify_pickup', { job_id: String(jobId), code: String(code), nonce: getStartNonce() }, function(resp){
        finish(resp, payload.label || 'Confirm Pickup');
      });
      return;
    }

    if (toState === 'delivered') {
      doAjax('caricove_courier_verify_delivery', { job_id: String(jobId), code: String(code), nonce: getStartNonce() }, function(resp){
        finish(resp, payload.label || 'Complete Delivery');
      });
      return;
    }
  };

  function bootConsoleBridge(){
    if (booted) return;
    if (!hasConsole()) return;
    booted = true;
    semanticRelabel();
    startHeartbeat();
    scheduleJobsRefresh();

    document.addEventListener('visibilitychange', function(){
      if (document.visibilityState === 'visible') refreshJobs('visible');
    });
    window.addEventListener('focus', function(){ refreshJobs('focus'); });
  }

  document.addEventListener('DOMContentLoaded', bootConsoleBridge);
  window.addEventListener('load', bootConsoleBridge);

  var lateBoots = 0;
  var lateTimer = setInterval(function(){
    lateBoots++;
    if (hasConsole()) {
      bootConsoleBridge();
      clearInterval(lateTimer);
      return;
    }
    if (lateBoots >= 20) clearInterval(lateTimer);
  }, 1000);
})();
</script>
<?php
}, 999);
