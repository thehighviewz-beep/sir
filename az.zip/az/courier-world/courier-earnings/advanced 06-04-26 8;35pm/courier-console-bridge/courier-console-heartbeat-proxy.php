<?php
/**
 * Plugin Name: Caricove Courier Console Bridge — Heartbeat Proxy (Hardened)
 * Description: REST proxy: /caricove-logistics-bridge/v1/heartbeat -> Core HeartbeatAPI::handle_heartbeat()
 * Version: 2.1.0
 */

if ( ! defined('ABSPATH') ) { exit; }

/**
 * Optional: if your loader supports it, this lets you “force core boot”
 * before routes register. Safe no-op if nothing hooks it.
 */
do_action('caricove_logistics_maybe_boot_core');

/**
 * Decide if Core heartbeat is available.
 */
function ccv_bridge_has_core_heartbeat() : bool {
    return (
        class_exists('\Caricove\Logistics\Core\HeartbeatAPI') &&
        method_exists('\Caricove\Logistics\Core\HeartbeatAPI', 'handle_heartbeat')
    );
}


function ccv_bridge_handle_heartbeat_fallback_ajax() {
    if ( ! is_user_logged_in() ) {
        wp_send_json_error(array('message' => 'Not logged in'), 401);
    }

    $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash($_POST['nonce'])) : '';
    if ( ! wp_verify_nonce($nonce, 'caricove_courier_start_trip') ) {
        wp_send_json_error(array('message' => 'Bad nonce'), 403);
    }

    $courier_id = get_current_user_id();
    $lat = isset($_POST['lat']) && $_POST['lat'] !== '' ? floatval(wp_unslash($_POST['lat'])) : null;
    $lng = isset($_POST['lng']) && $_POST['lng'] !== '' ? floatval(wp_unslash($_POST['lng'])) : null;

    if ( ccv_bridge_has_core_heartbeat() ) {
        $req = new WP_REST_Request('POST', '/caricove-logistics/v1/heartbeat');
        $req->set_param('courier_id', $courier_id);
        if ( null !== $lat ) {
            $req->set_param('lat', $lat);
        }
        if ( null !== $lng ) {
            $req->set_param('lng', $lng);
        }

        $res = \Caricove\Logistics\Core\HeartbeatAPI::handle_heartbeat($req);
        if ( $res instanceof WP_REST_Response ) {
            wp_send_json_success($res->get_data());
        }

        wp_send_json_success(array('ok' => true, 'courier_id' => $courier_id));
    }

    if ( class_exists('\Caricove\Logistics\Core\CourierProfile') ) {
        if ( null !== $lat ) update_user_meta($courier_id, \Caricove\Logistics\Core\CourierProfile::META_LAST_LAT, $lat);
        if ( null !== $lng ) update_user_meta($courier_id, \Caricove\Logistics\Core\CourierProfile::META_LAST_LNG, $lng);
        update_user_meta($courier_id, \Caricove\Logistics\Core\CourierProfile::META_LAST_SEEN_TS, time());
        if ( method_exists('\Caricove\Logistics\Core\CourierProfile', 'ensure_region_for_courier') ) {
            \Caricove\Logistics\Core\CourierProfile::ensure_region_for_courier($courier_id);
        }
    }

    do_action('cc_telemetry_courier_ping', $courier_id, array(
        'ts' => time(),
        'lat' => $lat,
        'lng' => $lng,
        'source' => 'bridge_ajax_fallback',
    ));

    wp_send_json_success(array('ok' => true, 'courier_id' => $courier_id));
}

add_action('wp_ajax_caricove_courier_heartbeat_fallback', 'ccv_bridge_handle_heartbeat_fallback_ajax');

/**
 * Register routes only when REST is initializing AND Core is available.
 * If Core isn't available, we still register a "soft-fail" route that never fatals.
 */
add_action('rest_api_init', function () {

    $namespace = 'caricove-logistics-bridge/v1';
    $route     = '/heartbeat';

    // Always register the route, but callback path depends on Core availability.
    register_rest_route($namespace, $route, array(
        'methods'  => 'POST',
        'permission_callback' => function () {
            return is_user_logged_in();
        },
        'callback' => function (WP_REST_Request $req) {

            // Attempt a late boot right before handling (covers load-order races).
            do_action('caricove_logistics_maybe_boot_core');

            if ( ccv_bridge_has_core_heartbeat() ) {
                try {
                    return \Caricove\Logistics\Core\HeartbeatAPI::handle_heartbeat($req);
                } catch (\Throwable $e) {
                    // Never fatal the REST server.
                    error_log('[CCV HEARTBEAT PROXY] Core threw: ' . $e->getMessage());
                    return new WP_REST_Response(array(
                        'ok'      => false,
                        'message' => 'Heartbeat failed inside Core.',
                    ), 500);
                }
            }

            // Soft-fail (no fatal, no white screen)
            return new WP_REST_Response(array(
                'ok'      => false,
                'message' => 'Core HeartbeatAPI missing (not loaded yet).',
            ), 503);
        },
    ));
}, 5); // early priority so it registers predictably