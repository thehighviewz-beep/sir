<?php
/**
 * Plugin Name: Caricove Courier Console Bridge — Balances
 * Description: Supplies balances + AJAX refresh for the console.
 * Version: 2.0.0
 */

if ( ! defined('ABSPATH') ) exit;

add_filter('caricove_logistics_scaffold_balances', function($balances, $courier_id){
    $courier_id = intval($courier_id);
    if ( ! $courier_id || ! class_exists('Caricove_Logistics_Earnings') ) return $balances;

    $e = Caricove_Logistics_Earnings::get_courier_balances($courier_id);

    $balances['available'] = floatval($e['available'] ?? 0);
    $balances['clearing']  = floatval($e['clearing'] ?? 0);
    $balances['held']      = floatval($e['paid'] ?? 0);
    $balances['currency']  = function_exists('get_woocommerce_currency') ? get_woocommerce_currency() : 'GYD';

    return $balances;
}, 10, 2);

add_action('wp_ajax_caricove_courier_get_balances', function(){
    if ( ! is_user_logged_in() ) wp_send_json_error(array('message'=>'Not logged in'), 401);
    if ( ! class_exists('Caricove_Logistics_Earnings') ) wp_send_json_error(array('message'=>'Earnings engine missing'), 500);

    $cid = get_current_user_id();
    $e = Caricove_Logistics_Earnings::get_courier_balances($cid);

    wp_send_json_success(array(
        'available' => floatval($e['available'] ?? 0),
        'clearing'  => floatval($e['clearing'] ?? 0),
        'held'      => floatval($e['paid'] ?? 0),
        'currency'  => function_exists('get_woocommerce_currency') ? get_woocommerce_currency() : 'GYD',
    ));
});