<?php
/**
 * Plugin Name: Caricove Courier Console Bridge — Actions (Telemetry-Guaranteed)
 * Description: Start Trip + Verify Pickup + Verify Delivery. Guarantees telemetry legs with idempotency + rich context.
 * Version: 2.2.1-telemetry-guaranteed
 */

if ( ! defined('ABSPATH') ) exit;

/**
 * Hard safety: if Core is missing, do NOT register ajax handlers.
 */
if (
    ! class_exists('\Caricove\Logistics\Core\ShipmentManager') ||
    ! class_exists('\Caricove\Logistics\Core\Schema')
) {
    return;
}

/* ---------------------------
 * Guards
 * --------------------------- */
function ccv_ccb_core_ok_or_fail() {
    if ( ! class_exists('\Caricove\Logistics\Core\ShipmentManager') ) {
        wp_send_json_error(array('message' => 'Core ShipmentManager missing'), 500);
    }
    if ( ! class_exists('\Caricove\Logistics\Core\Schema') ) {
        wp_send_json_error(array('message' => 'Core Schema missing'), 500);
    }
}

/* ---------------------------
 * Telemetry meta keys (match inspector contract)
 * --------------------------- */
function ccv_ccb_leg_start_meta_key( $leg ) {
    $leg = sanitize_key((string)$leg);
    if ( $leg === 'pickup' )  return '_cc_telemetry_leg_pickup_started_at';
    if ( $leg === 'dropoff' ) return '_cc_telemetry_leg_dropoff_started_at';
    return '';
}

function ccv_ccb_leg_done_meta_key( $leg ) {
    $leg = sanitize_key((string)$leg);
    if ( $leg === 'pickup' )  return '_cc_telemetry_leg_pickup_completed_at';
    if ( $leg === 'dropoff' ) return '_cc_telemetry_leg_dropoff_completed_at';
    return '';
}


function ccv_ccb_append_quality_flag( $shipment_id, $flag ) {
    $shipment_id = intval($shipment_id);
    $flag = sanitize_key((string)$flag);
    if ( ! $shipment_id || $flag === '' ) return;

    $raw = get_post_meta($shipment_id, '_cc_telemetry_quality_flags', true);
    $arr = is_array($raw) ? $raw : (is_string($raw) && $raw !== '' ? array($raw) : array());

    if ( ! in_array($flag, $arr, true) ) {
        $arr[] = $flag;
        update_post_meta($shipment_id, '_cc_telemetry_quality_flags', $arr);
    }
}

/* ---------------------------
 * Telemetry context builder (rich + stable)
 * --------------------------- */
function ccv_ccb_build_telemetry_context( $shipment_id, $courier_id, array $summary, $leg, $event, $reason = '' ) {

    $leg    = sanitize_key((string)$leg);
    $event  = sanitize_key((string)$event);
    $reason = sanitize_key((string)$reason);

    $ctx = array(
        'bridge_ver'    => '2.2.1-telemetry-guaranteed',
        'event'         => $event, // leg_started | leg_completed
        'leg'           => $leg,
        'ts_utc'        => time(),
        'shipment_id'   => intval($shipment_id),
        'courier_id'    => intval($courier_id),
        'reason'        => $reason,

        'status'        => (string)($summary['status'] ?? ''),
        'type'          => (string)($summary['type'] ?? ''),
        'origin_anchor' => (string)($summary['origin_anchor'] ?? ''),
        'dest_anchor'   => (string)($summary['destination_anchor'] ?? ''),
        'pickup_coords' => (string)($summary['pickup_coords'] ?? ''),
        'dropoff_coords'=> (string)($summary['dropoff_coords'] ?? ''),
        'size_band'     => (string)($summary['size_band'] ?? ''),
        'weight_band'   => (string)($summary['weight_band'] ?? ''),
        'bundle_id'     => (string)($summary['bundle_id'] ?? ''),
        'bundle_seq'    => intval($summary['bundle_seq'] ?? 0),
    );

    // Best-effort courier dimension
    if ( class_exists('\Caricove\Logistics\Core\CourierProfile') && method_exists('\Caricove\Logistics\Core\CourierProfile', 'get_profile') ) {
        $p = \Caricove\Logistics\Core\CourierProfile::get_profile( intval($courier_id) );
        if ( is_array($p) ) {
            $ctx['vehicle_type']   = (string)($p['vehicle_type'] ?? '');
            $ctx['capacity_class'] = (string)($p['capacity_class'] ?? '');
            $ctx['region']         = (string)($p['region'] ?? '');
        }
    }

    return $ctx;
}

/* ---------------------------
 * Deterministic emissions (idempotent)
 * --------------------------- */
function ccv_ccb_emit_leg_started_once( $shipment_id, $courier_id, array $summary, $leg, $reason = '' ) {

    $shipment_id = intval($shipment_id);
    $courier_id  = intval($courier_id);
    $leg         = sanitize_key((string)$leg);

    $k = ccv_ccb_leg_start_meta_key($leg);
    if ( ! $k ) return;

    $existing = intval(get_post_meta($shipment_id, $k, true));
    if ( $existing > 0 ) return; // idempotent

    $now = time();
    update_post_meta($shipment_id, $k, $now);
    update_post_meta($shipment_id, '_cc_telemetry_last_ping_ts', $now);

    $ctx = ccv_ccb_build_telemetry_context($shipment_id, $courier_id, $summary, $leg, 'leg_started', $reason);
    do_action('cc_telemetry_leg_started', $shipment_id, $courier_id, $ctx);
}

function ccv_ccb_emit_leg_completed( $shipment_id, $courier_id, array $summary, $leg, $reason = '' ) {

    $shipment_id = intval($shipment_id);
    $courier_id  = intval($courier_id);
    $leg         = sanitize_key((string)$leg);

    $k_start = ccv_ccb_leg_start_meta_key($leg);
    $k_done  = ccv_ccb_leg_done_meta_key($leg);
    if ( ! $k_start || ! $k_done ) return;

    // ✅ IDP: if already completed, never emit again (prevents duplicates + double-learning)
    $done_ts = intval( get_post_meta($shipment_id, $k_done, true) );
    if ( $done_ts > 0 ) {
        return;
    }

    $start_ts = intval(get_post_meta($shipment_id, $k_start, true));
    if ( $start_ts <= 0 ) {
        // Backfill start if missing (quality flag)
        ccv_ccb_append_quality_flag($shipment_id, 'missing_leg_start_'.$leg);
        $start_ts = time();
        update_post_meta($shipment_id, $k_start, $start_ts);
    }

    $now = time();
    $minutes = max(0.0, ($now - $start_ts) / 60.0);

    // ✅ Write completion + last-leg markers BEFORE emitting (makes retries safe)
    update_post_meta($shipment_id, $k_done, $now);
    update_post_meta($shipment_id, '_cc_telemetry_last_leg_minutes', $minutes);
    update_post_meta($shipment_id, '_cc_telemetry_last_ping_ts', $now);

    $ctx = ccv_ccb_build_telemetry_context($shipment_id, $courier_id, $summary, $leg, 'leg_completed', $reason);
    $ctx['minutes'] = $minutes;

    do_action('cc_telemetry_leg_completed', $shipment_id, $courier_id, $ctx);
}

/* ---------------------------
 * Ownership guard
 * --------------------------- */
function ccv_ccb_require_owned_shipment($shipment_id){
    if ( ! is_user_logged_in() ) wp_send_json_error(array('message'=>'Not logged in'), 401);

    ccv_ccb_core_ok_or_fail();

    $shipment_id = intval($shipment_id);
    if ( ! $shipment_id ) wp_send_json_error(array('message'=>'Missing job_id'), 400);

    $s = \Caricove\Logistics\Core\ShipmentManager::get_shipment_summary($shipment_id);
    if ( ! is_array($s) || empty($s) ) wp_send_json_error(array('message'=>'Shipment not found'), 404);

    $assigned = intval($s['courier_id'] ?? 0);
    $me = get_current_user_id();

    if ( $assigned && $assigned !== $me && ! current_user_can('manage_options') ) {
        wp_send_json_error(array('message'=>'Not assigned to this shipment'), 403);
    }

    return array($shipment_id, $assigned ?: $me, $s);
}

function ccv_ccb_require_live_offer($shipment_id){
    if ( ! is_user_logged_in() ) wp_send_json_error(array('message'=>'Not logged in'), 401);

    ccv_ccb_core_ok_or_fail();

    $shipment_id = intval($shipment_id);
    if ( ! $shipment_id ) wp_send_json_error(array('message'=>'Missing job_id'), 400);

    $me = get_current_user_id();
    $s = \Caricove\Logistics\Core\ShipmentManager::get_shipment_summary($shipment_id);
    if ( ! is_array($s) || empty($s) ) wp_send_json_error(array('message'=>'Shipment not found'), 404);

    $offerCourier = intval($s['offer_courier_id'] ?? 0);
    if ( $offerCourier !== $me && ! current_user_can('manage_options') ) {
        wp_send_json_error(array('message'=>'Offer is not assigned to you'), 403);
    }

    if ( ! class_exists('\Caricove\Logistics\Core\AutoAssign') || ! method_exists('\Caricove\Logistics\Core\AutoAssign', 'offer_is_live') ) {
        wp_send_json_error(array('message'=>'Offer engine unavailable'), 500);
    }

    if ( ! \Caricove\Logistics\Core\AutoAssign::offer_is_live($shipment_id, $offerCourier ?: $me) ) {
        \Caricove\Logistics\Core\AutoAssign::handle_offer_timeout($shipment_id, $offerCourier ?: $me);
        wp_send_json_error(array('message'=>'Offer expired'), 409);
    }

    return array($shipment_id, $me, $s);
}

/* ---------------------------
 * Standard response payload
 * --------------------------- */
function ccv_ccb_ajax_success_job($shipment_id, $courier_id){
    $s = \Caricove\Logistics\Core\ShipmentManager::get_shipment_summary($shipment_id);

    if ( function_exists('ccv_ccb_build_scaffold_job') ) {
        $job = ccv_ccb_build_scaffold_job($shipment_id, $s, $courier_id);
        $job['job_id'] = intval($job['job_id'] ?? ($job['id'] ?? $shipment_id));
        wp_send_json_success(array(
            'message' => 'OK',
            'job'     => $job,
            'summary' => $s,
        ));
    }

    $job = array(
        'job_id'          => intval($shipment_id),
        'status'          => (string)($s['status'] ?? ''),
        'status_label'    => (string)($s['status_label'] ?? ucwords(str_replace('_',' ', (string)($s['status'] ?? '')))),
        'next_state'      => '',
        'next_state_label'=> '',
    );

    $pickup_verified   = ! empty($s['pickup_code_verified']);
    $delivery_verified = ! empty($s['delivery_code_verified']);
    $status = (string)($s['status'] ?? '');

    if ($status === 'assigned') {
        $job['next_state'] = 'en_route';
        $job['next_state_label'] = 'Start Trip';
    } elseif ($status === 'in_transit' && ! $pickup_verified) {
        $job['next_state'] = 'pickup_code';
        $job['next_state_label'] = 'Confirm Pickup';
    } elseif ($status === 'picked_up') {
        $job['next_state'] = 'en_route';
        $job['next_state_label'] = 'On The Way';
    } elseif ($status === 'in_transit' && $pickup_verified && ! $delivery_verified) {
        $job['next_state'] = 'delivered';
        $job['next_state_label'] = 'Complete Delivery';
    }

    wp_send_json_success(array(
        'message' => 'OK',
        'job'     => $job,
        'summary' => $s,
    ));
}

add_action('wp_ajax_caricove_courier_accept_offer', function(){
    check_ajax_referer('caricove_courier_start_trip', 'nonce');

    list($sid, $cid, $s) = ccv_ccb_require_live_offer($_POST['job_id'] ?? 0);

    if ( ! class_exists('\Caricove\Logistics\Core\AutoAssign') || ! method_exists('\Caricove\Logistics\Core\AutoAssign', 'accept_job') ) {
        wp_send_json_error(array('message'=>'Offer engine unavailable'), 500);
    }

    $result = \Caricove\Logistics\Core\AutoAssign::accept_job($sid, $cid, array(
        'source' => 'courier_console',
    ));

    if ( is_wp_error($result) ) {
        wp_send_json_error(array('message'=>$result->get_error_message()), 409);
    }

    ccv_ccb_ajax_success_job($sid, $cid);
});

add_action('wp_ajax_caricove_courier_reject_offer', function(){
    check_ajax_referer('caricove_courier_start_trip', 'nonce');

    list($sid, $cid, $s) = ccv_ccb_require_live_offer($_POST['job_id'] ?? 0);

    if ( ! class_exists('\Caricove\Logistics\Core\AutoAssign') || ! method_exists('\Caricove\Logistics\Core\AutoAssign', 'reject_job') ) {
        wp_send_json_error(array('message'=>'Offer engine unavailable'), 500);
    }

    $result = \Caricove\Logistics\Core\AutoAssign::reject_job($sid, $cid, 'offer_rejected');
    if ( is_wp_error($result) ) {
        wp_send_json_error(array('message'=>$result->get_error_message()), 409);
    }

    wp_send_json_success(array(
        'message' => 'Offer rejected.',
        'job_id'  => $sid,
    ));
});

/* ============================================================
 * AJAX: Start Trip (Start → pickup leg)
 * ========================================================== */
add_action('wp_ajax_caricove_courier_start_trip', function(){
    check_ajax_referer('caricove_courier_start_trip', 'nonce');

    list($sid, $cid, $s) = ccv_ccb_require_owned_shipment($_POST['job_id'] ?? 0);

    $status = (string)($s['status'] ?? 'assigned');
    if ( ! in_array($status, array('assigned','picked_up','in_transit'), true) ) {
        wp_send_json_error(array('message'=>"Cannot start trip from status {$status}"), 400);
    }

    // We treat "Start Trip" as pickup-leg start unless pickup already verified
    $pickup_verified = ! empty($s['pickup_code_verified']);
    $leg = $pickup_verified ? 'dropoff' : 'pickup';

    if ( $status !== 'in_transit' ) {
        \Caricove\Logistics\Core\ShipmentManager::set_shipment_status($sid, 'in_transit', array(
            'source'     => 'courier_console',
            'reason'     => 'start_trip',
            'courier_id' => $cid,
            'leg'        => $leg,
        ));
    }

    // refresh summary
    $s2 = \Caricove\Logistics\Core\ShipmentManager::get_shipment_summary($sid);
    if ( is_array($s2) && ! empty($s2) ) $s = $s2;

    ccv_ccb_emit_leg_started_once($sid, $cid, $s, $leg, 'start_trip');

    ccv_ccb_ajax_success_job($sid, $cid);
});

/* ============================================================
 * AJAX: Verify Pickup (Complete pickup leg + GUARANTEE dropoff leg start)
 * ========================================================== */
add_action('wp_ajax_caricove_courier_verify_pickup', function(){
    check_ajax_referer('caricove_courier_start_trip', 'nonce');

    $code = trim(sanitize_text_field(wp_unslash($_POST['code'] ?? '')));
    if ($code==='') wp_send_json_error(array('message'=>'Pickup code required'), 400);

    ccv_ccb_core_ok_or_fail();

    list($sid, $cid, $s) = ccv_ccb_require_owned_shipment($_POST['job_id'] ?? 0);

    $stored = trim((string)($s['pickup_code'] ?? ''));
    if ($stored==='') wp_send_json_error(array('message'=>'No pickup code stored'), 400);
    if ($stored !== $code) wp_send_json_error(array('message'=>'Pickup code incorrect'), 400);

    // Self-heal: ensure pickup start exists
    ccv_ccb_emit_leg_started_once($sid, $cid, $s, 'pickup', 'pickup_confirm_start_selfheal');

    update_post_meta($sid, \Caricove\Logistics\Core\Schema::META_SHIPMENT_PICKUP_CODE_VERIFIED, 'yes');
    update_post_meta($sid, \Caricove\Logistics\Core\Schema::META_SHIPMENT_PICKUP_CODE_VERIFIED_AT, gmdate('c'));

    \Caricove\Logistics\Core\ShipmentManager::set_shipment_status($sid, 'picked_up', array(
        'source'     => 'courier_console',
        'reason'     => 'pickup_code_verified',
        'courier_id' => $cid,
    ));

    // refresh summary
    $s2 = \Caricove\Logistics\Core\ShipmentManager::get_shipment_summary($sid);
    if ( is_array($s2) && ! empty($s2) ) $s = $s2;

    // Complete pickup leg
    ccv_ccb_emit_leg_completed($sid, $cid, $s, 'pickup', 'pickup_confirmed');

    /**
     * GUARANTEE: pickup confirmed == dropoff started.
     * This is your “On The Way” moment.
     */
    ccv_ccb_emit_leg_started_once($sid, $cid, $s, 'dropoff', 'on_the_way');

    ccv_ccb_ajax_success_job($sid, $cid);
});

/* ============================================================
 * AJAX: Verify Delivery (Complete dropoff leg)
 * ========================================================== */
add_action('wp_ajax_caricove_courier_verify_delivery', function(){
    check_ajax_referer('caricove_courier_start_trip', 'nonce');

    $code = trim(sanitize_text_field(wp_unslash($_POST['code'] ?? '')));
    if ($code==='') wp_send_json_error(array('message'=>'Delivery code required'), 400);

    ccv_ccb_core_ok_or_fail();

    list($sid, $cid, $s) = ccv_ccb_require_owned_shipment($_POST['job_id'] ?? 0);

    $stored = trim((string)($s['delivery_code'] ?? ''));
    if ($stored==='') wp_send_json_error(array('message'=>'No delivery code stored'), 400);
    if ($stored !== $code) wp_send_json_error(array('message'=>'Delivery code incorrect'), 400);

    // Self-heal: ensure dropoff start exists (if something skipped pickup confirm)
    ccv_ccb_emit_leg_started_once($sid, $cid, $s, 'dropoff', 'dropoff_start_selfheal');

    update_post_meta($sid, \Caricove\Logistics\Core\Schema::META_SHIPMENT_DELIVERY_CODE_VERIFIED, 'yes');
    update_post_meta($sid, \Caricove\Logistics\Core\Schema::META_SHIPMENT_DELIVERY_CODE_VERIFIED_AT, gmdate('c'));

    \Caricove\Logistics\Core\ShipmentManager::set_shipment_status($sid, 'delivered', array(
        'source'     => 'courier_console',
        'reason'     => 'delivery_code_verified',
        'courier_id' => $cid,
    ));

    // refresh summary
    $s2 = \Caricove\Logistics\Core\ShipmentManager::get_shipment_summary($sid);
    if ( is_array($s2) && ! empty($s2) ) $s = $s2;

    // Complete dropoff leg
    ccv_ccb_emit_leg_completed($sid, $cid, $s, 'dropoff', 'delivery_confirmed');

    ccv_ccb_ajax_success_job($sid, $cid);
});