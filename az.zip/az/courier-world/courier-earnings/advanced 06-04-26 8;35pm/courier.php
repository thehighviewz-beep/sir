<?php
/**
 * Plugin Name: Caricove Logistics — Courier Console Scaffold
 * Description: Desktop-first visual scaffold for the Caricove courier console. Includes neon splash screen + unified console shell. Engine/logic modules feed data via filters.
 * Author: Caricove
 * Version: 1.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! class_exists( 'Caricove_Logistics_Scaffold' ) ) {

    class Caricove_Logistics_Scaffold {

        const ROLE_COURIER = 'caricove_courier';

        /**
         * Track whether we've already printed CSS/JS.
         *
         * @var bool
         */
        protected $assets_printed = false;

        /**
         * Singleton boot.
         */
        public static function boot() {
            static $instance = null;

            if ( null === $instance ) {
                $instance = new self();
            }

            return $instance;
        }

        /**
         * Constructor: hooks + shortcodes.
         */
        private function __construct() {
            add_shortcode( 'caricove_courier_console', array( $this, 'render_console_shortcode' ) );
        }

        /**
         * Shortcode handler: [caricove_courier_console]
         *
         * Desktop-first courier console scaffold.
         */
        public function render_console_shortcode( $atts = array() ) {
            if ( ! is_user_logged_in() ) {
                return '<div class="ccv-courier-shell ccv-courier-shell--restricted">You must be logged in to view the courier console.</div>';
            }

            $user = wp_get_current_user();
            if ( ! $user || ! $user->ID ) {
                return '<div class="ccv-courier-shell ccv-courier-shell--restricted">Unable to load your courier profile.</div>';
            }

            $roles = (array) $user->roles;

            // Allow administrators to preview the console.
            if ( ! in_array( self::ROLE_COURIER, $roles, true ) && ! in_array( 'administrator', $roles, true ) ) {
                return '<div class="ccv-courier-shell ccv-courier-shell--restricted">This console is reserved for Caricove couriers.</div>';
            }

            $courier_id   = $user->ID;
            $display_name = $user->display_name ? $user->display_name : $user->user_login;
            $region_label = get_user_meta( $courier_id, '_caricove_courier_region', true );

            // Base structure for jobs — engine modules will populate via filter.
            $empty_jobs = array(
                'active'    => array(),
                'completed' => array(),
            );

            /**
             * Filter: let the engine / other MU plugins feed job data into the scaffold.
             *
             * Each job should be an associative array:
             * [
             *   'id'             => int|string,
             *   'label'          => 'Job #1043',
             *   'state'          => 'assigned',              // machine state
             *   'state_label'    => 'Assigned',              // human state label
             *   'pay_label'      => '2,000',
             *   'currency'       => 'GYD',
             *   'pickup_title'   => 'Pickup',
             *   'pickup_text'    => 'Business World, Regent Street',
             *   'pickup_city'    => 'Georgetown',
             *   'pickup_name'    => 'Sender Name',
             *   'pickup_phone'   => '+592...',
             *   'dropoff_title'  => 'Dropoff',
             *   'dropoff_text'   => 'Lot 5, Eccles New Scheme',
             *   'dropoff_city'   => 'East Bank Demerara',
             *   'dropoff_name'   => 'Customer Name',
             *   'dropoff_phone'  => '+592...',
             *   'eta_label'      => 'ETA 35 mins',
             *   'distance_label' => '4.2 km',
             *   'deadline_label' => 'Deliver by 6:30 PM',
             *   'map_url'        => 'https://www.google.com/maps/...',
             *
             *   // Optional: scaffold-specific fields for richer UX
             *   'next_state'        => 'picked_up',          // next machine state
             *   'next_state_label'  => 'Start Trip',         // button label
             *   'requires_code'     => true,                 // ask for code before status change (usually for delivered)
             * ]
             */
            $jobs = apply_filters( 'caricove_logistics_scaffold_jobs', $empty_jobs, $courier_id );

           $active_jobs    = isset( $jobs['active'] )    && is_array( $jobs['active'] )    ? $jobs['active']    : array();
$handover_jobs  = isset( $jobs['handover'] )  && is_array( $jobs['handover'] )  ? $jobs['handover']  : array();
$completed_jobs = isset( $jobs['completed'] ) && is_array( $jobs['completed'] ) ? $jobs['completed'] : array();

            // If there is no engine yet, show a single demo card so you can check design.
            if ( empty( $active_jobs ) && empty( $completed_jobs ) ) {
                $active_jobs[] = array(
                    'id'             => 1001,
                    'label'          => 'Job #1001',
                    'state'          => 'assigned',
                    'state_label'    => 'Assigned',
                    'pay_label'      => '2,000',
                    'currency'       => 'GYD',
                    'pickup_title'   => 'Pickup',
                    'pickup_text'    => 'Caricove Hub, Water Street',
                    'pickup_city'    => 'Georgetown',
                    'pickup_name'    => 'Caricove Hub',
                    'pickup_phone'   => '+5920000000',
                    'dropoff_title'  => 'Dropoff',
                    'dropoff_text'   => 'Lot 17, Diamond Housing Scheme',
                    'dropoff_city'   => 'East Bank Demerara',
                    'dropoff_name'   => 'Sample Customer',
                    'dropoff_phone'  => '+5920000001',
                    'eta_label'      => 'ETA 30 mins',
                    'distance_label' => '5.4 km',
                    'deadline_label' => 'Deliver by 6:30 PM',
                    'map_url'        => 'https://www.google.com/maps',
                    'next_state'        => 'en_route',
                    'next_state_label'  => 'Start Trip',
                    'requires_code'     => false,
                );
            }

            // Balances: allow engine to feed them in; fallback to zeros.
            $balances_default = array(
                'available' => 0,
                'clearing'  => 0,
                'held'      => 0,
                'currency'  => 'GYD',
            );
            $balances = apply_filters( 'caricove_logistics_scaffold_balances', $balances_default, $courier_id );

            $available = isset( $balances['available'] ) ? floatval( $balances['available'] ) : 0;
            $clearing  = isset( $balances['clearing'] ) ? floatval( $balances['clearing'] ) : 0;
            $held      = isset( $balances['held'] ) ? floatval( $balances['held'] ) : 0;
            $cur       = isset( $balances['currency'] ) ? $balances['currency'] : 'GYD';

            $ajax_url     = admin_url( 'admin-ajax.php' );
$payout_nonce = wp_create_nonce( 'caricove_courier_payout' );
$start_nonce  = wp_create_nonce( 'caricove_courier_start_trip' );
            ob_start();

            $this->maybe_print_assets();
            ?>
            <div class="ccv-courier-shell ccv-courier-shell--desktop">
                <!-- Splash Screen -->
                <div id="ccv-courier-splash" class="ccv-splash">
                    <div class="ccv-splash-inner">
                        <div class="ccv-splash-ring">
                            <div class="ccv-splash-core"></div>
                        </div>
                        <div class="ccv-splash-title">Caricove Courier</div>
                        <div class="ccv-splash-sub">Preparing your workspace…</div>
                    </div>
                </div>

                <!-- Console -->
                <div class="ccv-console">
                    <!-- Header / Identity Row -->
                    <header class="ccv-console-header">
                        <div class="ccv-console-header-left">
                            <h1 class="ccv-console-title">Courier Command Center</h1>
                            <div class="ccv-console-name">
                                <span class="ccv-console-name-label">Welcome,</span>
                                <span class="ccv-console-name-value"><?php echo esc_html( $display_name ); ?></span>
                            </div>
               
                            <div class="ccv-console-meta"></div>
                        </div>

                        <div class="ccv-console-header-right">
                            <div class="ccv-balance-pills">
                                <div class="ccv-balance-pill ccv-balance-pill--green">
                                    <div class="ccv-balance-pill-label">Available</div>
                                    <div class="ccv-balance-pill-value">
                                        <span class="ccv-balance-currency"><?php echo esc_html( $cur ); ?></span>
                                        <span class="ccv-balance-amount" id="ccv-balance-available">
                                            <?php echo esc_html( number_format_i18n( $available, 2 ) ); ?>
                                        </span>
                                    </div>
                                </div>

                                <div class="ccv-balance-pill ccv-balance-pill--yellow">
                                    <div class="ccv-balance-pill-label">Clearing</div>
                                    <div class="ccv-balance-pill-value">
                                        <span class="ccv-balance-currency"><?php echo esc_html( $cur ); ?></span>
                                        <span class="ccv-balance-amount" id="ccv-balance-clearing">
                                            <?php echo esc_html( number_format_i18n( $clearing, 2 ) ); ?>
                                        </span>
                                    </div>
                                </div>
                                <div class="ccv-balance-pill ccv-balance-pill--red">
                                    <div class="ccv-balance-pill-label">Held</div>
                                    <div class="ccv-balance-pill-value">
                                        <span class="ccv-balance-currency"><?php echo esc_html( $cur ); ?></span>
                                        <span class="ccv-balance-amount" id="ccv-balance-held">
                                            <?php echo esc_html( number_format_i18n( $held, 2 ) ); ?>
                                        </span>
                                    </div>
                                </div>
                            </div>
            
                            <div class="ccv-payout-actions">
                                <button
                                    type="button"
                                    class="ccv-btn ccv-btn--primary"
                                    id="ccv-btn-payout-scheduled"
                                    data-payout-type="scheduled"
                                >
                                    Schedule Payout
                                </button>
                                <button
                                    type="button"
                                    class="ccv-btn ccv-btn--ghost"
                                    id="ccv-btn-payout-instant"
                                    data-payout-type="instant"
                                >
                                    Instant Payout
                                </button>
                            </div>
                        </div>
                    </header>
<div id="ccv-courier-js-meta"
     data-ajax-url="<?php echo esc_url( $ajax_url ); ?>"
     data-payout-nonce="<?php echo esc_attr( $payout_nonce ); ?>"
     data-start-nonce="<?php echo esc_attr( $start_nonce ); ?>"
     data-courier-id="<?php echo esc_attr( $courier_id ); ?>">
</div>
                    <!-- Hidden JS meta for AJAX -->
                   
                 
                                
                    <!-- Top console tabs (view modes) -->
                    <div class="ccv-console-tabs">
                        <button type="button" class="ccv-console-tab ccv-console-tab--active" data-view="today">
                            Today
                        </button>
                        <button type="button" class="ccv-console-tab" data-view="map">
                            Map
                        </button>
                        <button type="button" class="ccv-console-tab" data-view="earnings">
                            Earnings
                        </button>
                        <button type="button" class="ccv-console-tab" data-view="settings">
                            Settings
                        </button>
                    </div>
                    
  <div class="ccv-support-call-row">
    <a href="tel:+13474169427"
       class="ccv-call-btn ccv-call-btn--voice"
       aria-label="Call Caricove Support">📞</a>
    <a href="https://wa.me/13474169427"
       class="ccv-call-btn ccv-call-btn--wa"
       aria-label="WhatsApp Caricove Support"
       target="_blank" rel="noopener noreferrer">📞</a>
</div>



                   <!-- TODAY view -->
<div class="ccv-console-body" data-view="today">
    <div class="ccv-console-col ccv-console-col--left">
        <div class="ccv-list-header">
            <div class="ccv-list-header-title">Jobs</div>
            <div class="ccv-list-header-sub">
                Tap a job to see full route details, codes, and contacts.
            </div>
        </div>

        <!-- Active / Handover / History toggle (same pill style) -->
        <div class="ccv-list-toggle">
            <button
                type="button"
                class="ccv-list-toggle-btn ccv-list-toggle-btn--active"
                data-list-target="active"
            >
                Active
            </button>
            <button
                type="button"
                class="ccv-list-toggle-btn"
                data-list-target="handover"
            >
                Handover
            </button>
            <button
                type="button"
                class="ccv-list-toggle-btn"
                data-list-target="completed"
            >
                History
            </button>
        </div>

        <!-- Active jobs list (skinny cards) -->
        <div class="ccv-job-list ccv-job-list--active" id="ccv-job-list-active">
            <?php if ( ! empty( $active_jobs ) ) : ?>
                <?php foreach ( $active_jobs as $job ) : ?>
                    <?php echo $this->render_job_card( $job, 'active' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                <?php endforeach; ?>
            <?php else : ?>
                <div class="ccv-job-empty">
                    No active jobs right now. You’ll see them here as soon as they’re assigned.
                </div>
            <?php endif; ?>
        </div>

        <!-- Handover jobs: failed / special-pickup / escalated jobs linked to this courier -->
        <div class="ccv-job-list ccv-job-list--handover ccv-job-list--hidden" id="ccv-job-list-handover">
            <?php if ( ! empty( $handover_jobs ) ) : ?>
                <?php foreach ( $handover_jobs as $job ) : ?>
                    <?php echo $this->render_job_card( $job, 'handover' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                <?php endforeach; ?>
            <?php else : ?>
                <div class="ccv-job-empty">
                    Handover jobs and special pickups will appear here after a failed delivery or special handoff.
                </div>
            <?php endif; ?>
        </div>

        <!-- Completed jobs: only visible when History is selected -->
        <div class="ccv-job-list ccv-job-list--completed ccv-job-list--hidden" id="ccv-job-list-completed">
            <?php if ( ! empty( $completed_jobs ) ) : ?>
                <?php foreach ( $completed_jobs as $job ) : ?>
                    <?php echo $this->render_job_card( $job, 'completed' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                <?php endforeach; ?>
            <?php else : ?>
                <div class="ccv-job-empty">
                    Completed jobs will appear here after you finish them.
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="ccv-console-col ccv-console-col--right">
        <div class="ccv-detail-shell" id="ccv-job-detail-shell">
            <div class="ccv-detail-empty">
                Select a job on the left to see full route details, codes, and customer contacts.
            </div>
        </div>
    </div>
</div>
                    <!-- Map view (placeholder; engine can enhance) -->
                    <div class="ccv-console-body ccv-console-body--hidden" data-view="map">
                        <div class="ccv-console-col ccv-console-col--full">
                            <div class="ccv-map-placeholder">
                                Map view will show all today’s jobs with live status. Your engine module can inject an
                                actual map into <code>#ccv-map-canvas</code>.
                            </div>
                            <div id="ccv-map-canvas"></div>
                        </div>
                    </div>

                    <!-- Earnings view -->
                    <div class="ccv-console-body ccv-console-body--hidden" data-view="earnings">
                        <div class="ccv-console-col ccv-console-col--full">
                            <div class="ccv-earnings-header">
                                <h2>Earnings Overview</h2>
                               
                            </div>
                            <div class="ccv-earnings-grid">
                                <div class="ccv-earnings-card">
                                    <div class="ccv-earnings-label">Available for Cashout</div>
                                    <div class="ccv-earnings-value">
                                        <span class="ccv-balance-currency"><?php echo esc_html( $cur ); ?></span>
                                        <span class="ccv-earnings-amount" data-bind="available">
                                            <?php echo esc_html( number_format_i18n( $available, 2 ) ); ?>
                                        </span>
                                    </div>
                                </div>
                                <div class="ccv-earnings-card">
                                    <div class="ccv-earnings-label">In Clearing Window</div>
                                    <div class="ccv-earnings-value">
                                        <span class="ccv-balance-currency"><?php echo esc_html( $cur ); ?></span>
                                        <span class="ccv-earnings-amount" data-bind="clearing">
                                            <?php echo esc_html( number_format_i18n( $clearing, 2 ) ); ?>
                                        </span>
                                    </div>
                                </div>
                                <div class="ccv-earnings-card">
                                    <div class="ccv-earnings-label">Temporarily Held</div>
                                    <div class="ccv-earnings-value">
                                        <span class="ccv-balance-currency"><?php echo esc_html( $cur ); ?></span>
                                        <span class="ccv-earnings-amount" data-bind="held">
                                            <?php echo esc_html( number_format_i18n( $held, 2 ) ); ?>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class="ccv-earnings-footer">
                               
                            </div>
                        </div>
                    </div>

                    <!-- Settings view -->
                    <div class="ccv-console-body ccv-console-body--hidden" data-view="settings">
                        <div class="ccv-console-col ccv-console-col--full">
                            <div class="ccv-settings-panel">
                                <h2>Courier Settings</h2>
                                <p>
                                    Your logistics engine can attach real settings here (regions, schedules, payout
                                    preferences) without touching the shell design.
                                </p>
                                <?php
                                /**
                                 * Let engine modules inject additional controls, forms, or hints.
                                 */
                                do_action( 'caricove_logistics_scaffold_settings', $courier_id );
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
         
                <!-- Payout Modal -->
                <div class="ccv-modal-backdrop" id="ccv-payout-modal-backdrop" aria-hidden="true">
                    <div class="ccv-modal" role="dialog" aria-modal="true" aria-labelledby="ccv-payout-modal-title">
                        <div class="ccv-modal-header">
                            <h2 id="ccv-payout-modal-title">Request Payout</h2>
                            <button type="button" class="ccv-modal-close" id="ccv-payout-modal-close">&times;</button>
                        </div>
                        <div class="ccv-modal-body">
                            <div class="ccv-modal-row">
                                <label for="ccv-payout-amount" class="ccv-modal-label">
                                    Amount to cash out
                                </label>
                                <div class="ccv-modal-input-wrap">
                                    <span class="ccv-modal-currency"><?php echo esc_html( $cur ); ?></span>
                                    <input type="number"
                                           step="0.01"
                                           min="0"
                                           id="ccv-payout-amount"
                                           class="ccv-modal-input"
                                           placeholder="0.00" />
                                </div>
      
                                <div class="ccv-modal-helper">
                                    Available: <span id="ccv-payout-available-display">
                                        <?php echo esc_html( number_format_i18n( $available, 2 ) ); ?>
                                    </span> <?php echo esc_html( $cur ); ?>
                                </div>
                            </div>

                            <div class="ccv-modal-row">
                                <div class="ccv-modal-label">Payout type</div>
                                <div class="ccv-modal-pill-row">
                                    <button type="button"
                                            class="ccv-pill ccv-pill--active"
                                            data-payout-type="scheduled">
                                        Scheduled (no fee)
                                    </button>
                                    <button type="button"
                                            class="ccv-pill"
                                            data-payout-type="instant">
                                        Instant (small fee)
                                    </button>
                                </div>
                                <div class="ccv-modal-helper" id="ccv-modal-fee-note">
                                   
                                </div>
                            </div>

                            <div class="ccv-modal-row">
                                <div class="ccv-modal-status" id="ccv-payout-modal-status"></div>
                            </div>
                        </div>
                        <div class="ccv-modal-footer">
                            <button type="button"
                                    class="ccv-btn ccv-btn--ghost"
                                    id="ccv-payout-modal-cancel">
                                Cancel
                            </button>
                            <button type="button"
                                    class="ccv-btn ccv-btn--primary"
                                    id="ccv-payout-modal-submit">
                                Submit Request
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Job Code Modal (for status change when code is required) -->
                <div class="ccv-modal-backdrop" id="ccv-code-modal-backdrop" aria-hidden="true">
                    <div class="ccv-modal" role="dialog" aria-modal="true" aria-labelledby="ccv-code-modal-title">
                        <div class="ccv-modal-header">
                            <h2 id="ccv-code-modal-title">Enter Delivery Code</h2>
                            <button type="button" class="ccv-modal-close" id="ccv-code-modal-close">&times;</button>
                        </div>
                            <div class="ccv-modal-body">
                                <div class="ccv-modal-row">
                                    <label for="ccv-code-input" class="ccv-modal-label">
                                        Ask the customer for the delivery code and enter it below.
                                    </label>
                                    <div class="ccv-modal-input-wrap">
                                        <input type="text"
                                               id="ccv-code-input"
                                               class="ccv-modal-input"
                                               inputmode="numeric"
                                               autocomplete="one-time-code"
                                               placeholder="4–6 digit code" />
                                    </div>
                                    <div class="ccv-modal-helper">
                                        This confirms that the parcel reached the correct person.
                                    </div>
                                </div>
                                <div class="ccv-modal-row">
                                    <div class="ccv-modal-status" id="ccv-code-modal-status"></div>
                                </div>
                            </div>
                        <div class="ccv-modal-footer">
                            <button type="button"
                                    class="ccv-btn ccv-btn--ghost"
                                    id="ccv-code-modal-cancel">
                                Cancel
                            </button>
                            <button type="button"
                                    class="ccv-btn ccv-btn--primary"
                                    id="ccv-code-modal-submit">
                                Confirm Status
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Delivery Notes Modal -->
                <div class="ccv-modal-backdrop" id="ccv-notes-modal-backdrop" aria-hidden="true">
                    <div class="ccv-modal ccv-notes-modal" role="dialog" aria-modal="true" aria-labelledby="ccv-notes-modal-title">
                        <div class="ccv-modal-header">
                            <h2 id="ccv-notes-modal-title">Delivery Notes</h2>
                            <button type="button" class="ccv-modal-close ccv-notes-modal-close" id="ccv-notes-modal-close">&times;</button>
                        </div>
                        <div class="ccv-modal-body">
                            <div class="ccv-modal-row">
                                <div class="ccv-notes-panel" id="ccv-notes-modal-body">No delivery instructions provided.</div>
                            </div>
                        </div>
                       
                    </div>
                </div>
            </div>
            <?php

            return ob_get_clean();
        }

        /**
         * Render a single job card.
         *
         * Left cards are intentionally "skinny": just enough info to choose a job.
         * Rich details live in the right panel.
         *
         * @param array  $job
         * @param string $bucket 'active' or 'completed'
         * @return string
         */
  /**
 * Render a single job card.
 *
 * Left cards are intentionally "skinny": just enough info to choose a job.
 * Rich details live in the right panel.
 *
 * IMPORTANT: includes coords + phase so the Google Map overlay can draw balls,
 * and includes a countdown pill wired to data-deadline-ts.
 *
 * @param array  $job
 * @param string $bucket 'active' or 'completed'
 * @return string
 */
protected function render_job_card( $job, $bucket = 'active' ) {
    $id             = isset( $job['id'] ) ? $job['id'] : '';
    $label          = isset( $job['label'] ) ? $job['label'] : '';
    $state          = isset( $job['state'] ) ? $job['state'] : '';
    $state_label    = isset( $job['state_label'] ) ? $job['state_label'] : ( $state ? ucfirst( $state ) : '' );
    $pay_label      = isset( $job['pay_label'] ) ? $job['pay_label'] : '';
    $currency       = isset( $job['currency'] ) ? $job['currency'] : 'GYD';

    $pickup_title   = isset( $job['pickup_title'] ) ? $job['pickup_title'] : 'Pickup';
    $pickup_text    = isset( $job['pickup_text'] ) ? $job['pickup_text'] : '';
    $pickup_city    = isset( $job['pickup_city'] ) ? $job['pickup_city'] : '';
    $pickup_name    = isset( $job['pickup_name'] ) ? $job['pickup_name'] : '';
    $pickup_phone   = isset( $job['pickup_phone'] ) ? $job['pickup_phone'] : '';

    $dropoff_title  = isset( $job['dropoff_title'] ) ? $job['dropoff_title'] : 'Dropoff';
    $dropoff_text   = isset( $job['dropoff_text'] ) ? $job['dropoff_text'] : '';
    $dropoff_city   = isset( $job['dropoff_city'] ) ? $job['dropoff_city'] : '';
    $dropoff_name   = isset( $job['dropoff_name'] ) ? $job['dropoff_name'] : '';
    $dropoff_phone  = isset( $job['dropoff_phone'] ) ? $job['dropoff_phone'] : '';
    $dropoff_instructions = isset( $job['dropoff_instructions'] ) ? $job['dropoff_instructions'] : ( isset( $job['delivery_instructions'] ) ? $job['delivery_instructions'] : '' );

    $eta_label      = isset( $job['eta_label'] ) ? $job['eta_label'] : '';
    $distance_label = isset( $job['distance_label'] ) ? $job['distance_label'] : '';
    $deadline_label = isset( $job['deadline_label'] ) ? $job['deadline_label'] : '';
    $map_url        = isset( $job['map_url'] ) ? $job['map_url'] : '';

    // LEG phase + coords for map overlay
    $phase          = isset( $job['phase'] ) ? $job['phase'] : 'to_pickup';
    $pickup_lat     = isset( $job['pickup_lat'] ) ? $job['pickup_lat'] : '';
    $pickup_lng     = isset( $job['pickup_lng'] ) ? $job['pickup_lng'] : '';
    $dropoff_lat    = isset( $job['dropoff_lat'] ) ? $job['dropoff_lat'] : '';
    $dropoff_lng    = isset( $job['dropoff_lng'] ) ? $job['dropoff_lng'] : '';

    $mission_id     = isset( $job['mission_id'] ) ? $job['mission_id'] : '';
    $mission_seq    = isset( $job['mission_seq'] ) ? intval( $job['mission_seq'] ) : 0;

    // Deadline timestamp (seconds since epoch) — you’ll wire this from the bridge.
    $deadline_ts    = isset( $job['sla_deadline_ts'] ) ? intval( $job['sla_deadline_ts'] ) : 0;

    $next_state       = isset( $job['next_state'] ) ? $job['next_state'] : '';
    $next_state_label = isset( $job['next_state_label'] ) ? $job['next_state_label'] : '';
    $requires_code    = ! empty( $job['requires_code'] ) ? '1' : '0';

    // Route summary for the skinny row: city → city (fallback to text if no city).
    $from_area = $pickup_city ? $pickup_city : $pickup_text;
    $to_area   = $dropoff_city ? $dropoff_city : $dropoff_text;

    $route_summary = '';
    if ( $from_area && $to_area ) {
        $route_summary = $from_area . ' → ' . $to_area;
    } elseif ( $from_area ) {
        $route_summary = $from_area;
    } elseif ( $to_area ) {
        $route_summary = $to_area;
    }

    // Time chip – we’ll turn this into a live countdown pill if deadline_ts exists.
    $time_chip = $deadline_label ? $deadline_label : $eta_label;

    $bucket_class = ( 'completed' === $bucket ) ? 'ccv-job-card--completed' : 'ccv-job-card--active';

    ob_start();
    ?>
    <article class="ccv-job-card <?php echo esc_attr( $bucket_class ); ?>"
             data-job-id="<?php echo esc_attr( $id ); ?>"
             data-job-label="<?php echo esc_attr( $label ); ?>"
             data-job-state="<?php echo esc_attr( $state ); ?>"
             data-job-state-label="<?php echo esc_attr( $state_label ); ?>"
             data-job-pay="<?php echo esc_attr( $pay_label ); ?>"
             data-job-currency="<?php echo esc_attr( $currency ); ?>"

             data-pickup-title="<?php echo esc_attr( $pickup_title ); ?>"
             data-pickup-text="<?php echo esc_attr( $pickup_text ); ?>"
             data-pickup-city="<?php echo esc_attr( $pickup_city ); ?>"
             data-pickup-name="<?php echo esc_attr( $pickup_name ); ?>"
             data-pickup-phone="<?php echo esc_attr( $pickup_phone ); ?>"

             data-dropoff-title="<?php echo esc_attr( $dropoff_title ); ?>"
             data-dropoff-text="<?php echo esc_attr( $dropoff_text ); ?>"
             data-dropoff-city="<?php echo esc_attr( $dropoff_city ); ?>"
             data-dropoff-name="<?php echo esc_attr( $dropoff_name ); ?>"
             data-dropoff-phone="<?php echo esc_attr( $dropoff_phone ); ?>"
             data-dropoff-instructions="<?php echo esc_attr( $dropoff_instructions ); ?>"
             data-delivery-instructions="<?php echo esc_attr( $dropoff_instructions ); ?>"

             data-eta-label="<?php echo esc_attr( $eta_label ); ?>"
             data-distance-label="<?php echo esc_attr( $distance_label ); ?>"
             data-deadline-label="<?php echo esc_attr( $deadline_label ); ?>"
             data-deadline-ts="<?php echo esc_attr( $deadline_ts ); ?>"

             data-map-url="<?php echo esc_url( $map_url ); ?>"

             data-next-state="<?php echo esc_attr( $next_state ); ?>"
             data-next-state-label="<?php echo esc_attr( $next_state_label ); ?>"
             data-requires-code="<?php echo esc_attr( $requires_code ); ?>"

             data-phase="<?php echo esc_attr( $phase ); ?>"
             data-pickup-lat="<?php echo esc_attr( $pickup_lat ); ?>"
             data-pickup-lng="<?php echo esc_attr( $pickup_lng ); ?>"
             data-dropoff-lat="<?php echo esc_attr( $dropoff_lat ); ?>"
             data-dropoff-lng="<?php echo esc_attr( $dropoff_lng ); ?>"

             data-mission-id="<?php echo esc_attr( $mission_id ); ?>"
             data-mission-seq="<?php echo esc_attr( $mission_seq ); ?>">

        <div class="ccv-job-card-row ccv-job-card-row--thin-top">
            <div class="ccv-job-card-label"><?php echo esc_html( $label ); ?></div>
            <?php if ( $state_label ) : ?>
                <div class="ccv-job-card-state"><?php echo esc_html( $state_label ); ?></div>
            <?php endif; ?>
        </div>

        <div class="ccv-job-card-row ccv-job-card-row--thin-middle">
            <?php if ( $route_summary ) : ?>
                <div class="ccv-job-card-route">
                    <?php echo esc_html( $route_summary ); ?>
                </div>
            <?php endif; ?>
        </div>

        <div class="ccv-job-card-row ccv-job-card-row--thin-bottom">
            <div class="ccv-job-card-meta">
                <?php if ( $time_chip ) : ?>
                    <!-- Countdown pill – JS will override this text if deadline_ts is set -->
                    <span class="ccv-job-pill ccv-job-pill--time">
                        <?php echo esc_html( $time_chip ); ?>
                    </span>
                <?php endif; ?>

                <?php if ( $distance_label ) : ?>
                    <!-- Distance pill – dynamic from bridge/heartbeat -->
                    <span class="ccv-job-pill ccv-job-pill--distance">
                        <?php echo esc_html( $distance_label ); ?>
                    </span>
                <?php endif; ?>
            </div>
            <div class="ccv-job-card-pay">
                <span class="ccv-job-pay-currency"><?php echo esc_html( $currency ); ?></span>
                <span class="ccv-job-pay-amount"><?php echo esc_html( $pay_label ); ?></span>
            </div>
        </div>
    </article>
    <?php

    return ob_get_clean();
}
        
        /**
         * Print inline CSS/JS once per page.
         */
        protected function maybe_print_assets() {
            if ( $this->assets_printed ) {
                return;
            }

            $this->assets_printed = true;
            ?>
            <style>
          /* Push down left-side job list */
#ccv-job-list-active {
    margin-top: 15px !important;   /* Adjust this number */
}
    /* Row positioning under the payout buttons */
.ccv-console .ccv-support-call-row {
    display: flex;
    justify-content: flex-end;
    align-items: center;
    gap: 10px;
    margin-top: 10px;
}


.ccv-pay-gold {
    background: linear-gradient(135deg, #f5d57a, #dbb14e);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    font-weight: 700;
    font-size: 15px;
    letter-spacing: 0.5px;
}
.ccv-addr-name {
    font-size: 16px !important;
    font-weight: 600;
    margin-bottom: 2px;
}
.ccv-addr-street {
    font-size: 14px !important;
    opacity: 0.9;
    margin-bottom: 1px;
}
.ccv-addr-city {
    font-size: 13px !important;
    opacity: 0.8;
    margin-bottom: 4px;
}




/* ===== CARICOVE OVERRIDES: HEADER, PICKUP/DROPOFF, DELIVER-BY, BUTTON GAP ===== */

/* --- Detail header: Shipment + Pay --- */
.ccv-detail-title {
    font-size: 13px;                 /* a bit smaller, more refined */
    font-weight: 500;
    letter-spacing: 0.09em;
    text-transform: uppercase;
    color: #e6efff;
    opacity: 0.9;
}

.ccv-detail-payline {
    font-size: 18px;                 /* bigger and richer */
    font-weight: 700;
    letter-spacing: 0.03em;
    margin-top: 4px;
    color: #ffd34e;                  /* warm gold */
   
}

/* --- Pickup / Dropoff cards (right panel) --- */
/* Name (vendor / customer) */
.ccv-detail-name {
    font-size: 15px;
    margin-bottom: 2px;
}

/* Street address */
.ccv-detail-address {
    font-size: 13px;
    font-weight: 100;
    margin-bottom: 1px;
}

/* City / area */
.ccv-detail-city {
    font-size: 13px;
    opacity: 0.86;
}

/* Make the small “PICKUP / DROPOFF” labels a touch stronger */
.ccv-detail-label {
    font-size: 11px;
    font-weight: 600;
    letter-spacing: 0.09em;
    text-transform: uppercase;
    opacity: 0.82;
}

/* --- Deliver-by pill (right panel, under the two cards) --- */
/* The pill itself – static time, no countdown here */
.ccv-detail-deadline-pill {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 4px 14px;
    border-radius: 999px;
    border: 1px solid rgba(140, 190, 255, 0.9);
    background: radial-gradient(circle at top,
        rgba(18, 60, 130, 0.95),
        rgba(4, 16, 40, 0.98)
    );
    font-size: 11px;
    font-weight: 600;
    letter-spacing: 0.08em;
    color: #eaf4ff;
    text-shadow:
        0 0 4px rgba(120, 190, 255, 0.7),
        0 0 10px rgba(0, 0, 0, 0.9);
    white-space: nowrap;
    margin-bottom:px;
    margin-top:20px;
}

/* Hide any old “ETA / distance” lines the detail block might output */
.ccv-detail-codes div {
    display: none;
}
.ccv-detail-codes .ccv-detail-deadline-pill {
    display: inline-flex;
}

/* --- Spacing between Deliver-by and the big blue action button --- */
/* First actions row (Deliver-by + Open in Maps) stays tight */
.ccv-detail-actions {
    align-items: center;
}

/* Second actions row (the big Start/Confirm/Complete button) gets extra gap */
.ccv-detail-actions + .ccv-detail-actions {
    margin-top: 18px;    /* ← this is the breathing room you wanted */
}

/* Make sure the primary button itself feels solid, not cramped */
.ccv-detail-actions + .ccv-detail-actions .ccv-btn--primary {
    min-height: 38px;
    font-weight: 600;
    min-width:600px;
    margin-left:30px;
}

/* --- (Optional) subtle tweak: keep left-column job pills looking consistent --- */
.ccv-job-pill--time,
.ccv-job-pill--distance {
    border-radius: 999px;
    padding: 2px 8px;
}







/* Glow on hover – same Caricove shimmer vibe */
.ccv-console .ccv-support-btn:hover {
    box-shadow: 0 0 12px rgba(0, 255, 255, 0.85);
    transform: translateY(-1px);
    opacity: 0.96;
}
           .ccv-modal .ccv-modal-close:hover,
.ccv-modal .ccv-close:hover,
.ccv-modal .ccv-close-btn:hover {
    background: #e6e6e6 !important; /* softer white */
    box-shadow: 0 0 6px rgba(255,255,255,0.45),
                0 0 12px rgba(255,255,255,0.25) !important;
}
/* ===== Courier console: support call icons under payout buttons ===== */

.ccv-courier-shell .ccv-support-call-row {
    display: flex;
    justify-content: flex-end;
    align-items: center;
    gap: 10px;
    margin-top: 10px;
}

.ccv-courier-shell .ccv-support-call-row .ccv-support-btn {
    width: 30px;
    height: 30px;
    border-radius: 999px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border: 1px solid rgba(140, 190, 255, 0.7);
    background: radial-gradient(circle at top, rgba(4, 28, 80, 0.95), rgba(1, 4, 12, 0.98));
    box-shadow: 0 0 12px rgba(0, 150, 255, 0.45);
    cursor: pointer;
    text-decoration: none;
}

/* white normal phone */
.ccv-courier-shell .ccv-support-btn--voice {
    color: #f5f7ff;
}

/* WhatsApp green */
.ccv-courier-shell .ccv-support-btn--wa {
    color: #00e676;
}

/* hover glow */
.ccv-courier-shell .ccv-support-btn:hover {
    box-shadow:
        0 0 16px rgba(0, 200, 255, 0.9),
        0 0 32px rgba(0, 0, 0, 1);
    transform: translateY(-1px);
}
/* ----------------------------------------
   Caricove Courier Tabs – Soft Gold Hover
   ---------------------------------------- */
.ccv-console-tabs .ccv-console-tab:hover:not(.ccv-console-tab--active) {
    background: linear-gradient(135deg, #e7c36a, #d6aa4a) !important;
    color: #111 !important;
    border-color: rgba(231,195,106,0.45) !important;
    box-shadow:
        0 0 8px rgba(231,195,106,0.55),
        0 0 16px rgba(231,195,106,0.35) !important;
}

/* optional: active tab stays blue, no gold */
.ccv-console-tabs .ccv-console-tab--active:hover {
    background: #1e90ff !important; /* Caricove blue */
    box-shadow: 0 0 15px rgba(30,144,255,0.55) !important;
}
/* Tight but slightly spaced layout */
.ccv-console-name {
    display: flex !important;
    align-items: center !important;
    gap: 5px !important; /* slightly more space than last time */
}

/* "Welcome," label */
.ccv-console-name-label {
    font-size: 1.05rem !important;
    font-weight: 300 !important;
    color: #d8e6ff !important;
    letter-spacing: 0.2px !important;
    opacity: 0.9 !important;
    text-shadow:
        0 0 4px rgba(120, 180, 255, 0.35),
        0 0 8px rgba(120, 180, 255, 0.25) !important;
    margin: 0 !important;
    padding: 0 !important;
}

/* Username — slightly smaller and tighter glow */
.ccv-console-name-value {
    font-size: 1.0rem !important; /* one step smaller */
    font-weight: 500 !important;
    color: #6cd5ff !important;
    text-shadow:
        0 0 5px rgba(90, 200, 255, 0.55),
        0 0 10px rgba(90, 200, 255, 0.28) !important;
    margin: 0 !important;
    padding: 0 !important;
}
/* ----------------------------------------------------------
   Caricove Courier: Icy Grey Hover for List Toggle Buttons
   ---------------------------------------------------------- */
.ccv-list-toggle .ccv-list-toggle-btn:hover:not(.ccv-list-toggle-btn--active) {
    background: linear-gradient(135deg, #d9d9e1, #bfc4cc) !important; /* icy grey gradient */
    color: #111 !important;
    border-color: rgba(255, 255, 255, 0.25) !important;
    box-shadow:
        0 0 8px rgba(200, 210, 220, 0.45),
        0 0 14px rgba(200, 210, 220, 0.25) !important;
}

/* keep active blue, no icy grey hover on active */
.ccv-list-toggle .ccv-list-toggle-btn--active:hover {
    background: #1e90ff !important;
    color: #fff !important;
    box-shadow: 0 0 12px rgba(30,144,255,0.45) !important;
}
            .ccv-detail-call-row {
    display: flex;
    align-items: center;
    gap: 6px;
    margin-top: 4px;
    font-size: 11px;
    white-space: nowrap;
}

.ccv-detail-contact-name {
    opacity: 0.9;
    overflow: hidden;
    text-overflow: ellipsis;
}

.ccv-detail-call-actions {
    display: flex;
    gap: 4px;
    margin-left: auto;      /* pushes icons to the right side */
    flex-shrink: 0;
}

.ccv-call-btn {
    width: 22px;
    height: 22px;
    border-radius: 999px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 12px;
    text-decoration: none;
    border: 1px solid rgba(140, 190, 255, 0.7);
    background: rgba(3, 15, 38, 0.96);
    color: #0b1630;
    box-shadow: 0 0 10px rgba(0, 150, 255, 0.6);
    transition: transform 0.12s ease-out, box-shadow 0.12s ease-out, background 0.12s ease-out;
}

.ccv-call-btn--voice {
    background: #ffffff;    /* white phone = normal call */
    color: #0b1630;
}

.ccv-call-btn--wa {
    background: #00d46a;    /* green phone = WhatsApp */
    color: #ffffff;
    box-shadow: 0 0 14px rgba(0, 220, 120, 0.8);
}

.ccv-call-btn:hover {
    transform: translateY(-1px);
    box-shadow: 0 0 16px rgba(0, 200, 255, 0.9);
}
                .ccv-courier-shell {
                    position: relative;
                    font-family: system-ui, -apple-system, BlinkMacSystemFont, "SF Pro Text", "Segoe UI", sans-serif;
                    color: #f5f7ff;
                }
                .ccv-courier-shell--desktop {
                    background: radial-gradient(circle at top, #182b4d 0, #050814 55%, #010208 100%);
                    border-radius: 24px;
                    padding: 24px;
                    box-shadow: 0 0 40px rgba(0, 0, 0, 0.7);
                    overflow: hidden;
                }
                .ccv-courier-shell--restricted {
                    background: #050814;
                    padding: 32px;
                    border-radius: 16px;
                    text-align: center;
                    color: #f5f7ff;
                    border: 1px solid rgba(102, 153, 255, 0.4);
                }

                /* Splash */
                .ccv-splash {
                    position: absolute;
                    inset: 0;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    background: radial-gradient(circle at top, #0d1b3f 0, #02020a 60%, #000 100%);
                    z-index: 20;
                }
                .ccv-splash-inner {
                    text-align: center;
                    animation: ccvFadeUp 0.9s ease-out;
                }
                .ccv-splash-ring {
                    width: 120px;
                    height: 120px;
                    border-radius: 50%;
                    border: 2px solid rgba(80, 160, 255, 0.3);
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    margin: 0 auto 16px;
                    box-shadow: 0 0 40px rgba(0, 180, 255, 0.2);
                    position: relative;
                }
                .ccv-splash-ring::after {
                    content: "";
                    position: absolute;
                    inset: 12px;
                    border-radius: 50%;
                    border: 2px dashed rgba(0, 200, 255, 0.4);
                    animation: ccvSpin 9s linear infinite;
                }
                .ccv-splash-core {
                    width: 54px;
                    height: 54px;
                    border-radius: 50%;
                    background: conic-gradient(from 210deg, #00f0ff, #1e90ff, #6b5bff, #00f0ff);
                    box-shadow:
                        0 0 20px rgba(0, 240, 255, 0.8),
                        0 0 52px rgba(0, 160, 255, 0.52);
                    animation: ccvPulse 2.4s ease-in-out infinite;
                }
                .ccv-splash-title {
                    font-size: 20px;
                    font-weight: 600;
                    letter-spacing: 0.06em;
                    text-transform: uppercase;
                    margin-bottom: 8px;
                }
                .ccv-splash-sub {
                    font-size: 13px;
                    opacity: 0.7;
                }

                /* Console */
                .ccv-console {
                    position: relative;
                    opacity: 0;
                    transform: translateY(12px);
                    transition: opacity 0.45s ease-out, transform 0.45s ease-out;
                    display: flex;
                    flex-direction: column;
                    gap: 16px;
                }
                .ccv-console-header {
                    display: flex;
                    justify-content: space-between;
                    gap: 24px;
                    align-items: flex-start;
                }
                .ccv-console-header-left {
                    max-width: 50%;
                }
                .ccv-console-title {
                    font-size: 22px;
                    margin: 0 0 4px;
                }
                .ccv-console-name {
                    font-size: 14px;
                    color: rgba(232, 240, 255, 0.9);
                    margin-bottom: 6px;
                }
                .ccv-console-name-label {
                    opacity: 0.7;
                    margin-right: 4px;
                }
                .ccv-console-name-value {
                    font-weight: 600;
                }
                .ccv-console-meta {
                    display: flex;
                    flex-wrap: wrap;
                    gap: 8px;
                }
                .ccv-console-chip {
                    display: inline-flex;
                    align-items: center;
                    gap: 6px;
                    padding: 3px 10px;
                    border-radius: 999px;
                    background: linear-gradient(135deg, rgba(9, 84, 180, 0.8), rgba(1, 24, 62, 0.9));
                    border: 1px solid rgba(100, 185, 255, 0.5);
                    font-size: 11px;
                    text-transform: uppercase;
                    letter-spacing: 0.08em;
                }
                .ccv-console-chip-label {
                    opacity: 0.75;
                }
                .ccv-console-chip-value {
                    font-weight: 600;
                }

                .ccv-console-header-right {
                    flex: 1;
                    display: flex;
                    flex-direction: column;
                    gap: 8px;
                    align-items: flex-end;
                }
                .ccv-balance-pills {
                    display: flex;
                    gap: 8px;
                }
                .ccv-balance-pill {
                    min-width: 130px;
                    padding: 8px 12px;
                    border-radius: 14px;
                    background: rgba(4, 14, 40, 0.9);
                    border: 1px solid rgba(120, 180, 255, 0.45);
                    box-shadow: 0 0 20px rgba(0, 120, 255, 0.2);
                }
                .ccv-balance-pill--green {
                    border-color: rgba(0, 255, 170, 0.5);
                }
                .ccv-balance-pill--yellow {
                    border-color: rgba(255, 210, 85, 0.5);
                }
                .ccv-balance-pill--red {
                    border-color: rgba(255, 80, 100, 0.65);
                }
                .ccv-balance-pill-label {
                    font-size: 11px;
                    opacity: 0.75;
                    text-transform: uppercase;
                    letter-spacing: 0.08em;
                    margin-bottom: 3px;
                }
                .ccv-balance-pill-value {
                    font-size: 15px;
                    font-weight: 600;
                }
                .ccv-balance-currency {
                    opacity: 0.85;
                    margin-right: 4px;
                }

                .ccv-payout-actions {
                    display: flex;
                    gap: 8px;
                }
                .ccv-btn {
                    border-radius: 999px;
                    padding: 7px 14px;
                    font-size: 12px;
                    border: none;
                    cursor: pointer;
                    white-space: nowrap;
                    transition: transform 0.12s ease-out, box-shadow 0.12s ease-out, background 0.12s ease-out;
                }
                .ccv-btn--primary {
                    background: linear-gradient(135deg, #23b1ff, #007bff);
                    color: #010208;
                    box-shadow:
                        0 0 18px rgba(0, 160, 255, 0.55),
                        0 0 40px rgba(0, 90, 210, 0.6);
                }
                .ccv-btn--primary:hover {
                    transform: translateY(-1px);
                    box-shadow:
                        0 0 22px rgba(0, 190, 255, 0.9),
                        0 0 52px rgba(0, 110, 255, 0.7);
                }
                .ccv-btn--ghost {
                    background: transparent;
                    border: 1px solid rgba(120, 185, 255, 0.7);
                    color: #e7f0ff;
                }
                .ccv-btn--ghost:hover {
                    background: rgba(13, 56, 122, 0.85);
                    box-shadow: 0 0 18px rgba(0, 145, 255, 0.4);
                    transform: translateY(-1px);
                }

                /* Tabs */
                .ccv-console-tabs {
                    display: inline-flex;
                    gap: 6px;
                    padding: 4px;
                    border-radius: 999px;
                    background: radial-gradient(circle at top left, rgba(23, 80, 180, 0.7), rgba(2, 8, 30, 0.95));
                    border: 1px solid rgba(100, 175, 255, 0.65);
                    width: fit-content;
                }
                .ccv-console-tab {
                    border-radius: 999px;
                    padding: 5px 12px;
                    border: none;
                    font-size: 11px;
                    text-transform: uppercase;
                    letter-spacing: 0.09em;
                    color: rgba(220, 233, 255, 0.85);
                    cursor: pointer;
                    background: transparent;
                }.ccv-console-tab--active {
                    background: linear-gradient(135deg, #23b1ff, #0067ff);
                    color: #020109;
                    box-shadow: 0 0 16px rgba(0, 150, 255, 0.8);
                }

                /* Bodies */
                .ccv-console-body {
                    display: grid;
                    grid-template-columns: 0.9fr 1.1fr;
                    gap: 18px;
                    margin-top: 12px;
                }
                .ccv-console-body--hidden {
                    display: none;
                }
                .ccv-console-col {
                    background: radial-gradient(circle at top left, rgba(8, 32, 80, 0.95), rgba(3, 8, 24, 0.98));
                    border-radius: 18px;
                    padding: 14px;
                    border: 1px solid rgba(90, 150, 255, 0.4);
                    box-shadow: 0 0 22px rgba(0, 0, 0, 0.6);
                }
                .ccv-console-col--full {
                    grid-column: 1 / -1;
                }

                /* Lists */
                .ccv-list-header {
                    display: flex;
                    flex-direction: column;
                    gap: 2px;
                    margin-bottom: 8px;
                }
                .ccv-list-header-title {
                    font-size: 13px;
                    text-transform: uppercase;
                    letter-spacing: 0.12em;
                    opacity: 0.86;
                }
                .ccv-list-header-sub {
                    font-size: 12px;
                    opacity: 0.7;
                }

                .ccv-list-toggle {
                    display: inline-flex;
                    padding: 2px;
                    border-radius: 999px;
                    background: radial-gradient(circle at top left, rgba(17, 60, 150, 0.8), rgba(3, 10, 30, 0.95));
                    border: 1px solid rgba(110, 180, 255, 0.6);
                    margin-bottom: 8px;
                }
                .ccv-list-toggle-btn {
                    border-radius: 999px;
                    padding: 4px 10px;
                    border: none;
                    font-size: 11px;
                    text-transform: uppercase;
                    letter-spacing: 0.09em;
                    color: rgba(220, 232, 255, 0.9);
                    background: transparent;
                    cursor: pointer;
                }
                .ccv-list-toggle-btn--active {
                    background: linear-gradient(135deg, #23b1ff, #0067ff);
                    color: #010208;
                    box-shadow: 0 0 14px rgba(0, 150, 255, 0.8);
                }

                .ccv-job-list {
                    display: flex;
                    flex-direction: column;
                    gap: 6px;
                    max-height:420px;
                    overflow-y: auto;
                    padding-right: 4px;
                }
                .ccv-job-list--hidden {
                    display: none;
                }
                .ccv-job-empty {
                    font-size: 12px;
                    opacity: 0.7;
                    padding: 10px 12px;
                    border-radius: 12px;
                    background: rgba(4, 18, 52, 0.7);
                }

              /* ==== JOB CARDS (LEFT COLUMN) =================================== */

.ccv-job-card {
    border-radius: 12px;
    padding: 7px 9px;
    background: radial-gradient(circle at top, rgba(12, 52, 125, 0.9), rgba(3, 10, 32, 0.98));
    border: 1px solid rgba(80, 150, 255, 0.7);
    cursor: pointer;
    transition: transform 0.12s ease-out, box-shadow 0.12s ease-out, border-color 0.12s ease-out;
    box-shadow:
        0 0 14px rgba(0, 120, 255, 0.35),
        0 0 32px rgba(0, 0, 0, 0.85);
}

.ccv-job-card--completed {
    opacity: 0.85;
    border-style: dashed;
    border-color: rgba(130, 190, 255, 0.45);
    background: radial-gradient(circle at top, rgba(8, 42, 90, 0.9), rgba(1, 6, 18, 0.95));
}

.ccv-job-card:hover {
    transform: translateY(-1px);
    box-shadow:
        0 0 16px rgba(0, 180, 255, 0.75),
        0 0 40px rgba(0, 0, 0, 1);
    border-color: rgba(130, 200, 255, 0.9);
}

/* Row structure inside each card */
.ccv-job-card-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 8px;
}
.ccv-job-card-row--thin-top {
    margin-bottom: 2px;
}
.ccv-job-card-row--thin-middle {
    margin-bottom: 3px;
}

/* "Shipment #15002" */
.ccv-job-card-label {
    font-weight: 600;
    font-size: 13px;
}

/* Right chip: Assigned / On the way / Delivered */
.ccv-job-card-state {
    font-size: 10px;
    text-transform: uppercase;
    letter-spacing: 0.09em;
    padding: 2px 7px;
    border-radius: 999px;
    background: rgba(4, 210, 135, 0.1);
    border: 1px solid rgba(4, 210, 135, 0.5);
    white-space: nowrap;
}

/* Route line: "Georgetown → Turkeyen" */
.ccv-job-card-route {
    font-size: 12px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    opacity: 0.9;
}

/* ETA / distance pill row (bottom-left) */
.ccv-job-card-meta {
    display: flex;
    flex-wrap: wrap;
    gap: 4px;
}

/* Countdown + distance pills (left side) – KEEPING both here */
.ccv-job-pill {
    font-size: 10px;
    text-transform: uppercase;
    letter-spacing: 0.09em;
    padding: 2px 6px;
    border-radius: 999px;
    background: rgba(0, 0, 0, 0.3);
    border: 1px solid rgba(140, 190, 255, 0.5);
}

/* Pay block bottom-right */
.ccv-job-card-pay {
    font-size: 13px;
    font-weight: 600;
    white-space: nowrap;
}
.ccv-job-pay-currency {
    opacity: 0.78;
    margin-right: 4px;
}

.ccv-job-card--selected,
.ccv-job-card.is-active {
    border-color: rgba(120, 190, 255, 0.85) !important;
    box-shadow: 0 0 0 1px rgba(120, 190, 255, 0.35), 0 14px 34px rgba(0, 0, 0, 0.34);
}

.ccv-job-pill--time {
    transition: opacity 280ms ease, transform 280ms ease, background 280ms ease, color 280ms ease, border-color 280ms ease, box-shadow 280ms ease;
}

.ccv-job-pill--time.is-switching {
    opacity: 0.78;
    transform: translateY(-1px);
}


/* ==== DETAIL PANEL (RIGHT COLUMN) =============================== */

.ccv-detail-shell {
    min-height: 230px;
}
.ccv-detail-empty {
    font-size: 12px;
    opacity: 0.7;
    padding: 12px;
    border-radius: 12px;
    background: rgba(4, 18, 52, 0.7);
    border: 1px solid rgba(70, 135, 230, 0.5);
}
.ccv-detail {
    display: flex;
    flex-direction: column;
    gap: 10px;
}

/* Header: shipment + pay + state tag */
.ccv-detail-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 8px;
}
.ccv-detail-title-group {
    display: flex;
    flex-direction: column;
    gap: 2px;
}

/* "Shipment #15002" */
.ccv-detail-title {
    font-size: 14px;
    font-weight: 600;
}

/* Pay line – slightly larger, more prominent */
.ccv-detail-payline {
    font-size: 14px;
    font-weight: 600;
    margin-top: 2px;
}

/* Status chip on the right */
.ccv-detail-state-tag {
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.09em;
    padding: 3px 8px;
    border-radius: 999px;
    border: 1px solid rgba(130, 190, 255, 0.75);
    background: rgba(1, 6, 18, 0.9);
    white-space: nowrap;
}

/* Two-column layout for Pickup / Dropoff cards */
.ccv-detail-grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 10px;
}
.ccv-detail-card {
    border-radius: 12px;
    padding: 10px;
    background: rgba(3, 12, 35, 0.96);
    border: 1px solid rgba(80, 150, 255, 0.5);
}

/* "PICKUP" / "DROPOFF" labels */
.ccv-detail-label {
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    opacity: 0.78;
    margin-bottom: 3px;
}

/* First line under label – treat as “name / street” and bump 1px */
.ccv-detail-main {
    font-size: 14px;
    font-weight: 600;
    margin-bottom: 2px;
}

/* Second line – city + name combo (existing meta text) */
.ccv-detail-meta {
    font-size: 13px;
    opacity: 0.85;
}

/* Bottom bar: Deliver-by pill (left) + Open in Maps (right) */
.ccv-detail-actions {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 6px;
    gap: 8px;
}

/* We’re only keeping Deliver-by here.
   Hide ETA + distance lines if they’re still rendered. */
.ccv-detail-codes div {
    display: none;           /* hide all by default */
}

/* Last div in .ccv-detail-codes = "Deliver by HH:MM" */
.ccv-detail-codes div:last-child {
    display: inline-block;
    padding: 4px 10px;
    border-radius: 999px;
    border: 1px solid rgba(130, 190, 255, 0.85);
    font-size: 11px;
    font-weight: 600;
}

/* "Open in Maps" link on the right */
.ccv-detail-map-link {
    display: flex;
    align-items: center;
    justify-content: flex-end;
    gap: 10px;
    flex-wrap: wrap;
}

.ccv-detail-map-link a {
    font-size: 11px;
    text-decoration: none;
    color: #88c8ff;
    border-bottom: 1px dashed rgba(130, 200, 255, 0.7);
}

.ccv-notes-trigger {
    width: 34px;
    height: 34px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    flex: 0 0 auto;
    position: relative;
    z-index: 3;
    border-radius: 10px;
    border: 1px solid rgba(181, 134, 79, 0.95);
    background: linear-gradient(135deg, rgba(121, 79, 37, 0.96), rgba(168, 119, 68, 0.96));
    color: #120b03;
    box-shadow: 0 8px 18px rgba(0,0,0,0.35);
    cursor: pointer;
    padding: 0;
    appearance: none;
    -webkit-appearance: none;
}
.ccv-notes-trigger:hover,
.ccv-notes-trigger:focus {
    outline: none;
    transform: translateY(-1px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.42), 0 0 0 1px rgba(230, 194, 140, 0.55);
}

.ccv-notes-trigger svg {
    width: 17px;
    height: 17px;
    display: block;
    fill: currentColor;
}


.ccv-notes-trigger svg,
.ccv-notes-trigger svg * {
    pointer-events: none;
}
.ccv-notes-modal {
    max-width: 560px;
}

.ccv-notes-panel {
    width: 100%;
    min-height: 170px;
    border-radius: 14px;
    border: 1px solid rgba(116, 80, 41, 0.95);
    background: linear-gradient(180deg, rgba(201, 164, 116, 0.98), rgba(165, 125, 81, 0.98));
    color: #110a04;
    padding: 16px 18px;
    white-space: pre-wrap;
    word-break: break-word;
    line-height: 1.55;
    font-size: 14px;
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.25), 0 10px 20px rgba(0,0,0,0.22);
}

                /* Map / earnings / settings placeholders */
               #ccv-map-canvas {
    margin-top: 10px;
    width: 100%;
    height: 75vh;
    min-height: 560px;
    border-radius: 16px;
    overflow: hidden;
    border: 1px solid rgba(100, 160, 255, 0.6);
    background: radial-gradient(circle at top, rgba(6, 40, 100, 0.9), rgba(1, 4, 12, 0.98));
}
                .ccv-map-placeholder {
                    font-size: 12px;
                    opacity: 0.7;
                    margin-bottom: 8px;
                }

                .ccv-earnings-header h2 {
                    margin: 0 0 6px;
                    font-size: 16px;
                }
                .ccv-earnings-header p {
                    margin: 0 0 10px;
                    font-size: 12px;
                    opacity: 0.75;
                }
                .ccv-earnings-grid {
                    display: grid;
                    grid-template-columns: repeat(3, minmax(0, 1fr));
                    gap: 10px;
                    margin-bottom: 10px;
                }
                .ccv-earnings-card {
                    border-radius: 14px;
                    padding: 10px;
                    background: rgba(3, 15, 38, 0.96);
                    border: 1px solid rgba(80, 145, 255, 0.55);
                }
                .ccv-earnings-label {
                    font-size: 11px;
                    text-transform: uppercase;
                    letter-spacing: 0.08em;
                    opacity: 0.8;
                    margin-bottom: 3px;
                }
                .ccv-earnings-value {
                    font-size: 15px;
                    font-weight: 600;
                }
                .ccv-earnings-footer p {
                    margin: 0;
                    font-size: 11px;
                    opacity: 0.75;
                }

                .ccv-settings-panel h2 {
                    margin: 0 0 6px;
                    font-size: 16px;
                }
                .ccv-settings-panel p {
                    margin: 0 0 10px;
                    font-size: 12px;
                    opacity: 0.78;
                }

                /* Modal */
                .ccv-modal-backdrop {
                    position: fixed;
                    inset: 0;
                    background: radial-gradient(circle at top, rgba(8, 28, 80, 0.9), rgba(0, 0, 0, 0.94));
                    display: none;
                    align-items: center;
                    justify-content: center;
                    z-index: 9999;
                }
                .ccv-modal-backdrop--show {
                    display: flex;
                }
                .ccv-modal {
                    width: 360px;
                    max-width: 96%;
                    background: radial-gradient(circle at top left, #0b1b3f, #050814);
                    border-radius: 18px;
                    border: 1px solid rgba(120, 190, 255, 0.7);
                    box-shadow:
                        0 0 30px rgba(0, 170, 255, 0.35),
                        0 0 70px rgba(0, 0, 0, 0.9);
                    padding: 14px 14px 12px;
                }
                .ccv-modal-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    margin-bottom: 6px;
                }
                .ccv-modal-header h2 {
                    margin: 0;
                    font-size: 15px;
                }
                .ccv-modal-close {
                    border: none;
                    background: transparent;
                    color: #f5f7ff;
                    font-size: 20px;
                    line-height: 1;
                    cursor: pointer;
                }
                .ccv-modal-body {
                    display: flex;
                    flex-direction: column;
                    gap: 10px;
                    margin: 4px 0 8px;
                }
                .ccv-modal-row {
                    display: flex;
                    flex-direction: column;
                    gap: 4px;
                }
                .ccv-modal-label {
                    font-size: 12px;
                    opacity: 0.78;
                }
                .ccv-modal-input-wrap {
                    display: flex;
                    align-items: center;
                    border-radius: 999px;
                    background: rgba(6, 22, 52, 0.95);
                    border: 1px solid rgba(100, 165, 255, 0.7);
                    padding: 2px 8px;
                    overflow: hidden;
                }
                .ccv-modal-currency {
                    font-size: 12px;
                    opacity: 0.85;
                    margin-right: 6px;
                }
                .ccv-modal-input {
                    flex: 1;
                    border: none;
                    background: transparent;
                    color: #f5f7ff;
                    font-size: 13px;
                    outline: none;
                }
                .ccv-modal-helper {
                    font-size: 11px;
                    opacity: 0.78;
                }
                .ccv-modal-pill-row {
    display: flex;
    justify-content: center;   /* center the pill inside the row */
    align-items: center;
    gap: 6px;

/* Hover effect – faint Caricove blue halo */
.ccv-modal-close:hover {
    background: rgba(255,255,255,0.24);
    transform: scale(1.05);
}

/* Remove any theme bleed hover underline */
.ccv-modal-close:hover,
.ccv-modal-close:focus,
.ccv-modal-close:active {
    text-decoration: none !important;
    outline: none !important;
}
.ccv-pill {
    border-radius: 999px;
    padding: 4px 16px;
    border: 1px solid rgba(110, 175, 255, 0.65);
    background: transparent;
    color: #f5f7ff;
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    cursor: default;           /* no longer a toggle – just a label */
    display: inline-flex;
    justify-content: center;
    align-items: center;
    min-width: 220px;          /* keeps it nicely “pill” shaped */
    text-align: center;
}
                .ccv-pill {
                    border-radius: 999px;
                    padding: 4px 9px;
                    border: 1px solid rgba(110, 175, 255, 0.65);
                    background: transparent;
                    color: #f5f7ff;
                    font-size: 11px;
                    text-transform: uppercase;
                    letter-spacing: 0.08em;
                    cursor: pointer;
                }
                .ccv-pill--active {
                    background: linear-gradient(135deg, #24b0ff, #006cff);
                    color: #010208;
                    box-shadow: 0 0 16px rgba(0, 170, 255, 0.8);
                }
                .ccv-modal-status {
                    min-height: 16px;
                    font-size: 11px;
                }
                .ccv-modal-status--error {
                    color: #ff8095;
                }
                .ccv-modal-status--success {
                    color: #8dffb4;
                }
                .ccv-modal-footer {
                    display: flex;
                    justify-content: flex-end;
                    gap: 6px;
                }

                /* Animations */
                @keyframes ccvPulse {
                    0%, 100% { transform: scale(1); opacity: 0.9; }
                    50% { transform: scale(1.08); opacity: 1; }
                }
                @keyframes ccvSpin {
                    to { transform: rotate(360deg); }
                }
                @keyframes ccvFadeUp {
                    from { opacity: 0; transform: translateY(8px); }
                    to { opacity: 1; transform: translateY(0); }
                }

                /* Responsive */
                @media (max-width: 960px) {
                    .ccv-console-header {
                        flex-direction: column;
                    }
                    .ccv-console-header-left {
                        max-width: 100%;
                    }
                    .ccv-console-header-right {
                        align-items: flex-start;
                    }
                    .ccv-detail-call-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 6px;
    gap: 8px;
    font-size: 11px;
}

.ccv-detail-contact-label {
    opacity: 0.82;
}

.ccv-detail-call-actions {
    display: flex;
    gap: 4px;
}

.ccv-call-btn {
    width: 26px;
    height: 26px;
    border-radius: 999px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 13px;
    text-decoration: none;
    border: 1px solid rgba(140, 190, 255, 0.7);
    background: rgba(3, 15, 38, 0.96);
    color: #f5f7ff;
    box-shadow: 0 0 12px rgba(0, 150, 255, 0.7);
    transition: transform 0.12s ease-out, box-shadow 0.12s ease-out, background 0.12s ease-out;
}

.ccv-call-btn--voice {
    background: linear-gradient(135deg, #23b1ff, #0067ff);
}

.ccv-call-btn--wa {
    background: linear-gradient(135deg, #00d46a, #008b3a);
    box-shadow: 0 0 14px rgba(0, 220, 120, 0.75);
}

.ccv-call-btn:hover {
    transform: translateY(-1px);
    box-shadow: 0 0 18px rgba(0, 200, 255, 0.9);
}
                    .ccv-balance-pills {
                        width: 100%;
                        justify-content: flex-start;
                        flex-wrap: wrap;
                    }
                    .ccv-console-body {
                        grid-template-columns: 1fr;
                    }
                }
            </style>

           <script>
    (function() {
        function qs(sel, ctx) { return (ctx || document).querySelector(sel); }
        function qsa(sel, ctx) { return Array.prototype.slice.call((ctx || document).querySelectorAll(sel)); }

        document.addEventListener('DOMContentLoaded', function() {
            var splash    = qs('#ccv-courier-splash');
            var consoleEl = qs('.ccv-console');

            if (splash && consoleEl) {
                setTimeout(function() {
                    splash.style.opacity = '0';
                    splash.style.pointerEvents = 'none';
                    consoleEl.style.opacity = '1';
                    consoleEl.style.transform = 'translateY(0)';
                }, 900);
            }

            // Tabs (Today / Map / Earnings / Settings)
            var tabs = qsa('.ccv-console-tab');
            tabs.forEach(function(tab) {
                tab.addEventListener('click', function() {
                    var view = tab.getAttribute('data-view');
                    tabs.forEach(function(t) { t.classList.remove('ccv-console-tab--active'); });
                    tab.classList.add('ccv-console-tab--active');
                    qsa('.ccv-console-body').forEach(function(body) {
                        if (body.getAttribute('data-view') === view) {
                            body.classList.remove('ccv-console-body--hidden');
                        } else {
                            body.classList.add('ccv-console-body--hidden');
                        }
                    });
                });
            });

            // Left panel: Active / History toggle
// Left panel: Active / Handover / History toggle
var listToggleBtns = qsa('.ccv-list-toggle-btn');
var activeList     = qs('#ccv-job-list-active');
var handoverList   = qs('#ccv-job-list-handover');
var completedList  = qs('#ccv-job-list-completed');

function setListMode(mode) {
    listToggleBtns.forEach(function(btn) {
        if (btn.getAttribute('data-list-target') === mode) {
            btn.classList.add('ccv-list-toggle-btn--active');
        } else {
            btn.classList.remove('ccv-list-toggle-btn--active');
        }
    });

    // Hide all lists first
    if (activeList)   activeList.classList.add('ccv-job-list--hidden');
    if (handoverList) handoverList.classList.add('ccv-job-list--hidden');
    if (completedList)completedList.classList.add('ccv-job-list--hidden');

    // Show the selected bucket
    if ('active' === mode && activeList) {
        activeList.classList.remove('ccv-job-list--hidden');
    } else if ('handover' === mode && handoverList) {
        handoverList.classList.remove('ccv-job-list--hidden');
    } else if ('completed' === mode && completedList) {
        completedList.classList.remove('ccv-job-list--hidden');
    }
}

listToggleBtns.forEach(function(btn) {
    btn.addEventListener('click', function() {
        var target = btn.getAttribute('data-list-target') || 'active';
        setListMode(target);
    });
});



// Default to ACTIVE
setListMode('active');

            listToggleBtns.forEach(function(btn) {
                btn.addEventListener('click', function() {
                    var target = btn.getAttribute('data-list-target') || 'active';
                    setListMode(target);
                });
            });

            // Default to active
            setListMode('active');



function autoOpenFirstVisibleJobCard() {
    var visibleList = null;

    if (activeList && !activeList.classList.contains('ccv-job-list--hidden')) {
        visibleList = activeList;
    } else if (handoverList && !handoverList.classList.contains('ccv-job-list--hidden')) {
        visibleList = handoverList;
    } else if (completedList && !completedList.classList.contains('ccv-job-list--hidden')) {
        visibleList = completedList;
    }

    if (!visibleList) return;

    var firstCard = visibleList.querySelector('.ccv-job-card');
    if (firstCard) {
        renderDetailFromCard(firstCard);
    } else if (detailShell) {
        detailShell.innerHTML = '<div class="ccv-detail-empty">Select a job on the left to see full route details, codes, and customer contacts.</div>';
    }
}

autoOpenFirstVisibleJobCard();



           // Job details
var detailShell = qs('#ccv-job-detail-shell');

            var codeModalBackdrop = qs('#ccv-code-modal-backdrop');
            var codeModalClose    = qs('#ccv-code-modal-close');
            var codeModalCancel   = qs('#ccv-code-modal-cancel');
            var codeModalSubmit   = qs('#ccv-code-modal-submit');
            var codeModalInput    = qs('#ccv-code-input');
            var codeModalStatus   = qs('#ccv-code-modal-status');

            var notesModalBackdrop = qs('#ccv-notes-modal-backdrop');
            var notesModalClose    = qs('#ccv-notes-modal-close');
            var notesModalDismiss  = null;
            var notesModalBody     = qs('#ccv-notes-modal-body');

            var payoutModalBackdrop = qs('#ccv-payout-modal-backdrop');
            var payoutModalClose    = qs('#ccv-payout-modal-close');
            var payoutModalCancel   = qs('#ccv-payout-modal-cancel');
            var payoutModalSubmit   = qs('#ccv-payout-modal-submit');
            var payoutAmountInput   = qs('#ccv-payout-amount');
            var payoutStatusEl      = qs('#ccv-payout-modal-status');
            var payoutPillButtons   = qsa('.ccv-pill');
            var payoutType          = 'scheduled';

            var btnScheduled = qs('#ccv-btn-payout-scheduled');
            var btnInstant   = qs('#ccv-btn-payout-instant');

            var metaEl = qs('#ccv-courier-js-meta');
            var ajaxUrl = metaEl ? metaEl.getAttribute('data-ajax-url') : '';
            var payoutNonce = metaEl ? metaEl.getAttribute('data-payout-nonce') : '';

            var pendingStatusCard = null; // job card awaiting code-confirm

            function collectDataFromCard(card) {
                var data = {};
                if (!card) return data;
                Array.prototype.forEach.call(card.attributes, function(attr) {
                    if (attr.name.indexOf('data-') === 0) {
                        data[attr.name.replace('data-', '')] = attr.value;
                    }
                });
                return data; 
            }

            function ccvEscapeHtml(value) {
                return String(value || '')
                    .replace(/&/g, '&amp;')
                    .replace(/</g, '&lt;')
                    .replace(/>/g, '&gt;')
                    .replace(/"/g, '&quot;')
                    .replace(/'/g, '&#039;');
            }

            // ---------- COUNTDOWN PILL: TIME LEFT UNTIL DEADLINE ----------
            var countdownTimer = null;

            function formatDeadlineCountdown(diff) {
                var remaining = Math.max(0, Math.round(diff));
                var mins = Math.floor(remaining / 60);
                var secs = remaining % 60;

                if (mins >= 60) {
                    var hrs = Math.floor(mins / 60);
                    var m2 = mins % 60;
                    return hrs + 'h ' + m2 + 'm left';
                }

                return mins + 'm ' + String(secs).padStart(2, '0') + 's left';
            }

            function updateCountdownPills() {
                var pills = qsa('.ccv-job-pill--time');
                if (!pills.length) return;

                var nowSec = Date.now() / 1000;
                var phaseIndex = Math.floor(nowSec / 10) % 2;

                pills.forEach(function(pill) {
                    var card = pill.closest('.ccv-job-card');
                    if (!card) return;

                    var ts = parseInt(card.getAttribute('data-deadline-ts') || '0', 10);
                    var deadlineLabel = (card.getAttribute('data-deadline-label') || '').trim();
                    var offerLive = card.getAttribute('data-offer-live') === '1';

                    if (!ts && !deadlineLabel) {
                        return;
                    }

                    var diff = ts ? (ts - nowSec) : 0;
                    var showDeadline = (!offerLive && deadlineLabel && phaseIndex === 1);

                    var label = deadlineLabel || pill.textContent || '';
                    var bg = 'linear-gradient(135deg,#12406b,#23b1ff)';
                    var color = '#e9f6ff';
                    var border = '1px solid rgba(120,190,255,0.9)';
                    var shadow = '0 0 10px rgba(60,170,255,0.7), 0 0 16px rgba(0,0,0,1)';

                    if (!showDeadline) {
                        if (!ts) {
                            return;
                        }

                        if (diff <= -60) {
                            label  = 'Late';
                            bg     = 'linear-gradient(135deg,#3c0b10,#a21424)';
                            color  = '#ffe6ea';
                            border = '1px solid rgba(255,120,140,0.9)';
                            shadow = '0 0 10px rgba(255,80,110,0.9), 0 0 20px rgba(0,0,0,1)';
                        } else {
                            label = formatDeadlineCountdown(diff);

                            if (diff <= 0) {
                                bg     = 'linear-gradient(135deg,#4a1b00,#ff7b00)';
                                color  = '#fff3e5';
                                border = '1px solid rgba(255,180,90,0.9)';
                                shadow = '0 0 10px rgba(255,150,60,0.9), 0 0 20px rgba(0,0,0,1)';
                            } else if (diff <= 5 * 60) {
                                bg     = 'linear-gradient(135deg,#4c0c11,#e7384b)';
                                color  = '#ffe6ea';
                                border = '1px solid rgba(255,122,140,0.9)';
                                shadow = '0 0 10px rgba(231,56,75,0.9), 0 0 20px rgba(0,0,0,1)';
                            } else if (diff <= 15 * 60) {
                                bg     = 'linear-gradient(135deg,#473307,#f4c048)';
                                color  = '#fff7df';
                                border = '1px solid rgba(244,192,72,0.9)';
                                shadow = '0 0 10px rgba(244,192,72,0.7), 0 0 16px rgba(0,0,0,1)';
                            }
                        }
                    }

                    var desiredMode = showDeadline ? 'deadline' : 'countdown';
                    if (pill.getAttribute('data-display-mode') !== desiredMode) {
                        pill.setAttribute('data-display-mode', desiredMode);
                        pill.classList.add('is-switching');
                        setTimeout(function() {
                            pill.classList.remove('is-switching');
                        }, 280);
                    }

                    if (pill.textContent !== label) {
                        pill.textContent = label;
                    }

                    pill.style.background = bg;
                    pill.style.color = color;
                    pill.style.border = border;
                    pill.style.boxShadow = shadow;
                    pill.style.fontWeight = '600';
                    pill.style.letterSpacing = '0.06em';
                });
            }

            // Kick off countdown loop
            updateCountdownPills();
            countdownTimer = setInterval(updateCountdownPills, 1000);

            // ---------- DETAIL PANEL RENDERING (UNCHANGED LAYOUT) ----------

         function renderDetailFromCard(card) {
    if (!card || !detailShell) return;

    var data = collectDataFromCard(card);

    var stateLabel  = data['job-state-label'] || (data['job-state'] || '').toUpperCase();
    var payAmount   = data['job-pay']      || '';
    var payCurrency = data['job-currency'] || '';

    // GOLD STYLED PAY LINE
    var payLine = '';
    if (payAmount && payCurrency) {
        payLine = '<span class="ccv-pay-gold">' + payCurrency + ' ' + payAmount + '</span>';
    }

    // PICKUP FIELDS
    var pickupName   = data['pickup-name']   || '';
    var pickupStreet = data['pickup-text']   || '';
    var pickupCity   = data['pickup-city']   || '';

    // DROPOFF FIELDS
    var dropName   = data['dropoff-name']   || '';
    var dropStreet = data['dropoff-text']   || '';
    var dropCity   = data['dropoff-city']   || '';

    // PHONES
    var pickupPhone  = data['pickup-phone']  || '';
    var dropoffPhone = data['dropoff-phone'] || '';

    var pickupTel    = pickupPhone  ? 'tel:' + pickupPhone : '';
    var dropoffTel   = dropoffPhone ? 'tel:' + dropoffPhone : '';

    var pickupWa     = pickupPhone  ? 'https://wa.me/' + pickupPhone.replace(/\D+/g, '')  : '';
    var dropoffWa    = dropoffPhone ? 'https://wa.me/' + dropoffPhone.replace(/\D+/g, '') : '';

    // MAP URL (reuse if present, otherwise build)
    var pickupAddressParts = [];
    if (pickupStreet) pickupAddressParts.push(pickupStreet);
    if (pickupCity)   pickupAddressParts.push(pickupCity);

    var dropoffAddressParts = [];
    if (dropStreet) dropoffAddressParts.push(dropStreet);
    if (dropCity)   dropoffAddressParts.push(dropCity);

    var pickupAddress  = pickupAddressParts.join(', ');
    var dropoffAddress = dropoffAddressParts.join(', ');
    var deliveryNotes  = data['dropoff-instructions'] || data['delivery-instructions'] || '';

   var phase = (data['phase'] || 'to_pickup').toLowerCase();

var pickupLat = data['pickup-lat'] || '';
var pickupLng = data['pickup-lng'] || '';
var dropLat   = data['dropoff-lat'] || '';
var dropLng   = data['dropoff-lng'] || '';

var mapUrl = '';
var navUrl = data['nav-url'] || '';

// Exact pin map target first, phase-aware
if (phase === 'to_dropoff') {
    if (dropLat && dropLng) {
        mapUrl = 'https://www.google.com/maps/search/?api=1&query='
            + encodeURIComponent(dropLat + ',' + dropLng);
    } else if (dropoffAddress) {
        mapUrl = 'https://www.google.com/maps/search/?api=1&query='
            + encodeURIComponent(dropoffAddress);
    }
} else {
    if (pickupLat && pickupLng) {
        mapUrl = 'https://www.google.com/maps/search/?api=1&query='
            + encodeURIComponent(pickupLat + ',' + pickupLng);
    } else if (pickupAddress) {
        mapUrl = 'https://www.google.com/maps/search/?api=1&query='
            + encodeURIComponent(pickupAddress);
    }
}

// Navigation URL, phase-aware, only if bridge did not already provide one
if (!navUrl) {
    if (phase === 'to_dropoff') {
        if (dropLat && dropLng) {
            navUrl = 'https://www.google.com/maps/dir/?api=1&destination='
                + encodeURIComponent(dropLat + ',' + dropLng);
        } else if (dropoffAddress) {
            navUrl = 'https://www.google.com/maps/dir/?api=1&destination='
                + encodeURIComponent(dropoffAddress);
        }
    } else {
        if (pickupLat && pickupLng) {
            navUrl = 'https://www.google.com/maps/dir/?api=1&destination='
                + encodeURIComponent(pickupLat + ',' + pickupLng);
        } else if (pickupAddress) {
            navUrl = 'https://www.google.com/maps/dir/?api=1&destination='
                + encodeURIComponent(pickupAddress);
        }
    }
}

if (mapUrl) {
    card.setAttribute('data-map-url', mapUrl);
    data['map-url'] = mapUrl;
}
if (navUrl) {
    card.setAttribute('data-nav-url', navUrl);
    data['nav-url'] = navUrl;
}
    var html = ''
        + '<div class="ccv-detail">'

        // HEADER
        +   '<div class="ccv-detail-header">'
        +     '<div class="ccv-detail-title-group">'
        +       '<div class="ccv-detail-title">' + (data['job-label'] || '') + '</div>'
        +       (payLine ? '<div class="ccv-detail-payline">' + payLine + '</div>' : '')
        +     '</div>'
        +     '<div class="ccv-detail-state-tag">' + (stateLabel || '') + '</div>'
        +   '</div>'

        // GRID
        +   '<div class="ccv-detail-grid">'

        // PICKUP CARD
        +     '<div class="ccv-detail-card">'
        +       '<div class="ccv-detail-label">Pickup</div>'
        +       (pickupName   ? '<div class="ccv-addr-name">'   + pickupName   + '</div>' : '')
        +       (pickupStreet ? '<div class="ccv-addr-street">' + pickupStreet + '</div>' : '')
        +       (pickupCity   ? '<div class="ccv-addr-city">'   + pickupCity   + '</div>' : '');
    // contact row: ICONS ONLY (no name → no duplicate)
 if (pickupTel || pickupWa) {
    html += '<div class="ccv-detail-call-row">'
         +   '<div class="ccv-detail-call-actions">'
         +      (pickupTel ? '<a class="ccv-call-btn ccv-call-btn--voice" href="' + pickupTel + '">📞</a>' : '')
         +      (pickupWa  ? '<a class="ccv-call-btn ccv-call-btn--wa" href="' + pickupWa  + '" target="_blank" rel="noopener noreferrer">📞</a>' : '')
         +   '</div>'
         + '</div>';
}
    html += '</div>'  // end pickup card

        // DROPOFF CARD
        +     '<div class="ccv-detail-card">'
        +       '<div class="ccv-detail-label">Dropoff</div>'
        +       (dropName   ? '<div class="ccv-addr-name">'   + dropName   + '</div>' : '')
        +       (dropStreet ? '<div class="ccv-addr-street">' + dropStreet + '</div>' : '')
        +       (dropCity   ? '<div class="ccv-addr-city">'   + dropCity   + '</div>' : '');
    // contact row: ICONS ONLY (no duplicate name)
    if (dropoffTel || dropoffWa) {
        html += '<div class="ccv-detail-call-row">'
             +   '<div class="ccv-detail-call-actions">'
             +      (dropoffTel ? '<a class="ccv-call-btn ccv-call-btn--voice" href="' + dropoffTel + '">📞</a>' : '')
             +      (dropoffWa  ? '<a class="ccv-call-btn ccv-call-btn--wa" href="' + dropoffWa  + '" target="_blank" rel="noopener noreferrer">📞</a>' : '')
             +   '</div>'
             + '</div>';
    }
    html += '</div>'   // end dropoff card
        + '</div>'     // end grid

        // BOTTOM: DELIVER BY + DELIVERY NOTES + OPEN IN MAPS
        + '<div class="ccv-detail-actions">'
        +   '<div class="ccv-detail-codes">'
        +      (data['deadline-label']
                 ? '<span class="ccv-detail-deadline-pill">' + ccvEscapeHtml(data['deadline-label']) + '</span>'
                 : '')
        +   '</div>'
        +   '<div class="ccv-detail-map-link">'
        +      '<button type="button" class="ccv-notes-trigger" data-role="delivery-notes" title="Delivery Notes" aria-label="Delivery Notes">'
        +          '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 2h9l5 5v13a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2zm8 1.5V8h4.5"></path><path d="M8 11h8v1.8H8zm0 3.7h8v1.8H8zm0-7.4h4.5v1.8H8z"></path></svg>'
        +      '</button>'
        +      (mapUrl ? '<a href="' + mapUrl + '" target="_blank" rel="noopener noreferrer">Open in Maps</a>' : '')
        +   '</div>'
        + '</div>';

    // ACTION BUTTON
    if (data['next-state'] && data['next-state-label']) {
        html += '<div class="ccv-detail-actions">'
             +    '<button type="button" class="ccv-btn ccv-btn--primary" data-role="primary-action">'
             +       data['next-state-label']
             +    '</button>'
             +  '</div>';
    }

    html += '</div>';

    detailShell.innerHTML = html;

   var notesBtn = detailShell.querySelector('[data-role="delivery-notes"]');
if (notesBtn) {
    ['pointerdown', 'mousedown', 'touchstart', 'click'].forEach(function(evtName) {
        notesBtn.addEventListener(evtName, function(e) {
            if (e) {
                e.preventDefault();
                e.stopPropagation();
                if (typeof e.stopImmediatePropagation === 'function') {
                    e.stopImmediatePropagation();
                }
            }

            if (evtName === 'click') {
                openNotesModal(deliveryNotes);
            }

            return false;
        }, true);
    });
}

    // Wire primary action
    var primaryBtn = detailShell.querySelector('[data-role="primary-action"]');
    if (primaryBtn) {
        primaryBtn.addEventListener('click', function() {
            var requiresCode = card.getAttribute('data-requires-code') === '1';
            pendingStatusCard = card;
            if (requiresCode) {
                openCodeModal();
            } else {
                handleStatusChange(card, null);
            }
        });
    }
}


            function openCodeModal() {
                if (!codeModalBackdrop) return;
                codeModalStatus.textContent = '';
                codeModalStatus.className = 'ccv-modal-status';
                if (codeModalInput) {
                    codeModalInput.value = '';
                }
                codeModalBackdrop.classList.add('ccv-modal-backdrop--show');
                document.body.style.overflow = 'hidden';
                setTimeout(function() {
                    if (codeModalInput) codeModalInput.focus();
                }, 10);
            }

            function closeCodeModal() {
                if (!codeModalBackdrop) return;
                codeModalBackdrop.classList.remove('ccv-modal-backdrop--show');
                document.body.style.overflow = '';
            }

            function openNotesModal(notesText) {
                if (!notesModalBackdrop || !notesModalBody) return;
                var safeText = (notesText && String(notesText).trim()) ? String(notesText).trim() : 'No delivery instructions provided.';
                notesModalBody.textContent = safeText;
                notesModalBackdrop.classList.add('ccv-modal-backdrop--show');
                document.body.style.overflow = 'hidden';
            }

            function closeNotesModal() {
                if (!notesModalBackdrop) return;
                notesModalBackdrop.classList.remove('ccv-modal-backdrop--show');
                document.body.style.overflow = '';
            }

            if (codeModalBackdrop) {
                codeModalBackdrop.addEventListener('click', function(e) {
                    if (e.target === codeModalBackdrop) {
                        closeCodeModal();
                    }
                });
            }
            if (codeModalClose)  codeModalClose.addEventListener('click', closeCodeModal);
            if (codeModalCancel) codeModalCancel.addEventListener('click', closeCodeModal);

            if (notesModalBackdrop) {
                notesModalBackdrop.addEventListener('click', function(e) {
                    if (e.target === notesModalBackdrop) {
                        closeNotesModal();
                    }
                });
            }
            if (notesModalClose) notesModalClose.addEventListener('click', closeNotesModal);
           
            if (codeModalSubmit) {
                codeModalSubmit.addEventListener('click', function() {
                    if (!pendingStatusCard) {
                        closeCodeModal();
                        return;
                    }
                    var codeVal = codeModalInput ? codeModalInput.value.trim() : '';
                    if (!codeVal) {
                        codeModalStatus.textContent = 'Please enter the delivery code.';
                        codeModalStatus.className = 'ccv-modal-status ccv-modal-status--error';
                        return;
                    }
                    codeModalStatus.textContent = 'Verifying code…';
                    codeModalStatus.className = 'ccv-modal-status';

                    handleStatusChange(pendingStatusCard, codeVal);

                    setTimeout(function() {
                        closeCodeModal();
                    }, 500);
                });
            }

          document.addEventListener('click', function(e) {
    var card = e.target.closest('.ccv-job-card');
    if (!card) return;

    // ignore clicks coming from inner controls/buttons/inputs if any
    if (e.target.closest('button, a, input, select, textarea')) return;

    qsa('.ccv-job-card').forEach(function(c){
        c.classList.remove('is-active');
        c.classList.remove('ccv-job-card--selected');
    });
    card.classList.add('ccv-job-card--selected');

    renderDetailFromCard(card);
});

            // Balances / payout refresh
            function updateBalancesFromAjax() {
                if (!ajaxUrl || !window.fetch) return;
                var params = new URLSearchParams();
                params.append('action', 'caricove_courier_get_balances');
                params.append('_', Date.now());

                fetch(ajaxUrl + '?' + params.toString(), {
                    credentials: 'same-origin'
                }).then(function(r) { return r.json(); }).then(function(data) {
                    if (!data || !data.success || !data.data) return;
                    var d  = data.data;
                    var av = d.available || 0;
                    var cl = d.clearing || 0;
                    var hd = d.held || 0;

                    var avEl = qs('#ccv-balance-available');
                    var clEl = qs('#ccv-balance-clearing');
                    var hdEl = qs('#ccv-balance-held');
                    var av2  = qs('[data-bind="available"]');
                    var cl2  = qs('[data-bind="clearing"]');
                    var hd2  = qs('[data-bind="held"]');
                    var availDisplay = qs('#ccv-payout-available-display');

                    [ [avEl, av], [clEl, cl], [hdEl, hd], [av2, av], [cl2, cl], [hd2, hd] ].forEach(function(pair) {
                        if (pair[0]) pair[0].textContent = Number(pair[1]).toFixed(2);
                    });
                    if (availDisplay) {
                        availDisplay.textContent = Number(av).toFixed(2);
                    }
                })["catch"](function() {});
            }

            // Payout pill toggle (Scheduled vs Instant)
            payoutPillButtons.forEach(function(pill) {
                pill.addEventListener('click', function() {
                    payoutType = pill.getAttribute('data-payout-type') || 'scheduled';
                    payoutPillButtons.forEach(function(p) { p.classList.remove('ccv-pill--active'); });
                    pill.classList.add('ccv-pill--active');
                });
            });

            function openPayoutModal(type) {
                if (!payoutModalBackdrop) return;

                payoutType = type || 'scheduled';

                payoutPillButtons.forEach(function(p) {
                    var thisType = p.getAttribute('data-payout-type') || 'scheduled';

                    if (thisType === payoutType) {
                        p.style.display = 'inline-flex';
                        p.classList.add('ccv-pill--active');
                    } else {
                        p.style.display = 'none';
                        p.classList.remove('ccv-pill--active');
                    }
                });

                if (payoutStatusEl) {
                    payoutStatusEl.textContent = '';
                    payoutStatusEl.className = 'ccv-modal-status';
                }
                if (payoutAmountInput) {
                    payoutAmountInput.value = '';
                }

                payoutModalBackdrop.classList.add('ccv-modal-backdrop--show');
                document.body.style.overflow = 'hidden';

                setTimeout(function() {
                    if (payoutAmountInput) payoutAmountInput.focus();
                }, 10);
            }

            function closePayoutModal() {
                if (!payoutModalBackdrop) return;
                payoutModalBackdrop.classList.remove('ccv-modal-backdrop--show');
                document.body.style.overflow = '';
            }

            if (payoutModalBackdrop) {
                payoutModalBackdrop.addEventListener('click', function(e) {
                    if (e.target === payoutModalBackdrop) {
                        closePayoutModal();
                    }
                });
            }
            if (payoutModalClose)  payoutModalClose.addEventListener('click', closePayoutModal);
            if (payoutModalCancel) payoutModalCancel.addEventListener('click', closePayoutModal);

            if (btnScheduled) {
                btnScheduled.addEventListener('click', function() {
                    openPayoutModal('scheduled');
                });
            }
            if (btnInstant) {
                btnInstant.addEventListener('click', function() {
                    openPayoutModal('instant');
                });
            }

            if (payoutModalSubmit && ajaxUrl && window.fetch) {
                payoutModalSubmit.addEventListener('click', function() {
                    if (!payoutAmountInput) return;
                    var val = parseFloat(payoutAmountInput.value || '0');
                    if (!(val > 0)) {
                        payoutStatusEl.textContent = 'Please enter an amount greater than zero.';
                        payoutStatusEl.className = 'ccv-modal-status ccv-modal-status--error';
                        return;
                    }

                    payoutStatusEl.textContent = 'Submitting payout request…';
                    payoutStatusEl.className = 'ccv-modal-status';

                    var form = new FormData();
                    form.append('action', 'caricove_courier_request_payout');
                    form.append('amount', String(val));
                    form.append('type', payoutType);
                    form.append('nonce', payoutNonce);

                    fetch(ajaxUrl, {
                        method: 'POST',
                        credentials: 'same-origin',
                        body: form
                    }).then(function(r) { return r.json(); }).then(function(resp) {
                        if (!resp || !resp.success) {
                            payoutStatusEl.textContent = (resp && resp.data && resp.data.message) || 'Unable to submit request.';
                            payoutStatusEl.className = 'ccv-modal-status ccv-modal-status--error';
                            return;
                        }
                        payoutStatusEl.textContent = (resp.data && resp.data.message) || 'Payout request submitted.';
                        payoutStatusEl.className = 'ccv-modal-status ccv-modal-status--success';

                        updateBalancesFromAjax();
                        setInterval(function() {
    updateBalancesFromAjax();
}, 15000);

                        setTimeout(function() {
                            closePayoutModal();
                        }, 900);
                    })["catch"](function() {
                        payoutStatusEl.textContent = 'Network error. Please try again.';
                        payoutStatusEl.className = 'ccv-modal-status ccv-modal-status--error';
                    });
                });
            }

            updateBalancesFromAjax();

            // Escape key closes modals
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape') {
                    closePayoutModal();
                    closeCodeModal();
                    closeNotesModal();
                }
            });

            // Status change dispatcher
         function handleStatusChange(card, codeValue) {
  if (!card) return;
  var data = collectDataFromCard(card);

  var payload = {
    job_id:        data['job-id'] || null,
    from_state:    data['job-state'] || null,
    to_state:      data['next-state'] || null,
    label:         data['job-label'] || null,
    requires_code: card.getAttribute('data-requires-code') === '1',
    code:          codeValue || null
  };

  // Emit event (optional observers)
  try {
    window.dispatchEvent(new CustomEvent('caricove:courierStatusChange', { detail: payload }));
  } catch (err) {}

  // ✅ GUARANTEE the server action is triggered
  if (typeof window.CaricoveCourierStatusHandler === 'function') {
    window.CaricoveCourierStatusHandler(payload);
  }
}
        });
    })();
</script>

<script>
/**
 * Caricove Courier Console — State Router (Telemetry-critical)
 * Maps UI "next_state" -> correct admin-ajax endpoint.
 *
 * Required server handlers:
 *  - en_route    -> wp_ajax_caricove_courier_start_trip
 *  - pickup_code -> wp_ajax_caricove_courier_verify_pickup   (requires code)
 *  - delivered   -> wp_ajax_caricove_courier_verify_delivery (requires code)
 */
window.CaricoveCourierStatusHandler = function (payload) {
  try {
    if (!payload || !payload.job_id || !payload.to_state) return;

    var metaEl = document.getElementById('ccv-courier-js-meta');
    if (!metaEl || !window.fetch) return;

    var ajaxUrl    = metaEl.getAttribute('data-ajax-url') || '';
    var startNonce = metaEl.getAttribute('data-start-nonce') || '';
    if (!ajaxUrl || !startNonce) return;

    var toState = String(payload.to_state || '').trim();
    var codeVal = payload.code ? String(payload.code).trim() : '';

    // Explicit endpoint routing
    var action = '';
    var needsCode = false;

    if (toState === 'en_route') {
      action = 'caricove_courier_start_trip';
      needsCode = false;
    } else if (toState === 'pickup_code') {
      action = 'caricove_courier_verify_pickup';
      needsCode = true;
    } else if (toState === 'delivered') {
      action = 'caricove_courier_verify_delivery';
      needsCode = true;
    } else {
      // Unknown state: do nothing (prevents accidental bad calls)
      return;
    }

    if (needsCode && !codeVal) {
      // The modal should have enforced this already, but hard-guard anyway.
      return;
    }

    var form = new FormData();
    form.append('action', action);
    form.append('job_id', String(payload.job_id));
    form.append('nonce', startNonce);
    if (needsCode) form.append('code', codeVal);

    // UI feedback: lock primary button
    var detailShell = document.getElementById('ccv-job-detail-shell');
    var primaryBtn  = detailShell ? detailShell.querySelector('[data-role="primary-action"]') : null;
    var prevBtnText = primaryBtn ? primaryBtn.textContent : '';
    if (primaryBtn) {
      primaryBtn.disabled = true;
      primaryBtn.textContent = (toState === 'en_route') ? 'Starting…' : 'Processing…';
    }

    fetch(ajaxUrl, { method: 'POST', credentials: 'same-origin', body: form })
      .then(function (r) { return r.json(); })
      .then(function (resp) {
        if (!primaryBtn) return;

        if (!resp || !resp.success || !resp.data || !resp.data.job) {
          primaryBtn.disabled = false;
          primaryBtn.textContent = prevBtnText || 'Try Again';
          return;
        }

        var job = resp.data.job;

       // Update card attributes from server truth
var card = document.querySelector('.ccv-job-card[data-job-id="' + job.job_id + '"]');
if (card) {
  if (job.status) card.setAttribute('data-job-state', job.status);
  if (job.status_label) card.setAttribute('data-job-state-label', job.status_label);

  card.setAttribute('data-next-state', job.next_state || '');
  card.setAttribute('data-next-state-label', job.next_state_label || '');

  // Re-render detail (your existing renderDetailFromCard runs on click)
  if (typeof card.click === 'function') card.click();
}

// Refresh balances immediately after successful server truth update
if (typeof updateBalancesFromAjax === 'function') {
  updateBalancesFromAjax();
}

// Unlock button (detail will rerender; but safe fallback)
primaryBtn.disabled = false;
primaryBtn.textContent = prevBtnText || 'Done';
      })
      .catch(function () {
        if (!primaryBtn) return;
        primaryBtn.disabled = false;
        primaryBtn.textContent = prevBtnText || 'Try Again';
      });

  } catch (e) {
    // swallow to avoid breaking console UI
  }
};
</script>
            <?php
        }
    }

    Caricove_Logistics_Scaffold::boot();
}
