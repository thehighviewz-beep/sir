<?php
/**
 * Plugin Name: Caricove Dispatcher — Shipment Command Center (Sexy + Courier Radar) [FIXED: Summary-First]
 * Description: Dispatcher → Shipment Command Center. Single-pane ops view: shipment + order + vendor + customer + codes + courier + nearby eligible couriers + actions.
 * Author: Caricove
 * MU Plugin: true
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class Caricove_Dispatcher_Shipment_Command_Center {

    const PAGE_SLUG = 'cc-dispatcher-shipment-center';

    // Options
    const OPT_OVERRIDES_FALLBACK = '_cc_dispatcher_overrides';
    const OPT_SETTINGS_FALLBACK  = '_cc_dispatcher_settings';
    const OPT_CODE_AUDIT         = '_cc_dispatcher_code_reveal_audit';

    // Shipment CPT + meta defaults (fallback only; we now prefer Core summary)
    const META_STATUS            = '_cc_status';
    const META_HOLD_REASON       = '_cc_hold_reason';
    const META_ATTEMPTS          = '_cc_redispatch_attempts';
    const META_LAST_CAND_COUNT   = '_cc_last_candidate_count';

    const META_ORDER_ID          = '_cc_order_id';
    const META_VENDOR_ID         = '_cc_vendor_id';
    const META_ASSIGNED_COURIER  = '_cc_assigned_courier_id';

    const META_ORIGIN_ANCHOR     = '_cc_origin_anchor';
    const META_DEST_ANCHOR       = '_cc_destination_anchor';

    const META_PICKUP_COORDS     = '_cc_pickup_coords';
    const META_DROPOFF_COORDS    = '_cc_dropoff_coords';

    const META_SIZE_BAND         = '_cc_size_band';
    const META_WEIGHT_BAND       = '_cc_weight_band';

    // Codes (mask by default)
    const META_PICKUP_CODE       = '_cc_pickup_code';
    const META_DELIVERY_CODE     = '_cc_delivery_code';

    // Legacy manual-review flag (kept for compatibility with older admin actions)
    const META_INHOUSE_FLAG      = '_cc_inhouse_queue';

    // Vendor geo meta (fallbacks)
    const V_META_LAT             = '_cc_vendor_lat';
    const V_META_LNG             = '_cc_vendor_lng';
    const V_META_ZONE            = '_cc_vendor_zone';
    const V_META_FMT_ADDR        = '_cc_vendor_formatted_address';

    // Customer geo meta on order (fallbacks)
    const O_META_DROPOFF_LAT     = '_cc_dropoff_lat';
    const O_META_DROPOFF_LNG     = '_cc_dropoff_lng';
    const O_META_DROPOFF_ZONE    = '_cc_dropoff_zone';
    const O_META_DROPOFF_FMT     = '_cc_dropoff_formatted_address';

    // Courier lock meta (fallback)
    const U_META_LOCK_REASON     = '_cc_courier_lock_reason';
    const U_META_LOCK_EXPIRES    = '_cc_courier_lock_expires_at';

    // Trust meta
    const U_META_TRUST_SCORE     = '_cc_trust_score';
    const U_META_TRUST_TIER      = '_cc_trust_tier';

    public static function boot() {
        add_action( 'admin_menu', array( __CLASS__, 'register_menu' ), 40 );

        add_action( 'admin_post_cc_scc_retry',        array( __CLASS__, 'handle_retry' ) );
        add_action( 'admin_post_cc_scc_force',        array( __CLASS__, 'handle_force_assign' ) );
        add_action( 'admin_post_cc_scc_inhouse',      array( __CLASS__, 'handle_send_inhouse' ) );
        add_action( 'admin_post_cc_scc_manual_review', array( __CLASS__, 'handle_send_inhouse' ) );
        add_action( 'admin_post_cc_scc_clear_lock',   array( __CLASS__, 'handle_clear_lock' ) );
        add_action( 'admin_post_cc_scc_reveal_code',  array( __CLASS__, 'handle_reveal_code' ) );
    }

    public static function register_menu() {
        add_submenu_page(
            'caricove-dispatcher-admin',
            __( 'Shipment Command Center', 'caricove-logistics' ),
            __( 'Shipment View', 'caricove-logistics' ),
            'manage_options',
            self::PAGE_SLUG,
            array( __CLASS__, 'render_page' )
        );
    }

    /* -----------------------------
     * Core helpers
     * -------------------------- */

    private static function shipment_cpt() {
        return apply_filters( 'cc_logistics_shipment_cpt', 'cc_shipment' );
    }

    private static function get_shipment_summary_safe( $shipment_id ) {
        if ( class_exists('\Caricove\Logistics\Core\ShipmentManager') && method_exists('\Caricove\Logistics\Core\ShipmentManager', 'get_shipment_summary') ) {
            $s = \Caricove\Logistics\Core\ShipmentManager::get_shipment_summary( $shipment_id );
            return is_array($s) ? $s : array();
        }
        return array();
    }

private static function get_active_jobs_count_like_logistics( $courier_id ) {
    $courier_id = intval($courier_id);
    if ( ! $courier_id ) return 0;

    if ( class_exists('\Caricove\Logistics\Dispatcher\CourierPool') && method_exists('\Caricove\Logistics\Dispatcher\CourierPool', 'count_active_jobs_for_courier') ) {
        return (int) \Caricove\Logistics\Dispatcher\CourierPool::count_active_jobs_for_courier( $courier_id );
    }

    if ( class_exists('\Caricove\Logistics\Core\AutoAssign') && method_exists('\Caricove\Logistics\Core\AutoAssign', 'get_courier_active_job_count') ) {
        return (int) \Caricove\Logistics\Core\AutoAssign::get_courier_active_job_count( $courier_id );
    }

    $active_statuses = class_exists('\Caricove\Logistics\Core\StatusMachine') && method_exists('\Caricove\Logistics\Core\StatusMachine', 'get_canonical_active_job_statuses')
        ? \Caricove\Logistics\Core\StatusMachine::get_canonical_active_job_statuses()
        : array('assigned','out_for_delivery','picked_up','in_transit','out_for_redelivery_day1','paid_redelivery_pending_confirmation','paid_redelivery_ready_for_dispatch');

    $cpt = apply_filters('cc_logistics_shipment_cpt', 'cc_shipment');

    $courier_key = class_exists('\Caricove\Logistics\Core\Schema')
        ? \Caricove\Logistics\Core\Schema::META_SHIPMENT_COURIER_ID
        : '_cc_shipment_courier_id';

    $status_key = class_exists('\Caricove\Logistics\Core\Schema')
        ? \Caricove\Logistics\Core\Schema::META_SHIPMENT_STATUS
        : '_cc_shipment_status';

    $q = new \WP_Query(array(
        'post_type'      => $cpt,
        'post_status'    => 'any',
        'posts_per_page' => 500,
        'fields'         => 'ids',
        'no_found_rows'  => true,
        'meta_query'     => array(
            array('key' => $courier_key, 'value' => $courier_id),
            array('key' => $status_key, 'value' => (array)$active_statuses, 'compare' => 'IN'),
        ),
    ));

    return is_array($q->posts) ? count($q->posts) : 0;
}


    private static function settings_key() {
        if ( class_exists( '\Caricove\Logistics\Dispatcher\Settings' ) ) {
            $const = '\Caricove\Logistics\Dispatcher\Settings::OPTION_SETTINGS';
            if ( defined( $const ) ) return constant( $const );
        }
        return self::OPT_SETTINGS_FALLBACK;
    }

    private static function overrides_key() {
        if ( class_exists( '\Caricove\Logistics\Dispatcher\Overrides' ) ) {
            $const = '\Caricove\Logistics\Dispatcher\Overrides::OPTION_OVERRIDES';
            if ( defined( $const ) ) return constant( $const );
        }
        return self::OPT_OVERRIDES_FALLBACK;
    }

    private static function get_settings() {
        $s = get_option( self::settings_key(), array() );
        if ( ! is_array( $s ) ) $s = array();

        $d = array(
            'enabled' => 1,
            'weights' => array(
                'pickup_readiness' => 0.45,
                'fit'              => 0.20,
                'load'             => 0.15,
                'sla_safety'       => 0.10,
                'performance'      => 0.05,
                'minor_ops'        => 0.05,
            ),
            'max_distance_km'   => 15.0,
            'candidate_limit'   => 200,
            'heartbeat_max_age' => 300,
            'trust_weight'      => 0.15,
            'trust_bonus_cap'   => 0.25,
            'extra_heavy_mode'  => 'truck_only',
        );

        $out = array_merge( $d, $s );
        $out['weights'] = array_merge( $d['weights'], ( isset($s['weights']) && is_array($s['weights']) ? $s['weights'] : array() ) );

        return $out;
    }

    private static function get_overrides() {
        $ov = get_option( self::overrides_key(), array() );
        if ( ! is_array( $ov ) ) $ov = array();

        $defaults = array(
            'courier_blocklist'          => array(),
            'courier_weight_adjustments' => array(),
            'vendor_blocklist'           => array(),
            'vendor_manual_only'         => array(),
            'shipment_locks'             => array(),
            'shipment_forced_courier'    => array(),
        );

        $ov = array_merge( $defaults, $ov );
        foreach ( $defaults as $k => $v ) {
            if ( ! isset($ov[$k]) || ! is_array($ov[$k]) ) $ov[$k] = array();
        }

        return $ov;
    }

    private static function save_overrides( array $ov ) {
        update_option( self::overrides_key(), $ov, false );
    }

    private static function pm_int( $pid, $key, $default = 0 ) {
        $v = get_post_meta( $pid, $key, true );
        if ( $v === '' || $v === null ) return $default;
        return intval( $v );
    }

    private static function pm_str( $pid, $key, $default = '' ) {
        $v = get_post_meta( $pid, $key, true );
        if ( $v === '' || $v === null ) return $default;
        return (string) $v;
    }

    private static function um_str( $uid, $key, $default = '' ) {
        $v = get_user_meta( $uid, $key, true );
        if ( $v === '' || $v === null ) return $default;
        return (string) $v;
    }

    private static function um_int( $uid, $key, $default = 0 ) {
        $v = get_user_meta( $uid, $key, true );
        if ( $v === '' || $v === null ) return $default;
        return intval( $v );
    }

    private static function age_human( $ts ) {
        $ts = intval($ts);
        if ( $ts <= 0 ) return '—';
        $sec = time() - $ts;
        if ( $sec < 0 ) $sec = 0;
        $m = floor($sec/60);
        if ( $m < 60 ) return $m . 'm';
        $h = floor($m/60); $m = $m % 60;
        if ( $h < 24 ) return $h . 'h ' . $m . 'm';
        $d = floor($h/24); $h = $h % 24;
        return $d . 'd ' . $h . 'h';
    }

    private static function mask_code( $code ) {
        $code = (string) $code;
        if ( $code === '' ) return '—';
        return str_repeat('•', max(4, min(10, strlen($code))));
    }

    private static function can_reveal_codes() {
        return current_user_can('manage_options');
    }

    private static function log_code_reveal( $shipment_id, $which ) {
        $audit = get_option( self::OPT_CODE_AUDIT, array() );
        if ( ! is_array($audit) ) $audit = array();

        $uid  = get_current_user_id();
        $user = $uid ? get_userdata($uid) : null;

        $audit_entry = array(
            'ts'         => time(),
            'who'        => $user ? $user->user_login : 'unknown',
            'ip'         => isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field($_SERVER['REMOTE_ADDR']) : '',
            'shipment_id'=> intval($shipment_id),
            'which'      => sanitize_key($which),
        );

        array_unshift($audit, $audit_entry);
        $audit = array_slice($audit, 0, 100);

        update_option( self::OPT_CODE_AUDIT, $audit, false );
    }

    private static function admin_url_page( $args = array() ) {
        $base = admin_url('admin.php?page=' . self::PAGE_SLUG);
        return empty($args) ? $base : add_query_arg($args, $base);
    }

    private static function fmt_addr( $addr ) {
        if ( ! is_array($addr) ) return '';
        $parts = array_filter(array(
            $addr['street']   ?? '',
            $addr['street_2'] ?? '',
            $addr['village']  ?? '',
            $addr['city']     ?? '',
            $addr['region']   ?? '',
            $addr['postcode'] ?? '',
            $addr['country']  ?? '',
        ));
        return implode(', ', $parts);
    }

    /* -----------------------------
     * Actions
     * -------------------------- */

    public static function handle_retry() {
        if ( ! current_user_can('manage_options') ) wp_die('Unauthorized');
        check_admin_referer('cc_scc_action','_cc_nonce');

        $shipment_id = isset($_GET['shipment_id']) ? intval($_GET['shipment_id']) : 0;
        if ( ! $shipment_id ) {
            wp_safe_redirect( self::admin_url_page(array('notice'=>'bad')) );
            exit;
        }

        do_action( 'caricove_dispatcher_retry_assignment', $shipment_id, 'admin_retry' );

        wp_safe_redirect( self::admin_url_page(array('shipment_id'=>$shipment_id,'notice'=>'retry_ok')) );
        exit;
    }

    public static function handle_force_assign() {
        if ( ! current_user_can('manage_options') ) wp_die('Unauthorized');
        check_admin_referer('cc_scc_action','_cc_nonce');

        $shipment_id = isset($_POST['shipment_id']) ? intval($_POST['shipment_id']) : 0;
        $courier_id  = isset($_POST['courier_id']) ? intval($_POST['courier_id']) : 0;

        if ( ! $shipment_id || ! $courier_id ) {
            wp_safe_redirect( self::admin_url_page(array('notice'=>'bad')) );
            exit;
        }

        $ov = self::get_overrides();
        $ov['shipment_forced_courier'][ $shipment_id ] = $courier_id;
        self::save_overrides( $ov );

        do_action( 'caricove_dispatcher_retry_assignment', $shipment_id, 'admin_force' );

        wp_safe_redirect( self::admin_url_page(array('shipment_id'=>$shipment_id,'notice'=>'force_ok')) );
        exit;
    }

    public static function handle_send_inhouse() {
        if ( ! current_user_can('manage_options') ) wp_die('Unauthorized');
        check_admin_referer('cc_scc_action','_cc_nonce');

        $shipment_id = isset($_GET['shipment_id']) ? intval($_GET['shipment_id']) : 0;
        if ( ! $shipment_id ) {
            wp_safe_redirect( self::admin_url_page(array('notice'=>'bad')) );
            exit;
        }

        update_post_meta( $shipment_id, self::META_STATUS, 'manual' );
        update_post_meta( $shipment_id, self::META_INHOUSE_FLAG, 0 );
        update_post_meta( $shipment_id, self::META_HOLD_REASON, 'manual_review' );

        do_action( 'caricove_dispatcher_manual_review_requested', $shipment_id, 'admin' );
        do_action( 'caricove_dispatcher_sent_inhouse', $shipment_id, 'admin_manual_review' );

        wp_safe_redirect( self::admin_url_page(array('shipment_id'=>$shipment_id,'notice'=>'manual_review_ok')) );
        exit;
    }

    public static function handle_clear_lock() {
        if ( ! current_user_can('manage_options') ) wp_die('Unauthorized');
        check_admin_referer('cc_scc_action','_cc_nonce');

        $shipment_id = isset($_GET['shipment_id']) ? intval($_GET['shipment_id']) : 0;
        if ( ! $shipment_id ) {
            wp_safe_redirect( self::admin_url_page(array('notice'=>'bad')) );
            exit;
        }

        $ov = self::get_overrides();
        unset( $ov['shipment_locks'][ $shipment_id ] );
        unset( $ov['shipment_forced_courier'][ $shipment_id ] );
        self::save_overrides( $ov );

        do_action( 'caricove_dispatcher_lock_cleared', $shipment_id, 'admin' );

        wp_safe_redirect( self::admin_url_page(array('shipment_id'=>$shipment_id,'notice'=>'clearlock_ok')) );
        exit;
    }

    public static function handle_reveal_code() {
        if ( ! self::can_reveal_codes() ) wp_die('Unauthorized');
        check_admin_referer('cc_scc_reveal','_cc_nonce');

        $shipment_id = isset($_POST['shipment_id']) ? intval($_POST['shipment_id']) : 0;
        $which       = isset($_POST['which']) ? sanitize_key($_POST['which']) : '';

        if ( ! $shipment_id || ! in_array($which, array('pickup','delivery'), true) ) {
            wp_safe_redirect( self::admin_url_page(array('notice'=>'bad')) );
            exit;
        }

        self::log_code_reveal( $shipment_id, $which );

        wp_safe_redirect( self::admin_url_page(array(
            'shipment_id' => $shipment_id,
            'notice'      => 'reveal_ok',
            'reveal'      => $which,
        )) );
        exit;
    }

    /* -----------------------------
     * Courier Radar (unchanged logic)
     * -------------------------- */

    private static function courier_role() {
        if ( class_exists('\Caricove\Logistics\Core\CourierProfile') ) {
            return \Caricove\Logistics\Core\CourierProfile::ROLE_COURIER;
        }
        return 'caricove_courier';
    }

private static function courier_profile( $uid ) {
    if ( class_exists('\Caricove\Logistics\Core\CourierProfile') ) {
        $p = \Caricove\Logistics\Core\CourierProfile::get_profile( $uid );
        if ( is_array($p) ) {
            $p['user_id'] = $uid;
            return $p;
        }
    }
    return array(
        'user_id'      => $uid,
        'status'       => self::um_str($uid, '_cc_courier_status', ''),
        'last_seen_ts' => self::um_int($uid, '_cc_last_seen_ts', 0),
        'last_lat'     => self::um_str($uid, '_cc_last_lat', ''),
        'last_lng'     => self::um_str($uid, '_cc_last_lng', ''),
        'vehicle_type' => self::um_str($uid, '_cc_vehicle_type', ''),
        'capacity_class'=> self::um_str($uid, '_cc_capacity_class', ''),
        'radius_km'    => floatval(self::um_str($uid, '_cc_radius_km', '0')),
'max_active_jobs'=> self::um_int($uid, '_caricove_courier_max_jobs', 5),            'region'       => self::um_str($uid, '_cc_region', ''),
        'perf_score'   => floatval(self::um_str($uid, '_cc_perf_score', '50')),
    );
}
    private static function size_rank() { return array('xs'=>0,'s'=>1,'m'=>2,'l'=>3,'xl'=>4); }

    private static function courier_can_carry( array $profile, $size_band, $weight_band, $settings ) {
        unset($settings);
        $size_band = sanitize_key((string)$size_band);
        $weight_band = sanitize_key((string)$weight_band);
        if ( class_exists('\Caricove\Logistics\Core\ZoneResolver') ) {
            $vehicle = \Caricove\Logistics\Core\ZoneResolver::normalize_vehicle_type( (string) ($profile['vehicle_type'] ?? '') );
            $allowed = \Caricove\Logistics\Core\ZoneResolver::is_vehicle_allowed_for_weight_band( $vehicle, $weight_band );
            $limit   = sanitize_key( (string) \Caricove\Logistics\Core\ZoneResolver::get_vehicle_size_rank_limit( $vehicle ) );
            $rank = self::size_rank();
            $cap_r = isset($rank[$limit]) ? $rank[$limit] : 2;
            $ship_r = isset($rank[$size_band]) ? $rank[$size_band] : 2;
            return $allowed && $ship_r <= $cap_r;
        }
        return true;
    }

    private static function courier_is_locked( $uid, array $profile ) {
        $lock_reason = isset($profile['lock_reason']) ? (string)$profile['lock_reason'] : '';
        $lock_expires_raw = isset($profile['lock_expires_at']) ? (string)$profile['lock_expires_at'] : '';

        if ( $lock_reason === '' ) {
            $lock_reason = self::um_str($uid, self::U_META_LOCK_REASON, '');
            $lock_expires_raw = self::um_str($uid, self::U_META_LOCK_EXPIRES, '');
        }
        if ( $lock_reason === '' ) return false;

        $now = time();
        $expires = $lock_expires_raw ? strtotime($lock_expires_raw) : 0;
        if ( ! $expires || $expires > $now ) return true;

        return false;
    }

    
private static function estimate_distance_km( array $profile, $pickup_coords ) {
    if ( class_exists('\Caricove\Logistics\Dispatcher\Scoring') ) {
        return \Caricove\Logistics\Dispatcher\Scoring::estimate_distance_km( $profile, $pickup_coords );
    }
    return 999999.0;
}

    
private static function courier_eligible_reasoned( array $shipment, array $profile, array $settings, array $overrides ) {
    if ( class_exists('\Caricove\Logistics\Dispatcher\CourierPool') && method_exists('\Caricove\Logistics\Dispatcher\CourierPool', 'evaluate_courier') ) {
        $evaluation = \Caricove\Logistics\Dispatcher\CourierPool::evaluate_courier( $profile, $shipment, $settings, $overrides );
        $reason = sanitize_key( (string) ( $evaluation['reason'] ?? 'unknown' ) );
        $map = array(
            'eligible'                     => 'ok',
            'courier_blocked'              => 'blocked',
            'offline'                      => 'offline',
            'heartbeat_stale'              => 'stale_heartbeat',
            'courier_locked'               => 'locked',
            'vehicle_capacity_mismatch'    => ! empty( $evaluation['carry_failure_reason'] ) ? sanitize_key( (string) $evaluation['carry_failure_reason'] ) : 'vehicle_capacity',
            'max_active_jobs_reached'      => 'max_jobs',
            'pickup_distance_exceeded'     => 'pickup_distance_exceeded',
            'distance_preference_exceeded' => 'distance_preference_exceeded',
            'already_declined_this_cycle'  => 'declined_this_cycle',
            'zone_restriction_failed'      => 'zone',
            'vendor_manual_only'           => 'vendor_manual_only',
            'vendor_blocked'               => 'vendor_blocked',
            'shipment_locked'              => 'shipment_locked',
            'forced_to_other_courier'      => 'forced_elsewhere',
            'pickup_coords_missing'        => 'missing_pickup_coords',
            'profile_empty'                => 'profile_empty',
        );
        $why = isset($map[$reason]) ? $map[$reason] : $reason;
        return array( ! empty($evaluation['eligible']), $why, $evaluation );
    }

    $distance_km = self::estimate_distance_km( $profile, (string) ($shipment['pickup_coords'] ?? '') );
    $details = array(
        'eligible'               => false,
        'reason'                 => 'unknown',
        'pickup_distance_km'     => $distance_km,
        'pickup_distance_cap_km' => floatval( $profile['radius_km'] ?? 0 ),
        'active_jobs'            => self::get_active_jobs_count_like_logistics( intval($profile['user_id'] ?? 0) ),
        'max_active_jobs'        => max(1, intval($profile['max_active_jobs'] ?? 5)),
        'preference_band'        => '',
        'shipment_band'          => sanitize_key( (string) ($shipment['distance_band'] ?? $shipment['trip_band'] ?? '') ),
    );

    return array(false, 'unknown', $details);
}

    
private static function build_courier_radar( $pickup_coords, array $shipment, array $settings, array $overrides, $limit = 15 ) {
    $role = self::courier_role();

    $reasons_count = array(
        'ok'                          => 0,
        'blocked'                     => 0,
        'offline'                     => 0,
        'stale_heartbeat'             => 0,
        'locked'                      => 0,
        'vehicle_capacity'            => 0,
        'vehicle_band_blocked'        => 0,
        'numeric_weight_cap_exceeded' => 0,
        'size_band_blocked'           => 0,
        'max_jobs'                    => 0,
        'pickup_distance_exceeded'    => 0,
        'distance_preference_exceeded'=> 0,
        'declined_this_cycle'         => 0,
        'zone'                        => 0,
        'missing_pickup_coords'       => 0,
        'vendor_manual_only'          => 0,
        'vendor_blocked'              => 0,
        'forced_elsewhere'            => 0,
        'shipment_locked'             => 0,
        'unknown'                     => 0,
    );

    $rows = array();

    if ( class_exists('\Caricove\Logistics\Dispatcher\CourierPool') && method_exists('\Caricove\Logistics\Dispatcher\CourierPool', 'get_candidate_diagnostics') ) {
        $shipment_ctx = $shipment;
        $shipment_ctx['pickup_coords'] = $pickup_coords;

        $diagnostics = \Caricove\Logistics\Dispatcher\CourierPool::get_candidate_diagnostics( $shipment_ctx, $settings, $overrides, array() );
        foreach ( (array) $diagnostics as $row ) {
            $profile    = is_array( $row['profile'] ?? null ) ? $row['profile'] : array();
            $evaluation = is_array( $row['evaluation'] ?? null ) ? $row['evaluation'] : array();
            $score      = is_array( $row['score'] ?? null ) ? $row['score'] : array();
            $uid        = intval( $row['user_id'] ?? $profile['id'] ?? 0 );

            list( $ok, $why_ui, $details ) = self::courier_eligible_reasoned( $shipment_ctx, $profile, $settings, $overrides );
            if ( ! is_array($details) ) $details = $evaluation;

            $trust_score = self::um_int($uid, self::U_META_TRUST_SCORE, 0);
            $trust_tier  = sanitize_key( self::um_str($uid, self::U_META_TRUST_TIER, 'starter') );

            $rows[] = array(
                'user_id'         => $uid,
                'name'            => (string) ($profile['display_name'] ?? ''),
                'status'          => sanitize_key( (string) ($profile['status'] ?? '') ),
                'last_seen_ts'    => intval( $profile['last_seen_ts'] ?? 0 ),
                'last_lat'        => (string) ($profile['last_lat'] ?? ''),
                'last_lng'        => (string) ($profile['last_lng'] ?? ''),
                'vehicle'         => sanitize_key( (string) ($profile['vehicle_type'] ?? '') ),
                'capacity'        => sanitize_key( (string) ($profile['capacity_class'] ?? '') ),
                'preference_band' => sanitize_key( (string) ($details['preference_band'] ?? '') ),
                'shipment_band'   => sanitize_key( (string) ($details['shipment_band'] ?? $shipment_ctx['distance_band'] ?? $shipment_ctx['trip_band'] ?? '') ),
                'active_jobs'     => intval( $details['active_jobs'] ?? self::get_active_jobs_count_like_logistics( $uid ) ),
                'max_active_jobs' => intval( $details['max_active_jobs'] ?? max(1, intval($profile['max_active_jobs'] ?? 5)) ),
                'trust_score'     => $trust_score,
                'trust_tier'      => $trust_tier,
                'distance_km'     => array_key_exists('pickup_distance_km', $details) ? floatval($details['pickup_distance_km']) : null,
                'pickup_cap_km'   => floatval( $details['pickup_distance_cap_km'] ?? 0 ),
                'eligible'        => $ok,
                'why'             => $why_ui ?: 'unknown',
                'score_total'     => floatval( $score['total'] ?? 0 ),
                'score_breakdown' => $score,
            );

            if ( isset($reasons_count[$why_ui]) ) $reasons_count[$why_ui]++; else $reasons_count[$why_ui] = 1;
        }
    } else {
        $q = new WP_User_Query(array(
            'role'    => $role,
            'number'  => 500,
            'fields'  => array('ID','display_name','user_email'),
            'orderby' => 'ID',
            'order'   => 'ASC',
        ));

        foreach ( (array) $q->get_results() as $u ) {
            $uid = intval($u->ID);
            if ( ! $uid ) continue;

            $profile = self::courier_profile($uid);
            $profile['display_name'] = $u->display_name;

            $shipment_ctx = $shipment;
            $shipment_ctx['pickup_coords'] = $pickup_coords;

            list($ok, $why, $details) = self::courier_eligible_reasoned($shipment_ctx, $profile, $settings, $overrides);

            $trust_score = self::um_int($uid, self::U_META_TRUST_SCORE, 0);
            $trust_tier  = sanitize_key( self::um_str($uid, self::U_META_TRUST_TIER, 'starter') );

            $rows[] = array(
                'user_id'         => $uid,
                'name'            => $u->display_name,
                'status'          => sanitize_key( isset($profile['status']) ? $profile['status'] : '' ),
                'last_seen_ts'    => isset($profile['last_seen_ts']) ? intval($profile['last_seen_ts']) : 0,
                'last_lat'        => isset($profile['last_lat']) ? $profile['last_lat'] : '',
                'last_lng'        => isset($profile['last_lng']) ? $profile['last_lng'] : '',
                'vehicle'         => sanitize_key( isset($profile['vehicle_type']) ? $profile['vehicle_type'] : '' ),
                'capacity'        => sanitize_key( isset($profile['capacity_class']) ? $profile['capacity_class'] : '' ),
                'preference_band' => sanitize_key( (string) ($details['preference_band'] ?? '') ),
                'shipment_band'   => sanitize_key( (string) ($details['shipment_band'] ?? '') ),
                'active_jobs'     => intval( $details['active_jobs'] ?? self::get_active_jobs_count_like_logistics( $uid ) ),
                'max_active_jobs' => intval( $details['max_active_jobs'] ?? max(1, intval($profile['max_active_jobs'] ?? 5)) ),
                'trust_score'     => $trust_score,
                'trust_tier'      => $trust_tier,
                'distance_km'     => array_key_exists('pickup_distance_km', $details) ? floatval($details['pickup_distance_km']) : null,
                'pickup_cap_km'   => floatval( $details['pickup_distance_cap_km'] ?? 0 ),
                'eligible'        => $ok,
                'why'             => $why,
                'score_total'     => 0.0,
                'score_breakdown' => array(),
            );

            if ( isset($reasons_count[$why]) ) $reasons_count[$why]++; else $reasons_count[$why] = 1;
        }

        usort($rows, function($a,$b){
            if ( $a['eligible'] !== $b['eligible'] ) return $a['eligible'] ? -1 : 1;

            $ad = is_null($a['distance_km']) ? 999999 : floatval($a['distance_km']);
            $bd = is_null($b['distance_km']) ? 999999 : floatval($b['distance_km']);
            if ( $ad !== $bd ) return ($ad < $bd) ? -1 : 1;

            $al = intval($a['last_seen_ts']);
            $bl = intval($b['last_seen_ts']);
            return ($al > $bl) ? -1 : 1;
        });
    }

    return array(
        'rows'    => array_slice($rows, 0, max(1, intval($limit))),
        'counts'  => $reasons_count,
        'total'   => count($rows),
    );
}

    /* -----------------------------
     * UI
     * -------------------------- */

    public static function render_page() {
        if ( ! current_user_can('manage_options') ) return;

        $shipment_id = isset($_GET['shipment_id']) ? intval($_GET['shipment_id']) : 0;
        $notice_key  = isset($_GET['notice']) ? sanitize_key( wp_unslash($_GET['notice']) ) : '';
        $reveal      = isset($_GET['reveal']) ? sanitize_key( wp_unslash($_GET['reveal']) ) : '';

        $notice_map = array(
            'retry_ok'     => '✅ Redispatch triggered.',
            'force_ok'     => '✅ Forced courier saved (and retry triggered).',
            'inhouse_ok'   => '✅ Sent to Manual Review.',
            'manual_review_ok' => '✅ Sent to Manual Review.',
            'clearlock_ok' => '✅ Shipment lock cleared.',
            'reveal_ok'    => '✅ Code revealed (audit logged).',
            'bad'          => '⚠️ Something went wrong.',
        );
        $notice = isset($notice_map[$notice_key]) ? $notice_map[$notice_key] : '';

        $settings  = self::get_settings();
        $overrides = self::get_overrides();

        $shipment = null;
        $summary  = array();

        if ( $shipment_id ) {
            $shipment = get_post( $shipment_id );
            if ( $shipment && get_post_type($shipment_id) === self::shipment_cpt() ) {
                $summary = self::get_shipment_summary_safe($shipment_id);
            } else {
                $shipment = null;
            }
        }

        if ( ! $shipment ) {
            ?>
            <div class="wrap">
                <h1>Shipment Command Center</h1>
                <p class="description">Enter a shipment ID to open the single-pane ops view.</p>
                <?php echo self::styles(); ?>
                <div class="ccSCC">
                    <?php if ( $notice ) : ?>
                        <div class="ccSCC-note <?php echo $notice_key==='bad'?'bad':'ok'; ?>"><?php echo esc_html($notice); ?></div>
                    <?php endif; ?>

                    <div class="ccSCC-head">
                        <div class="ccSCC-title">Dispatcher <span>Shipment Command Center</span></div>
                        <div class="ccSCC-pill mono">CPT: <?php echo esc_html(self::shipment_cpt()); ?></div>
                    </div>

                    <form method="get" action="<?php echo esc_url(admin_url('admin.php')); ?>" class="ccSCC-search">
                        <input type="hidden" name="page" value="<?php echo esc_attr(self::PAGE_SLUG); ?>">
                        <input class="ccSCC-input" type="number" name="shipment_id" placeholder="Shipment ID (e.g. 15099)" required>
                        <button class="ccSCC-btn" type="submit">Open</button>
                    </form>
                </div>
            </div>
            <?php
            return;
        }

        /* ---------------------------------------------------------
         * SUMMARY-FIRST MAPPING (THIS FIXES YOUR EMPTY FIELDS)
         * ------------------------------------------------------ */

        // Shipment fields
        $status      = sanitize_key( $summary['status'] ?? self::pm_str($shipment_id, self::META_STATUS, '' ) );
        $order_id    = intval( $summary['order_id'] ?? self::pm_int($shipment_id, self::META_ORDER_ID, 0 ) );
        $vendor_id   = intval( $summary['vendor_id'] ?? self::pm_int($shipment_id, self::META_VENDOR_ID, 0 ) );
        $courier_id  = intval( $summary['courier_id'] ?? $summary['assigned_courier_id'] ?? self::pm_int($shipment_id, self::META_ASSIGNED_COURIER, 0 ) );

        $origin      = sanitize_key( $summary['origin_anchor'] ?? self::pm_str($shipment_id, self::META_ORIGIN_ANCHOR, '' ) );
        $dest        = sanitize_key( $summary['destination_anchor'] ?? $summary['dest_anchor'] ?? self::pm_str($shipment_id, self::META_DEST_ANCHOR, '' ) );

        $size_band   = sanitize_key( $summary['size_band'] ?? self::pm_str($shipment_id, self::META_SIZE_BAND, '' ) );
        $weight_band = sanitize_key( $summary['weight_band'] ?? self::pm_str($shipment_id, self::META_WEIGHT_BAND, '' ) );

        $pickup_coords  = (string) ( $summary['pickup_coords'] ?? self::pm_str($shipment_id, self::META_PICKUP_COORDS, '' ) );
        $dropoff_coords = (string) ( $summary['dropoff_coords'] ?? self::pm_str($shipment_id, self::META_DROPOFF_COORDS, '' ) );

        $pickup_code   = (string) ( $summary['pickup_code'] ?? self::pm_str($shipment_id, self::META_PICKUP_CODE, '' ) );
        $delivery_code = (string) ( $summary['delivery_code'] ?? self::pm_str($shipment_id, self::META_DELIVERY_CODE, '' ) );

        // Ops metrics (meta fallback)
        $attempts   = self::pm_int($shipment_id, self::META_ATTEMPTS, 0 );
        $cand_count = self::pm_int($shipment_id, self::META_LAST_CAND_COUNT, 0 );
        $hold_reason = (string) self::pm_str($shipment_id, self::META_HOLD_REASON, '' );

        // Summary extras (nice to show, but keep UI stable)
        $declared_value = isset($summary['declared_value']) ? intval($summary['declared_value']) : 0;
        $eta            = isset($summary['eta']) ? (string)$summary['eta'] : '';
        $sla_deadline   = isset($summary['sla_deadline']) ? (string)$summary['sla_deadline'] : '';
        $sla_risk       = isset($summary['sla_risk']) ? (float)$summary['sla_risk'] : null;
        $last_change_at = isset($summary['last_status_change_at']) ? (string)$summary['last_status_change_at'] : '';
        $quote_distance_km = isset($summary['quote_distance_km']) ? floatval($summary['quote_distance_km']) : 0.0;
        $quote_duration_seconds = isset($summary['quote_duration_seconds']) ? intval($summary['quote_duration_seconds']) : 0;
        $quote_total_gyd = isset($summary['quote_total_gyd']) ? floatval($summary['quote_total_gyd']) : 0.0;
        $distance_band = sanitize_key( (string) ($summary['distance_band'] ?? $summary['trip_band'] ?? '') );
        $trip_band = sanitize_key( (string) ($summary['trip_band'] ?? $summary['distance_band'] ?? '') );
        $route_source = sanitize_key( (string) ($summary['route_source'] ?? '') );
        $route_detail_source = sanitize_key( (string) ($summary['route_detail_source'] ?? '') );
        $route_provenance = sanitize_key( (string) ($summary['route_provenance'] ?? '') );
        $planner_has_truth = ! empty($summary['planner_has_truth']);
        $route_fallback_used = ! empty($summary['route_fallback_used']);
        $actual_weight_kg = isset($summary['total_weight']) ? floatval($summary['total_weight']) : 0.0;
        $dim_weight_kg = isset($summary['dim_weight']) ? floatval($summary['dim_weight']) : 0.0;
        $effective_weight_kg = isset($summary['effective_weight']) ? floatval($summary['effective_weight']) : max($actual_weight_kg, $dim_weight_kg);
        $longest_side_cm = isset($summary['longest_side_cm']) ? floatval($summary['longest_side_cm']) : 0.0;
        $volume_cm3 = isset($summary['volume_cm3']) ? floatval($summary['volume_cm3']) : 0.0;
        $recommended_vehicle = sanitize_key( (string) ($summary['recommended_vehicle'] ?? '') );
        $weight_band_upper_map = array( 'light' => 8.0, 'medium' => 20.0, 'heavy' => 80.0, 'extra_heavy' => max( 80.0, $effective_weight_kg ) );
        $size_band_upper_map = array( 's' => 35.0, 'm' => 60.0, 'l' => 120.0, 'xl' => max( 120.0, $longest_side_cm ) );
        $weight_progress_pct = 0.0;
        $size_progress_pct   = 0.0;
        if ( $weight_band && isset( $weight_band_upper_map[ $weight_band ] ) && $weight_band_upper_map[ $weight_band ] > 0 ) {
            $weight_progress_pct = min( 100.0, max( 0.0, ( $effective_weight_kg / $weight_band_upper_map[ $weight_band ] ) * 100.0 ) );
        }
        if ( $size_band && isset( $size_band_upper_map[ $size_band ] ) && $size_band_upper_map[ $size_band ] > 0 ) {
            $size_progress_pct = min( 100.0, max( 0.0, ( $longest_side_cm / $size_band_upper_map[ $size_band ] ) * 100.0 ) );
        }
        $capacity_card_explanation = 'This shipment is classified using actual weight, dimensional weight, longest side, and total volume.';
        if ( $dim_weight_kg > $actual_weight_kg ) {
            $capacity_card_explanation = 'Dimensional weight exceeds actual weight, so dispatcher capacity decisions use the higher effective weight.';
        }
        if ( $size_band === 'xl' ) {
            $capacity_card_explanation .= ' Size class is XL, so the vehicle floor rises to truck.';
        } elseif ( $recommended_vehicle ) {
            $capacity_card_explanation .= ' Recommended vehicle is ' . str_replace('_', ' ', $recommended_vehicle) . ' because it satisfies both size and effective-weight constraints.';
        }

        // Vendor/customer from summary (authoritative)
        $pickup_name  = (string) ($summary['pickup_name'] ?? '');
        $pickup_phone = (string) ($summary['pickup_phone'] ?? '');

        $dropoff_name  = (string) ($summary['dropoff_name'] ?? '');
        $dropoff_phone = (string) ($summary['dropoff_phone'] ?? '');

        $pickup_addr_arr  = isset($summary['pickup_address']) && is_array($summary['pickup_address']) ? $summary['pickup_address'] : array();
        $dropoff_addr_arr = isset($summary['dropoff_address']) && is_array($summary['dropoff_address']) ? $summary['dropoff_address'] : array();

        $vendor_fmt = self::fmt_addr($pickup_addr_arr);
        $cust_fmt   = self::fmt_addr($dropoff_addr_arr);

        // Order object (for placed time + email)
        $order = null;
        if ( $order_id && function_exists('wc_get_order') ) {
            $order = wc_get_order($order_id);
        }

        $order_placed = '';
        $customer_email = '';
        $customer_phone = $dropoff_phone; // summary is best
        $customer_name  = $dropoff_name;

        if ( $order ) {
            $order_placed   = $order->get_date_created() ? $order->get_date_created()->date('Y-m-d H:i:s') : '';
            $customer_email = $order->get_billing_email();
            // if summary dropoff phone missing, fallback to billing phone
            if ( $customer_phone === '' ) $customer_phone = (string)$order->get_billing_phone();
            // if summary name missing, fallback to billing full name
            if ( $customer_name === '' ) $customer_name = (string)$order->get_formatted_billing_full_name();
        }

        // Vendor email fallback from user (summary may not include)
        $vendor_email = '';
        if ( $vendor_id ) {
            $vu = get_userdata($vendor_id);
            if ( $vu ) $vendor_email = $vu->user_email;
        }

        // Codes reveal flags
        $pickup_code_show   = ($reveal === 'pickup')   ? ($pickup_code ?: '—')   : self::mask_code($pickup_code);
        $delivery_code_show = ($reveal === 'delivery') ? ($delivery_code ?: '—') : self::mask_code($delivery_code);

        // Assigned courier (summary uses courier_id)
        $courier_name = '';
        $courier_status = '';
        $courier_last_seen = 0;
        $courier_last_lat = '';
        $courier_last_lng = '';
        $courier_vehicle = '';
        $courier_capacity = '';
        $courier_trust_score = 0;
        $courier_trust_tier = 'starter';
        $courier_active_jobs = 0;
        $courier_distance_to_pickup = null;

        if ( $courier_id ) {
            $cu = get_userdata($courier_id);
            if ( $cu ) $courier_name = $cu->display_name;

            $cp = self::courier_profile($courier_id);
            $courier_status = sanitize_key( $cp['status'] ?? '' );
            $courier_last_seen = intval( $cp['last_seen_ts'] ?? 0 );
            $courier_last_lat = (string) ($cp['last_lat'] ?? '');
            $courier_last_lng = (string) ($cp['last_lng'] ?? '');
            $courier_vehicle = sanitize_key( $cp['vehicle_type'] ?? '' );
            $courier_capacity = sanitize_key( $cp['capacity_class'] ?? '' );

            $courier_trust_score = self::um_int($courier_id, self::U_META_TRUST_SCORE, 0);
            $courier_trust_tier  = sanitize_key( self::um_str($courier_id, self::U_META_TRUST_TIER, 'starter') );

$courier_active_jobs = 0;

if (
    class_exists('\Caricove\Logistics\Core\AutoAssign') &&
    method_exists('\Caricove\Logistics\Core\AutoAssign', 'get_courier_active_job_count')
) {
    $courier_active_jobs = (int) \Caricove\Logistics\Core\AutoAssign::get_courier_active_job_count( $courier_id );
} else {
    $courier_active_jobs = (int) self::get_active_jobs_count_like_logistics( $courier_id );
}
            if ( $pickup_coords !== '' ) {
                $courier_distance_to_pickup = self::estimate_distance_km($cp, $pickup_coords);
            }
        }

        // Radar uses summary pickup coords
        $radar = self::build_courier_radar(
            $pickup_coords,
            array_merge(
                $summary,
                array(
                    'shipment_id'         => $shipment_id,
                    'size_band'           => $size_band,
                    'weight_band'         => $weight_band,
                    'origin_anchor'       => $origin,
                    'destination_anchor'  => $dest,
                    'pickup_coords'       => $pickup_coords,
                    'distance_band'       => $distance_band,
                    'trip_band'           => $trip_band,
                    'route_source'        => $route_source,
                    'route_detail_source' => $route_detail_source,
                    'route_provenance'    => $route_provenance,
                )
            ),
            $settings,
            $overrides,
            15
        );

        // Action URLs
        $retry_url = wp_nonce_url(
            self::admin_url_page(array('shipment_id'=>$shipment_id)) . '&action=cc_scc_retry',
            'cc_scc_action',
            '_cc_nonce'
        );
        $inhouse_url = wp_nonce_url(
            self::admin_url_page(array('shipment_id'=>$shipment_id)) . '&action=cc_scc_manual_review',
            'cc_scc_action',
            '_cc_nonce'
        );
        $clearlock_url = wp_nonce_url(
            self::admin_url_page(array('shipment_id'=>$shipment_id)) . '&action=cc_scc_clear_lock',
            'cc_scc_action',
            '_cc_nonce'
        );

        ?>
        <div class="wrap">
            <h1>Shipment Command Center</h1>
            <p class="description">Single-pane ops view driven by Core summary (so it matches Logistics Admin perfectly).</p>

            <?php echo self::styles(); ?>

            <div class="ccSCC">

                <div class="ccSCC-head">
                    <div class="ccSCC-title">Dispatcher <span>Shipment Command Center</span></div>

                    <form method="get" action="<?php echo esc_url(admin_url('admin.php')); ?>" class="ccSCC-search">
                        <input type="hidden" name="page" value="<?php echo esc_attr(self::PAGE_SLUG); ?>">
                        <input class="ccSCC-input" type="number" name="shipment_id" value="<?php echo esc_attr($shipment_id); ?>" placeholder="Shipment ID" required>
                        <button class="ccSCC-btn" type="submit">Open</button>
                        <a class="ccSCC-btn alt" href="<?php echo esc_url(self::admin_url_page()); ?>">Reset</a>
                    </form>
                </div>

                <?php if ( $notice ) : ?>
                    <div class="ccSCC-note <?php echo $notice_key==='bad'?'bad':'ok'; ?>"><?php echo esc_html($notice); ?></div>
                <?php endif; ?>

                <div class="ccSCC-bar">
                    <div class="ccSCC-chip mono">Shipment #<?php echo esc_html($shipment_id); ?></div>

                    <div class="ccSCC-chip <?php echo $status ? 'red' : 'gray'; ?>">
                        Status: <strong><?php echo esc_html($status ?: '—'); ?></strong>
                    </div>

                    <div class="ccSCC-chip purple">
                        Lane: <strong><?php echo esc_html(($origin?:'—') . ' → ' . ($dest?:'—')); ?></strong>
                    </div>

                    <div class="ccSCC-chip gold">
                        Size/Weight: <strong><?php echo esc_html(($size_band?:'—') . '/' . ($weight_band?:'—')); ?></strong>
                    </div>

                    <div class="ccSCC-chip gray">
                        Attempts: <strong><?php echo esc_html($attempts); ?></strong>
                    </div>

                    <div class="ccSCC-chip gray">
                        Candidates: <strong><?php echo esc_html($cand_count); ?></strong>
                    </div>

                    <?php if ( $hold_reason ) : ?>
                        <div class="ccSCC-chip red">
                            HOLD: <strong><?php echo esc_html($hold_reason); ?></strong>
                        </div>
                    <?php endif; ?>

                    <div class="ccSCC-actions">
                        <a class="ccSCC-btn good" href="<?php echo esc_url($retry_url); ?>">Retry</a>
                        <a class="ccSCC-btn danger" href="<?php echo esc_url($inhouse_url); ?>">Manual Review</a>
                        <a class="ccSCC-btn alt" href="<?php echo esc_url($clearlock_url); ?>">Clear Lock</a>
                    </div>
                </div>

                <div class="ccSCC-grid">

                    <!-- Shipment -->
                    <div class="ccSCC-card">
                        <h2>Shipment</h2>
                        <div class="ccSCC-kv">
                            <div><span class="k">Shipment ID</span><span class="v mono">#<?php echo esc_html($shipment_id); ?></span></div>
                            <div><span class="k">Order</span><span class="v mono"><?php echo $order_id ? '#'.esc_html($order_id) : '—'; ?></span></div>
                            <div><span class="k">Order placed</span><span class="v"><?php echo esc_html($order_placed ?: '—'); ?></span></div>
                            <div><span class="k">Pickup coords</span><span class="v mono"><?php echo esc_html($pickup_coords ?: '—'); ?></span></div>
                            <div><span class="k">Dropoff coords</span><span class="v mono"><?php echo esc_html($dropoff_coords ?: '—'); ?></span></div>
                            <div><span class="k">Declared value</span><span class="v mono"><?php echo $declared_value ? esc_html($declared_value) : '—'; ?></span></div>
                            <div><span class="k">Quote distance</span><span class="v mono"><?php echo $quote_distance_km > 0 ? esc_html(number_format_i18n($quote_distance_km, 2) . ' km') : '—'; ?></span></div>
                            <div><span class="k">Quote duration</span><span class="v mono"><?php echo $quote_duration_seconds > 0 ? esc_html(gmdate('H:i:s', $quote_duration_seconds)) : '—'; ?></span></div>
                            <div><span class="k">Quote total</span><span class="v mono"><?php echo $quote_total_gyd > 0 ? esc_html(number_format_i18n($quote_total_gyd, 2) . ' GYD') : '—'; ?></span></div>
                            <div><span class="k">Distance band</span><span class="v mono"><?php echo esc_html($distance_band ?: '—'); ?></span></div>
                            <div><span class="k">Trip band</span><span class="v mono"><?php echo esc_html($trip_band ?: '—'); ?></span></div>
                            <div><span class="k">Route source</span><span class="v mono"><?php echo esc_html($route_source ?: '—'); ?></span></div>
                            <div><span class="k">Route provenance</span><span class="v mono"><?php echo esc_html($route_provenance ?: ($route_detail_source ?: '—')); ?></span></div>
                            <div><span class="k">ETA</span><span class="v mono"><?php echo esc_html($eta ?: '—'); ?></span></div>
                            <div><span class="k">SLA</span><span class="v mono"><?php echo esc_html($sla_deadline ?: '—'); ?></span></div>
                            <div><span class="k">SLA risk</span><span class="v mono"><?php echo is_null($sla_risk) ? '—' : esc_html(number_format_i18n($sla_risk, 3)); ?></span></div>
                            <div><span class="k">Last change</span><span class="v mono"><?php echo esc_html($last_change_at ?: '—'); ?></span></div>
                        </div>

                        <div class="ccSCC-mini muted">
                            Planner truth hydrates this panel first. Source: <strong><?php echo esc_html($route_source ?: '—'); ?></strong>,
                            provenance: <strong><?php echo esc_html($route_provenance ?: ($route_detail_source ?: '—')); ?></strong>,
                            planner truth: <strong><?php echo $planner_has_truth ? 'yes' : 'no'; ?></strong>,
                            fallback used: <strong><?php echo $route_fallback_used ? 'yes' : 'no'; ?></strong>.
                        </div>
                    </div>

                    <!-- Capacity & Classification -->
                    <div class="ccSCC-card">
                        <h2>Capacity &amp; Classification</h2>
                        <div class="ccSCC-kv">
                            <div><span class="k">Actual weight</span><span class="v mono"><?php echo esc_html( number_format_i18n( $actual_weight_kg, 2 ) . ' kg' ); ?></span></div>
                            <div><span class="k">Dimensional weight</span><span class="v mono"><?php echo esc_html( number_format_i18n( $dim_weight_kg, 2 ) . ' kg' ); ?></span></div>
                            <div><span class="k">Effective weight</span><span class="v mono"><?php echo esc_html( number_format_i18n( $effective_weight_kg, 2 ) . ' kg' ); ?></span></div>
                            <div><span class="k">Longest side</span><span class="v mono"><?php echo $longest_side_cm > 0 ? esc_html( number_format_i18n( $longest_side_cm, 2 ) . ' cm' ) : '—'; ?></span></div>
                            <div><span class="k">Volume</span><span class="v mono"><?php echo $volume_cm3 > 0 ? esc_html( number_format_i18n( $volume_cm3, 0 ) . ' cm³' ) : '—'; ?></span></div>
                            <div><span class="k">Weight band</span><span class="v mono"><?php echo esc_html( strtoupper( $weight_band ?: '—' ) ); ?></span></div>
                            <div><span class="k">Size band</span><span class="v mono"><?php echo esc_html( strtoupper( $size_band ?: '—' ) ); ?></span></div>
                            <div><span class="k">Route band</span><span class="v mono"><?php echo esc_html( $trip_band ?: '—' ); ?></span></div>
                            <div><span class="k">Recommended vehicle</span><span class="v mono"><?php echo esc_html( $recommended_vehicle ?: '—' ); ?></span></div>
                        </div>
                        <div class="ccSCC-load" style="margin-top:12px;">
                            <div class="ccSCC-load-label">Weight Load</div>
                            <div class="ccSCC-loadbar"><span style="width:<?php echo esc_attr( number_format( $weight_progress_pct, 1, '.', '' ) ); ?>%"></span></div>
                            <div class="ccSCC-load-meta mono"><?php echo esc_html( number_format_i18n( $effective_weight_kg, 2 ) . ' / ' . number_format_i18n( floatval( $weight_band_upper_map[ $weight_band ] ?? 0 ), 0 ) . ' kg' ); ?></div>
                        </div>
                        <div class="ccSCC-load" style="margin-top:12px;">
                            <div class="ccSCC-load-label">Size Load</div>
                            <div class="ccSCC-loadbar size"><span style="width:<?php echo esc_attr( number_format( $size_progress_pct, 1, '.', '' ) ); ?>%"></span></div>
                            <div class="ccSCC-load-meta mono"><?php echo esc_html( number_format_i18n( $longest_side_cm, 2 ) . ' / ' . number_format_i18n( floatval( $size_band_upper_map[ $size_band ] ?? 0 ), 0 ) . ' cm' ); ?></div>
                        </div>
                        <div class="ccSCC-mini" style="margin-top:12px; font-weight:800; opacity:.95;">
                            <?php echo esc_html( $capacity_card_explanation ); ?>
                        </div>
                    </div>

                    <!-- Vendor -->
                    <div class="ccSCC-card">
                        <h2>Vendor</h2>
                        <div class="ccSCC-kv">
                            <div><span class="k">Vendor ID</span><span class="v mono"><?php echo $vendor_id ? '#'.esc_html($vendor_id) : '—'; ?></span></div>
                            <div><span class="k">Name</span><span class="v"><?php echo esc_html($pickup_name ?: '—'); ?></span></div>
                            <div><span class="k">Phone</span><span class="v mono"><?php echo esc_html($pickup_phone ?: '—'); ?></span></div>
                            <div><span class="k">Email</span><span class="v"><?php echo esc_html($vendor_email ?: '—'); ?></span></div>
                            <div><span class="k">Zone</span><span class="v mono"><?php echo esc_html($origin ?: '—'); ?></span></div>
                            <div><span class="k">Coords</span><span class="v mono"><?php echo esc_html($pickup_coords ?: '—'); ?></span></div>
                            <div><span class="k">Address</span><span class="v"><?php echo esc_html($vendor_fmt ?: '—'); ?></span></div>
                        </div>
                    </div>

                    <!-- Customer -->
                    <div class="ccSCC-card">
                        <h2>Customer</h2>
                        <div class="ccSCC-kv">
                            <div><span class="k">Name</span><span class="v"><?php echo esc_html($customer_name ?: '—'); ?></span></div>
                            <div><span class="k">Email</span><span class="v"><?php echo esc_html($customer_email ?: '—'); ?></span></div>
                            <div><span class="k">Phone</span><span class="v mono"><?php echo esc_html($customer_phone ?: '—'); ?></span></div>
                            <div><span class="k">Zone</span><span class="v mono"><?php echo esc_html($dest ?: '—'); ?></span></div>
                            <div><span class="k">Coords</span><span class="v mono"><?php echo esc_html($dropoff_coords ?: '—'); ?></span></div>
                            <div><span class="k">Address</span><span class="v"><?php echo esc_html($cust_fmt ?: '—'); ?></span></div>
                        </div>
                    </div>

                    <!-- Codes Vault -->
                    <div class="ccSCC-card">
                        <h2>Codes Vault</h2>

                        <div class="ccSCC-codebox">
                            <div class="row">
                                <div class="label">Pickup code</div>
                                <div class="code mono"><?php echo esc_html($pickup_code_show); ?></div>
                            </div>

                            <div class="row">
                                <div class="label">Delivery code</div>
                                <div class="code mono"><?php echo esc_html($delivery_code_show); ?></div>
                            </div>

                            <div class="ccSCC-mini muted">
                                Codes are masked by default. Revealing writes an audit entry.
                            </div>

                            <div class="ccSCC-actions">
                                <?php if ( self::can_reveal_codes() ) : ?>
                                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:inline;">
                                        <?php wp_nonce_field('cc_scc_reveal','_cc_nonce'); ?>
                                        <input type="hidden" name="action" value="cc_scc_reveal_code">
                                        <input type="hidden" name="shipment_id" value="<?php echo esc_attr($shipment_id); ?>">
                                        <input type="hidden" name="which" value="pickup">
                                        <button class="ccSCC-btn alt" type="submit">Reveal pickup</button>
                                    </form>

                                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:inline;">
                                        <?php wp_nonce_field('cc_scc_reveal','_cc_nonce'); ?>
                                        <input type="hidden" name="action" value="cc_scc_reveal_code">
                                        <input type="hidden" name="shipment_id" value="<?php echo esc_attr($shipment_id); ?>">
                                        <input type="hidden" name="which" value="delivery">
                                        <button class="ccSCC-btn alt" type="submit">Reveal delivery</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <!-- Assigned Courier -->
                    <div class="ccSCC-card">
                        <h2>Assigned Courier</h2>

                        <div class="ccSCC-kv">
                            <div><span class="k">Courier</span><span class="v mono"><?php echo $courier_id ? '#'.esc_html($courier_id) : '—'; ?></span></div>
                            <div><span class="k">Name</span><span class="v"><?php echo esc_html($courier_name ?: '—'); ?></span></div>
                            <div><span class="k">Status</span><span class="v"><?php echo esc_html($courier_status ?: '—'); ?></span></div>
                            <div><span class="k">Last heartbeat</span><span class="v mono"><?php echo $courier_last_seen ? esc_html(self::age_human($courier_last_seen) . ' ago') : '—'; ?></span></div>
                            <div><span class="k">Location</span><span class="v mono"><?php echo esc_html(($courier_last_lat!=='' && $courier_last_lng!=='') ? ($courier_last_lat.','.$courier_last_lng) : '—'); ?></span></div>
                            <div><span class="k">Vehicle / cap</span><span class="v mono"><?php $assigned_cap = class_exists('\\Caricove\\Logistics\\Core\\ZoneResolver') ? \Caricove\Logistics\Core\ZoneResolver::get_vehicle_weight_cap_kg($courier_vehicle) : 0; echo esc_html(($courier_vehicle?:'—') . ' / ' . ($assigned_cap ? number_format_i18n($assigned_cap, 0) . 'kg' : '—')); ?></span></div>
                            <div><span class="k">Active jobs</span><span class="v mono"><?php echo esc_html($courier_active_jobs); ?></span></div>
                            <div><span class="k">Trust</span><span class="v mono"><?php echo esc_html($courier_trust_score . ' (' . ($courier_trust_tier?:'starter') . ')'); ?></span></div>
                            <div><span class="k">Distance to pickup</span><span class="v mono"><?php echo is_null($courier_distance_to_pickup) ? '—' : esc_html(number_format_i18n($courier_distance_to_pickup, 2) . ' km'); ?></span></div>
                        </div>
                    </div>

                    <!-- Courier Radar -->
                    <div class="ccSCC-card ccSCC-span2">
                        <h2>Courier Radar (Nearest Eligible)</h2>

                        <div class="ccSCC-mini">
                            <span class="ccSCC-chip <?php echo $pickup_coords ? 'green' : 'red'; ?>">
                                Pickup coords: <strong><?php echo $pickup_coords ? 'OK' : 'MISSING'; ?></strong>
                            </span>
                            <span class="ccSCC-chip gray">
                                Eligible: <strong><?php echo esc_html(intval($radar['counts']['ok'])); ?></strong>
                            </span>
                            <span class="ccSCC-chip gray">
                                Stale: <strong><?php echo esc_html(intval($radar['counts']['stale_heartbeat'])); ?></strong>
                            </span>
                            <span class="ccSCC-chip gray">
                                Locked: <strong><?php echo esc_html(intval($radar['counts']['locked'])); ?></strong>
                            </span>
                            <span class="ccSCC-chip gray">
                                Vehicle / cap kg: <strong><?php echo esc_html(intval($radar['counts']['vehicle_capacity'])); ?></strong>
                            </span>
                            <span class="ccSCC-chip gray">
                                Max jobs: <strong><?php echo esc_html(intval($radar['counts']['max_jobs'])); ?></strong>
                            </span>
                            <span class="ccSCC-chip gray">
                                Pickup cap: <strong><?php echo esc_html(intval($radar['counts']['pickup_distance_exceeded'])); ?></strong>
                            </span>
                            <span class="ccSCC-chip gray">
                                Preference: <strong><?php echo esc_html(intval($radar['counts']['distance_preference_exceeded'])); ?></strong>
                            </span>
                            <span class="ccSCC-chip gray">
                                Blocked: <strong><?php echo esc_html(intval($radar['counts']['blocked'])); ?></strong>
                            </span>
                        </div>

                        <?php if ( ! $pickup_coords ) : ?>
                            <div class="ccSCC-note bad">
                                ⚠️ Pickup coords missing → the canonical evaluator will fail couriers with <strong>missing_pickup_coords</strong> instead of pretending they are distance-safe.
                            </div>
                        <?php endif; ?>

                        <div class="ccSCC-tablewrap">
                            <table class="ccSCC-table">
                                <thead>
                                    <tr>
                                        <th>Courier</th>
                                        <th>Status</th>
                                        <th>Last heartbeat</th>
                                        <th>Location</th>
                                        <th>Vehicle / cap / pref</th>
                                        <th>Jobs</th>
                                        <th>Trust</th>
                                        <th>Distance / cap</th>
                                        <th>Eligibility / score</th>
                                        <th>Force</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php foreach ( $radar['rows'] as $r ) :
                                    $eligible = ! empty($r['eligible']);
                                    $why = $r['why'] ?: '—';
                                    $dist = is_null($r['distance_km']) ? '—' : number_format_i18n(floatval($r['distance_km']), 2) . ' km';
                                    ?>
                                    <tr>
                                        <td class="mono">#<?php echo esc_html($r['user_id']); ?> <span class="muted"><?php echo esc_html($r['name']); ?></span></td>
                                        <td>
                                            <span class="ccSCC-chip <?php echo ($r['status']==='online') ? 'green' : 'gray'; ?>">
                                                <?php echo esc_html($r['status'] ?: '—'); ?>
                                            </span>
                                        </td>
                                        <td class="mono"><?php echo $r['last_seen_ts'] ? esc_html(self::age_human($r['last_seen_ts']) . ' ago') : '—'; ?></td>
                                        <td class="mono muted"><?php echo esc_html(($r['last_lat']!=='' && $r['last_lng']!=='') ? ($r['last_lat'].','.$r['last_lng']) : '—'); ?></td>
                                        <td class="mono muted">
                                            <?php
                                            $cap_kg = 0.0;
                                            if ( isset($r['score_breakdown']['vehicle_weight_cap_kg']) ) {
                                                $cap_kg = floatval($r['score_breakdown']['vehicle_weight_cap_kg']);
                                            } elseif ( class_exists('\Caricove\Logistics\Core\ZoneResolver') ) {
                                                $cap_kg = floatval( \Caricove\Logistics\Core\ZoneResolver::get_vehicle_weight_cap_kg( (string) ($r['vehicle'] ?? '') ) );
                                            }
                                            $vehicleBits = array_filter(array(
                                                $r['vehicle'] ?: '—',
                                                $cap_kg > 0 ? number_format_i18n($cap_kg, 0) . 'kg' : '—',
                                                $r['preference_band'] ?: '—'
                                            ));
                                            echo esc_html(implode(' / ', $vehicleBits));
                                            ?>
                                        </td>
                                        <td class="mono"><?php echo esc_html(intval($r['active_jobs']) . '/' . intval($r['max_active_jobs'])); ?></td>
                                        <td class="mono"><?php echo esc_html(intval($r['trust_score']) . ' (' . ($r['trust_tier']?:'starter') . ')'); ?></td>
                                        <td class="mono">
                                            <?php
                                            $capTxt = !empty($r['pickup_cap_km']) ? ' / cap ' . number_format_i18n(floatval($r['pickup_cap_km']), 2) . ' km' : '';
                                            echo esc_html($dist . $capTxt);
                                            ?>
                                        </td>
                                        <td>
                                            <?php
                                            $why_label_map = array(
                                                'vehicle_capacity' => 'vehicle_capacity',
                                                'vehicle_band_blocked' => 'vehicle_band_blocked',
                                                'numeric_weight_cap_exceeded' => 'weight_cap_exceeded',
                                                'size_band_blocked' => 'size_band_blocked',
                                            );
                                          $why_label = $eligible ? 'eligible' : ( $why_label_map[$why] ?? $why );

                                            $summary_total_weight = floatval( $summary['total_weight'] ?? 0 );
                                            $score_weight_kg      = floatval( $r['score_breakdown']['shipment_weight_kg'] ?? 0 );

                                            /*
                                             * Command Center must prefer persisted shipment truth.
                                             * The scoring payload can be stale, fallback-derived, or missing.
                                             */
                                            $ship_weight_kg = $summary_total_weight > 0 ? $summary_total_weight : $score_weight_kg;

                                            $summary_weight_src = (string) ( $summary['total_weight_source'] ?? '' );
                                            $score_weight_src   = (string) ( $r['score_breakdown']['shipment_weight_source'] ?? '' );
                                            $ship_weight_src    = $summary_total_weight > 0
                                                ? ( $summary_weight_src !== '' ? $summary_weight_src : 'item_truth' )
                                                : ( $score_weight_src !== '' ? $score_weight_src : 'missing' );
                                            ?>
                                            <span class="ccSCC-chip <?php echo $eligible ? 'green' : 'red'; ?>">
                                                <?php echo esc_html($why_label); ?>
                                            </span>
                                            <?php
                                            $weight_src_label_map = array(
                                                'variation_product' => 'variation truth',
                                                'variation_meta' => 'variation meta',
                                                'product' => 'product truth',
                                                'product_meta' => 'product meta',
                                                'item_truth' => 'item truth',
                                                'item_meta' => 'item meta',
                                                'band_representative' => 'band fallback',
                                                'band_only' => 'band only',
                                                'missing' => 'missing truth',
                                                '' => 'missing truth',
                                            );
                                            $weight_src_label = $weight_src_label_map[ $ship_weight_src ] ?? str_replace( '_', ' ', $ship_weight_src );
                                            ?>
                                            <div class="mono muted" style="margin-top:6px;">
                                                size <?php echo esc_html(strtoupper((string) ($summary['size_band'] ?: '—'))); ?>
                                                · route <?php echo esc_html(($r['shipment_band']?:'—')); ?>
                                                · pref <?php echo esc_html(($r['preference_band']?:'—')); ?>
                                                · ship weight <?php echo esc_html(number_format_i18n($ship_weight_kg, 2) . 'kg'); ?>
                                                · source <?php echo esc_html($weight_src_label); ?>
                                                <?php if ( $eligible ) : ?>
                                                    · fit <?php echo esc_html(number_format_i18n(floatval($r['score_breakdown']['fit_score'] ?? 0), 3)); ?>
                                                    · score <?php echo esc_html(number_format_i18n(floatval($r['score_total']), 3)); ?>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                        <td>
                                            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:flex;gap:8px;align-items:center;">
                                                <?php wp_nonce_field('cc_scc_action','_cc_nonce'); ?>
                                                <input type="hidden" name="action" value="cc_scc_force">
                                                <input type="hidden" name="shipment_id" value="<?php echo esc_attr($shipment_id); ?>">
                                                <input type="hidden" name="courier_id" value="<?php echo esc_attr(intval($r['user_id'])); ?>">
                                                <button class="ccSCC-btn <?php echo $eligible ? '' : 'alt'; ?>" type="submit" <?php disabled(!$eligible); ?>>
                                                    Force
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>

                        <div class="ccSCC-mini muted">
                            Radar truth is now canonical: protected courier profile → canonical active-job count → pickup sanity cap → planner shipment band / preference band gate → score breakdown for eligible survivors only.
                        </div>
                    </div>

                    <!-- Timeline (summary-first) -->
                    <div class="ccSCC-card ccSCC-span2">
                        <h2>Timeline</h2>
                        <div class="ccSCC-timeline">
                            <?php
                            $events = array(
                                array('Order placed', $order_placed ?: ''),
                                array('Last status change', $last_change_at ?: ''),
                                array('ETA (dispatcher)', $eta ?: ''),
                                array('SLA deadline', $sla_deadline ?: ''),
                            );

                            foreach ( $events as $ev ) {
                                $label = $ev[0];
                                $txt   = $ev[1] ? $ev[1] : '—';
                                echo '<div class="ev"><div class="dot"></div><div class="body"><div class="t">'.esc_html($label).'</div><div class="d mono muted">'.esc_html($txt).'</div></div></div>';
                            }
                            ?>
                        </div>
                        <div class="ccSCC-mini muted">
                            This timeline uses your Core summary keys (last_status_change_at, eta, sla_deadline).
                        </div>
                    </div>

                </div>

                <div class="ccSCC-note">
                    <strong>Wiring note:</strong> Retry/Force triggers <span class="mono">do_action('caricove_dispatcher_retry_assignment', $shipment_id, $reason)</span>.
                </div>

            </div>
        </div>
        <?php
    }

    private static function styles() {
        return '
<style>
.ccSCC{
  margin: 14px 0;
  border-radius: 18px;
  background: radial-gradient(1200px 600px at 15% 0%, rgba(64,160,255,.20), rgba(0,0,0,0)),
              radial-gradient(900px 500px at 85% 10%, rgba(140,80,255,.16), rgba(0,0,0,0)),
              linear-gradient(180deg, #070B14, #04060C);
  border: 1px solid rgba(120,180,255,.18);
  box-shadow: 0 20px 60px rgba(0,0,0,.65), 0 0 0 1px rgba(80,160,255,.06) inset;
  padding: 16px;
  color: #fff;
  max-width: 1400px;
}
.ccSCC-head{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;padding:8px 6px 14px}
.ccSCC-title{font-size:22px;font-weight:900;letter-spacing:.2px}
.ccSCC-title span{opacity:.9;font-weight:800}
.ccSCC-search{display:flex;gap:10px;align-items:center;flex-wrap:wrap}
.ccSCC-input{
  min-width: 280px;
  padding: 11px 12px;
  border-radius: 12px;
  border:1px solid rgba(255,255,255,.12);
  background: rgba(255,255,255,.90);
  color:#000;
  outline:none;
  box-shadow: 0 0 0 1px rgba(0,0,0,.35) inset;
}
.ccSCC-input:focus{box-shadow:0 0 0 4px rgba(80,170,255,.25)}
.ccSCC-btn{
  padding: 11px 14px;
  border-radius: 12px;
  border: 1px solid rgba(120,180,255,.22);
  background: linear-gradient(135deg, rgba(50,140,255,.35), rgba(140,80,255,.20));
  color:#fff;
  font-weight: 900;
  cursor:pointer;
  text-decoration:none;
  display:inline-flex;align-items:center;justify-content:center;
  white-space:nowrap;
}
.ccSCC-btn:hover{filter:brightness(1.06)}
.ccSCC-btn.alt{background: rgba(255,255,255,.06)}
.ccSCC-btn.good{background: linear-gradient(135deg, rgba(52,211,153,.45), rgba(16,185,129,.18)); border-color: rgba(52,211,153,.28);}
.ccSCC-btn.danger{background: linear-gradient(135deg, rgba(255,77,109,.45), rgba(193,18,31,.20)); border-color: rgba(255,77,109,.30);}
.ccSCC-note{
  margin: 10px 6px 0 6px;
  padding: 10px 12px;
  border-radius: 14px;
  border: 1px solid rgba(255,255,255,.10);
  background: rgba(255,255,255,.05);
  font-weight: 900;
  font-size: 13px;
}
.ccSCC-note.ok{border-color: rgba(80,255,170,.25); box-shadow:0 0 22px rgba(80,255,170,.10)}
.ccSCC-note.bad{border-color: rgba(255,90,120,.25); box-shadow:0 0 22px rgba(255,90,120,.10)}
.ccSCC-bar{display:flex;gap:10px;flex-wrap:wrap;align-items:center;justify-content:space-between;padding:10px 6px 12px}
.ccSCC-actions{display:flex;gap:10px;flex-wrap:wrap}
.ccSCC-chip{
  display:inline-flex;align-items:center;gap:8px;
  padding:8px 10px;border-radius:999px;
  border:1px solid rgba(255,255,255,.12);
  background: rgba(0,0,0,.25);
  font-weight:900;font-size:12px;
}
.ccSCC-chip.gray{opacity:.85}
.ccSCC-chip.red{border-color: rgba(255,90,120,.30); box-shadow:0 0 18px rgba(255,90,120,.12)}
.ccSCC-chip.green{border-color: rgba(80,255,170,.28); box-shadow:0 0 18px rgba(80,255,170,.10)}
.ccSCC-chip.purple{border-color: rgba(160,110,255,.30); box-shadow:0 0 18px rgba(160,110,255,.12)}
.ccSCC-chip.gold{border-color: rgba(255,215,100,.30); box-shadow:0 0 18px rgba(255,215,100,.12)}
.ccSCC-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-top:10px}
@media (max-width: 980px){ .ccSCC-grid{grid-template-columns:1fr} .ccSCC-input{min-width:200px;width:100%} }
.ccSCC-card{
  border-radius: 16px;
  overflow:hidden;
  border:1px solid rgba(255,255,255,.08);
  background: rgba(255,255,255,.03);
  box-shadow: 0 18px 55px rgba(0,0,0,.50);
  padding: 16px;
}
.ccSCC-card h2{margin:0 0 10px;font-size:16px;color:#74d0ff}
.ccSCC-span2{grid-column: span 2}
@media (max-width: 980px){ .ccSCC-span2{grid-column: span 1} }
.ccSCC-kv{display:grid;grid-template-columns:1fr;gap:8px}
.ccSCC-kv .k{display:inline-block;min-width:140px;opacity:.78;font-weight:800;font-size:12px}
.ccSCC-kv .v{font-weight:800}
.ccSCC-mini{margin-top:10px;font-size:12px;opacity:.85}
.mono{font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;}
.muted{opacity:.78}
.ccSCC-codebox{border:1px solid rgba(255,255,255,.10);border-radius:14px;padding:12px;background: rgba(0,0,0,.22)}
.ccSCC-codebox .row{display:flex;justify-content:space-between;gap:10px;align-items:center;padding:6px 0}
.ccSCC-codebox .label{opacity:.8;font-weight:900}
.ccSCC-codebox .code{font-size:16px;letter-spacing:1px}
.ccSCC-tablewrap{margin-top:12px;overflow:auto;border-radius:14px;border:1px solid rgba(255,255,255,.08)}
.ccSCC-table{width:100%;border-collapse:collapse}
.ccSCC-table th,.ccSCC-table td{padding:12px;border-bottom:1px solid rgba(255,255,255,.07);text-align:left;white-space:nowrap;font-size:13px}
.ccSCC-table th{font-size:12px;opacity:.85;text-transform:uppercase;letter-spacing:.8px}
.ccSCC-timeline{display:flex;flex-direction:column;gap:10px;margin-top:8px}
.ccSCC-timeline .ev{display:flex;gap:10px;align-items:flex-start}
.ccSCC-timeline .dot{width:10px;height:10px;border-radius:999px;background:#74d0ff;box-shadow:0 0 18px rgba(116,208,255,.25);margin-top:4px}
.ccSCC-timeline .t{font-weight:900}
.ccSCC-timeline .d{margin-top:2px}
.ccSCC-pill{display:inline-flex;align-items:center;gap:10px;padding:10px 12px;border-radius:999px;border:1px solid rgba(255,255,255,.10);background: rgba(255,255,255,.04);font-weight:900}
.ccSCC-load-label{font-size:12px;opacity:.78;font-weight:900;margin-bottom:6px}
.ccSCC-loadbar{height:10px;border-radius:999px;background:rgba(255,255,255,.10);overflow:hidden}
.ccSCC-loadbar span{display:block;height:100%;background:linear-gradient(135deg,#1a6cff,#41c5ff)}
.ccSCC-loadbar.size span{background:linear-gradient(135deg,#8c50ff,#41c5ff)}
.ccSCC-load-meta{margin-top:4px;font-size:12px;opacity:.82}
</style>';
    }
}

Caricove_Dispatcher_Shipment_Command_Center::boot();