<?php
/**
 * Plugin Name: Caricove Dispatcher — Overrides Command Deck (TOP MENU + Telemetry v2) [FORCE=HARD IMMEDIATE]
 * Description: Creates a top-level “Dispatcher” admin menu and mounts the Overrides Command Deck inside it. Manual always wins (enforced). FORCE now executes immediately (ignores status/eligibility/dispatcher state).
 * Author: Caricove
 * MU Plugin: true
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class Caricove_Dispatcher_CommandDeck {

    // Top-level parent slug you’ll attach more submenus to
    const PARENT_SLUG = 'caricove-dispatcher-admin';

    // This page slug (submenu)
    const MENU_SLUG   = 'cc-dispatcher-overrides-deck';

    // Telemetry options (global)
    const TEL_OPT_SETTINGS = '_cc_telemetry_settings_v2';
    const TEL_OPT_STATE    = '_cc_telemetry_state_v2';

    public static function boot() {
        // IMPORTANT: early so parent menu exists before other admin files try add_submenu_page()
        add_action( 'admin_menu', array( __CLASS__, 'register_menu' ), 5 );

        // Form handler
        add_action( 'admin_post_cc_override_deck', array( __CLASS__, 'handle_post' ) );

add_action( 'cc_shipment_ready_for_assignment', array( __CLASS__, 'runtime_clear_stale_ready_lock' ), 1, 3 );

        // Telemetry wiring into Dispatcher — AI lane
        add_filter( 'cc_dispatcher_sla_hint_for_candidate', array( __CLASS__, 'telemetry_sla_hint' ), 30, 3 );
        add_filter( 'cc_dispatcher_candidate_score', array( __CLASS__, 'telemetry_candidate_score' ), 30, 4 );
    }

    public static function register_menu() {

        // 1) Top-level "Dispatcher" menu
        add_menu_page(
            __( 'Dispatcher', 'caricove-logistics' ),
            __( 'Dispatcher', 'caricove-logistics' ),
            'manage_options',
            self::PARENT_SLUG,
            array( __CLASS__, 'render_page' ),
            'dashicons-randomize',
            56
        );

        // 2) Submenu: Overrides (Command Deck)
        add_submenu_page(
            self::PARENT_SLUG,
            __( 'Overrides (Command Deck)', 'caricove-logistics' ),
            __( 'Overrides', 'caricove-logistics' ),
            'manage_options',
            self::MENU_SLUG,
            array( __CLASS__, 'render_page' )
        );
    }


private static function runtime_clear_stale_ready_lock( $shipment_id, $order_id = 0, $vendor_id = 0 ) {
    $shipment_id = intval( $shipment_id );
    if ( ! $shipment_id ) return;

    $overrides = self::ensure_arrays( self::get_overrides() );
    $changed   = false;

    if ( isset( $overrides['shipment_locks'][ $shipment_id ] ) ) {
        unset( $overrides['shipment_locks'][ $shipment_id ] );
        $changed = true;
    }

    if ( $changed ) {
        self::save_overrides( $overrides );
    }
}








    /* ---------------------------------------------------------
     * Manual Overrides option helpers
     * ------------------------------------------------------ */

    private static function get_overrides_option_key() {
        // Safer: don’t rely on defined('Class::CONST') (can be finicky). Use constant() if class exists.
        if ( class_exists( '\Caricove\Logistics\Dispatcher\Overrides' ) ) {
            $const = '\Caricove\Logistics\Dispatcher\Overrides::OPTION_OVERRIDES';
            if ( defined( $const ) ) {
                return constant( $const );
            }
        }
        return '_cc_dispatcher_overrides';
    }

    private static function get_settings_option_key() {
        if ( class_exists( '\Caricove\Logistics\Dispatcher\Settings' ) ) {
            $const = '\Caricove\Logistics\Dispatcher\Settings::OPTION_SETTINGS';
            if ( defined( $const ) ) {
                return constant( $const );
            }
        }
        return '_cc_dispatcher_settings';
    }

    private static function get_overrides() {
        $opt = get_option( self::get_overrides_option_key(), array() );
        return is_array( $opt ) ? $opt : array();
    }

    private static function save_overrides( array $overrides ) {
        update_option( self::get_overrides_option_key(), $overrides );
    }

    private static function get_settings() {
        $opt = get_option( self::get_settings_option_key(), array() );
        return is_array( $opt ) ? $opt : array();
    }

    private static function save_settings( array $settings ) {
        update_option( self::get_settings_option_key(), $settings );
    }

    private static function ensure_arrays( array $ov ) {
        $defaults = array(
            'courier_blocklist'          => array(),
            'courier_weight_adjustments' => array(),
            'vendor_blocklist'           => array(),
            'vendor_manual_only'         => array(),
            'shipment_locks'             => array(),
            'shipment_forced_courier'    => array(),
        );
        $ov = array_merge( $defaults, $ov );
        foreach ( $defaults as $k => $v ) {
            if ( ! isset( $ov[$k] ) || ! is_array( $ov[$k] ) ) $ov[$k] = array();
        }
        return $ov;
    }

    private static function courier_is_manually_blocked( $cid, array $overrides ) {
        return ! empty( $overrides['courier_blocklist'][ $cid ] );
    }

    private static function courier_has_manual_multiplier( $cid, array $overrides ) {
        return isset( $overrides['courier_weight_adjustments'][ $cid ] );
    }

    /* ---------------------------------------------------------
     * Telemetry v2 option helpers
     * ------------------------------------------------------ */

    private static function tel_get_settings() {
        $s = get_option( self::TEL_OPT_SETTINGS, array() );
        if ( ! is_array( $s ) ) $s = array();

        // Confidence → cap mapping (safe defaults)
        $s = array_merge(
            array(
                'mode'             => 'off',    // off | log_only | hint | override_with_constraints (reserved)
                'bucket_mode'      => 'auto',   // auto | force
                'forced_bucket'    => 'midday',
                'confidence'       => 'medium', // low | medium | high
                'cap_low'          => 0.05,
                'cap_medium'       => 0.10,
                'cap_high'         => 0.15,
                'half_life_days'   => 7,
                'expiry_default_h' => 24,
            ),
            $s
        );

        return $s;
    }

    private static function tel_save_settings( array $s ) {
        update_option( self::TEL_OPT_SETTINGS, $s );
    }

    private static function tel_get_state() {
        $st = get_option( self::TEL_OPT_STATE, array() );
        if ( ! is_array( $st ) ) $st = array();

        $st = array_merge(
            array(
                'scopes'       => array(),
                'last_updated' => '',
            ),
            $st
        );

        if ( ! is_array( $st['scopes'] ) ) $st['scopes'] = array();

        return $st;
    }

    private static function tel_save_state( array $st ) {
        $st['last_updated'] = gmdate( 'Y-m-d H:i:s' );
        update_option( self::TEL_OPT_STATE, $st );
    }

    /* ---------------------------------------------------------
     * Telemetry scope utilities (lane + time bucket)
     * ------------------------------------------------------ */

    private static function compute_time_bucket() {
        $tel = self::tel_get_settings();

        if ( $tel['bucket_mode'] === 'force' ) {
            return sanitize_key( $tel['forced_bucket'] );
        }

        // Auto buckets by local WP time (respects site timezone)
        $ts   = current_time( 'timestamp' );
        $hour = intval( gmdate( 'G', $ts + ( get_option('gmt_offset') * HOUR_IN_SECONDS ) ) );

        // Simple buckets (tweak anytime)
        if ( $hour >= 6 && $hour < 10 )  return 'morning';
        if ( $hour >= 10 && $hour < 16 ) return 'midday';
        if ( $hour >= 16 && $hour < 20 ) return 'evening_peak';
        return 'night';
    }

    private static function scope_key_from_lane( $origin, $dest, $bucket ) {
        $origin = $origin ? sanitize_key( $origin ) : 'unknown_origin';
        $dest   = $dest ? sanitize_key( $dest ) : 'unknown_dest';
        $bucket = $bucket ? sanitize_key( $bucket ) : 'unknown_bucket';
        return $origin . '::' . $dest . '::' . $bucket;
    }

    private static function scope_key_for_shipment( $shipment, $bucket ) {
        $origin = '';
        $dest   = '';

        if ( is_array( $shipment ) ) {
            if ( ! empty( $shipment['origin_anchor'] ) ) $origin = $shipment['origin_anchor'];
            if ( ! empty( $shipment['destination_anchor'] ) ) $dest = $shipment['destination_anchor'];
            if ( ! empty( $shipment['dest_anchor'] ) && ! $dest ) $dest = $shipment['dest_anchor'];
        }

        return self::scope_key_from_lane( $origin, $dest, $bucket );
    }

    private static function confidence_cap() {
        $tel = self::tel_get_settings();
        $c = $tel['confidence'];

        if ( $c === 'low' ) return floatval( $tel['cap_low'] );
        if ( $c === 'high' ) return floatval( $tel['cap_high'] );
        return floatval( $tel['cap_medium'] );
    }

    private static function decay_factor( $set_at_ts ) {
        $tel = self::tel_get_settings();
        $half_life_days = max( 1, intval( $tel['half_life_days'] ) );
        $half_life_sec  = $half_life_days * DAY_IN_SECONDS;

        $age = time() - intval( $set_at_ts );
        if ( $age <= 0 ) return 1.0;

        return pow( 0.5, $age / $half_life_sec );
    }

    private static function entry_is_expired( $expires_at ) {
        $expires_at = intval( $expires_at );
        if ( ! $expires_at ) return false;
        return time() > $expires_at;
    }

    /* ---------------------------------------------------------
     * Telemetry → Dispatcher wiring (bounded influence + scope)
     * Manual supremacy enforced.
     * ------------------------------------------------------ */

    public static function telemetry_sla_hint( $hint, $shipment, $profile ) {
        $tel = self::tel_get_settings();
        if ( $tel['mode'] === 'off' || $tel['mode'] === 'log_only' ) {
            return $hint;
        }

        $cid = isset( $profile['user_id'] ) ? intval( $profile['user_id'] ) : 0;
        if ( ! $cid ) return $hint;

        $overrides = self::ensure_arrays( self::get_overrides() );

        // Manual supremacy
        if ( self::courier_is_manually_blocked( $cid, $overrides ) ) return $hint;
        if ( self::courier_has_manual_multiplier( $cid, $overrides ) ) return $hint;

        $bucket = self::compute_time_bucket();
        $scope  = self::scope_key_for_shipment( $shipment, $bucket );

        $state = self::tel_get_state();
        if ( empty( $state['scopes'][ $scope ]['risks'][ $cid ] ) ) {
            return $hint;
        }

        $entry = $state['scopes'][ $scope ]['risks'][ $cid ];
        $risk  = floatval( $entry['value'] );

        if ( self::entry_is_expired( $entry['expires_at'] ) ) {
            return $hint;
        }

        $df   = self::decay_factor( $entry['set_at'] );
        $risk = max( 0.0, min( 1.0, $risk * $df ) );

        $hint['risk'] = $risk;
        return $hint;
    }

    public static function telemetry_candidate_score( $score, $shipment, $profile, $settings ) {
        $tel = self::tel_get_settings();
        if ( $tel['mode'] === 'off' || $tel['mode'] === 'log_only' ) {
            return $score;
        }

        $cid = isset( $profile['user_id'] ) ? intval( $profile['user_id'] ) : 0;
        if ( ! $cid ) return $score;

        $overrides = self::ensure_arrays( self::get_overrides() );

        // Manual supremacy
        if ( self::courier_is_manually_blocked( $cid, $overrides ) ) return $score;
        if ( self::courier_has_manual_multiplier( $cid, $overrides ) ) return $score;

        $bucket = self::compute_time_bucket();
        $scope  = self::scope_key_for_shipment( $shipment, $bucket );

        $state = self::tel_get_state();
        if ( empty( $state['scopes'][ $scope ]['nudges'][ $cid ] ) ) {
            return $score;
        }

        $entry = $state['scopes'][ $scope ]['nudges'][ $cid ];

        if ( self::entry_is_expired( $entry['expires_at'] ) ) {
            return $score;
        }

        $cap   = self::confidence_cap();
        $nudge = floatval( $entry['value'] );

        $df    = self::decay_factor( $entry['set_at'] );
        $nudge = $nudge * $df;

        if ( $nudge > $cap )  $nudge = $cap;
        if ( $nudge < -$cap ) $nudge = -$cap;

        if ( isset( $score['total'] ) ) {
            $base = floatval( $score['total'] );
            $score['total'] = max( 0.0, min( 1.0, $base * ( 1.0 + $nudge ) ) );
        }

        return $score;
    }

    /* ---------------------------------------------------------
     * HARD FORCE EXECUTION (operator supremacy)
     * ------------------------------------------------------ */

    private static function hard_force_assign_now( $shipment_id, $courier_id, array $context = array() ) {
        $shipment_id = intval( $shipment_id );
        $courier_id  = intval( $courier_id );

        if ( ! $shipment_id || ! $courier_id ) {
            return array( false, 'Missing shipment/courier ID.' );
        }

        if ( ! class_exists( '\Caricove\Logistics\Core\ShipmentManager' ) ) {
            return array( false, 'Core missing: ShipmentManager not loaded.' );
        }
        if ( ! class_exists( '\Caricove\Logistics\Dispatcher\Assign' ) ) {
            return array( false, 'Dispatcher missing: Assign not loaded.' );
        }

        $summary = \Caricove\Logistics\Core\ShipmentManager::get_shipment_summary( $shipment_id );
        if ( empty( $summary ) || ! is_array( $summary ) ) {
            return array( false, "Shipment #{$shipment_id} summary not found." );
        }

        // Ensure status does not block immediate assign (we ignore “correctness” and do operator intent)
        if ( empty( $summary['status'] ) || $summary['status'] !== 'ready_for_assignment' ) {
            \Caricove\Logistics\Core\ShipmentManager::set_shipment_status(
                $shipment_id,
                'ready_for_assignment',
                array_merge(
                    array(
                        'source' => 'command_deck',
                        'reason' => 'hard_force_assign_now',
                    ),
                    $context
                )
            );
            $summary = \Caricove\Logistics\Core\ShipmentManager::get_shipment_summary( $shipment_id );
            if ( empty( $summary ) || ! is_array( $summary ) ) {
                return array( false, "Shipment #{$shipment_id} could not refresh after force status." );
            }
        }

        // Execute assignment immediately (bypasses candidate pool + eligibility)
        $settings = class_exists( '\Caricove\Logistics\Dispatcher\Settings' )
            ? \Caricove\Logistics\Dispatcher\Settings::get_settings()
            : array( 'enabled' => 1 );

        \Caricove\Logistics\Dispatcher\Assign::to_courier(
            $shipment_id,
            $courier_id,
            $summary,
            $settings,
            array_merge(
                array(
                    'source'   => 'admin_force_immediate',
                    'operator' => get_current_user_id(),
                ),
                $context
            )
        );

        return array( true, "Shipment #{$shipment_id} IMMEDIATELY assigned to Courier #{$courier_id}." );
    }

    /* ---------------------------------------------------------
     * Form handler (Manual + Telemetry actions)
     * ------------------------------------------------------ */

    public static function handle_post() {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Unauthorized' );
        check_admin_referer( 'cc_override_deck_action', '_cc_nonce' );

        $action    = isset( $_POST['deck_action'] ) ? sanitize_key( wp_unslash( $_POST['deck_action'] ) ) : '';
        $overrides = self::ensure_arrays( self::get_overrides() );
        $settings  = self::get_settings();

        $tel_settings = self::tel_get_settings();
        $tel_state    = self::tel_get_state();

        $msg = '';

        switch ( $action ) {

            /* ---------------- Manual Overrides ---------------- */
           case 'shipment_normal':
case 'shipment_lock':
case 'shipment_force':
    $shipment_id = isset( $_POST['shipment_id'] ) ? intval( $_POST['shipment_id'] ) : 0;
    if ( ! $shipment_id ) { $msg = 'Missing shipment_id.'; break; }

    $current_status = '';
    if ( class_exists( '\Caricove\Logistics\Core\ShipmentManager' ) ) {
        $summary = \Caricove\Logistics\Core\ShipmentManager::get_shipment_summary( $shipment_id );
        if ( is_array( $summary ) && ! empty( $summary['status'] ) ) {
            $current_status = sanitize_key( $summary['status'] );
        }
    }

    // Always clear stale operator residue before applying the next command.
    unset( $overrides['shipment_locks'][ $shipment_id ] );
    unset( $overrides['shipment_forced_courier'][ $shipment_id ] );

    // Clear stale live-offer residue too, so a shipment can re-enter normal offer flow cleanly.
    delete_post_meta( $shipment_id, '_cc_offer_courier_id' );
    delete_post_meta( $shipment_id, '_cc_offer_expires_at' );
    delete_post_meta( $shipment_id, '_cc_hold_reason' );

    if ( $action === 'shipment_lock' ) {
        // Prevent stale admin locks from poisoning ready_for_assignment flow.
        if ( $current_status === 'ready_for_assignment' ) {
            $msg = "Shipment #{$shipment_id} is ready_for_assignment. Hard lock skipped to avoid blocking normal offer flow.";
            self::save_overrides( $overrides );
            break;
        }

        $overrides['shipment_locks'][ $shipment_id ] = 1;
        $msg = "Shipment #{$shipment_id} locked.";
        self::save_overrides( $overrides );

    } elseif ( $action === 'shipment_force' ) {
        $courier_id = isset( $_POST['force_courier_id'] ) ? intval( $_POST['force_courier_id'] ) : 0;
        if ( ! $courier_id ) { $msg = 'Missing courier ID to force.'; break; }

        $overrides['shipment_forced_courier'][ $shipment_id ] = $courier_id;
        self::save_overrides( $overrides );

        list( $ok, $m ) = self::hard_force_assign_now(
            $shipment_id,
            $courier_id,
            array(
                'deck_action' => 'shipment_force',
                'note'        => 'Operator supremacy: bypass status/eligibility/dispatcher.',
            )
        );
        $msg = $m;

    } else {
        $msg = "Shipment #{$shipment_id} returned to normal.";
        self::save_overrides( $overrides );
    }
    break;
                $shipment_id = isset( $_POST['shipment_id'] ) ? intval( $_POST['shipment_id'] ) : 0;
                if ( ! $shipment_id ) { $msg = 'Missing shipment_id.'; break; }

                unset( $overrides['shipment_locks'][ $shipment_id ] );
                unset( $overrides['shipment_forced_courier'][ $shipment_id ] );

                if ( $action === 'shipment_lock' ) {
                    $overrides['shipment_locks'][ $shipment_id ] = 1;
                    $msg = "Shipment #{$shipment_id} locked.";
                    self::save_overrides( $overrides );
                } elseif ( $action === 'shipment_force' ) {
                    $courier_id = isset( $_POST['force_courier_id'] ) ? intval( $_POST['force_courier_id'] ) : 0;
                    if ( ! $courier_id ) { $msg = 'Missing courier ID to force.'; break; }

                    // Persist force intent (audit)
                    $overrides['shipment_forced_courier'][ $shipment_id ] = $courier_id;
                    self::save_overrides( $overrides );

                    // ✅ HARD EXECUTION: do what operator said NOW (ignore everything else)
                    list( $ok, $m ) = self::hard_force_assign_now(
                        $shipment_id,
                        $courier_id,
                        array(
                            'deck_action' => 'shipment_force',
                            'note'        => 'Operator supremacy: bypass status/eligibility/dispatcher.',
                        )
                    );
                    $msg = $m;
                } else {
                    $msg = "Shipment #{$shipment_id} returned to normal.";
                    self::save_overrides( $overrides );
                }
                break;

            case 'courier_promote':
            case 'courier_cooldown':
            case 'courier_block':
            case 'courier_normal':
                $courier_id = isset( $_POST['courier_id'] ) ? intval( $_POST['courier_id'] ) : 0;
                if ( ! $courier_id ) { $msg = 'Missing courier_id.'; break; }

                unset( $overrides['courier_blocklist'][ $courier_id ] );
                unset( $overrides['courier_weight_adjustments'][ $courier_id ] );

                if ( $action === 'courier_block' ) {
                    $overrides['courier_blocklist'][ $courier_id ] = 1;
                    $msg = "Courier #{$courier_id} blocked.";
                } elseif ( $action === 'courier_promote' ) {
                    $overrides['courier_weight_adjustments'][ $courier_id ] = 1.5;
                    $msg = "Courier #{$courier_id} promoted (+50%).";
                } elseif ( $action === 'courier_cooldown' ) {
                    $overrides['courier_weight_adjustments'][ $courier_id ] = 0.7;
                    $msg = "Courier #{$courier_id} cooled down (-30%).";
                } else {
                    $msg = "Courier #{$courier_id} normal.";
                }

                self::save_overrides( $overrides );
                break;

            case 'vendor_manual_only':
            case 'vendor_block':
            case 'vendor_normal':
                $vendor_id = isset( $_POST['vendor_id'] ) ? intval( $_POST['vendor_id'] ) : 0;
                if ( ! $vendor_id ) { $msg = 'Missing vendor_id.'; break; }

                unset( $overrides['vendor_blocklist'][ $vendor_id ] );
                unset( $overrides['vendor_manual_only'][ $vendor_id ] );

                if ( $action === 'vendor_block' ) {
                    $overrides['vendor_blocklist'][ $vendor_id ] = 1;
                    $msg = "Vendor #{$vendor_id} blocked.";
                } elseif ( $action === 'vendor_manual_only' ) {
                    $overrides['vendor_manual_only'][ $vendor_id ] = 1;
                    $msg = "Vendor #{$vendor_id} manual-only.";
                } else {
                    $msg = "Vendor #{$vendor_id} normal.";
                }

                self::save_overrides( $overrides );
                break;

            case 'brain_pause':
            case 'brain_resume':
                $settings['enabled'] = ( $action === 'brain_pause' ) ? 0 : 1;
                self::save_settings( $settings );
                $msg = ( $action === 'brain_pause' ) ? 'Dispatcher paused.' : 'Dispatcher resumed.';
                break;

            /* ---------------- Telemetry Settings ---------------- */
            case 'tel_mode_off':
            case 'tel_mode_log':
            case 'tel_mode_hint':
                $tel_settings['mode'] = ($action === 'tel_mode_off') ? 'off' : (($action === 'tel_mode_log') ? 'log_only' : 'hint');
                self::tel_save_settings( $tel_settings );
                $msg = "Telemetry mode: {$tel_settings['mode']}.";
                break;

            case 'tel_bucket_auto':
            case 'tel_bucket_force':
                $tel_settings['bucket_mode'] = ($action === 'tel_bucket_force') ? 'force' : 'auto';
                $forced = isset( $_POST['tel_forced_bucket'] ) ? sanitize_key( wp_unslash( $_POST['tel_forced_bucket'] ) ) : 'midday';
                $tel_settings['forced_bucket'] = $forced ?: 'midday';
                self::tel_save_settings( $tel_settings );
                $msg = "Telemetry time bucket: {$tel_settings['bucket_mode']}.";
                break;

            case 'tel_conf_low':
            case 'tel_conf_med':
            case 'tel_conf_high':
                $tel_settings['confidence'] = ($action === 'tel_conf_low') ? 'low' : (($action === 'tel_conf_high') ? 'high' : 'medium');
                self::tel_save_settings( $tel_settings );
                $msg = "Telemetry confidence: {$tel_settings['confidence']}.";
                break;

            case 'tel_decay_save':
                $hl = isset( $_POST['tel_half_life_days'] ) ? intval( $_POST['tel_half_life_days'] ) : 7;
                if ( $hl < 1 ) $hl = 1;
                if ( $hl > 90 ) $hl = 90;
                $tel_settings['half_life_days'] = $hl;

                $exp = isset( $_POST['tel_expiry_default_h'] ) ? intval( $_POST['tel_expiry_default_h'] ) : 24;
                if ( $exp < 0 ) $exp = 0;
                if ( $exp > 720 ) $exp = 720;
                $tel_settings['expiry_default_h'] = $exp;

                self::tel_save_settings( $tel_settings );
                $msg = "Telemetry decay saved (half-life={$hl}d, default expiry={$exp}h).";
                break;

            /* ---------------- Telemetry Lane Controls ---------------- */
            case 'tel_lane_apply':
                $origin = isset( $_POST['tel_origin_anchor'] ) ? sanitize_key( wp_unslash( $_POST['tel_origin_anchor'] ) ) : '';
                $dest   = isset( $_POST['tel_dest_anchor'] ) ? sanitize_key( wp_unslash( $_POST['tel_dest_anchor'] ) ) : '';
                $bucket = isset( $_POST['tel_bucket'] ) ? sanitize_key( wp_unslash( $_POST['tel_bucket'] ) ) : self::compute_time_bucket();

                if ( empty( $origin ) ) $origin = 'gt_kingston_hub';
                if ( empty( $dest ) )   $dest   = 'gt_kingston_hub';

                $scope = self::scope_key_from_lane( $origin, $dest, $bucket );

                $cid = isset( $_POST['tel_courier_id'] ) ? intval( $_POST['tel_courier_id'] ) : 0;
                if ( ! $cid ) { $msg = 'Missing courier id for telemetry.'; break; }

                $what = isset( $_POST['tel_action'] ) ? sanitize_key( wp_unslash( $_POST['tel_action'] ) ) : '';
                $evidence = isset( $_POST['tel_evidence'] ) ? sanitize_text_field( wp_unslash( $_POST['tel_evidence'] ) ) : '';

                if ( empty( $tel_state['scopes'][ $scope ] ) ) {
                    $tel_state['scopes'][ $scope ] = array(
                        'nudges' => array(),
                        'risks'  => array(),
                        'last_updated' => '',
                    );
                }
                if ( empty( $tel_state['scopes'][ $scope ]['nudges'] ) ) $tel_state['scopes'][ $scope ]['nudges'] = array();
                if ( empty( $tel_state['scopes'][ $scope ]['risks'] ) )  $tel_state['scopes'][ $scope ]['risks']  = array();

                $now = time();
                $exp_h = intval( $tel_settings['expiry_default_h'] );
                $expires_at = $exp_h > 0 ? ($now + $exp_h * HOUR_IN_SECONDS) : 0;

                if ( $what === 'favor' ) {
                    $tel_state['scopes'][ $scope ]['nudges'][ $cid ] = array(
                        'value' => 0.10,
                        'set_at' => $now,
                        'expires_at' => $expires_at,
                        'evidence' => $evidence,
                    );
                    $msg = "Telemetry FAVOR (+10%) set for courier #{$cid} on {$scope}.";
                } elseif ( $what === 'avoid' ) {
                    $tel_state['scopes'][ $scope ]['nudges'][ $cid ] = array(
                        'value' => -0.10,
                        'set_at' => $now,
                        'expires_at' => $expires_at,
                        'evidence' => $evidence,
                    );
                    $msg = "Telemetry AVOID (-10%) set for courier #{$cid} on {$scope}.";
                } elseif ( $what === 'clear_nudge' ) {
                    unset( $tel_state['scopes'][ $scope ]['nudges'][ $cid ] );
                    $msg = "Telemetry nudge cleared for courier #{$cid} on {$scope}.";
                } elseif ( $what === 'risk_high' ) {
                    $tel_state['scopes'][ $scope ]['risks'][ $cid ] = array(
                        'value' => 0.80,
                        'set_at' => $now,
                        'expires_at' => $expires_at,
                        'evidence' => $evidence,
                    );
                    $msg = "Telemetry SLA risk HIGH set for courier #{$cid} on {$scope}.";
                } elseif ( $what === 'risk_clear' ) {
                    unset( $tel_state['scopes'][ $scope ]['risks'][ $cid ] );
                    $msg = "Telemetry SLA risk cleared for courier #{$cid} on {$scope}.";
                } else {
                    $msg = "Unknown telemetry lane action.";
                    break;
                }

                self::tel_save_state( $tel_state );
                break;

            default:
                $msg = 'Unknown action.';
                break;
        }

        $redirect = add_query_arg(
            array(
                'page' => self::MENU_SLUG,
                'cc_deck_msg' => rawurlencode( $msg ),
            ),
            admin_url( 'admin.php' )
        );

        wp_safe_redirect( $redirect );
        exit;
    }

    public static function render_page() {
        if ( ! current_user_can( 'manage_options' ) ) return;

        $msg = isset( $_GET['cc_deck_msg'] ) ? sanitize_text_field( wp_unslash( $_GET['cc_deck_msg'] ) ) : '';

        $settings = self::get_settings();
        $enabled  = isset( $settings['enabled'] ) ? intval( $settings['enabled'] ) : 1;

        $tel_settings = self::tel_get_settings();
        $tel_state    = self::tel_get_state();
        $tel_mode     = isset( $tel_settings['mode'] ) ? $tel_settings['mode'] : 'off';

        $bucket_auto = self::compute_time_bucket();
        $cap = self::confidence_cap();

        ?>
        <div class="wrap">
            <h1>Overrides — Command Deck</h1>
            <p class="description">Pick a thing → press one action → reality changes. Manual wins. Telemetry is lane+time aware, bounded, decaying, expiring, and explainable.</p>

            <style>
                .ccdeck { max-width: 1100px; background:#0b1220; border:1px solid #1f2a44; border-radius:14px; padding:18px; }
                .ccdeck-row { display:grid; grid-template-columns:1fr 1fr; gap:16px; }
                @media (max-width:980px){ .ccdeck-row{ grid-template-columns:1fr; } }
                .ccdeck-card { background:#060b16; border:1px solid #1c2440; border-radius:14px; padding:16px; }
                .ccdeck-card h2 { margin:0 0 10px; color:#74d0ff; font-size:18px; }
                .ccdeck-card p { margin:0 0 12px; color:#a9b4c7; }
                .ccdeck-inline { display:flex; flex-wrap:wrap; gap:10px; align-items:center; }
                .ccdeck-input { padding:10px 12px; border-radius:10px; border:1px solid #243055; background:#0b1220; color:#e7eefc; min-width:180px; }
                .ccdeck-btn { padding:10px 12px; border-radius:12px; border:1px solid #2b3a66; background:linear-gradient(180deg,#0ea5e9,#0284c7); color:#06101f; font-weight:800; cursor:pointer; }
                .ccdeck-btn.alt { background:#121a2e; color:#e7eefc; }
                .ccdeck-btn.danger { background:linear-gradient(180deg,#ff4d6d,#c1121f); color:#16060a; border-color:#3a1520; }
                .ccdeck-btn.good { background:linear-gradient(180deg,#34d399,#10b981); color:#06110d; border-color:#0c2a20; }
                .ccdeck-chip { display:inline-flex; gap:8px; align-items:center; padding:6px 10px; border-radius:999px; border:1px solid #243055; background:#0b1220; color:#cdd7ee; font-weight:700; font-size:12px; }
                .ccdeck-msg { margin:12px 0 0; padding:10px 12px; border-radius:12px; background:#071a12; border:1px solid #0f3b28; color:#bbf7d0; font-weight:600; }
                .ccdeck-mini { margin-top:10px; padding:10px 12px; border-radius:12px; border:1px solid #243055; background:#050a14; color:#cdd7ee; font-size:12px; }
                textarea.ccdeck-ta { width:100%; min-height:64px; border-radius:10px; border:1px solid #243055; background:#0b1220; color:#e7eefc; padding:10px; }
                select.ccdeck-select { padding:10px 12px; border-radius:10px; border:1px solid #243055; background:#0b1220; color:#e7eefc; }
            </style>

            <div class="ccdeck">
                <?php if ( $msg ) : ?><div class="ccdeck-msg"><?php echo esc_html( $msg ); ?></div><?php endif; ?>

                <div class="ccdeck-row">

                    <!-- Manual: Fix shipment -->
                    <div class="ccdeck-card">
                        <h2>Fix a Shipment</h2>
                        <p>Normal / Lock / Force.</p>
                        <form method="post" action="<?php echo esc_url( admin_url('admin-post.php') ); ?>">
                            <?php wp_nonce_field('cc_override_deck_action','_cc_nonce'); ?>
                            <input type="hidden" name="action" value="cc_override_deck" />
                            <div class="ccdeck-inline">
                                <input class="ccdeck-input" type="number" name="shipment_id" placeholder="Shipment ID" required />
                                <input class="ccdeck-input" type="number" name="force_courier_id" placeholder="Force Courier ID (optional)" />
                            </div>
                            <div class="ccdeck-inline" style="margin-top:10px;">
                                <button class="ccdeck-btn alt" name="deck_action" value="shipment_normal" type="submit">Normal</button>
                                <button class="ccdeck-btn danger" name="deck_action" value="shipment_lock" type="submit">Lock</button>
                                <button class="ccdeck-btn good" name="deck_action" value="shipment_force" type="submit">Force</button>
                            </div>
                            <div class="ccdeck-mini">FORCE now executes immediately (ignores status, eligibility, radios, dispatcher state).</div>
                        </form>
                    </div>

                    <!-- Manual: Control courier -->
                    <div class="ccdeck-card">
                        <h2>Control a Courier (Manual)</h2>
                        <p>Promote / Cool down / Block / Normal.</p>
                        <form method="post" action="<?php echo esc_url( admin_url('admin-post.php') ); ?>">
                            <?php wp_nonce_field('cc_override_deck_action','_cc_nonce'); ?>
                            <input type="hidden" name="action" value="cc_override_deck" />
                            <div class="ccdeck-inline">
                                <input class="ccdeck-input" type="number" name="courier_id" placeholder="Courier ID" required />
                            </div>
                            <div class="ccdeck-inline" style="margin-top:10px;">
                                <button class="ccdeck-btn good" name="deck_action" value="courier_promote" type="submit">Promote (+50%)</button>
                                <button class="ccdeck-btn alt" name="deck_action" value="courier_cooldown" type="submit">Cool Down (-30%)</button>
                                <button class="ccdeck-btn danger" name="deck_action" value="courier_block" type="submit">Block</button>
                                <button class="ccdeck-btn alt" name="deck_action" value="courier_normal" type="submit">Normal</button>
                            </div>
                        </form>
                        <div class="ccdeck-mini">Manual supremacy enforced: telemetry will NOT nudge couriers you manually tuned.</div>
                    </div>

                    <!-- Telemetry v2 -->
                    <div class="ccdeck-card">
                        <h2>Telemetry Copilot (AI) — v2</h2>
                        <p>Lane + time bucket + confidence + expiry + decay + evidence.</p>

                        <div class="ccdeck-inline">
                            <span class="ccdeck-chip">Mode: <strong style="color:#74d0ff;"><?php echo esc_html($tel_mode); ?></strong></span>
                            <span class="ccdeck-chip">Bucket: <strong><?php echo esc_html( ($tel_settings['bucket_mode']==='force') ? $tel_settings['forced_bucket'] : ($bucket_auto . ' (auto)') ); ?></strong></span>
                            <span class="ccdeck-chip">Confidence: <strong><?php echo esc_html($tel_settings['confidence']); ?></strong></span>
                            <span class="ccdeck-chip">Cap: <strong><?php echo esc_html( number_format_i18n($cap*100,0) ); ?>%</strong></span>
                            <span class="ccdeck-chip">Half-life: <strong><?php echo esc_html(intval($tel_settings['half_life_days'])); ?>d</strong></span>
                        </div>

                        <div class="ccdeck-inline" style="margin-top:10px;">
                            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:inline;">
                                <?php wp_nonce_field('cc_override_deck_action','_cc_nonce'); ?>
                                <input type="hidden" name="action" value="cc_override_deck" />
                                <button class="ccdeck-btn alt" name="deck_action" value="tel_mode_off" type="submit">OFF</button>
                                <button class="ccdeck-btn alt" name="deck_action" value="tel_mode_log" type="submit">LOG_ONLY</button>
                                <button class="ccdeck-btn good" name="deck_action" value="tel_mode_hint" type="submit">HINT</button>
                            </form>
                        </div>

                        <div class="ccdeck-mini">
                            <strong>Scope rule:</strong> telemetry applies per <span style="opacity:.9;">Origin→Dest→Bucket</span>.
                            If you don’t set a lane entry, there is no influence.
                        </div>

                        <hr style="border:none;border-top:1px solid #1c2440;margin:14px 0;">

                        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                            <?php wp_nonce_field('cc_override_deck_action','_cc_nonce'); ?>
                            <input type="hidden" name="action" value="cc_override_deck" />

                            <div class="ccdeck-inline">
                                <select class="ccdeck-select" name="tel_bucket">
                                    <option value="morning">morning</option>
                                    <option value="midday" selected>midday</option>
                                    <option value="evening_peak">evening_peak</option>
                                    <option value="night">night</option>
                                </select>
                                <input class="ccdeck-input" type="text" name="tel_origin_anchor" placeholder="Origin anchor (e.g. gt_kingston_hub)" />
                                <input class="ccdeck-input" type="text" name="tel_dest_anchor" placeholder="Dest anchor (e.g. gt_vlissingen_hub)" />
                            </div>

                            <div class="ccdeck-inline" style="margin-top:10px;">
                                <input class="ccdeck-input" type="number" name="tel_courier_id" placeholder="Courier ID" required />
                                <select class="ccdeck-select" name="tel_action">
                                    <option value="favor">AI Favor (+10%)</option>
                                    <option value="avoid">AI Avoid (-10%)</option>
                                    <option value="clear_nudge">Clear nudge</option>
                                    <option value="risk_high">Set SLA risk HIGH (0.80)</option>
                                    <option value="risk_clear">Clear SLA risk</option>
                                </select>
                            </div>

                            <div style="margin-top:10px;">
                                <textarea class="ccdeck-ta" name="tel_evidence" placeholder="Evidence (optional): e.g. Late 3/10 on Kingston→Vlissingen evening_peak."></textarea>
                            </div>

                            <div class="ccdeck-inline" style="margin-top:10px;">
                                <button class="ccdeck-btn good" name="deck_action" value="tel_lane_apply" type="submit">Apply Telemetry to Lane</button>
                                <span class="ccdeck-chip">Default expiry: <strong><?php echo esc_html(intval($tel_settings['expiry_default_h'])); ?>h</strong></span>
                            </div>
                        </form>

                        <hr style="border:none;border-top:1px solid #1c2440;margin:14px 0;">

                        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                            <?php wp_nonce_field('cc_override_deck_action','_cc_nonce'); ?>
                            <input type="hidden" name="action" value="cc_override_deck" />
                            <div class="ccdeck-inline">
                                <input class="ccdeck-input" type="number" name="tel_half_life_days" value="<?php echo esc_attr(intval($tel_settings['half_life_days'])); ?>" />
                                <input class="ccdeck-input" type="number" name="tel_expiry_default_h" value="<?php echo esc_attr(intval($tel_settings['expiry_default_h'])); ?>" />
                                <button class="ccdeck-btn alt" name="deck_action" value="tel_decay_save" type="submit">Save Decay/Expiry</button>
                            </div>
                            <div class="ccdeck-mini">half-life days controls decay; expiry hours controls auto-expiration when you set a new telemetry entry.</div>
                        </form>

                    </div>

                    <!-- Manual: Control vendor -->
                    <div class="ccdeck-card">
                        <h2>Control a Vendor</h2>
                        <p>Manual-only / Block / Normal.</p>
                        <form method="post" action="<?php echo esc_url( admin_url('admin-post.php') ); ?>">
                            <?php wp_nonce_field('cc_override_deck_action','_cc_nonce'); ?>
                            <input type="hidden" name="action" value="cc_override_deck" />
                            <div class="ccdeck-inline">
                                <input class="ccdeck-input" type="number" name="vendor_id" placeholder="Vendor ID" required />
                            </div>
                            <div class="ccdeck-inline" style="margin-top:10px;">
                                <button class="ccdeck-btn alt" name="deck_action" value="vendor_manual_only" type="submit">Manual-only</button>
                                <button class="ccdeck-btn danger" name="deck_action" value="vendor_block" type="submit">Block Vendor</button>
                                <button class="ccdeck-btn alt" name="deck_action" value="vendor_normal" type="submit">Normal</button>
                            </div>
                        </form>
                    </div>

                    <!-- Manual: Brain switch -->
                    <div class="ccdeck-card">
                        <h2>Dispatcher Brain</h2>
                        <p>Hard on/off switch for auto-assign.</p>
                        <div class="ccdeck-inline">
                            <span class="ccdeck-chip">
                                Auto-assign:
                                <?php if ( $enabled ) : ?>
                                    <span style="color:#34d399;">ON</span>
                                <?php else : ?>
                                    <span style="color:#ff4d6d;">OFF</span>
                                <?php endif; ?>
                            </span>
                        </div>

                        <div class="ccdeck-inline" style="margin-top:10px;">
                            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:inline;">
                                <?php wp_nonce_field('cc_override_deck_action','_cc_nonce'); ?>
                                <input type="hidden" name="action" value="cc_override_deck" />
                                <button class="ccdeck-btn danger" name="deck_action" value="brain_pause" type="submit">Pause</button>
                            </form>
                            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:inline;">
                                <?php wp_nonce_field('cc_override_deck_action','_cc_nonce'); ?>
                                <input type="hidden" name="action" value="cc_override_deck" />
                                <button class="ccdeck-btn good" name="deck_action" value="brain_resume" type="submit">Resume</button>
                            </form>
                        </div>
                    </div>

                </div>

                <div class="ccdeck-mini" style="margin-top:14px;">
                    <strong>Telemetry state:</strong> last updated <?php echo esc_html($tel_state['last_updated'] ? $tel_state['last_updated'] : '—'); ?>.
                    Entries are scoped by origin→dest→bucket, decay by half-life, and expire automatically. Manual multipliers/blocks suppress telemetry for that courier.
                </div>

            </div>
        </div>
        <?php
    }
}

Caricove_Dispatcher_CommandDeck::boot();