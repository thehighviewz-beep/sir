<?php
/**
 * Dispatcher Settings UI (Caricove)
 * Adds: WP Admin → Dispatcher → Settings
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class Caricove_Dispatcher_Settings_UI {

    const PAGE_SLUG = 'cc-dispatcher-settings';
    const OPT_SETTINGS_FALLBACK = '_cc_dispatcher_settings';

    // audit option (last 50)
    const OPT_AUDIT = '_cc_dispatcher_settings_audit';

    public static function boot() {
        add_action( 'admin_menu', array( __CLASS__, 'register_menu' ), 20 );
        add_action( 'admin_post_cc_dispatcher_settings_save', array( __CLASS__, 'handle_save' ) );
    }

    public static function register_menu() {
        add_submenu_page(
            'caricove-dispatcher-admin',
            __( 'Dispatcher Settings', 'caricove-logistics' ),
            __( 'Settings', 'caricove-logistics' ),
            'manage_options',
            self::PAGE_SLUG,
            array( __CLASS__, 'render_page' )
        );
    }

    private static function get_settings_option_key() {
        if ( class_exists( '\Caricove\Logistics\Dispatcher\Settings' ) ) {
            $const = '\Caricove\Logistics\Dispatcher\Settings::OPTION_SETTINGS';
            if ( defined( $const ) ) return constant( $const );
        }
        return self::OPT_SETTINGS_FALLBACK;
    }

    private static function defaults() {
        return array(
            'enabled'          => 1,

            // scoring weights
            'weights'          => array(
                'pickup_readiness' => 0.45,
                'fit'              => 0.20,
                'load'             => 0.15,
                'sla_safety'       => 0.10,
                'performance'      => 0.05,
                'minor_ops'        => 0.05,
            ),

            // distance normalization
            'max_distance_km'  => 15.0,

            // selection/pool
            'candidate_limit'  => 200,

            // heartbeat max age seconds (gate)
            'heartbeat_max_age'=> 300,

            // redispatch
            'redispatch_max_attempts' => 6,
            // comma list of seconds, e.g. 60,180,600
            'redispatch_backoff'      => '60,180,600,900',

            // legacy compatibility only; runtime is now truck-only for extra_heavy
            'extra_heavy_mode' => 'truck_only',

            // trust bonus (your trust-only scoring add)
            'trust_weight'     => 0.15,
            'trust_bonus_cap'  => 0.25,

            'require_fresh_heartbeat' => 1,
            'require_zone_match' => 0,
            'allow_adjacent_zone_match' => 1,
            'require_vehicle_fit' => 1,
            'require_capacity_fit' => 1,
            'honor_courier_max_active_jobs' => 1,
            'prefer_same_pickup_zone' => 1,
            'same_pickup_zone_bonus' => 0.08,
            'prefer_same_dropoff_zone' => 0,
            'same_dropoff_zone_bonus' => 0.04,
            'prefer_motorbike_eligible_small_jobs' => 1,
            'motorbike_bias_bonus' => 0.05,
            'prefer_car_medium_bulky_jobs' => 1,
            'car_bias_bonus' => 0.03,
            'eta_source' => 'cc_cp',
            'use_cc_cp_duration_for_eta' => 1,
            'use_cc_cp_duration_for_sla' => 1,
            'eta_operational_buffer_minutes' => 5,
            'pickup_approach_buffer_minutes' => 5,
            'sla_extra_buffer_minutes' => 10,
            'default_accept_window_seconds' => 12,
            'long_trip_accept_window_seconds' => 15,
            'auto_reassign_on_timeout' => 1,
            'auto_reassign_on_stale_heartbeat' => 1,
            'no_movement_timeout_seconds' => 300,
            'long_trips_are_dedicated_only' => 1,
            'backlog_enabled' => 1,
            'backlog_interval_seconds' => 60,
            'backlog_lock_ttl_seconds' => 50,
            'backlog_max_attempts' => 5,
            'backlog_max_per_sweep' => 25,
            'backlog_min_age_before_redispatch_seconds' => 30,
            'reliability_penalize_no_response' => 1,
            'reliability_no_response_penalty' => 0.05,
            'reliability_penalize_cancellations' => 1,
            'reliability_cancellation_penalty' => 0.05,
            'reliability_penalize_late_pickup' => 1,
            'reliability_late_pickup_penalty' => 0.03,
        );
    }

    private static function get_settings() {
        $opt_key = self::get_settings_option_key();
        $saved = get_option( $opt_key, array() );
        if ( ! is_array( $saved ) ) $saved = array();

        $d = self::defaults();

        // merge shallow
        $out = array_merge( $d, $saved );

        // merge nested weights safely
        $out['weights'] = array_merge( $d['weights'], ( isset($saved['weights']) && is_array($saved['weights']) ? $saved['weights'] : array() ) );
        if ( isset($out['weights']['distance']) || isset($out['weights']['sla_risk']) ) {
            $legacy = $out['weights'];
            $out['weights'] = array(
                'pickup_readiness' => isset($legacy['pickup_readiness']) ? floatval($legacy['pickup_readiness']) : floatval($legacy['distance'] ?? 0.45),
                'fit'              => isset($legacy['fit']) ? floatval($legacy['fit']) : 0.20,
                'load'             => isset($legacy['load']) ? floatval($legacy['load']) : 0.15,
                'sla_safety'       => isset($legacy['sla_safety']) ? floatval($legacy['sla_safety']) : floatval($legacy['sla_risk'] ?? 0.10),
                'performance'      => isset($legacy['performance']) ? floatval($legacy['performance']) : 0.05,
                'minor_ops'        => isset($legacy['minor_ops']) ? floatval($legacy['minor_ops']) : 0.05,
            );
        }

        return $out;
    }

    private static function clampf( $v, $min, $max ) {
        $v = floatval( $v );
        if ( $v < $min ) return $min;
        if ( $v > $max ) return $max;
        return $v;
    }

    private static function clampi( $v, $min, $max ) {
        $v = intval( $v );
        if ( $v < $min ) return $min;
        if ( $v > $max ) return $max;
        return $v;
    }

    private static function parse_backoff( $raw ) {
        $raw = is_string($raw) ? $raw : '';
        $parts = preg_split('/\s*,\s*/', trim($raw));
        $out = array();

        foreach ( $parts as $p ) {
            if ( $p === '' ) continue;
            $n = intval($p);
            if ( $n <= 0 ) continue;
            $out[] = $n;
        }

        // Always have at least one backoff step
        if ( empty($out) ) $out = array(60,180,600);

        // Cap to sane size
        $out = array_slice($out, 0, 12);

        return implode(',', $out);
    }

    private static function normalize_weights( $w ) {
        $keys = array('pickup_readiness','fit','load','sla_safety','performance','minor_ops');
        $sum = 0.0;

        foreach ( $keys as $k ) {
            $sum += isset($w[$k]) ? floatval($w[$k]) : 0.0;
        }

        if ( $sum <= 0 ) {
            return self::defaults()['weights'];
        }

        foreach ( $keys as $k ) {
            $w[$k] = floatval($w[$k]) / $sum;
        }

        return $w;
    }

    private static function add_audit_entry( array $before, array $after ) {
        $audit = get_option( self::OPT_AUDIT, array() );
        if ( ! is_array($audit) ) $audit = array();

        $uid = get_current_user_id();
        $user = $uid ? get_userdata($uid) : null;

        $entry = array(
            'ts'     => time(),
            'who'    => $user ? $user->user_login : 'unknown',
            'ip'     => isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field($_SERVER['REMOTE_ADDR']) : '',
            'before' => $before,
            'after'  => $after,
        );

        array_unshift($audit, $entry);
        $audit = array_slice($audit, 0, 50);

        update_option( self::OPT_AUDIT, $audit, false );
    }

    public static function handle_save() {
        if ( ! current_user_can('manage_options') ) wp_die('Unauthorized');
        check_admin_referer( 'cc_dispatcher_settings_save', '_cc_nonce' );

        $opt_key = self::get_settings_option_key();

        $current = self::get_settings();

        $enabled = isset($_POST['enabled']) ? intval($_POST['enabled']) : 0;
        $enabled = $enabled ? 1 : 0;

        $w = array(
            'pickup_readiness' => isset($_POST['w_pickup']) ? floatval($_POST['w_pickup']) : $current['weights']['pickup_readiness'],
            'fit'              => isset($_POST['w_fit']) ? floatval($_POST['w_fit']) : $current['weights']['fit'],
            'load'             => isset($_POST['w_load']) ? floatval($_POST['w_load']) : $current['weights']['load'],
            'sla_safety'       => isset($_POST['w_sla']) ? floatval($_POST['w_sla']) : $current['weights']['sla_safety'],
            'performance'      => isset($_POST['w_performance']) ? floatval($_POST['w_performance']) : $current['weights']['performance'],
            'minor_ops'        => isset($_POST['w_minor']) ? floatval($_POST['w_minor']) : $current['weights']['minor_ops'],
        );

        // clamp weights 0..1
        foreach ($w as $k => $v) {
            $w[$k] = self::clampf($v, 0.0, 1.0);
        }

        $normalize = ! empty($_POST['normalize_weights']) ? 1 : 0;
        if ( $normalize ) {
            $w = self::normalize_weights($w);
        }

        $max_distance_km = isset($_POST['max_distance_km']) ? self::clampf($_POST['max_distance_km'], 1.0, 250.0) : $current['max_distance_km'];
        $candidate_limit = isset($_POST['candidate_limit']) ? self::clampi($_POST['candidate_limit'], 10, 2000) : $current['candidate_limit'];
        $heartbeat_max_age = isset($_POST['heartbeat_max_age']) ? self::clampi($_POST['heartbeat_max_age'], 30, 86400) : $current['heartbeat_max_age'];

        $redispatch_max_attempts = isset($_POST['redispatch_max_attempts']) ? self::clampi($_POST['redispatch_max_attempts'], 0, 50) : $current['redispatch_max_attempts'];
        $redispatch_backoff = isset($_POST['redispatch_backoff']) ? self::parse_backoff($_POST['redispatch_backoff']) : $current['redispatch_backoff'];

        $extra_heavy_mode = isset($_POST['extra_heavy_mode']) ? sanitize_key($_POST['extra_heavy_mode']) : $current['extra_heavy_mode'];
        if ( ! in_array($extra_heavy_mode, array('truck_only'), true) ) {
            $extra_heavy_mode = $current['extra_heavy_mode'];
        }

        $trust_weight = isset($_POST['trust_weight']) ? self::clampf($_POST['trust_weight'], 0.0, 1.0) : $current['trust_weight'];
        $trust_bonus_cap = isset($_POST['trust_bonus_cap']) ? self::clampf($_POST['trust_bonus_cap'], 0.0, 1.0) : $current['trust_bonus_cap'];

        $require_fresh_heartbeat = ! empty($_POST['require_fresh_heartbeat']) ? 1 : 0;
        $require_zone_match = ! empty($_POST['require_zone_match']) ? 1 : 0;
        $allow_adjacent_zone_match = ! empty($_POST['allow_adjacent_zone_match']) ? 1 : 0;
        $require_vehicle_fit = ! empty($_POST['require_vehicle_fit']) ? 1 : 0;
        $require_capacity_fit = ! empty($_POST['require_capacity_fit']) ? 1 : 0;
        $honor_courier_max_active_jobs = ! empty($_POST['honor_courier_max_active_jobs']) ? 1 : 0;
        $prefer_same_pickup_zone = ! empty($_POST['prefer_same_pickup_zone']) ? 1 : 0;
        $same_pickup_zone_bonus = isset($_POST['same_pickup_zone_bonus']) ? self::clampf($_POST['same_pickup_zone_bonus'], 0.0, 1.0) : $current['same_pickup_zone_bonus'];
        $prefer_same_dropoff_zone = ! empty($_POST['prefer_same_dropoff_zone']) ? 1 : 0;
        $same_dropoff_zone_bonus = isset($_POST['same_dropoff_zone_bonus']) ? self::clampf($_POST['same_dropoff_zone_bonus'], 0.0, 1.0) : $current['same_dropoff_zone_bonus'];
        $prefer_motorbike_eligible_small_jobs = ! empty($_POST['prefer_motorbike_eligible_small_jobs']) ? 1 : 0;
        $motorbike_bias_bonus = isset($_POST['motorbike_bias_bonus']) ? self::clampf($_POST['motorbike_bias_bonus'], 0.0, 1.0) : $current['motorbike_bias_bonus'];
        $prefer_car_medium_bulky_jobs = ! empty($_POST['prefer_car_medium_bulky_jobs']) ? 1 : 0;
        $car_bias_bonus = isset($_POST['car_bias_bonus']) ? self::clampf($_POST['car_bias_bonus'], 0.0, 1.0) : $current['car_bias_bonus'];
        $eta_source = isset($_POST['eta_source']) ? sanitize_key($_POST['eta_source']) : $current['eta_source'];
        if ( ! in_array($eta_source, array('cc_cp','legacy_dispatcher'), true) ) { $eta_source = 'cc_cp'; }
        $use_cc_cp_duration_for_eta = ! empty($_POST['use_cc_cp_duration_for_eta']) ? 1 : 0;
        $use_cc_cp_duration_for_sla = ! empty($_POST['use_cc_cp_duration_for_sla']) ? 1 : 0;
        $eta_operational_buffer_minutes = isset($_POST['eta_operational_buffer_minutes']) ? self::clampi($_POST['eta_operational_buffer_minutes'], 0, 240) : $current['eta_operational_buffer_minutes'];
        $pickup_approach_buffer_minutes = isset($_POST['pickup_approach_buffer_minutes']) ? self::clampi($_POST['pickup_approach_buffer_minutes'], 0, 240) : $current['pickup_approach_buffer_minutes'];
        $sla_extra_buffer_minutes = isset($_POST['sla_extra_buffer_minutes']) ? self::clampi($_POST['sla_extra_buffer_minutes'], 0, 240) : $current['sla_extra_buffer_minutes'];
        $default_accept_window_seconds = isset($_POST['default_accept_window_seconds']) ? self::clampi($_POST['default_accept_window_seconds'], 5, 120) : $current['default_accept_window_seconds'];
        $long_trip_accept_window_seconds = isset($_POST['long_trip_accept_window_seconds']) ? self::clampi($_POST['long_trip_accept_window_seconds'], 5, 180) : $current['long_trip_accept_window_seconds'];
        $auto_reassign_on_timeout = ! empty($_POST['auto_reassign_on_timeout']) ? 1 : 0;
        $auto_reassign_on_stale_heartbeat = ! empty($_POST['auto_reassign_on_stale_heartbeat']) ? 1 : 0;
        $no_movement_timeout_seconds = isset($_POST['no_movement_timeout_seconds']) ? self::clampi($_POST['no_movement_timeout_seconds'], 30, 7200) : $current['no_movement_timeout_seconds'];
        $long_trips_are_dedicated_only = ! empty($_POST['long_trips_are_dedicated_only']) ? 1 : 0;
        $backlog_enabled = ! empty($_POST['backlog_enabled']) ? 1 : 0;
        $backlog_interval_seconds = isset($_POST['backlog_interval_seconds']) ? self::clampi($_POST['backlog_interval_seconds'], 30, 3600) : $current['backlog_interval_seconds'];
        $backlog_lock_ttl_seconds = isset($_POST['backlog_lock_ttl_seconds']) ? self::clampi($_POST['backlog_lock_ttl_seconds'], 10, 3600) : $current['backlog_lock_ttl_seconds'];
        $backlog_max_attempts = isset($_POST['backlog_max_attempts']) ? self::clampi($_POST['backlog_max_attempts'], 0, 50) : $current['backlog_max_attempts'];
        $backlog_max_per_sweep = isset($_POST['backlog_max_per_sweep']) ? self::clampi($_POST['backlog_max_per_sweep'], 1, 500) : $current['backlog_max_per_sweep'];
        $backlog_min_age_before_redispatch_seconds = isset($_POST['backlog_min_age_before_redispatch_seconds']) ? self::clampi($_POST['backlog_min_age_before_redispatch_seconds'], 0, 3600) : $current['backlog_min_age_before_redispatch_seconds'];
        $reliability_penalize_no_response = ! empty($_POST['reliability_penalize_no_response']) ? 1 : 0;
        $reliability_no_response_penalty = isset($_POST['reliability_no_response_penalty']) ? self::clampf($_POST['reliability_no_response_penalty'], 0.0, 1.0) : $current['reliability_no_response_penalty'];
        $reliability_penalize_cancellations = ! empty($_POST['reliability_penalize_cancellations']) ? 1 : 0;
        $reliability_cancellation_penalty = isset($_POST['reliability_cancellation_penalty']) ? self::clampf($_POST['reliability_cancellation_penalty'], 0.0, 1.0) : $current['reliability_cancellation_penalty'];
        $reliability_penalize_late_pickup = ! empty($_POST['reliability_penalize_late_pickup']) ? 1 : 0;
        $reliability_late_pickup_penalty = isset($_POST['reliability_late_pickup_penalty']) ? self::clampf($_POST['reliability_late_pickup_penalty'], 0.0, 1.0) : $current['reliability_late_pickup_penalty'];

        $new = $current;
        $new['enabled'] = $enabled;
        $new['weights'] = $w;
        $new['max_distance_km'] = $max_distance_km;
        $new['candidate_limit'] = $candidate_limit;
        $new['heartbeat_max_age'] = $heartbeat_max_age;
        $new['redispatch_max_attempts'] = $redispatch_max_attempts;
        $new['redispatch_backoff'] = $redispatch_backoff;
        $new['extra_heavy_mode'] = $extra_heavy_mode;
        $new['trust_weight'] = $trust_weight;
        $new['trust_bonus_cap'] = $trust_bonus_cap;
        $new['require_fresh_heartbeat'] = $require_fresh_heartbeat;
        $new['require_zone_match'] = $require_zone_match;
        $new['allow_adjacent_zone_match'] = $allow_adjacent_zone_match;
        $new['require_vehicle_fit'] = $require_vehicle_fit;
        $new['require_capacity_fit'] = $require_capacity_fit;
        $new['honor_courier_max_active_jobs'] = $honor_courier_max_active_jobs;
        $new['prefer_same_pickup_zone'] = $prefer_same_pickup_zone;
        $new['same_pickup_zone_bonus'] = $same_pickup_zone_bonus;
        $new['prefer_same_dropoff_zone'] = $prefer_same_dropoff_zone;
        $new['same_dropoff_zone_bonus'] = $same_dropoff_zone_bonus;
        $new['prefer_motorbike_eligible_small_jobs'] = $prefer_motorbike_eligible_small_jobs;
        $new['motorbike_bias_bonus'] = $motorbike_bias_bonus;
        $new['prefer_car_medium_bulky_jobs'] = $prefer_car_medium_bulky_jobs;
        $new['car_bias_bonus'] = $car_bias_bonus;
        $new['eta_source'] = $eta_source;
        $new['use_cc_cp_duration_for_eta'] = $use_cc_cp_duration_for_eta;
        $new['use_cc_cp_duration_for_sla'] = $use_cc_cp_duration_for_sla;
        $new['eta_operational_buffer_minutes'] = $eta_operational_buffer_minutes;
        $new['pickup_approach_buffer_minutes'] = $pickup_approach_buffer_minutes;
        $new['sla_extra_buffer_minutes'] = $sla_extra_buffer_minutes;
        $new['default_accept_window_seconds'] = $default_accept_window_seconds;
        $new['long_trip_accept_window_seconds'] = $long_trip_accept_window_seconds;
        $new['auto_reassign_on_timeout'] = $auto_reassign_on_timeout;
        $new['auto_reassign_on_stale_heartbeat'] = $auto_reassign_on_stale_heartbeat;
        $new['no_movement_timeout_seconds'] = $no_movement_timeout_seconds;
        $new['long_trips_are_dedicated_only'] = $long_trips_are_dedicated_only;
        $new['backlog_enabled'] = $backlog_enabled;
        $new['backlog_interval_seconds'] = $backlog_interval_seconds;
        $new['backlog_lock_ttl_seconds'] = $backlog_lock_ttl_seconds;
        $new['backlog_max_attempts'] = $backlog_max_attempts;
        $new['backlog_max_per_sweep'] = $backlog_max_per_sweep;
        $new['backlog_min_age_before_redispatch_seconds'] = $backlog_min_age_before_redispatch_seconds;
        $new['reliability_penalize_no_response'] = $reliability_penalize_no_response;
        $new['reliability_no_response_penalty'] = $reliability_no_response_penalty;
        $new['reliability_penalize_cancellations'] = $reliability_penalize_cancellations;
        $new['reliability_cancellation_penalty'] = $reliability_cancellation_penalty;
        $new['reliability_penalize_late_pickup'] = $reliability_penalize_late_pickup;
        $new['reliability_late_pickup_penalty'] = $reliability_late_pickup_penalty;

        update_option( $opt_key, $new, false );

        self::add_audit_entry( $current, $new );

        wp_safe_redirect( add_query_arg(
            array(
                'page' => self::PAGE_SLUG,
                'saved' => 1,
            ),
            admin_url('admin.php?page=' . self::PAGE_SLUG)
        ) );
        exit;
    }

    public static function render_page() {
        if ( ! current_user_can('manage_options') ) return;

        $s = self::get_settings();
        $saved = ! empty($_GET['saved']);

        $audit = get_option( self::OPT_AUDIT, array() );
        if ( ! is_array($audit) ) $audit = array();

        ?>
        <div class="wrap">
            <h1>Dispatcher Settings</h1>
            <p class="description">Knobs that tune assignment behavior. Safe ranges enforced. Changes are audited.</p>

            <style>
                .ccvX {
                    max-width: 1200px;
                    margin-top: 14px;
                    background: radial-gradient(1200px 600px at 15% 0%, rgba(64,160,255,.18), rgba(0,0,0,0)),
                                radial-gradient(900px 500px at 85% 10%, rgba(140,80,255,.14), rgba(0,0,0,0)),
                                linear-gradient(180deg,#070B14,#04060C);
                    border: 1px solid rgba(120,180,255,.18);
                    border-radius: 18px;
                    box-shadow: 0 20px 60px rgba(0,0,0,.65), 0 0 0 1px rgba(80,160,255,.06) inset;
                    color: #fff;
                    padding: 18px;
                }
                .ccvX-top {
                    display:flex; gap:12px; align-items:center; justify-content:space-between; flex-wrap:wrap;
                    padding: 6px 2px 14px 2px;
                }
                .ccvX-pill {
                    display:inline-flex; align-items:center; gap:10px;
                    padding: 10px 12px;
                    border-radius: 999px;
                    border: 1px solid rgba(255,255,255,.10);
                    background: rgba(255,255,255,.04);
                    font-weight: 800;
                }
                .ccvX-dot { width:10px; height:10px; border-radius:999px; box-shadow:0 0 18px rgba(120,200,255,.55); display:inline-block; }
                .ccvX-dot.ok { background:#34d399; }
                .ccvX-dot.bad{ background:#ff4d6d; }
                .ccvX-grid {
                    display:grid;
                    grid-template-columns: 1fr 1fr;
                    gap: 14px;
                }
                @media (max-width: 980px){
                    .ccvX-grid { grid-template-columns: 1fr; }
                }
                .ccvX-card{
                    background: rgba(255,255,255,.03);
                    border: 1px solid rgba(255,255,255,.08);
                    border-radius: 16px;
                    box-shadow: 0 18px 55px rgba(0,0,0,.50);
                    padding: 16px;
                }
                .ccvX-card h2{ margin:0 0 8px; font-size:16px; color:#74d0ff; }
                .ccvX-muted{ opacity:.82; font-size:12px; line-height:1.4; margin:0 0 12px; }
                .ccvX-row{ display:flex; gap:10px; flex-wrap:wrap; align-items:center; }
                .ccvX-field{ display:flex; flex-direction:column; gap:6px; min-width: 220px; }
                .ccvX-label{ font-weight:800; font-size:12px; opacity:.9; }
                .ccvX-input{
                    padding: 11px 12px;
                    border-radius: 12px;
                    border:1px solid rgba(255,255,255,.12);
                    background: rgba(255,255,255,.90);
                    color:#000;
                    outline:none;
                    box-shadow: 0 0 0 1px rgba(0,0,0,.35) inset;
                }
                .ccvX-input:focus{ box-shadow:0 0 0 4px rgba(80,170,255,.25); }
                .ccvX-select{
                    padding: 11px 12px;
                    border-radius: 12px;
                    border:1px solid rgba(255,255,255,.12);
                    background: rgba(255,255,255,.90);
                    color:#000;
                    outline:none;
                }
                .ccvX-btn{
                    padding: 11px 14px;
                    border-radius: 12px;
                    border: 1px solid rgba(120,180,255,.22);
                    background: linear-gradient(135deg, rgba(50,140,255,.35), rgba(140,80,255,.20));
                    color:#fff;
                    font-weight: 900;
                    cursor:pointer;
                    text-decoration:none;
                    display:inline-flex; align-items:center; justify-content:center;
                }
                .ccvX-btn:hover{ filter:brightness(1.06); }
                .ccvX-btn.alt{ background: rgba(255,255,255,.06); }
                .ccvX-btn.danger{ background: linear-gradient(135deg, rgba(255,77,109,.45), rgba(193,18,31,.20)); border-color: rgba(255,77,109,.30); }
                .ccvX-note{
                    margin-top: 10px;
                    padding: 10px 12px;
                    border-radius: 14px;
                    border: 1px solid rgba(255,255,255,.10);
                    background: rgba(255,255,255,.05);
                    font-weight: 800;
                    font-size: 13px;
                }
                .ccvX-note.ok{ border-color: rgba(80,255,170,.25); box-shadow:0 0 22px rgba(80,255,170,.10); }
                .ccvX-audit{
                    margin-top: 14px;
                    border-radius: 16px;
                    overflow:hidden;
                    border: 1px solid rgba(255,255,255,.08);
                }
                .ccvX-audit table{ width:100%; border-collapse:collapse; }
                .ccvX-audit th, .ccvX-audit td{
                    padding: 12px 12px;
                    border-bottom: 1px solid rgba(255,255,255,.08);
                    text-align:left;
                    font-size: 12px;
                    white-space:nowrap;
                }
                .ccvX-audit th{ opacity:.85; text-transform:uppercase; letter-spacing:.8px; }
                .ccvX-code{ font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace; }
                .ccvX-small{ opacity:.82; font-size:11px; }
            </style>

            <div class="ccvX">

                <div class="ccvX-top">
                    <div class="ccvX-pill">
                        <span class="ccvX-dot <?php echo $s['enabled'] ? 'ok' : 'bad'; ?>"></span>
                        <span>Auto-assign: <strong><?php echo $s['enabled'] ? 'ON' : 'OFF'; ?></strong></span>
                    </div>
                    <div class="ccvX-pill">
                        <span class="ccvX-code"><?php echo esc_html( self::get_settings_option_key() ); ?></span>
                        <span class="ccvX-small">settings option</span>
                    </div>
                </div>

                <?php if ( $saved ) : ?>
                    <div class="ccvX-note ok">✅ Settings saved.</div>
                <?php endif; ?>

                <form method="post" action="<?php echo esc_url( admin_url('admin-post.php') ); ?>">
                    <?php wp_nonce_field( 'cc_dispatcher_settings_save', '_cc_nonce' ); ?>
                    <input type="hidden" name="action" value="cc_dispatcher_settings_save" />

                    <div class="ccvX-grid">

                        <div class="ccvX-card">
                            <h2>Brain</h2>
                            <p class="ccvX-muted">Emergency toggle. If OFF, dispatcher should not auto-assign (but your ops tools can still intervene).</p>
                            <div class="ccvX-row">
                                <div class="ccvX-field" style="min-width:260px;">
                                    <div class="ccvX-label">Enabled</div>
                                    <select class="ccvX-select" name="enabled">
                                        <option value="1" <?php selected( intval($s['enabled']), 1 ); ?>>ON</option>
                                        <option value="0" <?php selected( intval($s['enabled']), 0 ); ?>>OFF</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="ccvX-card">
                            <h2>Scoring Weights</h2>
                            <p class="ccvX-muted">These shape who wins. Use Normalize to keep totals sane. (Weights are 0..1.)</p>

                            <div class="ccvX-row">
                                <div class="ccvX-field">
                                    <div class="ccvX-label">Pickup readiness</div>
                                    <input class="ccvX-input" type="number" step="0.01" min="0" max="1" name="w_pickup" value="<?php echo esc_attr( $s['weights']['pickup_readiness'] ); ?>">
                                </div>
                                <div class="ccvX-field">
                                    <div class="ccvX-label">Fit</div>
                                    <input class="ccvX-input" type="number" step="0.01" min="0" max="1" name="w_fit" value="<?php echo esc_attr( $s['weights']['fit'] ); ?>">
                                </div>
                                <div class="ccvX-field">
                                    <div class="ccvX-label">Load</div>
                                    <input class="ccvX-input" type="number" step="0.01" min="0" max="1" name="w_load" value="<?php echo esc_attr( $s['weights']['load'] ); ?>">
                                </div>
                                <div class="ccvX-field">
                                    <div class="ccvX-label">SLA safety</div>
                                    <input class="ccvX-input" type="number" step="0.01" min="0" max="1" name="w_sla" value="<?php echo esc_attr( $s['weights']['sla_safety'] ); ?>">
                                </div>
                                <div class="ccvX-field">
                                    <div class="ccvX-label">Performance</div>
                                    <input class="ccvX-input" type="number" step="0.01" min="0" max="1" name="w_performance" value="<?php echo esc_attr( $s['weights']['performance'] ); ?>">
                                </div>
                                <div class="ccvX-field">
                                    <div class="ccvX-label">Minor ops</div>
                                    <input class="ccvX-input" type="number" step="0.01" min="0" max="1" name="w_minor" value="<?php echo esc_attr( $s['weights']['minor_ops'] ); ?>">
                                </div>
                            </div>

                            <div class="ccvX-row" style="margin-top:10px;">
                                <label class="ccvX-pill" style="cursor:pointer;">
                                    <input type="checkbox" name="normalize_weights" value="1" style="margin:0;">
                                    <span>Normalize weights on save</span>
                                </label>
                            </div>
                        </div>

                        <div class="ccvX-card">
                            <h2>Distance & Pool</h2>
                            <p class="ccvX-muted">Distance normalization and how many online couriers you consider per assignment.</p>

                            <div class="ccvX-row">
                                <div class="ccvX-field">
                                    <div class="ccvX-label">Max distance (km)</div>
                                    <input class="ccvX-input" type="number" step="0.1" min="1" max="250" name="max_distance_km" value="<?php echo esc_attr( $s['max_distance_km'] ); ?>">
                                </div>

                                <div class="ccvX-field">
                                    <div class="ccvX-label">Candidate limit</div>
                                    <input class="ccvX-input" type="number" step="1" min="10" max="2000" name="candidate_limit" value="<?php echo esc_attr( $s['candidate_limit'] ); ?>">
                                </div>
                            </div>
                        </div>

                        <div class="ccvX-card">
                            <h2>Heartbeat Gate</h2>
                            <p class="ccvX-muted">Max allowed heartbeat age (seconds). Couriers older than this are excluded.</p>

                            <div class="ccvX-row">
                                <div class="ccvX-field">
                                    <div class="ccvX-label">Max age (seconds)</div>
                                    <input class="ccvX-input" type="number" step="1" min="30" max="86400" name="heartbeat_max_age" value="<?php echo esc_attr( $s['heartbeat_max_age'] ); ?>">
                                </div>
                            </div>
                        </div>

                        <div class="ccvX-card">
                            <h2>Redispatch</h2>
                            <p class="ccvX-muted">How aggressively the system retries when a shipment can’t be assigned or gets stuck.</p>

                            <div class="ccvX-row">
                                <div class="ccvX-field">
                                    <div class="ccvX-label">Max attempts</div>
                                    <input class="ccvX-input" type="number" step="1" min="0" max="50" name="redispatch_max_attempts" value="<?php echo esc_attr( $s['redispatch_max_attempts'] ); ?>">
                                </div>
                                <div class="ccvX-field" style="min-width:360px;">
                                    <div class="ccvX-label">Backoff seconds (comma list)</div>
                                    <input class="ccvX-input" type="text" name="redispatch_backoff" value="<?php echo esc_attr( $s['redispatch_backoff'] ); ?>" placeholder="60,180,600,900">
                                </div>
                            </div>

                            <div class="ccvX-note" style="margin-top:10px;">
                                Example: <span class="ccvX-code">60,180,600</span> retries at 1m, 3m, 10m.
                            </div>
                        </div>

                        <div class="ccvX-card">
                            <h2>Weight / Vehicle Policy</h2>
                            <p class="ccvX-muted">Locked policy: light/medium → motorbike or car, heavy → car only, extra_heavy → truck only. No in-house auto-route.</p>

                            <div class="ccvX-note" style="margin-top:10px;">
                                Motorbike cap <span class="ccvX-code">20kg</span> • Car cap <span class="ccvX-code">180kg</span> • Truck cap <span class="ccvX-code">1500kg</span><br>
                                Weight bands: <span class="ccvX-code">light 0–8</span>, <span class="ccvX-code">medium 8–20</span>, <span class="ccvX-code">heavy 20–80</span>, <span class="ccvX-code">extra_heavy 80+</span>.
                            </div>
                            <input type="hidden" name="extra_heavy_mode" value="truck_only">
                        </div>

                        <div class="ccvX-card">
                            <h2>Trust Bonus</h2>
                            <p class="ccvX-muted">Soft bias in scoring (not eligibility). Higher trust → higher chance to win. (0..1 scale)</p>

                            <div class="ccvX-row">
                                <div class="ccvX-field">
                                    <div class="ccvX-label">trust_weight</div>
                                    <input class="ccvX-input" type="number" step="0.01" min="0" max="1" name="trust_weight" value="<?php echo esc_attr( $s['trust_weight'] ); ?>">
                                </div>
                                <div class="ccvX-field">
                                    <div class="ccvX-label">trust_bonus_cap</div>
                                    <input class="ccvX-input" type="number" step="0.01" min="0" max="1" name="trust_bonus_cap" value="<?php echo esc_attr( $s['trust_bonus_cap'] ); ?>">
                                </div>
                            </div>

                            <div class="ccvX-note" style="margin-top:10px;">
                                Tip: keep cap ≤ <span class="ccvX-code">0.25</span> so distance/SLA still matter.
                            </div>
                        </div>


                        <div class="ccvX-card">
                            <h2>Eligibility Policies</h2>
                            <p class="ccvX-muted">Hard gates only. Fresh heartbeat, zone match, vehicle fit, and courier max jobs are enforced here.</p>
                            <div class="ccvX-row">
                                <label class="ccvX-pill"><input type="checkbox" name="require_fresh_heartbeat" value="1" style="margin:0;" <?php checked( ! empty($s['require_fresh_heartbeat']) ); ?>><span>Require fresh heartbeat</span></label>
                                <label class="ccvX-pill"><input type="checkbox" name="require_zone_match" value="1" style="margin:0;" <?php checked( ! empty($s['require_zone_match']) ); ?>><span>Require zone match</span></label>
                                <label class="ccvX-pill"><input type="checkbox" name="allow_adjacent_zone_match" value="1" style="margin:0;" <?php checked( ! empty($s['allow_adjacent_zone_match']) ); ?>><span>Allow adjacent zone match</span></label>
                                <label class="ccvX-pill"><input type="checkbox" name="require_vehicle_fit" value="1" style="margin:0;" <?php checked( ! empty($s['require_vehicle_fit']) ); ?>><span>Require vehicle fit</span></label>
                                <label class="ccvX-pill"><input type="checkbox" name="require_capacity_fit" value="1" style="margin:0;" <?php checked( ! empty($s['require_capacity_fit']) ); ?>><span>Require capacity fit</span></label>
                                <label class="ccvX-pill"><input type="checkbox" name="honor_courier_max_active_jobs" value="1" style="margin:0;" <?php checked( ! empty($s['honor_courier_max_active_jobs']) ); ?>><span>Honor courier max active jobs</span></label>
                            </div>
                        </div>

                        <div class="ccvX-card">
                            <h2>Assignment Preference</h2>
                            <p class="ccvX-muted">Soft bonuses layered on top of eligibility. These shape who wins.</p>
                            <div class="ccvX-row">
                                <label class="ccvX-pill"><input type="checkbox" name="prefer_same_pickup_zone" value="1" style="margin:0;" <?php checked( ! empty($s['prefer_same_pickup_zone']) ); ?>><span>Prefer same pickup zone</span></label>
                                <label class="ccvX-pill"><input type="checkbox" name="prefer_same_dropoff_zone" value="1" style="margin:0;" <?php checked( ! empty($s['prefer_same_dropoff_zone']) ); ?>><span>Prefer same dropoff zone</span></label>
                                <label class="ccvX-pill"><input type="checkbox" name="prefer_motorbike_eligible_small_jobs" value="1" style="margin:0;" <?php checked( ! empty($s['prefer_motorbike_eligible_small_jobs']) ); ?>><span>Bias to motorbike when eligible</span></label>
                                <label class="ccvX-pill"><input type="checkbox" name="prefer_car_medium_bulky_jobs" value="1" style="margin:0;" <?php checked( ! empty($s['prefer_car_medium_bulky_jobs']) ); ?>><span>Bias to car for bulky medium jobs</span></label>
                            </div>
                            <div class="ccvX-row" style="margin-top:10px;">
                                <div class="ccvX-field"><div class="ccvX-label">Same pickup zone bonus</div><input class="ccvX-input" type="number" step="0.01" min="0" max="1" name="same_pickup_zone_bonus" value="<?php echo esc_attr( $s['same_pickup_zone_bonus'] ); ?>"></div>
                                <div class="ccvX-field"><div class="ccvX-label">Same dropoff zone bonus</div><input class="ccvX-input" type="number" step="0.01" min="0" max="1" name="same_dropoff_zone_bonus" value="<?php echo esc_attr( $s['same_dropoff_zone_bonus'] ); ?>"></div>
                                <div class="ccvX-field"><div class="ccvX-label">Motorbike bias bonus</div><input class="ccvX-input" type="number" step="0.01" min="0" max="1" name="motorbike_bias_bonus" value="<?php echo esc_attr( $s['motorbike_bias_bonus'] ); ?>"></div>
                                <div class="ccvX-field"><div class="ccvX-label">Car bias bonus</div><input class="ccvX-input" type="number" step="0.01" min="0" max="1" name="car_bias_bonus" value="<?php echo esc_attr( $s['car_bias_bonus'] ); ?>"></div>
                            </div>
                        </div>

                        <div class="ccvX-card">
                            <h2>ETA + SLA Truth</h2>
                            <p class="ccvX-muted">Keep familiar ETA/SLA metas, but feed them from cc_cp intelligence.</p>
                            <div class="ccvX-row">
                                <div class="ccvX-field" style="min-width:260px;"><div class="ccvX-label">ETA source</div><select class="ccvX-select" name="eta_source"><option value="cc_cp" <?php selected( $s['eta_source'], 'cc_cp' ); ?>>cc_cp intelligence</option><option value="legacy_dispatcher" <?php selected( $s['eta_source'], 'legacy_dispatcher' ); ?>>legacy dispatcher</option></select></div>
                            </div>
                            <div class="ccvX-row" style="margin-top:10px;">
                                <label class="ccvX-pill"><input type="checkbox" name="use_cc_cp_duration_for_eta" value="1" style="margin:0;" <?php checked( ! empty($s['use_cc_cp_duration_for_eta']) ); ?>><span>Use cc_cp duration for ETA</span></label>
                                <label class="ccvX-pill"><input type="checkbox" name="use_cc_cp_duration_for_sla" value="1" style="margin:0;" <?php checked( ! empty($s['use_cc_cp_duration_for_sla']) ); ?>><span>Use cc_cp duration for SLA</span></label>
                            </div>
                            <div class="ccvX-row" style="margin-top:10px;">
                                <div class="ccvX-field"><div class="ccvX-label">ETA operational buffer (mins)</div><input class="ccvX-input" type="number" step="1" min="0" max="240" name="eta_operational_buffer_minutes" value="<?php echo esc_attr( $s['eta_operational_buffer_minutes'] ); ?>"></div>
                                <div class="ccvX-field"><div class="ccvX-label">Pickup approach buffer (mins)</div><input class="ccvX-input" type="number" step="1" min="0" max="240" name="pickup_approach_buffer_minutes" value="<?php echo esc_attr( $s['pickup_approach_buffer_minutes'] ); ?>"></div>
                                <div class="ccvX-field"><div class="ccvX-label">SLA extra buffer (mins)</div><input class="ccvX-input" type="number" step="1" min="0" max="240" name="sla_extra_buffer_minutes" value="<?php echo esc_attr( $s['sla_extra_buffer_minutes'] ); ?>"></div>
                            </div>
                        </div>

                        <div class="ccvX-card">
                            <h2>Assignment Flow</h2>
                            <p class="ccvX-muted">Offer timing and dedicated long-trip behavior.</p>
                            <div class="ccvX-row">
                                <div class="ccvX-field"><div class="ccvX-label">Default accept window (seconds)</div><input class="ccvX-input" type="number" step="1" min="5" max="120" name="default_accept_window_seconds" value="<?php echo esc_attr( $s['default_accept_window_seconds'] ); ?>"></div>
                                <div class="ccvX-field"><div class="ccvX-label">Long-trip accept window (seconds)</div><input class="ccvX-input" type="number" step="1" min="5" max="180" name="long_trip_accept_window_seconds" value="<?php echo esc_attr( $s['long_trip_accept_window_seconds'] ); ?>"></div>
                                <div class="ccvX-field"><div class="ccvX-label">No movement timeout (seconds)</div><input class="ccvX-input" type="number" step="1" min="30" max="7200" name="no_movement_timeout_seconds" value="<?php echo esc_attr( $s['no_movement_timeout_seconds'] ); ?>"></div>
                            </div>
                            <div class="ccvX-row" style="margin-top:10px;">
                                <label class="ccvX-pill"><input type="checkbox" name="auto_reassign_on_timeout" value="1" style="margin:0;" <?php checked( ! empty($s['auto_reassign_on_timeout']) ); ?>><span>Auto reassign on timeout</span></label>
                                <label class="ccvX-pill"><input type="checkbox" name="auto_reassign_on_stale_heartbeat" value="1" style="margin:0;" <?php checked( ! empty($s['auto_reassign_on_stale_heartbeat']) ); ?>><span>Auto reassign on stale heartbeat</span></label>
                                <label class="ccvX-pill"><input type="checkbox" name="long_trips_are_dedicated_only" value="1" style="margin:0;" <?php checked( ! empty($s['long_trips_are_dedicated_only']) ); ?>><span>Long trips are dedicated only</span></label>
                            </div>
                        </div>

                        <div class="ccvX-card">
                            <h2>Backlog</h2>
                            <p class="ccvX-muted">Fallback only. Not the owner of 12/15 second offer expiry.</p>
                            <div class="ccvX-row">
                                <label class="ccvX-pill"><input type="checkbox" name="backlog_enabled" value="1" style="margin:0;" <?php checked( ! empty($s['backlog_enabled']) ); ?>><span>Backlog enabled</span></label>
                            </div>
                            <div class="ccvX-row" style="margin-top:10px;">
                                <div class="ccvX-field"><div class="ccvX-label">Interval seconds</div><input class="ccvX-input" type="number" step="1" min="30" max="3600" name="backlog_interval_seconds" value="<?php echo esc_attr( $s['backlog_interval_seconds'] ); ?>"></div>
                                <div class="ccvX-field"><div class="ccvX-label">Lock TTL seconds</div><input class="ccvX-input" type="number" step="1" min="10" max="3600" name="backlog_lock_ttl_seconds" value="<?php echo esc_attr( $s['backlog_lock_ttl_seconds'] ); ?>"></div>
                                <div class="ccvX-field"><div class="ccvX-label">Max attempts</div><input class="ccvX-input" type="number" step="1" min="0" max="50" name="backlog_max_attempts" value="<?php echo esc_attr( $s['backlog_max_attempts'] ); ?>"></div>
                                <div class="ccvX-field"><div class="ccvX-label">Max per sweep</div><input class="ccvX-input" type="number" step="1" min="1" max="500" name="backlog_max_per_sweep" value="<?php echo esc_attr( $s['backlog_max_per_sweep'] ); ?>"></div>
                                <div class="ccvX-field"><div class="ccvX-label">Min age before redispatch (seconds)</div><input class="ccvX-input" type="number" step="1" min="0" max="3600" name="backlog_min_age_before_redispatch_seconds" value="<?php echo esc_attr( $s['backlog_min_age_before_redispatch_seconds'] ); ?>"></div>
                            </div>
                        </div>

                        <div class="ccvX-card">
                            <h2>Reliability / Exceptions</h2>
                            <p class="ccvX-muted">Small penalties only. No architecture change.</p>
                            <div class="ccvX-row">
                                <label class="ccvX-pill"><input type="checkbox" name="reliability_penalize_no_response" value="1" style="margin:0;" <?php checked( ! empty($s['reliability_penalize_no_response']) ); ?>><span>Penalize no response</span></label>
                                <label class="ccvX-pill"><input type="checkbox" name="reliability_penalize_cancellations" value="1" style="margin:0;" <?php checked( ! empty($s['reliability_penalize_cancellations']) ); ?>><span>Penalize cancellations</span></label>
                                <label class="ccvX-pill"><input type="checkbox" name="reliability_penalize_late_pickup" value="1" style="margin:0;" <?php checked( ! empty($s['reliability_penalize_late_pickup']) ); ?>><span>Penalize late pickup</span></label>
                            </div>
                            <div class="ccvX-row" style="margin-top:10px;">
                                <div class="ccvX-field"><div class="ccvX-label">No response penalty</div><input class="ccvX-input" type="number" step="0.01" min="0" max="1" name="reliability_no_response_penalty" value="<?php echo esc_attr( $s['reliability_no_response_penalty'] ); ?>"></div>
                                <div class="ccvX-field"><div class="ccvX-label">Cancellation penalty</div><input class="ccvX-input" type="number" step="0.01" min="0" max="1" name="reliability_cancellation_penalty" value="<?php echo esc_attr( $s['reliability_cancellation_penalty'] ); ?>"></div>
                                <div class="ccvX-field"><div class="ccvX-label">Late pickup penalty</div><input class="ccvX-input" type="number" step="0.01" min="0" max="1" name="reliability_late_pickup_penalty" value="<?php echo esc_attr( $s['reliability_late_pickup_penalty'] ); ?>"></div>
                            </div>
                        </div>

                    </div>

                    <div style="display:flex; gap:10px; margin-top:14px; flex-wrap:wrap;">
                        <button class="ccvX-btn" type="submit">Save Settings</button>
                        <a class="ccvX-btn alt" href="<?php echo esc_url( admin_url('admin.php?page=' . self::PAGE_SLUG) ); ?>">Refresh</a>
                    </div>

                </form>

                <div class="ccvX-card" style="margin-top:14px;">
                    <h2>Audit Log</h2>
                    <p class="ccvX-muted">Last 50 settings changes. Helps you debug “why did behavior change?”</p>

                    <div class="ccvX-audit">
                        <table>
                            <thead>
                                <tr>
                                    <th>When</th>
                                    <th>Who</th>
                                    <th>IP</th>
                                    <th>Enabled</th>
                                    <th>Weights</th>
                                    <th>Max km</th>
                                    <th>Heartbeat</th>
                                    <th>Redispatch</th>
                                    <th>Vehicle Policy</th>
                                    <th>Trust</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php if ( empty($audit) ) : ?>
                                <tr><td colspan="10" style="opacity:.85;">No audit entries yet.</td></tr>
                            <?php else : ?>
                                <?php foreach ( $audit as $e ) :
                                    $when = isset($e['ts']) ? intval($e['ts']) : 0;
                                    $who  = isset($e['who']) ? $e['who'] : '';
                                    $ip   = isset($e['ip']) ? $e['ip'] : '';
                                    $after = isset($e['after']) && is_array($e['after']) ? $e['after'] : array();

                                    $w = isset($after['weights']) && is_array($after['weights']) ? $after['weights'] : array();
                                    $wtxt = sprintf(
                                        'pickup=%.2f fit=%.2f load=%.2f sla=%.2f perf=%.2f minor=%.2f',
                                        isset($w['pickup_readiness']) ? floatval($w['pickup_readiness']) : 0,
                                        isset($w['fit']) ? floatval($w['fit']) : 0,
                                        isset($w['load']) ? floatval($w['load']) : 0,
                                        isset($w['sla_safety']) ? floatval($w['sla_safety']) : 0,
                                        isset($w['performance']) ? floatval($w['performance']) : 0,
                                        isset($w['minor_ops']) ? floatval($w['minor_ops']) : 0
                                    );

                                    $rd = sprintf(
                                        'max=%d backoff=%s',
                                        isset($after['redispatch_max_attempts']) ? intval($after['redispatch_max_attempts']) : 0,
                                        isset($after['redispatch_backoff']) ? esc_html($after['redispatch_backoff']) : ''
                                    );

                                    $trust = sprintf(
                                        'w=%.2f cap=%.2f',
                                        isset($after['trust_weight']) ? floatval($after['trust_weight']) : 0,
                                        isset($after['trust_bonus_cap']) ? floatval($after['trust_bonus_cap']) : 0
                                    );
                                ?>
                                <tr>
                                    <td class="ccvX-code"><?php echo $when ? esc_html( date('Y-m-d H:i:s', $when ) ) : '—'; ?></td>
                                    <td><?php echo esc_html($who); ?></td>
                                    <td class="ccvX-code"><?php echo esc_html($ip); ?></td>
                                    <td><?php echo ! empty($after['enabled']) ? 'ON' : 'OFF'; ?></td>
                                    <td class="ccvX-code"><?php echo esc_html($wtxt); ?></td>
                                    <td class="ccvX-code"><?php echo isset($after['max_distance_km']) ? esc_html($after['max_distance_km']) : '—'; ?></td>
                                    <td class="ccvX-code"><?php echo isset($after['heartbeat_max_age']) ? esc_html($after['heartbeat_max_age']) : '—'; ?></td>
                                    <td class="ccvX-code"><?php echo esc_html($rd); ?></td>
                                    <td class="ccvX-code">truck_only (locked)</td>
                                    <td class="ccvX-code"><?php echo esc_html($trust); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                </div>

            </div>
        </div>
        <?php
    }
}

Caricove_Dispatcher_Settings_UI::boot();