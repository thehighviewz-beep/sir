<?php
/**
 * Plugin Name: Caricove Logistics — Admin
 * Description: Admin UI for Caricove Logistics (Logistics menu, Dashboard, Shipments, Couriers, Hub Storage, Connection Team, Controls).
 * Author: Caricove
 * Version: 1.3.0
 * MU Plugin: true
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * NOTE:
 * - This plugin assumes the Core engine (caricove-logistics-core) is already loaded
 *   via caricove-logistics-loader.php.
 */

use Caricove\Logistics\Core\Schema;
use Caricove\Logistics\Core\ShipmentManager;
use Caricove\Logistics\Core\CourierProfile;
use Caricove\Logistics\Core\AutoAssign;

class Caricove_Logistics_Admin {

    /**
     * Bootstrap.
     */
    public static function boot() {
        add_action( 'admin_menu', array( __CLASS__, 'register_admin_menu' ) );
        add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_admin_styles' ) );
    }

    /**
     * Aesthetic + layout styles just for Logistics screens.
     */
    public static function enqueue_admin_styles( $hook ) {
        if ( strpos( $hook, 'caricove-logistics' ) === false ) {
            return;
        }

        // High-contrast Caricove cards: black background, white numbers & text.
        $css = '
        .ccv-wrap {
            max-width: 1220px;
        }

        .ccv-cards {
            display:flex;
            flex-wrap:wrap;
            gap:22px;
            margin-top:25px;
        }
         .ccv-table th,
        .ccv-table td {
            vertical-align:top;
        }

        .ccv-status-pill {
            display:inline-block;
            padding:2px 9px;
            border-radius:999px;
            font-size:11px;
            text-transform:uppercase;
            letter-spacing:0.08em;
            background:#020617;
            border:1px solid #1f2933;
            color:#e5e7eb;
        }

        .ccv-status-pill--hub {
            background:#1d4ed8;
            border-color:#2563eb;
            color:#eff6ff;
        }

        .ccv-status-pill--day1 {
            background:#0369a1;
            border-color:#0ea5e9;
            color:#e0f2fe;
        }

        .ccv-status-pill--delivered {
            background:#065f46;
            border-color:#16a34a;
            color:#ecfdf5;
        }

        .ccv-status-pill--abandoned {
            background:#7f1d1d;
            border-color:#b91c1c;
            color:#fee2e2;
        }

        .ccv-chip {
            display:inline-block;
            padding:2px 7px;
            border-radius:999px;
            font-size:11px;
            background:#0b1120;
            border:1px solid #1f2937;
            color:#e5e7eb;
        }
         
        .ccv-card {
            flex:1 1 260px;
            padding:20px 24px;
            border-radius:14px;

            background:#020617; /* deep near-black */
            border:1px solid #1f2933;

            box-shadow:0 12px 32px rgba(0,0,0,0.45);

            color:#ffffff;
            min-width:240px;
        }

        .ccv-card h2 {
            margin:0;
            font-size:13px;
            font-weight:600;
            letter-spacing:0.12em;
            text-transform:uppercase;
            color:#e5e7eb; /* soft white */
        }

        .ccv-card .ccv-card-value {
            margin-top:8px;
            font-size:32px;
            font-weight:700;
            color:#ffffff; /* bright white number */
        }

        .ccv-card .ccv-card-sub {
            margin-top:6px;
            font-size:12px;
            color:#cbd5e1; /* gentle light gray */
        }

        .ccv-section-title {
            margin-top:32px;
            font-size:14px;
            text-transform:uppercase;
            letter-spacing:0.12em;
            color:#374151;
        }

        .ccv-hint {
            font-size:12px;
            color:#6b7280;
        }

       

        .ccv-badge {
            display:inline-block;
            padding:2px 9px;
            border-radius:999px;
            font-size:11px;
            text-transform:uppercase;
            letter-spacing:0.08em;
            background:#0f172a;
            border:1px solid #1e293b;
            color:#e5e7eb;
        }

        .ccv-pill-danger {
            background:#7f1d1d;
            border-color:#b91c1c;
            color:#fee2e2;
        }

        .ccv-pill-ok {
            background:#065f46;
            border-color:#059669;
            color:#ecfdf5;
        }

        .ccv-controls-form label {
            font-weight:600;
            display:block;
            margin-bottom:3px;
        }

        .ccv-controls-form select,
        .ccv-controls-form input[type="text"],
        .ccv-controls-form input[type="number"] {
            min-width:260px;
            max-width:100%;
        }

        .ccv-controls-form .field-group {
            margin-bottom:15px;
        }
        ';

        wp_add_inline_style( 'wp-admin', $css );
    }

    /**
     * Register top-level "Logistics" menu + submenus.
     */
    public static function register_admin_menu() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            return;
        }

        $cap = 'manage_woocommerce';

        // Top-level Logistics menu.
        add_menu_page(
            __( 'Caricove Logistics', 'caricove-logistics' ),
            __( 'Logistics', 'caricove-logistics' ),
            $cap,
            'caricove-logistics',
            array( __CLASS__, 'render_dashboard_page' ),
            'dashicons-location-alt',
            56
        );

        // Dashboard
        add_submenu_page(
            'caricove-logistics',
            __( 'Dashboard', 'caricove-logistics' ),
            __( 'Dashboard', 'caricove-logistics' ),
            $cap,
            'caricove-logistics',
            array( __CLASS__, 'render_dashboard_page' )
        );

        // Shipments screen
        add_submenu_page(
            'caricove-logistics',
            __( 'Shipments', 'caricove-logistics' ),
            __( 'Shipments', 'caricove-logistics' ),
            $cap,
            'caricove-logistics-shipments',
            array( __CLASS__, 'render_shipments_page' )
        );

        // Couriers screen
        add_submenu_page(
            'caricove-logistics',
            __( 'Couriers', 'caricove-logistics' ),
            __( 'Couriers', 'caricove-logistics' ),
            $cap,
            'caricove-logistics-couriers',
            array( __CLASS__, 'render_couriers_page' )
        );

        // Hub Storage screen
        add_submenu_page(
            'caricove-logistics',
            __( 'Hub Storage', 'caricove-logistics' ),
            __( 'Hub Storage', 'caricove-logistics' ),
            $cap,
            'caricove-logistics-hub-storage',
            array( __CLASS__, 'render_hub_storage_page' )
        );

        // Connection Team screen
        add_submenu_page(
            'caricove-logistics',
            __( 'Connection Team', 'caricove-logistics' ),
            __( 'Connection Team', 'caricove-logistics' ),
            $cap,
            'caricove-logistics-connection-team',
            array( __CLASS__, 'render_connection_team_page' )
        );

        // NEW: Controls / Overrides (your god-mode page)
        add_submenu_page(
            'caricove-logistics',
            __( 'Controls', 'caricove-logistics' ),
            __( 'Controls', 'caricove-logistics' ),
            $cap,
            'caricove-logistics-controls',
            array( __CLASS__, 'render_controls_page' )
        );
    }

    /**
     * Dashboard page.
     */
    public static function render_dashboard_page() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            return;
        }

        // Totals.
        $total_shipments = wp_count_posts( 'cc_shipment' );
        $total_any       = array_sum( (array) $total_shipments );

        // In hub storage.
        $hub_query = new \WP_Query(
            array(
                'post_type'      => 'cc_shipment',
                'post_status'    => 'any',
                'posts_per_page' => -1,
                'no_found_rows'  => true,
                'fields'         => 'ids',
                'meta_query'     => array(
                    array(
                        'key'   => Schema::META_SHIPMENT_IN_HUB_STORAGE,
                        'value' => 'yes',
                    ),
                ),
            )
        );
        $hub_count = $hub_query->post_count;

        // Abandoned.
        $abandoned_query = new \WP_Query(
            array(
                'post_type'      => 'cc_shipment',
                'post_status'    => 'any',
                'posts_per_page' => -1,
                'no_found_rows'  => true,
                'fields'         => 'ids',
                'meta_query'     => array(
                    array(
                        'key'   => Schema::META_SHIPMENT_STATUS,
                        'value' => 'abandoned_by_customer',
                    ),
                ),
            )
        );
        $abandoned_count = $abandoned_query->post_count;

        ?>
        <div class="wrap ccv-wrap">
            <h1><?php esc_html_e( 'Caricove Logistics — Dashboard', 'caricove-logistics' ); ?></h1>
            <p class="ccv-hint">
                <?php esc_html_e( 'This dashboard shows live metrics from the Logistics Core — total shipments, hub load, and items that have reached the end of their storage window.', 'caricove-logistics' ); ?>
            </p>

            <div class="ccv-cards">
                <div class="ccv-card">
                    <h2><?php esc_html_e( 'Total Shipments', 'caricove-logistics' ); ?></h2>
                    <div class="ccv-card-value"><?php echo esc_html( $total_any ); ?></div>
                    <div class="ccv-card-sub"><?php esc_html_e( 'All logistics shipments currently tracked by Caricove.', 'caricove-logistics' ); ?></div>
                </div>

                <div class="ccv-card">
                    <h2><?php esc_html_e( 'In Hub Storage', 'caricove-logistics' ); ?></h2>
                    <div class="ccv-card-value"><?php echo esc_html( $hub_count ); ?></div>
                    <div class="ccv-card-sub"><?php esc_html_e( 'Shipments currently held at the Caricove hub.', 'caricove-logistics' ); ?></div>
                </div>

                <div class="ccv-card">
                    <h2><?php esc_html_e( 'Abandoned / Expired', 'caricove-logistics' ); ?></h2>
                    <div class="ccv-card-value"><?php echo esc_html( $abandoned_count ); ?></div>
                    <div class="ccv-card-sub"><?php esc_html_e( 'Shipments whose storage window ended and are pending or completed resolution.', 'caricove-logistics' ); ?></div>
                </div>
            </div>

            <h2 class="ccv-section-title"><?php esc_html_e( 'Quick Navigation', 'caricove-logistics' ); ?></h2>
            <p>
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=caricove-logistics-shipments' ) ); ?>" class="button button-primary">
                    <?php esc_html_e( 'Open Shipments', 'caricove-logistics' ); ?>
                </a>
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=caricove-logistics-hub-storage' ) ); ?>" class="button">
                    <?php esc_html_e( 'View Hub Storage', 'caricove-logistics' ); ?>
                </a>
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=caricove-logistics-couriers' ) ); ?>" class="button">
                    <?php esc_html_e( 'Monitor Couriers', 'caricove-logistics' ); ?>
                </a>
            </p>
        </div>
        <?php
    }

    /**
     * Shipments page.
     */
 public static function render_shipments_page() {
    if ( ! current_user_can( 'manage_woocommerce' ) ) {
        return;
    }

    // Filters from GET.
    $status_filter  = isset( $_GET['ccv_status'] ) ? sanitize_text_field( wp_unslash( $_GET['ccv_status'] ) ) : '';
    $hub_filter     = isset( $_GET['ccv_in_hub'] ) ? sanitize_text_field( wp_unslash( $_GET['ccv_in_hub'] ) ) : '';
    $vendor_filter  = isset( $_GET['ccv_vendor'] ) ? intval( $_GET['ccv_vendor'] ) : 0;
    $page           = isset( $_GET['ccv_page'] ) ? max( 1, intval( $_GET['ccv_page'] ) ) : 1;
    $per_page       = 20;

    $meta_query = array( 'relation' => 'AND' );

    if ( $status_filter ) {
        $meta_query[] = array(
            'key'   => Schema::META_SHIPMENT_STATUS,
            'value' => $status_filter,
        );
    }

    if ( $hub_filter === 'yes' ) {
        $meta_query[] = array(
            'key'   => Schema::META_SHIPMENT_IN_HUB_STORAGE,
            'value' => 'yes',
        );
    } elseif ( $hub_filter === 'no' ) {
        $meta_query[] = array(
            'key'     => Schema::META_SHIPMENT_IN_HUB_STORAGE,
            'value'   => 'yes',
            'compare' => '!=',
        );
    }

    if ( $vendor_filter ) {
        $meta_query[] = array(
            'key'   => Schema::META_SHIPMENT_VENDOR_ID,
            'value' => $vendor_filter,
        );
    }

    $query_args = array(
        'post_type'      => 'cc_shipment',
        'post_status'    => 'any',
        'posts_per_page' => $per_page,
        'paged'          => $page,
        'no_found_rows'  => false,
        'meta_query'     => $meta_query,
    );

    $ship_q = new \WP_Query( $query_args );
    $shipments = $ship_q->posts;
    $total     = $ship_q->found_posts;
    $total_pages = $ship_q->max_num_pages;

    // Build list of vendors for filter.
    $vendor_options = array();
    $vendor_ids = array();

    if ( ! empty( $shipments ) ) {
        foreach ( $shipments as $post ) {
            $summary = ShipmentManager::get_shipment_summary( $post->ID );
            if ( ! empty( $summary['vendor_id'] ) ) {
                $vendor_ids[] = $summary['vendor_id'];
            }
        }
        $vendor_ids = array_unique( array_filter( $vendor_ids ) );
    }

    if ( ! empty( $vendor_ids ) ) {
        foreach ( $vendor_ids as $vid ) {
            $user = get_user_by( 'id', $vid );
            if ( $user ) {
                $vendor_options[ $vid ] = $user->display_name ? $user->display_name : $user->user_login;
            }
        }
    }

    // Known statuses for dropdown.
    $status_options = array(
        ''                       => __( 'All statuses', 'caricove-logistics' ),
        'ready_for_assignment'   => __( 'Ready for assignment', 'caricove-logistics' ),
        'assigned'               => __( 'Assigned', 'caricove-logistics' ),
        'picked_up'              => __( 'Picked up', 'caricove-logistics' ),
        'in_transit'             => __( 'In transit', 'caricove-logistics' ),
        'hub_received'           => __( 'Hub received', 'caricove-logistics' ),
        'in_hub_storage'         => __( 'In hub storage', 'caricove-logistics' ),
        'out_for_redelivery_day1'=> __( 'Out for Redelivery – Day 1', 'caricove-logistics' ),
        'delivered'              => __( 'Delivered', 'caricove-logistics' ),
        'abandoned_by_customer'  => __( 'Abandoned', 'caricove-logistics' ),
    );
    ?>
    <div class="wrap ccv-wrap">
        <h1><?php esc_html_e( 'Logistics — Shipments', 'caricove-logistics' ); ?></h1>
        <p class="ccv-hint">
            <?php esc_html_e( 'Review all logistics shipments with live logistics status, hub state, and redelivery flags.', 'caricove-logistics' ); ?>
        </p>

        <form method="get" style="margin-bottom:15px;">
            <input type="hidden" name="page" value="caricove-logistics-shipments" />

            <label for="ccv_status" style="margin-right:8px;">
                <?php esc_html_e( 'Status:', 'caricove-logistics' ); ?>
            </label>
            <select name="ccv_status" id="ccv_status" style="min-width:180px;margin-right:15px;">
                <?php foreach ( $status_options as $key => $label ) : ?>
                    <option value="<?php echo esc_attr( $key ); ?>" <?php selected( $status_filter, $key ); ?>>
                        <?php echo esc_html( $label ); ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <label for="ccv_in_hub" style="margin-right:8px;">
                <?php esc_html_e( 'In Hub:', 'caricove-logistics' ); ?>
            </label>
            <select name="ccv_in_hub" id="ccv_in_hub" style="min-width:140px;margin-right:15px;">
                <option value=""><?php esc_html_e( 'All', 'caricove-logistics' ); ?></option>
                <option value="yes" <?php selected( $hub_filter, 'yes' ); ?>><?php esc_html_e( 'Yes', 'caricove-logistics' ); ?></option>
                <option value="no"  <?php selected( $hub_filter, 'no' );  ?>><?php esc_html_e( 'No', 'caricove-logistics' ); ?></option>
            </select>

            <label for="ccv_vendor" style="margin-right:8px;">
                <?php esc_html_e( 'Vendor:', 'caricove-logistics' ); ?>
            </label>
            <select name="ccv_vendor" id="ccv_vendor" style="min-width:180px;margin-right:15px;">
                <option value="0"><?php esc_html_e( 'All vendors', 'caricove-logistics' ); ?></option>
                <?php foreach ( $vendor_options as $vid => $vname ) : ?>
                    <option value="<?php echo esc_attr( $vid ); ?>" <?php selected( $vendor_filter, $vid ); ?>>
                        <?php echo esc_html( $vname ); ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <button type="submit" class="button button-primary">
                <?php esc_html_e( 'Filter', 'caricove-logistics' ); ?>
            </button>
        </form>

        <table class="widefat striped ccv-table">
            <thead>
                <tr>
                    <th><?php esc_html_e( 'Shipment', 'caricove-logistics' ); ?></th>
                    <th><?php esc_html_e( 'Order', 'caricove-logistics' ); ?></th>
                    <th><?php esc_html_e( 'Vendor', 'caricove-logistics' ); ?></th>
                    <th><?php esc_html_e( 'Status', 'caricove-logistics' ); ?></th>
                    <th><?php esc_html_e( 'In Hub', 'caricove-logistics' ); ?></th>
                    <th><?php esc_html_e( 'Hub Received', 'caricove-logistics' ); ?></th>
                    <th><?php esc_html_e( 'Storage Expires', 'caricove-logistics' ); ?></th>
                    <th><?php esc_html_e( 'Free Used', 'caricove-logistics' ); ?></th>
                    <th><?php esc_html_e( 'Paid Attempts', 'caricove-logistics' ); ?></th>
                    <th><?php esc_html_e( 'Last Change', 'caricove-logistics' ); ?></th>
                </tr>
            </thead>
            <tbody>
            <?php if ( empty( $shipments ) ) : ?>
                <tr>
                    <td colspan="10"><?php esc_html_e( 'No shipments found for this filter.', 'caricove-logistics' ); ?></td>
                </tr>
            <?php else : ?>
                <?php foreach ( $shipments as $post ) : ?>
                    <?php
                    $sid      = $post->ID;
                    $summary  = ShipmentManager::get_shipment_summary( $sid );
                    $order_id = $summary['order_id'];
                    $vendor_id= $summary['vendor_id'];

                    $status   = $summary['status'];
                    $in_hub   = $summary['in_hub_storage'] === 'yes';
                    $hub_at   = $summary['hub_received_at'];
                    $exp_at   = $summary['storage_expires_at'];
                    $free_used= $summary['free_redelivery_used'] === 'yes';
                    $paid_cnt = $summary['paid_redelivery_count'];
                    $last_chg = $summary['last_status_change_at'];

                    // Build status pill class.
                    $status_class = 'ccv-status-pill';
                    if ( $status === 'hub_received' || $status === 'in_hub_storage' ) {
                        $status_class .= ' ccv-status-pill--hub';
                    } elseif ( $status === 'out_for_redelivery_day1' ) {
                        $status_class .= ' ccv-status-pill--day1';
                    } elseif ( $status === 'delivered' ) {
                        $status_class .= ' ccv-status-pill--delivered';
                    } elseif ( $status === 'abandoned_by_customer' ) {
                        $status_class .= ' ccv-status-pill--abandoned';
                    }
                    ?>
                    <tr>
                        <td>
                            <strong>#<?php echo esc_html( $sid ); ?></strong><br/>
                            <small><?php echo esc_html( get_the_title( $sid ) ); ?></small>
                        </td>
                        <td>
                            <?php if ( $order_id ) : ?>
                                <a href="<?php echo esc_url( get_edit_post_link( $order_id ) ); ?>">
                                    <?php echo esc_html( '#' . $order_id ); ?>
                                </a>
                            <?php else : ?>
                                <?php esc_html_e( '-', 'caricove-logistics' ); ?>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php
                            if ( $vendor_id ) {
                                $u = get_user_by( 'id', $vendor_id );
                                echo esc_html( $u ? ( $u->display_name ?: $u->user_login ) : $vendor_id );
                            } else {
                                esc_html_e( '-', 'caricove-logistics' );
                            }
                            ?>
                        </td>
                        <td>
                            <span class="<?php echo esc_attr( $status_class ); ?>">
                                <?php echo esc_html( $status ?: '-' ); ?>
                            </span>
                        </td>
                        <td>
                            <?php if ( $in_hub ) : ?>
                                <span class="ccv-chip"><?php esc_html_e( 'Yes', 'caricove-logistics' ); ?></span>
                            <?php else : ?>
                                <span class="ccv-chip"><?php esc_html_e( 'No', 'caricove-logistics' ); ?></span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php echo esc_html( $hub_at ? $hub_at : '-' ); ?>
                        </td>
                        <td>
                            <?php echo esc_html( $exp_at ? $exp_at : '-' ); ?>
                        </td>
                        <td>
                            <?php if ( $free_used ) : ?>
                                <span class="ccv-chip"><?php esc_html_e( 'Used', 'caricove-logistics' ); ?></span>
                            <?php else : ?>
                                <span class="ccv-chip"><?php esc_html_e( 'Not used', 'caricove-logistics' ); ?></span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="ccv-chip">
                                <?php echo esc_html( intval( $paid_cnt ) ); ?>
                            </span>
                        </td>
                        <td>
                            <?php echo esc_html( $last_chg ? $last_chg : '-' ); ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>

        <?php if ( $total_pages > 1 ) : ?>
            <div style="margin-top:15px;">
                <?php
                $base_url = remove_query_arg( 'ccv_page' );
                if ( $page > 1 ) {
                    $prev_url = add_query_arg( 'ccv_page', $page - 1, $base_url );
                    echo '<a class="button" href="' . esc_url( $prev_url ) . '">&laquo; ' . esc_html__( 'Previous', 'caricove-logistics' ) . '</a> ';
                }
                if ( $page < $total_pages ) {
                    $next_url = add_query_arg( 'ccv_page', $page + 1, $base_url );
                    echo '<a class="button" href="' . esc_url( $next_url ) . '">' . esc_html__( 'Next', 'caricove-logistics' ) . ' &raquo;</a>';
                }
                ?>
                <span class="ccv-hint" style="margin-left:10px;">
                    <?php
                    printf(
                        /* translators: 1: current page, 2: total pages */
                        esc_html__( 'Page %1$d of %2$d', 'caricove-logistics' ),
                        intval( $page ),
                        intval( $total_pages )
                    );
                    ?>
                </span>
            </div>
        <?php endif; ?>
    </div>
    <?php
}

    /**
     * Couriers page.
     */
    public static function render_couriers_page() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            return;
        }

        $courier_rows = array();

        $q = new \WP_User_Query(
            array(
                'role'   => CourierProfile::ROLE_COURIER,
                'number' => 200,
                'fields' => 'all',
            )
        );

        foreach ( $q->get_results() as $user ) {
            $profile = CourierProfile::get_profile( $user->ID );

            $courier_rows[] = array(
                'id'           => $user->ID,
                'name'         => $user->display_name ? $user->display_name : $user->user_login,
                'status'       => isset( $profile['status'] ) ? $profile['status'] : '',
                'region'       => isset( $profile['region'] ) ? $profile['region'] : '',
                'last_lat'     => isset( $profile['last_lat'] ) ? $profile['last_lat'] : '',
                'last_lng'     => isset( $profile['last_lng'] ) ? $profile['last_lng'] : '',
                'last_seen_ts' => isset( $profile['last_seen_ts'] ) ? intval( $profile['last_seen_ts'] ) : 0,
                'vehicle'      => isset( $profile['vehicle_type'] ) ? $profile['vehicle_type'] : '',
            );
        }

        $now = time();
        ?>
        <div class="wrap ccv-wrap">
            <h1><?php esc_html_e( 'Logistics — Couriers', 'caricove-logistics' ); ?></h1>
            <p class="ccv-hint">
                <?php esc_html_e( 'Monitor courier status, last heartbeat, approximate service region, and active job counts. This gives you a live operational view on the courier fleet.', 'caricove-logistics' ); ?>
            </p>

            <table class="widefat striped ccv-table">
                <thead>
                    <tr>
                        <th><?php esc_html_e( 'Courier', 'caricove-logistics' ); ?></th>
                        <th><?php esc_html_e( 'Status', 'caricove-logistics' ); ?></th>
                        <th><?php esc_html_e( 'Heartbeat', 'caricove-logistics' ); ?></th>
                        <th><?php esc_html_e( 'Region', 'caricove-logistics' ); ?></th>
                        <th><?php esc_html_e( 'Active Jobs', 'caricove-logistics' ); ?></th>
                    </tr>
                </thead>
                <tbody>
                <?php if ( empty( $courier_rows ) ) : ?>
                    <tr>
                        <td colspan="5"><?php esc_html_e( 'No couriers found.', 'caricove-logistics' ); ?></td>
                    </tr>
                <?php else : ?>
                    <?php foreach ( $courier_rows as $row ) : ?>
                        <?php
                        $status       = $row['status'] ? $row['status'] : 'offline';
                        $last_seen_ts = $row['last_seen_ts'];
                        $age_label    = __( 'Never', 'caricove-logistics' );
                        $pill_class   = 'ccv-badge';

                        if ( $last_seen_ts ) {
                            $age_secs = $now - $last_seen_ts;

                            if ( $age_secs < 60 ) {
                                $age_label = __( 'Just now', 'caricove-logistics' );
                            } elseif ( $age_secs < 3600 ) {
                                $mins      = floor( $age_secs / 60 );
                                $age_label = sprintf(
                                    _n( '%d minute ago', '%d minutes ago', $mins, 'caricove-logistics' ),
                                    $mins
                                );
                            } else {
                                $hours     = floor( $age_secs / 3600 );
                                $age_label = sprintf(
                                    _n( '%d hour ago', '%d hours ago', $hours, 'caricove-logistics' ),
                                    $hours
                                );
                            }

                            $max_age = apply_filters( 'cc_core_courier_max_heartbeat_age', 300, $row, array() );

                            if ( $age_secs <= $max_age ) {
                                $pill_class .= ' ccv-pill-ok';
                            } elseif ( $age_secs > $max_age * 4 ) {
                                $pill_class .= ' ccv-pill-danger';
                            }
                        }
                        $active_jobs = AutoAssign::get_courier_active_job_count( $row['id'] );
                        ?>
                        <tr>
                            <td>
                                <strong><?php echo esc_html( $row['name'] ); ?></strong><br/>
                                <small>#<?php echo esc_html( $row['id'] ); ?></small>
                            </td>
                            <td>
                                <span class="ccv-badge">
                                    <?php echo esc_html( ucfirst( $status ) ); ?>
                                </span>
                            </td>
                            <td>
                                <span class="<?php echo esc_attr( $pill_class ); ?>">
                                    <?php echo esc_html( $age_label ); ?>
                                </span>
                            </td>
                            <td>
                                <?php
                                $region_label = $row['region'];
                                if ( $region_label === CourierProfile::REGION_OFFGRID ) {
                                    $region_label = __( 'Off-grid', 'caricove-logistics' );
                                }
                                echo esc_html( $region_label ? $region_label : '-' );
                                ?>
                            </td>
                            <td>
                                <?php
                                echo esc_html(
                                    sprintf(
                                        _n( '%d active job', '%d active jobs', $active_jobs, 'caricove-logistics' ),
                                        $active_jobs
                                    )
                                );
                                ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    /**
     * Hub Storage page.
     */
    public static function render_hub_storage_page() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            return;
        }

        // Handle bulk "Mark as Abandoned".
        if (
            isset( $_POST['ccv_hub_action'], $_POST['ccv_hub_ids'], $_POST['_wpnonce'] )
            && $_POST['ccv_hub_action'] === 'abandon'
            && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'ccv_hub_storage_action' )
        ) {
            $ids = array_map( 'intval', (array) $_POST['ccv_hub_ids'] );
            foreach ( $ids as $sid ) {
                ShipmentManager::set_shipment_status(
                    $sid,
                    'abandoned_by_customer',
                    array(
                        'source' => 'hub_storage_admin',
                    )
                );
            }
            echo '<div class="updated notice"><p>' . esc_html__( 'Selected shipments marked as abandoned.', 'caricove-logistics' ) . '</p></div>';
        }

        // Query in-hub shipments.
        $hub_query = new \WP_Query(
            array(
                'post_type'      => 'cc_shipment',
                'post_status'    => 'any',
                'posts_per_page' => 50,
                'no_found_rows'  => false,
                'meta_query'     => array(
                    array(
                        'key'   => Schema::META_SHIPMENT_IN_HUB_STORAGE,
                        'value' => 'yes',
                    ),
                ),
            )
        );

        $shipments = $hub_query->posts;
        ?>
        <div class="wrap ccv-wrap">
            <h1><?php esc_html_e( 'Logistics — Hub Storage', 'caricove-logistics' ); ?></h1>
            <p class="ccv-hint">
                <?php esc_html_e( 'This screen shows shipments currently held at the Caricove hub. Use it to track time in storage and move aged items into Return Resolution by marking them as abandoned.', 'caricove-logistics' ); ?>
            </p>

            <?php if ( empty( $shipments ) ) : ?>
                <p><?php esc_html_e( 'No shipments are currently marked as being in hub storage.', 'caricove-logistics' ); ?></p>
            <?php else : ?>
                <form method="post">
                    <?php wp_nonce_field( 'ccv_hub_storage_action' ); ?>
                    <table class="widefat striped ccv-table">
                        <thead>
                            <tr>
                                <th style="width:20px;">
                                    <input type="checkbox" onclick="jQuery(\'.ccv-hub-checkbox\').prop(\'checked\', this.checked);" />
                                </th>
                                <th><?php esc_html_e( 'Shipment', 'caricove-logistics' ); ?></th>
                                <th><?php esc_html_e( 'Order', 'caricove-logistics' ); ?></th>
                                <th><?php esc_html_e( 'Vendor', 'caricove-logistics' ); ?></th>
                                <th><?php esc_html_e( 'Hub Received', 'caricove-logistics' ); ?></th>
                                <th><?php esc_html_e( 'Storage Expires', 'caricove-logistics' ); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ( $shipments as $post ) : ?>
                            <?php
                            $sid        = $post->ID;
                            $summary    = ShipmentManager::get_shipment_summary( $sid );
                            $order_id   = $summary['order_id'];
                            $vendor_id  = $summary['vendor_id'];
                            $hub_at     = $summary['hub_received_at'];
                            $expires_at = $summary['storage_expires_at'];
                            ?>
                            <tr>
                                <td>
                                    <input type="checkbox" class="ccv-hub-checkbox" name="ccv_hub_ids[]" value="<?php echo esc_attr( $sid ); ?>" />
                                </td>
                                <td>
                                    <strong>#<?php echo esc_html( $sid ); ?></strong><br/>
                                    <span class="ccv-badge"><?php echo esc_html( $summary['status'] ); ?></span>
                                </td>
                                <td>
                                    <?php if ( $order_id ) : ?>
                                        <a href="<?php echo esc_url( get_edit_post_link( $order_id ) ); ?>">
                                            <?php echo esc_html( '#' . $order_id ); ?>
                                        </a>
                                    <?php else : ?>
                                        <?php esc_html_e( '-', 'caricove-logistics' ); ?>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php
                                    if ( $vendor_id ) {
                                        $user = get_user_by( 'id', $vendor_id );
                                        echo esc_html( $user ? $user->display_name : $vendor_id );
                                    } else {
                                        esc_html_e( '-', 'caricove-logistics' );
                                    }
                                    ?>
                                </td>
                                <td>
                                    <?php echo esc_html( $hub_at ? $hub_at : '-' ); ?>
                                </td>
                                <td>
                                    <?php echo esc_html( $expires_at ? $expires_at : '-' ); ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>

                    <p style="margin-top:10px;">
                        <select name="ccv_hub_action">
                            <option value=""><?php esc_html_e( 'Bulk actions', 'caricove-logistics' ); ?></option>
                            <option value="abandon"><?php esc_html_e( 'Mark as Abandoned', 'caricove-logistics' ); ?></option>
                        </select>
                        <button type="submit" class="button button-primary">
                            <?php esc_html_e( 'Apply', 'caricove-logistics' ); ?>
                        </button>
                    </p>
                </form>
            <?php endif; ?>
        </div>
        <?php
    }

    /**
     * Connection Team page.
     */
    public static function render_connection_team_page() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            return;
        }

        ?>
        <div class="wrap ccv-wrap">
            <h1><?php esc_html_e( 'Logistics — Connection Team', 'caricove-logistics' ); ?></h1>
            <p class="ccv-hint">
                <?php esc_html_e( 'The Connection Team console manages customer contact attempts for paid re-delivery cycles. As the call-cycle engine comes online, this screen will show which customers have been reached, which are pending, and when the next attempt is due.', 'caricove-logistics' ); ?>
            </p>
            <p class="ccv-hint">
                <?php esc_html_e( 'At this stage, the UI shell is active and safe. The underlying 3-day, 30/60/120 call logic will be wired into the Logistics Core and displayed here in a later phase.', 'caricove-logistics' ); ?>
            </p>
        </div>
        <?php
    }

    /**
     * NEW: Controls / Overrides page.
     *
     * Lazy-but-god-mode controls for couriers: dropdown + status/heartbeat/GPS.
     */
    public static function render_controls_page() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            return;
        }

        self::handle_controls_actions();

        // Build courier dropdown.
        $courier_users = get_users(
            array(
                'role'   => CourierProfile::ROLE_COURIER,
                'number' => 500,
                'fields' => array( 'ID', 'display_name', 'user_login' ),
            )
        );

        ?>
        <div class="wrap ccv-wrap">
            <h1><?php esc_html_e( 'Logistics — Controls', 'caricove-logistics' ); ?></h1>
            <p class="ccv-hint">
                <?php esc_html_e( 'Use these controls for support and emergency interventions. You can adjust courier status, refresh heartbeat, and override GPS using a dropdown instead of manually typing IDs.', 'caricove-logistics' ); ?>
            </p>

            <?php settings_errors( 'ccv_logistics_controls' ); ?>

            <h2 class="ccv-section-title"><?php esc_html_e( 'Courier Controls', 'caricove-logistics' ); ?></h2>

            <form method="post" class="ccv-controls-form">
                <?php wp_nonce_field( 'ccv_logistics_controls_action', 'ccv_logistics_controls_nonce' ); ?>

                <div class="field-group">
                    <label for="ccv_courier_id"><?php esc_html_e( 'Select Courier', 'caricove-logistics' ); ?></label>
                    <select name="ccv_courier_id" id="ccv_courier_id">
                        <option value=""><?php esc_html_e( 'Choose a courier…', 'caricove-logistics' ); ?></option>
                        <?php foreach ( $courier_users as $u ) : ?>
                            <?php
                            $label = $u->display_name ? $u->display_name : $u->user_login;
                            $label .= ' (#' . $u->ID . ')';
                            ?>
                            <option value="<?php echo esc_attr( $u->ID ); ?>">
                                <?php echo esc_html( $label ); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="field-group">
                    <label for="ccv_courier_status"><?php esc_html_e( 'Set Status', 'caricove-logistics' ); ?></label>
                    <select name="ccv_courier_status" id="ccv_courier_status">
                        <option value=""><?php esc_html_e( 'Do not change', 'caricove-logistics' ); ?></option>
                        <option value="online"><?php esc_html_e( 'Online', 'caricove-logistics' ); ?></option>
                        <option value="busy"><?php esc_html_e( 'Busy', 'caricove-logistics' ); ?></option>
                        <option value="offline"><?php esc_html_e( 'Offline', 'caricove-logistics' ); ?></option>
                    </select>
                </div>

                <div class="field-group">
                    <label><?php esc_html_e( 'Heartbeat & GPS', 'caricove-logistics' ); ?></label>
                    <label style="display:block;margin-bottom:4px;">
                        <input type="checkbox" name="ccv_mark_heartbeat" value="1" />
                        <?php esc_html_e( 'Mark heartbeat as fresh (now)', 'caricove-logistics' ); ?>
                    </label>
                    <span class="ccv-hint">
                        <?php esc_html_e( 'Checking this will update the last_seen timestamp. If the courier is online, the dispatcher may try to feed them waiting jobs.', 'caricove-logistics' ); ?>
                    </span>
                </div>

                <div class="field-group">
                    <label><?php esc_html_e( 'Override GPS (Optional)', 'caricove-logistics' ); ?></label>
                    <input type="text" name="ccv_courier_lat" placeholder="Lat e.g. 6.816" />
                    <input type="text" name="ccv_courier_lng" placeholder="Lng e.g. -58.16" />
                    <p class="ccv-hint">
                        <?php esc_html_e( 'If you set both lat & lng, the courier region will be recalculated. This will also mark the region source as manual override.', 'caricove-logistics' ); ?>
                    </p>
                </div>

                <p>
                    <button type="submit" class="button button-primary" name="ccv_controls_action" value="apply_courier">
                        <?php esc_html_e( 'Apply Courier Controls', 'caricove-logistics' ); ?>
                    </button>
                </p>
            </form>
        </div>
        <?php
    }

    /**
     * Handle POST for Controls / Overrides (courier side).
     */
    protected static function handle_controls_actions() {
        if ( ! isset( $_POST['ccv_controls_action'] ) ) {
            return;
        }

        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            return;
        }

        if ( ! isset( $_POST['ccv_logistics_controls_nonce'] ) ||
             ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ccv_logistics_controls_nonce'] ) ), 'ccv_logistics_controls_action' )
        ) {
            add_settings_error(
                'ccv_logistics_controls',
                'ccv_bad_nonce',
                __( 'Security check failed. Please try again.', 'caricove-logistics' )
            );
            return;
        }

        $action     = sanitize_text_field( wp_unslash( $_POST['ccv_controls_action'] ) );
        $courier_id = isset( $_POST['ccv_courier_id'] ) ? intval( $_POST['ccv_courier_id'] ) : 0;

        if ( ! $courier_id ) {
            add_settings_error(
                'ccv_logistics_controls',
                'ccv_no_courier',
                __( 'Please select a courier.', 'caricove-logistics' )
            );
            return;
        }

        if ( 'apply_courier' === $action ) {

            // 1) Update status if provided.
            if ( ! empty( $_POST['ccv_courier_status'] ) ) {
                $new_status = sanitize_text_field( wp_unslash( $_POST['ccv_courier_status'] ) );
                $allowed    = array( 'online', 'offline', 'busy' );

                if ( in_array( $new_status, $allowed, true ) ) {
                    update_user_meta( $courier_id, CourierProfile::META_STATUS, $new_status );
                }
            }

            // 2) Mark heartbeat fresh if requested.
            if ( ! empty( $_POST['ccv_mark_heartbeat'] ) ) {
                update_user_meta( $courier_id, CourierProfile::META_LAST_SEEN_TS, time() );
                // Ensure region from GPS unless manually overridden.
                CourierProfile::ensure_region_for_courier( $courier_id );
            }

            // 3) Override GPS if both lat & lng provided.
            $lat = isset( $_POST['ccv_courier_lat'] ) ? trim( (string) $_POST['ccv_courier_lat'] ) : '';
            $lng = isset( $_POST['ccv_courier_lng'] ) ? trim( (string) $_POST['ccv_courier_lng'] ) : '';

            if ( $lat !== '' && $lng !== '' && is_numeric( $lat ) && is_numeric( $lng ) ) {
                update_user_meta( $courier_id, CourierProfile::META_LAST_LAT, floatval( $lat ) );
                update_user_meta( $courier_id, CourierProfile::META_LAST_LNG, floatval( $lng ) );
                update_user_meta( $courier_id, CourierProfile::META_LAST_SEEN_TS, time() );

                // Mark region source as manual override so heartbeat logic won’t auto-change it.
                update_user_meta( $courier_id, CourierProfile::META_REGION_SOURCE, 'manual_override' );
            }

            add_settings_error(
                'ccv_logistics_controls',
                'ccv_controls_updated',
                __( 'Courier controls applied successfully.', 'caricove-logistics' ),
                'updated'
            );
        }
    }
}



Caricove_Logistics_Admin::boot();