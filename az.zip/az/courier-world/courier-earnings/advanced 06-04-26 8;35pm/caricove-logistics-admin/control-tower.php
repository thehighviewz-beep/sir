<?php
/**
 * Plugin Name: Caricove Dispatcher — HOLD / Redispatch Control Tower (Sexy Ops UI)
 * Description: Dispatcher → HOLD Queue. Rescue stuck shipments: Retry, Force Assign, Send to Manual Review, Clear Lock, Explain.
 * Author: Caricove
 * MU Plugin: true
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class Caricove_Dispatcher_Hold_Control_Tower {

    const PAGE_SLUG = 'cc-dispatcher-hold-tower';

    // Shipment meta (best-effort defaults; override via filters if your keys differ)
    const META_STATUS            = '_cc_status';
    const META_HOLD_REASON       = '_cc_hold_reason';
    const META_HOLD_SINCE_TS     = '_cc_hold_since_ts';
    const META_ATTEMPTS          = '_cc_redispatch_attempts';
    const META_LAST_CAND_COUNT   = '_cc_last_candidate_count';
    const META_ORIGIN_ANCHOR     = '_cc_origin_anchor';
    const META_DEST_ANCHOR       = '_cc_destination_anchor';
    const META_SIZE_BAND         = '_cc_size_band';
    const META_WEIGHT_BAND       = '_cc_weight_band';
    const META_INHOUSE_FLAG      = '_cc_inhouse_queue';

    // Courier assignment meta (if you store it)
    const META_ASSIGNED_COURIER  = '_cc_assigned_courier_id';

    // Overrides option (same shape as your command deck)
    const OPT_OVERRIDES_FALLBACK = '_cc_dispatcher_overrides';

    public static function boot() {
        add_action( 'admin_menu', array( __CLASS__, 'register_menu' ), 30 );

        add_action( 'admin_post_cc_hold_retry',        array( __CLASS__, 'handle_retry' ) );
        add_action( 'admin_post_cc_hold_force',        array( __CLASS__, 'handle_force_assign' ) );
        add_action( 'admin_post_cc_hold_inhouse',      array( __CLASS__, 'handle_send_inhouse' ) );
        add_action( 'admin_post_cc_hold_manual_review', array( __CLASS__, 'handle_send_inhouse' ) );
        add_action( 'admin_post_cc_hold_clear_lock',   array( __CLASS__, 'handle_clear_lock' ) );
    }

    public static function register_menu() {
        add_submenu_page(
            'caricove-dispatcher-admin',
            __( 'HOLD / Redispatch', 'caricove-logistics' ),
            __( 'HOLD Queue', 'caricove-logistics' ),
            'manage_options',
            self::PAGE_SLUG,
            array( __CLASS__, 'render_page' )
        );
    }

    /* -----------------------------
     * Helpers
     * -------------------------- */

    private static function shipment_cpt() {
        return apply_filters( 'cc_logistics_shipment_cpt', 'cc_shipment' );
    }

    private static function hold_statuses() {
        // Adjust anytime; can also be overridden by filter.
        $defaults = array(
            'hold',
            'hold_no_courier',
            'hold_secure_courier',
            'hold_redispatch',
            'unassigned',
            'pending_dispatch',
            'needs_assignment',
        );
        return apply_filters( 'cc_dispatcher_hold_statuses', $defaults );
    }

    private static function inhouse_statuses() {
        $defaults = array( 'manual', 'manual_only' );
        return apply_filters( 'cc_dispatcher_inhouse_statuses', $defaults );
    }

    private static function get_overrides_option_key() {
        if ( class_exists( '\Caricove\Logistics\Dispatcher\Overrides' ) ) {
            $const = '\Caricove\Logistics\Dispatcher\Overrides::OPTION_OVERRIDES';
            if ( defined( $const ) ) return constant( $const );
        }
        return self::OPT_OVERRIDES_FALLBACK;
    }

    private static function get_overrides() {
        $opt = get_option( self::get_overrides_option_key(), array() );
        return is_array( $opt ) ? $opt : array();
    }

    private static function save_overrides( array $overrides ) {
        update_option( self::get_overrides_option_key(), $overrides, false );
    }

    private static function ensure_overrides_shape( array $ov ) {
        $defaults = array(
            'courier_blocklist'          => array(),
            'courier_weight_adjustments' => array(),
            'vendor_blocklist'           => array(),
            'vendor_manual_only'         => array(),
            'shipment_locks'             => array(),
            'shipment_forced_courier'    => array(),
        );
        $ov = array_merge( $defaults, $ov );
        foreach ( $defaults as $k => $v ) {
            if ( ! isset( $ov[$k] ) || ! is_array( $ov[$k] ) ) $ov[$k] = array();
        }
        return $ov;
    }

    private static function safe_int_meta( $post_id, $key, $default = 0 ) {
        $v = get_post_meta( $post_id, $key, true );
        if ( $v === '' || $v === null ) return $default;
        return intval( $v );
    }

    private static function safe_str_meta( $post_id, $key, $default = '' ) {
        $v = get_post_meta( $post_id, $key, true );
        if ( $v === '' || $v === null ) return $default;
        return (string) $v;
    }

    private static function age_human( $since_ts ) {
        $since_ts = intval( $since_ts );
        if ( $since_ts <= 0 ) return '—';
        $sec = time() - $since_ts;
        if ( $sec < 0 ) $sec = 0;

        $m = floor($sec / 60);
        if ( $m < 60 ) return $m . 'm';

        $h = floor($m / 60);
        $m = $m % 60;
        if ( $h < 24 ) return $h . 'h ' . $m . 'm';

        $d = floor($h / 24);
        $h = $h % 24;
        return $d . 'd ' . $h . 'h';
    }

    private static function admin_url_page( $args = array() ) {
        $base = admin_url( 'admin.php?page=' . self::PAGE_SLUG );
        if ( empty($args) ) return $base;
        return add_query_arg( $args, $base );
    }

    private static function notice( $key ) {
        $map = array(
            'retry_ok'      => '✅ Redispatch triggered.',
            'force_ok'      => '✅ Forced courier saved (and retry triggered).',
            'inhouse_ok'    => '✅ Sent to Manual Review queue.',
            'manual_review_ok' => '✅ Sent to Manual Review queue.',
            'clearlock_ok'  => '✅ Shipment lock cleared.',
            'bad'           => '⚠️ Something went wrong.',
        );
        return isset($map[$key]) ? $map[$key] : '';
    }

    /* -----------------------------
     * Actions
     * -------------------------- */

    public static function handle_retry() {
        if ( ! current_user_can('manage_options') ) wp_die('Unauthorized');
        check_admin_referer( 'cc_hold_action', '_cc_nonce' );

        $shipment_id = isset($_GET['shipment_id']) ? intval($_GET['shipment_id']) : 0;
        if ( ! $shipment_id ) {
            wp_safe_redirect( self::admin_url_page( array('notice'=>'bad') ) );
            exit;
        }

        // Let your redispatcher/dispatcher handle it
        do_action( 'caricove_dispatcher_retry_assignment', $shipment_id, 'admin_retry' );

        // Best-effort: bump status out of hold if you want (optional; filterable)
        if ( apply_filters('cc_dispatcher_hold_retry_touch_status', false, $shipment_id) ) {
            update_post_meta( $shipment_id, self::META_STATUS, 'pending_dispatch' );
        }

        wp_safe_redirect( self::admin_url_page( array('notice'=>'retry_ok') ) );
        exit;
    }

    public static function handle_force_assign() {
        if ( ! current_user_can('manage_options') ) wp_die('Unauthorized');
        check_admin_referer( 'cc_hold_action', '_cc_nonce' );

        $shipment_id = isset($_POST['shipment_id']) ? intval($_POST['shipment_id']) : 0;
        $courier_id  = isset($_POST['force_courier_id']) ? intval($_POST['force_courier_id']) : 0;

        if ( ! $shipment_id || ! $courier_id ) {
            wp_safe_redirect( self::admin_url_page( array('notice'=>'bad') ) );
            exit;
        }

        $ov = self::ensure_overrides_shape( self::get_overrides() );
        $ov['shipment_forced_courier'][ $shipment_id ] = $courier_id;
        self::save_overrides( $ov );

        // Trigger dispatch attempt
        do_action( 'caricove_dispatcher_retry_assignment', $shipment_id, 'admin_force' );

        wp_safe_redirect( self::admin_url_page( array('notice'=>'force_ok') ) );
        exit;
    }

    public static function handle_send_inhouse() {
        if ( ! current_user_can('manage_options') ) wp_die('Unauthorized');
        check_admin_referer( 'cc_hold_action', '_cc_nonce' );

        $shipment_id = isset($_GET['shipment_id']) ? intval($_GET['shipment_id']) : 0;
        if ( ! $shipment_id ) {
            wp_safe_redirect( self::admin_url_page( array('notice'=>'bad') ) );
            exit;
        }

        update_post_meta( $shipment_id, self::META_INHOUSE_FLAG, 0 );
        update_post_meta( $shipment_id, self::META_STATUS, 'manual' );
        update_post_meta( $shipment_id, self::META_HOLD_REASON, 'manual_review' );

        do_action( 'caricove_dispatcher_manual_review_requested', $shipment_id, 'admin' );
        do_action( 'caricove_dispatcher_sent_inhouse', $shipment_id, 'admin_manual_review' );

        wp_safe_redirect( self::admin_url_page( array('notice'=>'manual_review_ok') ) );
        exit;
    }

    public static function handle_clear_lock() {
        if ( ! current_user_can('manage_options') ) wp_die('Unauthorized');
        check_admin_referer( 'cc_hold_action', '_cc_nonce' );

        $shipment_id = isset($_GET['shipment_id']) ? intval($_GET['shipment_id']) : 0;
        if ( ! $shipment_id ) {
            wp_safe_redirect( self::admin_url_page( array('notice'=>'bad') ) );
            exit;
        }

        $ov = self::ensure_overrides_shape( self::get_overrides() );

        // Remove shipment lock + forced courier (optional)
        unset( $ov['shipment_locks'][ $shipment_id ] );
        unset( $ov['shipment_forced_courier'][ $shipment_id ] );

        self::save_overrides( $ov );

        do_action( 'caricove_dispatcher_lock_cleared', $shipment_id, 'admin' );

        wp_safe_redirect( self::admin_url_page( array('notice'=>'clearlock_ok') ) );
        exit;
    }

    /* -----------------------------
     * UI
     * -------------------------- */

    public static function render_page() {
        if ( ! current_user_can('manage_options') ) return;

        $q  = isset($_GET['q']) ? sanitize_text_field( wp_unslash($_GET['q']) ) : '';
        $tab = isset($_GET['tab']) ? sanitize_key( wp_unslash($_GET['tab']) ) : 'hold';
        if ( ! in_array($tab, array('hold','inhouse','all'), true) ) $tab = 'hold';

        $notice_key = isset($_GET['notice']) ? sanitize_key( wp_unslash($_GET['notice']) ) : '';
        $notice = $notice_key ? self::notice($notice_key) : '';

        $cpt = self::shipment_cpt();

        $hold_statuses = self::hold_statuses();
        $inhouse_statuses = self::inhouse_statuses();

        $meta_query = array('relation' => 'AND');

        // search by shipment id quick
        $post__in = array();
        if ( $q !== '' && ctype_digit($q) ) {
            $post__in = array( intval($q) );
        }

        if ( $tab === 'hold' ) {
            $meta_query[] = array(
                'key'     => self::META_STATUS,
                'value'   => $hold_statuses,
                'compare' => 'IN',
            );
        } elseif ( $tab === 'inhouse' ) {
            $meta_query[] = array(
                'key'     => self::META_STATUS,
                'value'   => $inhouse_statuses,
                'compare' => 'IN',
            );
        }

        $args = array(
            'post_type'      => $cpt,
            'post_status'    => array('publish','private','draft'),
            'posts_per_page' => 100,
            'orderby'        => 'modified',
            'order'          => 'DESC',
        );

        if ( ! empty($post__in) ) {
            $args['post__in'] = $post__in;
        } else {
            $args['meta_query'] = $meta_query;
        }

        $query = new WP_Query( $args );
        $rows = $query->posts;

        $nonce = wp_create_nonce('cc_hold_action');

        // For explain link: if your scoring lab exists, point there (adjust if your page differs)
        $explain_base = apply_filters(
            'cc_dispatcher_explain_url_base',
            admin_url('admin.php?page=scoring-lab')
        );

        ?>
        <div class="wrap">
            <h1>HOLD / Redispatch Control Tower</h1>
            <p class="description">Rescue stuck shipments fast: retry, force assign, inhouse, clear lock. Designed for Guyana reality. Extra-heavy now stays inside the courier universe; this tower routes only to manual review when human intervention is needed.</p>

            <style>
                .ccHoldX{
                    max-width: 1400px;
                    margin-top: 14px;
                    background: radial-gradient(1200px 600px at 15% 0%, rgba(64,160,255,.18), rgba(0,0,0,0)),
                                radial-gradient(900px 500px at 85% 10%, rgba(140,80,255,.14), rgba(0,0,0,0)),
                                linear-gradient(180deg,#070B14,#04060C);
                    border: 1px solid rgba(120,180,255,.18);
                    border-radius: 18px;
                    box-shadow: 0 20px 60px rgba(0,0,0,.65), 0 0 0 1px rgba(80,160,255,.06) inset;
                    color: #fff;
                    padding: 18px;
                }
                .ccHoldTop{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap}
                .ccHoldPills{display:flex;gap:10px;flex-wrap:wrap}
                .ccHoldPill{
                    display:inline-flex;align-items:center;gap:8px;
                    padding:10px 14px;border-radius:999px;
                    border:1px solid rgba(120,180,255,.22);
                    background: rgba(90,140,255,.08);
                    color:#fff;text-decoration:none;font-weight:900;font-size:13px;
                    box-shadow: 0 0 0 1px rgba(0,0,0,.35) inset, 0 10px 25px rgba(0,0,0,.35);
                }
                .ccHoldPill.active{
                    background: linear-gradient(135deg, rgba(80,170,255,.22), rgba(170,90,255,.14));
                    border-color: rgba(180,220,255,.35);
                }
                .ccHoldSearch{display:flex;gap:10px;align-items:center;flex-wrap:wrap}
                .ccHoldInput{
                    min-width: 320px;
                    padding: 11px 12px;
                    border-radius: 12px;
                    border:1px solid rgba(255,255,255,.12);
                    background: rgba(255,255,255,.90);
                    color:#000;
                    outline:none;
                    box-shadow: 0 0 0 1px rgba(0,0,0,.35) inset;
                }
                .ccHoldInput:focus{box-shadow:0 0 0 4px rgba(80,170,255,.25)}
                .ccHoldBtn{
                    padding: 11px 14px;
                    border-radius: 12px;
                    border: 1px solid rgba(120,180,255,.22);
                    background: linear-gradient(135deg, rgba(50,140,255,.35), rgba(140,80,255,.20));
                    color:#fff;
                    font-weight: 900;
                    cursor:pointer;
                    text-decoration:none;
                    display:inline-flex;align-items:center;justify-content:center;
                    white-space:nowrap;
                }
                .ccHoldBtn:hover{filter:brightness(1.06)}
                .ccHoldBtn.alt{background: rgba(255,255,255,.06)}
                .ccHoldBtn.danger{background: linear-gradient(135deg, rgba(255,77,109,.45), rgba(193,18,31,.20)); border-color: rgba(255,77,109,.30);}
                .ccHoldBtn.good{background: linear-gradient(135deg, rgba(52,211,153,.45), rgba(16,185,129,.18)); border-color: rgba(52,211,153,.28);}
                .ccHoldNote{
                    margin-top: 12px;
                    padding: 10px 12px;
                    border-radius: 14px;
                    border: 1px solid rgba(255,255,255,.10);
                    background: rgba(255,255,255,.05);
                    font-weight: 800;
                    font-size: 13px;
                }
                .ccHoldNote.ok{border-color: rgba(80,255,170,.25); box-shadow:0 0 22px rgba(80,255,170,.10)}
                .ccHoldNote.bad{border-color: rgba(255,90,120,.25); box-shadow:0 0 22px rgba(255,90,120,.10)}
                .ccHoldTableWrap{margin-top:14px;overflow:auto;border-radius:16px;border:1px solid rgba(255,255,255,.08);background: rgba(255,255,255,.03);box-shadow:0 18px 55px rgba(0,0,0,.50);}
                table.ccHoldTable{width:100%;border-collapse:collapse}
                .ccHoldTable th,.ccHoldTable td{padding:12px 12px;border-bottom:1px solid rgba(255,255,255,.07);text-align:left;white-space:nowrap;font-size:13px}
                .ccHoldTable th{font-size:12px;opacity:.85;text-transform:uppercase;letter-spacing:.8px}
                .ccChip{display:inline-flex;align-items:center;gap:6px;padding:6px 10px;border-radius:999px;border:1px solid rgba(255,255,255,.12);background: rgba(0,0,0,.25);font-weight:900;font-size:12px}
                .ccChip.gold{border-color: rgba(255,215,100,.30); box-shadow:0 0 18px rgba(255,215,100,.12)}
                .ccChip.purple{border-color: rgba(160,110,255,.30); box-shadow:0 0 18px rgba(160,110,255,.12)}
                .ccChip.green{border-color: rgba(80,255,170,.28); box-shadow:0 0 18px rgba(80,255,170,.10)}
                .ccChip.red{border-color: rgba(255,90,120,.30); box-shadow:0 0 18px rgba(255,90,120,.12)}
                .ccChip.gray{opacity:.85}
                .mono{font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;}
                .muted{opacity:.78}
                .actions{display:flex;gap:8px;align-items:center;flex-wrap:wrap}
                .forceForm{display:flex;gap:8px;align-items:center;flex-wrap:wrap}
                .forceSmall{width:140px;min-width:140px}
                .small{font-size:12px;opacity:.85}
            </style>

            <div class="ccHoldX">

                <div class="ccHoldTop">
                    <div class="ccHoldPills">
                        <a class="ccHoldPill <?php echo $tab==='hold'?'active':''; ?>" href="<?php echo esc_url(self::admin_url_page(array('tab'=>'hold'))); ?>">HOLD</a>
                        <a class="ccHoldPill <?php echo $tab==='inhouse'?'active':''; ?>" href="<?php echo esc_url(self::admin_url_page(array('tab'=>'inhouse'))); ?>">Manual Review</a>
                        <a class="ccHoldPill <?php echo $tab==='all'?'active':''; ?>" href="<?php echo esc_url(self::admin_url_page(array('tab'=>'all'))); ?>">All Recent</a>
                    </div>

                    <form class="ccHoldSearch" method="get" action="<?php echo esc_url( admin_url('admin.php') ); ?>">
                        <input type="hidden" name="page" value="<?php echo esc_attr(self::PAGE_SLUG); ?>">
                        <input type="hidden" name="tab" value="<?php echo esc_attr($tab); ?>">
                        <input class="ccHoldInput" type="text" name="q" value="<?php echo esc_attr($q); ?>" placeholder="Search shipment ID (e.g. 565)..." />
                        <button class="ccHoldBtn" type="submit">Search</button>
                        <a class="ccHoldBtn alt" href="<?php echo esc_url(self::admin_url_page(array('tab'=>$tab))); ?>">Reset</a>
                    </form>
                </div>

                <?php if ( $notice ) : ?>
                    <div class="ccHoldNote <?php echo $notice_key==='bad' ? 'bad' : 'ok'; ?>">
                        <?php echo esc_html($notice); ?>
                    </div>
                <?php endif; ?>

                <div class="ccHoldNote">
                    <span class="mono">CPT</span>: <span class="mono"><?php echo esc_html($cpt); ?></span>
                    <span class="muted">•</span>
                    <span class="mono">Hold statuses</span>: <span class="muted"><?php echo esc_html( implode(', ', $hold_statuses) ); ?></span>
                    <span class="muted">•</span>
                    <span class="mono">Manual-review statuses</span>: <span class="muted"><?php echo esc_html( implode(', ', $inhouse_statuses) ); ?></span>
                </div>

                <div class="ccHoldTableWrap">
                    <table class="ccHoldTable">
                        <thead>
                            <tr>
                                <th>Shipment</th>
                                <th>Status</th>
                                <th>Reason</th>
                                <th>Age</th>
                                <th>Attempts</th>
                                <th>Candidates</th>
                                <th>Lane</th>
                                <th>Size / Weight</th>
                                <th>Assigned</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if ( empty($rows) ) : ?>
                            <tr>
                                <td colspan="10" class="muted">No rows found for this view.</td>
                            </tr>
                        <?php else : ?>
                            <?php foreach ( $rows as $p ) :
                                $sid = intval($p->ID);

                                $status   = sanitize_key( self::safe_str_meta($sid, self::META_STATUS, '' ) );
                                $reason   = self::safe_str_meta($sid, self::META_HOLD_REASON, '' );
                                $since_ts = self::safe_int_meta($sid, self::META_HOLD_SINCE_TS, 0 );
                                if ( ! $since_ts ) {
                                    // best-effort: use modified time as "since"
                                    $since_ts = strtotime( $p->post_modified_gmt ? $p->post_modified_gmt : $p->post_modified ) ?: 0;
                                }

                                $attempts = self::safe_int_meta($sid, self::META_ATTEMPTS, 0 );
                                $cand     = self::safe_int_meta($sid, self::META_LAST_CAND_COUNT, 0 );

                                $origin   = sanitize_key( self::safe_str_meta($sid, self::META_ORIGIN_ANCHOR, '' ) );
                                $dest     = sanitize_key( self::safe_str_meta($sid, self::META_DEST_ANCHOR, '' ) );

                                $size     = sanitize_key( self::safe_str_meta($sid, self::META_SIZE_BAND, '' ) );
                                $weight   = sanitize_key( self::safe_str_meta($sid, self::META_WEIGHT_BAND, '' ) );

                                $assigned = self::safe_int_meta($sid, self::META_ASSIGNED_COURIER, 0 );

                                $age      = self::age_human($since_ts);

                                $status_chip = 'gray';
                                if ( in_array($status, self::hold_statuses(), true) ) $status_chip = 'red';
                                if ( in_array($status, self::inhouse_statuses(), true) ) $status_chip = 'purple';

                                $lane = ($origin || $dest) ? (($origin ?: '—') . ' → ' . ($dest ?: '—')) : '—';

                                $retry_url = wp_nonce_url(
                                    self::admin_url_page(array('notice'=>'', 'shipment_id'=>$sid)) . '&action=cc_hold_retry',
                                    'cc_hold_action',
                                    '_cc_nonce'
                                );

                                $inhouse_url = wp_nonce_url(
                                    self::admin_url_page(array('notice'=>'', 'shipment_id'=>$sid)) . '&action=cc_hold_manual_review',
                                    'cc_hold_action',
                                    '_cc_nonce'
                                );

                                $clearlock_url = wp_nonce_url(
                                    self::admin_url_page(array('notice'=>'', 'shipment_id'=>$sid)) . '&action=cc_hold_clear_lock',
                                    'cc_hold_action',
                                    '_cc_nonce'
                                );

                                $explain_url = add_query_arg(
                                    array('shipment_id'=>$sid),
                                    $explain_base
                                );
                                ?>
                                <tr>
                                    <td class="mono">#<?php echo esc_html($sid); ?></td>

                                    <td>
                                        <span class="ccChip <?php echo esc_attr($status_chip); ?>">
                                            <?php echo esc_html($status ?: '—'); ?>
                                        </span>
                                    </td>

                                    <td class="muted"><?php echo esc_html($reason ?: '—'); ?></td>

                                    <td class="mono"><?php echo esc_html($age); ?></td>

                                    <td class="mono"><?php echo esc_html($attempts); ?></td>

                                    <td>
                                        <span class="ccChip gold"><?php echo esc_html($cand); ?></span>
                                    </td>

                                    <td class="mono muted"><?php echo esc_html($lane); ?></td>

                                    <td class="mono muted"><?php echo esc_html(($size ?: '—') . ' / ' . ($weight ?: '—')); ?></td>

                                    <td class="mono"><?php echo $assigned ? esc_html('#'.$assigned) : '—'; ?></td>

                                    <td>
                                        <div class="actions">
                                            <a class="ccHoldBtn good" href="<?php echo esc_url($retry_url); ?>">Retry</a>

                                            <form class="forceForm" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                                                <?php wp_nonce_field('cc_hold_action','_cc_nonce'); ?>
                                                <input type="hidden" name="action" value="cc_hold_force">
                                                <input type="hidden" name="shipment_id" value="<?php echo esc_attr($sid); ?>">
                                                <input class="ccHoldInput forceSmall" type="number" name="force_courier_id" placeholder="Force courier ID" required>
                                                <button class="ccHoldBtn" type="submit">Force</button>
                                            </form>

                                            <a class="ccHoldBtn alt" href="<?php echo esc_url($clearlock_url); ?>">Clear Lock</a>
                                            <a class="ccHoldBtn danger" href="<?php echo esc_url($inhouse_url); ?>">Manual Review</a>
                                            <a class="ccHoldBtn alt" href="<?php echo esc_url($explain_url); ?>" target="_blank" rel="noopener">Explain</a>
                                        </div>
                                        <div class="small muted">Actions are safe; forced courier uses Overrides option.</div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <div class="ccHoldNote" style="margin-top:12px;">
                    <strong>Wiring note:</strong>
                    <span class="muted">Retry/Force trigger</span>
                    <span class="mono">do_action('caricove_dispatcher_retry_assignment', $shipment_id, $reason)</span>.
                    <span class="muted">If you already have a dispatcher/redispatch function, hook it to that action once.</span>
                </div>

            </div>
        </div>
        <?php
    }
}

Caricove_Dispatcher_Hold_Control_Tower::boot();