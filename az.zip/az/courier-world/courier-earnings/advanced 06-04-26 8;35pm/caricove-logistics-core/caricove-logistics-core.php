<?php
/**
 * Plugin Name: Caricove Logistics — Core Engine
 * Description: Core logistics engine for Caricove (shipments, couriers, zones, heartbeat, lifecycle).
 * Version: 2.0.0
 * Author: Caricove
 * MU Plugin: true
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * ---------------------------------------------------------------
 *  1. LOAD AUTOLOADER (SAFE)
 * ---------------------------------------------------------------
 */
$autoloader = __DIR__ . '/src/Autoloader.php';

if ( file_exists( $autoloader ) ) {
    require_once $autoloader;

// Hard-load Trust/Risk engine (avoids autoloader edge cases).
$trust_risk = __DIR__ . '/src/TrustAndRiskEngine.php';
if ( file_exists( $trust_risk ) ) {
    require_once $trust_risk;
}

    if ( class_exists( '\Caricove\Logistics\Core\Autoloader' ) ) {
        \Caricove\Logistics\Core\Autoloader::boot();
    }
}

/**
 * ---------------------------------------------------------------
 *  2. ENSURE SHIPMENTS CPT EXISTS
 * ---------------------------------------------------------------
 *
 * We make sure the cc_shipment CPT is registered early.
 */
add_action( 'init', function () {
    if ( class_exists( '\Caricove\Logistics\Core\Schema' ) ) {
        \Caricove\Logistics\Core\Schema::register_shipment_cpt();
    }
}, 5 );

/**
 * ---------------------------------------------------------------
 *  3. BOOT THE LOGISTICS CORE (DEFENSIVE)
 * ---------------------------------------------------------------
 *
 * We only call ::boot() if the class exists, so a missing file
 * can never cause a fatal error.
 */
add_action( 'plugins_loaded', function () {

    // Schema already registers CPT on init, but you may add other helpers later.
    if ( class_exists( '\Caricove\Logistics\Core\Schema' ) ) {
        // No-op right now; kept for symmetry.
    }

    // Courier profile meta.
    if ( class_exists( '\Caricove\Logistics\Core\CourierProfile' ) ) {
        \Caricove\Logistics\Core\CourierProfile::boot();
    }

    // Shipment manager (order → shipments, status model).
    if ( class_exists( '\Caricove\Logistics\Core\ShipmentManager' ) ) {
        \Caricove\Logistics\Core\ShipmentManager::boot();
    }

    // Status machine (list of valid statuses).
    if ( class_exists( '\Caricove\Logistics\Core\StatusMachine' ) ) {
        \Caricove\Logistics\Core\StatusMachine::boot();
    }

    // Hub lifecycle (hub_received wrapper).
    if ( class_exists( '\Caricove\Logistics\Core\HubLifecycle' ) ) {
        \Caricove\Logistics\Core\HubLifecycle::boot();
    }
    
    // Geo Registry (anchors + zones)
    if ( class_exists( '\Caricove\Logistics\Core\GeoRegistry' ) ) {
        \Caricove\Logistics\Core\GeoRegistry::boot();
    }

    // Storage engine (placeholder; SLA plugin handles cron).
    if ( class_exists( '\Caricove\Logistics\Core\StorageEngine' ) ) {
        \Caricove\Logistics\Core\StorageEngine::boot();
    }

    // Redelivery flags (free + paid).
    if ( class_exists( '\Caricove\Logistics\Core\RedeliveryFlags' ) ) {
        \Caricove\Logistics\Core\RedeliveryFlags::boot();
    }

    // Movement logger (chain-of-custody table).
    if ( class_exists( '\Caricove\Logistics\Core\MovementLogger' ) ) {
        \Caricove\Logistics\Core\MovementLogger::boot();
    }

    // Auto-assign baseline engine.
    if ( class_exists( '\Caricove\Logistics\Core\AutoAssign' ) ) {
        \Caricove\Logistics\Core\AutoAssign::boot();
    }

    // Zone resolver helper.
    if ( class_exists( '\Caricove\Logistics\Core\ZoneResolver' ) ) {
        \Caricove\Logistics\Core\ZoneResolver::boot();   // (boot is optional; define if needed)
    }

    // Connection Team engine (call cycles).
    if ( class_exists( '\Caricove\Logistics\Core\ConnectionTeam' ) ) {
        \Caricove\Logistics\Core\ConnectionTeam::boot();
    }

    // Safety engine.
    if ( class_exists( '\Caricove\Logistics\Core\SafetyManager' ) ) {
        \Caricove\Logistics\Core\SafetyManager::boot();
    }

    // Safety REST API.
    if ( class_exists( '\Caricove\Logistics\Core\SafetyAPI' ) ) {
        \Caricove\Logistics\Core\SafetyAPI::boot();
    }

    // Heartbeat REST API.
    if ( class_exists( '\Caricove\Logistics\Core\HeartbeatAPI' ) ) {
        \Caricove\Logistics\Core\HeartbeatAPI::boot();
    }
    
   // Trust + Risk signals (courier trust_score + shipment risk_score).
   if ( class_exists( '\Caricove\Logistics\Core\TrustAndRiskEngine' ) ) {
    \Caricove\Logistics\Core\TrustAndRiskEngine::boot();
}
});