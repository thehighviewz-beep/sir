<?php
namespace Caricove\Logistics\Core;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * HubLifecycle
 *
 * Thin wrapper to mark shipments as hub_received.
 * Actual hub storage logic (timestamps/flags) is in ShipmentManager::set_shipment_status().
 */
class HubLifecycle {

    public static function boot() {
        // Reserved: could listen to cc_shipment_status_changed if needed.
    }

    /**
     * Mark a shipment as received at the hub.
     *
     * @param int   $shipment_id
     * @param array $context
     */
    public static function mark_hub_received( $shipment_id, $context = array() ) {
        $shipment_id = intval( $shipment_id );
        if ( ! $shipment_id ) {
            return;
        }

        $context = array_merge(
            array(
                'source' => 'hub_lifecycle',
            ),
            (array) $context
        );

        ShipmentManager::set_shipment_status( $shipment_id, 'hub_received', $context );
    }
}