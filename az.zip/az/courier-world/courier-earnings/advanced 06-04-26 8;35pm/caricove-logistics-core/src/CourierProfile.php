<?php
namespace Caricove\Logistics\Core;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * CourierProfile
 *
 * Courier user meta: status, region, GPS, capacity, perf_score, etc.
 * This is the single source of truth for Dispatcher/CourierPool eligibility.
 */
class CourierProfile {

    /**
     * Protected raw courier truth keys that filters may not mutate.
     *
     * @return string[]
     */
    protected static function get_protected_profile_keys() {
        return array(
            'id',
            'status',
            'region',
            'zone_id',
            'zone_label',
            'zone_type',
            'radius_km',
            'vehicle_type',
            'max_active_jobs',
            'capacity_class',
            'region_source',
            'last_lat',
            'last_lng',
            'last_seen_ts',
            'perf_score',
            'special_role',
            'lock_reason',
            'lock_expires_at',
        );
    }

    /**
     * Re-assert protected courier truth after filters run.
     *
     * Filters may add fields, but they may not rewrite protected raw truth.
     *
     * @param array $raw_profile
     * @param mixed $filtered
     * @return array
     */
    protected static function protect_profile_truth( array $raw_profile, $filtered ) {
        $profile = is_array( $filtered ) ? $filtered : array();

        foreach ( self::get_protected_profile_keys() as $key ) {
            if ( array_key_exists( $key, $raw_profile ) ) {
                $profile[ $key ] = $raw_profile[ $key ];
            }
        }

        return $profile;
    }


    const ROLE_COURIER = 'caricove_courier';

    // Core status / capabilities.
    const META_STATUS          = '_caricove_courier_status';        // online/offline/busy
    const META_REGION          = '_caricove_courier_region';        // zone/region code
    const META_RADIUS_KM       = '_caricove_courier_radius_km';     // float
    const META_VEHICLE_TYPE    = '_caricove_courier_vehicle_type';  // bike/car/van/truck
    const META_MAX_ACTIVE_JOBS = '_caricove_courier_max_jobs';      // int
    const META_CAPACITY_CLASS  = '_caricove_courier_capacity';      // xs/s/m/l/xl
    const META_REGION_SOURCE   = '_caricove_courier_region_source'; // gps_auto | manual_override

    // Special region slug for couriers whose GPS is clearly outside anchors.
    const REGION_OFFGRID = 'off_grid';

    // Live GPS + heartbeat.
    const META_LAST_LAT        = '_caricove_courier_gps_lat';
    const META_LAST_LNG        = '_caricove_courier_gps_lng';
    const META_LAST_SEEN_TS    = '_caricove_courier_last_seen';

    // Performance / scoring.
    const META_PERF_SCORE      = '_caricove_courier_perf_score';    // 0–100 composite

    public static function boot() {
        // Optional: keep empty unless you add enforcement later.
        // Add admin sanity page (safe, does not affect front-end).
        if ( is_admin() ) {
            add_action( 'admin_menu', array( __CLASS__, 'register_sanity_page' ), 99 );
        }
    }

    /**
     * Get full courier profile.
     *
     * @param int $courier_id
     * @return array
     */
    public static function get_profile( $courier_id ) {
        $courier_id = intval( $courier_id );
        if ( ! $courier_id ) {
            return array();
        }

        // Schema-driven metas (safe fallbacks if Schema isn't loaded yet).
        $special_role_key    = '_cc_courier_special_role';
        $lock_reason_key     = '_cc_courier_lock_reason';
        $lock_expires_key    = '_cc_courier_lock_expires_at';

        if ( class_exists( __NAMESPACE__ . '\Schema' ) ) {
            /** @var class-string $schema */
            $schema = __NAMESPACE__ . '\Schema';
            if ( defined( $schema . '::META_COURIER_SPECIAL_ROLE' ) ) {
                $special_role_key = constant( $schema . '::META_COURIER_SPECIAL_ROLE' );
            }
            if ( defined( $schema . '::META_COURIER_LOCK_REASON' ) ) {
                $lock_reason_key = constant( $schema . '::META_COURIER_LOCK_REASON' );
            }
            if ( defined( $schema . '::META_COURIER_LOCK_EXPIRES_AT' ) ) {
                $lock_expires_key = constant( $schema . '::META_COURIER_LOCK_EXPIRES_AT' );
            }
        }

        $last_lat = get_user_meta( $courier_id, self::META_LAST_LAT, true );
        $last_lng = get_user_meta( $courier_id, self::META_LAST_LNG, true );
        $region   = get_user_meta( $courier_id, self::META_REGION, true );

        $zone_id = '';
        $zone_label = '';
        $zone_type = '';
        if ( class_exists( '\CC_CP_Storage' ) && is_numeric( $last_lat ) && is_numeric( $last_lng ) ) {
            try {
                $resolved_zone = \CC_CP_Storage::resolve_point_to_zone( floatval( $last_lat ), floatval( $last_lng ) );
                if ( is_array( $resolved_zone ) ) {
                    $zone_id    = sanitize_key( (string) ( $resolved_zone['id'] ?? $resolved_zone['slug'] ?? '' ) );
                    $zone_label = sanitize_text_field( (string) ( $resolved_zone['label'] ?? '' ) );
                    $zone_type  = sanitize_key( (string) ( $resolved_zone['zone_type'] ?? '' ) );
                }
            } catch ( \Throwable $e ) {
                // Read lightly; never let zone resolution break profile reads.
            }
        }

        if ( $zone_id === '' ) {
            $zone_id = sanitize_key( (string) $region );
        }

        $meta = array(
            'id'              => $courier_id,
            'status'          => get_user_meta( $courier_id, self::META_STATUS, true ),
            'region'          => $region,
            'zone_id'         => $zone_id,
            'zone_label'      => $zone_label,
            'zone_type'       => $zone_type,
            'radius_km'       => floatval( get_user_meta( $courier_id, self::META_RADIUS_KM, true ) ),
            'vehicle_type'    => get_user_meta( $courier_id, self::META_VEHICLE_TYPE, true ),
            'max_active_jobs' => intval( get_user_meta( $courier_id, self::META_MAX_ACTIVE_JOBS, true ) ),
            'capacity_class'  => get_user_meta( $courier_id, self::META_CAPACITY_CLASS, true ),
            'region_source'   => get_user_meta( $courier_id, self::META_REGION_SOURCE, true ),

            'last_lat'        => $last_lat,
            'last_lng'        => $last_lng,
            'last_seen_ts'    => intval( get_user_meta( $courier_id, self::META_LAST_SEEN_TS, true ) ),

            'perf_score'      => floatval( get_user_meta( $courier_id, self::META_PERF_SCORE, true ) ),

            // Control + special role meta.
            'special_role'    => get_user_meta( $courier_id, $special_role_key, true ),
            'lock_reason'     => get_user_meta( $courier_id, $lock_reason_key, true ),
            'lock_expires_at' => get_user_meta( $courier_id, $lock_expires_key, true ),
        );

        $filtered = apply_filters( 'cc_courier_profile', $meta, $courier_id );

        return self::protect_profile_truth( $meta, $filtered );
    }

    /**
     * Ensure the courier has a region set based on GPS or fallback anchor.
     *
     * @param int  $courier_id
     * @param bool $allow_default
     */
    public static function ensure_region_for_courier( $courier_id, $allow_default = true ) {
        $courier_id = intval( $courier_id );
        if ( ! $courier_id ) {
            return;
        }

        $region_source = get_user_meta( $courier_id, self::META_REGION_SOURCE, true );
        if ( $region_source === 'manual_override' ) {
            return;
        }

        $lat_val = get_user_meta( $courier_id, self::META_LAST_LAT, true );
        $lng_val = get_user_meta( $courier_id, self::META_LAST_LNG, true );

        $region_to_set = '';

        // Prefer distance-aware mapping if ZoneResolver exists.
        if (
            is_numeric( $lat_val ) &&
            is_numeric( $lng_val ) &&
            class_exists( __NAMESPACE__ . '\ZoneResolver' )
        ) {
            $zones = array();
            if ( class_exists( __NAMESPACE__ . '\Schema' ) && method_exists( __NAMESPACE__ . '\Schema', 'get_zone_definitions' ) ) {
                $zones = Schema::get_zone_definitions();
                if ( ! is_array( $zones ) ) $zones = array();
            }

            $result = ZoneResolver::map_coords_to_anchor_with_distance(
                (float) $lat_val,
                (float) $lng_val,
                $zones
            );

            $anchor      = ! empty( $result['anchor'] ) ? $result['anchor'] : 'gt_kingston_hub';
            $distance_km = isset( $result['distance_km'] ) ? floatval( $result['distance_km'] ) : null;

            $offgrid_threshold_km = apply_filters(
                'cc_core_offgrid_distance_km',
                120.0,
                $courier_id,
                $lat_val,
                $lng_val,
                $result
            );

            if ( null !== $distance_km && $distance_km > $offgrid_threshold_km ) {
                $region_to_set = self::REGION_OFFGRID;
            } else {
                $region_to_set = $anchor;
            }
        } elseif ( $allow_default ) {
            $existing = get_user_meta( $courier_id, self::META_REGION, true );
            $region_to_set = $existing ? $existing : 'gt_kingston_hub';
        } else {
            return;
        }

        update_user_meta( $courier_id, self::META_REGION, sanitize_key( $region_to_set ) );
        update_user_meta( $courier_id, self::META_REGION_SOURCE, 'gps_auto' );
    }

    /* ---------------------------------------------------------------------
     * COURIER LOCK / SPECIAL ROLE HELPERS
     * ------------------------------------------------------------------ */

    public static function lock_courier( $courier_id, $reason = 'risk_hold', $ttl_seconds = 0 ) {
        $courier_id = intval( $courier_id );
        if ( ! $courier_id ) return;

        $lock_reason_key  = '_cc_courier_lock_reason';
        $lock_expires_key = '_cc_courier_lock_expires_at';

        if ( class_exists( __NAMESPACE__ . '\Schema' ) ) {
            $schema = __NAMESPACE__ . '\Schema';
            if ( defined( $schema . '::META_COURIER_LOCK_REASON' ) ) {
                $lock_reason_key = constant( $schema . '::META_COURIER_LOCK_REASON' );
            }
            if ( defined( $schema . '::META_COURIER_LOCK_EXPIRES_AT' ) ) {
                $lock_expires_key = constant( $schema . '::META_COURIER_LOCK_EXPIRES_AT' );
            }
        }

        update_user_meta( $courier_id, $lock_reason_key, sanitize_key( $reason ) );

        if ( $ttl_seconds > 0 ) {
            $expires_ts = current_time( 'timestamp', true ) + intval( $ttl_seconds );
            update_user_meta( $courier_id, $lock_expires_key, gmdate( 'Y-m-d H:i:s', $expires_ts ) );
        } else {
            delete_user_meta( $courier_id, $lock_expires_key );
        }

        do_action( 'cc_courier_locked', $courier_id, $reason, $ttl_seconds );
    }

    public static function unlock_courier( $courier_id ) {
        $courier_id = intval( $courier_id );
        if ( ! $courier_id ) return;

        $lock_reason_key  = '_cc_courier_lock_reason';
        $lock_expires_key = '_cc_courier_lock_expires_at';

        if ( class_exists( __NAMESPACE__ . '\Schema' ) ) {
            $schema = __NAMESPACE__ . '\Schema';
            if ( defined( $schema . '::META_COURIER_LOCK_REASON' ) ) {
                $lock_reason_key = constant( $schema . '::META_COURIER_LOCK_REASON' );
            }
            if ( defined( $schema . '::META_COURIER_LOCK_EXPIRES_AT' ) ) {
                $lock_expires_key = constant( $schema . '::META_COURIER_LOCK_EXPIRES_AT' );
            }
        }

        delete_user_meta( $courier_id, $lock_reason_key );
        delete_user_meta( $courier_id, $lock_expires_key );

        do_action( 'cc_courier_unlocked', $courier_id );
    }

    public static function set_special_role( $courier_id, $role = 'normal' ) {
        $courier_id = intval( $courier_id );
        if ( ! $courier_id ) return;

        $special_role_key = '_cc_courier_special_role';

        if ( class_exists( __NAMESPACE__ . '\Schema' ) ) {
            $schema = __NAMESPACE__ . '\Schema';
            if ( defined( $schema . '::META_COURIER_SPECIAL_ROLE' ) ) {
                $special_role_key = constant( $schema . '::META_COURIER_SPECIAL_ROLE' );
            }
        }

        update_user_meta( $courier_id, $special_role_key, sanitize_key( $role ) );
        do_action( 'cc_courier_special_role_set', $courier_id, $role );
    }

    /* ---------------------------------------------------------------------
     * ADMIN: sanity check page (glowing, fast)
     * ------------------------------------------------------------------ */

    public static function register_sanity_page() {
        if ( ! current_user_can( 'manage_woocommerce' ) && ! current_user_can( 'manage_options' ) ) {
            return;
        }

        // Appears under Tools for safety (won’t depend on your Logistics menu).
        add_submenu_page(
            'tools.php',
            'Caricove CourierProfile — Sanity',
            'CourierProfile Sanity',
            'manage_options',
            'cc-courierprofile-sanity',
            array( __CLASS__, 'render_sanity_page' )
        );
    }

    public static function render_sanity_page() {
        if ( ! current_user_can( 'manage_options' ) ) return;

        $courier_id = isset($_GET['courier_id']) ? intval($_GET['courier_id']) : 41;

        $p = self::get_profile( $courier_id );

        $vals = array(
            'Courier ID'     => $courier_id,
            'Status'         => (string)($p['status'] ?? ''),
            'Last seen (ts)' => (string)($p['last_seen_ts'] ?? ''),
            'Last lat'       => (string)($p['last_lat'] ?? ''),
            'Last lng'       => (string)($p['last_lng'] ?? ''),
            'Region'         => (string)($p['region'] ?? ''),
            'Region source'  => (string)($p['region_source'] ?? ''),
            'Max jobs'       => (string)($p['max_active_jobs'] ?? ''),
            'Radius (km)'    => (string)($p['radius_km'] ?? ''),
            'Vehicle'        => (string)($p['vehicle_type'] ?? ''),
            'Capacity'       => (string)($p['capacity_class'] ?? ''),
            'Perf score'     => (string)($p['perf_score'] ?? ''),
            'Lock reason'    => (string)($p['lock_reason'] ?? ''),
            'Lock expires'   => (string)($p['lock_expires_at'] ?? ''),
            'Special role'   => (string)($p['special_role'] ?? ''),
        );

        $self_url = admin_url('tools.php?page=cc-courierprofile-sanity');
        ?>
        <div class="wrap">
            <h1>CourierProfile Sanity</h1>
            <p style="opacity:.85">Fast truth view of the exact meta Dispatcher/CourierPool reads.</p>

            <form method="get" action="<?php echo esc_url($self_url); ?>" style="margin:10px 0 16px;">
                <input type="hidden" name="page" value="cc-courierprofile-sanity" />
                <input type="number" name="courier_id" value="<?php echo esc_attr($courier_id); ?>" style="min-width:220px;padding:8px 10px;border-radius:10px;" />
                <button class="button button-primary">Load</button>
            </form>

            <div style="
                max-width:980px;padding:16px;border-radius:18px;
                background: radial-gradient(1200px 600px at 15% 0%, rgba(64,160,255,.20), rgba(0,0,0,0)),
                            radial-gradient(900px 500px at 85% 10%, rgba(140,80,255,.16), rgba(0,0,0,0)),
                            linear-gradient(180deg,#070B14,#04060C);
                border:1px solid rgba(120,180,255,.18);
                box-shadow:0 20px 60px rgba(0,0,0,.55), 0 0 0 1px rgba(80,160,255,.06) inset;
                color:#fff;
            ">
                <?php foreach ($vals as $k => $v): ?>
                    <div style="display:flex;justify-content:space-between;gap:18px;padding:8px 0;border-bottom:1px solid rgba(255,255,255,.07);">
                        <div style="opacity:.85;font-weight:800;"><?php echo esc_html($k); ?></div>
                        <div style="font-family:ui-monospace,Menlo,Consolas,monospace;font-weight:800;"><?php echo esc_html($v === '' ? '—' : $v); ?></div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php
    }
}

CourierProfile::boot();