<?php
namespace Caricove\Logistics\Core\Signals;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class TrustAndRisk {

    // Courier trust meta
    const META_TRUST_SCORE = '_cc_trust_score';   // int 0..100
    const META_TRUST_TIER  = '_cc_trust_tier';    // starter|trusted|elite|secure

    // Shipment risk meta (stored on shipment CPT post meta)
    const META_RISK_SCORE = '_cc_risk_score';     // int 0..100
    const META_RISK_TIER  = '_cc_risk_tier';      // standard|insured|high_value|ultra

    /** Boot hooks */
    public static function boot() {

        // When a courier goes online/offline or heartbeats, we can refresh trust if you want.
        // Keep this light. Default: only refresh trust on explicit events (below).
        add_action( 'caricove_courier_went_online', array( __CLASS__, 'maybe_refresh_trust_for_courier' ), 10, 1 );

        // When a shipment is created, set risk immediately (core truth).
        add_action( 'caricove_logistics_shipment_created', array( __CLASS__, 'set_risk_for_shipment' ), 10, 2 );
        // If you update order/shipment details later, you can re-evaluate:
        add_action( 'caricove_logistics_shipment_recalc_risk', array( __CLASS__, 'set_risk_for_shipment' ), 10, 2 );
    }

    /* ============================================================
     * COURIER TRUST
     * ============================================================
     */

    public static function maybe_refresh_trust_for_courier( $courier_user_id ) {
        $courier_user_id = intval( $courier_user_id );
        if ( ! $courier_user_id ) { return; }
        self::recalc_and_store_trust( $courier_user_id );
    }

    /**
     * Recalculate courier trust score from existing meta signals.
     * This is intentionally conservative: if you don't have data yet,
     * the courier stays "starter" and trust won't falsely inflate.
     */
    public static function recalc_and_store_trust( $courier_user_id ) {
        $courier_user_id = intval( $courier_user_id );
        if ( ! $courier_user_id ) { return array( 'trust_score' => 0, 'trust_tier' => 'starter' ); }

        // These meta keys are placeholders you can wire later from Plugin 3/4/5.
        $completed_jobs   = max( 0, intval( get_user_meta( $courier_user_id, '_cc_jobs_completed', true ) ) );
        $on_time_rate     = self::clamp01( floatval( get_user_meta( $courier_user_id, '_cc_on_time_rate', true ) ) ); // 0..1
        $cancel_rate      = self::clamp01( floatval( get_user_meta( $courier_user_id, '_cc_cancel_rate', true ) ) );  // 0..1
        $dispute_rate     = self::clamp01( floatval( get_user_meta( $courier_user_id, '_cc_dispute_rate', true ) ) ); // 0..1
        $proof_ok_rate    = self::clamp01( floatval( get_user_meta( $courier_user_id, '_cc_proof_ok_rate', true ) ) );// 0..1

        // Active flags/locks should cap trust hard.
        $active_flag = (string) get_user_meta( $courier_user_id, '_cc_active_flag', true ); // e.g. 'fraud','no_show','complaints'
        $is_flagged  = ( $active_flag !== '' );

        // Experience score (log-ish, but cheap):
        // 0 jobs => 10, 10 jobs => ~30, 50 jobs => ~55, 200 jobs => ~80, 500+ => ~95
        $exp = 10.0;
        if ( $completed_jobs > 0 ) {
            $exp = 10.0 + ( 85.0 * ( log( 1 + min( 500, $completed_jobs ) ) / log( 501 ) ) );
        }

        // Convert rates into 0..100 components.
        $ontime    = 100.0 * $on_time_rate;
        $reliable  = 100.0 * ( 1.0 - $cancel_rate );
        $disputes  = 100.0 * ( 1.0 - $dispute_rate );
        $proof     = 100.0 * $proof_ok_rate;

        // Weighted trust score (Task 1 outline weights):
        $trust = ( 0.25 * $exp ) + ( 0.30 * $ontime ) + ( 0.20 * $reliable ) + ( 0.15 * $disputes ) + ( 0.10 * $proof );

        // Hard cap if flagged.
        if ( $is_flagged ) {
            $trust = min( $trust, 64.0 ); // cannot exceed "trusted" while flagged
        }

        $trust = intval( round( self::clamp( $trust, 0.0, 100.0 ) ) );
        $tier  = self::trust_tier_from_score( $trust );

        update_user_meta( $courier_user_id, self::META_TRUST_SCORE, $trust );
        update_user_meta( $courier_user_id, self::META_TRUST_TIER, $tier );

        do_action( 'caricove_logistics_trust_updated', $courier_user_id, $trust, $tier );

        return array( 'trust_score' => $trust, 'trust_tier' => $tier );
    }

    protected static function trust_tier_from_score( $trust_score ) {
        $t = intval( $trust_score );
        if ( $t >= 80 ) { return 'secure'; }
        if ( $t >= 65 ) { return 'elite'; }
        if ( $t >= 45 ) { return 'trusted'; }
        return 'starter';
    }

    /* ============================================================
     * SHIPMENT RISK
     * ============================================================
     */

    /**
     * Set risk meta on shipment CPT.
     *
     * @param int   $shipment_id
     * @param array $shipment_summary (optional) if you already have it
     */
    public static function set_risk_for_shipment( $shipment_id, $shipment_summary = array() ) {
        $shipment_id = intval( $shipment_id );
        if ( ! $shipment_id ) { return; }

        // Try to read order/shipment context from the summary first.
        $order_id = 0;
        if ( is_array( $shipment_summary ) && ! empty( $shipment_summary['order_id'] ) ) {
            $order_id = intval( $shipment_summary['order_id'] );
        } else {
            $order_id = intval( get_post_meta( $shipment_id, '_cc_order_id', true ) );
        }

        $risk = self::compute_risk_for_shipment( $shipment_id, $order_id, $shipment_summary );

        update_post_meta( $shipment_id, self::META_RISK_SCORE, intval( $risk['risk_score'] ) );
        update_post_meta( $shipment_id, self::META_RISK_TIER, (string) $risk['risk_tier'] );

        do_action( 'caricove_logistics_risk_updated', $shipment_id, $risk['risk_score'], $risk['risk_tier'], $order_id );

        return $risk;
    }

    /**
     * Conservative risk model (no fancy dependencies).
     * You can refine category flags + customer history later.
     */
    public static function compute_risk_for_shipment( $shipment_id, $order_id = 0, $shipment_summary = array() ) {

        $shipment_value = 0.0;

        // If shipment summary already provides vendor-scoped total, use it.
        if ( is_array( $shipment_summary ) && isset( $shipment_summary['shipment_value'] ) ) {
            $shipment_value = floatval( $shipment_summary['shipment_value'] );
        }

        // Otherwise, fallback: use order total (not ideal, but non-zero).
        if ( $shipment_value <= 0 && $order_id && function_exists( 'wc_get_order' ) ) {
            $order = wc_get_order( $order_id );
            if ( $order ) {
                $shipment_value = floatval( $order->get_total() );
            }
        }

        // Value signal (0..100) with simple banding
        $value_signal = 10;
        if ( $shipment_value >= 800 ) { $value_signal = 95; }
        elseif ( $shipment_value >= 400 ) { $value_signal = 80; }
        elseif ( $shipment_value >= 150 ) { $value_signal = 60; }
        elseif ( $shipment_value >= 50 )  { $value_signal = 30; }
        else { $value_signal = 10; }

        // Category signal (0..100)
        // Default low. You can override via filter or by setting per-product meta and rolling up later.
        $category_signal = 10;
        $category_signal = intval( apply_filters(
            'cc_risk_category_signal',
            $category_signal,
            $shipment_id,
            $order_id,
            $shipment_summary
        ) );

        // Address confidence (0..100 risk; higher = worse)
        $address_signal = 20;
        $has_pickup_coords = ! empty( $shipment_summary['pickup_coords'] ) || get_post_meta( $shipment_id, '_cc_pickup_coords', true );
        $has_dropoff_coords = ! empty( $shipment_summary['dropoff_coords'] ) || get_post_meta( $shipment_id, '_cc_dropoff_coords', true );
        if ( $has_pickup_coords && $has_dropoff_coords ) {
            $address_signal = 5;
        } elseif ( $has_pickup_coords || $has_dropoff_coords ) {
            $address_signal = 25;
        } else {
            $address_signal = 60;
        }

        // Customer history signal (0..100)
        $customer_signal = 25; // default "new-ish"
        if ( $order_id && function_exists( 'wc_get_order' ) ) {
            $order = wc_get_order( $order_id );
            if ( $order ) {
                $uid = intval( $order->get_user_id() );
                if ( $uid ) {
                    $prior_dispute = intval( get_user_meta( $uid, '_cc_customer_dispute_count', true ) );
                    $prior_orders  = intval( get_user_meta( $uid, '_cc_customer_completed_orders', true ) );
                    if ( $prior_dispute > 0 ) {
                        $customer_signal = 80;
                    } elseif ( $prior_orders >= 5 ) {
                        $customer_signal = 10;
                    } else {
                        $customer_signal = 30;
                    }
                }
            }
        }

        // Protocol requirement signal (0..100)
        $protocol_signal = 0;
        $requires_signature = ! empty( $shipment_summary['requires_signature'] ) || (bool) get_post_meta( $shipment_id, '_cc_requires_signature', true );
        $requires_id_check  = ! empty( $shipment_summary['requires_id_check'] )  || (bool) get_post_meta( $shipment_id, '_cc_requires_id_check', true );
        if ( $requires_signature || $requires_id_check ) {
            $protocol_signal = $requires_id_check ? 60 : 35;
        }

        // Weighted sum (Task 1 defaults)
        $risk_score = (0.40 * $value_signal)
                    + (0.20 * $category_signal)
                    + (0.15 * $address_signal)
                    + (0.15 * $customer_signal)
                    + (0.10 * $protocol_signal);

        // Hard escalators via filter (e.g., electronics high-theft)
        $risk_score = floatval( apply_filters(
            'cc_risk_score_after_escalators',
            $risk_score,
            array(
                'value_signal'    => $value_signal,
                'category_signal' => $category_signal,
                'address_signal'  => $address_signal,
                'customer_signal' => $customer_signal,
                'protocol_signal' => $protocol_signal,
                'shipment_value'  => $shipment_value,
            ),
            $shipment_id,
            $order_id,
            $shipment_summary
        ) );

        $risk_score = intval( round( self::clamp( $risk_score, 0.0, 100.0 ) ) );
        $risk_tier  = self::risk_tier_from_score( $risk_score );

        // Allow explicit tier override via filter (admin/vendor overrides later)
        $risk_tier = (string) apply_filters( 'cc_risk_tier_override', $risk_tier, $risk_score, $shipment_id, $order_id, $shipment_summary );

        return array(
            'risk_score' => $risk_score,
            'risk_tier'  => $risk_tier,
        );
    }

    protected static function risk_tier_from_score( $risk_score ) {
        $r = intval( $risk_score );
        if ( $r >= 75 ) { return 'ultra'; }
        if ( $r >= 55 ) { return 'high_value'; }
        if ( $r >= 35 ) { return 'insured'; }
        return 'standard';
    }

    /* ============================================================
     * Helpers
     * ============================================================
     */

    protected static function clamp01( $v ) {
        $v = floatval( $v );
        if ( $v < 0 ) { return 0.0; }
        if ( $v > 1 ) { return 1.0; }
        return $v;
    }

    protected static function clamp( $v, $min, $max ) {
        $v = floatval( $v );
        if ( $v < $min ) { return $min; }
        if ( $v > $max ) { return $max; }
        return $v;
    }
}