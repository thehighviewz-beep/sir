<?php
namespace Caricove\Logistics\Core;

use WP_Query;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * ConnectionTeam
 *
 * Engine for tracking and deciding paid redelivery contact cycles.
 * - Tracks 3-day call cycles.
 * - Enforces 30/60/120 minute gaps between attempts per day.
 * - Marks shipments as ready_for_dispatch when answered.
 * - Marks shipments as failed_unreachable if cycle completes with no answer.
 */
class ConnectionTeam {

    public static function boot() {
        // Reserved for future cron hook (e.g. cc_logistics_connection_team_tick).
    }

    public static function get_cycle_day( $shipment_id ) {
        $val = get_post_meta( $shipment_id, Schema::META_SHIPMENT_CONTACT_CYCLE_DAY, true );
        $day = intval( $val );
        if ( $day < 1 ) {
            $day = 1;
        } elseif ( $day > 3 ) {
            $day = 3;
        }
        return $day;
    }

    public static function get_attempts_today( $shipment_id ) {
        $val = get_post_meta( $shipment_id, Schema::META_SHIPMENT_CONTACT_ATTEMPTS_TODAY, true );
        return max( 0, intval( $val ) );
    }

    public static function get_total_attempts( $shipment_id ) {
        $val = get_post_meta( $shipment_id, Schema::META_SHIPMENT_CONTACT_TOTAL_ATTEMPTS, true );
        return max( 0, intval( $val ) );
    }

    /**
     * Determine if a new attempt is allowed RIGHT NOW for a given shipment,
     * based on attempts_today and last_attempt_at and the 30/60/120 spacing.
     *
     * @param int $shipment_id
     * @return bool
     */
    public static function can_attempt_now( $shipment_id ) {
        $attempts_today = self::get_attempts_today( $shipment_id );
        $last_at        = get_post_meta( $shipment_id, Schema::META_SHIPMENT_CONTACT_LAST_ATTEMPT_AT, true );

        if ( $attempts_today <= 0 || empty( $last_at ) ) {
            return true;
        }

        $last_ts = strtotime( $last_at );
        if ( ! $last_ts ) {
            return true;
        }

        $now     = current_time( 'timestamp', true );
        $diff    = $now - $last_ts;

        $spacing_minutes = array(
            1 => 30,
            2 => 60,
            3 => 120,
        );

        if ( ! isset( $spacing_minutes[ $attempts_today ] ) ) {
            $required = 120 * 60;
        } else {
            $required = $spacing_minutes[ $attempts_today ] * 60;
        }

        return ( $diff >= $required );
    }

    /**
     * Log a contact attempt and advance the state as needed.
     *
     * @param int    $shipment_id
     * @param string $outcome answered|no_answer|unreachable|wrong_number
     * @param array  $context
     */
    public static function log_attempt( $shipment_id, $outcome, $context = array() ) {
        $shipment_id = intval( $shipment_id );
        if ( ! $shipment_id ) {
            return;
        }

        $outcome = sanitize_key( $outcome );

        $cycle_day       = self::get_cycle_day( $shipment_id );
        $attempts_today  = self::get_attempts_today( $shipment_id );
        $total_attempts  = self::get_total_attempts( $shipment_id );

        $attempts_today++;
        $total_attempts++;

        update_post_meta( $shipment_id, Schema::META_SHIPMENT_CONTACT_CYCLE_DAY, $cycle_day );
        update_post_meta( $shipment_id, Schema::META_SHIPMENT_CONTACT_ATTEMPTS_TODAY, $attempts_today );
        update_post_meta( $shipment_id, Schema::META_SHIPMENT_CONTACT_TOTAL_ATTEMPTS, $total_attempts );
        update_post_meta( $shipment_id, Schema::META_SHIPMENT_CONTACT_LAST_ATTEMPT_AT, current_time( 'mysql', true ) );
        update_post_meta( $shipment_id, Schema::META_SHIPMENT_CONTACT_LAST_OUTCOME, $outcome );

        if ( 'answered' === $outcome ) {
            self::handle_answered( $shipment_id, $cycle_day, $attempts_today, $total_attempts, $context );
            return;
        }

        self::handle_not_answered( $shipment_id, $cycle_day, $attempts_today, $total_attempts, $context );
    }

    protected static function handle_answered( $shipment_id, $cycle_day, $attempts_today, $total_attempts, $context ) {
        RedeliveryFlags::mark_paid_redelivery_ready_for_dispatch(
            $shipment_id,
            array_merge(
                (array) $context,
                array(
                    'contact_cycle_day'      => $cycle_day,
                    'contact_attempts_today' => $attempts_today,
                    'contact_total_attempts' => $total_attempts,
                )
            )
        );

        update_post_meta( $shipment_id, Schema::META_SHIPMENT_CONTACT_ATTEMPTS_TODAY, 0 );
        update_post_meta( $shipment_id, Schema::META_SHIPMENT_CONTACT_CYCLE_DAY, $cycle_day );
    }

    protected static function handle_not_answered( $shipment_id, $cycle_day, $attempts_today, $total_attempts, $context ) {
        $max_attempts_per_day = 4;

        if ( $attempts_today < $max_attempts_per_day ) {
            return;
        }

        if ( $cycle_day < 3 ) {
            $cycle_day++;
            update_post_meta( $shipment_id, Schema::META_SHIPMENT_CONTACT_CYCLE_DAY, $cycle_day );
            update_post_meta( $shipment_id, Schema::META_SHIPMENT_CONTACT_ATTEMPTS_TODAY, 0 );
            return;
        }

        RedeliveryFlags::mark_paid_redelivery_failed_unreachable(
            $shipment_id,
            array_merge(
                (array) $context,
                array(
                    'contact_cycle_day'      => $cycle_day,
                    'contact_attempts_today' => $attempts_today,
                    'contact_total_attempts' => $total_attempts,
                )
            )
        );
    }

    /**
     * Get shipments in paid_redelivery_pending_confirmation
     * that are eligible for another call *right now*.
     *
     * @param int $limit
     * @return int[]
     */
    public static function get_pending_queue( $limit = 50 ) {
        $query = new WP_Query(
            array(
                'post_type'      => 'cc_shipment',
                'post_status'    => 'any',
                'posts_per_page' => $limit,
                'no_found_rows'  => true,
                'fields'         => 'ids',
                'meta_query'     => array(
                    array(
                        'key'   => Schema::META_SHIPMENT_STATUS,
                        'value' => 'paid_redelivery_pending_confirmation',
                    ),
                ),
            )
        );

        $ids = array();

        if ( empty( $query->posts ) ) {
            return $ids;
        }

        foreach ( $query->posts as $shipment_id ) {
            if ( self::can_attempt_now( $shipment_id ) ) {
                $ids[] = (int) $shipment_id;
            }
        }

        return $ids;
    }
}