<?php
namespace Caricove\Logistics\Core;

use WP_REST_Request;
use WP_REST_Response;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * HeartbeatAPI
 *
 * REST endpoint for courier GPS + heartbeat.
 */
class HeartbeatAPI {

    protected static $booted = false;

    public static function boot() {
        if ( self::$booted ) {
            return;
        }

        self::$booted = true;
        add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
    }

    public static function register_routes() {
        register_rest_route(
            'caricove-logistics/v1',
            '/heartbeat',
            array(
                'methods'             => 'POST',
                'callback'            => array( __CLASS__, 'handle_heartbeat' ),
                'permission_callback' => array( __CLASS__, 'permission_callback' ),
            )
        );
    }

    public static function permission_callback( $request ) {
        // For now, allow any logged-in user; can tighten later.
        return is_user_logged_in();
    }

    public static function handle_heartbeat( WP_REST_Request $request ) {
        $courier_id = intval( $request->get_param( 'courier_id' ) );

        if ( ! $courier_id ) {
            $current = get_current_user_id();
            if ( $current ) {
                $courier_id = $current;
            }
        }

        if ( ! $courier_id ) {
            return new WP_REST_Response(
                array(
                    'ok'      => false,
                    'message' => __( 'Missing courier_id.', 'caricove-logistics' ),
                ),
                400
            );
        }

        $lat = $request->get_param( 'lat' );
        $lng = $request->get_param( 'lng' );

        if ( null !== $lat ) {
            update_user_meta( $courier_id, CourierProfile::META_LAST_LAT, floatval( $lat ) );
        }
        if ( null !== $lng ) {
            update_user_meta( $courier_id, CourierProfile::META_LAST_LNG, floatval( $lng ) );
        }

        update_user_meta( $courier_id, CourierProfile::META_LAST_SEEN_TS, time() );
        CourierProfile::ensure_region_for_courier( $courier_id );

        $region = get_user_meta( $courier_id, CourierProfile::META_REGION, true );
        $status = get_user_meta( $courier_id, CourierProfile::META_STATUS, true );

        if ( $region && 'online' === $status && class_exists( '\Caricove\Logistics\Core\ShipmentManager' ) ) {
            if ( $region !== CourierProfile::REGION_OFFGRID ) {
                ShipmentManager::redispatch_ready_shipments_for_region( $region );
            }
        }

do_action('cc_telemetry_courier_ping', $courier_id, array(
  'ts'     => time(),
  'lat'    => (null !== $lat ? floatval($lat) : null),
  'lng'    => (null !== $lng ? floatval($lng) : null),
  'source' => 'core_heartbeat',
));


        return new WP_REST_Response(
            array(
                'ok'           => true,
                'courier_id'   => $courier_id,
                'last_lat'     => get_user_meta( $courier_id, CourierProfile::META_LAST_LAT, true ),
                'last_lng'     => get_user_meta( $courier_id, CourierProfile::META_LAST_LNG, true ),
                'last_seen_ts' => intval( get_user_meta( $courier_id, CourierProfile::META_LAST_SEEN_TS, true ) ),
                'region'       => $region,
            ),
            200
        );
    }
}

HeartbeatAPI::boot();
