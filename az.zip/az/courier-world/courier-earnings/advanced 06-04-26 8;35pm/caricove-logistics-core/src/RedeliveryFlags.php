<?php
namespace Caricove\Logistics\Core;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * RedeliveryFlags
 *
 * Central place to manage free vs paid redelivery flags for shipments.
 * - Tracks free_redelivery_used (yes/no)
 * - Tracks paid_redelivery_count (integer)
 * - Provides helper methods for paid redelivery state transitions.
 */
class RedeliveryFlags {

    public static function boot() {
        // Hooks reserved for future (e.g. reacting to status changes).
    }

    /**
     * Mark that the free redelivery was used for this shipment.
     *
     * @param int $shipment_id
     */
    public static function mark_free_redelivery_used( $shipment_id ) {
        $shipment_id = intval( $shipment_id );
        if ( ! $shipment_id ) {
            return;
        }

        update_post_meta(
            $shipment_id,
            Schema::META_SHIPMENT_FREE_REDELIVERY_USED,
            'yes'
        );
    }

    /**
     * Increment paid redelivery count for a shipment.
     *
     * @param int $shipment_id
     * @return int New count
     */
    public static function increment_paid_redelivery_count( $shipment_id ) {
        $shipment_id = intval( $shipment_id );
        if ( ! $shipment_id ) {
            return 0;
        }

        $current = intval(
            get_post_meta(
                $shipment_id,
                Schema::META_SHIPMENT_PAID_REDELIVERY_COUNT,
                true
            )
        );

        $current++;

        update_post_meta(
            $shipment_id,
            Schema::META_SHIPMENT_PAID_REDELIVERY_COUNT,
            $current
        );

        return $current;
    }

    /**
     * When a customer successfully pays for a new redelivery attempt,
     * call this to:
     *  - increment paid_redelivery_count
     *  - set status = paid_redelivery_pending_confirmation
     *
     * @param int   $shipment_id
     * @param array $context
     */
    public static function request_paid_redelivery( $shipment_id, $context = array() ) {
        $shipment_id = intval( $shipment_id );
        if ( ! $shipment_id ) {
            return;
        }

        // Bump paid attempts.
        $count = self::increment_paid_redelivery_count( $shipment_id );

        $context = array_merge(
            array(
                'source'          => 'paid_redelivery_request',
                'paid_attempt_no' => $count,
            ),
            (array) $context
        );

        ShipmentManager::set_shipment_status(
            $shipment_id,
            'paid_redelivery_pending_confirmation',
            $context
        );
    }

    /**
     * Called when the Connection Team confirms that the customer
     * is reachable and ready for a paid redelivery attempt.
     *
     * @param int   $shipment_id
     * @param array $context
     */
    public static function mark_paid_redelivery_ready_for_dispatch( $shipment_id, $context = array() ) {
        $shipment_id = intval( $shipment_id );
        if ( ! $shipment_id ) {
            return;
        }

        $context = array_merge(
            array(
                'source'       => 'paid_redelivery_confirmed',
                'contact_team' => 'approved',
            ),
            (array) $context
        );

        ShipmentManager::set_shipment_status(
            $shipment_id,
            'paid_redelivery_ready_for_dispatch',
            $context
        );
    }

    /**
     * Called when the Connection Team fails to reach the customer
     * after the full call cycle (3 days, 30/60/120 mins).
     *
     * @param int   $shipment_id
     * @param array $context
     */
    public static function mark_paid_redelivery_failed_unreachable( $shipment_id, $context = array() ) {
        $shipment_id = intval( $shipment_id );
        if ( ! $shipment_id ) {
            return;
        }

        $context = array_merge(
            array(
                'source'       => 'paid_redelivery_failed_unreachable',
                'contact_team' => 'unreachable',
            ),
            (array) $context
        );

        ShipmentManager::set_shipment_status(
            $shipment_id,
            'paid_redelivery_failed_unreachable',
            $context
        );
    }
}