<?php
namespace Caricove\Logistics\Core;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * StorageEngine
 *
 * Placeholder for future advanced hub storage logic.
 * Current 30-day expiry is handled in the SLA MU plugin.
 */
class StorageEngine {

    public static function boot() {
        // Reserved for future; SLA MU plugin handles cron-based expiry.
    }
}