<?php
namespace Caricove\Logistics\Core;

use WP_Query;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * MovementLogger
 *
 * Logs a row into wp_cc_shipment_movements
 * every time a shipment status changes.
 */
class MovementLogger {

    public static function boot() {
        add_action( 'cc_shipment_status_changed', array( __CLASS__, 'log_status_change' ), 10, 4 );
    }

    /**
     * Log a status change into the movements table.
     *
     * @param int    $shipment_id
     * @param string $old_status
     * @param string $new_status
     * @param array  $context
     */
    public static function log_status_change( $shipment_id, $old_status, $new_status, $context = array() ) {
        global $wpdb;

        $shipment_id = intval( $shipment_id );
        if ( ! $shipment_id ) {
            return;
        }

        $table_name = $wpdb->prefix . 'cc_shipment_movements';

        if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table_name ) ) !== $table_name ) {
            return;
        }

        $summary   = ShipmentManager::get_shipment_summary( $shipment_id );
        $order_id  = ! empty( $summary['order_id'] ) ? intval( $summary['order_id'] ) : 0;
        $courier_id = 0;

        if ( isset( $context['courier_id'] ) ) {
            $courier_id = intval( $context['courier_id'] );
        }

        $event_key = isset( $context['source'] ) ? sanitize_key( $context['source'] ) : 'status_change';

        $notes = '';
        if ( isset( $context['reason'] ) ) {
            $notes = 'reason=' . sanitize_text_field( $context['reason'] );
        }

        $wpdb->insert(
            $table_name,
            array(
                'shipment_id' => $shipment_id,
                'order_id'    => $order_id,
                'courier_id'  => $courier_id,
                'status_from' => (string) $old_status,
                'status_to'   => (string) $new_status,
                'event_key'   => $event_key,
                'notes'       => $notes,
                'created_at'  => gmdate( 'Y-m-d H:i:s' ),
            ),
            array(
                '%d',
                '%d',
                '%d',
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
            )
        );
    }
}