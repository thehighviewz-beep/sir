<?php
namespace Caricove\Logistics\Core;

use Caricove\Logistics\Core\AutoAssign;

use WP_Query;
use WC_Order;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * ShipmentManager (Hardened + Strict-Dispatcher-Compatible) — VENDOR GATE EDITION
 *
 * Key behavior:
 * ✅ Default status on creation: pending_vendor_ready (NOT ready_for_assignment)
 * ✅ Does NOT fire cc_shipment_ready_for_assignment on creation
 * ✅ Public: vendor_mark_ready_for_pickup()
 *    - status => ready_for_assignment
 *    - fires cc_vendor_marked_ready_for_pickup + cc_shipment_ready_for_assignment
 *
 * Load assurance:
 * ✅ Boots only after WooCommerce is actually available (MU-safe, avoids “wc_get_order undefined” races)
 *
 * ETA/SLA policy sync:
 * ✅ While pending_vendor_ready: ETA = vendor-gate wait (~24h by default), source = vendor_gate (never “telemetry_blend”)
 * ✅ After vendor unlock: normal core baseline + telemetry hooks via cc_core_eta_sla_payload
 */
class ShipmentManager {

    /**
     * Vendor-gate status before Dispatcher may assign.
     */
    const STATUS_PENDING_VENDOR_READY = 'pending_vendor_ready';

    /**
     * Internal guard so we only register hooks once.
     */
    protected static $booted = false;

    protected static function read_quote_breakdown( $shipment_id ) {
        $raw = get_post_meta( $shipment_id, '_cc_cp_quote_breakdown', true );
        if ( is_array( $raw ) ) {
            return $raw;
        }
        if ( is_string( $raw ) && $raw !== '' ) {
            $decoded = json_decode( $raw, true );
            if ( is_array( $decoded ) ) {
                return $decoded;
            }
        }
        return array();
    }

    public static function normalize_distance_band( $band ) {
        $band = sanitize_key( (string) $band );
        if ( $band === 'extra_short' ) {
            return 'very_short';
        }
        if ( in_array( $band, array( 'very_short', 'short', 'medium', 'long' ), true ) ) {
            return $band;
        }
        return '';
    }

    public static function get_shipment_distance_band( $shipment_id, array $quote = array() ) {
        $shipment_id = intval( $shipment_id );
        if ( ! $shipment_id ) {
            return '';
        }

        $route = self::normalize_route_truth( $shipment_id, $quote );
        return sanitize_key( (string) ( $route['distance_band'] ?? '' ) );
    }

    protected static function infer_distance_band_from_distance( $distance_km ) {
        $distance_km = max( 0.0, floatval( $distance_km ) );

        if ( function_exists( 'cc_cp_get_band' ) ) {
            return self::normalize_distance_band( cc_cp_get_band( $distance_km ) );
        }

        if ( $distance_km <= 3.0 ) {
            return 'very_short';
        }
        if ( $distance_km <= 7.0 ) {
            return 'short';
        }
        if ( $distance_km <= 15.0 ) {
            return 'medium';
        }

        return 'long';
    }

    protected static function parse_coords_pair( $coords ) {
        if ( ! is_string( $coords ) || strpos( $coords, ',' ) === false ) {
            return array( null, null );
        }

        $parts = array_map( 'trim', explode( ',', $coords ) );
        if ( count( $parts ) !== 2 || ! is_numeric( $parts[0] ) || ! is_numeric( $parts[1] ) ) {
            return array( null, null );
        }

        return array( floatval( $parts[0] ), floatval( $parts[1] ) );
    }

    protected static function haversine_distance_km( $from_coords, $to_coords ) {
        list( $from_lat, $from_lng ) = self::parse_coords_pair( $from_coords );
        list( $to_lat, $to_lng )     = self::parse_coords_pair( $to_coords );

        if ( $from_lat === null || $from_lng === null || $to_lat === null || $to_lng === null ) {
            return 0.0;
        }

        $earth_radius_km = 6371.0;
        $d_lat = deg2rad( $to_lat - $from_lat );
        $d_lng = deg2rad( $to_lng - $from_lng );

        $a = sin( $d_lat / 2 ) * sin( $d_lat / 2 )
            + cos( deg2rad( $from_lat ) ) * cos( deg2rad( $to_lat ) )
            * sin( $d_lng / 2 ) * sin( $d_lng / 2 );

        $c = 2 * atan2( sqrt( $a ), sqrt( max( 0.0, 1 - $a ) ) );
        $distance = $earth_radius_km * $c;

        if ( ! is_finite( $distance ) || $distance < 0 ) {
            return 0.0;
        }

        return $distance;
    }


    protected static function representative_weight_kg_for_band( $band ) {
        $band = sanitize_key( (string) $band );
        if ( class_exists( '\Caricove\Logistics\Core\ZoneResolver' ) ) {
            return max( 0.0, floatval( ZoneResolver::representative_weight_kg_for_band( $band ) ) );
        }
        $map = array( 'light' => 4.0, 'medium' => 14.0, 'heavy' => 50.0, 'extra_heavy' => 120.0 );
        return floatval( $map[ $band ] ?? 0.0 );
    }

    protected static function calculate_item_dimensional_weight_kg( $length_cm, $width_cm, $height_cm ) {
        if ( class_exists( '\Caricove\Logistics\Core\ZoneResolver' ) ) {
            return max( 0.0, floatval( ZoneResolver::calculate_dimensional_weight_kg( $length_cm, $width_cm, $height_cm ) ) );
        }
        $volume = max( 0.0, floatval( $length_cm ) ) * max( 0.0, floatval( $width_cm ) ) * max( 0.0, floatval( $height_cm ) );
        return $volume > 0 ? round( $volume / 5000, 3 ) : 0.0;
    }

    protected static function calculate_item_effective_weight_kg( $actual_weight_kg, $length_cm, $width_cm, $height_cm ) {
        if ( class_exists( '\Caricove\Logistics\Core\ZoneResolver' ) ) {
            return max( 0.0, floatval( ZoneResolver::calculate_effective_weight_kg( $actual_weight_kg, $length_cm, $width_cm, $height_cm ) ) );
        }
        return max( max( 0.0, floatval( $actual_weight_kg ) ), self::calculate_item_dimensional_weight_kg( $length_cm, $width_cm, $height_cm ) );
    }

    protected static function calculate_item_volume_cm3( $length_cm, $width_cm, $height_cm ) {
        if ( class_exists( '\Caricove\Logistics\Core\ZoneResolver' ) ) {
            return max( 0.0, floatval( ZoneResolver::calculate_volume_cm3( $length_cm, $width_cm, $height_cm ) ) );
        }
        return max( 0.0, floatval( $length_cm ) ) * max( 0.0, floatval( $width_cm ) ) * max( 0.0, floatval( $height_cm ) );
    }

    protected static function get_order_item_physical_truth( $item ) {
        $truth = array(
            'weight_kg'      => 0.0,
            'length_cm'      => 0.0,
            'width_cm'       => 0.0,
            'height_cm'      => 0.0,
            'fragile'        => false,
            'liquid'         => false,
            'perishable'     => false,
            'handling_notes' => '',
            'source'         => 'missing',
        );

        if ( ! $item || ! is_object( $item ) ) {
            return $truth;
        }

        $read_numeric_meta = static function( $post_id, array $keys ) {
            $post_id = intval( $post_id );
            if ( $post_id <= 0 ) {
                return 0.0;
            }
            foreach ( $keys as $key ) {
                $raw = get_post_meta( $post_id, $key, true );
                if ( $raw === '' || $raw === null ) {
                    continue;
                }
                $value = max( 0.0, floatval( $raw ) );
                if ( $value > 0 ) {
                    return $value;
                }
            }
            return 0.0;
        };

        $read_bool_meta = static function( $post_id, $key ) {
            return get_post_meta( intval( $post_id ), $key, true ) === '1';
        };

        $candidate_ids = array();
        $variation_id  = is_callable( array( $item, 'get_variation_id' ) ) ? intval( $item->get_variation_id() ) : 0;
        $product_id    = is_callable( array( $item, 'get_product_id' ) ) ? intval( $item->get_product_id() ) : 0;
        if ( $variation_id > 0 ) {
            $candidate_ids[] = $variation_id;
        }
        if ( $product_id > 0 ) {
            $candidate_ids[] = $product_id;
        }

        foreach ( array_values( array_unique( array_filter( $candidate_ids ) ) ) as $candidate_id ) {
            $product = wc_get_product( $candidate_id );

            $weight = $product ? floatval( $product->get_weight() ) : 0.0;
            $length = $product ? floatval( $product->get_length() ) : 0.0;
            $width  = $product ? floatval( $product->get_width() ) : 0.0;
            $height = $product ? floatval( $product->get_height() ) : 0.0;

            if ( $weight <= 0 ) {
                $weight = $read_numeric_meta( $candidate_id, array( '_weight', '_cc_item_weight_kg', '_ccvps_weight', 'weight' ) );
            }
            if ( $length <= 0 ) {
                $length = $read_numeric_meta( $candidate_id, array( '_length', '_cc_item_length_cm', '_ccvps_length', 'length' ) );
            }
            if ( $width <= 0 ) {
                $width = $read_numeric_meta( $candidate_id, array( '_width', '_cc_item_width_cm', '_ccvps_width', 'width' ) );
            }
            if ( $height <= 0 ) {
                $height = $read_numeric_meta( $candidate_id, array( '_height', '_cc_item_height_cm', '_ccvps_height', 'height' ) );
            }

         $has_any_physical_truth = ( $weight > 0 || $length > 0 || $width > 0 || $height > 0 );
            if ( ! $has_any_physical_truth ) {
                continue;
            }

            $truth['weight_kg']      = max( 0.0, $weight );
            $truth['length_cm']      = max( 0.0, $length );
            $truth['width_cm']       = max( 0.0, $width );
            $truth['height_cm']      = max( 0.0, $height );
            $truth['fragile']        = $read_bool_meta( $candidate_id, '_ccvps_fragile' );
            $truth['liquid']         = $read_bool_meta( $candidate_id, '_ccvps_liquid' );
            $truth['perishable']     = $read_bool_meta( $candidate_id, '_ccvps_perishable' );
            $truth['handling_notes'] = (string) get_post_meta( $candidate_id, '_ccvps_handling_notes', true );

            if ( $candidate_id === $variation_id && $variation_id > 0 ) {
                $truth['source'] = $product ? 'variation_product' : 'variation_meta';
            } else {
                $truth['source'] = $product ? 'product' : 'product_meta';
            }

            /*
             * Do not return early on dimensions-only truth.
             * If this candidate has dimensions but no weight, keep scanning so a later
             * candidate can supply weight. If no later candidate has weight, the last
             * dimensions-only candidate will still be returned after the loop.
             */
            if ( $weight > 0 ) {
                return $truth;
            }
        }

        return $truth;
    }

    protected static function hydrate_order_item_physical_truth( $item_id, $item ) {
        $truth = self::get_order_item_physical_truth( $item );

        $item_weight_kg = max( 0.0, floatval( $truth['weight_kg'] ?? 0 ) );
        $item_length_cm = max( 0.0, floatval( $truth['length_cm'] ?? 0 ) );
        $item_width_cm  = max( 0.0, floatval( $truth['width_cm'] ?? 0 ) );
        $item_height_cm = max( 0.0, floatval( $truth['height_cm'] ?? 0 ) );
        $item_dim_weight_kg = self::calculate_item_dimensional_weight_kg( $item_length_cm, $item_width_cm, $item_height_cm );
        $item_effective_weight_kg = self::calculate_item_effective_weight_kg( $item_weight_kg, $item_length_cm, $item_width_cm, $item_height_cm );
        $item_volume_cm3 = self::calculate_item_volume_cm3( $item_length_cm, $item_width_cm, $item_height_cm );
        $item_longest_side_cm = max( $item_length_cm, $item_width_cm, $item_height_cm );
        $item_units     = 0;
        $item_oversize  = false;
        $size_band      = null;
        $weight_band    = null;

        if ( class_exists( '\Caricove\Logistics\Core\ZoneResolver' ) ) {
            $size_band     = ZoneResolver::map_dimensions_to_size_band( $item_length_cm, $item_width_cm, $item_height_cm );
            $weight_band   = ZoneResolver::map_weight_to_band( $item_effective_weight_kg );
            $item_units    = ZoneResolver::map_size_band_to_units( $size_band );
            $item_oversize = ZoneResolver::is_oversize_dimensions( $item_length_cm, $item_width_cm, $item_height_cm );
        }

        $size_band   = $size_band ? sanitize_key( $size_band ) : null;
        $weight_band = $weight_band ? sanitize_key( $weight_band ) : null;

        if ( $item_id ) {
            if ( $size_band ) {
                wc_update_order_item_meta( $item_id, Schema::META_ITEM_SIZE_CLASS, $size_band );
            }
            if ( $weight_band ) {
                wc_update_order_item_meta( $item_id, Schema::META_ITEM_WEIGHT_BAND, $weight_band );
            }
            wc_update_order_item_meta( $item_id, '_cc_item_weight_kg', $item_weight_kg );
            wc_update_order_item_meta( $item_id, '_cc_item_length_cm', $item_length_cm );
            wc_update_order_item_meta( $item_id, '_cc_item_width_cm',  $item_width_cm );
            wc_update_order_item_meta( $item_id, '_cc_item_height_cm', $item_height_cm );
            wc_update_order_item_meta( $item_id, '_cc_item_dim_weight_kg', $item_dim_weight_kg );
            wc_update_order_item_meta( $item_id, '_cc_item_effective_weight_kg', $item_effective_weight_kg );
            wc_update_order_item_meta( $item_id, '_cc_item_volume_cm3', $item_volume_cm3 );
            wc_update_order_item_meta( $item_id, '_cc_item_longest_side_cm', $item_longest_side_cm );
            wc_update_order_item_meta( $item_id, '_cc_item_units',     intval( $item_units ) );
            wc_update_order_item_meta( $item_id, '_cc_item_oversize',  $item_oversize ? '1' : '0' );
        }

        return array(
            'size_band'                => $size_band,
            'weight_band'              => $weight_band,
            'item_weight_kg'           => $item_weight_kg,
            'item_dim_weight_kg'       => $item_dim_weight_kg,
            'item_effective_weight_kg' => $item_effective_weight_kg,
            'item_length_cm'           => $item_length_cm,
            'item_width_cm'            => $item_width_cm,
            'item_height_cm'           => $item_height_cm,
            'item_volume_cm3'          => $item_volume_cm3,
            'item_longest_side_cm'     => $item_longest_side_cm,
            'item_units'               => intval( $item_units ),
            'item_oversize'            => (bool) $item_oversize,
            'source'                   => (string) ( $truth['source'] ?? 'missing' ),
        );
    }

    protected static function backfill_shipment_physical_truth_from_order( $shipment_id ) {
        $shipment_id = intval( $shipment_id );
        if ( ! $shipment_id ) {
            return array();
        }

        $order_id = intval( get_post_meta( $shipment_id, Schema::META_SHIPMENT_ORDER_ID, true ) );
        if ( ! $order_id ) {
            return array();
        }

        $order = wc_get_order( $order_id );
        if ( ! $order ) {
            return array();
        }

        $size_rank   = array( 'xs' => 0, 's' => 1, 'm' => 2, 'l' => 3, 'xl' => 4 );
        $weight_rank = array( 'light' => 0, 'medium' => 1, 'heavy' => 2, 'extra_heavy' => 3 );

        $max_size_band = '';
        $weight_band = '';
        $legacy_band = '';
        $total_weight_kg = 0.0;
        $total_dim_weight_kg = 0.0;
        $total_effective_weight_kg = 0.0;
        $max_longest_side_cm = 0.0;
        $total_volume_cm3 = 0.0;
        $weight_source = 'missing';

        foreach ( $order->get_items( 'line_item' ) as $item_id => $item ) {
            $linked_shipment = intval( wc_get_order_item_meta( $item_id, Schema::META_ITEM_SHIPMENT_ID, true ) );
            if ( $linked_shipment !== $shipment_id ) {
                continue;
            }

            $physical = self::hydrate_order_item_physical_truth( $item_id, $item );
            $qty = is_callable( array( $item, 'get_quantity' ) ) ? max( 1, intval( $item->get_quantity() ) ) : 1;

            $item_size = sanitize_key( (string) ( $physical['size_band'] ?? wc_get_order_item_meta( $item_id, Schema::META_ITEM_SIZE_CLASS, true ) ) );
            if ( $item_size && isset( $size_rank[ $item_size ] ) ) {
                if ( $max_size_band === '' || $size_rank[ $item_size ] > $size_rank[ $max_size_band ] ) {
                    $max_size_band = $item_size;
                }
            }

            $item_weight_band = sanitize_key( (string) ( $physical['weight_band'] ?? wc_get_order_item_meta( $item_id, Schema::META_ITEM_WEIGHT_BAND, true ) ) );
            if ( $item_weight_band && isset( $weight_rank[ $item_weight_band ] ) ) {
                if ( $legacy_band === '' || $weight_rank[ $item_weight_band ] > $weight_rank[ $legacy_band ] ) {
                    $legacy_band = $item_weight_band;
                }
            }

            $item_weight = max( 0.0, floatval( $physical['item_weight_kg'] ?? wc_get_order_item_meta( $item_id, '_cc_item_weight_kg', true ) ) );
            $item_dim_weight = max( 0.0, floatval( $physical['item_dim_weight_kg'] ?? wc_get_order_item_meta( $item_id, '_cc_item_dim_weight_kg', true ) ) );
            $item_effective_weight = max( 0.0, floatval( $physical['item_effective_weight_kg'] ?? wc_get_order_item_meta( $item_id, '_cc_item_effective_weight_kg', true ) ) );
            $item_longest_side = max( 0.0, floatval( $physical['item_longest_side_cm'] ?? wc_get_order_item_meta( $item_id, '_cc_item_longest_side_cm', true ) ) );
            $item_volume = max( 0.0, floatval( $physical['item_volume_cm3'] ?? wc_get_order_item_meta( $item_id, '_cc_item_volume_cm3', true ) ) );

            if ( $item_weight > 0 ) {
                $total_weight_kg += ( $item_weight * $qty );
                $weight_source = (string) ( $physical['source'] ?? 'item_meta' );
            }
            if ( $item_dim_weight > 0 ) {
                $total_dim_weight_kg += ( $item_dim_weight * $qty );
            }
            if ( $item_effective_weight > 0 ) {
                $total_effective_weight_kg += ( $item_effective_weight * $qty );
            }
            if ( $item_longest_side > $max_longest_side_cm ) {
                $max_longest_side_cm = $item_longest_side;
            }
            if ( $item_volume > 0 ) {
                $total_volume_cm3 += ( $item_volume * $qty );
            }
        }

        if ( $total_effective_weight_kg <= 0 ) {
            $total_effective_weight_kg = max( $total_weight_kg, $total_dim_weight_kg );
        }

        if ( $total_effective_weight_kg > 0 && class_exists( '\Caricove\Logistics\Core\ZoneResolver' ) ) {
            $weight_band = ZoneResolver::map_weight_to_band( $total_effective_weight_kg );
        }
        if ( ! $weight_band ) {
            $weight_band = $legacy_band;
        }
        if ( $total_effective_weight_kg <= 0 && $weight_band ) {
            $total_effective_weight_kg = self::representative_weight_kg_for_band( $weight_band );
            if ( $total_effective_weight_kg > 0 ) {
                $weight_source = 'band_representative';
            }
        }

        if ( $max_size_band ) {
            update_post_meta( $shipment_id, Schema::META_SHIPMENT_SIZE_BAND, sanitize_key( $max_size_band ) );
        }
        if ( $weight_band ) {
            update_post_meta( $shipment_id, Schema::META_SHIPMENT_WEIGHT_BAND, sanitize_key( $weight_band ) );
        }
        if ( $total_weight_kg > 0 ) {
            update_post_meta( $shipment_id, '_cc_shipment_total_weight', round( $total_weight_kg, 3 ) );
        }
        update_post_meta( $shipment_id, '_cc_shipment_dim_weight', round( $total_dim_weight_kg, 3 ) );
        update_post_meta( $shipment_id, '_cc_shipment_effective_weight', round( $total_effective_weight_kg, 3 ) );
        update_post_meta( $shipment_id, '_cc_shipment_longest_side_cm', round( $max_longest_side_cm, 3 ) );
        update_post_meta( $shipment_id, '_cc_shipment_volume_cm3', round( $total_volume_cm3, 3 ) );
        update_post_meta( $shipment_id, '_cc_shipment_total_weight_source', sanitize_key( (string) $weight_source ) );

        return array(
            'size_band'        => $max_size_band,
            'weight_band'      => $weight_band,
            'total_weight'     => $total_weight_kg,
            'dim_weight'       => $total_dim_weight_kg,
            'effective_weight' => $total_effective_weight_kg,
            'longest_side_cm'  => $max_longest_side_cm,
            'volume_cm3'       => $total_volume_cm3,
            'weight_source'    => $weight_source,
        );
    }

    protected static function normalize_route_truth( $shipment_id, array $quote_breakdown = array() ) {
        $shipment_id = intval( $shipment_id );
        if ( ! $shipment_id ) {
            return array(
                'distance_km'       => 0.0,
                'duration_seconds'  => 0,
                'quote_total_gyd'   => 0.0,
                'distance_band'     => '',
                'trip_band'         => '',
                'route_source'      => 'legacy_manual',
                'route_detail_source' => '',
                'route_provenance'  => 'legacy_manual',
                'planner_has_truth' => false,
                'fallback_used'     => true,
                'quote_breakdown'   => array(),
            );
        }

        if ( empty( $quote_breakdown ) ) {
            $quote_breakdown = self::read_quote_breakdown( $shipment_id );
        }

        $route_meta = array();
        if ( isset( $quote_breakdown['route'] ) && is_array( $quote_breakdown['route'] ) ) {
            $route_meta = $quote_breakdown['route'];
        }

        $distance_km = 0.0;
        $duration_seconds = 0;
        $quote_total_gyd = floatval( get_post_meta( $shipment_id, '_cc_cp_quote_total_gyd', true ) );
        $detail_source = '';

        $planner_distance_sources = array(
            $quote_breakdown['distance_km'] ?? null,
            $quote_breakdown['route_distance_km'] ?? null,
            $route_meta['distance_km'] ?? null,
            get_post_meta( $shipment_id, '_cc_cp_quote_distance_km', true ),
        );

        foreach ( $planner_distance_sources as $candidate ) {
            if ( is_numeric( $candidate ) && floatval( $candidate ) > 0 ) {
                $distance_km = floatval( $candidate );
                break;
            }
        }

        $planner_duration_sources = array(
            $quote_breakdown['duration_seconds'] ?? null,
            $route_meta['duration_seconds'] ?? null,
            get_post_meta( $shipment_id, '_cc_cp_quote_duration_seconds', true ),
        );

        foreach ( $planner_duration_sources as $candidate ) {
            if ( is_numeric( $candidate ) && intval( $candidate ) > 0 ) {
                $duration_seconds = intval( $candidate );
                break;
            }
        }

        if ( $duration_seconds <= 0 && is_numeric( $quote_breakdown['duration_minutes'] ?? null ) ) {
            $duration_seconds = intval( round( floatval( $quote_breakdown['duration_minutes'] ) * 60 ) );
        }

        if ( $quote_total_gyd <= 0 && is_numeric( $quote_breakdown['total'] ?? null ) ) {
            $quote_total_gyd = floatval( $quote_breakdown['total'] );
        }
        if ( $quote_total_gyd <= 0 && is_numeric( $quote_breakdown['quote_total_gyd'] ?? null ) ) {
            $quote_total_gyd = floatval( $quote_breakdown['quote_total_gyd'] );
        }

        $detail_source = sanitize_key(
            (string) (
                $route_meta['source']
                ?? $quote_breakdown['route_source']
                ?? $quote_breakdown['source']
                ?? ''
            )
        );

        $distance_band = self::normalize_distance_band( $quote_breakdown['distance_band'] ?? $quote_breakdown['trip_band'] ?? '' );
        if ( $distance_band === '' && $distance_km > 0 ) {
            $distance_band = self::infer_distance_band_from_distance( $distance_km );
        }

        $planner_has_truth = ( $distance_km > 0 || $duration_seconds > 0 || $quote_total_gyd > 0 || $distance_band !== '' );
        $route_source = $planner_has_truth ? 'cc_cp' : '';
        $route_provenance = $planner_has_truth ? 'cc_cp' : '';

        if ( $planner_has_truth && $detail_source === '' ) {
            $detail_source = 'cc_cp';
        }

        if ( ! $planner_has_truth ) {
            $fallback_distance = self::haversine_distance_km(
                (string) get_post_meta( $shipment_id, Schema::META_SHIPMENT_PICKUP_COORDS, true ),
                (string) get_post_meta( $shipment_id, Schema::META_SHIPMENT_DROPOFF_COORDS, true )
            );

            if ( $fallback_distance > 0 ) {
                $distance_km      = $fallback_distance;
                $duration_seconds = $duration_seconds > 0 ? $duration_seconds : intval( max( 300, round( $distance_km * 240 ) ) );
                $distance_band    = self::infer_distance_band_from_distance( $distance_km );
                $route_source     = 'fallback_haversine';
                $detail_source    = 'fallback_haversine';
                $route_provenance = 'fallback_haversine';
            } else {
                $route_source     = 'legacy_manual';
                $detail_source    = 'legacy_manual';
                $route_provenance = 'legacy_manual';
            }
        }

        return array(
            'distance_km'         => max( 0.0, floatval( $distance_km ) ),
            'duration_seconds'    => max( 0, intval( $duration_seconds ) ),
            'quote_total_gyd'     => max( 0.0, floatval( $quote_total_gyd ) ),
            'distance_band'       => sanitize_key( (string) $distance_band ),
            'trip_band'           => sanitize_key( (string) $distance_band ),
            'route_source'        => sanitize_key( (string) $route_source ),
            'route_detail_source' => sanitize_key( (string) $detail_source ),
            'route_provenance'    => sanitize_key( (string) $route_provenance ),
            'planner_has_truth'   => (bool) $planner_has_truth,
            'fallback_used'       => ! $planner_has_truth,
            'quote_breakdown'     => is_array( $quote_breakdown ) ? $quote_breakdown : array(),
        );
    }

    protected static function clear_operational_offer_meta( $shipment_id ) {
        $shipment_id = intval( $shipment_id );
        if ( ! $shipment_id ) {
            return;
        }

        delete_post_meta( $shipment_id, Schema::META_SHIPMENT_OFFER_CREATED_AT );
        delete_post_meta( $shipment_id, Schema::META_SHIPMENT_OFFER_EXPIRES_AT );
        delete_post_meta( $shipment_id, Schema::META_SHIPMENT_OFFER_COURIER_ID );
        delete_post_meta( $shipment_id, Schema::META_SHIPMENT_OFFER_RESPONSE_WINDOW );
    }

    /* ---------------------------------------------------------------------
     * LOAD ASSURANCE (MU-SAFE)
     * ------------------------------------------------------------------ */

    /**
     * Call this instead of boot() directly.
     * Ensures WooCommerce functions/classes exist before we register WC hooks.
     */
    public static function load_assurance() : void {
        // Try late on plugins_loaded (covers normal plugins + MU contexts).
        add_action( 'plugins_loaded', array( __CLASS__, 'boot_when_ready' ), 30 );

        // Try again when Woo initializes (covers cases where WC loads after MU).
        add_action( 'woocommerce_init', array( __CLASS__, 'boot_when_ready' ), 5 );

        // Fallback safety: in some stacks woocommerce_init can be missed; try on init too.
        add_action( 'init', array( __CLASS__, 'boot_when_ready' ), 20 );
    }

    /**
     * Boot only when Woo is present; otherwise do nothing (and next hook will re-attempt).
     */
    public static function boot_when_ready() : void {
        if ( self::$booted ) {
            return;
        }

        // Minimal WC readiness check.
        if ( ! function_exists( 'wc_get_order' ) || ! class_exists( '\WC_Order' ) ) {
            return;
        }

        self::$booted = true;
        self::boot();
    }

    /* ---------------------------------------------------------------------
     * BOOT
     * ------------------------------------------------------------------ */

    public static function boot() : void {
        add_action(
            'woocommerce_checkout_order_processed',
            array( __CLASS__, 'create_shipments_from_order' ),
            20,
            1
        );

        add_action( 'woocommerce_order_status_cancelled', array( __CLASS__, 'cancel_shipments_for_order' ), 10, 1 );
        add_action( 'woocommerce_order_status_refunded',  array( __CLASS__, 'cancel_shipments_for_order' ), 10, 1 );
    }

    /* ---------------------------------------------------------------------
     * ORDER → SHIPMENTS
     * ------------------------------------------------------------------ */

    public static function create_shipments_from_order( $order_id ) {
        $order = wc_get_order( $order_id );
        if ( ! $order ) {
            return;
        }

        $items = $order->get_items( 'line_item' );
        if ( empty( $items ) ) {
            return;
        }

        $grouped_by_vendor = array();

        foreach ( $items as $item_id => $item ) {

            $product        = $item->get_product();
            $default_vendor = 0;

            $vendor_id = apply_filters(
                'cc_logistics_vendor_id_for_item',
                $default_vendor,
                $order,
                $item
            );

            if ( empty( $vendor_id ) && $product ) {
                $author_id = (int) get_post_field( 'post_author', $product->get_id() );
                if ( $author_id > 0 ) {
                    $vendor_id = $author_id;
                }
            }

            $vendor_id = intval( $vendor_id );
            if ( ! isset( $grouped_by_vendor[ $vendor_id ] ) ) {
                $grouped_by_vendor[ $vendor_id ] = array();
            }
            $grouped_by_vendor[ $vendor_id ][ $item_id ] = $item;

            // Compute bands + raw physical truth from the chosen variation/product logistics truth.
            $physical_truth = self::hydrate_order_item_physical_truth( $item_id, $item );
            $size_band      = $physical_truth['size_band'] ?? null;
            $weight_band    = $physical_truth['weight_band'] ?? null;
            $value_band     = null;
            $item_weight_kg = floatval( $physical_truth['item_weight_kg'] ?? 0 );
            $item_length_cm = floatval( $physical_truth['item_length_cm'] ?? 0 );
            $item_width_cm  = floatval( $physical_truth['item_width_cm'] ?? 0 );
            $item_height_cm = floatval( $physical_truth['item_height_cm'] ?? 0 );
            $item_units     = intval( $physical_truth['item_units'] ?? 0 );
            $item_oversize  = ! empty( $physical_truth['item_oversize'] );

            $line_total = floatval( $item->get_total() ) + floatval( $item->get_total_tax() );
            if ( class_exists( '\Caricove\Logistics\Core\ZoneResolver' ) ) {
                $value_band = ZoneResolver::map_value_to_band( $line_total );
            }

            // Normalize computed bands defensively.
            $size_band   = $size_band   ? sanitize_key( $size_band )   : null;
            $weight_band = $weight_band ? sanitize_key( $weight_band ) : null;
            $value_band  = $value_band  ? sanitize_key( $value_band )  : null;

            // Write item-level meta on the order item.
            wc_update_order_item_meta( $item_id, Schema::META_ITEM_VENDOR_ID, $vendor_id );
            wc_update_order_item_meta( $item_id, Schema::META_ITEM_ORDER_ITEM_ID, $item_id );

            if ( $size_band ) {
                wc_update_order_item_meta( $item_id, Schema::META_ITEM_SIZE_CLASS, $size_band );
            }
            if ( $weight_band ) {
                wc_update_order_item_meta( $item_id, Schema::META_ITEM_WEIGHT_BAND, $weight_band );
            }
            if ( $value_band ) {
                wc_update_order_item_meta( $item_id, Schema::META_ITEM_VALUE_BAND, $value_band );
            }

            // Support truth for stronger shipment aggregation (non-breaking).
            wc_update_order_item_meta( $item_id, '_cc_item_weight_kg', $item_weight_kg );
            wc_update_order_item_meta( $item_id, '_cc_item_length_cm', $item_length_cm );
            wc_update_order_item_meta( $item_id, '_cc_item_width_cm',  $item_width_cm );
            wc_update_order_item_meta( $item_id, '_cc_item_height_cm', $item_height_cm );
            wc_update_order_item_meta( $item_id, '_cc_item_units',     intval( $item_units ) );
            wc_update_order_item_meta( $item_id, '_cc_item_oversize',  $item_oversize ? '1' : '0' );
        }

        // Addresses & contacts from order.
        $pickup_address       = self::build_pickup_address_from_order( $order );
        $dropoff_address      = self::build_dropoff_address_from_order( $order );
        $dropoff_instructions = self::get_dropoff_delivery_instructions_from_order( $order );

        if ( $dropoff_instructions !== '' && is_array( $dropoff_address ) ) {
            $dropoff_address['instructions']          = $dropoff_instructions;
            $dropoff_address['delivery_instructions'] = $dropoff_instructions;
        }

        // Dropoff coords / anchor from geocoding.
        $dropoff_coords     = '';
        $destination_anchor = '';

        $drop_lat = $order->get_meta( '_cc_dropoff_lat' );
        $drop_lng = $order->get_meta( '_cc_dropoff_lng' );

        if ( is_numeric( $drop_lat ) && is_numeric( $drop_lng ) ) {
            $dropoff_coords = $drop_lat . ',' . $drop_lng;

            $drop_zone_meta = $order->get_meta( '_cc_dropoff_zone' );
            if ( $drop_zone_meta ) {
                $destination_anchor = sanitize_key( $drop_zone_meta );
            } elseif ( class_exists( '\Caricove\Logistics\Core\ZoneResolver' ) ) {
                $destination_anchor = ZoneResolver::map_coords_to_anchor(
                    (float) $drop_lat,
                    (float) $drop_lng,
                    Schema::get_zone_definitions()
                );
            }
        }

        if ( ! $destination_anchor && class_exists( '\Caricove\Logistics\Core\ZoneResolver' ) ) {
            $destination_anchor = ZoneResolver::resolve_dropoff_zone(
                $dropoff_coords ? $dropoff_coords : $dropoff_address
            );
        }

        $pickup_name   = self::get_pickup_contact_name_from_order( $order );
        $pickup_phone  = self::get_pickup_contact_phone_from_order( $order );
        $dropoff_name  = self::get_dropoff_contact_name_from_order( $order );
        $dropoff_phone = self::get_dropoff_contact_phone_from_order( $order );

        // Aggregation helpers (STRICT alignment with Dispatcher).
        $size_rank = array( 'xs' => 0, 's' => 1, 'm' => 2, 'l' => 3, 'xl' => 4 );
        $weight_rank = array(
            'light'       => 0,
            'medium'      => 1,
            'heavy'       => 2,
            'extra_heavy' => 3,
        );

        foreach ( $grouped_by_vendor as $vendor_id => $vendor_items ) {

            // Vendor-specific pickup coords + anchor.
            $pickup_coords = '';
            $origin_anchor = '';

            if ( $vendor_id ) {
                $vendor_lat  = get_user_meta( $vendor_id, '_cc_vendor_lat', true );
                $vendor_lng  = get_user_meta( $vendor_id, '_cc_vendor_lng', true );
                $vendor_zone = get_user_meta( $vendor_id, '_cc_vendor_zone', true );

                if ( is_numeric( $vendor_lat ) && is_numeric( $vendor_lng ) ) {
                    $pickup_coords = $vendor_lat . ',' . $vendor_lng;

                    if ( $vendor_zone ) {
                        $origin_anchor = sanitize_key( $vendor_zone );
                    } elseif ( class_exists( '\Caricove\Logistics\Core\ZoneResolver' ) ) {
                        $origin_anchor = ZoneResolver::map_coords_to_anchor(
                            (float) $vendor_lat,
                            (float) $vendor_lng,
                            Schema::get_zone_definitions()
                        );
                    }
                }
            }

            // Ensure dropoff_coords is never blank when we know destination anchor.
            if ( empty( $dropoff_coords ) && $destination_anchor ) {
                $zones = Schema::get_zone_definitions();

                if ( isset( $zones[ $destination_anchor ]['lat'], $zones[ $destination_anchor ]['lng'] ) ) {
                    $dropoff_coords = $zones[ $destination_anchor ]['lat'] . ',' . $zones[ $destination_anchor ]['lng'];
                } elseif ( isset( $zones['gt_kingston_hub']['lat'], $zones['gt_kingston_hub']['lng'] ) ) {
                    $dropoff_coords = $zones['gt_kingston_hub']['lat'] . ',' . $zones['gt_kingston_hub']['lng'];
                }
            }

            // Ensure pickup_coords is never blank when we know origin anchor.
            if ( empty( $pickup_coords ) && $origin_anchor ) {
                $zones = Schema::get_zone_definitions();

                if ( isset( $zones[ $origin_anchor ]['lat'], $zones[ $origin_anchor ]['lng'] ) ) {
                    $pickup_coords = $zones[ $origin_anchor ]['lat'] . ',' . $zones[ $origin_anchor ]['lng'];
                } elseif ( isset( $zones['gt_kingston_hub']['lat'], $zones['gt_kingston_hub']['lng'] ) ) {
                    $pickup_coords = $zones['gt_kingston_hub']['lat'] . ',' . $zones['gt_kingston_hub']['lng'];
                }
            }

            // Vendor pickup address (geocoder/storefront truth → formatted geocoder fallback → billing fallback → hub).
            $vendor_pickup_address = $pickup_address;

            if ( $vendor_id ) {
                $candidate = array(
                    'street'    => (string) get_user_meta( $vendor_id, '_cc_vendor_storefront_street_1', true ),
                    'street_2'  => (string) get_user_meta( $vendor_id, '_cc_vendor_storefront_street_2', true ),
                    'village'   => '',
                    'city'      => (string) get_user_meta( $vendor_id, '_cc_vendor_storefront_city', true ),
                    'region'    => (string) get_user_meta( $vendor_id, '_cc_vendor_storefront_region', true ),
                    'postcode'  => (string) get_user_meta( $vendor_id, '_cc_vendor_storefront_postcode', true ),
                    'country'   => (string) get_user_meta( $vendor_id, '_cc_vendor_storefront_country_name', true ),
                );

                if ( array_filter( $candidate ) ) {
                    $vendor_pickup_address = $candidate;
                }

                // Geocode-bridge formatted address fallback.
                if ( $vendor_pickup_address === $pickup_address ) {
                    $formatted = get_user_meta( $vendor_id, '_cc_vendor_storefront_address', true );
                    if ( ! $formatted ) {
                        $formatted = get_user_meta( $vendor_id, '_cc_vendor_formatted_address', true );
                    }

                    if ( $formatted ) {
                        $vendor_pickup_address = array(
                            'street'    => (string) $formatted,
                            'street_2'  => '',
                            'village'   => '',
                            'city'      => '',
                            'region'    => '',
                            'postcode'  => '',
                            'country'   => '',
                        );
                    }
                }

                // Billing address fallback.
                if ( $vendor_pickup_address === $pickup_address ) {
                    $candidate = array(
                        'street'    => (string) get_user_meta( $vendor_id, 'billing_address_1', true ),
                        'street_2'  => (string) get_user_meta( $vendor_id, 'billing_address_2', true ),
                        'village'   => '',
                        'city'      => (string) get_user_meta( $vendor_id, 'billing_city', true ),
                        'region'    => (string) get_user_meta( $vendor_id, 'billing_state', true ),
                        'postcode'  => (string) get_user_meta( $vendor_id, 'billing_postcode', true ),
                        'country'   => (string) get_user_meta( $vendor_id, 'billing_country', true ),
                    );

                    if ( array_filter( $candidate ) ) {
                        $vendor_pickup_address = $candidate;
                    }
                }
            }

            // Resolve pickup anchor if still empty.
            if ( ! $origin_anchor && class_exists( '\Caricove\Logistics\Core\ZoneResolver' ) ) {
                $origin_anchor = ZoneResolver::resolve_pickup_zone(
                    $pickup_coords ? $pickup_coords : $vendor_pickup_address
                );
            }

            $item_count     = count( $vendor_items );
            $declared_value = 0.0;

            foreach ( $vendor_items as $item ) {
                $declared_value += floatval( $item->get_total() ) + floatval( $item->get_total_tax() );
            }

            // Create shipment CPT.
            $shipment_post_id = wp_insert_post(
                array(
                    'post_type'   => 'cc_shipment',
                    'post_status' => 'publish',
                    'post_title'  => sprintf(
                        'Shipment %s – Order #%s – Vendor %d',
                        wp_generate_uuid4(),
                        $order->get_order_number(),
                        intval( $vendor_id )
                    ),
                    'post_parent' => $order->get_id(),
                )
            );

            if ( ! $shipment_post_id || is_wp_error( $shipment_post_id ) ) {
                continue;
            }

            // ==========================================================
            // CORE SHIPMENT META (VENDOR-GATED)
            // ==========================================================
            update_post_meta( $shipment_post_id, Schema::META_SHIPMENT_TYPE, 'delivery' );

            // Vendor gate status by default.
            $initial_status = apply_filters(
                'cc_core_initial_shipment_status',
                self::STATUS_PENDING_VENDOR_READY,
                $shipment_post_id,
                $order->get_id(),
                $vendor_id
            );
            update_post_meta( $shipment_post_id, Schema::META_SHIPMENT_STATUS, sanitize_key( $initial_status ) );

            update_post_meta( $shipment_post_id, Schema::META_SHIPMENT_ORDER_ID, $order->get_id() );
            update_post_meta( $shipment_post_id, Schema::META_SHIPMENT_VENDOR_ID, $vendor_id );
            update_post_meta( $shipment_post_id, Schema::META_SHIPMENT_PICKUP_ADDRESS, wp_json_encode( $vendor_pickup_address ) );
            update_post_meta( $shipment_post_id, Schema::META_SHIPMENT_DROPOFF_ADDRESS, wp_json_encode( $dropoff_address ) );
            update_post_meta( $shipment_post_id, Schema::META_SHIPMENT_PICKUP_COORDS, $pickup_coords );
            update_post_meta( $shipment_post_id, Schema::META_SHIPMENT_DROPOFF_COORDS, $dropoff_coords );

            // Per-vendor pickup identity.
            $pickup_name_for_shipment  = $pickup_name;
            $pickup_phone_for_shipment = $pickup_phone;

            if ( $vendor_id ) {
                $storefront_name = (string) get_user_meta( $vendor_id, '_cc_vendor_storefront_name', true );
                if ( ! $storefront_name ) {
                    $storefront_name = (string) get_user_meta( $vendor_id, '_cc_store_name', true );
                }

                if ( $storefront_name ) {
                    $pickup_name_for_shipment = $storefront_name;
                } elseif ( ! $pickup_name_for_shipment ) {
                    $vendor_user = get_user_by( 'id', $vendor_id );
                    if ( $vendor_user ) {
                        $pickup_name_for_shipment = $vendor_user->display_name;
                    }
                }

                $storefront_phone = (string) get_user_meta( $vendor_id, '_cc_store_public_phone', true );
                if ( ! $storefront_phone ) {
                    $storefront_phone = (string) get_user_meta( $vendor_id, 'billing_phone', true );
                }

                if ( $storefront_phone ) {
                    $pickup_phone_for_shipment = $storefront_phone;
                }
            }

            update_post_meta( $shipment_post_id, Schema::META_SHIPMENT_PICKUP_NAME,  $pickup_name_for_shipment );
            update_post_meta( $shipment_post_id, Schema::META_SHIPMENT_PICKUP_PHONE, $pickup_phone_for_shipment );
            update_post_meta( $shipment_post_id, Schema::META_SHIPMENT_DROPOFF_NAME,  $dropoff_name );
            update_post_meta( $shipment_post_id, Schema::META_SHIPMENT_DROPOFF_PHONE, $dropoff_phone );

            if ( $dropoff_instructions !== '' ) {
                update_post_meta( $shipment_post_id, '_cc_shipment_delivery_instructions', $dropoff_instructions );
                update_post_meta( $shipment_post_id, '_cc_dropoff_delivery_instructions', $dropoff_instructions );
            }

            update_post_meta( $shipment_post_id, Schema::META_SHIPMENT_ITEM_COUNT, $item_count );
            update_post_meta( $shipment_post_id, Schema::META_SHIPMENT_DECLARED_VALUE, $declared_value );
            update_post_meta( $shipment_post_id, Schema::META_SHIPMENT_ORIGIN_ANCHOR, $origin_anchor );
            update_post_meta( $shipment_post_id, Schema::META_SHIPMENT_DEST_ANCHOR, $destination_anchor );

            // Link items to shipment & aggregate shipment burden.
            $max_size_band       = null;
            $legacy_weight_band  = null;
            $total_weight_kg     = 0.0;
            $total_dim_weight_kg = 0.0;
            $total_effective_weight_kg = 0.0;
            $max_longest_side_cm = 0.0;
            $total_volume_cm3    = 0.0;
            $total_units         = 0;
            $shipment_oversize   = false;

            foreach ( $vendor_items as $item_id => $item ) {

                wc_update_order_item_meta( $item_id, Schema::META_ITEM_SHIPMENT_ID, $shipment_post_id );
                wc_update_order_item_meta( $item_id, Schema::META_ITEM_PICKUP_ZONE, $origin_anchor );
                wc_update_order_item_meta( $item_id, Schema::META_ITEM_DROPOFF_ZONE, $destination_anchor );

                $item_size        = sanitize_key( (string) wc_get_order_item_meta( $item_id, Schema::META_ITEM_SIZE_CLASS, true ) );
                $item_weight_band = sanitize_key( (string) wc_get_order_item_meta( $item_id, Schema::META_ITEM_WEIGHT_BAND, true ) );
                $item_weight_kg   = floatval( wc_get_order_item_meta( $item_id, '_cc_item_weight_kg', true ) );
                $item_dim_weight_kg = floatval( wc_get_order_item_meta( $item_id, '_cc_item_dim_weight_kg', true ) );
                $item_effective_weight_kg = floatval( wc_get_order_item_meta( $item_id, '_cc_item_effective_weight_kg', true ) );
                $item_longest_side_cm = floatval( wc_get_order_item_meta( $item_id, '_cc_item_longest_side_cm', true ) );
                $item_volume_cm3 = floatval( wc_get_order_item_meta( $item_id, '_cc_item_volume_cm3', true ) );
                $item_units       = intval( wc_get_order_item_meta( $item_id, '_cc_item_units', true ) );
                $item_oversize    = wc_get_order_item_meta( $item_id, '_cc_item_oversize', true ) === '1';
                $qty              = is_callable( array( $item, 'get_quantity' ) ) ? max( 1, intval( $item->get_quantity() ) ) : 1;

                if ( $item_size && isset( $size_rank[ $item_size ] ) ) {
                    if ( null === $max_size_band || $size_rank[ $item_size ] > $size_rank[ $max_size_band ] ) {
                        $max_size_band = $item_size;
                    }
                }

                if ( $item_weight_band && isset( $weight_rank[ $item_weight_band ] ) ) {
                    if ( null === $legacy_weight_band || $weight_rank[ $item_weight_band ] > $weight_rank[ $legacy_weight_band ] ) {
                        $legacy_weight_band = $item_weight_band;
                    }
                }

                if ( $item_weight_kg > 0 ) {
                    $total_weight_kg += ( $item_weight_kg * $qty );
                }
                if ( $item_dim_weight_kg > 0 ) {
                    $total_dim_weight_kg += ( $item_dim_weight_kg * $qty );
                }
                if ( $item_effective_weight_kg > 0 ) {
                    $total_effective_weight_kg += ( $item_effective_weight_kg * $qty );
                }
                if ( $item_longest_side_cm > $max_longest_side_cm ) {
                    $max_longest_side_cm = $item_longest_side_cm;
                }
                if ( $item_volume_cm3 > 0 ) {
                    $total_volume_cm3 += ( $item_volume_cm3 * $qty );
                }
                if ( $item_units > 0 ) {
                    $total_units += ( $item_units * $qty );
                }
                if ( $item_oversize ) {
                    $shipment_oversize = true;
                }
            }

            if ( ! $max_size_band ) {
                $max_size_band = apply_filters( 'cc_core_default_size_band', 'm', $shipment_post_id, $order, $vendor_id );
            }

            if ( $total_effective_weight_kg <= 0 ) {
                $total_effective_weight_kg = max( $total_weight_kg, $total_dim_weight_kg );
            }

            $shipment_weight_band = null;
            if ( class_exists( '\Caricove\Logistics\Core\ZoneResolver' ) && $total_effective_weight_kg > 0 ) {
                $shipment_weight_band = ZoneResolver::map_weight_to_band( $total_effective_weight_kg );
            }
            if ( ! $shipment_weight_band ) {
                $shipment_weight_band = $legacy_weight_band;
            }
            if ( ! $shipment_weight_band ) {
                $shipment_weight_band = apply_filters( 'cc_core_default_weight_band', 'medium', $shipment_post_id, $order, $vendor_id );
            }

            $recommended_vehicle = 'car';
            if ( class_exists( '\Caricove\Logistics\Core\ZoneResolver' ) ) {
                $recommended_vehicle = ZoneResolver::recommend_vehicle_tier( $total_effective_weight_kg, $max_size_band, $total_units, $shipment_oversize );
            }

            update_post_meta( $shipment_post_id, Schema::META_SHIPMENT_SIZE_BAND, sanitize_key( $max_size_band ) );
            update_post_meta( $shipment_post_id, Schema::META_SHIPMENT_WEIGHT_BAND, sanitize_key( $shipment_weight_band ) );

            // Support metas for richer downstream decisions without breaking existing readers.
            update_post_meta( $shipment_post_id, '_cc_shipment_total_weight', round( $total_weight_kg, 3 ) );
            update_post_meta( $shipment_post_id, '_cc_shipment_dim_weight', round( $total_dim_weight_kg, 3 ) );
            update_post_meta( $shipment_post_id, '_cc_shipment_effective_weight', round( $total_effective_weight_kg, 3 ) );
            update_post_meta( $shipment_post_id, '_cc_shipment_longest_side_cm', round( $max_longest_side_cm, 3 ) );
            update_post_meta( $shipment_post_id, '_cc_shipment_volume_cm3', round( $total_volume_cm3, 3 ) );
            update_post_meta( $shipment_post_id, '_cc_shipment_total_weight_source', 'item_truth' );
            update_post_meta( $shipment_post_id, '_cc_shipment_total_units', intval( $total_units ) );
            update_post_meta( $shipment_post_id, '_cc_shipment_legacy_weight_band', sanitize_key( (string) $legacy_weight_band ) );
            update_post_meta( $shipment_post_id, '_cc_shipment_oversize', $shipment_oversize ? '1' : '0' );
            update_post_meta( $shipment_post_id, '_cc_shipment_recommended_vehicle', sanitize_key( $recommended_vehicle ) );
            update_post_meta( $shipment_post_id, '_cc_shipment_in_house_only', '0' );
            delete_post_meta( $shipment_post_id, Schema::META_SHIPMENT_INHOUSE_REQUIRED );
            delete_post_meta( $shipment_post_id, Schema::META_SHIPMENT_INHOUSE_REASON );
            delete_post_meta( $shipment_post_id, '_cc_shipment_inhouse_required' );
            delete_post_meta( $shipment_post_id, '_cc_shipment_inhouse_reason' );

           // ETA/SLA: compute now (safe; doesn’t dispatch)
            self::recompute_eta_sla( $shipment_post_id, array(
                'event'    => 'created',
                'order_id' => $order->get_id(),
                'vendor_id'=> $vendor_id,
            ) );

            // Pricing planner quote: write canonical shipment quote now that coords/meta exist.
            self::maybe_write_pricing_planner_quote( $shipment_post_id, $order->get_id(), $vendor_id );

            // Lifecycle actions
            do_action( 'cc_shipment_created', $shipment_post_id, $order->get_id(), $vendor_id );
            
            // Do NOT unlock Dispatcher here.
            do_action( 'cc_shipment_pending_vendor_ready', $shipment_post_id, $order->get_id(), $vendor_id );
        }
    }

    /* ---------------------------------------------------------------------
     * VENDOR GATE: MARK READY FOR PICKUP
     * ------------------------------------------------------------------ */

    public static function vendor_mark_ready_for_pickup( $shipment_id, $vendor_id, array $context = array() ) : bool {
        $shipment_id = intval( $shipment_id );
        $vendor_id   = intval( $vendor_id );

        if ( ! $shipment_id || ! $vendor_id ) {
            return false;
        }

        if ( get_post_type( $shipment_id ) !== 'cc_shipment' ) {
            return false;
        }

        $ship_vendor = intval( get_post_meta( $shipment_id, Schema::META_SHIPMENT_VENDOR_ID, true ) );
        if ( $ship_vendor !== $vendor_id ) {
            return false;
        }

        $old_status = (string) get_post_meta( $shipment_id, Schema::META_SHIPMENT_STATUS, true );
        if ( $old_status === self::STATUS_PENDING_VENDOR_READY ) {
            self::clear_ready_cycle_blockers( $shipment_id );
        }

        $existing_courier = intval( get_post_meta( $shipment_id, Schema::META_SHIPMENT_COURIER_ID, true ) );
        if ( $existing_courier > 0 ) {
            return false;
        }
        $allowed_from = apply_filters(
            'cc_vendor_ready_allowed_from_statuses',
            array( self::STATUS_PENDING_VENDOR_READY ),
            $shipment_id,
            $vendor_id
        );

        if ( ! in_array( $old_status, $allowed_from, true ) ) {
            return false;
        }

        self::set_shipment_status(
            $shipment_id,
            'ready_for_assignment',
            array_merge(
                array(
                    'source'    => 'vendor',
                    'vendor_id' => $vendor_id,
                    'reason'    => 'vendor_mark_ready_for_pickup',
                ),
                $context
            )
        );

        // Recompute now that we are out of vendor gate.
        self::recompute_eta_sla( $shipment_id, array(
            'event'     => 'vendor_ready',
            'vendor_id' => $vendor_id,
        ) );

        delete_post_meta( $shipment_id, Schema::META_SHIPMENT_RESCUE_STATE );

        $order_id = intval( get_post_meta( $shipment_id, Schema::META_SHIPMENT_ORDER_ID, true ) );

        do_action( 'cc_vendor_marked_ready_for_pickup', $shipment_id, $order_id, $vendor_id );
        do_action( 'cc_shipment_ready_for_assignment', $shipment_id, $order_id, $vendor_id );

        return true;
    }

    /* ---------------------------------------------------------------------
     * CANCEL
     * ------------------------------------------------------------------ */

    public static function cancel_shipments_for_order( $order_id, $reason = 'cancelled' ) {
        $shipments = self::get_shipments_for_order( $order_id );
        if ( empty( $shipments ) ) {
            return;
        }

        foreach ( $shipments as $shipment_id ) {
            self::set_shipment_status( $shipment_id, 'cancelled', array( 'order_reason' => $reason ) );
        }
    }

    /* ---------------------------------------------------------------------
     * STATUS MANAGEMENT
     * ------------------------------------------------------------------ */

    public static function set_shipment_status( $shipment_id, $new_status, $context = array() ) {
        $shipment_id = intval( $shipment_id );
        if ( ! $shipment_id ) {
            return;
        }

        $old_status = get_post_meta( $shipment_id, Schema::META_SHIPMENT_STATUS, true );
        $new_status = sanitize_key( (string) $new_status );

        if ( in_array( $new_status, array( 'offered', 'rejected' ), true ) ) {
            $context['operational_status_alias'] = $new_status;
            $new_status = 'ready_for_assignment';
        }

        if ( class_exists( __NAMESPACE__ . '\StatusMachine' ) && ! StatusMachine::is_known_status( $new_status ) ) {
            return;
        }

        if ( $old_status === $new_status ) {
            return;
        }

        update_post_meta( $shipment_id, Schema::META_SHIPMENT_STATUS, $new_status );

        $now_utc = current_time( 'mysql', true );
        update_post_meta( $shipment_id, Schema::META_SHIPMENT_LAST_STATUS_CHANGE_AT, $now_utc );

        $hub_like_statuses = apply_filters( 'cc_core_hub_statuses', array( 'hub_received', 'in_hub_storage' ) );

        if ( in_array( $new_status, $hub_like_statuses, true ) ) {
            $existing_hub_ts = get_post_meta( $shipment_id, Schema::META_SHIPMENT_HUB_RECEIVED_AT, true );

            if ( ! $existing_hub_ts ) {
                update_post_meta( $shipment_id, Schema::META_SHIPMENT_HUB_RECEIVED_AT, $now_utc );

                $expires_ts = apply_filters(
                    'cc_core_hub_storage_expires_ts',
                    strtotime( '+30 days', current_time( 'timestamp', true ) ),
                    $shipment_id,
                    $new_status,
                    $context
                );

                if ( $expires_ts ) {
                    update_post_meta(
                        $shipment_id,
                        Schema::META_SHIPMENT_STORAGE_EXPIRES_AT,
                        gmdate( 'Y-m-d H:i:s', $expires_ts )
                    );
                }
            }

            update_post_meta( $shipment_id, Schema::META_SHIPMENT_IN_HUB_STORAGE, 'yes' );
        }

        $non_hub_statuses = apply_filters(
            'cc_core_non_hub_statuses',
            array(
                self::STATUS_PENDING_VENDOR_READY,
                'ready_for_assignment',
                'assigned',
                'picked_up',
                'in_transit',
                'out_for_redelivery_day1',
                'paid_redelivery_pending_confirmation',
                'paid_redelivery_ready_for_dispatch',
                'paid_redelivery_failed_unreachable',
                'delivered',
                'returned',
                'cancelled',
                'abandoned_by_customer',
                'resolution_completed',
            )
        );

        if ( in_array( $new_status, $non_hub_statuses, true ) ) {
            update_post_meta( $shipment_id, Schema::META_SHIPMENT_IN_HUB_STORAGE, 'no' );
        }

        do_action( 'cc_shipment_status_changed', $shipment_id, $old_status, $new_status, $context );
    }

    protected static function get_courier_vehicle_type( $courier_id ) {
        $courier_id = intval( $courier_id );
        if ( ! $courier_id ) {
            return '';
        }

        if ( class_exists( '\Caricove\Logistics\Core\CourierProfile' ) && method_exists( '\Caricove\Logistics\Core\CourierProfile', 'get_profile' ) ) {
            $profile = \Caricove\Logistics\Core\CourierProfile::get_profile( $courier_id );
            if ( is_array( $profile ) && ! empty( $profile['vehicle_type'] ) ) {
                return sanitize_key( (string) $profile['vehicle_type'] );
            }
        }

        $vehicle = '';
        if ( class_exists( '\Caricove\Logistics\Core\CourierProfile' ) && defined( '\Caricove\Logistics\Core\CourierProfile::META_VEHICLE_TYPE' ) ) {
            $vehicle = (string) get_user_meta( $courier_id, \Caricove\Logistics\Core\CourierProfile::META_VEHICLE_TYPE, true );
        }

        if ( '' === $vehicle ) {
            $vehicle = (string) get_user_meta( $courier_id, '_caricove_courier_vehicle_type', true );
        }

        if ( '' === $vehicle ) {
            $vehicle = (string) get_user_meta( $courier_id, '_cc_vehicle_type', true );
        }

        return sanitize_key( $vehicle );
    }

    protected static function get_courier_capacity_class( $courier_id ) {
        $courier_id = intval( $courier_id );
        if ( ! $courier_id ) {
            return '';
        }

        if ( class_exists( '\Caricove\Logistics\Core\CourierProfile' ) && method_exists( '\Caricove\Logistics\Core\CourierProfile', 'get_profile' ) ) {
            $profile = \Caricove\Logistics\Core\CourierProfile::get_profile( $courier_id );
            if ( is_array( $profile ) && ! empty( $profile['capacity_class'] ) ) {
                return sanitize_key( (string) $profile['capacity_class'] );
            }
        }

        $capacity = '';
        if ( class_exists( '\Caricove\Logistics\Core\CourierProfile' ) && defined( '\Caricove\Logistics\Core\CourierProfile::META_CAPACITY_CLASS' ) ) {
            $capacity = (string) get_user_meta( $courier_id, \Caricove\Logistics\Core\CourierProfile::META_CAPACITY_CLASS, true );
        }

        if ( '' === $capacity ) {
            $capacity = (string) get_user_meta( $courier_id, '_caricove_courier_capacity', true );
        }

        if ( '' === $capacity ) {
            $capacity = (string) get_user_meta( $courier_id, '_cc_capacity_class', true );
        }

        return sanitize_key( $capacity );
    }

    /* ---------------------------------------------------------------------
     * SUMMARY & QUERIES
     * ------------------------------------------------------------------ */

    public static function get_shipment_summary( $shipment_id ) {
        $shipment_id = intval( $shipment_id );
        if ( ! $shipment_id ) {
            return array();
        }

        $quote_breakdown = self::read_quote_breakdown( $shipment_id );
        $normalized_route = self::normalize_route_truth( $shipment_id, $quote_breakdown );

        $declined_couriers = get_post_meta( $shipment_id, Schema::META_SHIPMENT_DECLINED_COURIERS, true );
        if ( ! is_array( $declined_couriers ) ) {
            $declined_couriers = array();
        }
        $declined_couriers = array_values( array_unique( array_filter( array_map( 'intval', $declined_couriers ) ) ) );

        $distance_band = sanitize_key( (string) ( $normalized_route['distance_band'] ?? '' ) );
        $trip_band_raw = sanitize_key( (string) ( $quote_breakdown['trip_band'] ?? '' ) );
        $trip_band = sanitize_key( (string) ( $normalized_route['trip_band'] ?? $distance_band ) );

        $meta = array(
            'shipment_id'         => $shipment_id,

            'type'               => get_post_meta( $shipment_id, Schema::META_SHIPMENT_TYPE, true ),
            'status'             => get_post_meta( $shipment_id, Schema::META_SHIPMENT_STATUS, true ),
            'order_id'           => intval( get_post_meta( $shipment_id, Schema::META_SHIPMENT_ORDER_ID, true ) ),
            'vendor_id'          => intval( get_post_meta( $shipment_id, Schema::META_SHIPMENT_VENDOR_ID, true ) ),

            'pickup_address'     => json_decode( get_post_meta( $shipment_id, Schema::META_SHIPMENT_PICKUP_ADDRESS, true ), true ),
            'dropoff_address'    => json_decode( get_post_meta( $shipment_id, Schema::META_SHIPMENT_DROPOFF_ADDRESS, true ), true ),
            'pickup_coords'      => get_post_meta( $shipment_id, Schema::META_SHIPMENT_PICKUP_COORDS, true ),
            'dropoff_coords'     => get_post_meta( $shipment_id, Schema::META_SHIPMENT_DROPOFF_COORDS, true ),

            'pickup_name'        => get_post_meta( $shipment_id, Schema::META_SHIPMENT_PICKUP_NAME, true ),
            'pickup_phone'       => get_post_meta( $shipment_id, Schema::META_SHIPMENT_PICKUP_PHONE, true ),
            'dropoff_name'       => get_post_meta( $shipment_id, Schema::META_SHIPMENT_DROPOFF_NAME, true ),
            'dropoff_phone'      => get_post_meta( $shipment_id, Schema::META_SHIPMENT_DROPOFF_PHONE, true ),
            'dropoff_instructions' => (string) ( get_post_meta( $shipment_id, '_cc_shipment_delivery_instructions', true ) ?: get_post_meta( $shipment_id, '_cc_dropoff_delivery_instructions', true ) ),

            'item_count'         => intval( get_post_meta( $shipment_id, Schema::META_SHIPMENT_ITEM_COUNT, true ) ),
            'declared_value'     => floatval( get_post_meta( $shipment_id, Schema::META_SHIPMENT_DECLARED_VALUE, true ) ),

            'origin_anchor'      => get_post_meta( $shipment_id, Schema::META_SHIPMENT_ORIGIN_ANCHOR, true ),
            'destination_anchor' => get_post_meta( $shipment_id, Schema::META_SHIPMENT_DEST_ANCHOR, true ),

            'size_band'          => get_post_meta( $shipment_id, Schema::META_SHIPMENT_SIZE_BAND, true ),
            'weight_band'        => get_post_meta( $shipment_id, Schema::META_SHIPMENT_WEIGHT_BAND, true ),
            'total_weight'       => floatval( get_post_meta( $shipment_id, '_cc_shipment_total_weight', true ) ),
            'dim_weight'         => floatval( get_post_meta( $shipment_id, '_cc_shipment_dim_weight', true ) ),
            'effective_weight'   => floatval( get_post_meta( $shipment_id, '_cc_shipment_effective_weight', true ) ),
            'longest_side_cm'    => floatval( get_post_meta( $shipment_id, '_cc_shipment_longest_side_cm', true ) ),
            'volume_cm3'         => floatval( get_post_meta( $shipment_id, '_cc_shipment_volume_cm3', true ) ),
            'total_weight_source'=> sanitize_key( (string) get_post_meta( $shipment_id, '_cc_shipment_total_weight_source', true ) ),
            'total_units'        => intval( get_post_meta( $shipment_id, '_cc_shipment_total_units', true ) ),
            'oversize'           => get_post_meta( $shipment_id, '_cc_shipment_oversize', true ),
            'recommended_vehicle'=> get_post_meta( $shipment_id, '_cc_shipment_recommended_vehicle', true ),
            'in_house_only'      => '0',
            'vehicle_type'       => (string) ( get_post_meta( $shipment_id, '_cc_shipment_vehicle_type', true ) ?: get_post_meta( $shipment_id, '_cc_assigned_vehicle_type', true ) ),
            'assigned_vehicle_type' => (string) ( get_post_meta( $shipment_id, '_cc_shipment_vehicle_type', true ) ?: get_post_meta( $shipment_id, '_cc_assigned_vehicle_type', true ) ),
            'capacity_class'     => (string) ( get_post_meta( $shipment_id, '_cc_shipment_capacity_class', true ) ?: get_post_meta( $shipment_id, '_cc_assigned_capacity_class', true ) ),
            'assigned_capacity_class' => (string) ( get_post_meta( $shipment_id, '_cc_shipment_capacity_class', true ) ?: get_post_meta( $shipment_id, '_cc_assigned_capacity_class', true ) ),

            'courier_id'         => intval( get_post_meta( $shipment_id, Schema::META_SHIPMENT_COURIER_ID, true ) ),
            'bundle_id'          => get_post_meta( $shipment_id, Schema::META_SHIPMENT_BUNDLE_ID, true ),
            'bundle_seq'         => intval( get_post_meta( $shipment_id, Schema::META_SHIPMENT_BUNDLE_SEQ, true ) ),
            'assignment_accepted_at' => get_post_meta( $shipment_id, Schema::META_SHIPMENT_ASSIGNMENT_ACCEPTED_AT, true ),

            'eta'                => get_post_meta( $shipment_id, Schema::META_SHIPMENT_ETA, true ),
            'eta_source'         => get_post_meta( $shipment_id, Schema::META_SHIPMENT_ETA_SOURCE, true ),
            'sla_deadline'       => get_post_meta( $shipment_id, Schema::META_SHIPMENT_SLA_DEADLINE, true ),
            'sla_risk'           => floatval( get_post_meta( $shipment_id, Schema::META_SHIPMENT_SLA_RISK, true ) ),
            'sla_breached'       => get_post_meta( $shipment_id, Schema::META_SHIPMENT_SLA_BREACHED, true ),

            'telemetry_excluded' => get_post_meta( $shipment_id, Schema::META_SHIPMENT_TELEMETRY_EXCLUDED, true ),
            'telemetry_notes'    => get_post_meta( $shipment_id, Schema::META_SHIPMENT_TELEMETRY_NOTES, true ),

            'pickup_code'               => get_post_meta( $shipment_id, Schema::META_SHIPMENT_PICKUP_CODE, true ),
            'pickup_code_verified'      => get_post_meta( $shipment_id, Schema::META_SHIPMENT_PICKUP_CODE_VERIFIED, true ),
            'pickup_code_verified_at'   => get_post_meta( $shipment_id, Schema::META_SHIPMENT_PICKUP_CODE_VERIFIED_AT, true ),

            'delivery_code'             => get_post_meta( $shipment_id, Schema::META_SHIPMENT_DELIVERY_CODE, true ),
            'delivery_code_verified'    => get_post_meta( $shipment_id, Schema::META_SHIPMENT_DELIVERY_CODE_VERIFIED, true ),
            'delivery_code_verified_at' => get_post_meta( $shipment_id, Schema::META_SHIPMENT_DELIVERY_CODE_VERIFIED_AT, true ),

            'pod_image_id'              => intval( get_post_meta( $shipment_id, Schema::META_SHIPMENT_POD_IMAGE_ID, true ) ),
            'pod_notes'                 => get_post_meta( $shipment_id, Schema::META_SHIPMENT_POD_NOTES, true ),

            'in_hub_storage'        => get_post_meta( $shipment_id, Schema::META_SHIPMENT_IN_HUB_STORAGE, true ),
            'hub_received_at'       => get_post_meta( $shipment_id, Schema::META_SHIPMENT_HUB_RECEIVED_AT, true ),
            'storage_expires_at'    => get_post_meta( $shipment_id, Schema::META_SHIPMENT_STORAGE_EXPIRES_AT, true ),

            'free_redelivery_used'  => get_post_meta( $shipment_id, Schema::META_SHIPMENT_FREE_REDELIVERY_USED, true ),
            'paid_redelivery_count' => intval( get_post_meta( $shipment_id, Schema::META_SHIPMENT_PAID_REDELIVERY_COUNT, true ) ),

            'contact_cycle_day'       => intval( get_post_meta( $shipment_id, Schema::META_SHIPMENT_CONTACT_CYCLE_DAY, true ) ),
            'contact_attempts_today'  => intval( get_post_meta( $shipment_id, Schema::META_SHIPMENT_CONTACT_ATTEMPTS_TODAY, true ) ),
            'contact_last_attempt_at' => get_post_meta( $shipment_id, Schema::META_SHIPMENT_CONTACT_LAST_ATTEMPT_AT, true ),
            'contact_last_outcome'    => get_post_meta( $shipment_id, Schema::META_SHIPMENT_CONTACT_LAST_OUTCOME, true ),
            'contact_total_attempts'  => intval( get_post_meta( $shipment_id, Schema::META_SHIPMENT_CONTACT_TOTAL_ATTEMPTS, true ) ),

            'last_status_change_at'   => get_post_meta( $shipment_id, Schema::META_SHIPMENT_LAST_STATUS_CHANGE_AT, true ),

            'safety_flag'       => get_post_meta( $shipment_id, Schema::META_SHIPMENT_SAFETY_FLAG, true ),
            'safety_reason'     => get_post_meta( $shipment_id, Schema::META_SHIPMENT_SAFETY_REASON, true ),
            'safety_flagged_at' => get_post_meta( $shipment_id, Schema::META_SHIPMENT_SAFETY_FLAGGED_AT, true ),

            'rescue_state'      => get_post_meta( $shipment_id, Schema::META_SHIPMENT_RESCUE_STATE, true ),
            'rescue_courier_id' => intval( get_post_meta( $shipment_id, Schema::META_SHIPMENT_RESCUE_COURIER_ID, true ) ),
            'rescue_started_at' => get_post_meta( $shipment_id, Schema::META_SHIPMENT_RESCUE_STARTED_AT, true ),
            'rescue_expires_at' => get_post_meta( $shipment_id, Schema::META_SHIPMENT_RESCUE_EXPIRES_AT, true ),
            'rescue_reason'     => get_post_meta( $shipment_id, Schema::META_SHIPMENT_RESCUE_REASON, true ),
            'rescue_log'        => get_post_meta( $shipment_id, Schema::META_SHIPMENT_RESCUE_LOG, true ),

            'offer_created_at'      => intval( get_post_meta( $shipment_id, Schema::META_SHIPMENT_OFFER_CREATED_AT, true ) ),
            'offer_expires_at'      => intval( get_post_meta( $shipment_id, Schema::META_SHIPMENT_OFFER_EXPIRES_AT, true ) ),
            'offer_courier_id'      => intval( get_post_meta( $shipment_id, Schema::META_SHIPMENT_OFFER_COURIER_ID, true ) ),
            'offer_response_window' => intval( get_post_meta( $shipment_id, Schema::META_SHIPMENT_OFFER_RESPONSE_WINDOW, true ) ),
            'offer_last_timeout_at' => get_post_meta( $shipment_id, Schema::META_SHIPMENT_OFFER_LAST_TIMEOUT_AT, true ),
            'offer_last_reject_at'  => get_post_meta( $shipment_id, Schema::META_SHIPMENT_OFFER_LAST_REJECT_AT, true ),
            'offer_last_reject_courier_id' => intval( get_post_meta( $shipment_id, Schema::META_SHIPMENT_OFFER_LAST_REJECT_COURIER, true ) ),
            'declined_couriers'     => $declined_couriers,

            'quote_total_gyd'        => floatval( $normalized_route['quote_total_gyd'] ?? 0 ),
            'quote_distance_km'      => floatval( $normalized_route['distance_km'] ?? 0 ),
            'quote_duration_seconds' => intval( $normalized_route['duration_seconds'] ?? 0 ),
            'route_distance_km'      => floatval( $normalized_route['distance_km'] ?? 0 ),
            'route_duration_seconds' => intval( $normalized_route['duration_seconds'] ?? 0 ),
            'trip_band'              => $trip_band,
            'trip_band_raw'          => $trip_band_raw,
            'distance_band'          => $distance_band,
            'route_source'           => sanitize_key( (string) ( $normalized_route['route_source'] ?? '' ) ),
            'route_detail_source'    => sanitize_key( (string) ( $normalized_route['route_detail_source'] ?? '' ) ),
            'route_provenance'       => sanitize_key( (string) ( $normalized_route['route_provenance'] ?? '' ) ),
            'planner_has_truth'      => ! empty( $normalized_route['planner_has_truth'] ),
            'route_fallback_used'    => ! empty( $normalized_route['fallback_used'] ),
            'quote_breakdown'        => $quote_breakdown,
        );

        $meta['inhouse_required'] = '';
        $meta['inhouse_reason']   = '';
        $meta['in_house_only']    = '0';

        if ( empty( $meta['total_weight'] ) || empty( $meta['weight_band'] ) || empty( $meta['size_band'] ) ) {
            $backfill = self::backfill_shipment_physical_truth_from_order( $shipment_id );
            if ( ! empty( $backfill['size_band'] ) ) {
                $meta['size_band'] = sanitize_key( (string) $backfill['size_band'] );
            }
            if ( ! empty( $backfill['weight_band'] ) ) {
                $meta['weight_band'] = sanitize_key( (string) $backfill['weight_band'] );
            }
            if ( isset( $backfill['total_weight'] ) ) {
                $meta['total_weight'] = max( 0.0, floatval( $backfill['total_weight'] ) );
            }
            if ( isset( $backfill['dim_weight'] ) ) {
                $meta['dim_weight'] = max( 0.0, floatval( $backfill['dim_weight'] ) );
            }
            if ( isset( $backfill['effective_weight'] ) ) {
                $meta['effective_weight'] = max( 0.0, floatval( $backfill['effective_weight'] ) );
            }
            if ( isset( $backfill['longest_side_cm'] ) ) {
                $meta['longest_side_cm'] = max( 0.0, floatval( $backfill['longest_side_cm'] ) );
            }
            if ( isset( $backfill['volume_cm3'] ) ) {
                $meta['volume_cm3'] = max( 0.0, floatval( $backfill['volume_cm3'] ) );
            }
            if ( ! empty( $backfill['weight_source'] ) ) {
                $meta['total_weight_source'] = sanitize_key( (string) $backfill['weight_source'] );
            }
        }

        if ( empty( $meta['effective_weight'] ) ) {
            $meta['effective_weight'] = max( floatval( $meta['total_weight'] ?? 0 ), floatval( $meta['dim_weight'] ?? 0 ) );
        }

        if ( empty( $meta['total_weight'] ) && ! empty( $meta['weight_band'] ) ) {
            $meta['total_weight'] = self::representative_weight_kg_for_band( $meta['weight_band'] );
            if ( ! empty( $meta['total_weight'] ) ) {
                $meta['total_weight_source'] = 'band_representative';
            }
        }
        if ( empty( $meta['effective_weight'] ) && ! empty( $meta['weight_band'] ) ) {
            $meta['effective_weight'] = self::representative_weight_kg_for_band( $meta['weight_band'] );
        }

        if ( class_exists( '\Caricove\Logistics\Core\ZoneResolver' ) ) {
            $meta['recommended_vehicle'] = ZoneResolver::normalize_vehicle_type( (string) ( $meta['recommended_vehicle'] ?? '' ) );
        }

        $courier_id = intval( $meta['courier_id'] ?? 0 );
        if ( $courier_id > 0 && class_exists( '\Caricove\Logistics\Core\CourierProfile' ) ) {
            $courier_profile = CourierProfile::get_profile( $courier_id );
            if ( is_array( $courier_profile ) ) {
                $meta['courier_last_lat'] = isset( $courier_profile['last_lat'] ) ? floatval( $courier_profile['last_lat'] ) : null;
                $meta['courier_last_lng'] = isset( $courier_profile['last_lng'] ) ? floatval( $courier_profile['last_lng'] ) : null;
                $meta['courier_vehicle_type'] = sanitize_key( (string) ( $courier_profile['vehicle_type'] ?? '' ) );
                $meta['courier_capacity_class'] = sanitize_key( (string) ( $courier_profile['capacity_class'] ?? '' ) );
            }
        }

        return apply_filters( 'cc_shipment_summary', $meta, $shipment_id );
    }

    public static function get_shipments_for_order( $order_id ) {
        $order_id = intval( $order_id );
        if ( ! $order_id ) {
            return array();
        }

        $query = new WP_Query(
            array(
                'post_type'      => 'cc_shipment',
                'post_status'    => 'any',
                'posts_per_page' => -1,
                'post_parent'    => $order_id,
                'fields'         => 'ids',
                'no_found_rows'  => true,
            )
        );

        return $query->posts;
    }

    /* ---------------------------------------------------------------------
     * ASSIGNMENT & ETA
     * ------------------------------------------------------------------ */

    public static function assign_shipment_to_courier( $shipment_id, $courier_id, $context = array() ) {
        $shipment_id = intval( $shipment_id );
        $courier_id  = intval( $courier_id );

        if ( ! $shipment_id || ! $courier_id ) {
            return;
        }

        $vehicle_type   = isset( $context['vehicle_type'] ) ? sanitize_key( (string) $context['vehicle_type'] ) : '';
        $capacity_class = isset( $context['capacity_class'] ) ? sanitize_key( (string) $context['capacity_class'] ) : '';

        if ( '' === $vehicle_type ) {
            $vehicle_type = self::get_courier_vehicle_type( $courier_id );
        }

        if ( '' === $capacity_class ) {
            $capacity_class = self::get_courier_capacity_class( $courier_id );
        }

        if ( '' !== $vehicle_type ) {
            update_post_meta( $shipment_id, '_cc_shipment_vehicle_type', $vehicle_type );
            update_post_meta( $shipment_id, '_cc_assigned_vehicle_type', $vehicle_type );
        }

        if ( '' !== $capacity_class ) {
            update_post_meta( $shipment_id, '_cc_shipment_capacity_class', $capacity_class );
            update_post_meta( $shipment_id, '_cc_assigned_capacity_class', $capacity_class );
        }

        update_post_meta( $shipment_id, Schema::META_SHIPMENT_COURIER_ID, $courier_id );

        if ( ! empty( $context['job_id'] ) ) {
            update_post_meta( $shipment_id, Schema::META_SHIPMENT_JOB_ID, intval( $context['job_id'] ) );
        }

        $new_status = isset( $context['status'] ) ? $context['status'] : 'assigned';

        $context = array_merge(
            $context,
            array(
                'courier_id'     => $courier_id,
                'vehicle_type'   => $vehicle_type,
                'capacity_class' => $capacity_class,
            )
        );

        self::set_shipment_status(
            $shipment_id,
            $new_status,
            $context
        );

        self::clear_operational_offer_meta( $shipment_id );

        self::recompute_eta_sla( $shipment_id, array(
            'event'          => 'assigned',
            'courier_id'     => $courier_id,
            'vehicle_type'   => $vehicle_type,
            'capacity_class' => $capacity_class,
        ) );

        do_action( 'cc_shipment_assigned_to_courier', $shipment_id, $courier_id, $context );
    }

    public static function set_shipment_eta_and_sla( $shipment_id, $eta, $sla_deadline, $risk = 0.0, $source = 'matrix' ) {
        $shipment_id = intval( $shipment_id );
        if ( ! $shipment_id ) {
            return;
        }

        $eta_str = is_numeric( $eta ) ? gmdate( 'c', intval( $eta ) ) : (string) $eta;
        $sla_str = is_numeric( $sla_deadline ) ? gmdate( 'c', intval( $sla_deadline ) ) : (string) $sla_deadline;

        $risk_val = max( 0.0, min( 1.0, floatval( $risk ) ) );

        update_post_meta( $shipment_id, Schema::META_SHIPMENT_ETA, $eta_str );
        update_post_meta( $shipment_id, Schema::META_SHIPMENT_ETA_SOURCE, sanitize_key( $source ) );
        update_post_meta( $shipment_id, Schema::META_SHIPMENT_SLA_DEADLINE, $sla_str );
        update_post_meta( $shipment_id, Schema::META_SHIPMENT_SLA_RISK, $risk_val );

        do_action(
            'cc_shipment_eta_sla_updated',
            $shipment_id,
            array(
                'eta'          => $eta_str,
                'source'       => $source,
                'sla_deadline' => $sla_str,
                'risk'         => $risk_val,
            )
        );
    }

    /* ---------------------------------------------------------------------
     * REDISPATCH HELPER (REGION-BASED)
     * ------------------------------------------------------------------ */

    public static function redispatch_ready_shipments_for_region( $origin_anchor ) {
        $origin_anchor = sanitize_key( $origin_anchor );
        if ( ! $origin_anchor ) {
            return;
        }

        $redispatch_batch = function ( array $shipment_ids ) {
            foreach ( $shipment_ids as $shipment_id ) {
                $shipment_id = intval( $shipment_id );
                if ( ! $shipment_id ) {
                    continue;
                }

                $summary = self::get_shipment_summary( $shipment_id );
                if ( empty( $summary ) ) {
                    continue;
                }

                if ( AutoAssign::maybe_finalize_expired_offer( $shipment_id, 0, $summary ) ) {
                    continue;
                }

                if ( AutoAssign::shipment_has_live_offer( $shipment_id, $summary ) ) {
                    continue;
                }

                $order_id  = ! empty( $summary['order_id'] ) ? intval( $summary['order_id'] ) : 0;
                $vendor_id = ! empty( $summary['vendor_id'] ) ? intval( $summary['vendor_id'] ) : 0;

                do_action( 'cc_shipment_ready_for_assignment', $shipment_id, $order_id, $vendor_id );
            }
        };

        $phase1 = new WP_Query(
            array(
                'post_type'      => 'cc_shipment',
                'post_status'    => 'any',
                'posts_per_page' => 20,
                'fields'         => 'ids',
                'no_found_rows'  => true,
                'meta_query'     => array(
                    'relation' => 'AND',
                    array(
                        'key'   => Schema::META_SHIPMENT_STATUS,
                        'value' => 'ready_for_assignment',
                    ),
                    array(
                        'key'   => Schema::META_SHIPMENT_ORIGIN_ANCHOR,
                        'value' => $origin_anchor,
                    ),
                    array(
                        'key'     => Schema::META_SHIPMENT_COURIER_ID,
                        'value'   => 0,
                        'compare' => '=',
                    ),
                ),
            )
        );

        $phase1_ids = $phase1->have_posts() ? array_map( 'intval', $phase1->posts ) : array();
        if ( ! empty( $phase1_ids ) ) {
            $redispatch_batch( $phase1_ids );
            return;
        }

        $phase2 = new WP_Query(
            array(
                'post_type'      => 'cc_shipment',
                'post_status'    => 'any',
                'posts_per_page' => 20,
                'fields'         => 'ids',
                'no_found_rows'  => true,
                'meta_query'     => array(
                    'relation' => 'AND',
                    array(
                        'key'   => Schema::META_SHIPMENT_STATUS,
                        'value' => 'ready_for_assignment',
                    ),
                    array(
                        'key'     => Schema::META_SHIPMENT_COURIER_ID,
                        'value'   => 0,
                        'compare' => '=',
                    ),
                ),
            )
        );

        $phase2_ids = $phase2->have_posts() ? array_map( 'intval', $phase2->posts ) : array();
        if ( ! empty( $phase2_ids ) ) {
            $redispatch_batch( $phase2_ids );
        }
    }
    
    
    protected static function maybe_write_pricing_planner_quote( int $shipment_id, int $order_id = 0, int $vendor_id = 0 ) : void {
    $shipment_id = intval( $shipment_id );
    if ( ! $shipment_id ) {
        return;
    }

    if ( get_post_type( $shipment_id ) !== 'cc_shipment' ) {
        return;
    }

    $pickup_coords  = get_post_meta( $shipment_id, Schema::META_SHIPMENT_PICKUP_COORDS, true );
    $dropoff_coords = get_post_meta( $shipment_id, Schema::META_SHIPMENT_DROPOFF_COORDS, true );

    $has_pickup  = is_string( $pickup_coords ) && strpos( $pickup_coords, ',' ) !== false;
    $has_dropoff = is_string( $dropoff_coords ) && strpos( $dropoff_coords, ',' ) !== false;

    if ( ! $has_pickup || ! $has_dropoff ) {
        return;
    }

    $existing_quote = floatval( get_post_meta( $shipment_id, '_cc_cp_quote_total_gyd', true ) );
    if ( $existing_quote > 0 ) {
        return;
    }

    try {
        $quoted = null;

        if ( class_exists( 'CC_CP_Engine' ) && method_exists( 'CC_CP_Engine', 'quote_for_shipment' ) ) {
            $quoted = \CC_CP_Engine::quote_for_shipment( $shipment_id );
        } elseif ( class_exists( 'CC_CP_Pricing_Engine' ) && method_exists( 'CC_CP_Pricing_Engine', 'quote_for_shipment' ) ) {
            $quoted = \CC_CP_Pricing_Engine::quote_for_shipment( $shipment_id );
        }

        do_action(
            'cc_shipment_pricing_quote_attempted',
            $shipment_id,
            $order_id,
            $vendor_id,
            $quoted
        );

        self::recompute_eta_sla( $shipment_id, array(
            'event' => 'cc_cp_quote_refreshed',
        ) );
    } catch ( \Throwable $e ) {
        update_post_meta( $shipment_id, '_cc_cp_quote_error', sanitize_text_field( $e->getMessage() ) );
        update_post_meta( $shipment_id, '_cc_cp_quote_error_at', current_time( 'mysql', true ) );

        do_action(
            'cc_shipment_pricing_quote_failed',
            $shipment_id,
            $order_id,
            $vendor_id,
            $e->getMessage()
        );
    }
}
    
    
    
    
    
    
    
    
    
    

    /* ---------------------------------------------------------------------
     * INTERNAL HELPERS
     * ------------------------------------------------------------------ */

    protected static function build_pickup_address_from_order( WC_Order $order ) {
        $base = array(
            'street'  => get_option( 'woocommerce_store_address' ),
            'village' => '',
            'city'    => get_option( 'woocommerce_store_city' ),
            'region'  => get_option( 'woocommerce_default_country' ),
        );

        return apply_filters( 'cc_pickup_address_for_order', $base, $order );
    }

    protected static function build_dropoff_address_from_order( WC_Order $order ) {
        $canonical = array(
            'street'    => (string) $order->get_meta( '_cc_dropoff_address_1', true ),
            'street_2'  => (string) $order->get_meta( '_cc_dropoff_address_2', true ),
            'village'   => '',
            'city'      => (string) $order->get_meta( '_cc_dropoff_city', true ),
            'region'    => (string) $order->get_meta( '_cc_dropoff_state', true ),
            'postcode'  => (string) $order->get_meta( '_cc_dropoff_postcode', true ),
            'country'   => (string) ( $order->get_meta( '_cc_dropoff_country_name', true ) ?: $order->get_meta( '_cc_dropoff_country', true ) ),
        );

        if ( ! array_filter( $canonical ) ) {
            $display = trim( (string) $order->get_meta( '_cc_dropoff_display_address', true ) );
            if ( $display === '' ) {
                $display = trim( (string) $order->get_meta( '_cc_dropoff_formatted_address', true ) );
            }

            if ( $display !== '' ) {
                $canonical['street'] = $display;
            }
        }

        if ( array_filter( $canonical ) ) {
            return apply_filters( 'cc_dropoff_address_for_order', $canonical, $order );
        }

        $shipping = array(
            'street'    => $order->get_shipping_address_1(),
            'street_2'  => $order->get_shipping_address_2(),
            'village'   => '',
            'city'      => $order->get_shipping_city(),
            'region'    => $order->get_shipping_state(),
            'postcode'  => $order->get_shipping_postcode(),
            'country'   => $order->get_shipping_country(),
        );

        if ( empty( $shipping['street'] ) && empty( $shipping['city'] ) ) {
            $shipping['street']   = $order->get_billing_address_1();
            $shipping['street_2'] = $order->get_billing_address_2();
            $shipping['city']     = $order->get_billing_city();
            $shipping['region']   = $order->get_billing_state();
            $shipping['postcode'] = $order->get_billing_postcode();
            $shipping['country']  = $order->get_billing_country();
        }

        return apply_filters( 'cc_dropoff_address_for_order', $shipping, $order );
    }

    protected static function get_pickup_contact_name_from_order( WC_Order $order ) {
        $name = get_option( 'blogname' );
        return apply_filters( 'cc_pickup_contact_name_for_order', $name, $order );
    }

    protected static function get_pickup_contact_phone_from_order( WC_Order $order ) {
        $phone = get_option( 'cc_store_phone', '' );
        return apply_filters( 'cc_pickup_contact_phone_from_order', $phone, $order );
    }

    protected static function get_dropoff_delivery_instructions_from_order( WC_Order $order ) {
        $instructions = trim( (string) $order->get_meta( '_cc_dropoff_delivery_instructions', true ) );
        if ( $instructions === '' ) {
            $instructions = trim( (string) $order->get_meta( '_cc_delivery_instructions', true ) );
        }

        return apply_filters( 'cc_dropoff_delivery_instructions_for_order', sanitize_textarea_field( $instructions ), $order );
    }

    protected static function get_dropoff_contact_name_from_order( WC_Order $order ) {
        $name = trim( $order->get_shipping_first_name() . ' ' . $order->get_shipping_last_name() );
        if ( ! $name ) {
            $name = trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() );
        }

        return apply_filters( 'cc_dropoff_contact_name_for_order', $name, $order );
    }

    protected static function get_dropoff_contact_phone_from_order( WC_Order $order ) {
        $phone = $order->get_billing_phone();
        return apply_filters( 'cc_dropoff_contact_phone_from_order', $phone, $order );
    }

    public static function bundle_shipments( array $shipment_ids ) {
        $shipment_ids = array_values( array_unique( array_filter( array_map( 'intval', $shipment_ids ) ) ) );
        if ( count( $shipment_ids ) < 2 ) {
            return '';
        }

        $bundle_id = 'bundle_' . wp_generate_uuid4();
        $seq = 1;

        foreach ( $shipment_ids as $shipment_id ) {
            update_post_meta( $shipment_id, Schema::META_SHIPMENT_BUNDLE_ID, $bundle_id );
            update_post_meta( $shipment_id, Schema::META_SHIPMENT_BUNDLE_SEQ, $seq );
            $seq++;
        }

        do_action( 'cc_shipment_bundle_updated', $bundle_id, $shipment_ids );

        return $bundle_id;
    }


    /* ---------------------------------------------------------------------
     * ETA/SLA recompute with Telemetry hooks (POLICY-SYNCED)
     * ------------------------------------------------------------------ */

    protected static function recompute_eta_sla( int $shipment_id, array $context = array() ) : void {
        if ( $shipment_id <= 0 ) {
            return;
        }

        $summary = self::get_shipment_summary( $shipment_id );
        if ( empty( $summary ) ) {
            return;
        }

        $origin = (string) ( $summary['origin_anchor'] ?? '' );
        $dest   = (string) ( $summary['destination_anchor'] ?? '' );
        $status = (string) ( $summary['status'] ?? '' );

        // Vendor-gate mode: represent waiting/handling (not drive-time).
        $vendor_gate_locked = ( $status === self::STATUS_PENDING_VENDOR_READY );

        if ( $vendor_gate_locked ) {
            $eta_minutes = (float) apply_filters(
                'cc_core_eta_vendor_gate_minutes',
                1440.0, // 24 hours
                $shipment_id,
                $summary,
                $context
            );

            $sla_after_eta_minutes = (float) apply_filters(
                'cc_core_sla_minutes_after_eta_vendor_gate',
                180.0, // 3 hours buffer
                $shipment_id,
                $summary,
                array( 'eta_minutes' => $eta_minutes )
            );

            $payload = array(
                'eta_minutes'           => (float) $eta_minutes,
                'sla_after_eta_minutes' => (float) $sla_after_eta_minutes,
                'source'                => 'vendor_gate',
                'vendor_gate_locked'    => true,
            );

            // Allow telemetry to *hint* via payload, but default policy is LOCKED unless explicitly enabled.
            $payload_filtered = apply_filters(
                'cc_core_eta_sla_payload',
                $payload,
                $shipment_id,
                $summary,
                $context
            );

            $allow_override = (bool) apply_filters(
                'cc_core_allow_eta_override_while_vendor_gate',
                false,
                $shipment_id,
                $summary,
                $context,
                $payload_filtered
            );

            if ( $allow_override ) {
                $eta_minutes           = (float) ( $payload_filtered['eta_minutes'] ?? $eta_minutes );
                $sla_after_eta_minutes = (float) ( $payload_filtered['sla_after_eta_minutes'] ?? $sla_after_eta_minutes );
            } else {
                // If telemetry tried to set something, keep a lightweight breadcrumb for observability.
                if ( isset( $payload_filtered['source'] ) && $payload_filtered['source'] !== 'vendor_gate' ) {
                    $note = 'Vendor gate locked; external ETA payload ignored.';
                    $existing = (string) get_post_meta( $shipment_id, Schema::META_SHIPMENT_TELEMETRY_NOTES, true );
                    update_post_meta(
                        $shipment_id,
                        Schema::META_SHIPMENT_TELEMETRY_NOTES,
                        trim( $existing . "\n" . $note )
                    );
                }
            }

            $now    = time();
            $eta_ts = $now + (int) round( $eta_minutes * 60 );
            $sla_ts = $now + (int) round( ( $eta_minutes + $sla_after_eta_minutes ) * 60 );

            // While vendor-gated, do not score courier risk.
            $risk = 0.0;

            // ✅ Policy sync: eta_source MUST remain vendor_gate while locked (never telemetry_blend).
            self::set_shipment_eta_and_sla(
                $shipment_id,
                $eta_ts,
                $sla_ts,
                $risk,
                'vendor_gate'
            );

            return;
        }

        // Normal mode (post-vendor-gate): prefer cc_cp intelligence when enabled, otherwise core baseline + telemetry hooks.
        $dispatcher_settings = class_exists( '\Caricove\Logistics\Dispatcher\Settings' ) ? \Caricove\Logistics\Dispatcher\Settings::get_settings() : array();
        $eta_source = sanitize_key( (string) ( $dispatcher_settings['eta_source'] ?? 'legacy_dispatcher' ) );
        $use_cc_cp_eta = ( $eta_source === 'cc_cp' ) && ! empty( $dispatcher_settings['use_cc_cp_duration_for_eta'] );
        $use_cc_cp_sla = ( $eta_source === 'cc_cp' ) && ! empty( $dispatcher_settings['use_cc_cp_duration_for_sla'] );

        $cc_cp_duration_seconds = intval( get_post_meta( $shipment_id, '_cc_cp_quote_duration_seconds', true ) );
        $cc_cp_duration_seconds = max( 0, $cc_cp_duration_seconds );
        if ( ( $use_cc_cp_eta || $use_cc_cp_sla ) && $cc_cp_duration_seconds > 0 ) {
            $pickup_buffer = max( 0, intval( $dispatcher_settings['pickup_approach_buffer_minutes'] ?? 5 ) );
            $eta_buffer    = max( 0, intval( $dispatcher_settings['eta_operational_buffer_minutes'] ?? 5 ) );
            $sla_buffer    = max( 0, intval( $dispatcher_settings['sla_extra_buffer_minutes'] ?? 10 ) );

            $now = time();
            $eta_ts = $now + ( $cc_cp_duration_seconds ) + ( ( $pickup_buffer + $eta_buffer ) * 60 );
            $sla_ts = $eta_ts + ( $sla_buffer * 60 );

            self::set_shipment_eta_and_sla( $shipment_id, $eta_ts, $sla_ts, 0.0, 'cc_cp' );
            return;
        }

        if ( $origin !== '' && $origin === $dest ) {
            $eta_minutes = 15.0;
        } elseif ( $origin !== '' && $dest !== '' ) {
            $eta_minutes = 35.0;
        } else {
            $eta_minutes = 45.0;
        }

        $w = (string) ( $summary['weight_band'] ?? '' );
        if ( $w === 'heavy' ) {
            $eta_minutes += 6.0;
        } elseif ( $w === 'extra_heavy' ) {
            $eta_minutes += 12.0;
        }

        $eta_minutes = (float) apply_filters(
            'cc_core_eta_base_minutes',
            (float) $eta_minutes,
            $shipment_id,
            $summary,
            array( 'origin_anchor' => $origin, 'dest_anchor' => $dest )
        );

        $sla_after_eta_minutes = (float) apply_filters(
            'cc_core_sla_minutes_after_eta',
            10.0,
            $shipment_id,
            $summary,
            array( 'eta_minutes' => $eta_minutes )
        );

        $payload_in = array(
            'eta_minutes'           => (float) $eta_minutes,
            'sla_after_eta_minutes' => (float) $sla_after_eta_minutes,
            'source'                => 'core',
        );

        $payload = apply_filters(
            'cc_core_eta_sla_payload',
            $payload_in,
            $shipment_id,
            $summary,
            $context
        );

        $eta_minutes           = (float) ( $payload['eta_minutes'] ?? $eta_minutes );
        $sla_after_eta_minutes = (float) ( $payload['sla_after_eta_minutes'] ?? $sla_after_eta_minutes );

        $now    = time();
        $eta_ts = $now + (int) round( $eta_minutes * 60 );
        $sla_ts = $now + (int) round( ( $eta_minutes + $sla_after_eta_minutes ) * 60 );

        $risk = 0.0;
        if ( $sla_after_eta_minutes < 8 ) {
            $risk = 0.35;
        }

        self::set_shipment_eta_and_sla(
            $shipment_id,
            $eta_ts,
            $sla_ts,
            $risk,
            isset( $payload['telemetry'] ) ? 'telemetry_blend' : 'core'
        );
    }
}

/**
 * ✅ LOAD ASSURANCE ENTRYPOINT (replaces direct boot()).
 */
ShipmentManager::load_assurance();