<?php
namespace Caricove\Logistics\Core;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * SafetyManager
 *
 * Handles unsafe-delivery flags for shipments and couriers.
 */
class SafetyManager {

    public static function boot() {
        // No automatic hooks yet; manual/API usage only for now.
    }

    /**
     * Flag a shipment as unsafe.
     *
     * @param int    $shipment_id
     * @param int    $courier_id
     * @param string $reason   e.g. unsafe_location, customer_threat, animal_threat
     * @param array  $context  e.g. ['notes' => '...']
     */
    public static function flag_unsafe( $shipment_id, $courier_id, $reason, $context = array() ) {
        $shipment_id = intval( $shipment_id );
        $courier_id  = intval( $courier_id );
        $reason      = sanitize_key( $reason );

        if ( ! $shipment_id || ! $reason ) {
            return;
        }

        $now_mysql = current_time( 'mysql', true );

        // Shipment-level safety.
        update_post_meta( $shipment_id, Schema::META_SHIPMENT_SAFETY_FLAG, 'yes' );
        update_post_meta( $shipment_id, Schema::META_SHIPMENT_SAFETY_REASON, $reason );
        update_post_meta( $shipment_id, Schema::META_SHIPMENT_SAFETY_FLAGGED_AT, $now_mysql );

        // Courier-level safety flag.
        if ( $courier_id ) {
            update_user_meta( $courier_id, Schema::META_COURIER_SAFETY_FLAG, 'yes' );

            $existing_raw = get_user_meta( $courier_id, Schema::META_COURIER_SAFETY_NOTES, true );
            $notes_arr    = array();

            if ( $existing_raw ) {
                $decoded = json_decode( $existing_raw, true );
                if ( is_array( $decoded ) ) {
                    $notes_arr = $decoded;
                }
            }

            $notes_arr[] = array(
                'shipment_id' => $shipment_id,
                'reason'      => $reason,
                'timestamp'   => $now_mysql,
            );

            update_user_meta(
                $courier_id,
                Schema::META_COURIER_SAFETY_NOTES,
                wp_json_encode( $notes_arr )
            );
        }

        // Append to shipment telemetry notes.
        $notes_meta = get_post_meta( $shipment_id, Schema::META_SHIPMENT_TELEMETRY_NOTES, true );
        $notes_list = array();

        if ( is_array( $notes_meta ) ) {
            $notes_list = $notes_meta;
        } elseif ( is_string( $notes_meta ) && $notes_meta !== '' ) {
            $decoded = json_decode( $notes_meta, true );
            if ( is_array( $decoded ) ) {
                $notes_list = $decoded;
            }
        }

        $notes_list[] = array(
            'type'       => 'safety_flag',
            'reason'     => $reason,
            'courier_id' => $courier_id,
            'at'         => $now_mysql,
            'context'    => $context,
        );

        update_post_meta( $shipment_id, Schema::META_SHIPMENT_TELEMETRY_NOTES, $notes_list );

        do_action( 'cc_logistics_safety_flagged', $shipment_id, $courier_id, $reason, $context );
    }

    public static function is_unsafe( $shipment_id ) {
        $flag = get_post_meta( $shipment_id, Schema::META_SHIPMENT_SAFETY_FLAG, true );
        return ( $flag === 'yes' );
    }
}