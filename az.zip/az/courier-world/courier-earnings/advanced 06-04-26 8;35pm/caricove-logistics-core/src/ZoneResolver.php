<?php
namespace Caricove\Logistics\Core;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * ZoneResolver
 *
 * Canonical zone, size, weight, and vehicle-family helpers.
 *
 * This replacement locks the 3-layer logistics universe to the agreed model:
 * - weight bands: light <= 8kg, medium <= 20kg, heavy <= 80kg, extra_heavy > 80kg
 * - vehicle families: motorbike, car, truck
 * - vehicle caps: motorbike 20kg, car 180kg, truck 1500kg
 * - no automatic in-house routing
 * - trucks reserved for extra_heavy missions; numeric cap still protects safety
 */
class ZoneResolver {

    public static function boot() {
        // Reserved for future hooks if needed.
    }

    /* ---------------------------------------------------------------------
     * ZONES / ANCHORS
     * ------------------------------------------------------------------ */

    public static function resolve_pickup_zone( $address_or_coords ) {
        $zones   = Schema::get_zone_definitions();
        $default = 'gt_kingston_hub';

        if ( is_string( $address_or_coords ) && strpos( $address_or_coords, ',' ) !== false ) {
            list( $lat_str, $lng_str ) = array_map( 'trim', explode( ',', $address_or_coords, 2 ) );
            if ( is_numeric( $lat_str ) && is_numeric( $lng_str ) ) {
                $anchor = self::map_coords_to_anchor( floatval( $lat_str ), floatval( $lng_str ), $zones );
                if ( $anchor ) {
                    $default = $anchor;
                }
            }
        }

        return apply_filters( 'cc_resolve_pickup_zone', $default, $address_or_coords, $zones );
    }

    public static function resolve_dropoff_zone( $address_or_coords ) {
        $zones   = Schema::get_zone_definitions();
        $default = 'gt_kingston_hub';

        if ( is_string( $address_or_coords ) && strpos( $address_or_coords, ',' ) !== false ) {
            list( $lat_str, $lng_str ) = array_map( 'trim', explode( ',', $address_or_coords, 2 ) );
            if ( is_numeric( $lat_str ) && is_numeric( $lng_str ) ) {
                $anchor = self::map_coords_to_anchor( floatval( $lat_str ), floatval( $lng_str ), $zones );
                if ( $anchor ) {
                    $default = $anchor;
                }
            }
        }

        return apply_filters( 'cc_resolve_dropoff_zone', $default, $address_or_coords, $zones );
    }

    public static function map_coords_to_anchor_with_distance( $lat, $lng, $zones = null ) {
        $lat = floatval( $lat );
        $lng = floatval( $lng );

        if ( ! $zones ) {
            $zones = Schema::get_zone_definitions();
        }

        $best_key         = 'gt_kingston_hub';
        $best_distance_km = null;

        if ( empty( $zones ) || ! is_array( $zones ) ) {
            return array(
                'anchor'      => $best_key,
                'distance_km' => null,
            );
        }

        $earth_radius_km = 6371.0;

        foreach ( $zones as $key => $zone ) {
            if ( ! isset( $zone['lat'], $zone['lng'] ) ) {
                continue;
            }

            $zlat = floatval( $zone['lat'] );
            $zlng = floatval( $zone['lng'] );

            $d_lat = deg2rad( $lat - $zlat );
            $d_lng = deg2rad( $lng - $zlng );

            $a = sin( $d_lat / 2 ) * sin( $d_lat / 2 )
               + cos( deg2rad( $zlat ) ) * cos( deg2rad( $lat ) )
               * sin( $d_lng / 2 ) * sin( $d_lng / 2 );

            $c   = 2 * atan2( sqrt( $a ), sqrt( 1 - $a ) );
            $d_km = $earth_radius_km * $c;

            if ( null === $best_distance_km || $d_km < $best_distance_km ) {
                $best_distance_km = $d_km;
                $best_key         = $key;
            }
        }

        return array(
            'anchor'      => $best_key,
            'distance_km' => $best_distance_km,
        );
    }

    public static function map_coords_to_anchor( $lat, $lng, $zones = null ) {
        $result = self::map_coords_to_anchor_with_distance( $lat, $lng, $zones );
        return isset( $result['anchor'] ) ? $result['anchor'] : 'gt_kingston_hub';
    }

    /* ---------------------------------------------------------------------
     * SIZE BANDS
     * ------------------------------------------------------------------ */

    public static function normalize_dimensions_desc( $length, $width, $height ) {
        $dims = array(
            max( 0.0, is_numeric( $length ) ? floatval( $length ) : 0.0 ),
            max( 0.0, is_numeric( $width ) ? floatval( $width ) : 0.0 ),
            max( 0.0, is_numeric( $height ) ? floatval( $height ) : 0.0 ),
        );
        rsort( $dims, SORT_NUMERIC );
        return $dims;
    }

    public static function calculate_volume_cm3( $length, $width, $height ) {
        $dims = self::normalize_dimensions_desc( $length, $width, $height );
        return max( 0.0, floatval( $dims[0] * $dims[1] * $dims[2] ) );
    }

    public static function calculate_dimensional_weight_kg( $length, $width, $height, $divisor = 5000 ) {
        $divisor = max( 1.0, floatval( $divisor ) );
        $volume  = self::calculate_volume_cm3( $length, $width, $height );
        if ( $volume <= 0 ) {
            return 0.0;
        }
        return round( $volume / $divisor, 3 );
    }

    public static function calculate_effective_weight_kg( $actual_weight_kg, $length, $width, $height, $divisor = 5000 ) {
        $actual = max( 0.0, floatval( $actual_weight_kg ) );
        $dim    = self::calculate_dimensional_weight_kg( $length, $width, $height, $divisor );
        return max( $actual, $dim );
    }

    public static function get_size_band_bounds( $band ) {
        $band = sanitize_key( (string) $band );
        $map  = array(
            's'  => array( 'label' => 'Small',  'max_longest_cm' => 35.0,  'max_volume_cm3' => 20000.0 ),
            'm'  => array( 'label' => 'Medium', 'max_longest_cm' => 60.0,  'max_volume_cm3' => 80000.0 ),
            'l'  => array( 'label' => 'Large',  'max_longest_cm' => 120.0, 'max_volume_cm3' => 400000.0 ),
            'xl' => array( 'label' => 'XL',     'max_longest_cm' => 300.0, 'max_volume_cm3' => 12000000.0 ),
        );
        return isset( $map[ $band ] ) ? $map[ $band ] : array();
    }

    public static function map_dimensions_to_size_band( $length, $width, $height ) {
        $bands = Schema::get_size_bands();
        $dims  = self::normalize_dimensions_desc( $length, $width, $height );
        list( $d1, $d2, $d3 ) = $dims;
        $volume = self::calculate_volume_cm3( $length, $width, $height );

        if ( $d1 <= 35.0 && $volume <= 20000.0 ) {
            $band = 's';
        } elseif ( $d1 <= 60.0 && $volume <= 80000.0 ) {
            $band = 'm';
        } elseif ( $d1 <= 120.0 && $volume <= 400000.0 ) {
            $band = 'l';
        } else {
            $band = 'xl';
        }

        return apply_filters( 'cc_map_dimensions_to_size_band', $band, $length, $width, $height, $bands );
    }

    /* ---------------------------------------------------------------------
     * WEIGHT BANDS
     * ------------------------------------------------------------------ */

    public static function get_weight_band_rules() {
        $rules = array(
            'light' => array(
                'label'     => 'Light',
                'min_kg'    => 0.0,
                'max_kg'    => 8.0,
                'allowed'   => array( 'motorbike', 'car', 'truck' ),
                'native'    => array( 'motorbike' ),
                'modifiers' => array( 'motorbike' => 0.10, 'car' => 0.00, 'truck' => -0.02 ),
            ),
            'medium' => array(
                'label'     => 'Medium',
                'min_kg'    => 8.0,
                'max_kg'    => 20.0,
                'allowed'   => array( 'motorbike', 'car', 'truck' ),
                'native'    => array( 'motorbike', 'car' ),
                'modifiers' => array( 'motorbike' => 0.05, 'car' => 0.05, 'truck' => -0.02 ),
            ),
            'heavy' => array(
                'label'     => 'Heavy',
                'min_kg'    => 20.0,
                'max_kg'    => 80.0,
                'allowed'   => array( 'car', 'truck' ),
                'native'    => array( 'car' ),
                'modifiers' => array( 'car' => 0.10, 'truck' => 0.04 ),
            ),
            'extra_heavy' => array(
                'label'     => 'Extra Heavy',
                'min_kg'    => 80.0,
                'max_kg'    => null,
                'allowed'   => array( 'truck' ),
                'native'    => array( 'truck' ),
                'modifiers' => array( 'truck' => 0.10 ),
            ),
        );

        return apply_filters( 'cc_weight_band_rules', $rules );
    }

    public static function map_weight_to_band( $weight_kg ) {
        $bands = Schema::get_weight_bands();

        $weight_kg = is_numeric( $weight_kg ) ? floatval( $weight_kg ) : 0.0;
        if ( $weight_kg < 0 ) {
            $weight_kg = 0.0;
        }

        $cutoff_light_max  = apply_filters( 'cc_weight_cutoff_light_max_kg', 8.0,  $weight_kg, $bands );
        $cutoff_medium_max = apply_filters( 'cc_weight_cutoff_medium_max_kg', 20.0, $weight_kg, $bands );
        $cutoff_heavy_max  = apply_filters( 'cc_weight_cutoff_heavy_max_kg', 80.0, $weight_kg, $bands );

        if ( $cutoff_medium_max < $cutoff_light_max ) {
            $cutoff_medium_max = $cutoff_light_max;
        }
        if ( $cutoff_heavy_max < $cutoff_medium_max ) {
            $cutoff_heavy_max = $cutoff_medium_max;
        }

        if ( $weight_kg <= $cutoff_light_max ) {
            $band = 'light';
        } elseif ( $weight_kg <= $cutoff_medium_max ) {
            $band = 'medium';
        } elseif ( $weight_kg <= $cutoff_heavy_max ) {
            $band = 'heavy';
        } else {
            $band = 'extra_heavy';
        }

        return apply_filters( 'cc_map_weight_to_band', $band, $weight_kg, $bands );
    }


    public static function representative_weight_kg_for_band( $band ) {
        $band = sanitize_key( (string) $band );
        switch ( $band ) {
            case 'light':
                return 4.0;
            case 'medium':
                return 14.0;
            case 'heavy':
                return 50.0;
            case 'extra_heavy':
                return 120.0;
            default:
                return 0.0;
        }
    }

    public static function get_weight_band_bounds( $band ) {
        $band = sanitize_key( (string) $band );
        $rules = self::get_weight_band_rules();
        return isset( $rules[ $band ] ) && is_array( $rules[ $band ] ) ? $rules[ $band ] : array();
    }

    /* ---------------------------------------------------------------------
     * VEHICLE / LOAD HELPERS
     * ------------------------------------------------------------------ */

    public static function normalize_vehicle_type( $vehicle ) {
        $vehicle = sanitize_key( (string) $vehicle );

        $map = array(
            'motorbike' => 'motorbike',
            'motorcycle'=> 'motorbike',
            'bike'      => 'motorbike',
            'bicycle'   => 'motorbike',
            'scooter'   => 'motorbike',
            'car'       => 'car',
            'truck'     => 'truck',
            'van'       => 'truck',
            'canter'    => 'truck',
            'lorry'     => 'truck',
            'in_house'  => 'truck',
        );

        return $map[ $vehicle ] ?? $vehicle;
    }

    public static function vehicle_weight_caps() {
        $caps = array(
            'motorbike' => 20.0,
            'car'       => 180.0,
            'truck'     => 1500.0,

            // Legacy aliases -> canonical family caps.
            'motorcycle'=> 20.0,
            'bike'      => 20.0,
            'bicycle'   => 20.0,
            'scooter'   => 20.0,
            'van'       => 1500.0,
            'canter'    => 1500.0,
            'lorry'     => 1500.0,
            'in_house'  => 1500.0,
        );
        return apply_filters( 'cc_vehicle_weight_caps', $caps );
    }

    public static function get_vehicle_weight_cap_kg( $vehicle ) {
        $vehicle = self::normalize_vehicle_type( $vehicle );
        $caps    = self::vehicle_weight_caps();
        return isset( $caps[ $vehicle ] ) ? floatval( $caps[ $vehicle ] ) : 0.0;
    }

    public static function get_vehicle_size_rank_limit( $vehicle ) {
        $vehicle = self::normalize_vehicle_type( $vehicle );
        $map = array(
            'motorbike' => 'm',
            'car'       => 'l',
            'truck'     => 'xl',
        );
        return isset( $map[ $vehicle ] ) ? sanitize_key( (string) $map[ $vehicle ] ) : '';
    }

    public static function is_vehicle_allowed_for_weight_band( $vehicle, $band ) {
        $vehicle = self::normalize_vehicle_type( $vehicle );
        $band    = sanitize_key( (string) $band );
        $bounds  = self::get_weight_band_bounds( $band );
        $allowed = array_map( array( __CLASS__, 'normalize_vehicle_type' ), (array) ( $bounds['allowed'] ?? array() ) );
        return in_array( $vehicle, $allowed, true );
    }

    public static function is_vehicle_native_for_weight_band( $vehicle, $band ) {
        $vehicle = self::normalize_vehicle_type( $vehicle );
        $band    = sanitize_key( (string) $band );
        $bounds  = self::get_weight_band_bounds( $band );
        $native  = array_map( array( __CLASS__, 'normalize_vehicle_type' ), (array) ( $bounds['native'] ?? array() ) );
        return in_array( $vehicle, $native, true );
    }

    public static function get_vehicle_family_modifier_for_weight_band( $vehicle, $band ) {
        $vehicle = self::normalize_vehicle_type( $vehicle );
        $band    = sanitize_key( (string) $band );
        $bounds  = self::get_weight_band_bounds( $band );
        $mods    = is_array( $bounds['modifiers'] ?? null ) ? $bounds['modifiers'] : array();
        return isset( $mods[ $vehicle ] ) ? floatval( $mods[ $vehicle ] ) : 0.0;
    }

    public static function get_max_supported_shipment_weight_kg() {
        return floatval( apply_filters( 'cc_max_supported_shipment_weight_kg', self::get_vehicle_weight_cap_kg( 'truck' ) ) );
    }

    public static function map_size_band_to_units( $size_band ) {
        $size_band = sanitize_key( (string) $size_band );
        $units_map = array(
            'xs' => 1,
            's'  => 1,
            'm'  => 2,
            'l'  => 3,
            'xl' => 4,
        );
        $units = isset( $units_map[ $size_band ] ) ? intval( $units_map[ $size_band ] ) : 2;
        return intval( apply_filters( 'cc_map_size_band_to_units', $units, $size_band, $units_map ) );
    }

    public static function is_oversize_dimensions( $length, $width, $height ) {
        $band = self::map_dimensions_to_size_band( $length, $width, $height );
        $dims = self::normalize_dimensions_desc( $length, $width, $height );
        $volume = self::calculate_volume_cm3( $length, $width, $height );
        $oversize = ( $band === 'xl' || $dims[0] > 120.0 || $volume > 400000.0 );
        return (bool) apply_filters( 'cc_is_oversize_dimensions', $oversize, $length, $width, $height, $dims );
    }

    public static function recommend_vehicle_tier( $effective_weight_kg, $size_band, $total_units = 0, $is_oversize = false ) {
        $effective_weight_kg = is_numeric( $effective_weight_kg ) ? floatval( $effective_weight_kg ) : 0.0;
        $size_band           = sanitize_key( (string) $size_band );
        $total_units         = intval( $total_units );

        $weight_band = self::map_weight_to_band( $effective_weight_kg );

        if ( $is_oversize || $size_band === 'xl' ) {
            $tier = 'truck';
        } elseif ( $weight_band === 'extra_heavy' ) {
            $tier = 'truck';
        } elseif ( $weight_band === 'heavy' ) {
            $tier = 'car';
        } elseif ( in_array( $size_band, array( 's', 'm' ), true ) && $effective_weight_kg <= self::get_vehicle_weight_cap_kg( 'motorbike' ) && $total_units <= 6 ) {
            $tier = 'motorbike';
        } else {
            $tier = 'car';
        }

        return (string) apply_filters( 'cc_recommend_vehicle_tier', $tier, $effective_weight_kg, $size_band, $total_units, $is_oversize, self::vehicle_weight_caps() );
    }


    /* ---------------------------------------------------------------------
     * VALUE BANDS
     * ------------------------------------------------------------------ */

    public static function map_value_to_band( $amount ) {
        $amount = is_numeric( $amount ) ? floatval( $amount ) : 0.0;

        $band = 'low';

        if ( $amount >= 100000 ) {
            $band = 'high';
        } elseif ( $amount >= 20000 ) {
            $band = 'mid';
        }

        return apply_filters( 'cc_map_value_to_band', $band, $amount );
    }
}
