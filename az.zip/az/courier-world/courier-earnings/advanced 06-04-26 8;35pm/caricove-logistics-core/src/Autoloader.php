<?php
/**
 * Caricove Logistics Core - PSR-4 Autoloader
 *
 * Automatically loads all classes under:
 *   Caricove\Logistics\Core\
 *
 * Files must be placed inside /src/ and named according to the class:
 *   Caricove\Logistics\Core\Schema          ->  src/Schema.php
 *   Caricove\Logistics\Core\ShipmentManager ->  src/ShipmentManager.php
 */

namespace Caricove\Logistics\Core;

spl_autoload_register(function($class) {

    // PSR-4 namespace prefix for all core logistics classes
    $prefix = 'Caricove\\Logistics\\Core\\';

    // Only autoload classes from this prefix
    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return; // Not our namespace → skip
    }

    // Convert namespace to relative class name
    $relative = substr($class, $len);

    // Convert namespace separators to folder separators
    $file = __DIR__ . '/' . str_replace('\\', '/', $relative) . '.php';

    // Load the file if it exists
    if (file_exists($file)) {
        require_once $file;
    }
});