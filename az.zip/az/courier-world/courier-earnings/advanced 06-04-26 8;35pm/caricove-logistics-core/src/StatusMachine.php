<?php
namespace Caricove\Logistics\Core;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * StatusMachine
 *
 * Canonical shipment status helpers for the older state universe.
 * Offer / accept / reject / timeout are operational events and markers,
 * not canonical shipment statuses.
 */
class StatusMachine {

    public static function boot() {
        // Reserved for future validation hooks.
    }

    /**
     * Canonical shipment statuses in the preserved pre-expanded universe.
     *
     * @return string[]
     */
    public static function get_known_statuses() {
        $statuses = array(
            // Pre-assignment / intake.
            ShipmentManager::STATUS_PENDING_VENDOR_READY,
            'ready_for_assignment',
            'unassigned',
            'pending_dispatch',
            'needs_assignment',

            // Courier lifecycle.
            'assigned',
            'out_for_delivery',
            'picked_up',
            'in_transit',

            // Hub lifecycle.
            'hub_received',
            'in_hub_storage',

            // Free redelivery.
            'out_for_redelivery_day1',

            // Paid redelivery.
            'paid_redelivery_pending_confirmation',
            'paid_redelivery_ready_for_dispatch',
            'paid_redelivery_failed_unreachable',

            // Final / terminal.
            'delivered',
            'returned',
            'cancelled',
            'abandoned_by_customer',
            'resolution_completed',

            // Manual / legacy operator lanes.
            'hold',
            'hold_no_courier',
            'hold_secure_courier',
            'hold_redispatch',
            'manual',
            'manual_only',
            'inhouse',
        );

        return array_values(
            array_unique(
                array_map(
                    'sanitize_key',
                    apply_filters( 'cc_core_known_shipment_statuses', $statuses )
                )
            )
        );
    }

    /**
     * Shipment statuses that count as operationally occupying a courier.
     *
     * @return string[]
     */
    public static function get_canonical_active_job_statuses() {
        $statuses = array(
            'assigned',
            'out_for_delivery',
            'picked_up',
            'in_transit',
            'out_for_redelivery_day1',
            'paid_redelivery_pending_confirmation',
            'paid_redelivery_ready_for_dispatch',
        );

        return array_values(
            array_unique(
                array_map(
                    'sanitize_key',
                    apply_filters( 'cc_core_active_job_statuses', $statuses )
                )
            )
        );
    }

    /**
     * Terminal shipment statuses.
     *
     * @return string[]
     */
    public static function get_terminal_statuses() {
        $statuses = array(
            'delivered',
            'returned',
            'cancelled',
            'abandoned_by_customer',
            'resolution_completed',
        );

        return array_values(
            array_unique(
                array_map(
                    'sanitize_key',
                    apply_filters( 'cc_core_terminal_shipment_statuses', $statuses )
                )
            )
        );
    }

    /**
     * Is this a known canonical shipment status?
     *
     * @param string $status
     * @return bool
     */
    public static function is_known_status( $status ) {
        $status = sanitize_key( (string) $status );
        return in_array( $status, self::get_known_statuses(), true );
    }

    /**
     * Is this an active courier-occupying shipment status?
     *
     * @param string $status
     * @return bool
     */
    public static function is_active_job_status( $status ) {
        $status = sanitize_key( (string) $status );
        return in_array( $status, self::get_canonical_active_job_statuses(), true );
    }

    /**
     * Is this a terminal shipment status?
     *
     * @param string $status
     * @return bool
     */
    public static function is_terminal_status( $status ) {
        $status = sanitize_key( (string) $status );
        return in_array( $status, self::get_terminal_statuses(), true );
    }
}
