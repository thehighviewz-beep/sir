<?php
namespace Caricove\Logistics\Core;

use WP_REST_Request;
use WP_REST_Response;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * SafetyAPI
 *
 * REST endpoint to allow courier apps / internal tools to flag unsafe deliveries.
 */
class SafetyAPI {

    public static function boot() {
        add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
    }

    public static function register_routes() {
        register_rest_route(
            'caricove-logistics/v1',
            '/flag-unsafe',
            array(
                'methods'             => 'POST',
                'callback'            => array( __CLASS__, 'handle_flag_unsafe' ),
                'permission_callback' => array( __CLASS__, 'permission_callback' ),
            )
        );
    }

    public static function permission_callback( $request ) {
        // For now: any logged-in user can flag. Later you can enforce courier role.
        return is_user_logged_in();
    }

    public static function handle_flag_unsafe( WP_REST_Request $req ) {
        $shipment_id = intval( $req->get_param( 'shipment_id' ) );
        $courier_id  = intval( $req->get_param( 'courier_id' ) );
        $reason      = sanitize_key( $req->get_param( 'reason' ) );
        $notes       = $req->get_param( 'notes' );

        if ( ! $shipment_id || ! $reason ) {
            return new WP_REST_Response(
                array(
                    'ok'      => false,
                    'message' => __( 'Missing shipment_id or reason.', 'caricove-logistics' ),
                ),
                400
            );
        }

        if ( ! $courier_id && is_user_logged_in() ) {
            $courier_id = get_current_user_id();
        }

        $context = array();
        if ( $notes ) {
            $context['notes'] = sanitize_text_field( $notes );
        }

        SafetyManager::flag_unsafe( $shipment_id, $courier_id, $reason, $context );

        return new WP_REST_Response(
            array(
                'ok'          => true,
                'shipment_id' => $shipment_id,
                'courier_id'  => $courier_id,
                'reason'      => $reason,
            ),
            200
        );
    }
}