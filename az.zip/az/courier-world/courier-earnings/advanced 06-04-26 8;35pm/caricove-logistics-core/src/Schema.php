<?php
namespace Caricove\Logistics\Core;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Caricove Logistics Schema
 *
 * Canonical meta keys, options, and helpers for the entire logistics engine.
 * NOTE: Schema defines "what exists" and canonical values. Policy enforcement
 * (ex: extra_heavy manual review, rescue handling, or special flags) should be handled by policy / admin workflow,
 * not by the dispatcher scoring layer.
 */
class Schema {

    /* ---------------------------------------------------------------
     *  OPTIONS
     * ------------------------------------------------------------ */

    const OPTION_ZONES        = '_cc_logistics_zones';
    const OPTION_SIZE_BANDS   = '_cc_logistics_size_bands';
    const OPTION_WEIGHT_BANDS = '_cc_logistics_weight_bands';
    const OPTION_FRAGILITY    = '_cc_logistics_fragility_levels';

    /* ---------------------------------------------------------------
     *  LINE ITEM META (WC ORDER ITEMS)
     * ------------------------------------------------------------ */

    // Shipment item meta on WC line items.
    const META_ITEM_VENDOR_ID      = '_cc_item_vendor_id';
    const META_ITEM_ORDER_ITEM_ID  = '_cc_item_order_item_id';
    const META_ITEM_SHIPMENT_ID    = '_cc_item_shipment_id';

    const META_ITEM_SIZE_CLASS     = '_cc_item_size_class';     // xs/s/m/l/xl
    const META_ITEM_WEIGHT_BAND    = '_cc_item_weight_band';    // light/medium/heavy/extra_heavy
    const META_ITEM_FRAGILITY      = '_cc_item_fragility';      // normal/fragile
    const META_ITEM_VALUE_BAND     = '_cc_item_value_band';     // low/mid/high

    // Optional: special handling flags on items (future-proof).
    const META_ITEM_SPECIAL_HANDLING = '_cc_item_special_handling'; // json (ex: ["two_person_lift","in_house_only"])

    const META_ITEM_PICKUP_ZONE    = '_cc_pickup_zone';
    const META_ITEM_DROPOFF_ZONE   = '_cc_dropoff_zone';

    /* ---------------------------------------------------------------
     *  SHIPMENT META (POST TYPE: cc_shipment)
     * ------------------------------------------------------------ */

    const META_SHIPMENT_TYPE             = '_cc_shipment_type';             // delivery/return/etc.
    const META_SHIPMENT_STATUS           = '_cc_shipment_status';

    const META_SHIPMENT_ORDER_ID         = '_cc_shipment_order_id';
    const META_SHIPMENT_VENDOR_ID        = '_cc_shipment_vendor_id';

    const META_SHIPMENT_PICKUP_ADDRESS   = '_cc_shipment_pickup_address';   // JSON
    const META_SHIPMENT_DROPOFF_ADDRESS  = '_cc_shipment_dropoff_address';  // JSON
    const META_SHIPMENT_PICKUP_COORDS    = '_cc_shipment_pickup_coords';    // "lat,lng"
    const META_SHIPMENT_DROPOFF_COORDS   = '_cc_shipment_dropoff_coords';   // "lat,lng"

    const META_SHIPMENT_PICKUP_NAME      = '_cc_shipment_pickup_name';
    const META_SHIPMENT_PICKUP_PHONE     = '_cc_shipment_pickup_phone';
    const META_SHIPMENT_DROPOFF_NAME     = '_cc_shipment_dropoff_name';
    const META_SHIPMENT_DROPOFF_PHONE    = '_cc_shipment_dropoff_phone';

    const META_SHIPMENT_ITEM_COUNT       = '_cc_shipment_item_count';
    const META_SHIPMENT_DECLARED_VALUE   = '_cc_shipment_declared_value';

    const META_SHIPMENT_ORIGIN_ANCHOR    = '_cc_shipment_origin_anchor';
    const META_SHIPMENT_DEST_ANCHOR      = '_cc_shipment_dest_anchor';

    const META_SHIPMENT_SIZE_BAND        = '_cc_shipment_size_band';        // xs/s/m/l/xl
    const META_SHIPMENT_WEIGHT_BAND      = '_cc_shipment_weight_band';      // light/medium/heavy/extra_heavy

    const META_SHIPMENT_COURIER_ID       = '_cc_shipment_courier_id';
    const META_SHIPMENT_JOB_ID           = '_cc_shipment_job_id';

    const META_SHIPMENT_BUNDLE_ID        = '_cc_shipment_bundle_id';
    const META_SHIPMENT_BUNDLE_SEQ       = '_cc_shipment_bundle_seq';

    const META_SHIPMENT_ETA              = '_cc_shipment_eta';
    const META_SHIPMENT_ETA_SOURCE       = '_cc_shipment_eta_source';
    const META_SHIPMENT_SLA_DEADLINE     = '_cc_shipment_sla_deadline';
    const META_SHIPMENT_SLA_RISK         = '_cc_shipment_sla_risk';
    const META_SHIPMENT_SLA_BREACHED     = '_cc_shipment_sla_breached';

    // Telemetry flags + notes.
    const META_SHIPMENT_TELEMETRY_EXCLUDED = '_cc_shipment_telemetry_excluded'; // yes/no
    const META_SHIPMENT_TELEMETRY_NOTES    = '_cc_shipment_telemetry_notes';    // array/json

    // Pickup / Delivery codes + Proof of Delivery.
    const META_SHIPMENT_PICKUP_CODE               = '_cc_shipment_pickup_code';
    const META_SHIPMENT_PICKUP_CODE_VERIFIED      = '_cc_shipment_pickup_code_verified';
    const META_SHIPMENT_PICKUP_CODE_VERIFIED_AT   = '_cc_shipment_pickup_code_verified_at';

    const META_SHIPMENT_DELIVERY_CODE             = '_cc_shipment_delivery_code';
    const META_SHIPMENT_DELIVERY_CODE_VERIFIED    = '_cc_shipment_delivery_code_verified';
    const META_SHIPMENT_DELIVERY_CODE_VERIFIED_AT = '_cc_shipment_delivery_code_verified_at';

    const META_SHIPMENT_POD_IMAGE_ID              = '_cc_shipment_pod_image_id';
    const META_SHIPMENT_POD_NOTES                 = '_cc_shipment_pod_notes';

    // Status-change helper.
    const META_SHIPMENT_LAST_STATUS_CHANGE_AT     = '_cc_shipment_last_status_change_at';

    // Offer / response timing truth (backend side only; courier console truth will be wired later).
    const META_SHIPMENT_OFFER_CREATED_AT          = '_cc_offer_created_at';
    const META_SHIPMENT_OFFER_EXPIRES_AT          = '_cc_offer_expires_at';
    const META_SHIPMENT_OFFER_COURIER_ID          = '_cc_offer_courier_id';
    const META_SHIPMENT_OFFER_RESPONSE_WINDOW     = '_cc_offer_response_window';
    const META_SHIPMENT_OFFER_LAST_TIMEOUT_AT     = '_cc_offer_last_timeout_at';
    const META_SHIPMENT_OFFER_LAST_REJECT_AT      = '_cc_offer_last_reject_at';
    const META_SHIPMENT_OFFER_LAST_REJECT_COURIER = '_cc_offer_last_reject_courier_id';
    const META_SHIPMENT_DECLINED_COURIERS         = '_cc_declined_couriers';
    const META_SHIPMENT_ASSIGNMENT_ACCEPTED_AT    = '_cc_assignment_accepted_at';

    /* ---------------------------------------------------------------
     *  IN-HOUSE / SPECIAL HANDLING META (NEW)
     * ------------------------------------------------------------ */

    /**
     * In-house handling gate.
     * These metas are set by your MU policy gate (NOT by dispatcher).
     */
    const META_SHIPMENT_INHOUSE_REQUIRED = '_cc_shipment_inhouse_required'; // yes/no
    const META_SHIPMENT_INHOUSE_REASON   = '_cc_shipment_inhouse_reason';   // manual_review | two_person_lift | furniture | equipment | other
    const META_SHIPMENT_SPECIAL_HANDLING = '_cc_shipment_special_handling'; // json array (["two_person_lift","straps_required",...])

    /* ---------------------------------------------------------------
     *  HUB & STORAGE META
     * ------------------------------------------------------------ */

    const META_SHIPMENT_IN_HUB_STORAGE      = '_cc_shipment_in_hub_storage';      // yes/no
    const META_SHIPMENT_HUB_RECEIVED_AT     = '_cc_shipment_hub_received_at';     // datetime
    const META_SHIPMENT_STORAGE_EXPIRES_AT  = '_cc_shipment_storage_expires_at';  // datetime

    /* ---------------------------------------------------------------
     *  REDELIVERY META (FREE + PAID)
     * ------------------------------------------------------------ */

    const META_SHIPMENT_FREE_REDELIVERY_USED   = '_cc_shipment_free_redelivery_used';   // yes/no
    const META_SHIPMENT_PAID_REDELIVERY_COUNT  = '_cc_shipment_paid_redelivery_count';  // int

    /* ---------------------------------------------------------------
     *  CONNECTION TEAM META (CALL CYCLES)
     * ------------------------------------------------------------ */

    const META_SHIPMENT_CONTACT_CYCLE_DAY        = '_cc_shipment_contact_cycle_day';
    const META_SHIPMENT_CONTACT_ATTEMPTS_TODAY   = '_cc_shipment_contact_attempts_today';
    const META_SHIPMENT_CONTACT_LAST_ATTEMPT_AT  = '_cc_shipment_contact_last_attempt_at';
    const META_SHIPMENT_CONTACT_LAST_OUTCOME     = '_cc_shipment_contact_last_outcome';
    const META_SHIPMENT_CONTACT_TOTAL_ATTEMPTS   = '_cc_shipment_contact_total_attempts';

    /* ---------------------------------------------------------------
     *  SAFETY META (SHIPMENT + COURIER)
     * ------------------------------------------------------------ */

    const META_SHIPMENT_SAFETY_FLAG       = '_cc_shipment_safety_flag';       // yes/no
    const META_SHIPMENT_SAFETY_REASON     = '_cc_shipment_safety_reason';     // unsafe_location/customer_threat/etc.
    const META_SHIPMENT_SAFETY_FLAGGED_AT = '_cc_shipment_safety_flagged_at'; // datetime

    const META_COURIER_SAFETY_FLAG        = '_cc_courier_safety_flag';        // yes/no
    const META_COURIER_SAFETY_NOTES       = '_cc_courier_safety_notes';       // json/text

    /* ---------------------------------------------------------------
     *  SHIPMENT RESCUE / SPECIAL COURIER META
     * ------------------------------------------------------------ */

    const META_SHIPMENT_RESCUE_STATE        = '_cc_shipment_rescue_state';
    const META_SHIPMENT_RESCUE_COURIER_ID   = '_cc_shipment_rescue_courier_id';
    const META_SHIPMENT_RESCUE_STARTED_AT   = '_cc_shipment_rescue_started_at';
    const META_SHIPMENT_RESCUE_EXPIRES_AT   = '_cc_shipment_rescue_expires_at';
    const META_SHIPMENT_RESCUE_REASON       = '_cc_shipment_rescue_reason';
    const META_SHIPMENT_RESCUE_LOG          = '_cc_shipment_rescue_log';

    /* ---------------------------------------------------------------
     *  COURIER CONTROL / SPECIAL ROLE META
     * ------------------------------------------------------------ */

    const META_COURIER_SPECIAL_ROLE    = '_cc_courier_special_role';    // normal|hub_rescue|security|connection_runner
    const META_COURIER_LOCK_REASON     = '_cc_courier_lock_reason';     // ''|risk_hold|investigation|manual_admin
    const META_COURIER_LOCK_EXPIRES_AT = '_cc_courier_lock_expires_at'; // datetime


    /**
     * Existing offer / response metas are operational markers only.
     * They are allowed for bounded offer handling, but they are not
     * canonical shipment-state truth.
     *
     * @return string[]
     */
    public static function get_operational_offer_meta_keys() {
        return array(
            self::META_SHIPMENT_OFFER_CREATED_AT,
            self::META_SHIPMENT_OFFER_EXPIRES_AT,
            self::META_SHIPMENT_OFFER_COURIER_ID,
            self::META_SHIPMENT_OFFER_RESPONSE_WINDOW,
            self::META_SHIPMENT_OFFER_LAST_TIMEOUT_AT,
            self::META_SHIPMENT_OFFER_LAST_REJECT_AT,
            self::META_SHIPMENT_OFFER_LAST_REJECT_COURIER,
            self::META_SHIPMENT_DECLINED_COURIERS,
            self::META_SHIPMENT_ASSIGNMENT_ACCEPTED_AT,
        );
    }

    /**
     * Offer / response / rescue metas that must never be read as
     * canonical shipment status truth.
     *
     * @param string $meta_key
     * @return bool
     */
    public static function is_operational_marker_meta( $meta_key ) {
        $meta_key = (string) $meta_key;

        $keys = array_merge(
            self::get_operational_offer_meta_keys(),
            array(
                self::META_SHIPMENT_RESCUE_STATE,
                self::META_SHIPMENT_RESCUE_COURIER_ID,
                self::META_SHIPMENT_RESCUE_STARTED_AT,
                self::META_SHIPMENT_RESCUE_EXPIRES_AT,
                self::META_SHIPMENT_RESCUE_REASON,
                self::META_SHIPMENT_RESCUE_LOG,
            )
        );

        return in_array( $meta_key, $keys, true );
    }

    /* ---------------------------------------------------------------
     *  UTIL: REGISTER SHIPMENTS CPT
     * ------------------------------------------------------------ */

    public static function register_shipment_cpt() {
        $labels = array(
            'name'               => __( 'Shipments', 'caricove-logistics' ),
            'singular_name'      => __( 'Shipment', 'caricove-logistics' ),
            'menu_name'          => __( 'Shipments', 'caricove-logistics' ),
            'name_admin_bar'     => __( 'Shipment', 'caricove-logistics' ),
            'add_new'            => __( 'Add New', 'caricove-logistics' ),
            'add_new_item'       => __( 'Add New Shipment', 'caricove-logistics' ),
            'new_item'           => __( 'New Shipment', 'caricove-logistics' ),
            'edit_item'          => __( 'Edit Shipment', 'caricove-logistics' ),
            'view_item'          => __( 'View Shipment', 'caricove-logistics' ),
            'all_items'          => __( 'All Shipments', 'caricove-logistics' ),
            'search_items'       => __( 'Search Shipments', 'caricove-logistics' ),
            'not_found'          => __( 'No shipments found.', 'caricove-logistics' ),
            'not_found_in_trash' => __( 'No shipments found in Trash.', 'caricove-logistics' ),
        );

        $args = array(
            'labels'             => $labels,
            'public'             => false,
            'show_ui'            => true,
            'show_in_menu'       => false, // Admin UI plugin adds its own menu.
            'capability_type'    => 'post',
            'hierarchical'       => false,
            'supports'           => array( 'title' ),
            'has_archive'        => false,
            'rewrite'            => false,
        );

        register_post_type( 'cc_shipment', $args );
    }

    /* ---------------------------------------------------------------
     *  HELPERS: ZONES / BANDS / FRAGILITY
     * ------------------------------------------------------------ */

    public static function get_zone_definitions() {
        $raw     = get_option( self::OPTION_ZONES, '' );
        $decoded = json_decode( $raw, true );

        if ( is_array( $decoded ) ) {
            return $decoded;
        }

        return array(
            'gt_kingston_hub' => array(
                'label' => 'Kingston Hub',
                'type'  => 'anchor',
            ),
        );
    }

    public static function get_size_bands() {
        $raw     = get_option( self::OPTION_SIZE_BANDS, '' );
        $decoded = json_decode( $raw, true );

        if ( is_array( $decoded ) ) {
            return $decoded;
        }

        return array(
            'xs' => array( 'label' => 'Extra Small' ),
            's'  => array( 'label' => 'Small' ),
            'm'  => array( 'label' => 'Medium' ),
            'l'  => array( 'label' => 'Large' ),
            'xl' => array( 'label' => 'Extra Large (Bulky)' ),
        );
    }

    public static function get_weight_bands() {
        $raw     = get_option( self::OPTION_WEIGHT_BANDS, '' );
        $decoded = json_decode( $raw, true );

        if ( is_array( $decoded ) ) {
            return $decoded;
        }

        return array(
            'light'       => array( 'label' => 'Light' ),
            'medium'      => array( 'label' => 'Medium' ),
            'heavy'       => array( 'label' => 'Heavy' ),
            'extra_heavy' => array( 'label' => 'Extra Heavy' ),
        );
    }

    public static function get_fragility_levels() {
        $raw     = get_option( self::OPTION_FRAGILITY, '' );
        $decoded = json_decode( $raw, true );

        if ( is_array( $decoded ) ) {
            return $decoded;
        }

        return array(
            'normal'  => array( 'label' => 'Normal' ),
            'fragile' => array( 'label' => 'Fragile' ),
        );
    }
}