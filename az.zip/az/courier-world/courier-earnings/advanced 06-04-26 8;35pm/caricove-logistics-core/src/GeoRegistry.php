<?php
namespace Caricove\Logistics\Core;

if ( ! defined('ABSPATH') ) { exit; }

/**
 * Core Geo Registry
 * Canonical storage for Anchors + Zones (source of truth).
 *
 * Anchors: slug, label, lat, lng, radius_m, zone_id
 * Zones: zone_id, label, polygon (array of [lat,lng]), anchors (array of slugs)
 */
class GeoRegistry {

    const OPT_ANCHORS = '_cc_anchor_definitions';
    const OPT_ZONES   = '_cc_zone_definitions';

    public static function boot() {
        // nothing required; kept for symmetry
    }

    public static function get_anchors() : array {
        $a = get_option(self::OPT_ANCHORS, array());
        return is_array($a) ? $a : array();
    }

    public static function get_zones() : array {
        $z = get_option(self::OPT_ZONES, array());
        return is_array($z) ? $z : array();
    }

    public static function save_anchors(array $anchors) : void {
        update_option(self::OPT_ANCHORS, array_values($anchors), false);
    }

    public static function save_zones(array $zones) : void {
        update_option(self::OPT_ZONES, array_values($zones), false);
    }

    /**
     * Resolve nearest anchor if within radius. Returns anchor slug or ''.
     */
    public static function resolve_anchor(float $lat, float $lng) : string {
        $anchors = self::get_anchors();
        $best = '';
        $best_m = PHP_FLOAT_MAX;

        foreach ($anchors as $a) {
            $slug = isset($a['slug']) ? sanitize_key($a['slug']) : '';
            if (!$slug) continue;

            $alat = isset($a['lat']) ? floatval($a['lat']) : null;
            $alng = isset($a['lng']) ? floatval($a['lng']) : null;
            $radm = isset($a['radius_m']) ? floatval($a['radius_m']) : 250;

            if ($alat === null || $alng === null) continue;

            $m = self::haversine_m($lat, $lng, $alat, $alng);
            if ($m < $best_m) {
                $best_m = $m;
                $best = $slug;
            }
        }

        if (!$best) return '';

        // check radius
        $a = self::get_anchor($best);
        $radm = isset($a['radius_m']) ? floatval($a['radius_m']) : 250;
        return ($best_m <= $radm) ? $best : '';
    }

    public static function get_anchor(string $slug) : array {
        $slug = sanitize_key($slug);
        foreach (self::get_anchors() as $a) {
            if (sanitize_key($a['slug'] ?? '') === $slug) return $a;
        }
        return array();
    }

    public static function resolve_zone(float $lat, float $lng) : string {
        $zones = self::get_zones();
        foreach ($zones as $z) {
            $id = isset($z['zone_id']) ? sanitize_key($z['zone_id']) : '';
            $poly = isset($z['polygon']) && is_array($z['polygon']) ? $z['polygon'] : array();
            if (!$id || count($poly) < 3) continue;
            if (self::point_in_polygon($lat, $lng, $poly)) return $id;
        }
        return '';
    }

    public static function lane_key(string $origin_anchor, string $dest_anchor) : string {
        $o = $origin_anchor ? sanitize_key($origin_anchor) : 'unknown_origin';
        $d = $dest_anchor ? sanitize_key($dest_anchor) : 'unknown_dest';
        return $o . '::' . $d;
    }

    /* ---------- geometry helpers ---------- */

    public static function haversine_m($lat1,$lng1,$lat2,$lng2) : float {
        $r = 6371000.0;
        $dLat = deg2rad($lat2 - $lat1);
        $dLng = deg2rad($lng2 - $lng1);
        $a = sin($dLat/2)*sin($dLat/2) + cos(deg2rad($lat1))*cos(deg2rad($lat2))*sin($dLng/2)*sin($dLng/2);
        $c = 2 * atan2(sqrt($a), sqrt(1-$a));
        return $r * $c;
    }

    // Ray casting algorithm
    public static function point_in_polygon($lat, $lng, array $poly) : bool {
        $inside = false;
        $j = count($poly) - 1;

        for ($i = 0; $i < count($poly); $i++) {
            $xi = floatval($poly[$i][0]); $yi = floatval($poly[$i][1]);
            $xj = floatval($poly[$j][0]); $yj = floatval($poly[$j][1]);

            $intersect = (($yi > $lng) !== ($yj > $lng))
                && ($lat < ($xj - $xi) * ($lng - $yi) / (($yj - $yi) ?: 1e-9) + $xi);

            if ($intersect) $inside = !$inside;
            $j = $i;
        }
        return $inside;
    }
}