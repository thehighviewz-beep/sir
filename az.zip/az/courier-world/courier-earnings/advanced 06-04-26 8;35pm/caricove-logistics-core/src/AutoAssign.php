<?php
namespace Caricove\Logistics\Core;

use WP_Error;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * AutoAssign
 *
 * Core operational offer handling and dispatcher fallback coordination.
 * Canonical shipment status stays in the older state universe; offer flow is
 * tracked with temporary operational metas + telemetry only.
 */
class AutoAssign {

    protected static $booted = false;

    protected static function append_intelligence_log( $shipment_id, array $payload ) {
        $shipment_id = intval( $shipment_id );
        if ( ! $shipment_id ) {
            return;
        }

        $payload['recorded_at'] = current_time( 'mysql', true );
        do_action( 'cc_cp_logistics_intelligence_event', $payload );

        if ( ! has_action( 'cc_cp_logistics_intelligence_event' ) ) {
            $existing = get_post_meta( $shipment_id, '_cc_cp_logistics_intel_events', true );
            if ( ! is_array( $existing ) ) {
                $existing = array();
            }
            $existing[] = $payload;
            if ( count( $existing ) > 100 ) {
                $existing = array_slice( $existing, -100 );
            }
            update_post_meta( $shipment_id, '_cc_cp_logistics_intel_events', $existing );
        }
    }

    protected static function build_offer_intelligence_payload( $shipment_id, $courier_id, $event, array $extra = array() ) {
        $shipment_id = intval( $shipment_id );
        $courier_id  = intval( $courier_id );
        $summary     = ShipmentManager::get_shipment_summary( $shipment_id );
        $profile     = $courier_id ? CourierProfile::get_profile( $courier_id ) : array();

        return array_merge(
            array(
                'event'               => sanitize_key( (string) $event ),
                'shipment_id'         => $shipment_id,
                'courier_id'          => $courier_id,
                'timestamp'           => time(),
                'distance_band'       => sanitize_key( (string) ( $summary['distance_band'] ?? $summary['trip_band'] ?? '' ) ),
                'route_source'        => sanitize_key( (string) ( $summary['route_source'] ?? '' ) ),
                'route_detail_source' => sanitize_key( (string) ( $summary['route_detail_source'] ?? '' ) ),
                'vehicle_type'        => sanitize_key( (string) ( $profile['vehicle_type'] ?? $summary['courier_vehicle_type'] ?? '' ) ),
                'active_jobs'         => $courier_id ? self::get_courier_active_job_count( $courier_id ) : 0,
                'quote_total'         => floatval( $summary['quote_total_gyd'] ?? 0 ),
                'origin_anchor'       => sanitize_key( (string) ( $summary['origin_anchor'] ?? '' ) ),
                'destination_anchor'  => sanitize_key( (string) ( $summary['destination_anchor'] ?? '' ) ),
            ),
            $extra
        );
    }

    public static function get_declined_couriers( $shipment_id ) {
        $shipment_id = intval( $shipment_id );
        if ( ! $shipment_id ) {
            return array();
        }

        $declined = get_post_meta( $shipment_id, Schema::META_SHIPMENT_DECLINED_COURIERS, true );
        if ( ! is_array( $declined ) ) {
            $declined = array();
        }

        return array_values( array_unique( array_filter( array_map( 'intval', $declined ) ) ) );
    }

    public static function add_declined_courier( $shipment_id, $courier_id ) {
        $shipment_id = intval( $shipment_id );
        $courier_id  = intval( $courier_id );
        if ( ! $shipment_id || ! $courier_id ) {
            return;
        }

        $declined = self::get_declined_couriers( $shipment_id );
        if ( ! in_array( $courier_id, $declined, true ) ) {
            $declined[] = $courier_id;
            update_post_meta( $shipment_id, Schema::META_SHIPMENT_DECLINED_COURIERS, array_values( $declined ) );
        }
    }

    public static function clear_offer_meta( $shipment_id ) {
        $shipment_id = intval( $shipment_id );
        if ( ! $shipment_id ) {
            return;
        }

        delete_post_meta( $shipment_id, Schema::META_SHIPMENT_OFFER_CREATED_AT );
        delete_post_meta( $shipment_id, Schema::META_SHIPMENT_OFFER_EXPIRES_AT );
        delete_post_meta( $shipment_id, Schema::META_SHIPMENT_OFFER_COURIER_ID );
        delete_post_meta( $shipment_id, Schema::META_SHIPMENT_OFFER_RESPONSE_WINDOW );
        wp_clear_scheduled_hook( 'cc_core_offer_timeout', array( $shipment_id ) );
    }

    protected static function clear_offer_assignment_residue( $shipment_id ) {
        $shipment_id = intval( $shipment_id );
        if ( ! $shipment_id ) {
            return;
        }

        update_post_meta( $shipment_id, Schema::META_SHIPMENT_COURIER_ID, 0 );
        delete_post_meta( $shipment_id, Schema::META_SHIPMENT_ASSIGNMENT_ACCEPTED_AT );
    }

    public static function get_offer_window_state( $shipment_id, array $summary = array(), $courier_id = 0 ) {
        $shipment_id = intval( $shipment_id );
        $courier_id  = intval( $courier_id );

        if ( ! $shipment_id ) {
            return array(
                'has_offer'             => false,
                'matches_courier'       => false,
                'is_live'               => false,
                'is_expired'            => false,
                'offer_courier_id'      => 0,
                'offer_expires_at'      => 0,
                'status'                => '',
                'assigned_and_accepted' => false,
            );
        }

        if ( empty( $summary ) ) {
            $summary = ShipmentManager::get_shipment_summary( $shipment_id );
        }

        if ( empty( $summary ) ) {
            return array(
                'has_offer'             => false,
                'matches_courier'       => false,
                'is_live'               => false,
                'is_expired'            => false,
                'offer_courier_id'      => 0,
                'offer_expires_at'      => 0,
                'status'                => '',
                'assigned_and_accepted' => false,
            );
        }

        $status           = sanitize_key( (string) ( $summary['status'] ?? '' ) );
        $offer_courier_id = intval( $summary['offer_courier_id'] ?? 0 );
        $offer_expires_at = intval( $summary['offer_expires_at'] ?? 0 );
        $assigned         = intval( $summary['courier_id'] ?? 0 );
        $accepted_at      = (string) ( $summary['assignment_accepted_at'] ?? '' );

        $terminal = class_exists( StatusMachine::class ) && StatusMachine::is_terminal_status( $status );
        $has_offer = ( $offer_courier_id > 0 && $offer_expires_at > 0 );
        $matches_courier = ! $courier_id || ( $offer_courier_id > 0 && $offer_courier_id === $courier_id );
        $assigned_and_accepted = ( $assigned > 0 && $accepted_at !== '' );
        $is_expired = ( $has_offer && time() >= $offer_expires_at );
        $is_live = (
            $has_offer
            && ! $terminal
            && ! $assigned_and_accepted
            && $matches_courier
            && ! $is_expired
            && $status === 'ready_for_assignment'
        );

        return array(
            'has_offer'             => $has_offer,
            'matches_courier'       => $matches_courier,
            'is_live'               => $is_live,
            'is_expired'            => ( $has_offer && $matches_courier && ! $assigned_and_accepted && $is_expired ),
            'offer_courier_id'      => $offer_courier_id,
            'offer_expires_at'      => $offer_expires_at,
            'status'                => $status,
            'assigned_and_accepted' => $assigned_and_accepted,
        );
    }

    public static function shipment_has_live_offer( $shipment_id, array $summary = array(), $courier_id = 0 ) {
        $state = self::get_offer_window_state( $shipment_id, $summary, $courier_id );
        return ! empty( $state['is_live'] );
    }

    public static function shipment_has_expired_offer( $shipment_id, array $summary = array(), $courier_id = 0 ) {
        $state = self::get_offer_window_state( $shipment_id, $summary, $courier_id );
        return ! empty( $state['is_expired'] );
    }

    public static function maybe_finalize_expired_offer( $shipment_id, $courier_id = 0, array $summary = array() ) {
        $shipment_id = intval( $shipment_id );
        if ( ! $shipment_id ) {
            return false;
        }

        $state = self::get_offer_window_state( $shipment_id, $summary, $courier_id );
        if ( empty( $state['is_expired'] ) ) {
            return false;
        }

        self::handle_offer_timeout( $shipment_id, intval( $state['offer_courier_id'] ?? 0 ) );
        return true;
    }

    protected static function redispatch_shipment( $shipment_id, $reason = 'offer_cycle' ) {
        $shipment_id = intval( $shipment_id );
        if ( ! $shipment_id ) {
            return;
        }

        $reason = sanitize_key( (string) $reason );
        $settings = class_exists( '\Caricove\Logistics\Dispatcher\Settings' )
            ? \Caricove\Logistics\Dispatcher\Settings::get_settings()
            : array();

        $attempts = intval( get_post_meta( $shipment_id, '_cc_redispatch_attempts', true ) );
        $attempts++;
        update_post_meta( $shipment_id, '_cc_redispatch_attempts', $attempts );

        $max_attempts = max(
            1,
            intval( $settings['redispatch_max_attempts'] ?? 0 ),
            intval( $settings['backlog_max_attempts'] ?? 0 )
        );

        if ( $attempts > $max_attempts ) {
            update_post_meta( $shipment_id, '_cc_hold_reason', 'offer_cycle_exhausted' );
            do_action( 'cc_dispatcher_offer_cycle_exhausted', $shipment_id, $attempts, $reason );
            return;
        }

        if ( class_exists( '\Caricove\Logistics\Dispatcher\Engine' ) ) {
            \Caricove\Logistics\Dispatcher\Engine::handle_retry_assignment( $shipment_id, $reason );
            return;
        }

        $summary = ShipmentManager::get_shipment_summary( $shipment_id );
        do_action(
            'cc_shipment_ready_for_assignment',
            $shipment_id,
            intval( $summary['order_id'] ?? 0 ),
            intval( $summary['vendor_id'] ?? 0 )
        );
    }

    public static function offer_is_live( $shipment_id, $courier_id = 0 ) {
        $state = self::get_offer_window_state( $shipment_id, array(), $courier_id );
        return ! empty( $state['is_live'] );
    }

    public static function accept_job( $shipment_id, $courier_id, array $context = array() ) {
        $shipment_id = intval( $shipment_id );
        $courier_id  = intval( $courier_id );
        if ( ! $shipment_id || ! $courier_id ) {
            return new WP_Error( 'cc_offer_bad_request', 'Invalid offer request.' );
        }

        if ( ! self::offer_is_live( $shipment_id, $courier_id ) ) {
            return new WP_Error( 'cc_offer_not_live', 'Offer is no longer live.' );
        }

        $summary = ShipmentManager::get_shipment_summary( $shipment_id );
        $settings = class_exists( '\Caricove\Logistics\Dispatcher\Settings' )
            ? \Caricove\Logistics\Dispatcher\Settings::get_settings()
            : array();

        self::clear_offer_meta( $shipment_id );

        $context = array_merge(
            array(
                'source'           => 'offer_accept',
                'skip_offer_window' => 1,
                'offer_response_required' => 0,
            ),
            $context
        );

        if ( class_exists( '\Caricove\Logistics\Dispatcher\Assign' ) ) {
            \Caricove\Logistics\Dispatcher\Assign::to_courier(
                $shipment_id,
                $courier_id,
                $summary,
                $settings,
                $context
            );
        } else {
            ShipmentManager::assign_shipment_to_courier(
                $shipment_id,
                $courier_id,
                array_merge( $context, array( 'status' => 'assigned' ) )
            );
        }

        update_post_meta( $shipment_id, Schema::META_SHIPMENT_ASSIGNMENT_ACCEPTED_AT, current_time( 'mysql', true ) );

        $payload = self::build_offer_intelligence_payload(
            $shipment_id,
            $courier_id,
            'offer_accepted',
            array(
                'source' => sanitize_key( (string) ( $context['source'] ?? 'offer_accept' ) ),
            )
        );
        self::append_intelligence_log( $shipment_id, $payload );

        do_action( 'cc_shipment_offer_accepted', $shipment_id, $courier_id, $context );

        return true;
    }

    public static function reject_job( $shipment_id, $courier_id, $reason = 'offer_rejected' ) {
        $shipment_id = intval( $shipment_id );
        $courier_id  = intval( $courier_id );
        if ( ! $shipment_id || ! $courier_id ) {
            return new WP_Error( 'cc_offer_bad_request', 'Invalid offer request.' );
        }

        if ( ! self::offer_is_live( $shipment_id, $courier_id ) ) {
            return new WP_Error( 'cc_offer_not_live', 'Offer is no longer live.' );
        }

        self::finalize_offer_failure(
            $shipment_id,
            $courier_id,
            'offer_rejected',
            array(
                'reason' => sanitize_key( (string) $reason ),
            )
        );

        return true;
    }

    public static function begin_offer_window( $shipment_id, $courier_id, array $shipment_summary = array(), array $settings = array(), array $context = array() ) {
        $shipment_id = intval( $shipment_id );
        $courier_id  = intval( $courier_id );

        if ( ! $shipment_id || ! $courier_id ) {
            return;
        }

        if ( empty( $shipment_summary ) ) {
            $shipment_summary = ShipmentManager::get_shipment_summary( $shipment_id );
        }
        if ( empty( $settings ) && class_exists( '\Caricove\Logistics\Dispatcher\Settings' ) ) {
            $settings = \Caricove\Logistics\Dispatcher\Settings::get_settings();
        }

        $status = sanitize_key( (string) ( $shipment_summary['status'] ?? '' ) );
        if ( $status !== 'ready_for_assignment' ) {
            return;
        }

        self::clear_offer_meta( $shipment_id );
        self::clear_offer_assignment_residue( $shipment_id );

        $window = class_exists( '\Caricove\Logistics\Dispatcher\Settings' )
            ? \Caricove\Logistics\Dispatcher\Settings::get_accept_window_seconds( $shipment_summary, $settings )
            : max( 5, intval( $settings['default_accept_window_seconds'] ?? 12 ) );

        $created_at = time();
        $expires_at = $created_at + max( 5, intval( $window ) );

        update_post_meta( $shipment_id, Schema::META_SHIPMENT_OFFER_CREATED_AT, $created_at );
        update_post_meta( $shipment_id, Schema::META_SHIPMENT_OFFER_EXPIRES_AT, $expires_at );
        update_post_meta( $shipment_id, Schema::META_SHIPMENT_OFFER_COURIER_ID, $courier_id );
        update_post_meta( $shipment_id, Schema::META_SHIPMENT_OFFER_RESPONSE_WINDOW, max( 5, intval( $window ) ) );

        wp_clear_scheduled_hook( 'cc_core_offer_timeout', array( $shipment_id ) );
        wp_schedule_single_event( $expires_at, 'cc_core_offer_timeout', array( $shipment_id ) );

        $payload = self::build_offer_intelligence_payload(
            $shipment_id,
            $courier_id,
            'offer_sent',
            array(
                'expires_at' => $expires_at,
                'source'     => sanitize_key( (string) ( $context['source'] ?? 'dispatcher_auto' ) ),
            )
        );
        self::append_intelligence_log( $shipment_id, $payload );

        do_action( 'cc_shipment_offer_sent', $shipment_id, $courier_id, $context );
    }

    public static function handle_offer_timeout( $shipment_id, $courier_id = 0 ) {
        $shipment_id = intval( $shipment_id );
        $courier_id  = intval( $courier_id );

        if ( ! $shipment_id ) {
            return;
        }

        $summary = ShipmentManager::get_shipment_summary( $shipment_id );
        if ( empty( $summary ) ) {
            return;
        }

        $offer_courier = intval( $summary['offer_courier_id'] ?? 0 );
        if ( ! $offer_courier ) {
            return;
        }
        if ( $courier_id && $offer_courier !== $courier_id ) {
            return;
        }

        $expires_at = intval( $summary['offer_expires_at'] ?? 0 );
        if ( ! $expires_at || time() < $expires_at ) {
            return;
        }

        self::finalize_offer_failure(
            $shipment_id,
            $offer_courier,
            'offer_timed_out',
            array()
        );
    }

    public static function boot() {
        if ( self::$booted ) {
            return;
        }

        self::$booted = true;

        add_action(
            'cc_shipment_ready_for_assignment',
            array( __CLASS__, 'maybe_auto_assign' ),
            10,
            3
        );

        add_filter(
            'cc_dispatcher_courier_active_jobs',
            array( __CLASS__, 'filter_dispatcher_active_jobs' ),
            10,
            3
        );

        add_action(
            'cc_core_offer_timeout',
            array( __CLASS__, 'handle_offer_timeout' ),
            10,
            1
        );
    }

    public static function maybe_auto_assign( $shipment_id, $order_id, $vendor_id ) {
        $shipment_id = intval( $shipment_id );
        if ( ! $shipment_id ) {
            return;
        }

        $dispatcher_available = class_exists( '\Caricove\Logistics\Dispatcher\Engine' )
            && class_exists( '\Caricove\Logistics\Dispatcher\Assign' )
            && class_exists( '\Caricove\Logistics\Dispatcher\CourierPool' )
            && class_exists( '\Caricove\Logistics\Dispatcher\Scoring' );

        if ( $dispatcher_available ) {
            return;
        }

        if ( apply_filters( 'cc_disable_core_auto_assign', false, $shipment_id, $order_id, $vendor_id ) ) {
            return;
        }

        if ( ! apply_filters( 'cc_enable_core_auto_assign_fallback', false, $shipment_id, $order_id, $vendor_id ) ) {
            return;
        }

        $summary = ShipmentManager::get_shipment_summary( $shipment_id );
        if ( empty( $summary ) || sanitize_key( (string) ( $summary['status'] ?? '' ) ) !== 'ready_for_assignment' ) {
            return;
        }

        if ( ! class_exists( '\Caricove\Logistics\Dispatcher\Settings' ) || ! class_exists( '\Caricove\Logistics\Dispatcher\Overrides' ) ) {
            return;
        }

        $settings  = \Caricove\Logistics\Dispatcher\Settings::get_settings();
        $overrides = \Caricove\Logistics\Dispatcher\Overrides::get_overrides();
        $courier_id = self::find_best_courier_for_shipment( $summary, $settings, $overrides );

        if ( ! $courier_id ) {
            return;
        }

        \Caricove\Logistics\Dispatcher\Assign::to_courier(
            $shipment_id,
            $courier_id,
            $summary,
            $settings,
            array(
                'source' => 'core_auto_assign_fallback',
            )
        );
    }

    public static function find_best_courier_for_shipment( array $shipment_summary, array $settings = array(), array $overrides = array() ) {
        if ( empty( $settings ) && class_exists( '\Caricove\Logistics\Dispatcher\Settings' ) ) {
            $settings = \Caricove\Logistics\Dispatcher\Settings::get_settings();
        }
        if ( empty( $overrides ) && class_exists( '\Caricove\Logistics\Dispatcher\Overrides' ) ) {
            $overrides = \Caricove\Logistics\Dispatcher\Overrides::get_overrides();
        }

        if ( ! class_exists( '\Caricove\Logistics\Dispatcher\CourierPool' ) || ! class_exists( '\Caricove\Logistics\Dispatcher\Scoring' ) ) {
            return 0;
        }

        $candidates = \Caricove\Logistics\Dispatcher\CourierPool::get_candidates( $shipment_summary, $settings, $overrides );
        if ( empty( $candidates ) ) {
            return 0;
        }

        $best_id = 0;
        $best_total = -INF;

        foreach ( $candidates as $courier_id => $profile ) {
            $score = \Caricove\Logistics\Dispatcher\Scoring::score( $shipment_summary, $profile, $settings, $overrides );
            $total = floatval( $score['total'] ?? 0 );
            if ( $total > $best_total ) {
                $best_total = $total;
                $best_id    = intval( $courier_id );
            }
        }

        return $best_id;
    }

    public static function is_courier_eligible_for_shipment( $courier_id, array $shipment_summary, array $settings = array(), array $overrides = array() ) {
        if ( empty( $settings ) && class_exists( '\Caricove\Logistics\Dispatcher\Settings' ) ) {
            $settings = \Caricove\Logistics\Dispatcher\Settings::get_settings();
        }
        if ( empty( $overrides ) && class_exists( '\Caricove\Logistics\Dispatcher\Overrides' ) ) {
            $overrides = \Caricove\Logistics\Dispatcher\Overrides::get_overrides();
        }
        if ( ! class_exists( '\Caricove\Logistics\Dispatcher\CourierPool' ) ) {
            return false;
        }

        $evaluation = \Caricove\Logistics\Dispatcher\CourierPool::evaluate_courier_by_id( $courier_id, $shipment_summary, $settings, $overrides );
        return ! empty( $evaluation['eligible'] );
    }

    public static function filter_dispatcher_active_jobs( $current, $profile, $shipment ) {
        unset( $shipment );

        if ( $current !== null && $current !== false && $current !== '' ) {
            return $current;
        }

        $courier_id = 0;
        if ( is_array( $profile ) ) {
            $courier_id = intval( $profile['id'] ?? $profile['user_id'] ?? 0 );
        }

        if ( ! $courier_id ) {
            return 0;
        }

        return self::get_courier_active_job_count( $courier_id );
    }

    public static function get_courier_active_job_count( $courier_id ) {
        $courier_id = intval( $courier_id );
        if ( ! $courier_id ) {
            return 0;
        }

        $statuses = class_exists( StatusMachine::class )
            ? StatusMachine::get_canonical_active_job_statuses()
            : array( 'assigned', 'picked_up', 'in_transit' );

        $query = new \WP_Query(
            array(
                'post_type'      => 'cc_shipment',
                'post_status'    => 'any',
                'posts_per_page' => 200,
                'fields'         => 'ids',
                'no_found_rows'  => true,
                'meta_query'     => array(
                    'relation' => 'AND',
                    array(
                        'key'   => Schema::META_SHIPMENT_COURIER_ID,
                        'value' => $courier_id,
                    ),
                    array(
                        'key'     => Schema::META_SHIPMENT_STATUS,
                        'value'   => $statuses,
                        'compare' => 'IN',
                    ),
                ),
            )
        );

        return $query->have_posts() ? count( (array) $query->posts ) : 0;
    }

    public static function compute_courier_score( $courier_id, array $shipment_summary, array $settings = array(), array $overrides = array() ) {
        if ( empty( $settings ) && class_exists( '\Caricove\Logistics\Dispatcher\Settings' ) ) {
            $settings = \Caricove\Logistics\Dispatcher\Settings::get_settings();
        }
        if ( empty( $overrides ) && class_exists( '\Caricove\Logistics\Dispatcher\Overrides' ) ) {
            $overrides = \Caricove\Logistics\Dispatcher\Overrides::get_overrides();
        }
        if ( ! class_exists( '\Caricove\Logistics\Dispatcher\Scoring' ) ) {
            return array( 'total' => 0.0 );
        }

        $profile = CourierProfile::get_profile( $courier_id );
        if ( ! is_array( $profile ) ) {
            $profile = array();
        }
        $profile['id'] = intval( $courier_id );

        return \Caricove\Logistics\Dispatcher\Scoring::score( $shipment_summary, $profile, $settings, $overrides );
    }
}
