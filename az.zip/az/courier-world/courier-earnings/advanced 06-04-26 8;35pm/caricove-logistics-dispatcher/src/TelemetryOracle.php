<?php
namespace Caricove\Logistics\Dispatcher;

if ( ! defined('ABSPATH') ) { exit; }

/**
 * TelemetryOracle
 * Returns: eta_seconds, travel_minutes, risk (0..1), confidence (0..1), bucket_used
 *
 * Data source: option _cc_telemetry_lane_stats
 * Where lane stats are keyed by:
 * lane_key::time_bucket::day_type::vehicle
 *
 * Stats shape per key:
 * [
 *   'n' => int,
 *   'p50' => seconds,
 *   'p90' => seconds,
 *   'avg' => seconds,
 *   'late_rate' => 0..1
 * ]
 */
class TelemetryOracle {

    const OPT_MATRIX = '_cc_telemetry_eta_matrix';

    protected static $booted = false;

    const OPT_LANE_STATS = '_cc_telemetry_lane_stats';

    public static function boot() {
        if ( self::$booted ) {
            return;
        }

        self::$booted = true;
        add_filter('cc_dispatcher_sla_hint_for_candidate', array(__CLASS__,'sla_hint'), 25, 3);
    }

    public static function sla_hint($hint, $shipment, $profile) {

        // If shipment doesn’t have anchors, we can’t do lane learning.
        $origin = isset($shipment['origin_anchor']) ? sanitize_key($shipment['origin_anchor']) : '';
        $dest   = isset($shipment['destination_anchor']) ? sanitize_key($shipment['destination_anchor']) : (isset($shipment['dest_anchor']) ? sanitize_key($shipment['dest_anchor']) : '');

        if (!$origin || !$dest) return $hint;

        $bucket = apply_filters('cc_telemetry_time_bucket', self::time_bucket());
        $day_type = self::day_type();
        $vehicle  = isset($profile['vehicle_type']) ? sanitize_key((string)$profile['vehicle_type']) : 'unknown';

        $lane = $origin . '::' . $dest;

        $res = self::lookup_with_fallback($lane, $bucket, $day_type, $vehicle);

        if (!$res) {
            $res = self::matrix_lookup_with_fallback($origin, $dest);
        }

        if (!$res) return $hint;

        // risk = blend(late_rate + “slow tail”)
        $risk = floatval($res['risk']);
        $confidence = floatval($res['confidence']);

        $hint['risk'] = max(0.0, min(1.0, $risk));
        $hint['eta_seconds'] = isset($res['eta_seconds']) ? intval($res['eta_seconds']) : null;
        $hint['travel_minutes'] = isset($res['eta_seconds']) ? (floatval($res['eta_seconds']) / 60.0) : null;
        $hint['confidence'] = max(0.0, min(1.0, $confidence));
        $hint['bucket_used'] = (string)$res['bucket_used'];

        return $hint;
    }

    public static function time_bucket() : string {
        $ts = current_time('timestamp');
        $hour = intval(gmdate('G', $ts + ( get_option('gmt_offset') * HOUR_IN_SECONDS )));
        if ($hour >= 6 && $hour < 10) return 'morning';
        if ($hour >= 10 && $hour < 16) return 'midday';
        if ($hour >= 16 && $hour < 20) return 'evening_peak';
        return 'night';
    }

    public static function day_type() : string {
        $ts = current_time('timestamp');
        $dow = intval(gmdate('N', $ts + ( get_option('gmt_offset') * HOUR_IN_SECONDS ))); // 1..7
        if ($dow >= 1 && $dow <= 5) return 'weekday';
        if ($dow === 6) return 'saturday';
        return 'sunday';
    }

    public static function get_stats() : array {
        $st = get_option(self::OPT_LANE_STATS, array());
        return is_array($st) ? $st : array();
    }

    protected static function matrix_bucket() : string {
        if ( class_exists( '\Caricove_Telemetry_Settings' ) && method_exists( '\Caricove_Telemetry_Settings', 'settings' ) && method_exists( '\Caricove_Telemetry_Settings', 'time_bucket' ) ) {
            $ts = current_time( 'timestamp' );
            $settings = \Caricove_Telemetry_Settings::settings();
            return (string) \Caricove_Telemetry_Settings::time_bucket( $ts, $settings );
        }

        return self::day_type() . '+' . self::time_bucket();
    }

    protected static function matrix_lookup_with_fallback( string $origin, string $dest ) : array {
        $matrix = get_option( self::OPT_MATRIX, array() );
        if ( ! is_array( $matrix ) || empty( $matrix ) ) {
            return array();
        }

        $bucket = self::matrix_bucket();
        $keys = array(
            $origin . ':' . $dest . '|dropoff|' . $bucket,
            $origin . ':' . $dest . '|route|' . $bucket,
            $origin . ':' . $dest . '|pickup|' . $bucket,
        );

        foreach ( $keys as $k ) {
            if ( empty( $matrix[ $k ] ) || ! is_array( $matrix[ $k ] ) ) {
                continue;
            }

            $row = $matrix[ $k ];
            $n   = max( 0, intval( $row['samples'] ?? 0 ) );
            if ( $n <= 0 ) {
                continue;
            }

            $avg_min = floatval( $row['avg_min'] ?? 0.0 );
            $last_min = floatval( $row['last_min'] ?? 0.0 );
            $minutes = $avg_min > 0 ? $avg_min : $last_min;
            if ( $minutes <= 0 ) {
                continue;
            }

            $confidence = $n >= 20 ? 0.85 : ( $n >= 8 ? 0.60 : 0.35 );
            $risk = $n >= 20 ? 0.10 : ( $n >= 8 ? 0.20 : 0.35 );

            return array(
                'eta_seconds' => intval( round( $minutes * 60 ) ),
                'risk' => $risk,
                'confidence' => $confidence,
                'bucket_used' => 'matrix:' . $k,
                'n' => $n,
            );
        }

        return array();
    }


    /**
     * Fallback ladder:
     * 1) lane+bucket+day+vehicle
     * 2) lane+bucket+day+any_vehicle
     * 3) lane+bucket+any_day+any_vehicle
     * 4) lane+any_bucket+any_day+any_vehicle
     */
    public static function lookup_with_fallback(string $lane, string $bucket, string $day, string $vehicle) : array {
        $stats = self::get_stats();
        $keys = array(
            "{$lane}::{$bucket}::{$day}::{$vehicle}",
            "{$lane}::{$bucket}::{$day}::any",
            "{$lane}::{$bucket}::any::any",
            "{$lane}::any::any::any",
        );

        $min_n_strict = 12; // enough to be confident
        $min_n_loose  = 5;  // acceptable

        foreach ($keys as $i => $k) {
            if (empty($stats[$k]) || !is_array($stats[$k])) continue;

            $row = $stats[$k];
            $n = intval($row['n'] ?? 0);
            if ($n <= 0) continue;

            // Confidence based on sample size and fallback depth
            $depth_penalty = 0.10 * $i;
            $conf = ($n >= $min_n_strict) ? 0.85 : (($n >= $min_n_loose) ? 0.55 : 0.35);
            $conf = max(0.15, $conf - $depth_penalty);

            $p50 = intval($row['p50'] ?? 0);
            $p90 = intval($row['p90'] ?? 0);
            $avg = intval($row['avg'] ?? 0);
            $late = floatval($row['late_rate'] ?? 0.0);

            $eta = $p50 ?: ($avg ?: $p90);
            if ($eta <= 0) continue;

            // risk blends late_rate + tail heaviness
            $tail = ($p90 > 0 && $p50 > 0) ? min(1.0, max(0.0, ($p90 - $p50) / max(1.0, $p50))) : 0.0;
            $risk = min(1.0, 0.65*$late + 0.35*$tail);

            return array(
                'eta_seconds' => $eta,
                'risk' => $risk,
                'confidence' => $conf,
                'bucket_used' => $k,
                'n' => $n,
            );
        }

        return array();
    }
}

TelemetryOracle::boot();
