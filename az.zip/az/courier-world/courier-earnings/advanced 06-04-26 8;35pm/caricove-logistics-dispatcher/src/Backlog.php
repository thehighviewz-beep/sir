<?php
namespace Caricove\Logistics\Dispatcher;

use Caricove\Logistics\Core\ShipmentManager;
use Caricove\Logistics\Core\Schema;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Backlog {

    protected static $booted = false;

    const PATCH_VERSION            = '2026-04-03-aggressive-ready-5x-v5';
    const META_REDISPATCH_ATTEMPTS = '_cc_redispatch_attempts';
    const OPTION_LAST_RUN          = 'caricove_redispatch_last_run';
    const OPTION_LOG_RING          = 'caricove_backlog_log_ring';
    const OPTION_LAST_SWEEP_STATE  = 'caricove_backlog_last_sweep_state';
    const MAX_LOG_LINES            = 1200;
    const FORCE_MARKER_PREFIX      = 'caricove_backlog_force_';

    protected static $eligible_statuses = array(
        'ready_for_assignment',
    );

    public static function boot() {
        if ( self::$booted ) {
            return;
        }
        self::$booted = true;
    }

    public static function patch_version() {
        return self::PATCH_VERSION;
    }

    protected static function rules() {
        return array(
            'enabled'           => true,
            'interval_seconds'  => 60,
            'no_lock_mode'      => true,
            'max_attempts'      => 5,
            'eligible_statuses' => self::$eligible_statuses,
            'patch_version'     => self::PATCH_VERSION,
        );
    }

    public static function sweep() {
        $rules    = self::rules();
        $sweep_id = gmdate( 'Y-m-d H:i:s' ) . '|' . wp_generate_password( 6, false, false );

        self::reset_sweep_state( $sweep_id, $rules );
        self::log( 'SWEEP HIT ' . $sweep_id );
        self::log( 'Patch version=' . self::PATCH_VERSION );
        self::log( 'Aggressive backlog rules=' . wp_json_encode( $rules ) );
        self::log( 'No-lock mode active: every cron hit runs a sweep immediately.' );

        update_option( self::OPTION_LAST_RUN, time(), false );

        try {
            if ( ! class_exists( '\Caricove\Logistics\Core\ShipmentManager' ) || ! class_exists( __NAMESPACE__ . '\Engine' ) ) {
                self::log( 'Sweep aborted: ShipmentManager or Engine unavailable.' );
                return;
            }

            $shipment_cpt = 'cc_shipment';
            $status_key   = class_exists( '\Caricove\Logistics\Core\Schema' ) ? Schema::META_SHIPMENT_STATUS : '_cc_shipment_status';
            $courier_key  = class_exists( '\Caricove\Logistics\Core\Schema' ) ? Schema::META_SHIPMENT_COURIER_ID : '_cc_shipment_courier_id';

            $q = new \WP_Query(
                array(
                    'post_type'              => $shipment_cpt,
                    'post_status'            => 'any',
                    'posts_per_page'         => -1,
                    'fields'                 => 'ids',
                    'no_found_rows'          => true,
                    'update_post_meta_cache' => false,
                    'update_post_term_cache' => false,
                    'meta_query'             => array(
                        array(
                            'key'     => $status_key,
                            'value'   => 'ready_for_assignment',
                            'compare' => '=',
                        ),
                    ),
                    'orderby'                => 'ID',
                    'order'                  => 'ASC',
                )
            );

            $ready_ids = array_map( 'intval', (array) $q->posts );
            self::set_ready_ids( $ready_ids );
            self::log( 'Ready shipment IDs=' . implode( ',', $ready_ids ) );

            if ( empty( $ready_ids ) ) {
                self::log( 'Sweep found no ready_for_assignment shipments.' );
                return;
            }

            $max_attempts = max( 1, intval( $rules['max_attempts'] ?? 5 ) );

            foreach ( $ready_ids as $shipment_id ) {
                $shipment_id = intval( $shipment_id );
                if ( ! $shipment_id ) {
                    continue;
                }

                try {
                    self::mark_shipment( $shipment_id, 'seen_in_ready_query', true );
                    self::log( 'Shipment #' . $shipment_id . ' begin' );

                    $summary = ShipmentManager::get_shipment_summary( $shipment_id );
                    if ( empty( $summary ) || ! is_array( $summary ) ) {
                        self::mark_shipment( $shipment_id, 'summary_empty', true );
                        self::mark_shipment( $shipment_id, 'skip_reason', 'summary_empty' );
                        self::log( 'Shipment #' . $shipment_id . ' skipped: empty summary' );
                        continue;
                    }

                    $status = (string) ( $summary['status'] ?? '' );
                    self::mark_shipment( $shipment_id, 'summary_status', $status );
                    self::log( 'Shipment #' . $shipment_id . ' summary_status=' . $status );

                    if ( $status !== 'ready_for_assignment' ) {
                        self::mark_shipment( $shipment_id, 'skip_reason', 'summary_status_not_ready' );
                        self::log( 'Shipment #' . $shipment_id . ' skipped: summary status drifted to ' . $status );
                        continue;
                    }

                    if (
                        class_exists( '\Caricove\Logistics\Core\AutoAssign' )
                        && method_exists( '\Caricove\Logistics\Core\AutoAssign', 'get_offer_window_state' )
                    ) {
                        $offer_state = \Caricove\Logistics\Core\AutoAssign::get_offer_window_state(
                            $shipment_id,
                            (array) $summary,
                            intval( $summary['offer_courier_id'] ?? 0 )
                        );

                        if ( ! empty( $offer_state['is_live'] ) ) {
                            self::mark_shipment( $shipment_id, 'skip_reason', 'live_offer_window' );
                            self::log( 'Shipment #' . $shipment_id . ' skipped: operational offer window still live.' );
                            continue;
                        }

                        if ( ! empty( $offer_state['is_expired'] )
                            && method_exists( '\Caricove\Logistics\Core\AutoAssign', 'maybe_finalize_expired_offer' ) ) {
                            \Caricove\Logistics\Core\AutoAssign::maybe_finalize_expired_offer(
                                $shipment_id,
                                intval( $offer_state['offer_courier_id'] ?? 0 ),
                                (array) $summary
                            );
                            $summary = (array) ShipmentManager::get_shipment_summary( $shipment_id );
                        }
                    }

                    self::clear_stale_assignment_residue( $shipment_id, $courier_key );

                    $attempts = intval( get_post_meta( $shipment_id, self::META_REDISPATCH_ATTEMPTS, true ) );
                    self::mark_shipment( $shipment_id, 'attempts_before', $attempts );
                    self::log( 'Shipment #' . $shipment_id . ' attempts_before=' . $attempts );

                    if ( $attempts >= $max_attempts ) {
                        self::mark_shipment( $shipment_id, 'skip_reason', 'hard_cap_reached' );
                        self::mark_shipment( $shipment_id, 'hard_capped', true );
                        self::log( 'Shipment #' . $shipment_id . ' skipped: already at hard cap ' . $max_attempts );
                        continue;
                    }

                    self::mark_shipment( $shipment_id, 'touched', true );
                    self::mark_shipment( $shipment_id, 'dispatch_planned', true );

                    self::redispatch_single(
                        $shipment_id,
                        (array) $summary,
                        $attempts,
                        $max_attempts
                    );
                } catch ( \Throwable $e ) {
                    self::mark_shipment( $shipment_id, 'shipment_exception', $e->getMessage() );
                    self::mark_shipment( $shipment_id, 'skip_reason', 'shipment_exception' );
                    self::log(
                        sprintf(
                            'Shipment #%d exception: %s in %s:%d',
                            $shipment_id,
                            $e->getMessage(),
                            $e->getFile(),
                            $e->getLine()
                        )
                    );
                    continue;
                }
            }
        } catch ( \Throwable $e ) {
            self::log(
                sprintf(
                    'Sweep fatal: %s in %s:%d',
                    $e->getMessage(),
                    $e->getFile(),
                    $e->getLine()
                )
            );
            throw $e;
        } finally {
            self::finish_sweep();
            self::persist_current_state();
        }
    }

    protected static function clear_stale_assignment_residue( $shipment_id, $courier_key ) {
        $courier_id = intval( get_post_meta( $shipment_id, $courier_key, true ) );

        self::mark_shipment( $shipment_id, 'courier_before_clear', $courier_id );

        if ( $courier_id > 0 ) {
            self::log(
                sprintf(
                    'Shipment #%d clearing stale canonical courier assignment residue courier_id=%d',
                    $shipment_id,
                    $courier_id
                )
            );
        }

        update_post_meta( $shipment_id, $courier_key, 0 );

        if ( class_exists( '\Caricove\Logistics\Core\Schema' ) ) {
            delete_post_meta( $shipment_id, Schema::META_SHIPMENT_ASSIGNMENT_ACCEPTED_AT );
        }
    }

    protected static function redispatch_single( $shipment_id, array $summary, $attempts, $max_attempts ) {
        $shipment_id = intval( $shipment_id );
        if ( ! $shipment_id ) {
            return;
        }

        $status = (string) ( $summary['status'] ?? '' );
        if ( $status !== 'ready_for_assignment' ) {
            self::mark_shipment( $shipment_id, 'skip_reason', 'status_changed_before_increment' );
            self::log( 'Shipment #' . $shipment_id . ' redispatch aborted: status became ' . $status );
            return;
        }

        $attempts = intval( $attempts ) + 1;
        update_post_meta( $shipment_id, self::META_REDISPATCH_ATTEMPTS, $attempts );
        self::mark_shipment( $shipment_id, 'attempts_after', $attempts );
        self::mark_shipment( $shipment_id, 'incremented', true );
        self::log( 'Shipment #' . $shipment_id . ' attempts_after=' . $attempts . ' of ' . $max_attempts );

        if ( $attempts > $max_attempts ) {
            self::mark_shipment( $shipment_id, 'skip_reason', 'increment_exceeded_hard_cap' );
            self::log( 'Shipment #' . $shipment_id . ' exceeded hard cap after increment; aborting.' );
            return;
        }

        self::mark_shipment( $shipment_id, 'dispatch_called', true );
        self::log( 'Shipment #' . $shipment_id . ' entering forced aggressive redispatch.' );

        $context = array(
            'forced_backlog'   => true,
            'attempt_number'   => $attempts,
            'max_attempts'     => $max_attempts,
            'source'           => 'backlog_aggressive',
            'ignore_overrides' => true,
            'backlog_sweep_id' => self::current_sweep_id(),
        );

        self::set_force_marker( $shipment_id, $context );
        try {
            Engine::on_shipment_ready(
                $shipment_id,
                intval( $summary['order_id'] ?? 0 ),
                intval( $summary['vendor_id'] ?? 0 ),
                $context
            );
        } catch ( \Throwable $e ) {
            self::mark_shipment( $shipment_id, 'dispatch_exception', $e->getMessage() );
            self::mark_shipment( $shipment_id, 'engine_last_note', 'dispatch_exception' );
            self::log(
                sprintf(
                    'Shipment #%d dispatch exception: %s in %s:%d',
                    $shipment_id,
                    $e->getMessage(),
                    $e->getFile(),
                    $e->getLine()
                )
            );
        } finally {
            self::clear_force_marker( $shipment_id );
        }

        self::mark_shipment( $shipment_id, 'dispatch_returned', true );
        self::log( 'Shipment #' . $shipment_id . ' forced aggressive redispatch returned to backlog.' );
        self::reassert_ready_if_needed( $shipment_id, $max_attempts );
    }

    protected static function force_marker_key( $shipment_id ) {
        return self::FORCE_MARKER_PREFIX . intval( $shipment_id );
    }

    protected static function set_force_marker( $shipment_id, $context = array() ) {
        set_transient( self::force_marker_key( $shipment_id ), is_array( $context ) ? $context : array(), 5 * MINUTE_IN_SECONDS );
    }

    protected static function clear_force_marker( $shipment_id ) {
        delete_transient( self::force_marker_key( $shipment_id ) );
    }

    protected static function reassert_ready_if_needed( $shipment_id, $max_attempts ) {
        $shipment_id = intval( $shipment_id );
        if ( ! $shipment_id ) {
            return;
        }

        $summary   = ShipmentManager::get_shipment_summary( $shipment_id );
        $status    = is_array( $summary ) ? (string) ( $summary['status'] ?? '' ) : '';
        $attempts  = intval( get_post_meta( $shipment_id, self::META_REDISPATCH_ATTEMPTS, true ) );
        self::mark_shipment( $shipment_id, 'post_dispatch_status', $status );
        self::mark_shipment( $shipment_id, 'post_dispatch_attempts', $attempts );

        if ( $attempts >= intval( $max_attempts ) ) {
            self::log( 'Shipment #' . $shipment_id . ' post-dispatch hard cap reached; not reasserting ready.' );
            return;
        }

        $courier_key = class_exists( '\Caricove\Logistics\Core\Schema' ) ? Schema::META_SHIPMENT_COURIER_ID : '_cc_shipment_courier_id';
        $courier_id  = intval( get_post_meta( $shipment_id, $courier_key, true ) );
        self::mark_shipment( $shipment_id, 'post_dispatch_courier_id', $courier_id );

        if ( $courier_id > 0 ) {
            self::log( 'Shipment #' . $shipment_id . ' post-dispatch has courier #' . $courier_id . '; not reasserting ready.' );
            return;
        }

        if ( $status !== 'ready_for_assignment' ) {
            self::log( 'Shipment #' . $shipment_id . ' post-dispatch drifted to status=' . $status . '; reasserting ready_for_assignment.' );
            if ( method_exists( '\Caricove\Logistics\Core\ShipmentManager', 'set_shipment_status' ) ) {
                ShipmentManager::set_shipment_status(
                    $shipment_id,
                    'ready_for_assignment',
                    array(
                        'source' => 'dispatcher_backlog_force_reassert',
                        'reason' => 'forced_backlog_retry',
                    )
                );
            } else {
                $status_key = class_exists( '\Caricove\Logistics\Core\Schema' ) ? Schema::META_SHIPMENT_STATUS : '_cc_shipment_status';
                update_post_meta( $shipment_id, $status_key, 'ready_for_assignment' );
            }
            self::mark_shipment( $shipment_id, 'reasserted_ready', true );
        }
    }

    public static function state() {
        $state = get_option( self::OPTION_LAST_SWEEP_STATE, array() );
        return is_array( $state ) ? $state : array();
    }

    public static function clear_logs() {
        update_option( self::OPTION_LOG_RING, array(), false );
    }

    public static function clear_debug() {
        self::clear_logs();
        update_option( self::OPTION_LAST_SWEEP_STATE, array(), false );
    }

    public static function persisted_logs() {
        $ring = get_option( self::OPTION_LOG_RING, array() );
        return is_array( $ring ) ? $ring : array();
    }

    public static function current_sweep_id() {
        $state = self::state();
        return (string) ( $state['sweep_id'] ?? '' );
    }

    public static function engine_note( $shipment_id, $message, $data = array() ) {
        $shipment_id = intval( $shipment_id );
        $payload     = is_array( $data ) ? $data : array();

        if ( $shipment_id > 0 ) {
            self::mark_shipment( $shipment_id, 'engine_last_note', $message );
            if ( ! empty( $payload ) ) {
                foreach ( $payload as $key => $value ) {
                    self::mark_shipment( $shipment_id, 'engine_' . sanitize_key( (string) $key ), $value );
                }
            }
        }

        self::log( 'Shipment #' . $shipment_id . ' engine: ' . $message . ( ! empty( $payload ) ? ' data=' . wp_json_encode( $payload ) : '' ) );
    }

    protected static function reset_sweep_state( $sweep_id, array $rules ) {
        self::persist_state(
            array(
                'patch_version'        => self::PATCH_VERSION,
                'sweep_id'             => (string) $sweep_id,
                'started_at_gmt'       => gmdate( 'Y-m-d H:i:s' ),
                'finished_at_gmt'      => '',
                'rules'                => $rules,
                'ready_ids'            => array(),
                'ready_count'          => 0,
                'shipments'            => array(),
                'touched_ids'          => array(),
                'untouched_ids'        => array(),
                'hard_capped_ids'      => array(),
                'processed_count'      => 0,
                'untouched_count'      => 0,
                'hard_capped_count'    => 0,
                'state_written_at_gmt' => gmdate( 'Y-m-d H:i:s' ),
            )
        );
    }

    protected static function set_ready_ids( array $ready_ids ) {
        $state                  = self::state();
        $state['patch_version'] = self::PATCH_VERSION;
        $state['ready_ids']     = array_values( array_map( 'intval', $ready_ids ) );
        $state['ready_count']   = count( $state['ready_ids'] );

        foreach ( $state['ready_ids'] as $shipment_id ) {
            if ( ! isset( $state['shipments'][ $shipment_id ] ) || ! is_array( $state['shipments'][ $shipment_id ] ) ) {
                $state['shipments'][ $shipment_id ] = array(
                    'shipment_id' => $shipment_id,
                    'touched'     => false,
                );
            }
        }

        self::persist_state( $state );
    }

    protected static function mark_shipment( $shipment_id, $key, $value ) {
        $shipment_id = intval( $shipment_id );
        if ( ! $shipment_id ) {
            return;
        }

        $state = self::state();
        if ( ! isset( $state['shipments'][ $shipment_id ] ) || ! is_array( $state['shipments'][ $shipment_id ] ) ) {
            $state['shipments'][ $shipment_id ] = array(
                'shipment_id' => $shipment_id,
                'touched'     => false,
            );
        }

        $state['patch_version'] = self::PATCH_VERSION;
        $state['shipments'][ $shipment_id ][ $key ] = $value;

        if ( $key === 'touched' && $value ) {
            $state['shipments'][ $shipment_id ]['touched'] = true;
        }

        self::persist_state( $state );
    }

    protected static function finish_sweep() {
        $state     = self::state();
        $shipments = isset( $state['shipments'] ) && is_array( $state['shipments'] ) ? $state['shipments'] : array();
        $ready_ids = isset( $state['ready_ids'] ) && is_array( $state['ready_ids'] ) ? $state['ready_ids'] : array();

        $touched_ids     = array();
        $untouched_ids   = array();
        $hard_capped_ids = array();

        foreach ( $ready_ids as $shipment_id ) {
            $row = isset( $shipments[ $shipment_id ] ) && is_array( $shipments[ $shipment_id ] ) ? $shipments[ $shipment_id ] : array();
            if ( ! empty( $row['touched'] ) ) {
                $touched_ids[] = $shipment_id;
            } else {
                $untouched_ids[] = $shipment_id;
            }
            if ( ! empty( $row['hard_capped'] ) ) {
                $hard_capped_ids[] = $shipment_id;
            }
        }

        $state['patch_version']     = self::PATCH_VERSION;
        $state['touched_ids']       = array_values( $touched_ids );
        $state['untouched_ids']     = array_values( $untouched_ids );
        $state['hard_capped_ids']   = array_values( $hard_capped_ids );
        $state['processed_count']   = count( $touched_ids );
        $state['untouched_count']   = count( $untouched_ids );
        $state['hard_capped_count'] = count( $hard_capped_ids );
        $state['finished_at_gmt']   = gmdate( 'Y-m-d H:i:s' );

        self::persist_state( $state );

        self::log(
            sprintf(
                'Sweep complete. ready=%d touched=%d untouched=%d hard_capped=%d untouched_ids=%s',
                intval( $state['ready_count'] ?? 0 ),
                intval( $state['processed_count'] ?? 0 ),
                intval( $state['untouched_count'] ?? 0 ),
                intval( $state['hard_capped_count'] ?? 0 ),
                implode( ',', $untouched_ids )
            )
        );
    }

    protected static function persist_current_state() {
        $state = self::state();
        if ( ! is_array( $state ) ) {
            $state = array();
        }
        $state['patch_version']        = self::PATCH_VERSION;
        $state['state_written_at_gmt'] = gmdate( 'Y-m-d H:i:s' );
        self::persist_state( $state );
    }

    protected static function persist_state( array $state ) {
        $state['patch_version'] = self::PATCH_VERSION;
        if ( empty( $state['state_written_at_gmt'] ) ) {
            $state['state_written_at_gmt'] = gmdate( 'Y-m-d H:i:s' );
        }
        update_option( self::OPTION_LAST_SWEEP_STATE, $state, false );
    }

    protected static function log( $message ) {
        $line = '[' . gmdate( 'Y-m-d H:i:s' ) . '] [Backlog] ' . $message;

        $ring   = get_option( self::OPTION_LOG_RING, array() );
        $ring   = is_array( $ring ) ? $ring : array();
        $ring[] = $line;

        if ( count( $ring ) > self::MAX_LOG_LINES ) {
            $ring = array_slice( $ring, - self::MAX_LOG_LINES );
        }

        update_option( self::OPTION_LOG_RING, $ring, false );
        error_log( '[Caricove Backlog] ' . $line );
    }
}

Backlog::boot();
