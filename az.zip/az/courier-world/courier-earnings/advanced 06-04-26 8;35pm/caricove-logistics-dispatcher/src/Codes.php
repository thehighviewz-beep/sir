<?php
namespace Caricove\Logistics\Dispatcher;

use Caricove\Logistics\Core\ShipmentManager;
use Caricove\Logistics\Core\Schema;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Codes
 *
 * Responsible ONLY for:
 *  - Generating Pickup Codes
 *  - Generating Delivery Codes
 * 
 * Runs when orders transition into real fulfillment states:
 *  - payment complete
 *  - processing
 *  - completed
 *
 * This module is 100% isolated and compatible with Dispatcher V2.
 * Drop into /src and add Codes::boot() in the loader.
 */
class Codes {

    protected static $booted = false;

    /**
     * Register event listeners.
     */
    public static function boot() {
        if ( self::$booted ) {
            return;
        }

        self::$booted = true;

        add_action( 'woocommerce_payment_complete',        [ __CLASS__, 'generate_for_order' ], 10, 1 );
        add_action( 'woocommerce_order_status_processing', [ __CLASS__, 'generate_for_order' ], 10, 1 );
        add_action( 'woocommerce_order_status_completed',  [ __CLASS__, 'generate_for_order' ], 10, 1 );

        Logger::log('Codes module booted.');
    }

    /**
     * Generate pickup & delivery codes for all shipments tied to an order.
     *
     * @param int|\WC_Order $order
     */
    public static function generate_for_order( $order ) {

        // Normalize order ID.
        if ( $order instanceof \WC_Order ) {
            $order_id = $order->get_id();
        } else {
            $order_id = intval( $order );
        }

        if ( ! $order_id ) {
            return;
        }

        // Ensure core classes exist.
        if ( ! class_exists( ShipmentManager::class ) || ! class_exists( Schema::class ) ) {
            Logger::log('Codes: Core missing (ShipmentManager/Schema). Cannot generate codes.');
            return;
        }

        // Pull all shipments for this order.
        $shipments = ShipmentManager::get_shipments_for_order( $order_id );
        if ( empty( $shipments ) ) {
            Logger::log("Codes: Order #{$order_id} has no shipments.");
            return;
        }

        foreach ( $shipments as $shipment_id ) {

            $shipment_id = intval( $shipment_id );
            if ( ! $shipment_id ) {
                continue;
            }

            // Pickup Code
            $pickup_code = get_post_meta( 
                $shipment_id, 
                Schema::META_SHIPMENT_PICKUP_CODE, 
                true 
            );

            if ( empty( $pickup_code ) ) {
                $pickup_code = self::generate_6_digit();
                update_post_meta( 
                    $shipment_id, 
                    Schema::META_SHIPMENT_PICKUP_CODE, 
                    $pickup_code 
                );
            }

            // Delivery Code
            $delivery_code = get_post_meta( 
                $shipment_id, 
                Schema::META_SHIPMENT_DELIVERY_CODE, 
                true 
            );

            if ( empty( $delivery_code ) ) {
                $delivery_code = self::generate_6_digit();
                update_post_meta( 
                    $shipment_id, 
                    Schema::META_SHIPMENT_DELIVERY_CODE, 
                    $delivery_code 
                );
            }

            Logger::log(
                sprintf(
                    'Codes: Shipment #%d → PU=%s / DO=%s',
                    $shipment_id,
                    $pickup_code,
                    $delivery_code
                )
            );
        }
    }

    /**
     * Generate a 6-digit numeric code (leading zeros allowed).
     */
    protected static function generate_6_digit() {
        return str_pad( (string) wp_rand( 0, 999999 ), 6, '0', STR_PAD_LEFT );
    }
}

Codes::boot();
