<?php
namespace Caricove\Logistics\Dispatcher;

use Caricove\Logistics\Core\CourierProfile;
use Caricove\Logistics\Core\ShipmentManager;
use Caricove\Logistics\Core\StatusMachine;
use Caricove\Logistics\Core\ZoneResolver;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class CourierPool {

    const PATCH_VERSION = '2026-04-05-unified-truth';

    public static function get_candidates( array $shipment, array $settings, array $overrides, array $debug_context = array() ) {
        $candidates = array();
        $debug_context['skip_diagnostic_scores'] = true;

        foreach ( self::get_candidate_diagnostics( $shipment, $settings, $overrides, $debug_context ) as $row ) {
            if ( empty( $row['eligible'] ) || empty( $row['profile'] ) ) {
                continue;
            }

            $profile = $row['profile'];
            $profile['evaluation'] = $row['evaluation'];
            $profile['user_id']    = intval( $profile['id'] ?? $row['user_id'] ?? 0 );

            $candidates[ intval( $profile['user_id'] ) ] = $profile;
        }

        return apply_filters( 'cc_dispatcher_courier_pool', $candidates, $shipment, $settings, $overrides );
    }

    public static function get_candidate_diagnostics( array $shipment, array $settings, array $overrides, array $debug_context = array(), $limit = 0 ) {
        $users = self::query_couriers( false, $settings, $shipment );
        $rows  = array();

        if ( ! empty( $users ) ) {
            $user_ids = array_values(
                array_filter(
                    array_map(
                        function ( $user ) {
                            return intval( $user->ID ?? 0 );
                        },
                        $users
                    )
                )
            );

            if ( ! empty( $user_ids ) ) {
                update_meta_cache( 'user', $user_ids );
            }
        }

        $skip_scores = ! empty( $debug_context['skip_diagnostic_scores'] );

        foreach ( $users as $user ) {
            $uid = intval( $user->ID ?? 0 );
            if ( ! $uid ) {
                continue;
            }

            $profile = CourierProfile::get_profile( $uid );
            if ( ! is_array( $profile ) ) {
                $profile = array();
            }
            $profile['id'] = $uid;
            $profile['display_name'] = $user->display_name ?? '';
            $profile['user_email']   = $user->user_email ?? '';

            $evaluation = self::evaluate_courier( $profile, $shipment, $settings, $overrides, $debug_context );
            $score      = array();

            if ( ! $skip_scores && ! empty( $evaluation['eligible'] ) ) {
                $score = Scoring::score( $shipment, $profile, $settings, $overrides );
            }

            $rows[] = array(
                'user_id'     => $uid,
                'profile'     => $profile,
                'eligible'    => ! empty( $evaluation['eligible'] ),
                'evaluation'  => $evaluation,
                'score'       => $score,
                'reason'      => (string) ( $evaluation['reason'] ?? 'unknown' ),
            );
        }

        usort(
            $rows,
            function ( $a, $b ) {
                if ( $a['eligible'] !== $b['eligible'] ) {
                    return $a['eligible'] ? -1 : 1;
                }

                $as = floatval( $a['score']['total'] ?? 0 );
                $bs = floatval( $b['score']['total'] ?? 0 );
                if ( abs( $as - $bs ) > 0.02 ) {
                    return ( $as > $bs ) ? -1 : 1;
                }

                $apr = floatval( $a['score']['pickup_readiness'] ?? 0 );
                $bpr = floatval( $b['score']['pickup_readiness'] ?? 0 );
                if ( $apr !== $bpr ) {
                    return ( $apr > $bpr ) ? -1 : 1;
                }

                $afs = floatval( $a['score']['fit_score'] ?? 0 );
                $bfs = floatval( $b['score']['fit_score'] ?? 0 );
                if ( $afs !== $bfs ) {
                    return ( $afs > $bfs ) ? -1 : 1;
                }

                $als = floatval( $a['score']['load_score'] ?? 0 );
                $bls = floatval( $b['score']['load_score'] ?? 0 );
                if ( $als !== $bls ) {
                    return ( $als > $bls ) ? -1 : 1;
                }

                $aps = floatval( $a['score']['performance_score'] ?? 0 );
                $bps = floatval( $b['score']['performance_score'] ?? 0 );
                if ( $aps !== $bps ) {
                    return ( $aps > $bps ) ? -1 : 1;
                }

                $ad = floatval( $a['evaluation']['pickup_distance_km'] ?? 999999 );
                $bd = floatval( $b['evaluation']['pickup_distance_km'] ?? 999999 );
                if ( $ad !== $bd ) {
                    return ( $ad < $bd ) ? -1 : 1;
                }

                return intval( $a['user_id'] ) <=> intval( $b['user_id'] );
            }
        );

        if ( $limit > 0 ) {
            $rows = array_slice( $rows, 0, max( 1, intval( $limit ) ) );
        }

        return $rows;
    }

    public static function evaluate_courier_by_id( $courier_id, array $shipment, array $settings, array $overrides = array(), array $debug_context = array() ) {
        $courier_id = intval( $courier_id );
        if ( ! $courier_id ) {
            return array(
                'eligible' => false,
                'reason'   => 'profile_empty',
            );
        }

        $profile = CourierProfile::get_profile( $courier_id );
        if ( ! is_array( $profile ) ) {
            $profile = array();
        }
        $profile['id'] = $courier_id;

        return self::evaluate_courier( $profile, $shipment, $settings, $overrides, $debug_context );
    }

    public static function evaluate_courier( array $profile, array $shipment, array $settings, array $overrides = array(), array $debug_context = array() ) {
        unset( $debug_context );

        $profile = is_array( $profile ) ? $profile : array();
        $shipment = is_array( $shipment ) ? $shipment : array();
        $settings = is_array( $settings ) ? $settings : array();
        $overrides = is_array( $overrides ) ? $overrides : array();

        $courier_id = intval( $profile['id'] ?? $profile['user_id'] ?? 0 );
        if ( ! $courier_id ) {
            return self::fail( 'profile_empty', $profile, $shipment, $settings );
        }

        $profile['id'] = $courier_id;

        $evaluation = self::base_context( $profile, $shipment, $settings );
        $evaluation['active_jobs'] = self::get_active_jobs_for_courier( $courier_id );
        $evaluation['max_active_jobs'] = max( 1, intval( $profile['max_active_jobs'] ?? 0 ) ?: 5 );
        $evaluation['pickup_distance_km'] = self::get_pickup_distance_km( $profile, $shipment );
        $evaluation['pickup_distance_cap_km'] = self::get_pickup_distance_cap_km( $profile, $settings );
        $evaluation['preference_band'] = self::get_preference_band( $profile );
        $evaluation['declined_couriers'] = array_values( array_unique( array_filter( array_map( 'intval', (array) ( $shipment['declined_couriers'] ?? array() ) ) ) ) );

        // 1. Online.
        if ( sanitize_key( (string) ( $profile['status'] ?? '' ) ) !== 'online' ) {
            return self::fail( 'offline', $profile, $shipment, $settings, $evaluation );
        }

        // 2. Heartbeat freshness.
        $require_fresh = ! empty( $settings['require_fresh_heartbeat'] );
        $last_seen_ts  = intval( $profile['last_seen_ts'] ?? 0 );
        $heartbeat_max_age = max( 30, intval( $settings['heartbeat_max_age'] ?? 300 ) );
        if ( $require_fresh && ( ! $last_seen_ts || ( time() - $last_seen_ts ) > $heartbeat_max_age ) ) {
            return self::fail( 'heartbeat_stale', $profile, $shipment, $settings, $evaluation );
        }

        // 3. Not locked / blocked.
        if ( self::is_courier_blocked( $courier_id, $overrides ) ) {
            return self::fail( 'courier_blocked', $profile, $shipment, $settings, $evaluation );
        }
        if ( self::is_courier_locked( $profile ) ) {
            return self::fail( 'courier_locked', $profile, $shipment, $settings, $evaluation );
        }

        // 4. Carry fit.
      $carry_context = self::courier_carry_context( $profile, $shipment );
        $evaluation = array_merge( $evaluation, $carry_context );
        if ( empty( $carry_context['carry_ok'] ) ) {
            $carry_reason = sanitize_key( (string) ( $carry_context['carry_failure_reason'] ?? '' ) );
            if ( $carry_reason === '' ) {
                $carry_reason = 'vehicle_capacity_mismatch';
            }
            return self::fail( $carry_reason, $profile, $shipment, $settings, $evaluation );
        }

        // 5. Max active jobs.
        if ( ! empty( $settings['honor_courier_max_active_jobs'] ) && $evaluation['active_jobs'] >= $evaluation['max_active_jobs'] ) {
            return self::fail( 'max_active_jobs_reached', $profile, $shipment, $settings, $evaluation );
        }

        // 6. Real courier -> pickup sanity.
        if ( empty( $shipment['pickup_coords'] ) ) {
            return self::fail( 'pickup_coords_missing', $profile, $shipment, $settings, $evaluation );
        }
        if ( $evaluation['pickup_distance_km'] > $evaluation['pickup_distance_cap_km'] ) {
            return self::fail( 'pickup_distance_exceeded', $profile, $shipment, $settings, $evaluation );
        }

        // 7. Travel preference band gate.
        if ( self::band_rank( $evaluation['shipment_band'] ) > self::band_rank( $evaluation['preference_band'] ) ) {
            return self::fail( 'distance_preference_exceeded', $profile, $shipment, $settings, $evaluation );
        }

        // 8. Declined / expired during this dispatch cycle.
        if ( in_array( $courier_id, $evaluation['declined_couriers'], true ) ) {
            return self::fail( 'already_declined_this_cycle', $profile, $shipment, $settings, $evaluation );
        }

        // 9. Zone / vendor / manual-only restrictions.
        $vendor_id = intval( $shipment['vendor_id'] ?? 0 );
        if ( $vendor_id && ! empty( $overrides['vendor_blocklist'][ $vendor_id ] ) ) {
            return self::fail( 'vendor_blocked', $profile, $shipment, $settings, $evaluation );
        }
        if ( $vendor_id && ! empty( $overrides['vendor_manual_only'][ $vendor_id ] ) ) {
            return self::fail( 'vendor_manual_only', $profile, $shipment, $settings, $evaluation );
        }
        if ( ! self::courier_matches_zone_policy( $profile, $shipment, $settings ) ) {
            return self::fail( 'zone_restriction_failed', $profile, $shipment, $settings, $evaluation );
        }

        $shipment_id = intval( $shipment['shipment_id'] ?? 0 );
        if ( $shipment_id && ! empty( $overrides['shipment_locks'][ $shipment_id ] ) ) {
            return self::fail( 'shipment_locked', $profile, $shipment, $settings, $evaluation );
        }

        $forced_courier = $shipment_id && isset( $overrides['shipment_forced_courier'][ $shipment_id ] )
            ? intval( $overrides['shipment_forced_courier'][ $shipment_id ] )
            : 0;
        if ( $forced_courier > 0 && $forced_courier !== $courier_id ) {
            return self::fail( 'forced_to_other_courier', $profile, $shipment, $settings, $evaluation );
        }

        $evaluation['eligible'] = true;
        $evaluation['reason']   = 'eligible';

        return $evaluation;
    }

    public static function get_active_jobs_for_courier( $courier_id ) {
        $courier_id = intval( $courier_id );
        if ( ! $courier_id ) {
            return 0;
        }

        $value = apply_filters(
            'cc_dispatcher_courier_active_jobs',
            null,
            array( 'user_id' => $courier_id, 'id' => $courier_id ),
            array()
        );

        if ( $value !== null && $value !== false && $value !== '' ) {
            return max( 0, intval( $value ) );
        }

        return self::count_active_jobs_for_courier( $courier_id );
    }

    public static function count_active_jobs_for_courier( $courier_id ) {
        $courier_id = intval( $courier_id );
        if ( ! $courier_id ) {
            return 0;
        }

        $statuses = StatusMachine::get_canonical_active_job_statuses();
        if ( empty( $statuses ) ) {
            return 0;
        }

        $query = new \WP_Query(
            array(
                'post_type'      => 'cc_shipment',
                'post_status'    => 'any',
                'posts_per_page' => 200,
                'fields'         => 'ids',
                'no_found_rows'  => true,
                'meta_query'     => array(
                    'relation' => 'AND',
                    array(
                        'key'   => \Caricove\Logistics\Core\Schema::META_SHIPMENT_COURIER_ID,
                        'value' => $courier_id,
                    ),
                    array(
                        'key'     => \Caricove\Logistics\Core\Schema::META_SHIPMENT_STATUS,
                        'value'   => $statuses,
                        'compare' => 'IN',
                    ),
                ),
            )
        );

        return $query->have_posts() ? count( (array) $query->posts ) : 0;
    }

    public static function get_preference_band( array $profile ) {
        $range_pref = '';
        if ( ! empty( $profile['ccv_settings'] ) && is_array( $profile['ccv_settings'] ) ) {
            $range_pref = sanitize_key( (string) ( $profile['ccv_settings']['range_pref'] ?? '' ) );
        }

        if ( $range_pref === '' ) {
            $courier_id = intval( $profile['id'] ?? $profile['user_id'] ?? 0 );
            if ( $courier_id ) {
                $range_pref = sanitize_key( (string) get_user_meta( $courier_id, '_ccv_range_pref', true ) );
            }
        }

        $map = array(
            'very_close'        => 'very_short',
            'local_area'        => 'short',
            'across_georgetown' => 'medium',
            'extended_routes'   => 'long',
        );

        if ( isset( $map[ $range_pref ] ) ) {
            return $map[ $range_pref ];
        }

        return 'long';
    }

    public static function get_pickup_distance_cap_km( array $profile, array $settings ) {
        $global_cap = max( 1.0, floatval( $settings['max_distance_km'] ?? 15.0 ) );
        $saved_cap  = floatval( $profile['radius_km'] ?? 0 );

        if ( $saved_cap > 0 ) {
            return max( 1.0, min( $global_cap, $saved_cap ) );
        }

        return $global_cap;
    }

    public static function get_pickup_distance_km( array $profile, array $shipment ) {
        return Scoring::estimate_distance_km( $profile, (string) ( $shipment['pickup_coords'] ?? '' ) );
    }

    protected static function query_couriers( $online_only, array $settings, array $shipment ) {
        $limit = max( 10, intval( $settings['candidate_limit'] ?? 200 ) );
        $limit = min( 1000, $limit );

        $args = array(
            'role'    => CourierProfile::ROLE_COURIER,
            'number'  => $online_only ? $limit : max( $limit, 500 ),
            'fields'  => 'all',
            'orderby' => 'ID',
            'order'   => 'ASC',
        );

        if ( $online_only ) {
            $args['meta_query'] = array(
                array(
                    'key'   => CourierProfile::META_STATUS,
                    'value' => 'online',
                ),
            );
        }

        $args = apply_filters( 'cc_dispatcher_courier_pool_args', $args, $shipment, $settings );

        $user_query = new \WP_User_Query( $args );
        return (array) $user_query->get_results();
    }

    protected static function base_context( array $profile, array $shipment, array $settings ) {
        $shipment_band = sanitize_key( (string) ( $shipment['distance_band'] ?? $shipment['trip_band'] ?? '' ) );
        if ( $shipment_band === '' ) {
            $shipment_band = ShipmentManager::get_shipment_distance_band( intval( $shipment['shipment_id'] ?? 0 ) );
        }

        $vehicle_family = class_exists( ZoneResolver::class )
            ? ZoneResolver::normalize_vehicle_type( (string) ( $profile['vehicle_type'] ?? '' ) )
            : sanitize_key( (string) ( $profile['vehicle_type'] ?? '' ) );

        $shipment_weight_band = sanitize_key( (string) ( $shipment['weight_band'] ?? '' ) );
        $shipment_weight_kg   = max( 0.0, floatval( $shipment['total_weight'] ?? 0 ) );
        $vehicle_weight_cap_kg = class_exists( ZoneResolver::class )
            ? floatval( ZoneResolver::get_vehicle_weight_cap_kg( $vehicle_family ) )
            : 0.0;

        return array(
            'eligible'               => false,
            'reason'                 => 'unknown',
            'courier_id'             => intval( $profile['id'] ?? 0 ),
            'shipment_id'            => intval( $shipment['shipment_id'] ?? 0 ),
            'pickup_distance_km'     => 999999.0,
            'pickup_distance_cap_km' => max( 1.0, floatval( $settings['max_distance_km'] ?? 15.0 ) ),
            'shipment_band'          => $shipment_band,
            'preference_band'        => self::get_preference_band( $profile ),
            'shipment_weight_band'   => $shipment_weight_band,
            'shipment_weight_kg'     => $shipment_weight_kg,
            'vehicle_family'         => $vehicle_family,
            'vehicle_weight_cap_kg'  => $vehicle_weight_cap_kg,
            'route_source'           => sanitize_key( (string) ( $shipment['route_source'] ?? '' ) ),
            'route_detail_source'    => sanitize_key( (string) ( $shipment['route_detail_source'] ?? '' ) ),
            'route_provenance'       => sanitize_key( (string) ( $shipment['route_provenance'] ?? '' ) ),
        );
    }

    protected static function fail( $reason, array $profile, array $shipment, array $settings, array $evaluation = array() ) {
        $evaluation = array_merge( self::base_context( $profile, $shipment, $settings ), $evaluation );
        $evaluation['eligible'] = false;
        $evaluation['reason']   = sanitize_key( (string) $reason );
        return $evaluation;
    }

    protected static function band_rank( $band ) {
        $map = array(
            'very_short' => 1,
            'short'      => 2,
            'medium'     => 3,
            'long'       => 4,
        );

        $band = sanitize_key( (string) $band );
        return $map[ $band ] ?? 999;
    }

    protected static function courier_matches_zone_policy( array $profile, array $shipment, array $settings ) {
        if ( empty( $settings['require_zone_match'] ) ) {
            return true;
        }

        $courier_zone = sanitize_key( (string) ( $profile['zone_id'] ?? $profile['region'] ?? '' ) );
        $pickup_zone  = sanitize_key( (string) ( $shipment['pickup_zone_id'] ?? $shipment['origin_anchor'] ?? '' ) );

        if ( $courier_zone === '' || $pickup_zone === '' ) {
            return false;
        }

        if ( $courier_zone === $pickup_zone ) {
            return true;
        }

        $adjacent = array_map( 'sanitize_key', (array) ( $shipment['adjacent_pickup_zone_ids'] ?? $shipment['pickup_adjacent_zone_ids'] ?? array() ) );
        if ( ! empty( $settings['allow_adjacent_zone_match'] ) && in_array( $courier_zone, $adjacent, true ) ) {
            return true;
        }

        return false;
    }

    protected static function courier_carry_context( array $profile, array $shipment ) {
        $vehicle = class_exists( ZoneResolver::class )
            ? ZoneResolver::normalize_vehicle_type( (string) ( $profile['vehicle_type'] ?? '' ) )
            : sanitize_key( (string) ( $profile['vehicle_type'] ?? '' ) );

        $declared_capacity = sanitize_key( (string) ( $profile['capacity_class'] ?? '' ) );
        $shipment_size_band   = sanitize_key( (string) ( $shipment['size_band'] ?? '' ) );
        $shipment_weight_band = sanitize_key( (string) ( $shipment['weight_band'] ?? '' ) );
        $shipment_weight_kg   = max( 0.0, floatval( $shipment['total_weight'] ?? 0 ) );

        $size_rank = array( 'xs' => 0, 's' => 1, 'm' => 2, 'l' => 3, 'xl' => 4 );
        $shipment_size_rank = $size_rank[ $shipment_size_band ] ?? 2;

        $vehicle_size_limit = class_exists( ZoneResolver::class )
            ? sanitize_key( (string) ZoneResolver::get_vehicle_size_rank_limit( $vehicle ) )
            : 'm';
        $vehicle_size_rank = $size_rank[ $vehicle_size_limit ] ?? 2;
        $declared_rank = isset( $size_rank[ $declared_capacity ] ) ? $size_rank[ $declared_capacity ] : null;
        if ( $declared_rank !== null ) {
            $vehicle_size_rank = min( $vehicle_size_rank, $declared_rank );
        }

        $vehicle_weight_cap_kg = class_exists( ZoneResolver::class )
            ? floatval( ZoneResolver::get_vehicle_weight_cap_kg( $vehicle ) )
            : 0.0;

        $weight_band_ok = class_exists( ZoneResolver::class )
            ? ZoneResolver::is_vehicle_allowed_for_weight_band( $vehicle, $shipment_weight_band )
            : true;
        $weight_native = class_exists( ZoneResolver::class )
            ? ZoneResolver::is_vehicle_native_for_weight_band( $vehicle, $shipment_weight_band )
            : false;

        $size_fit_ok = $shipment_size_rank <= $vehicle_size_rank;
        $weight_cap_ok = true;
        $weight_cap_source = 'band_only';
        if ( $shipment_weight_kg > 0 && $vehicle_weight_cap_kg > 0 ) {
            $weight_cap_ok = ( $shipment_weight_kg <= $vehicle_weight_cap_kg );
            $weight_cap_source = 'numeric_cap';
        }

        $carry_failure_reason = '';
        if ( ! $size_fit_ok ) {
            $carry_failure_reason = 'size_band_blocked';
        } elseif ( ! $weight_band_ok ) {
            $carry_failure_reason = 'vehicle_band_blocked';
        } elseif ( ! $weight_cap_ok ) {
            $carry_failure_reason = 'numeric_weight_cap_exceeded';
        }

        return array(
         'carry_ok'               => ( $size_fit_ok && $weight_band_ok && $weight_cap_ok ),
            'carry_failure_reason'   => $carry_failure_reason,
            'vehicle_family'         => $vehicle,
            'declared_capacity_class'=> $declared_capacity,
            'vehicle_size_limit'     => $vehicle_size_limit,
            'vehicle_size_rank'      => $vehicle_size_rank,
            'vehicle_weight_cap_kg'  => $vehicle_weight_cap_kg,
            'shipment_size_band'     => $shipment_size_band,
            'shipment_size_rank'     => $shipment_size_rank,
            'shipment_weight_band'   => $shipment_weight_band,
            'shipment_weight_kg'     => $shipment_weight_kg,
            'size_fit_ok'            => $size_fit_ok,
            'weight_band_ok'         => (bool) $weight_band_ok,
            'weight_cap_ok'          => (bool) $weight_cap_ok,
            'weight_cap_source'      => $weight_cap_source,
            'vehicle_native_for_weight_band' => (bool) $weight_native,
        );
    }

    protected static function courier_can_carry( array $profile, $shipment_size_band, $shipment_weight_band ) {
        $shipment = array(
            'size_band'   => $shipment_size_band,
            'weight_band' => $shipment_weight_band,
            'total_weight'=> 0,
        );
        $ctx = self::courier_carry_context( $profile, $shipment );
        return ! empty( $ctx['carry_ok'] );
    }

    protected static function is_courier_locked( array $profile ) {
        $lock_reason = sanitize_key( (string) ( $profile['lock_reason'] ?? '' ) );
        if ( $lock_reason === '' ) {
            return false;
        }

        $expires_at = $profile['lock_expires_at'] ?? '';
        if ( $expires_at ) {
            $ts = strtotime( (string) $expires_at );
            if ( $ts && $ts < time() ) {
                return false;
            }
        }

        return true;
    }

    protected static function is_courier_blocked( $courier_id, array $overrides ) {
        $courier_id = intval( $courier_id );
        if ( ! $courier_id ) {
            return false;
        }

        if ( ! empty( $overrides['courier_blocklist'][ $courier_id ] ) ) {
            return true;
        }

        return class_exists( Overrides::class ) ? Overrides::is_courier_blocked( $courier_id ) : false;
    }
}

add_filter(
    'cc_dispatcher_courier_active_jobs',
    function ( $current, $profile, $shipment ) {
        unset( $shipment );
        if ( $current !== null && $current !== false && $current !== '' ) {
            return $current;
        }

        $courier_id = 0;
        if ( is_array( $profile ) ) {
            $courier_id = intval( $profile['id'] ?? $profile['user_id'] ?? 0 );
        }

        if ( ! $courier_id ) {
            return 0;
        }

        return CourierPool::count_active_jobs_for_courier( $courier_id );
    },
    10,
    3
);
