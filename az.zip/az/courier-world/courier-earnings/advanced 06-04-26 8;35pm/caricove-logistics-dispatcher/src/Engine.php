<?php
namespace Caricove\Logistics\Dispatcher;

use Caricove\Logistics\Core\AutoAssign;
use Caricove\Logistics\Core\ShipmentManager;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Engine {

    const PATCH_VERSION = '2026-04-03-aggressive-ready-5x-v4';

    protected static $booted = false;

    public static function boot() {
        if ( self::$booted ) {
            return;
        }

        self::$booted = true;

        add_action(
            'cc_shipment_ready_for_assignment',
            array( __CLASS__, 'on_shipment_ready' ),
            10,
            3
        );

        add_action(
            'caricove_dispatcher_retry_assignment',
            array( __CLASS__, 'handle_retry_assignment' ),
            10,
            2
        );

        add_action(
            'caricove_dispatcher_lock_cleared',
            array( __CLASS__, 'handle_retry_assignment' ),
            10,
            2
        );
    }

    public static function patch_version() {
        return self::PATCH_VERSION;
    }

    
public static function enforce_saved_radius_wins( $meta, $courier_id ) {
    unset( $courier_id );
    return $meta;
}

public static function handle_retry_assignment( $shipment_id, $reason = 'admin_retry' ) {
        $shipment_id = intval( $shipment_id );
        if ( ! $shipment_id ) {
            return;
        }

        $summary = ShipmentManager::get_shipment_summary( $shipment_id );
        if ( empty( $summary ) ) {
            Logger::log( sprintf( 'Shipment #%d: admin retry ignored; summary empty.', $shipment_id ) );
            return;
        }

        $status = isset( $summary['status'] ) ? (string) $summary['status'] : '';
        if ( $status === 'unassigned' ) {
            ShipmentManager::set_shipment_status(
                $shipment_id,
                'ready_for_assignment',
                array(
                    'source' => 'dispatcher_admin',
                    'reason' => sanitize_key( (string) $reason ),
                )
            );
            $summary['status'] = 'ready_for_assignment';
        }

        if ( $summary['status'] !== 'ready_for_assignment' ) {
            Logger::log( sprintf( 'Shipment #%d: admin retry ignored; status=%s.', $shipment_id, $summary['status'] ) );
            return;
        }

        self::on_shipment_ready(
            $shipment_id,
            intval( $summary['order_id'] ?? 0 ),
            intval( $summary['vendor_id'] ?? 0 )
        );
    }

    public static function on_shipment_ready( $shipment_id, $order_id, $vendor_id, $context = array() ) {
        $shipment_id = intval( $shipment_id );
        $order_id    = intval( $order_id );
        $vendor_id   = intval( $vendor_id );
        $context     = is_array( $context ) ? $context : array();
        $forced      = self::is_forced_backlog( $shipment_id, $context );

        if ( ! $shipment_id ) {
            return;
        }

        self::backlog_note(
            $shipment_id,
            'engine_entry',
            array(
                'forced_backlog' => $forced ? 'yes' : 'no',
                'patch_version'  => self::PATCH_VERSION,
                'context'        => $context,
            )
        );

        $settings = Settings::get_settings();
        if ( empty( $settings['enabled'] ) && ! $forced ) {
            self::backlog_note( $shipment_id, 'dispatcher_disabled_skip' );
            Logger::log( sprintf( 'Shipment #%d: dispatcher disabled; skipping.', $shipment_id ) );
            return;
        }

        $summary = ShipmentManager::get_shipment_summary( $shipment_id );
        if ( empty( $summary ) ) {
            self::backlog_note( $shipment_id, 'summary_empty' );
            Logger::log( sprintf( 'Shipment #%d: summary empty; cannot dispatch.', $shipment_id ) );
            if ( $forced ) {
                self::preserve_ready_state_for_forced_backlog( $shipment_id, array(), 'summary_empty' );
                self::backlog_note( $shipment_id, 'forced_backlog_retry_preserved', array( 'reason' => 'summary_empty' ) );
            }
            return;
        }

        if ( $summary['status'] !== 'ready_for_assignment' ) {
            self::backlog_note( $shipment_id, 'status_not_ready', array( 'status' => $summary['status'] ) );
            Logger::log( sprintf( 'Shipment #%d: status %s, not ready_for_assignment.', $shipment_id, $summary['status'] ) );
            return;
        }

        if ( AutoAssign::maybe_finalize_expired_offer( $shipment_id, 0, $summary ) ) {
            self::backlog_note( $shipment_id, 'expired_offer_finalized' );
            Logger::log( sprintf( 'Shipment #%d: expired offer finalized before dispatch pass.', $shipment_id ) );
            return;
        }

        if ( AutoAssign::shipment_has_live_offer( $shipment_id, $summary ) ) {
            self::backlog_note( $shipment_id, 'live_offer_window_skip' );
            Logger::log( sprintf( 'Shipment #%d: live offer window already active; dispatcher pass skipped.', $shipment_id ) );
            return;
        }

        if ( ! empty( $summary['rescue_state'] ) && ! $forced ) {
            delete_post_meta( $shipment_id, \Caricove\Logistics\Core\Schema::META_SHIPMENT_RESCUE_STATE );
            $summary['rescue_state'] = '';
            self::backlog_note( $shipment_id, 'rescue_state_cleared_on_ready' );
            Logger::log( sprintf( 'Shipment #%d: stale rescue_state cleared on ready pass.', $shipment_id ) );
        }

        $overrides = Overrides::get_overrides();

        if ( $vendor_id && Overrides::is_vendor_blocked( $vendor_id ) && ! $forced ) {
            self::backlog_note( $shipment_id, 'vendor_blocked_skip', array( 'vendor_id' => $vendor_id ) );
            Logger::log(
                sprintf(
                    'Shipment #%d (vendor #%d) blocked via overrides; dispatcher skipping.',
                    $shipment_id,
                    $vendor_id
                )
            );
            do_action( 'cc_dispatcher_vendor_blocked', $shipment_id, $order_id, $vendor_id, $summary );
            return;
        }

        if ( $vendor_id && Overrides::is_vendor_manual_only( $vendor_id ) && ! $forced ) {
            self::backlog_note( $shipment_id, 'vendor_manual_only_skip', array( 'vendor_id' => $vendor_id ) );
            Logger::log(
                sprintf(
                    'Shipment #%d (vendor #%d) marked manual-only; dispatcher skipping for manual assignment.',
                    $shipment_id,
                    $vendor_id
                )
            );
            do_action( 'cc_dispatcher_vendor_manual_only', $shipment_id, $order_id, $vendor_id, $summary );
            return;
        }

        if ( Overrides::is_shipment_locked( $shipment_id ) && ! $forced ) {
            self::backlog_note( $shipment_id, 'shipment_locked_skip' );
            Logger::log( sprintf( 'Shipment #%d: shipment locked in overrides; skipping.', $shipment_id ) );
            return;
        }

        $forced_courier = Overrides::get_forced_courier_for_shipment( $shipment_id );
        if ( $forced_courier ) {
            self::backlog_note( $shipment_id, 'forced_courier_override', array( 'courier_id' => $forced_courier ) );
            Logger::log( sprintf( 'Shipment #%d: forced courier override to courier #%d.', $shipment_id, $forced_courier ) );
            try {
                Assign::to_courier(
                    $shipment_id,
                    $forced_courier,
                    $summary,
                    $settings,
                    array(
                        'source' => $forced ? 'dispatcher_forced_backlog' : 'dispatcher_forced',
                    )
                );
                self::backlog_note( $shipment_id, 'assign_called', array( 'courier_id' => $forced_courier ) );
            } catch ( \Throwable $e ) {
                self::backlog_note( $shipment_id, 'assign_exception', array( 'message' => $e->getMessage() ) );
                Logger::log( sprintf( 'Shipment #%d: forced courier assignment exception: %s.', $shipment_id, $e->getMessage() ) );
                if ( $forced ) {
                    self::preserve_ready_state_for_forced_backlog( $shipment_id, $summary, 'assign_exception' );
                    self::backlog_note( $shipment_id, 'forced_backlog_retry_preserved', array( 'reason' => 'assign_exception' ) );
                }
            }
            return;
        }

        try {
            $candidates = CourierPool::get_candidates(
                $summary,
                $settings,
                $overrides,
                array(
                    'shipment_id'     => $shipment_id,
                    'forced_backlog'  => $forced,
                    'log_rejections'  => $forced,
                    'context'         => $context,
                )
            );
        } catch ( \Throwable $e ) {
            self::backlog_note( $shipment_id, 'candidate_pool_exception', array( 'message' => $e->getMessage() ) );
            Logger::log( sprintf( 'Shipment #%d: candidate pool exception: %s.', $shipment_id, $e->getMessage() ) );
            if ( $forced ) {
                self::preserve_ready_state_for_forced_backlog( $shipment_id, $summary, 'candidate_pool_exception' );
                self::backlog_note( $shipment_id, 'forced_backlog_retry_preserved', array( 'reason' => 'candidate_pool_exception' ) );
            }
            return;
        }

        self::backlog_note( $shipment_id, 'candidate_pool_built', array( 'candidate_count' => count( $candidates ) ) );
        if ( ! empty( $candidates ) ) {
            self::backlog_note( $shipment_id, 'candidate_ids', array( 'ids' => array_values( array_map( 'intval', array_keys( $candidates ) ) ) ) );
        }

        if ( empty( $candidates ) ) {
            self::backlog_note( $shipment_id, 'no_candidates' );
            Logger::log( sprintf( 'Shipment #%d: no eligible couriers in pool.', $shipment_id ) );
            do_action( 'cc_dispatcher_no_candidates', $shipment_id, $summary );
            if ( $forced ) {
                self::preserve_ready_state_for_forced_backlog( $shipment_id, $summary, 'no_candidates' );
                self::backlog_note( $shipment_id, 'forced_backlog_retry_preserved', array( 'reason' => 'no_candidates' ) );
            }
            return;
        }

        $best_courier = 0;
        $best_score   = null;
        $scores_debug = array();

        foreach ( $candidates as $courier_id => $profile ) {
            try {
                $score = Scoring::score( $summary, $profile, $settings, $overrides );
            } catch ( \Throwable $e ) {
                self::backlog_note(
                    $shipment_id,
                    'scoring_exception',
                    array(
                        'courier_id' => intval( $courier_id ),
                        'message'    => $e->getMessage(),
                    )
                );
                Logger::log( sprintf( 'Shipment #%d: scoring exception for courier #%d: %s.', $shipment_id, $courier_id, $e->getMessage() ) );
                continue;
            }

            $scores_debug[ $courier_id ] = $score;

            if ( null === $best_score || $score['total'] > $best_score['total'] ) {
                $best_score   = $score;
                $best_courier = $courier_id;
            }
        }

        if ( ! $best_courier ) {
            self::backlog_note( $shipment_id, 'no_winner_after_scoring' );
            Logger::log( sprintf( 'Shipment #%d: scoring produced no winner.', $shipment_id ) );
            do_action( 'cc_dispatcher_no_winner', $shipment_id, $summary, $scores_debug );
            if ( $forced ) {
                self::preserve_ready_state_for_forced_backlog( $shipment_id, $summary, 'no_winner_after_scoring' );
                self::backlog_note( $shipment_id, 'forced_backlog_retry_preserved', array( 'reason' => 'no_winner_after_scoring' ) );
            }
            return;
        }

        if ( ! $forced ) {
            $best_courier = apply_filters(
                'cc_dispatcher_before_assign_winner',
                $best_courier,
                $shipment_id,
                $summary,
                $best_score,
                $scores_debug
            );

            if ( ! $best_courier ) {
                self::backlog_note( $shipment_id, 'winner_vetoed' );
                Logger::log( sprintf( 'Shipment #%d: winner vetoed by filter.', $shipment_id ) );
                return;
            }
        } else {
            self::backlog_note( $shipment_id, 'forced_backlog_bypassed_winner_veto' );
            Logger::log( sprintf( 'Shipment #%d: forced backlog bypassed winner veto filters.', $shipment_id ) );
        }

        self::backlog_note(
            $shipment_id,
            'assigning_winner',
            array(
                'courier_id'      => intval( $best_courier ),
                'candidate_count' => count( $candidates ),
            )
        );

        Logger::log(
            sprintf(
                'Shipment #%d: assigning courier #%d from %d candidates.',
                $shipment_id,
                $best_courier,
                count( $candidates )
            )
        );

        try {
            Assign::to_courier(
                $shipment_id,
                $best_courier,
                $summary,
                $settings,
                array(
                    'source' => $forced ? 'dispatcher_forced_backlog' : 'dispatcher_auto',
                    'score'  => $best_score,
                )
            );
            self::backlog_note( $shipment_id, 'assign_called', array( 'courier_id' => intval( $best_courier ) ) );
        } catch ( \Throwable $e ) {
            self::backlog_note( $shipment_id, 'assign_exception', array( 'message' => $e->getMessage(), 'courier_id' => intval( $best_courier ) ) );
            Logger::log( sprintf( 'Shipment #%d: assign exception for courier #%d: %s.', $shipment_id, $best_courier, $e->getMessage() ) );
            if ( $forced ) {
                self::preserve_ready_state_for_forced_backlog( $shipment_id, $summary, 'assign_exception' );
                self::backlog_note( $shipment_id, 'forced_backlog_retry_preserved', array( 'reason' => 'assign_exception' ) );
            }
        }
    }

    protected static function is_forced_backlog( $shipment_id, $context = array() ) {
        $shipment_id = intval( $shipment_id );
        $context     = is_array( $context ) ? $context : array();

        if ( ! empty( $context['forced_backlog'] ) || ! empty( $context['backlog_sweep_id'] ) || ( isset( $context['source'] ) && $context['source'] === 'backlog_aggressive' ) ) {
            return true;
        }

        if ( class_exists( __NAMESPACE__ . '\Backlog' ) && defined( __NAMESPACE__ . '\Backlog::FORCE_MARKER_PREFIX' ) ) {
            $marker = get_transient( Backlog::FORCE_MARKER_PREFIX . $shipment_id );
            if ( is_array( $marker ) && ( ! empty( $marker['forced_backlog'] ) || ! empty( $marker['backlog_sweep_id'] ) ) ) {
                return true;
            }
        }

        return false;
    }

    protected static function preserve_ready_state_for_forced_backlog( $shipment_id, $summary, $reason ) {
        $shipment_id = intval( $shipment_id );
        $reason      = sanitize_key( (string) $reason );
        $status      = is_array( $summary ) ? (string) ( $summary['status'] ?? '' ) : '';

        if ( $status !== 'ready_for_assignment' && method_exists( '\Caricove\Logistics\Core\ShipmentManager', 'set_shipment_status' ) ) {
            ShipmentManager::set_shipment_status(
                $shipment_id,
                'ready_for_assignment',
                array(
                    'source' => 'dispatcher_forced_backlog',
                    'reason' => $reason,
                )
            );
        }

        self::backlog_note( $shipment_id, 'forced_backlog_keep_ready', array( 'reason' => $reason ) );
        Logger::log( sprintf( 'Shipment #%d: forced backlog preserved ready_for_assignment after %s.', $shipment_id, $reason ) );
    }

    protected static function backlog_note( $shipment_id, $message, $data = array() ) {
        if ( class_exists( __NAMESPACE__ . '\Backlog' ) ) {
            Backlog::engine_note( $shipment_id, $message, $data );
        }
    }
}

Engine::boot();
