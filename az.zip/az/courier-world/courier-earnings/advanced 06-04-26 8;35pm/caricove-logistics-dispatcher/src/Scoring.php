<?php
namespace Caricove\Logistics\Dispatcher;

use Caricove\Logistics\Core\ZoneResolver;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Scoring {

    public static function estimate_distance_km( array $profile, $pickup_coords ) {
        $pickup_coords = is_string( $pickup_coords ) ? trim( $pickup_coords ) : '';

        if ( $pickup_coords === '' ) {
            return 999999.0;
        }

        if ( ! isset( $profile['last_lat'], $profile['last_lng'] ) || ! is_numeric( $profile['last_lat'] ) || ! is_numeric( $profile['last_lng'] ) ) {
            return 999999.0;
        }

        $parts = array_map( 'trim', explode( ',', $pickup_coords ) );
        if ( count( $parts ) !== 2 || ! is_numeric( $parts[0] ) || ! is_numeric( $parts[1] ) ) {
            return 999999.0;
        }

        $p_lat = floatval( $parts[0] );
        $p_lng = floatval( $parts[1] );
        $c_lat = floatval( $profile['last_lat'] );
        $c_lng = floatval( $profile['last_lng'] );

        $earth_radius_km = 6371.0;
        $d_lat = deg2rad( $p_lat - $c_lat );
        $d_lng = deg2rad( $p_lng - $c_lng );

        $a = sin( $d_lat / 2 ) * sin( $d_lat / 2 )
            + cos( deg2rad( $c_lat ) ) * cos( deg2rad( $p_lat ) )
            * sin( $d_lng / 2 ) * sin( $d_lng / 2 );

        $c = 2 * atan2( sqrt( $a ), sqrt( max( 0.0, 1 - $a ) ) );
        $d = $earth_radius_km * $c;

        if ( ! is_finite( $d ) || $d < 0 ) {
            return 999999.0;
        }

        return $d;
    }

    public static function score( array $shipment, array $profile, array $settings, array $overrides ) {
        $courier_id = intval( $profile['id'] ?? $profile['user_id'] ?? 0 );
        $evaluation = isset( $profile['evaluation'] ) && is_array( $profile['evaluation'] )
            ? $profile['evaluation']
            : CourierPool::evaluate_courier( $profile, $shipment, $settings, $overrides );

        if ( empty( $evaluation['eligible'] ) ) {
            return array(
                'eligible'               => false,
                'reason'                 => sanitize_key( (string) ( $evaluation['reason'] ?? 'ineligible' ) ),
                'total'                  => 0.0,
                'pickup_distance_km'     => floatval( $evaluation['pickup_distance_km'] ?? 999999 ),
                'pickup_distance_cap_km' => floatval( $evaluation['pickup_distance_cap_km'] ?? 0 ),
                'fit_score'              => 0.0,
            );
        }

        $weights = self::resolve_score_weights( $settings );
        $pickup_distance_km = floatval( $evaluation['pickup_distance_km'] ?? self::estimate_distance_km( $profile, (string) ( $shipment['pickup_coords'] ?? '' ) ) );
        $pickup_cap_km      = max( 1.0, floatval( $evaluation['pickup_distance_cap_km'] ?? CourierPool::get_pickup_distance_cap_km( $profile, $settings ) ) );
        $active_jobs        = max( 0, intval( $evaluation['active_jobs'] ?? CourierPool::get_active_jobs_for_courier( $courier_id ) ) );
        $max_jobs           = max( 1, intval( $evaluation['max_active_jobs'] ?? $profile['max_active_jobs'] ?? 5 ) );

        $pickup_readiness = self::clamp01( 1.0 - ( min( $pickup_distance_km, $pickup_cap_km ) / $pickup_cap_km ) );
        $load_ratio       = self::clamp01( $active_jobs / $max_jobs );
        $load_score       = self::clamp01( 1.0 - $load_ratio );
        $performance      = self::clamp01( floatval( $profile['perf_score'] ?? 50 ) / 100.0 );

        $sla_hint = apply_filters(
            'cc_dispatcher_sla_hint_for_candidate',
            array(
                'risk'           => 0.0,
                'eta_seconds'    => null,
                'travel_minutes' => null,
            ),
            $shipment,
            $profile
        );
        $sla_risk   = self::clamp01( floatval( $sla_hint['risk'] ?? 0.0 ) );
        $sla_safety = self::clamp01( 1.0 - $sla_risk );

        $fit = self::fit_score( $shipment, $profile, $evaluation );

        $corridor   = self::corridor_score( $shipment, $profile, $settings );
        $trust_score = $courier_id ? max( 0, min( 100, intval( get_user_meta( $courier_id, '_cc_trust_score', true ) ) ) ) : 0;
        $trust_tier  = $courier_id ? sanitize_key( (string) get_user_meta( $courier_id, '_cc_trust_tier', true ) ) : 'starter';
        $trust_norm  = self::clamp01( $trust_score / 100.0 );
        $minor_ops   = self::clamp01( ( $corridor * 0.70 ) + ( $trust_norm * 0.30 ) );

        $total = ( $pickup_readiness * $weights['pickup_readiness'] )
               + ( $fit['score']        * $weights['fit'] )
               + ( $load_score          * $weights['load'] )
               + ( $sla_safety          * $weights['sla_safety'] )
               + ( $performance         * $weights['performance'] )
               + ( $minor_ops           * $weights['minor_ops'] );

        $multiplier = $courier_id ? Overrides::get_courier_multiplier( $courier_id ) : 1.0;
        $total = self::clamp01( $total * max( 0.01, floatval( $multiplier ) ) );

        $score = array(
            'eligible'               => true,
            'reason'                 => 'eligible',
            'total'                  => $total,
            'pickup_distance_km'     => $pickup_distance_km,
            'pickup_distance_cap_km' => $pickup_cap_km,
            'pickup_readiness'       => $pickup_readiness,
            'distance_km'            => $pickup_distance_km,
            'distance_score'         => $pickup_readiness,
            'load_ratio'             => $load_ratio,
            'load_score'             => $load_score,
            'active_jobs'            => $active_jobs,
            'max_active_jobs'        => $max_jobs,
            'sla_risk'               => $sla_risk,
            'sla_safety'             => $sla_safety,
            'sla_score'              => $sla_safety,
            'performance_score'      => $performance,
            'perf_score'             => $performance,
            'fit_score'              => $fit['score'],
            'vehicle_fit_score'      => $fit['score'],
            'fit_ratio'              => $fit['fit_ratio'],
            'fit_numeric_score'      => $fit['numeric_score'],
            'fit_family_modifier'    => $fit['family_modifier'],
            'fit_edge_penalty'       => $fit['edge_penalty'],
            'vehicle_weight_cap_kg'  => $fit['vehicle_weight_cap_kg'],
            'shipment_weight_kg'     => $fit['shipment_weight_kg'],
            'shipment_weight_band'   => sanitize_key( (string) ( $evaluation['shipment_weight_band'] ?? $shipment['weight_band'] ?? '' ) ),
            'vehicle_family'         => sanitize_key( (string) ( $evaluation['vehicle_family'] ?? $profile['vehicle_type'] ?? '' ) ),
            'corridor_score'         => $corridor,
            'minor_ops_score'        => $minor_ops,
            'minor_ops_corridor'     => $corridor,
            'minor_ops_trust'        => $trust_norm,
            'trust_score'            => $trust_score,
            'trust_tier'             => $trust_tier ?: 'starter',
            'override_multiplier'    => $multiplier,
            'weights_used'           => $weights,
            'route_source'           => sanitize_key( (string) ( $shipment['route_source'] ?? '' ) ),
            'route_detail_source'    => sanitize_key( (string) ( $shipment['route_detail_source'] ?? '' ) ),
            'route_provenance'       => sanitize_key( (string) ( $shipment['route_provenance'] ?? '' ) ),
            'shipment_band'          => sanitize_key( (string) ( $evaluation['shipment_band'] ?? $shipment['distance_band'] ?? $shipment['trip_band'] ?? '' ) ),
            'preference_band'        => sanitize_key( (string) ( $evaluation['preference_band'] ?? '' ) ),
            'hints'                  => $sla_hint,
        );

        $score = apply_filters( 'cc_dispatcher_candidate_score', $score, $shipment, $profile, $settings );
        if ( isset( $score['total'] ) ) {
            $score['total'] = self::clamp01( $score['total'] );
        }

        return $score;
    }

    protected static function resolve_score_weights( array $settings ) {
        $saved = isset( $settings['weights'] ) && is_array( $settings['weights'] ) ? $settings['weights'] : array();

        $weights = array(
            'pickup_readiness' => isset( $saved['pickup_readiness'] ) ? floatval( $saved['pickup_readiness'] ) : ( isset( $saved['distance'] ) ? floatval( $saved['distance'] ) : 0.45 ),
            'fit'              => isset( $saved['fit'] ) ? floatval( $saved['fit'] ) : 0.20,
            'load'             => isset( $saved['load'] ) ? floatval( $saved['load'] ) : 0.15,
            'sla_safety'       => isset( $saved['sla_safety'] ) ? floatval( $saved['sla_safety'] ) : ( isset( $saved['sla_risk'] ) ? floatval( $saved['sla_risk'] ) : 0.10 ),
            'performance'      => isset( $saved['performance'] ) ? floatval( $saved['performance'] ) : 0.05,
            'minor_ops'        => isset( $saved['minor_ops'] ) ? floatval( $saved['minor_ops'] ) : 0.05,
        );

        $sum = array_sum( $weights );
        if ( $sum <= 0 ) {
            return array(
                'pickup_readiness' => 0.45,
                'fit'              => 0.20,
                'load'             => 0.15,
                'sla_safety'       => 0.10,
                'performance'      => 0.05,
                'minor_ops'        => 0.05,
            );
        }

        foreach ( $weights as $key => $value ) {
            $weights[ $key ] = self::clamp01( $value / $sum );
        }

        return $weights;
    }

    protected static function fit_score( array $shipment, array $profile, array $evaluation ) {
        $vehicle = class_exists( ZoneResolver::class )
            ? ZoneResolver::normalize_vehicle_type( (string) ( $evaluation['vehicle_family'] ?? $profile['vehicle_type'] ?? '' ) )
            : sanitize_key( (string) ( $evaluation['vehicle_family'] ?? $profile['vehicle_type'] ?? '' ) );

        $shipment_weight_kg   = max( 0.0, floatval( $evaluation['shipment_weight_kg'] ?? $shipment['effective_weight'] ?? $shipment['total_weight'] ?? 0 ) );
        $shipment_weight_band = sanitize_key( (string) ( $evaluation['shipment_weight_band'] ?? $shipment['weight_band'] ?? '' ) );
        $vehicle_weight_cap_kg = max( 0.0, floatval( $evaluation['vehicle_weight_cap_kg'] ?? ( class_exists( ZoneResolver::class ) ? ZoneResolver::get_vehicle_weight_cap_kg( $vehicle ) : 0 ) ) );
        $shipment_weight_source = $shipment_weight_kg > 0 ? 'numeric' : 'missing';
        if ( $shipment_weight_kg <= 0 && $shipment_weight_band !== '' && class_exists( ZoneResolver::class ) ) {
            $shipment_weight_kg = max( 0.0, floatval( ZoneResolver::representative_weight_kg_for_band( $shipment_weight_band ) ) );
            if ( $shipment_weight_kg > 0 ) {
                $shipment_weight_source = 'band_representative';
            }
        }

        $fit_ratio = 0.0;
        if ( $shipment_weight_kg > 0 && $vehicle_weight_cap_kg > 0 ) {
            $fit_ratio = $shipment_weight_kg / $vehicle_weight_cap_kg;
        }

        $numeric_score   = self::fit_numeric_score( $fit_ratio );
        $family_modifier = class_exists( ZoneResolver::class )
            ? floatval( ZoneResolver::get_vehicle_family_modifier_for_weight_band( $vehicle, $shipment_weight_band ) )
            : 0.0;

        $edge_penalty = 0.0;
        if ( $fit_ratio >= 0.95 ) {
            $edge_penalty += 0.20;
        } elseif ( $fit_ratio >= 0.90 ) {
            $edge_penalty += 0.10;
        }
        if ( $shipment_weight_band === 'light' && $vehicle === 'car' && $fit_ratio > 0 && $fit_ratio < 0.03 ) {
            $edge_penalty += 0.05;
        }

        return array(
            'score'                => self::clamp01( $numeric_score + $family_modifier - $edge_penalty ),
            'fit_ratio'            => $fit_ratio,
            'numeric_score'        => $numeric_score,
            'family_modifier'      => $family_modifier,
            'edge_penalty'         => $edge_penalty,
            'vehicle_weight_cap_kg'=> $vehicle_weight_cap_kg,
            'shipment_weight_kg'   => $shipment_weight_kg,
            'shipment_weight_source' => $shipment_weight_source,
        );
    }

    protected static function fit_numeric_score( $fit_ratio ) {
        $fit_ratio = max( 0.0, floatval( $fit_ratio ) );

        if ( $fit_ratio >= 0.20 && $fit_ratio <= 0.60 ) {
            return 1.00;
        }
        if ( $fit_ratio >= 0.10 && $fit_ratio < 0.20 ) {
            return 0.85;
        }
        if ( $fit_ratio >= 0.05 && $fit_ratio < 0.10 ) {
            return 0.70;
        }
        if ( $fit_ratio >= 0.02 && $fit_ratio < 0.05 ) {
            return 0.45;
        }
        if ( $fit_ratio < 0.02 ) {
            return 0.20;
        }
        if ( $fit_ratio > 0.60 && $fit_ratio <= 0.80 ) {
            return 0.85;
        }
        if ( $fit_ratio > 0.80 && $fit_ratio <= 0.90 ) {
            return 0.60;
        }
        if ( $fit_ratio > 0.90 && $fit_ratio <= 0.95 ) {
            return 0.40;
        }
        if ( $fit_ratio > 0.95 && $fit_ratio <= 1.00 ) {
            return 0.20;
        }

        return 0.20;
    }

    protected static function corridor_score( array $shipment, array $profile, array $settings ) {
        $score = 0.35;

        $courier_zone = sanitize_key( (string) ( $profile['zone_id'] ?? $profile['region'] ?? '' ) );
        $pickup_zone  = sanitize_key( (string) ( $shipment['pickup_zone_id'] ?? $shipment['origin_anchor'] ?? '' ) );
        $dropoff_zone = sanitize_key( (string) ( $shipment['dropoff_zone_id'] ?? $shipment['destination_anchor'] ?? '' ) );

        if ( $courier_zone !== '' && $courier_zone === $pickup_zone ) {
            $score += 0.40;
        } elseif ( ! empty( $settings['allow_adjacent_zone_match'] ) ) {
            $adjacent = array_map( 'sanitize_key', (array) ( $shipment['adjacent_pickup_zone_ids'] ?? $shipment['pickup_adjacent_zone_ids'] ?? array() ) );
            if ( in_array( $courier_zone, $adjacent, true ) ) {
                $score += 0.20;
            }
        }

        if ( $courier_zone !== '' && $courier_zone === $dropoff_zone ) {
            $score += 0.10;
        }

        return self::clamp01( $score );
    }

    protected static function clamp01( $value ) {
        $value = floatval( $value );
        if ( $value < 0.0 ) {
            return 0.0;
        }
        if ( $value > 1.0 ) {
            return 1.0;
        }
        return $value;
    }
}
