<?php
namespace Caricove\Logistics\Dispatcher;

use Caricove\Logistics\Core\ShipmentManager;
use Caricove\Logistics\Core\Schema;
use Caricove\Logistics\Core\AutoAssign;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Assign {

    public static function to_courier(
        $shipment_id,
        $courier_id,
        array $shipment_summary,
        array $settings,
        array $context = array()
    ) {
        $shipment_id = intval( $shipment_id );
        $courier_id  = intval( $courier_id );

        if ( ! $shipment_id || ! $courier_id ) {
            return array(
                'mode'       => 'noop',
                'shipment_id' => $shipment_id,
                'courier_id' => $courier_id,
            );
        }

        $order_id  = ! empty( $shipment_summary['order_id'] ) ? intval( $shipment_summary['order_id'] ) : 0;
        $vendor_id = ! empty( $shipment_summary['vendor_id'] ) ? intval( $shipment_summary['vendor_id'] ) : 0;

        $context = wp_parse_args(
            $context,
            array(
                'order_id'  => $order_id,
                'vendor_id' => $vendor_id,
                'status'    => 'assigned',
                'source'    => 'dispatcher_auto',
            )
        );

        if ( self::should_stage_offer_window( $shipment_summary, $settings, $context ) && class_exists( AutoAssign::class ) ) {
            AutoAssign::begin_offer_window( $shipment_id, $courier_id, $shipment_summary, $settings, $context );

            Logger::log(
                sprintf(
                    'Shipment #%d staged to courier #%d for offer window (source=%s).',
                    $shipment_id,
                    $courier_id,
                    sanitize_key( (string) $context['source'] )
                )
            );

            do_action(
                'cc_dispatcher_after_offer_staged',
                $shipment_id,
                $courier_id,
                $context
            );

            return array(
                'mode'        => 'offer_window',
                'shipment_id' => $shipment_id,
                'courier_id'  => $courier_id,
            );
        }

        ShipmentManager::assign_shipment_to_courier(
            $shipment_id,
            $courier_id,
            $context
        );

        Logger::log(
            sprintf(
                'Shipment #%d assigned to courier #%d (source=%s).',
                $shipment_id,
                $courier_id,
                sanitize_key( (string) $context['source'] )
            )
        );

        do_action(
            'cc_dispatcher_after_assign',
            $shipment_id,
            $courier_id,
            $context
        );

        $rules = Settings::get_bundling_rules( $settings );
        if ( ! empty( $rules['max_shipments_per_job'] ) && intval( $rules['max_shipments_per_job'] ) >= 2 ) {
            self::maybe_bundle_after_assignment( $shipment_id, $courier_id, $rules, $context );
        }

        return array(
            'mode'        => 'assigned',
            'shipment_id' => $shipment_id,
            'courier_id'  => $courier_id,
        );
    }

    protected static function should_stage_offer_window( array $shipment_summary, array $settings, array $context ) {
        if ( ! empty( $context['skip_offer_window'] ) || ! empty( $context['direct_assign'] ) || ! empty( $context['force_assign'] ) ) {
            return false;
        }

        $source = sanitize_key( (string) ( $context['source'] ?? '' ) );
       if ( in_array( $source, array( 'offer_accept', 'courier_console_accept', 'admin_force_immediate', 'dispatcher_forced' ), true ) ) {
    return false;
}

        if ( strpos( $source, 'admin_force' ) === 0 ) {
            return false;
        }

        $status = sanitize_key( (string) ( $shipment_summary['status'] ?? '' ) );
        if ( $status !== 'ready_for_assignment' ) {
            return false;
        }

        return intval( $settings['default_accept_window_seconds'] ?? 0 ) > 0;
    }

    protected static function maybe_bundle_after_assignment( $shipment_id, $courier_id, array $rules, array $context ) {
        $shipment_id = intval( $shipment_id );
        $courier_id  = intval( $courier_id );
        if ( ! $shipment_id || ! $courier_id ) {
            return;
        }

        $seed_summary = ShipmentManager::get_shipment_summary( $shipment_id );
        if ( empty( $seed_summary ) ) {
            return;
        }

        $origin_anchor = ! empty( $seed_summary['origin_anchor'] ) ? $seed_summary['origin_anchor'] : '';
        if ( ! $origin_anchor ) {
            return;
        }

        $seed_eta_ts = 0;
        if ( ! empty( $seed_summary['eta'] ) ) {
            $seed_eta_ts = strtotime( $seed_summary['eta'] );
        }
        if ( ! $seed_eta_ts ) {
            $seed_eta_ts = time();
        }

        $max_jobs    = max( 1, intval( $rules['max_shipments_per_job'] ?? 1 ) );
        $max_stops   = max( 0, intval( $rules['max_extra_stops'] ?? 0 ) );
        $window_min  = max( 0, intval( $rules['window_minutes'] ?? 0 ) );
        $window_secs = $window_min * 60;

        $bundle_ids = array( $shipment_id );

        $q = new \WP_Query(
            array(
                'post_type'      => 'cc_shipment',
                'post_status'    => 'any',
                'posts_per_page' => 50,
                'fields'         => 'ids',
                'no_found_rows'  => true,
                'meta_query'     => array(
                    'relation' => 'AND',
                    array(
                        'key'   => Schema::META_SHIPMENT_COURIER_ID,
                        'value' => $courier_id,
                    ),
                    array(
                        'key'   => Schema::META_SHIPMENT_STATUS,
                        'value' => 'assigned',
                    ),
                    array(
                        'key'   => Schema::META_SHIPMENT_ORIGIN_ANCHOR,
                        'value' => $origin_anchor,
                    ),
                ),
            )
        );

        if ( ! $q->have_posts() ) {
            return;
        }

        $candidates = array();

        foreach ( $q->posts as $sid ) {
            $sid = intval( $sid );
            if ( ! $sid || $sid === $shipment_id ) {
                continue;
            }

            $summary = ShipmentManager::get_shipment_summary( $sid );
            if ( empty( $summary ) || ! empty( $summary['bundle_id'] ) ) {
                continue;
            }

            $eta_ts = 0;
            if ( ! empty( $summary['eta'] ) ) {
                $eta_ts = strtotime( $summary['eta'] );
            }
            if ( ! $eta_ts ) {
                $eta_ts = time();
            }

            $delta = abs( $eta_ts - $seed_eta_ts );
            if ( $window_secs && $delta > $window_secs ) {
                continue;
            }

            $candidates[] = array(
                'id'       => $sid,
                'eta_ts'   => $eta_ts,
                'delta_ts' => $delta,
            );
        }

        if ( empty( $candidates ) ) {
            return;
        }

        usort(
            $candidates,
            function ( $a, $b ) {
                if ( $a['delta_ts'] === $b['delta_ts'] ) {
                    return 0;
                }
                return ( $a['delta_ts'] < $b['delta_ts'] ) ? -1 : 1;
            }
        );

        foreach ( $candidates as $row ) {
            if ( count( $bundle_ids ) >= $max_jobs ) {
                break;
            }
            $bundle_ids[] = intval( $row['id'] );
        }

        if ( count( $bundle_ids ) < 2 ) {
            return;
        }

        if ( $max_stops && count( $bundle_ids ) - 1 > $max_stops ) {
            $bundle_ids = array_slice( $bundle_ids, 0, $max_stops + 1 );
        }

        $bundle_id = 'ccbundle_' . $courier_id . '_' . gmdate( 'YmdHis' );

        foreach ( $bundle_ids as $index => $sid ) {
            update_post_meta( $sid, Schema::META_SHIPMENT_BUNDLE_ID, $bundle_id );
            update_post_meta( $sid, Schema::META_SHIPMENT_BUNDLE_SEQ, $index + 1 );
        }

        do_action( 'cc_dispatcher_bundle_created', $bundle_id, $courier_id, $bundle_ids, $context );
    }
}
