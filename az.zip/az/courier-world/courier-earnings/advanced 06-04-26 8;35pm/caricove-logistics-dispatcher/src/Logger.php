<?php
namespace Caricove\Logistics\Dispatcher;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Logger {

    protected static $buffer = array();
    const OPTION_RING = 'caricove_dispatcher_log_ring';
    const MAX_LINES   = 600;

    public static function log( $message ) {
        $line = '[' . gmdate( 'Y-m-d H:i:s' ) . '] ' . $message;
        self::$buffer[] = $line;

        $ring   = get_option( self::OPTION_RING, array() );
        $ring   = is_array( $ring ) ? $ring : array();
        $ring[] = $line;

        if ( count( $ring ) > self::MAX_LINES ) {
            $ring = array_slice( $ring, - self::MAX_LINES );
        }

        update_option( self::OPTION_RING, $ring, false );
        error_log( '[Caricove Dispatcher] ' . $line );
        do_action( 'cc_dispatcher_log', $message );
    }

    public static function all() {
        return self::$buffer;
    }

    public static function persisted() {
        $ring = get_option( self::OPTION_RING, array() );
        return is_array( $ring ) ? $ring : array();
    }

    public static function clear_persisted() {
        update_option( self::OPTION_RING, array(), false );
    }
}
