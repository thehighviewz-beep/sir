<?php
namespace Caricove\Logistics\Dispatcher;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Settings {

    const OPTION_SETTINGS = '_cc_dispatcher_settings';

    public static function defaults() {
        return array(
            'enabled'                 => 1,
            'mode'                    => 'standard',
            'max_distance_km'         => 15.0,
            'require_region_match'    => 0, // legacy, retained only for backward compatibility

            'weights'                 => array(
                'pickup_readiness' => 0.45,
                'fit'              => 0.20,
                'load'             => 0.15,
                'sla_safety'       => 0.10,
                'performance'      => 0.05,
                'minor_ops'        => 0.05,
            ),

            'candidate_limit'         => 200,
            'heartbeat_max_age'       => 300,
            'redispatch_max_attempts' => 6,
            'redispatch_backoff'      => '60,180,600,900',
            'extra_heavy_mode'        => 'truck_only',
            'trust_weight'            => 0.15,
            'trust_bonus_cap'         => 0.25,

            'bundling'                => array(
                'max_shipments_per_job' => 3,
                'max_detour_minutes'    => 8,
                'max_extra_stops'       => 2,
                'window_minutes'        => 6,
            ),

            'require_fresh_heartbeat'            => 1,
            'require_zone_match'                 => 0,
            'allow_adjacent_zone_match'          => 1,
            'require_vehicle_fit'                => 1,
            'require_capacity_fit'               => 1,
            'honor_courier_max_active_jobs'      => 1,

            'prefer_same_pickup_zone'            => 1,
            'same_pickup_zone_bonus'             => 0.08,
            'prefer_same_dropoff_zone'           => 0,
            'same_dropoff_zone_bonus'            => 0.04,
            'prefer_motorbike_eligible_small_jobs' => 1,
            'motorbike_bias_bonus'               => 0.05,
            'prefer_car_medium_bulky_jobs'       => 1,
            'car_bias_bonus'                     => 0.03,

            'eta_source'                         => 'cc_cp',
            'use_cc_cp_duration_for_eta'         => 1,
            'use_cc_cp_duration_for_sla'         => 1,
            'eta_operational_buffer_minutes'     => 5,
            'pickup_approach_buffer_minutes'     => 5,
            'sla_extra_buffer_minutes'           => 10,

            'default_accept_window_seconds'      => 12,
            'long_trip_accept_window_seconds'    => 15,
            'auto_reassign_on_timeout'           => 1,
            'auto_reassign_on_stale_heartbeat'   => 1,
            'no_movement_timeout_seconds'        => 300,
            'long_trips_are_dedicated_only'      => 1,

            'backlog_enabled'                    => 1,
            'backlog_interval_seconds'           => 60,
            'backlog_lock_ttl_seconds'           => 50,
            'backlog_max_attempts'               => 5,
            'backlog_max_per_sweep'              => 25,
            'backlog_min_age_before_redispatch_seconds' => 30,

            'reliability_penalize_no_response'   => 1,
            'reliability_no_response_penalty'    => 0.05,
            'reliability_penalize_cancellations' => 1,
            'reliability_cancellation_penalty'   => 0.05,
            'reliability_penalize_late_pickup'   => 1,
            'reliability_late_pickup_penalty'    => 0.03,
        );
    }

    public static function get_settings() {
        $defaults = self::defaults();
        $saved = get_option( self::OPTION_SETTINGS, array() );
        if ( ! is_array( $saved ) ) {
            $saved = array();
        }
        $settings = array_replace_recursive( $defaults, $saved );
        if ( empty( $settings['bundling'] ) || ! is_array( $settings['bundling'] ) ) {
            $settings['bundling'] = $defaults['bundling'];
        }
        if ( ! isset( $saved['require_zone_match'] ) && isset( $saved['require_region_match'] ) ) {
            $settings['require_zone_match'] = ! empty( $saved['require_region_match'] ) ? 1 : 0;
        }
        if ( isset( $settings['weights']['distance'] ) || isset( $settings['weights']['sla_risk'] ) ) {
            $legacy = $settings['weights'];
            $settings['weights'] = array(
                'pickup_readiness' => isset( $legacy['pickup_readiness'] ) ? floatval( $legacy['pickup_readiness'] ) : floatval( $legacy['distance'] ?? 0.45 ),
                'fit'              => isset( $legacy['fit'] ) ? floatval( $legacy['fit'] ) : 0.20,
                'load'             => isset( $legacy['load'] ) ? floatval( $legacy['load'] ) : 0.15,
                'sla_safety'       => isset( $legacy['sla_safety'] ) ? floatval( $legacy['sla_safety'] ) : floatval( $legacy['sla_risk'] ?? 0.10 ),
                'performance'      => isset( $legacy['performance'] ) ? floatval( $legacy['performance'] ) : 0.05,
                'minor_ops'        => isset( $legacy['minor_ops'] ) ? floatval( $legacy['minor_ops'] ) : 0.05,
            );
        }
        $settings['heartbeat_max_age'] = max( 30, intval( $settings['heartbeat_max_age'] ) );
        $settings['candidate_limit']   = max( 10, intval( $settings['candidate_limit'] ) );
        $settings['max_distance_km']   = max( 1.0, floatval( $settings['max_distance_km'] ) );
        $settings['same_pickup_zone_bonus']  = self::clampf( $settings['same_pickup_zone_bonus'], 0.0, 1.0 );
        $settings['same_dropoff_zone_bonus'] = self::clampf( $settings['same_dropoff_zone_bonus'], 0.0, 1.0 );
        $settings['motorbike_bias_bonus']    = self::clampf( $settings['motorbike_bias_bonus'], 0.0, 1.0 );
        $settings['car_bias_bonus']          = self::clampf( $settings['car_bias_bonus'], 0.0, 1.0 );
        $settings['trust_weight']            = self::clampf( $settings['trust_weight'], 0.0, 1.0 );
        $settings['trust_bonus_cap']         = self::clampf( $settings['trust_bonus_cap'], 0.0, 1.0 );
        $settings['default_accept_window_seconds']   = max( 5, intval( $settings['default_accept_window_seconds'] ) );
        $settings['long_trip_accept_window_seconds'] = max( $settings['default_accept_window_seconds'], intval( $settings['long_trip_accept_window_seconds'] ) );
        $settings['backlog_interval_seconds'] = max( 30, intval( $settings['backlog_interval_seconds'] ) );
        $settings['backlog_lock_ttl_seconds'] = max( 10, intval( $settings['backlog_lock_ttl_seconds'] ) );
        $settings['backlog_max_attempts']     = max( 0, intval( $settings['backlog_max_attempts'] ) );
        $settings['backlog_max_per_sweep']    = max( 1, intval( $settings['backlog_max_per_sweep'] ) );
        $settings['backlog_min_age_before_redispatch_seconds'] = max( 0, intval( $settings['backlog_min_age_before_redispatch_seconds'] ) );
        return $settings;
    }

    public static function get_bundling_rules( array $settings ) {
        if ( empty( $settings['bundling'] ) || ! is_array( $settings['bundling'] ) ) {
            $settings = self::get_settings();
        }
        return array_merge( self::defaults()['bundling'], $settings['bundling'] );
    }

    public static function get_backlog_rules( array $settings = array() ) {
        if ( empty( $settings ) ) {
            $settings = self::get_settings();
        }
        return array(
            'enabled' => ! empty( $settings['backlog_enabled'] ),
            'interval_seconds' => max( 30, intval( $settings['backlog_interval_seconds'] ?? 60 ) ),
            'lock_ttl_seconds' => max( 10, intval( $settings['backlog_lock_ttl_seconds'] ?? 50 ) ),
            'max_attempts' => max( 0, intval( $settings['backlog_max_attempts'] ?? 5 ) ),
            'max_per_sweep' => max( 1, intval( $settings['backlog_max_per_sweep'] ?? 25 ) ),
            'min_age_before_redispatch_seconds' => max( 0, intval( $settings['backlog_min_age_before_redispatch_seconds'] ?? 30 ) ),
        );
    }

    public static function get_accept_window_seconds( array $shipment = array(), array $settings = array() ) {
        if ( empty( $settings ) ) {
            $settings = self::get_settings();
        }
        $trip_band = sanitize_key( (string) ( $shipment['trip_band'] ?? '' ) );
        if ( $trip_band === 'long' ) {
            return max( 5, intval( $settings['long_trip_accept_window_seconds'] ?? 15 ) );
        }
        return max( 5, intval( $settings['default_accept_window_seconds'] ?? 12 ) );
    }

    protected static function clampf( $value, $min, $max ) {
        $value = floatval( $value );
        if ( $value < $min ) return $min;
        if ( $value > $max ) return $max;
        return $value;
    }
}
