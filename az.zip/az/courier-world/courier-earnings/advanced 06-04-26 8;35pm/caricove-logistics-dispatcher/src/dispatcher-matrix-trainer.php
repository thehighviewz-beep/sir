<?php
/**
 * Dispatcher → Matrix Trainer (v1)
 * Edits Core anchors/zones and Telemetry lane stats (with audit).
 */

if (!defined('ABSPATH')) exit;

class Caricove_Dispatcher_Matrix_Trainer {

    const PAGE_SLUG = 'cc-dispatcher-matrix-trainer';
    const OPT_AUDIT = '_cc_matrix_trainer_audit';

    public static function boot() {
        add_action('admin_menu', array(__CLASS__,'menu'), 35);
        add_action('admin_post_cc_matrix_save', array(__CLASS__,'save'));
    }

    public static function menu() {
        add_submenu_page(
            'caricove-dispatcher-admin',
            'Matrix Trainer',
            'Matrix Trainer',
            'manage_options',
            self::PAGE_SLUG,
            array(__CLASS__,'render')
        );
    }

    private static function audit($what, $before, $after) {
        $a = get_option(self::OPT_AUDIT, array());
        if (!is_array($a)) $a = array();

        $u = get_userdata(get_current_user_id());
        array_unshift($a, array(
            'ts'=>time(),
            'who'=>$u ? $u->user_login : 'unknown',
            'what'=>$what,
            'before'=>$before,
            'after'=>$after,
        ));
        $a = array_slice($a, 0, 50);
        update_option(self::OPT_AUDIT, $a, false);
    }

    public static function save() {
        if (!current_user_can('manage_options')) wp_die('Unauthorized');
        check_admin_referer('cc_matrix_save','_cc_nonce');

        // Save anchors/zones (Core)
        $anchors_raw = isset($_POST['anchors_json']) ? wp_unslash($_POST['anchors_json']) : '';
        $zones_raw   = isset($_POST['zones_json']) ? wp_unslash($_POST['zones_json']) : '';
        $lanes_raw   = isset($_POST['lane_stats_json']) ? wp_unslash($_POST['lane_stats_json']) : '';

        $anchors = json_decode($anchors_raw, true);
        $zones   = json_decode($zones_raw, true);
        $lanes   = json_decode($lanes_raw, true);

        if (!is_array($anchors)) $anchors = array();
        if (!is_array($zones))   $zones   = array();
        if (!is_array($lanes))   $lanes   = array();

        // Core GeoRegistry
        $beforeA = class_exists('\Caricove\Logistics\Core\GeoRegistry') ? \Caricove\Logistics\Core\GeoRegistry::get_anchors() : array();
        $beforeZ = class_exists('\Caricove\Logistics\Core\GeoRegistry') ? \Caricove\Logistics\Core\GeoRegistry::get_zones() : array();

        if (class_exists('\Caricove\Logistics\Core\GeoRegistry')) {
            \Caricove\Logistics\Core\GeoRegistry::save_anchors($anchors);
            \Caricove\Logistics\Core\GeoRegistry::save_zones($zones);
        }

        self::audit('geo', $beforeA, $anchors);
        self::audit('geo_zones', $beforeZ, $zones);

        // Telemetry lane stats
        $beforeL = get_option(\Caricove\Logistics\Dispatcher\TelemetryOracle::OPT_LANE_STATS ?? '_cc_telemetry_lane_stats', array());
        update_option('_cc_telemetry_lane_stats', $lanes, false);
        self::audit('lane_stats', $beforeL, $lanes);

        wp_safe_redirect(admin_url('admin.php?page='.self::PAGE_SLUG.'&saved=1'));
        exit;
    }

    public static function render() {
        if (!current_user_can('manage_options')) return;

        $saved = !empty($_GET['saved']);

        $anchors = class_exists('\Caricove\Logistics\Core\GeoRegistry') ? \Caricove\Logistics\Core\GeoRegistry::get_anchors() : array();
        $zones   = class_exists('\Caricove\Logistics\Core\GeoRegistry') ? \Caricove\Logistics\Core\GeoRegistry::get_zones() : array();
        $lanes   = get_option('_cc_telemetry_lane_stats', array());
        if (!is_array($lanes)) $lanes = array();

        ?>
        <div class="wrap">
            <h1>Matrix Trainer</h1>
            <p class="description">This is the “reality brain editor”: anchors/zones (Core truth) + lane stats (Telemetry oracle).</p>

            <style>
                .ccMT{
                  max-width: 1200px; margin-top:14px; padding:16px; color:#fff;
                  border-radius:18px;
                  background: radial-gradient(1200px 600px at 15% 0%, rgba(64,160,255,.20), rgba(0,0,0,0)),
                              radial-gradient(900px 500px at 85% 10%, rgba(140,80,255,.16), rgba(0,0,0,0)),
                              linear-gradient(180deg,#070B14,#04060C);
                  border:1px solid rgba(120,180,255,.18);
                  box-shadow:0 20px 60px rgba(0,0,0,.65), 0 0 0 1px rgba(80,160,255,.06) inset;
                }
                .ccMT .row{display:grid;grid-template-columns:1fr;gap:12px}
                .ccMT .card{border:1px solid rgba(255,255,255,.08);background:rgba(255,255,255,.03);border-radius:16px;padding:14px;box-shadow:0 18px 55px rgba(0,0,0,.50)}
                .ccMT h2{margin:0 0 8px;color:#74d0ff}
                .ccMT textarea{
                  width:100%; min-height:220px;
                  border-radius:12px; border:1px solid rgba(255,255,255,.12);
                  background:rgba(255,255,255,.90); color:#000; padding:12px;
                  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono","Courier New", monospace;
                }
                .ccMT .btn{
                  padding:11px 14px;border-radius:12px;border:1px solid rgba(120,180,255,.22);
                  background: linear-gradient(135deg, rgba(50,140,255,.35), rgba(140,80,255,.20));
                  color:#fff;font-weight:900;cursor:pointer;text-decoration:none;display:inline-flex;align-items:center;justify-content:center;
                }
                .ccMT .note{margin-top:10px;padding:10px 12px;border-radius:14px;border:1px solid rgba(255,255,255,.10);background:rgba(255,255,255,.05);font-weight:900}
                .ccMT .ok{border-color: rgba(80,255,170,.25); box-shadow:0 0 22px rgba(80,255,170,.10)}
            </style>

            <div class="ccMT">
                <?php if ($saved): ?><div class="note ok">✅ Saved. Dispatcher will use these anchors/zones and lane stats immediately.</div><?php endif; ?>

                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                    <?php wp_nonce_field('cc_matrix_save','_cc_nonce'); ?>
                    <input type="hidden" name="action" value="cc_matrix_save">

                    <div class="row">

                        <div class="card">
                            <h2>Anchors (Core)</h2>
                            <p class="description">Array of anchor objects: slug, label, lat, lng, radius_m, zone_id</p>
                            <textarea name="anchors_json"><?php echo esc_textarea(json_encode($anchors, JSON_PRETTY_PRINT)); ?></textarea>
                        </div>

                        <div class="card">
                            <h2>Zones (Core)</h2>
                            <p class="description">Array of zone objects: zone_id, label, polygon[[lat,lng],...], anchors[]</p>
                            <textarea name="zones_json"><?php echo esc_textarea(json_encode($zones, JSON_PRETTY_PRINT)); ?></textarea>
                        </div>

                        <div class="card">
                            <h2>Lane Stats (Telemetry Oracle)</h2>
                            <p class="description">
                                Key format: <code>origin::dest::bucket::day::vehicle</code> (use <code>any</code> for fallbacks).
                                Each value: <code>{n,p50,p90,avg,late_rate}</code> (seconds, late_rate 0..1).
                            </p>
                            <textarea name="lane_stats_json"><?php echo esc_textarea(json_encode($lanes, JSON_PRETTY_PRINT)); ?></textarea>
                        </div>

                        <div class="card">
                            <button class="btn" type="submit">Save Matrix + Lane Stats</button>
                        </div>

                    </div>
                </form>
            </div>
        </div>
        <?php
    }
}

