<?php
namespace Caricove\Logistics\Dispatcher;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Overrides {

    const OPTION_OVERRIDES = '_cc_dispatcher_overrides';

    public static function get_overrides() {
        $saved = get_option( self::OPTION_OVERRIDES, array() );
        return is_array( $saved ) ? $saved : array();
    }

    public static function is_vendor_blocked( $vendor_id ) {
        $overrides = self::get_overrides();
        $vendor_id = intval( $vendor_id );

        return ! empty( $overrides['vendor_blocklist'][ $vendor_id ] );
    }

    public static function is_vendor_manual_only( $vendor_id ) {
        $overrides = self::get_overrides();
        $vendor_id = intval( $vendor_id );

        return ! empty( $overrides['vendor_manual_only'][ $vendor_id ] );
    }

    public static function is_shipment_locked( $shipment_id ) {
        $overrides  = self::get_overrides();
        $shipment_id = intval( $shipment_id );
        if ( empty( $overrides['shipment_locks'] ) || ! is_array( $overrides['shipment_locks'] ) ) {
            return false;
        }
        return ! empty( $overrides['shipment_locks'][ $shipment_id ] );
    }

    public static function is_courier_blocked( $courier_id ) {
        $overrides  = self::get_overrides();
        $courier_id = intval( $courier_id );
        if ( empty( $overrides['courier_blocklist'] ) || ! is_array( $overrides['courier_blocklist'] ) ) {
            return false;
        }
        return ! empty( $overrides['courier_blocklist'][ $courier_id ] );
    }

    public static function get_forced_courier_for_shipment( $shipment_id ) {
        $overrides   = self::get_overrides();
        $shipment_id = intval( $shipment_id );
        if ( empty( $overrides['shipment_forced_courier'] ) || ! is_array( $overrides['shipment_forced_courier'] ) ) {
            return 0;
        }
        $cid = isset( $overrides['shipment_forced_courier'][ $shipment_id ] )
            ? intval( $overrides['shipment_forced_courier'][ $shipment_id ] )
            : 0;
        return $cid > 0 ? $cid : 0;
    }

    public static function get_courier_multiplier( $courier_id ) {
        $overrides  = self::get_overrides();
        $courier_id = intval( $courier_id );
        if ( empty( $overrides['courier_weight_adjustments'][ $courier_id ] ) ) {
            return 1.0;
        }
        $factor = floatval( $overrides['courier_weight_adjustments'][ $courier_id ] );
        return $factor > 0 ? $factor : 1.0;
    }
}