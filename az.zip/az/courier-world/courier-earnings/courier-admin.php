<?php
/**
 * Courier Earnings — Admin HQ (Cinematic Don Panel)
 * - Global overview
 * - Courier lookup + wallet drilldown
 * - Cron health + clearing conversion forecast
 * - Payout request queues (scheduled + instant)
 * - Held queue + actions
 * - Forfeited ledger review
 *
 * Requires:
 * - Caricove_Courier_Earnings_Engine (engine)
 * - Caricove_Courier_Earnings_Payouts (payout request gate)
 */

if ( ! defined('ABSPATH') ) { exit; }

if ( ! class_exists('Caricove_Courier_Earnings_Admin') ) {

class Caricove_Courier_Earnings_Admin {

    const PAGE = 'cc-courier-earnings-hq';

    public static function boot() {
        add_action('admin_menu', array(__CLASS__, 'menu'), 90);

        // Held actions
        add_action('admin_post_cc_earnings_hold', array(__CLASS__, 'post_hold'));
        add_action('admin_post_cc_earnings_release', array(__CLASS__, 'post_release'));
        add_action('admin_post_cc_earnings_forfeit', array(__CLASS__, 'post_forfeit'));
        add_action('admin_post_cc_earnings_promoter', array(__CLASS__, 'post_promoter'));
    }

    public static function menu() {
        // Attach under Logistics if present; fallback to Tools
        $parent = 'caricove-logistics-admin';

        if ( self::parent_exists($parent) ) {
            add_submenu_page(
                $parent,
                'Courier Earnings',
                'Courier Earnings',
                'manage_options',
                self::PAGE,
                array(__CLASS__, 'render')
            );
            return;
        }

        add_management_page(
            'Courier Earnings',
            'Courier Earnings',
            'manage_options',
            self::PAGE,
            array(__CLASS__, 'render')
        );
    }

    protected static function parent_exists($slug) {
        global $menu;
        if ( ! is_array($menu) ) return false;
        foreach ($menu as $m) {
            if (!empty($m[2]) && $m[2] === $slug) return true;
        }
        return false;
    }

    /* =========================
     * Render
     * ======================= */

    public static function render() {
        if ( ! current_user_can('manage_options') ) return;

        $engine_ok  = class_exists('Caricove_Courier_Earnings_Engine');
        $payouts_ok = class_exists('Caricove_Courier_Earnings_Payouts');

        echo '<div class="wrap">';
        echo '<h1>Caricove — Courier Earnings HQ</h1>';
        echo self::css();

        if ( ! $engine_ok ) {
            echo '<div class="ccEHQ-note bad"><b>Engine not loaded.</b> (Caricove_Courier_Earnings_Engine missing)</div>';
            echo '</div>';
            return;
        }

        $tab = sanitize_key($_GET['tab'] ?? 'hq');
if ( ! in_array($tab, array('hq','courier','held','forfeited'), true) ) $tab = 'hq';

        echo '<div class="ccEHQ-tabs">';
        self::tab('hq','HQ Overview',$tab);
self::tab('courier','Courier Lookup',$tab);
self::tab('held','Held Queue',$tab);
self::tab('forfeited','Forfeited',$tab);
        self::render_promoter_notice();

        echo '</div>';

       if ( $tab === 'courier' ) {
    self::render_courier_lookup();
} elseif ( $tab === 'held' ) {
    self::render_held_queue();
} elseif ( $tab === 'forfeited' ) {
    self::render_forfeited_queue();
} else {
    self::render_hq_overview($payouts_ok);
}

        echo '</div>';
    }

    protected static function tab($id, $label, $active) {
        $u = admin_url('admin.php?page='.self::PAGE.'&tab='.$id);
        $cls = 'ccEHQ-tab'.($id===$active?' on':'');
        echo '<a class="'.esc_attr($cls).'" href="'.esc_url($u).'">'.esc_html($label).'</a>';
    }

    /* =========================
     * HQ Overview
     * ======================= */
     
     
     protected static function render_promoter_notice() {
    $msg = sanitize_key($_GET['cc_promoter'] ?? '');
    if ( $msg === '' ) return;

    $map = array(
        'available'       => array('ok',  'Earning promoted to Available.'),
        'held'            => array('ok',  'Earning moved to Held.'),
        'bad_id'          => array('bad', 'Invalid earning ID.'),
        'bad_status'      => array('bad', 'Only clearing or available earnings can be held.'),
        'not_clearing'    => array('bad', 'Only clearing earnings can be promoted to Available.'),
        'missing_method'  => array('bad', 'Hold method is missing from the earnings engine.'),
        'invalid_action'  => array('bad', 'Invalid promoter action.'),
    );

    if ( empty($map[$msg]) ) return;

    $tone = $map[$msg][0];
    $text = $map[$msg][1];

    echo '<div class="ccEHQ-note '.esc_attr($tone === 'bad' ? 'bad' : '').'">'.esc_html($text).'</div>';
}


    protected static function render_hq_overview($payouts_ok) {
        $totals = self::global_totals();
        $cron   = self::cron_health();

$scheduled_pending = 0;
$instant_pending   = 0;
$forfeited_count   = self::count_forfeited_entries();

if ( $payouts_ok ) {
    $req = Caricove_Courier_Earnings_Payouts::get_requests();
    foreach ( (array) $req as $r ) {
        $type   = (string)($r['type'] ?? '');
        $status = (string)($r['status'] ?? '');
        if ( $status !== 'requested' ) {
            continue;
        }
        if ( $type === 'instant' ) {
            $instant_pending++;
        } elseif ( $type === 'scheduled' ) {
            $scheduled_pending++;
        }
    }
}
        echo '<div class="ccEHQ-grid2">';

        // KPIs
        echo '<div class="ccEHQ-card">';
        echo '<div class="ccEHQ-head"><div class="ccEHQ-title">Global Wallet</div><div class="ccEHQ-chip">GYD only</div></div>';
        echo '<div class="ccEHQ-kpis">';
        echo self::kpi('Available',  self::money($totals['available']), 'green');
        echo self::kpi('Clearing',   self::money($totals['clearing']), 'yellow');
        echo self::kpi('Held',       self::money($totals['held']), 'purple');
        echo self::kpi('Paid',       self::money($totals['paid']), 'blue');
        echo '</div>';
        echo '<div class="ccEHQ-mini">These totals are summed from <span class="mono">'.esc_html(Caricove_Courier_Earnings_Engine::CPT_EARNING).'</span> ledger entries.</div>';
        echo '</div>';

        // Cron health + conversion
        echo '<div class="ccEHQ-card">';
        echo '<div class="ccEHQ-head"><div class="ccEHQ-title">Cron Health</div><div class="ccEHQ-chip '.($cron['healthy']?'ok':'warn').'">'.esc_html($cron['healthy']?'Healthy':'Needs attention').'</div></div>';

        echo '<div class="ccEHQ-kv"><span>Last clearing sweep</span><b>'.esc_html($cron['last_human']).'</b></div>';
        echo '<div class="ccEHQ-kv"><span>Moved (clearing → available)</span><b>'.esc_html($cron['last_moved']).'</b></div>';
        echo '<div class="ccEHQ-kv"><span>Last external cron hit</span><b>'.esc_html($cron['last_hit_human']).'</b></div>';
        echo '<div class="ccEHQ-kv"><span>Last cron result</span><b>'.esc_html($cron['last_result']).' — '.esc_html($cron['last_result_human']).'</b></div>';
        echo '<div class="ccEHQ-kv"><span>Cron script version</span><b>'.esc_html($cron['script_version']).'</b></div>';
        echo '<div class="ccEHQ-kv"><span>Expected cadence</span><b>'.esc_html($cron['next_human']).'</b></div>';
        echo '<div class="ccEHQ-kv"><span>Status window</span><b>'.esc_html($cron['next_countdown']).'</b></div>';
        echo '<div class="ccEHQ-kv"><span>Overdue clearing rows still waiting</span><b>'.esc_html($cron['overdue_count']).'</b></div>';

        echo '<div class="ccEHQ-divider"></div>';

        echo '<div class="ccEHQ-head" style="margin-top:0"><div class="ccEHQ-title">Clearing Conversion Forecast</div></div>';
        echo '<div class="ccEHQ-kv"><span>Unlocking within 24h</span><b>'.esc_html(self::money($cron['unlock_24h'])).'</b></div>';
        echo '<div class="ccEHQ-kv"><span>Unlocking within 72h</span><b>'.esc_html(self::money($cron['unlock_72h'])).'</b></div>';
        echo '<div class="ccEHQ-mini">“Unlocking” is calculated from clearing entries ordered by <span class="mono">'.esc_html(Caricove_Courier_Earnings_Engine::META_CLEARING_UNTIL).'</span>.</div>';

        echo '</div>';

        echo '</div>'; // grid2

      echo '<div class="ccEHQ-grid2">';

echo '<div class="ccEHQ-card">';
echo '<div class="ccEHQ-head"><div class="ccEHQ-title">Payout Requests</div><div class="ccEHQ-chip '.($scheduled_pending? 'warn':'ok').'">'.esc_html($scheduled_pending.' pending').'</div></div>';
echo '<div class="ccEHQ-kv"><span>Scheduled payout requests awaiting action</span><b>'.esc_html($scheduled_pending).'</b></div>';
echo '<div class="ccEHQ-mini">Weekly auto-payout logic has been retired here. Scheduled courier cash-outs now live in the payout request queue until you approve or reject them.</div>';

echo '</div>';

echo '<div class="ccEHQ-card">';
echo '<div class="ccEHQ-head"><div class="ccEHQ-title">Instant Payout Requests</div><div class="ccEHQ-chip '.($instant_pending? 'warn':'ok').'">'.esc_html($instant_pending.' pending').'</div></div>';
echo '<div class="ccEHQ-kv"><span>Instant payout requests awaiting action</span><b>'.esc_html($instant_pending).'</b></div>';
echo '<div class="ccEHQ-mini">Instant payout requests never deduct Available until you approve them.</div>';

echo '</div>';

echo '</div>'; // grid2



echo '<div class="ccEHQ-card">';
echo '<div class="ccEHQ-head"><div class="ccEHQ-title">Earnings Promoter</div><div class="ccEHQ-chip warn">Admin override</div></div>';
echo '<div class="ccEHQ-mini">Move a courier earning from Clearing to Available, or place an earning on Hold. Promotion is blocked unless the earning is currently clearing.</div>';

echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" class="ccEHQ-holdForm">';
wp_nonce_field('cc_earnings_promoter_admin','_cc_nonce');
echo '<input type="hidden" name="action" value="cc_earnings_promoter">';
echo '<input type="hidden" name="redirect" value="'.esc_attr(admin_url('admin.php?page='.self::PAGE.'&tab=hq')).'">';

echo '<input class="ccEHQ-input" name="earning_id" placeholder="Earning ID, e.g. 12345">';

echo '<select class="ccEHQ-select" name="promoter_action">
        <option value="promote_available">Promote clearing → available</option>
        <option value="hold">Move earning → held</option>
      </select>';

echo '<select class="ccEHQ-select" name="reason">
        <option value="manual_admin">manual_admin</option>
        <option value="cron_correction">cron_correction</option>
        <option value="dispute">dispute</option>
        <option value="fraud_review">fraud_review</option>
      </select>';

echo '<input class="ccEHQ-input" name="note" placeholder="Admin note / reason">';
echo '<button class="ccEHQ-btn" type="submit">Apply</button>';
echo '</form>';

echo '<div class="ccEHQ-mini">Recommended use: promote only when the delivery truth is settled and you intentionally want the courier earning released before the normal clearing window.</div>';
echo '</div>';
        echo '<div class="ccEHQ-card">';
        echo '<div class="ccEHQ-head"><div class="ccEHQ-title">Hold / Forfeit Control</div><div class="ccEHQ-chip">'.esc_html($forfeited_count.' forfeited').'</div></div>';
        echo '<div class="ccEHQ-kv"><span>Held entries are still under review</span><b><a class="ccEHQ-link" href="'.esc_url(admin_url('admin.php?page='.self::PAGE.'&tab=held')).'">Open held queue</a></b></div>';
        echo '<div class="ccEHQ-kv"><span>Forfeited entries have their own audit trail now</span><b><a class="ccEHQ-link" href="'.esc_url(admin_url('admin.php?page='.self::PAGE.'&tab=forfeited')).'">Open forfeited</a></b></div>';
        echo '<div class="ccEHQ-mini">Forfeited amounts remain out of the courier wallet, but they no longer disappear into the generic paid bucket on the admin side.</div>';
        echo '</div>';
    }

    /* =========================
     * Courier Lookup + Drilldown
     * ======================= */

    protected static function render_courier_lookup() {
        $q = sanitize_text_field($_GET['q'] ?? '');
        $courier_id = intval($_GET['courier_id'] ?? 0);

        echo '<div class="ccEHQ-card">';
        echo '<div class="ccEHQ-head"><div class="ccEHQ-title">Courier Lookup</div><div class="ccEHQ-chip">ID / name / email</div></div>';

        echo '<form method="get" class="ccEHQ-form">';
        echo '<input type="hidden" name="page" value="'.esc_attr(self::PAGE).'">';
        echo '<input type="hidden" name="tab" value="courier">';
        echo '<input class="ccEHQ-input" name="q" value="'.esc_attr($q).'" placeholder="Search courier (e.g. 41, John, john@email.com)">';
        echo '<button class="ccEHQ-btn" type="submit">Search</button>';
        echo '</form>';

        $users = array();
        if ( $q !== '' ) {
            $args = array(
                'number' => 20,
                'orderby'=> 'ID',
                'order'  => 'DESC',
                'search' => '*'.$q.'*',
                'search_columns' => array('user_login','user_email','display_name'),
            );
            if ( ctype_digit($q) ) {
                $args = array('include'=>array(intval($q)));
            }
            $users = get_users($args);
        }

        if ( $users ) {
            echo '<div class="ccEHQ-tablewrap"><table class="ccEHQ-table ccEHQ-table-lookup">';
            echo '<thead><tr><th class="ccEHQ-col-id">ID</th><th>Courier</th><th>Email</th><th class="ccEHQ-col-actions">Open</th></tr></thead><tbody>';
            foreach ($users as $u) {
                $open = admin_url('admin.php?page='.self::PAGE.'&tab=courier&courier_id='.$u->ID);
                echo '<tr>';
                echo '<td class="mono ccEHQ-col-id">#'.esc_html($u->ID).'</td>';
                echo '<td>'.esc_html($u->display_name).'</td>';
                echo '<td class="muted">'.esc_html($u->user_email).'</td>';
                echo '<td class="ccEHQ-col-actions"><a class="ccEHQ-btnSmall" href="'.esc_url($open).'">Open Wallet</a></td>';
                echo '</tr>';
            }
            echo '</tbody></table></div>';
        } elseif ($q !== '') {
            echo '<div class="ccEHQ-mini">No results for that query.</div>';
        }

        echo '</div>';

        if ( $courier_id ) {
            self::render_courier_wallet($courier_id);
        } else {
            echo '<div class="ccEHQ-mini">Tip: search and click “Open Wallet” to see Available/Clearing/Held + clearing countdowns.</div>';
        }
    }

    protected static function render_courier_wallet($courier_id) {
        $courier_id = intval($courier_id);
        $u = get_user_by('id',$courier_id);

        if ( ! $u ) {
            echo '<div class="ccEHQ-note bad">Courier not found.</div>';
            return;
        }

        $b = Caricove_Courier_Earnings_Engine::get_balances_for_courier($courier_id);

        $forecast = self::courier_clearing_forecast($courier_id);
        $rows = self::ledger_rows_for_courier($courier_id, 80);

        echo '<div class="ccEHQ-card">';
        echo '<div class="ccEHQ-head">';
        echo '<div class="ccEHQ-title">Courier Wallet — '.esc_html($u->display_name).' <span class="muted mono">#'.esc_html($courier_id).'</span></div>';
        echo '<div class="ccEHQ-chip">GYD</div>';
        echo '</div>';

        echo '<div class="ccEHQ-kpis">';
        echo self::kpi('Available', self::money($b['available'] ?? 0), 'green');
        echo self::kpi('Clearing',  self::money($b['clearing'] ?? 0), 'yellow');
        echo self::kpi('Held',      self::money($b['held'] ?? 0), 'purple');
        echo self::kpi('Paid',      self::money($b['paid'] ?? 0), 'blue');
        echo '</div>';

        echo '<div class="ccEHQ-divider"></div>';

        echo '<div class="ccEHQ-grid2">';
        echo '<div>';
        echo '<div class="ccEHQ-subtitle">Clearing → Available</div>';
        echo '<div class="ccEHQ-kv"><span>Next unlock in</span><b>'.esc_html($forecast['next_unlock_in']).'</b></div>';
        echo '<div class="ccEHQ-kv"><span>Next unlock amount</span><b>'.esc_html(self::money($forecast['next_unlock_amount'])).'</b></div>';
        echo '<div class="ccEHQ-kv"><span>Unlocking within 24h</span><b>'.esc_html(self::money($forecast['unlock_24h'])).'</b></div>';
        echo '<div class="ccEHQ-kv"><span>Unlocking within 72h</span><b>'.esc_html(self::money($forecast['unlock_72h'])).'</b></div>';
        echo '<div class="ccEHQ-mini">This is calculated from each clearing row’s <span class="mono">clearing_until</span>.</div>';
        echo '</div>';

        echo '<div>';
        echo '<div class="ccEHQ-subtitle">Admin Power</div>';
        echo '<div class="ccEHQ-mini">Use Held to pause funds from <b>clearing</b> or <b>available</b>. Courier gets an auto-email immediately.</div>';
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" class="ccEHQ-holdForm">';
        wp_nonce_field('cc_earnings_hold_admin','_cc_nonce');
        echo '<input type="hidden" name="action" value="cc_earnings_hold">';
        echo '<input type="hidden" name="redirect" value="'.esc_attr(admin_url('admin.php?page='.self::PAGE.'&tab=courier&courier_id='.$courier_id)).'">';
        echo '<input class="ccEHQ-input" name="earning_id" placeholder="Earning ID to hold (from table below)">';
        echo '<select class="ccEHQ-select" name="reason">
                <option value="dispute">dispute</option>
                <option value="fraud_review">fraud_review</option>
                <option value="manual_admin">manual_admin</option>
              </select>';
        echo '<input class="ccEHQ-input" name="note" placeholder="Short note (goes to courier email)">';
        echo '<button class="ccEHQ-btn" type="submit">Hold + Email</button>';
        echo '</form>';
        echo '</div>';
        echo '</div>'; // grid2

        echo '<div class="ccEHQ-divider"></div>';
        echo '<div class="ccEHQ-subtitle">Ledger (latest 80)</div>';

        echo '<div class="ccEHQ-tablewrap"><table class="ccEHQ-table ccEHQ-table-ledger">';
        echo '<thead><tr>
                <th class="ccEHQ-col-id">Earning</th>
                <th class="ccEHQ-col-id">Shipment</th>
                <th class="ccEHQ-col-status">Status</th>
                <th class="ccEHQ-col-money">Net</th>
                <th class="ccEHQ-col-money">Gross</th>
                <th class="ccEHQ-col-time">Clears</th>
                <th class="ccEHQ-col-note">Held note</th>
              </tr></thead><tbody>';

        foreach ($rows as $r) {
            $badge = self::badge($r['status']);
            echo '<tr>';
            echo '<td class="mono ccEHQ-col-id">#'.esc_html($r['earning_id']).'</td>';
            echo '<td class="mono ccEHQ-col-id">#'.esc_html($r['shipment_id']).'</td>';
            echo '<td class="ccEHQ-col-status">'.$badge.'</td>';
            echo '<td class="ccEHQ-col-money">'.esc_html(self::money($r['net'])).'</td>';
            echo '<td class="ccEHQ-col-money muted">'.esc_html(self::money($r['gross'])).'</td>';
            echo '<td class="mono ccEHQ-col-time">'.esc_html($r['clears_on']).'</td>';
            echo '<td class="muted ccEHQ-col-note">'.esc_html($r['held_note']).'</td>';
            echo '</tr>';
        }

        echo '</tbody></table></div>';
        echo '</div>';
    }

    /* =========================
     * Instant approvals tab
     * ======================= */

    protected static function render_payouts($payouts_ok, $type = 'instant') {
        $type = ($type === 'scheduled') ? 'scheduled' : 'instant';
        $title = ($type === 'scheduled') ? 'Payout Requests' : 'Instant Payout Requests';
        $empty = ($type === 'scheduled') ? 'No pending scheduled payout requests.' : 'No pending instant payout requests.';

        echo '<div class="ccEHQ-card">';
        echo '<div class="ccEHQ-head"><div class="ccEHQ-title">'.esc_html($title).'</div><div class="ccEHQ-chip">'.esc_html($payouts_ok?'Live':'Missing module').'</div></div>';

        if ( ! $payouts_ok ) {
            echo '<div class="ccEHQ-note bad">Payout module not loaded.</div></div>';
            return;
        }

        $req = Caricove_Courier_Earnings_Payouts::get_requests();
        $pending = array_values(array_filter($req, function($r) use ($type){
            return ($r['type'] ?? '') === $type && ($r['status'] ?? '') === 'requested';
        }));

        if ( ! $pending ) {
            echo '<div class="ccEHQ-mini">'.esc_html($empty).'</div></div>';
            return;
        }

        echo '<div class="ccEHQ-tablewrap"><table class="ccEHQ-table ccEHQ-table-payouts">';
        echo '<thead><tr><th class="ccEHQ-col-id">ID</th><th>Courier</th><th class="ccEHQ-col-money">Amount</th><th class="ccEHQ-col-money">Fee</th><th class="ccEHQ-col-money">Net</th><th class="ccEHQ-col-time">When</th><th class="ccEHQ-col-actions">Actions</th></tr></thead><tbody>';

        foreach ($pending as $r) {
            $cid = intval($r['courier_id'] ?? 0);
            $u = $cid ? get_user_by('id',$cid) : null;
            $name = $u ? ($u->display_name.' (#'.$cid.')') : ('#'.$cid);

            $approve = wp_nonce_url(admin_url('admin-post.php?action=cc_payout_approve&id='.rawurlencode($r['id'])), 'cc_payout_admin');
            $reject  = wp_nonce_url(admin_url('admin-post.php?action=cc_payout_reject&id='.rawurlencode($r['id'])), 'cc_payout_admin');

            echo '<tr>';
            echo '<td class="mono ccEHQ-col-id">'.esc_html($r['id']).'</td>';
            echo '<td>'.esc_html($name).'</td>';
            echo '<td class="ccEHQ-col-money">'.esc_html(self::money($r['amount_gyd'] ?? 0)).'</td>';
            echo '<td class="ccEHQ-col-money muted">'.esc_html(self::money($r['fee_gyd'] ?? 0)).'</td>';
            echo '<td class="ccEHQ-col-money">'.esc_html(self::money($r['net_gyd'] ?? 0)).'</td>';
            echo '<td class="mono ccEHQ-col-time">'.esc_html(gmdate('Y-m-d H:i', intval($r['ts'] ?? time()))).' UTC</td>';
                        $hold = wp_nonce_url(admin_url('admin-post.php?action=cc_payout_hold&id='.rawurlencode($r['id'])), 'cc_payout_admin');
            echo '<td class="ccEHQ-col-actions"><a class="ccEHQ-btnSmall" href="'.esc_url($approve).'">Approve</a> <a class="ccEHQ-btnSmall ghost" href="'.esc_url($hold).'">Hold</a> <a class="ccEHQ-btnSmall ghost" href="'.esc_url($reject).'">Reject</a></td>';
            echo '</tr>';
        }

        echo '</tbody></table></div></div>';
    }

    /* =========================
     * Held queue tab
     * ======================= */

    protected static function render_held_queue() {
        $held = get_posts(array(
            'post_type'      => Caricove_Courier_Earnings_Engine::CPT_EARNING,
            'post_status'    => 'any',
            'posts_per_page' => 80,
            'orderby'        => 'date',
            'order'          => 'DESC',
            'fields'         => 'ids',
            'meta_query'     => array(
                array('key'=> Caricove_Courier_Earnings_Engine::META_STATUS, 'value'=>'held'),
            ),
        ));

        echo '<div class="ccEHQ-card">';
        echo '<div class="ccEHQ-head"><div class="ccEHQ-title">Held Queue</div><div class="ccEHQ-chip">Email auto-sent</div></div>';
        echo '<div class="ccEHQ-mini">Held is your dispute court: release pays the courier now; forfeit moves the ledger into true forfeited status.</div>';

        if ( ! $held ) {
            echo '<div class="ccEHQ-mini">No held entries.</div></div>';
            return;
        }

        echo '<div class="ccEHQ-tablewrap"><table class="ccEHQ-table ccEHQ-table-held">';
       echo '<thead><tr><th class="ccEHQ-col-id">Earning</th><th class="ccEHQ-col-id">Shipment</th><th>Courier</th><th class="ccEHQ-col-money">Net</th><th>Reason</th><th class="ccEHQ-col-note">Note</th><th class="ccEHQ-col-time">Held at</th></tr></thead><tbody>';

        foreach ($held as $eid) {
            $sid = intval(get_post_meta($eid, Caricove_Courier_Earnings_Engine::META_SHIPMENT_ID, true));
            $cid = intval(get_post_meta($eid, Caricove_Courier_Earnings_Engine::META_COURIER_ID, true));
            $amt = floatval(get_post_meta($eid, Caricove_Courier_Earnings_Engine::META_AMOUNT_GYD, true));
            $reason = (string)get_post_meta($eid, Caricove_Courier_Earnings_Engine::META_HELD_REASON, true);
            $note = (string)get_post_meta($eid, Caricove_Courier_Earnings_Engine::META_HELD_NOTE, true);
            $held_ts = intval(get_post_meta($eid, Caricove_Courier_Earnings_Engine::META_HELD_AT_TS, true));

            $u = $cid ? get_user_by('id',$cid) : null;
            $name = $u ? ($u->display_name.' (#'.$cid.')') : ('#'.$cid);

           

            echo '<tr>';
            echo '<td class="mono ccEHQ-col-id">#'.esc_html($eid).'</td>';
            echo '<td class="mono ccEHQ-col-id">#'.esc_html($sid).'</td>';
            echo '<td>'.esc_html($name).'</td>';
            echo '<td class="ccEHQ-col-money">'.esc_html(self::money($amt)).'</td>';
            echo '<td>'.esc_html($reason).'</td>';
            echo '<td class="muted ccEHQ-col-note">'.esc_html($note).'</td>';
            echo '<td class="mono ccEHQ-col-time">'.esc_html($held_ts? gmdate('Y-m-d H:i',$held_ts).' UTC':'—').'</td>';
           
            echo '</tr>';
        }

        echo '</tbody></table></div></div>';
    }

    protected static function render_forfeited_queue() {
        $forfeited = get_posts(array(
            'post_type'      => Caricove_Courier_Earnings_Engine::CPT_EARNING,
            'post_status'    => 'any',
            'posts_per_page' => 120,
            'orderby'        => 'meta_value_num',
            'order'          => 'DESC',
            'fields'         => 'ids',
            'meta_key'       => Caricove_Courier_Earnings_Engine::META_HELD_RESOLVED_AT,
            'meta_query'     => array(
                array('key'=> Caricove_Courier_Earnings_Engine::META_STATUS, 'value'=>'forfeited'),
            ),
        ));

        echo '<div class="ccEHQ-card">';
        echo '<div class="ccEHQ-head"><div class="ccEHQ-title">Forfeited</div><div class="ccEHQ-chip">Audit trail</div></div>';
        echo '<div class="ccEHQ-mini">These are true forfeited courier earning ledgers. They stay out of the courier wallet and remain separated from Paid.</div>';

        if ( ! $forfeited ) {
            echo '<div class="ccEHQ-mini">No forfeited entries.</div></div>';
            return;
        }

        echo '<div class="ccEHQ-tablewrap"><table class="ccEHQ-table ccEHQ-table-forfeited">';
        echo '<thead><tr><th class="ccEHQ-col-id">Earning</th><th class="ccEHQ-col-id">Shipment</th><th>Courier</th><th class="ccEHQ-col-money">Net</th><th>Reason</th><th class="ccEHQ-col-note">Note</th><th class="ccEHQ-col-time">Forfeited at</th></tr></thead><tbody>';

        foreach ($forfeited as $eid) {
            $sid = intval(get_post_meta($eid, Caricove_Courier_Earnings_Engine::META_SHIPMENT_ID, true));
            $cid = intval(get_post_meta($eid, Caricove_Courier_Earnings_Engine::META_COURIER_ID, true));
            $amt = floatval(get_post_meta($eid, Caricove_Courier_Earnings_Engine::META_AMOUNT_GYD, true));
            $reason = (string)get_post_meta($eid, Caricove_Courier_Earnings_Engine::META_HELD_REASON, true);
            $note = (string)get_post_meta($eid, Caricove_Courier_Earnings_Engine::META_HELD_NOTE, true);
            $resolved_ts = intval(get_post_meta($eid, Caricove_Courier_Earnings_Engine::META_HELD_RESOLVED_AT, true));

            $u = $cid ? get_user_by('id',$cid) : null;
            $name = $u ? ($u->display_name.' (#'.$cid.')') : ('#'.$cid);

            echo '<tr>';
            echo '<td class="mono ccEHQ-col-id">#'.esc_html($eid).'</td>';
            echo '<td class="mono ccEHQ-col-id">#'.esc_html($sid).'</td>';
            echo '<td>'.esc_html($name).'</td>';
            echo '<td class="ccEHQ-col-money">'.esc_html(self::money($amt)).'</td>';
            echo '<td>'.esc_html($reason ?: '—').'</td>';
            echo '<td class="muted ccEHQ-col-note">'.esc_html($note ?: '—').'</td>';
            echo '<td class="mono ccEHQ-col-time">'.esc_html($resolved_ts ? gmdate('Y-m-d H:i', $resolved_ts).' UTC' : '—').'</td>';
            echo '</tr>';
        }

        echo '</tbody></table></div></div>';
    }

    /* =========================
     * Held post handlers
     * ======================= */

    public static function post_hold() {
        if ( ! current_user_can('manage_options') ) wp_die('Unauthorized');
        check_admin_referer('cc_earnings_hold_admin','_cc_nonce');

        $eid = intval($_POST['earning_id'] ?? 0);
        $reason = sanitize_key($_POST['reason'] ?? 'dispute');
        $note = sanitize_text_field($_POST['note'] ?? '');
        $redirect = esc_url_raw($_POST['redirect'] ?? admin_url('admin.php?page='.self::PAGE.'&tab=held'));

        if ( $eid && method_exists('Caricove_Courier_Earnings_Engine','hold_entry') ) {
            Caricove_Courier_Earnings_Engine::hold_entry($eid, $reason, $note, get_current_user_id());
        }

        wp_safe_redirect($redirect);
        exit;
    }

    public static function post_release() {
        if ( ! current_user_can('manage_options') ) wp_die('Unauthorized');
        check_admin_referer('cc_earnings_hold_admin');

        $eid = intval($_GET['earning_id'] ?? 0);
        if ( $eid && method_exists('Caricove_Courier_Earnings_Engine','release_hold') ) {
            Caricove_Courier_Earnings_Engine::release_hold($eid, get_current_user_id());
        }

        wp_safe_redirect(admin_url('admin.php?page='.self::PAGE.'&tab=held&paid=1'));
        exit;
    }

    public static function post_forfeit() {
        if ( ! current_user_can('manage_options') ) wp_die('Unauthorized');
        check_admin_referer('cc_earnings_hold_admin');

        $eid = intval($_GET['earning_id'] ?? 0);
        if ( $eid && method_exists('Caricove_Courier_Earnings_Engine','forfeit_hold') ) {
            Caricove_Courier_Earnings_Engine::forfeit_hold($eid, get_current_user_id());
        }

        wp_safe_redirect(admin_url('admin.php?page='.self::PAGE.'&tab=held&forfeited=1'));
        exit;
    }
    
    
    
    public static function post_promoter() {
    if ( ! current_user_can('manage_options') ) {
        wp_die('Unauthorized');
    }

    check_admin_referer('cc_earnings_promoter_admin','_cc_nonce');

    $eid      = absint($_POST['earning_id'] ?? 0);
    $action   = sanitize_key(wp_unslash($_POST['promoter_action'] ?? ''));
    $reason   = sanitize_key(wp_unslash($_POST['reason'] ?? 'manual_admin'));
    $note     = sanitize_text_field(wp_unslash($_POST['note'] ?? ''));
    $redirect = esc_url_raw(wp_unslash($_POST['redirect'] ?? admin_url('admin.php?page='.self::PAGE.'&tab=hq')));

    $redirect = remove_query_arg('cc_promoter', $redirect);

    if ( ! $eid || get_post_type($eid) !== Caricove_Courier_Earnings_Engine::CPT_EARNING ) {
        wp_safe_redirect(add_query_arg('cc_promoter', 'bad_id', $redirect));
        exit;
    }

    $status = (string) get_post_meta($eid, Caricove_Courier_Earnings_Engine::META_STATUS, true);
    $now    = current_time('timestamp', true);

    if ( $action === 'promote_available' ) {
        if ( $status !== 'clearing' ) {
            wp_safe_redirect(add_query_arg('cc_promoter', 'not_clearing', $redirect));
            exit;
        }

        update_post_meta($eid, Caricove_Courier_Earnings_Engine::META_STATUS, 'available');
        update_post_meta($eid, Caricove_Courier_Earnings_Engine::META_CLEARING_UNTIL, $now);

        update_post_meta($eid, '_cc_earnings_admin_promoted_at', $now);
        update_post_meta($eid, '_cc_earnings_admin_promoted_by', get_current_user_id());
        update_post_meta($eid, '_cc_earnings_admin_promoted_reason', $reason);
        update_post_meta($eid, '_cc_earnings_admin_promoted_note', $note);

        wp_safe_redirect(add_query_arg('cc_promoter', 'available', $redirect));
        exit;
    }

    if ( $action === 'hold' ) {
        if ( ! in_array($status, array('clearing','available'), true) ) {
            wp_safe_redirect(add_query_arg('cc_promoter', 'bad_status', $redirect));
            exit;
        }

        if ( ! method_exists('Caricove_Courier_Earnings_Engine','hold_entry') ) {
            wp_safe_redirect(add_query_arg('cc_promoter', 'missing_method', $redirect));
            exit;
        }

        Caricove_Courier_Earnings_Engine::hold_entry($eid, $reason, $note, get_current_user_id());

        wp_safe_redirect(add_query_arg('cc_promoter', 'held', $redirect));
        exit;
    }

    wp_safe_redirect(add_query_arg('cc_promoter', 'invalid_action', $redirect));
    exit;
}

    /* =========================
     * Data helpers
     * ======================= */

    protected static function ledger_rows_for_courier($courier_id, $limit = 80) {
        $courier_id = intval($courier_id);
        $limit = max(1, intval($limit));

        $ids = get_posts(array(
            'post_type'      => Caricove_Courier_Earnings_Engine::CPT_EARNING,
            'post_status'    => 'any',
            'posts_per_page' => $limit,
            'orderby'        => 'date',
            'order'          => 'DESC',
            'fields'         => 'ids',
            'meta_query'     => array(
                array('key'=> Caricove_Courier_Earnings_Engine::META_COURIER_ID, 'value'=> $courier_id),
            ),
        ));

        $rows = array();
        foreach ($ids as $eid) {
            $rows[] = array(
                'earning_id' => intval($eid),
                'shipment_id'=> intval(get_post_meta($eid, Caricove_Courier_Earnings_Engine::META_SHIPMENT_ID, true)),
                'status'     => (string)get_post_meta($eid, Caricove_Courier_Earnings_Engine::META_STATUS, true),
                'net'        => floatval(get_post_meta($eid, Caricove_Courier_Earnings_Engine::META_AMOUNT_GYD, true)),
                'gross'      => floatval(get_post_meta($eid, Caricove_Courier_Earnings_Engine::META_GROSS_GYD, true)),
                'clears_on'  => ( $c = intval(get_post_meta($eid, Caricove_Courier_Earnings_Engine::META_CLEARING_UNTIL, true)) ) ? gmdate('Y-m-d', $c) : '—',
                'held_note'  => (string)get_post_meta($eid, Caricove_Courier_Earnings_Engine::META_HELD_NOTE, true),
            );
        }
        return $rows;
    }

    protected static function courier_clearing_forecast($courier_id) {
        $courier_id = intval($courier_id);
        $now = current_time('timestamp', true);

        Caricove_Courier_Earnings_Engine::run_clearing_to_available(array(
            'courier_id' => $courier_id,
            'limit'      => 500,
            'reason'     => 'admin_forecast_read',
        ));

        $clearing = get_posts(array(
            'post_type'      => Caricove_Courier_Earnings_Engine::CPT_EARNING,
            'post_status'    => 'any',
            'posts_per_page' => 500,
            'orderby'        => 'meta_value_num',
            'order'          => 'ASC',
            'fields'         => 'ids',
            'meta_query'     => array(
                array('key'=> Caricove_Courier_Earnings_Engine::META_COURIER_ID, 'value'=> $courier_id),
                array('key'=> Caricove_Courier_Earnings_Engine::META_STATUS, 'value'=> 'clearing'),
                array(
                    'key'     => Caricove_Courier_Earnings_Engine::META_CLEARING_UNTIL,
                    'value'   => $now,
                    'compare' => '>',
                    'type'    => 'NUMERIC',
                ),
            ),
            'meta_key' => Caricove_Courier_Earnings_Engine::META_CLEARING_UNTIL,
        ));

        $next_ts = 0;
        $next_amt = 0.0;
        $unlock_24h = 0.0;
        $unlock_72h = 0.0;

        foreach ($clearing as $eid) {
            $until = intval(get_post_meta($eid, Caricove_Courier_Earnings_Engine::META_CLEARING_UNTIL, true));
            $amt   = floatval(get_post_meta($eid, Caricove_Courier_Earnings_Engine::META_AMOUNT_GYD, true));

            if ( $until <= 0 ) {
                continue;
            }

            if ( $next_ts === 0 || $until < $next_ts ) {
                $next_ts = $until;
                $next_amt = $amt;
            } elseif ( $until === $next_ts ) {
                $next_amt += $amt;
            }

            if ( $until <= ($now + 24*HOUR_IN_SECONDS) ) $unlock_24h += $amt;
            if ( $until <= ($now + 72*HOUR_IN_SECONDS) ) $unlock_72h += $amt;
        }

        $next_in = $next_ts ? self::countdown($next_ts - $now) : '—';

        return array(
            'next_unlock_in'    => $next_in,
            'next_unlock_amount'=> $next_amt,
            'unlock_24h'        => $unlock_24h,
            'unlock_72h'        => $unlock_72h,
        );
    }

   protected static function cron_health() {
        $last_sweep  = get_option('_cc_earnings_last_clearing_sweep', array());
        $last_hit    = get_option('caricove_earnings_last_cron_hit', array());
        $last_result = get_option('caricove_earnings_last_cron_result', array());

        $last_ts       = intval($last_sweep['ts'] ?? 0);
        $last_moved    = intval($last_sweep['moved'] ?? 0);
        $hit_at_gmt    = (string) ($last_hit['hit_at_gmt'] ?? '');
        $script_ver    = (string) ($last_hit['script_version'] ?? 'n/a');
        $result_status = (string) ($last_result['status'] ?? 'n/a');
        $result_time   = (string) ($last_result['finished_at_gmt'] ?? '');
        $now           = current_time('timestamp', true);

        $last_hit_ts = $hit_at_gmt ? strtotime($hit_at_gmt . ' UTC') : 0;

        $overdue_ids = get_posts(array(
            'post_type'      => Caricove_Courier_Earnings_Engine::CPT_EARNING,
            'post_status'    => 'any',
            'posts_per_page' => 200,
            'fields'         => 'ids',
            'meta_query'     => array(
                'relation' => 'AND',
                array(
                    'key'   => Caricove_Courier_Earnings_Engine::META_STATUS,
                    'value' => 'clearing',
                ),
                array(
                    'key'     => Caricove_Courier_Earnings_Engine::META_CLEARING_UNTIL,
                    'value'   => $now,
                    'compare' => '<=',
                    'type'    => 'NUMERIC',
                ),
            ),
        ));

        $unlock = self::unlock_forecast_global();

        /*
         * Healthy means:
         * - external cron hit recently (within 10 minutes), and
         * - last result did not fail.
         */
        $healthy = false;
        if ( $last_hit_ts > 0 && ($now - $last_hit_ts) <= 600 && $result_status !== 'fail' && $result_status !== 'class_unavailable' ) {
            $healthy = true;
        }

        return array(
            'last_human'        => $last_ts ? gmdate('Y-m-d H:i:s', $last_ts) . ' UTC' : '—',
            'last_moved'        => $last_moved,
            'next_human'        => 'External cron',
            'next_countdown'    => $healthy ? '≤ 10m expected' : 'late / unknown',
            'healthy'           => $healthy,
            'unlock_24h'        => $unlock['24h'],
            'unlock_72h'        => $unlock['72h'],
            'last_hit_human'    => $hit_at_gmt ? $hit_at_gmt . ' UTC' : '—',
            'last_result'       => $result_status,
            'last_result_human' => $result_time ? $result_time . ' UTC' : '—',
            'script_version'    => $script_ver,
            'overdue_count'     => count($overdue_ids),
        );
    }

    protected static function unlock_forecast_global() {
        $now = current_time('timestamp', true);

        Caricove_Courier_Earnings_Engine::run_clearing_to_available(array(
            'limit'  => 1500,
            'reason' => 'admin_global_forecast_read',
        ));

        $ids = get_posts(array(
            'post_type'      => Caricove_Courier_Earnings_Engine::CPT_EARNING,
            'post_status'    => 'any',
            'posts_per_page' => 1500,
            'fields'         => 'ids',
            'meta_query'     => array(
                array('key'=> Caricove_Courier_Earnings_Engine::META_STATUS, 'value'=>'clearing'),
                array(
                    'key'     => Caricove_Courier_Earnings_Engine::META_CLEARING_UNTIL,
                    'value'   => $now,
                    'compare' => '>',
                    'type'    => 'NUMERIC',
                ),
            ),
        ));

        $a24 = 0.0;
        $a72 = 0.0;

        foreach ($ids as $eid) {
            $until = intval(get_post_meta($eid, Caricove_Courier_Earnings_Engine::META_CLEARING_UNTIL, true));
            $amt   = floatval(get_post_meta($eid, Caricove_Courier_Earnings_Engine::META_AMOUNT_GYD, true));

            if ( $until > $now && $until <= ($now + 24 * HOUR_IN_SECONDS) ) {
                $a24 += $amt;
            }
            if ( $until > $now && $until <= ($now + 72 * HOUR_IN_SECONDS) ) {
                $a72 += $amt;
            }
        }

        return array('24h'=>$a24,'72h'=>$a72);
    }

    protected static function global_totals() {
        $kpi = array('available'=>0.0,'clearing'=>0.0,'held'=>0.0,'paid'=>0.0);

        $ids = get_posts(array(
            'post_type'      => Caricove_Courier_Earnings_Engine::CPT_EARNING,
            'post_status'    => 'any',
            'posts_per_page' => 2000,
            'fields'         => 'ids',
        ));

        foreach ($ids as $eid) {
            $st = (string)get_post_meta($eid, Caricove_Courier_Earnings_Engine::META_STATUS, true);
            $amt= floatval(get_post_meta($eid, Caricove_Courier_Earnings_Engine::META_AMOUNT_GYD, true));
            if ( isset($kpi[$st]) ) $kpi[$st] += $amt;
        }
        return $kpi;
    }

    protected static function count_forfeited_entries() {
        $q = new WP_Query(array(
            'post_type'      => Caricove_Courier_Earnings_Engine::CPT_EARNING,
            'post_status'    => 'any',
            'posts_per_page' => 1,
            'fields'         => 'ids',
            'meta_query'     => array(
                array('key'=> Caricove_Courier_Earnings_Engine::META_STATUS, 'value'=>'forfeited'),
            ),
        ));
        return intval($q->found_posts);
    }

    protected static function scheduled_payout_clock() {
        // Display-only schedule. Default: every Sunday 02:00 UTC.
        // If you want Guyana local, we can convert with site TZ later.
        $settings = get_option('_cc_payout_schedule', array());
        if ( ! is_array($settings) ) $settings = array();

        $dow  = isset($settings['dow']) ? intval($settings['dow']) : 0; // 0=Sunday
        $hour = isset($settings['hour'])? intval($settings['hour']) : 2;
        $min  = isset($settings['min']) ? intval($settings['min']) : 0;

        $label = 'Weekly — Sunday 02:00 UTC';

        $now = current_time('timestamp', true);
        $next = self::next_weekly_time($now, $dow, $hour, $min);

        return array(
            'label'     => $label,
            'next_ts'   => $next,
            'next_human'=> gmdate('Y-m-d H:i:s', $next).' UTC',
            'countdown' => self::countdown($next - $now),
        );
    }

    protected static function next_weekly_time($now, $dow, $hour, $min) {
        // Find next occurrence of DOW at HH:MM UTC
        $now_gm = $now;
        $cur_dow = intval(gmdate('w', $now_gm));
        $days_ahead = ($dow - $cur_dow + 7) % 7;

        $candidate = gmmktime($hour, $min, 0, intval(gmdate('n',$now_gm)), intval(gmdate('j',$now_gm)) + $days_ahead, intval(gmdate('Y',$now_gm)));

        if ( $candidate <= $now_gm ) {
            $candidate = $candidate + 7 * DAY_IN_SECONDS;
        }
        return $candidate;
    }

    protected static function money($n) {
        return 'GYD ' . number_format_i18n((float)$n, 2);
    }

    protected static function badge($st) {
        $st = strtolower((string)$st);
        $cls = 'ccEHQ-badge';
        if ($st==='available') $cls .= ' green';
        elseif ($st==='clearing') $cls .= ' yellow';
        elseif ($st==='held') $cls .= ' purple';
        elseif ($st==='paid') $cls .= ' blue';
        else $cls .= ' gray';
        return '<span class="'.esc_attr($cls).'">'.esc_html(strtoupper($st)).'</span>';
    }

    protected static function kpi($label, $value, $tone) {
        return '<div class="ccEHQ-kpi '.$tone.'"><div class="l">'.esc_html($label).'</div><div class="v">'.esc_html($value).'</div></div>';
    }

    protected static function countdown($sec) {
        $sec = intval($sec);
        if ( $sec <= 0 ) return 'now';

        $d = floor($sec / DAY_IN_SECONDS);
        $sec -= $d * DAY_IN_SECONDS;
        $h = floor($sec / HOUR_IN_SECONDS);
        $sec -= $h * HOUR_IN_SECONDS;
        $m = floor($sec / MINUTE_IN_SECONDS);

        if ( $d > 0 ) return $d.'d '.$h.'h '.$m.'m';
        if ( $h > 0 ) return $h.'h '.$m.'m';
        return $m.'m';
    }

    /* =========================
     * CSS (no red hover, no black text)
     * ======================= */

    protected static function css() {
        return '<style>
        .ccEHQ-tabs{display:flex;gap:10px;flex-wrap:wrap;margin:14px 0}
        .ccEHQ-tab{padding:10px 14px;border-radius:999px;border:1px solid rgba(120,180,255,.22);background:rgba(0,0,0,.18);text-decoration:none;color:#f5f7ff;font-weight:800}
        .ccEHQ-tab:hover{box-shadow:0 0 18px rgba(0,160,255,.35);transform:translateY(-1px)}
        .ccEHQ-tab.on{background:linear-gradient(135deg, rgba(50,140,255,.55), rgba(140,80,255,.20));border-color:rgba(180,220,255,.35)}
        .ccEHQ-card{
            max-width:1200px;margin:12px 0;padding:16px;border-radius:18px;color:#f5f7ff;
            background: radial-gradient(1200px 600px at 15% 0%, rgba(64,160,255,.18), rgba(0,0,0,0)),
                        radial-gradient(900px 500px at 85% 10%, rgba(140,80,255,.14), rgba(0,0,0,0)),
                        linear-gradient(180deg,#070B14,#04060C);
            border:1px solid rgba(120,180,255,.18);
            box-shadow:0 20px 60px rgba(0,0,0,.55);
        }
        .ccEHQ-head{display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap}
        .ccEHQ-title{font-size:16px;font-weight:900;letter-spacing:.08em;text-transform:uppercase;color:#7bd7ff}
        .ccEHQ-subtitle{font-weight:900;letter-spacing:.08em;text-transform:uppercase;color:#9ddcff;margin-bottom:8px}
        .ccEHQ-chip{display:inline-flex;align-items:center;gap:6px;padding:6px 10px;border-radius:999px;border:1px solid rgba(120,185,255,.35);background:rgba(0,0,0,.25);font-weight:900;font-size:11px;letter-spacing:.1em;text-transform:uppercase}
        .ccEHQ-chip.ok{border-color:rgba(0,255,170,.35)}
        .ccEHQ-chip.warn{border-color:rgba(255,210,85,.45)}
        .ccEHQ-grid2{display:grid;grid-template-columns:1fr 1fr;gap:12px;max-width:1200px}
        @media (max-width: 980px){.ccEHQ-grid2{grid-template-columns:1fr}}
        .ccEHQ-kpis{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px;margin-top:12px}
        @media (max-width: 980px){.ccEHQ-kpis{grid-template-columns:repeat(2,minmax(0,1fr))}}
        .ccEHQ-kpi{border-radius:16px;padding:10px 12px;border:1px solid rgba(255,255,255,.08);background:rgba(0,0,0,.20)}
        .ccEHQ-kpi .l{font-size:11px;letter-spacing:.12em;text-transform:uppercase;opacity:.86}
        .ccEHQ-kpi .v{margin-top:4px;font-size:18px;font-weight:900}
        .ccEHQ-kpi.green{border-color:rgba(0,255,170,.22)}
        .ccEHQ-kpi.yellow{border-color:rgba(255,210,85,.22)}
        .ccEHQ-kpi.purple{border-color:rgba(160,110,255,.22)}
        .ccEHQ-kpi.blue{border-color:rgba(80,170,255,.22)}
        .ccEHQ-kv{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:10px 12px;border-radius:14px;border:1px solid rgba(255,255,255,.07);background:rgba(0,0,0,.18);margin-top:8px}
        .ccEHQ-kv span{opacity:.82}
        .ccEHQ-mini{margin-top:10px;opacity:.82;font-size:12px}
        .ccEHQ-divider{height:1px;background:rgba(255,255,255,.08);margin:14px 0}
        .ccEHQ-form,.ccEHQ-holdForm{display:flex;gap:10px;flex-wrap:wrap;margin-top:12px}
        .ccEHQ-input{
            border-radius:999px;border:1px solid rgba(120,185,255,.45);
            background:rgba(3,15,38,.92);color:#f5f7ff;padding:10px 12px;min-width:280px;outline:none;
        }
        .ccEHQ-input:focus{box-shadow:0 0 0 4px rgba(0,150,255,.18)}
        .ccEHQ-select{
            border-radius:999px;border:1px solid rgba(120,185,255,.45);
            background:rgba(3,15,38,.92);color:#f5f7ff;padding:10px 12px;outline:none;
        }
        .ccEHQ-btn{
            border-radius:999px;padding:10px 14px;border:1px solid rgba(120,185,255,.35);
            background:linear-gradient(135deg,#23b1ff,#0067ff);color:#06101a;font-weight:900;cursor:pointer;text-decoration:none;display:inline-flex;align-items:center;justify-content:center;
        }
        .ccEHQ-btn:hover{box-shadow:0 0 18px rgba(0,160,255,.45);transform:translateY(-1px)}
        .ccEHQ-btnSmall{
            border-radius:999px;padding:7px 10px;border:1px solid rgba(120,185,255,.35);
            background:linear-gradient(135deg,#23b1ff,#0067ff);color:#06101a;font-weight:900;text-decoration:none;display:inline-flex;align-items:center;justify-content:center;
        }
        .ccEHQ-btnSmall.ghost{background:rgba(0,0,0,.20);color:#f5f7ff}
        .ccEHQ-btnSmall:hover{box-shadow:0 0 16px rgba(0,160,255,.35);transform:translateY(-1px)}
        .ccEHQ-tablewrap{margin-top:12px;overflow:auto;border-radius:14px;border:1px solid rgba(255,255,255,.08)}
        .ccEHQ-table{width:100%;border-collapse:collapse}
        .ccEHQ-table th,.ccEHQ-table td{padding:10px 12px;border-bottom:1px solid rgba(255,255,255,.07);white-space:nowrap;font-size:12px;color:#f5f7ff}
        .ccEHQ-table th{font-size:11px;letter-spacing:.1em;text-transform:uppercase;opacity:.86}
        .ccEHQ-badge{display:inline-flex;align-items:center;gap:6px;padding:4px 10px;border-radius:999px;border:1px solid rgba(255,255,255,.12);background:rgba(0,0,0,.22);font-weight:900;font-size:11px;letter-spacing:.08em}
        .ccEHQ-badge.green{border-color:rgba(0,255,170,.28)}
        .ccEHQ-badge.yellow{border-color:rgba(255,210,85,.32)}
        .ccEHQ-badge.purple{border-color:rgba(160,110,255,.30)}
        .ccEHQ-badge.blue{border-color:rgba(80,170,255,.30)}
        .ccEHQ-badge.gray{opacity:.85}
        .ccEHQ-note{max-width:1200px;margin-top:12px;padding:12px 14px;border-radius:16px;border:1px solid rgba(255,255,255,.10);background:rgba(255,255,255,.05);font-weight:900}
        .ccEHQ-note.bad{border-color:rgba(255,120,160,.25);box-shadow:0 0 22px rgba(255,120,160,.10)}
        .ccEHQ-col-id{width:110px}
        .ccEHQ-col-status{width:150px;text-align:center}
        .ccEHQ-col-money{width:140px;text-align:right}
        .ccEHQ-col-time{width:170px}
        .ccEHQ-col-note{min-width:230px;white-space:normal}
        .ccEHQ-col-actions{width:200px;text-align:center}
        .ccEHQ-col-actions .ccEHQ-btnSmall{margin:2px 4px}
        .ccEHQ-table .ccEHQ-col-status .ccEHQ-badge{justify-content:center}
        .ccEHQ-table td.ccEHQ-col-money,.ccEHQ-table th.ccEHQ-col-money{text-align:right}
        .ccEHQ-table td.ccEHQ-col-status,.ccEHQ-table th.ccEHQ-col-status{text-align:center}
        .ccEHQ-table td.ccEHQ-col-actions,.ccEHQ-table th.ccEHQ-col-actions{text-align:center}
        .ccEHQ-link{color:#9ddcff;text-decoration:none}
        .ccEHQ-link:hover{text-decoration:underline}
        .mono{font-family: ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,"Liberation Mono","Courier New",monospace}
        .muted{opacity:.78}
        </style>';
    }
}

Caricove_Courier_Earnings_Admin::boot();

}