<?php
/**
 * Courier Earnings — Engine (GYD-only)
 * - Ledger CPT: cc_courier_earning
 * - States: clearing | available | held | paid
 * - Held: admin can move money from clearing/available -> held, email courier, then release or forfeit
 */

if ( ! defined('ABSPATH') ) { exit; }

if ( ! class_exists('Caricove_Courier_Earnings_Engine') ) {

class Caricove_Courier_Earnings_Engine {

    const VERSION = '2.2.0';
    const CPT_EARNING = 'cc_courier_earning';

    const OPTION_SETTINGS = '_cc_earnings_settings_v2';
    const OPTION_MATRIX   = '_cc_earnings_matrix_v2';

    const META_SHIPMENT_ID     = '_cc_earning_shipment_id';
    const META_COURIER_ID      = '_cc_earning_courier_id';
    const META_STATUS          = '_cc_earning_status';          // clearing|available|held|paid|forfeited
    const META_AMOUNT_GYD      = '_cc_earning_amount_gyd';
    const META_GROSS_GYD       = '_cc_earning_gross_gyd';
    const META_FEE_GYD         = '_cc_earning_fee_gyd';
    const META_ROUTE_KEY       = '_cc_earning_route_key';
    const META_DISTANCE_KM     = '_cc_earning_distance_km';
    const META_COMPONENTS      = '_cc_earning_components';
    const META_CREATED_AT_TS   = '_cc_earning_created_at';
    const META_CLEARING_UNTIL  = '_cc_earning_clearing_until';

    // Held details
    const META_HELD_REASON     = '_cc_earning_held_reason';
    const META_HELD_NOTE       = '_cc_earning_held_note';
    const META_HELD_AT_TS      = '_cc_earning_held_at';
    const META_HELD_BY         = '_cc_earning_held_by';
    const META_HELD_RESOLUTION = '_cc_earning_held_resolution'; // released|forfeited
    const META_HELD_RESOLVED_AT= '_cc_earning_held_resolved_at';

    const META_PAID_AT_TS      = '_cc_earning_paid_at';

    const CURRENCY = 'GYD';

    public static function boot() {
        add_action('init', array(__CLASS__, 'register_cpt'), 5);

        // Create ledger when delivered (best path)
        add_action('cc_shipment_status_changed', array(__CLASS__, 'on_shipment_status_changed'), 10, 4);

        // Cron hook for clearing -> available (you can call it from external cron too)
        add_action('cc_earnings_daily_cron', array(__CLASS__, 'run_clearing_to_available'));
    }
    
    public static function list_statements($courier_id, $start_ymd, $end_ymd) {
    $courier_id = intval($courier_id);
    if ( ! $courier_id ) return array();

    $start_ts = strtotime($start_ymd . ' 00:00:00');
    $end_ts   = strtotime($end_ymd   . ' 23:59:59');
    if ( ! $start_ts || ! $end_ts ) return array();

    $entries = get_posts(array(
        'post_type'      => self::CPT_EARNING,
        'post_status'    => 'any',
        'posts_per_page' => 500,
        'orderby'        => 'date',
        'order'          => 'DESC',
        'fields'         => 'ids',
        'meta_query'     => array(
            array('key'=> self::META_COURIER_ID, 'value'=> $courier_id),
            array(
                'key'     => self::META_CREATED_AT_TS,
                'value'   => array($start_ts, $end_ts),
                'compare' => 'BETWEEN',
                'type'    => 'NUMERIC',
            ),
        ),
    ));

    $rows = array();
    foreach ( (array)$entries as $eid ) {
        $shipment_id = intval(get_post_meta($eid, self::META_SHIPMENT_ID, true));
        $status      = (string)get_post_meta($eid, self::META_STATUS, true);
        $net         = floatval(get_post_meta($eid, self::META_AMOUNT_GYD, true));
        $gross       = floatval(get_post_meta($eid, self::META_GROSS_GYD, true));
        $fee         = floatval(get_post_meta($eid, self::META_FEE_GYD, true));
        $route       = (string)get_post_meta($eid, self::META_ROUTE_KEY, true);
        $dist        = floatval(get_post_meta($eid, self::META_DISTANCE_KM, true));
        $created_ts  = intval(get_post_meta($eid, self::META_CREATED_AT_TS, true));
        $clears_ts   = intval(get_post_meta($eid, self::META_CLEARING_UNTIL, true));
        $note        = (string)get_post_meta($eid, self::META_HELD_NOTE, true);

        $rows[] = array(
            'earning_id'  => $eid,
            'date'        => $created_ts ? gmdate('Y-m-d', $created_ts) : '',
            'shipment_id' => $shipment_id,
            'route'       => $route,
            'distance_km' => $dist,
            'status'      => $status,
            'gross_gyd'   => $gross,
            'fee_gyd'     => $fee,
            'net_gyd'     => $net,
            'clears_on'   => $clears_ts ? gmdate('Y-m-d', $clears_ts) : '',
            'note'        => $note,
        );
    }

    return $rows;
}

    public static function register_cpt() {
        register_post_type(self::CPT_EARNING, array(
            'labels' => array(
                'name' => __('Courier Earnings', 'caricove-logistics'),
                'singular_name' => __('Courier Earning', 'caricove-logistics'),
            ),
            'public' => false,
            'show_ui' => false,
            'show_in_menu' => false,
            'supports' => array('title'),
            'rewrite' => false,
        ));
    }

    public static function get_settings() {
        $defaults = array(
            'base_fare_gyd'     => 300.0,
            'per_km_gyd'        => 80.0,
            'min_fare_gyd'      => 400.0,
            'courier_share'     => 1.00,
            'clearing_days'     => 5,

            // Instant fee (Guyana reality)
            'instant_fee_pct'   => 0.025, // 2.5%
            'instant_fee_flat'  => 150.0, // +150 GYD

            // Email toggles
            'email_on_hold'     => true,
            'email_from_name'   => 'Caricove Logistics',
            'email_from_addr'   => '', // optional; leave blank to use WP default
        );

        $saved = get_option(self::OPTION_SETTINGS, array());
        if ( ! is_array($saved) ) $saved = array();
        $s = array_merge($defaults, $saved);

        $s['courier_share']    = max(0.0, min(1.0, floatval($s['courier_share'])));
        $s['clearing_days']    = max(1, intval($s['clearing_days']));
        $s['instant_fee_pct']  = max(0.0, min(0.25, floatval($s['instant_fee_pct'])));
        $s['instant_fee_flat'] = max(0.0, floatval($s['instant_fee_flat']));
        $s['email_on_hold']    = (bool) $s['email_on_hold'];

        return $s;
    }

    public static function get_matrix() {
        $m = get_option(self::OPTION_MATRIX, array());
        return is_array($m) ? $m : array();
    }

    public static function make_route_key($origin_anchor, $dest_anchor) {
        $o = $origin_anchor ? (string)$origin_anchor : '';
        $d = $dest_anchor ? (string)$dest_anchor : '';
        return $o . ':' . $d;
    }

    public static function on_shipment_status_changed($shipment_id, $old_status, $new_status, $context) {
        $shipment_id = intval($shipment_id);
        if ( ! $shipment_id ) return;

        if ( (string)$new_status !== 'delivered' ) return;

        if ( ! class_exists('\Caricove\Logistics\Core\ShipmentManager') ) {
            error_log('[EARNINGS] ShipmentManager missing; cannot create ledger.');
            return;
        }

        $summary = \Caricove\Logistics\Core\ShipmentManager::get_shipment_summary($shipment_id);
        if ( empty($summary) || ! is_array($summary) ) return;

        $courier_id = intval($summary['courier_id'] ?? 0);
        if ( ! $courier_id ) return;

        if ( self::ledger_exists_for_shipment($shipment_id) ) return;

        $calc = self::compute_for_summary($summary);
        if ( ! $calc ) return;

        $settings = self::get_settings();
        $now = current_time('timestamp', true);
        $clearing_until = $now + ( intval($settings['clearing_days']) * DAY_IN_SECONDS );

        $earning_id = wp_insert_post(array(
            'post_type'   => self::CPT_EARNING,
            'post_status' => 'publish',
            'post_title'  => sprintf('Earning — Shipment #%d — Courier #%d', $shipment_id, $courier_id),
        ));

        if ( ! $earning_id || is_wp_error($earning_id) ) return;

        update_post_meta($earning_id, self::META_SHIPMENT_ID, $shipment_id);
        update_post_meta($earning_id, self::META_COURIER_ID,  $courier_id);
        update_post_meta($earning_id, self::META_STATUS,      'clearing');
        update_post_meta($earning_id, self::META_AMOUNT_GYD,  floatval($calc['courier_amount_gyd']));
        update_post_meta($earning_id, self::META_GROSS_GYD,   floatval($calc['gross_fare_gyd']));
        update_post_meta($earning_id, self::META_FEE_GYD,     0.0);
        update_post_meta($earning_id, self::META_ROUTE_KEY,   (string)$calc['route_key']);
        update_post_meta($earning_id, self::META_DISTANCE_KM, floatval($calc['distance_km']));
        update_post_meta($earning_id, self::META_COMPONENTS,  $calc['components']);
        update_post_meta($earning_id, self::META_CREATED_AT_TS, $now);
        update_post_meta($earning_id, self::META_CLEARING_UNTIL, $clearing_until);

        do_action('cc_earnings_ledger_created', $earning_id, $shipment_id, $courier_id, array('source'=>'delivered_hook'));
    }

    public static function ledger_exists_for_shipment($shipment_id) {
        $shipment_id = intval($shipment_id);
        if ( ! $shipment_id ) return false;

        $found = get_posts(array(
            'post_type'      => self::CPT_EARNING,
            'post_status'    => 'any',
            'posts_per_page' => 1,
            'fields'         => 'ids',
            'meta_query'     => array(
                array('key' => self::META_SHIPMENT_ID, 'value' => $shipment_id),
            ),
        ));
        return ! empty($found);
    }

    /**
     * Public compatibility method (your jobs bridge called this).
     */
  public static function compute_for_summary(array $summary) {
    $settings = self::get_settings();
    $matrix   = self::get_matrix();

    $origin = ! empty($summary['origin_anchor']) ? (string)$summary['origin_anchor'] : '';
    $dest   = ! empty($summary['destination_anchor']) ? (string)$summary['destination_anchor'] : '';
    $route_key = self::make_route_key($origin, $dest);

    $base  = floatval($settings['base_fare_gyd']);
    $per   = floatval($settings['per_km_gyd']);
    $min   = floatval($settings['min_fare_gyd']);
    $share = floatval($settings['courier_share']);

    if ( isset($matrix[$route_key]) && is_array($matrix[$route_key]) ) {
        $row = $matrix[$route_key];
        if ( isset($row['base_fare_gyd']) ) $base = floatval($row['base_fare_gyd']);
        if ( isset($row['per_km_gyd']) )    $per  = floatval($row['per_km_gyd']);
        if ( isset($row['min_fare_gyd']) )  $min  = floatval($row['min_fare_gyd']);
        if ( isset($row['courier_share']) ) $share = max(0.0, min(1.0, floatval($row['courier_share'])));
    }

    $shipment_id = 0;
    if ( ! empty($summary['shipment_id']) ) {
        $shipment_id = absint($summary['shipment_id']);
    } elseif ( ! empty($summary['id']) ) {
        $shipment_id = absint($summary['id']);
    }

    $planner_quote_total    = 0.0;
    $planner_distance_km    = 0.0;
    $planner_duration_sec   = 0;
    $planner_breakdown      = array();
    $planner_quote_detected = false;

    if ( $shipment_id > 0 ) {
        $planner_quote_total  = floatval(get_post_meta($shipment_id, '_cc_cp_quote_total_gyd', true));
        $planner_distance_km  = floatval(get_post_meta($shipment_id, '_cc_cp_quote_distance_km', true));
        $planner_duration_sec = absint(get_post_meta($shipment_id, '_cc_cp_quote_duration_seconds', true));

        $raw_breakdown = get_post_meta($shipment_id, '_cc_cp_quote_breakdown', true);
        if ( is_string($raw_breakdown) && $raw_breakdown !== '' ) {
            $decoded = json_decode($raw_breakdown, true);
            if ( is_array($decoded) ) {
                $planner_breakdown = $decoded;
            }
        } elseif ( is_array($raw_breakdown) ) {
            $planner_breakdown = $raw_breakdown;
        }

        if ( $planner_quote_total > 0 ) {
            $planner_quote_detected = true;
        } elseif ( class_exists('CC_CP_Pricing_Engine') && method_exists('CC_CP_Pricing_Engine', 'quote_for_shipment') ) {
            $quoted = CC_CP_Pricing_Engine::quote_for_shipment($shipment_id);
            if ( is_array($quoted) ) {
                if ( isset($quoted['total_shipping_fee']) ) {
                    $planner_quote_total = floatval($quoted['total_shipping_fee']);
                } elseif ( isset($quoted['quote_total_gyd']) ) {
                    $planner_quote_total = floatval($quoted['quote_total_gyd']);
                }

                if ( isset($quoted['distance_km']) ) {
                    $planner_distance_km = floatval($quoted['distance_km']);
                }

                if ( isset($quoted['duration_seconds']) ) {
                    $planner_duration_sec = absint($quoted['duration_seconds']);
                }

                $planner_breakdown = $quoted;

                if ( $planner_quote_total > 0 ) {
                    $planner_quote_detected = true;
                }
            }
        }
    }

    if ( $planner_quote_detected ) {
        $distance_km = $planner_distance_km > 0 ? $planner_distance_km : self::estimate_distance_km_from_summary($summary);

        $gross = max(0.0, $planner_quote_total);
        $gross = floatval(apply_filters('cc_earnings_gross_fare_gyd', $gross, $summary, $settings, $matrix));
        if ( ! is_finite($gross) || $gross <= 0 ) {
            $gross = max($planner_quote_total, 0.0);
        }

        $courier_amount = $gross * $share;
        if ( ! is_finite($courier_amount) || $courier_amount <= 0 ) {
            $courier_amount = $gross * $share;
        }

        $components = array(
            'source'               => 'pricing_planner',
            'planner_quote_gyd'    => $planner_quote_total,
            'planner_distance_km'  => $planner_distance_km,
            'planner_duration_sec' => $planner_duration_sec,
            'distance_km'          => $distance_km,
            'gross_fare_gyd'       => $gross,
            'courier_share'        => $share,
            'courier_amount_gyd'   => $courier_amount,
            'planner_breakdown'    => $planner_breakdown,
        );

        return array(
            'route_key'          => $route_key,
            'distance_km'        => $distance_km,
            'gross_fare_gyd'     => $gross,
            'courier_amount_gyd' => $courier_amount,
            'components'         => $components,
        );
    }

    $distance_km = self::estimate_distance_km_from_summary($summary);

    $min_billable_km = floatval(apply_filters('cc_earnings_min_billable_km', 1.0, $summary, $settings, $matrix));
    if ( $distance_km <= 0 && $min_billable_km > 0 ) $distance_km = $min_billable_km;

    $base_component     = $base;
    $distance_component = max(0.0, $distance_km) * $per;
    $raw_fare           = $base_component + $distance_component;

    $gross = max($raw_fare, $min);
    $gross = floatval(apply_filters('cc_earnings_gross_fare_gyd', $gross, $summary, $settings, $matrix));
    $gross = max($gross, $min);
    if ( ! is_finite($gross) || $gross <= 0 ) $gross = $min;

    $courier_amount = $gross * $share;
    if ( ! is_finite($courier_amount) || $courier_amount <= 0 ) $courier_amount = $gross * $share;

    $components = array(
        'source'              => 'earnings_matrix_fallback',
        'base_fare_gyd'       => $base_component,
        'per_km_gyd'          => $per,
        'distance_km'         => $distance_km,
        'distance_gyd'        => $distance_component,
        'min_fare_gyd'        => $min,
        'gross_fare_gyd'      => $gross,
        'courier_share'       => $share,
        'courier_amount_gyd'  => $courier_amount,
    );

    return array(
        'route_key'          => $route_key,
        'distance_km'        => $distance_km,
        'gross_fare_gyd'     => $gross,
        'courier_amount_gyd' => $courier_amount,
        'components'         => $components,
    );
}

    public static function estimate_distance_km_from_summary(array $summary) {
        $pickup  = ! empty($summary['pickup_coords']) ? (string)$summary['pickup_coords'] : '';
        $dropoff = ! empty($summary['dropoff_coords']) ? (string)$summary['dropoff_coords'] : '';
        if ( strpos($pickup, ',') === false || strpos($dropoff, ',') === false ) return 0.0;

        $p = array_map('floatval', array_map('trim', explode(',', $pickup, 2)));
        $d = array_map('floatval', array_map('trim', explode(',', $dropoff, 2)));
        if ( count($p) !== 2 || count($d) !== 2 ) return 0.0;

        $earth = 6371.0;
        $phi1 = deg2rad($p[0]); $phi2 = deg2rad($d[0]);
        $dphi = deg2rad($d[0] - $p[0]);
        $dlmb = deg2rad($d[1] - $p[1]);

        $a = sin($dphi/2) * sin($dphi/2) + cos($phi1) * cos($phi2) * sin($dlmb/2) * sin($dlmb/2);
        $c = 2 * atan2(sqrt($a), sqrt(1-$a));
        $dist = $earth * $c;

        if ( ! is_finite($dist) || $dist < 0 ) return 0.0;
        return (float)$dist;
    }

   public static function get_balances_for_courier($courier_id) {
        $courier_id = intval($courier_id);
        if ( ! $courier_id ) {
            return array('available'=>0,'clearing'=>0,'held'=>0,'paid'=>0);
        }

        /*
         * Self-heal truth on read:
         * if any clearing rows are already due, release them before totaling balances.
         * This prevents "next unlock in now" from lying while Available stays stale.
         */
        self::run_clearing_to_available(array(
            'courier_id' => $courier_id,
            'limit'      => 500,
            'reason'     => 'wallet_read',
        ));

        $available = 0.0;
        $clearing  = 0.0;
        $held      = 0.0;
        $paid      = 0.0;

        $entries = get_posts(array(
            'post_type'      => self::CPT_EARNING,
            'post_status'    => 'any',
            'posts_per_page' => -1,
            'fields'         => 'ids',
            'meta_query'     => array(
                array(
                    'key'   => self::META_COURIER_ID,
                    'value' => $courier_id,
                ),
            ),
        ));

        foreach ( $entries as $eid ) {
            $amt = floatval(get_post_meta($eid, self::META_AMOUNT_GYD, true));
            $st  = (string) get_post_meta($eid, self::META_STATUS, true);

            if ( $st === 'available' ) {
                $available += $amt;
            } elseif ( $st === 'clearing' ) {
                $clearing += $amt;
            } elseif ( $st === 'held' ) {
                $held += $amt;
            } elseif ( $st === 'paid' ) {
                $paid += $amt;
            }
        }

        return compact('available','clearing','held','paid');
    }

    public static function run_clearing_to_available($args = array()) {
        $defaults = array(
            'courier_id' => 0,
            'limit'      => 500,
            'reason'     => 'manual',
        );
        $args = wp_parse_args($args, $defaults);

        $courier_id = intval($args['courier_id']);
        $limit      = max(1, intval($args['limit']));
        $reason     = sanitize_key($args['reason']);
        $now        = current_time('timestamp', true);

        $meta_query = array(
            'relation' => 'AND',
            array(
                'key'   => self::META_STATUS,
                'value' => 'clearing',
            ),
            array(
                'key'     => self::META_CLEARING_UNTIL,
                'value'   => $now,
                'compare' => '<=',
                'type'    => 'NUMERIC',
            ),
        );

        if ( $courier_id > 0 ) {
            $meta_query[] = array(
                'key'   => self::META_COURIER_ID,
                'value' => $courier_id,
            );
        }

        $entries = get_posts(array(
            'post_type'      => self::CPT_EARNING,
            'post_status'    => 'any',
            'posts_per_page' => $limit,
            'fields'         => 'ids',
            'meta_query'     => $meta_query,
        ));

        $moved     = 0;
        $moved_ids = array();

        foreach ( $entries as $eid ) {
            $st = (string) get_post_meta($eid, self::META_STATUS, true);
            if ( $st !== 'clearing' ) {
                continue;
            }

            update_post_meta($eid, self::META_STATUS, 'available');
            $moved++;
            $moved_ids[] = intval($eid);

            do_action('cc_earning_became_available', intval($eid));
        }

        $result = array(
            'finished_at_gmt' => gmdate('Y-m-d H:i:s'),
            'ts'              => time(),
            'reason'          => $reason,
            'courier_id'      => $courier_id,
            'checked_limit'   => $limit,
            'moved'           => $moved,
            'moved_ids'       => $moved_ids,
        );

        update_option('_cc_earnings_last_clearing_sweep', $result, false);

        return $moved;
    }
    /* =========================================================
     * HELD WORKFLOW (ADMIN CONTROL) + EMAIL
     * ======================================================= */

    public static function hold_entry($earning_id, $reason='dispute', $note='', $admin_user_id=0) {
        $earning_id = intval($earning_id);
        if ( ! $earning_id ) return false;

        $st = (string)get_post_meta($earning_id, self::META_STATUS, true);
        if ( ! in_array($st, array('available','clearing'), true) ) {
            return false;
        }

        update_post_meta($earning_id, self::META_STATUS, 'held');
        update_post_meta($earning_id, self::META_HELD_REASON, sanitize_key($reason));
        update_post_meta($earning_id, self::META_HELD_NOTE, sanitize_text_field($note));
        update_post_meta($earning_id, self::META_HELD_AT_TS, current_time('timestamp', true));
        update_post_meta($earning_id, self::META_HELD_BY, intval($admin_user_id));

        // Email courier (if enabled)
        $settings = self::get_settings();
        if ( ! empty($settings['email_on_hold']) ) {
            self::email_courier_hold_notice($earning_id, $reason, $note);
        }

        do_action('cc_earnings_held', $earning_id, $reason, $note);
        return true;
    }

    public static function release_hold($earning_id, $admin_user_id=0, $note='') {
        $earning_id = intval($earning_id);
        if ( ! $earning_id ) return false;

        $st = (string)get_post_meta($earning_id, self::META_STATUS, true);
        if ( $st !== 'held' ) return false;

        $now = current_time('timestamp', true);

        update_post_meta($earning_id, self::META_STATUS, 'paid');
        update_post_meta($earning_id, self::META_PAID_AT_TS, $now);
        update_post_meta($earning_id, self::META_HELD_RESOLUTION, 'released');
        update_post_meta($earning_id, self::META_HELD_RESOLVED_AT, $now);

        if ( $note !== '' ) {
            update_post_meta($earning_id, self::META_HELD_NOTE, sanitize_text_field($note));
        }

        do_action('cc_earnings_hold_released', $earning_id, 'paid', $admin_user_id);
        return true;
    }

    public static function forfeit_hold($earning_id, $admin_user_id=0, $note='') {
        $earning_id = intval($earning_id);
        if ( ! $earning_id ) return false;

        $st = (string)get_post_meta($earning_id, self::META_STATUS, true);
        if ( $st !== 'held' ) return false;

        $now = current_time('timestamp', true);
        update_post_meta($earning_id, self::META_STATUS, 'forfeited');
        delete_post_meta($earning_id, self::META_PAID_AT_TS);
        update_post_meta($earning_id, self::META_HELD_RESOLUTION, 'forfeited');
        update_post_meta($earning_id, self::META_HELD_RESOLVED_AT, $now);

        if ( $note !== '' ) {
            update_post_meta($earning_id, self::META_HELD_NOTE, sanitize_text_field($note));
        }

        do_action('cc_earnings_hold_forfeited', $earning_id, $admin_user_id);
        return true;
    }

    protected static function email_courier_hold_notice($earning_id, $reason, $note) {
        $courier_id = intval(get_post_meta($earning_id, self::META_COURIER_ID, true));
        if ( ! $courier_id ) return;

        $u = get_user_by('id', $courier_id);
        if ( ! $u || empty($u->user_email) ) return;

        $shipment_id = intval(get_post_meta($earning_id, self::META_SHIPMENT_ID, true));
        $amount = floatval(get_post_meta($earning_id, self::META_AMOUNT_GYD, true));

        $settings = self::get_settings();

        $from_name = (string)($settings['email_from_name'] ?? 'Caricove Logistics');
        $from_addr = (string)($settings['email_from_addr'] ?? '');
        $headers = array('Content-Type: text/plain; charset=UTF-8');

        if ( $from_addr ) {
            $headers[] = 'From: ' . $from_name . ' <' . $from_addr . '>';
        }

        $subject = 'Caricove: Earnings Hold Notice (Shipment #' . $shipment_id . ')';

        $body = "Hi " . ($u->display_name ?: $u->user_login) . ",\n\n"
            . "A portion of your earnings has been placed on HOLD for review.\n\n"
            . "Shipment: #" . $shipment_id . "\n"
            . "Amount: GYD " . number_format_i18n($amount, 2) . "\n"
            . "Reason: " . $reason . "\n"
            . ($note ? ("Note: " . $note . "\n") : "")
            . "\nWhat happens next:\n"
            . "- If the review confirms the delivery is valid, the hold will be released and funds return to your balance.\n"
            . "- If the review fails, the held funds may be forfeited.\n\n"
            . "If you have evidence (messages, screenshots, call logs), reply to support and include the shipment number.\n\n"
            . "— Caricove Logistics\n";

        @wp_mail($u->user_email, $subject, $body, $headers);
    }

    public static function compute_instant_fee_gyd($amount_gyd) {
        $s = self::get_settings();
        $pct = floatval($s['instant_fee_pct']);
        $flat= floatval($s['instant_fee_flat']);
        $fee = ($amount_gyd * $pct) + $flat;
        return max(0.0, round($fee, 2));
    }
}

Caricove_Courier_Earnings_Engine::boot();

}