<?php
/**
 * Courier Earnings — Payout Requests (Admin-gated)
 * - Instant payout: REQUESTED -> admin must Approve/Reject/Hold
 * - Scheduled payout: REQUESTED -> admin must Approve/Reject/Hold
 * - Partial approvals/holds SPLIT available ledger rows instead of consuming whole rows
 */

if ( ! defined('ABSPATH') ) { exit; }

if ( ! class_exists('Caricove_Courier_Earnings_Payouts') ) {

class Caricove_Courier_Earnings_Payouts {

    const OPTION_REQUESTS = '_cc_payout_requests_v2';
    const META_PAYOUT_REQUEST_ID = '_cc_payout_request_id';

    public static function boot() {
        add_action('wp_ajax_caricove_courier_request_payout', array(__CLASS__, 'ajax_request_payout'));
        add_action('admin_post_cc_payout_approve', array(__CLASS__, 'admin_approve'));
        add_action('admin_post_cc_payout_hold', array(__CLASS__, 'admin_hold'));
        add_action('admin_post_cc_payout_reject', array(__CLASS__, 'admin_reject'));
    }

    public static function get_requests() {
        $req = get_option(self::OPTION_REQUESTS, array());
        return is_array($req) ? $req : array();
    }

    public static function save_requests(array $req) {
        update_option(self::OPTION_REQUESTS, $req, false);
    }

    public static function ajax_request_payout() {
        if ( ! is_user_logged_in() ) {
            wp_send_json_error(array('message' => 'Not logged in'), 401);
        }

        $nonce = sanitize_text_field($_POST['nonce'] ?? '');
        if ( ! wp_verify_nonce($nonce, 'caricove_courier_payout') ) {
            wp_send_json_error(array('message' => 'Bad nonce'), 403);
        }

        if ( ! class_exists('Caricove_Courier_Earnings_Engine') ) {
            wp_send_json_error(array('message' => 'Earnings engine missing'), 500);
        }

        $courier_id = get_current_user_id();

        $payout_method = function_exists('ccv_ccb_get_payout_method_for_courier')
            ? ccv_ccb_get_payout_method_for_courier($courier_id)
            : array();

        if (empty($payout_method['configured'])) {
            wp_send_json_error(array('message' => 'Add a payout method before requesting cashout.'), 400);
        }

        $payout_method_snapshot = function_exists('ccv_ccb_payout_method_request_snapshot')
            ? ccv_ccb_payout_method_request_snapshot($courier_id)
            : array(
                'type'              => (string) ($payout_method['type'] ?? ''),
                'type_label'        => (string) ($payout_method['type_label'] ?? ''),
                'destination_label' => (string) ($payout_method['destination_label'] ?? ''),
                'configured'        => ! empty($payout_method['configured']),
                'processor_status'  => (string) ($payout_method['processor_status'] ?? 'standby'),
            );

       $amount = round(floatval($_POST['amount'] ?? 0), 2);
$requested_type = sanitize_key($_POST['type'] ?? 'scheduled');
$type   = 'scheduled'; // Instant payouts are retired for now; all courier requests enter the standard queue.
$min_payout = 1000.00;

if ( $amount < $min_payout ) {
    wp_send_json_error(array('message' => 'Minimum payout amount is GYD 1,000.00'), 400);
}

        $b         = Caricove_Courier_Earnings_Engine::get_balances_for_courier($courier_id);
        $available = round(floatval($b['available']), 2);

        if ( $amount > $available ) {
            wp_send_json_error(array('message' => 'Amount exceeds available balance'), 400);
        }

        $fee = 0.0;
        $net = $amount;

        $req = self::get_requests();
        $id  = 'ccp_' . wp_generate_password(12, false, false);

        $req[] = array(
            'id'         => $id,
            'ts'         => time(),
            'courier_id' => $courier_id,
            'type'       => $type,
            'amount_gyd' => $amount,
            'fee_gyd'    => $fee,
            'net_gyd'    => $net,
            'status'     => 'requested', // requested|approved|held|rejected|paid
            'payout_method'            => $payout_method_snapshot,
            'payout_method_type'       => (string) ($payout_method_snapshot['type'] ?? ''),
            'payout_destination_label' => (string) ($payout_method_snapshot['destination_label'] ?? ''),
            'processor_status'         => (string) ($payout_method_snapshot['processor_status'] ?? 'standby'),
        );

        self::save_requests($req);

        wp_send_json_success(array(
            'message'  => 'Payout request submitted. Awaiting admin approval.',
            'currency' => 'GYD',
        ));
    }

    public static function admin_approve() {
        if ( ! current_user_can('manage_options') ) {
            wp_die('Unauthorized');
        }

        check_admin_referer('cc_payout_admin');

        $id = sanitize_text_field($_GET['id'] ?? '');
        if ( $id === '' ) {
            wp_die('Missing id');
        }

        $result = self::process_request($id, 'approve');
        $tab    = self::admin_tab_for_request($id, 'payout_requests');
        $flag   = $result ? 'approved=1' : 'insufficient=1';

        wp_safe_redirect(admin_url('admin.php?page=caricove-bank&tab=' . $tab . '&' . $flag));
        exit;
    }

    public static function admin_hold() {
        if ( ! current_user_can('manage_options') ) {
            wp_die('Unauthorized');
        }

        check_admin_referer('cc_payout_admin');

        $id = sanitize_text_field($_GET['id'] ?? '');
        if ( $id === '' ) {
            wp_die('Missing id');
        }

        $result = self::process_request($id, 'hold');
        $tab    = self::admin_tab_for_request($id, 'payout_requests');
        $flag   = $result ? 'held=1' : 'insufficient=1';

        wp_safe_redirect(admin_url('admin.php?page=caricove-bank&tab=' . $tab . '&' . $flag));
        exit;
    }

    public static function admin_reject() {
        if ( ! current_user_can('manage_options') ) {
            wp_die('Unauthorized');
        }

        check_admin_referer('cc_payout_admin');

        $id = sanitize_text_field($_GET['id'] ?? '');
        if ( $id === '' ) {
            wp_die('Missing id');
        }

        $req = self::get_requests();

        foreach ( $req as &$r ) {
            if ( ($r['id'] ?? '') === $id && ($r['status'] ?? '') === 'requested' ) {
                $r['status']      = 'rejected';
                $r['rejected_at'] = time();
                break;
            }
        }
        unset($r);

        self::save_requests($req);

        wp_safe_redirect(admin_url('admin.php?page=caricove-bank&tab=' . self::admin_tab_for_request($id, 'payout_requests') . '&rejected=1'));
        exit;
    }

    public static function process_request($id, $mode = 'approve') {
        $id   = sanitize_text_field((string) $id);
        $mode = ($mode === 'hold') ? 'hold' : 'approve';

        if ( $id === '' || ! class_exists('Caricove_Courier_Earnings_Engine') ) {
            return false;
        }

        $req     = self::get_requests();
        $changed = false;

        foreach ( $req as &$r ) {
            if ( ($r['id'] ?? '') !== $id || ($r['status'] ?? '') !== 'requested' ) {
                continue;
            }

            $courier_id = intval($r['courier_id'] ?? 0);
            $amount     = round(floatval($r['amount_gyd'] ?? 0), 2);

            if ( ! $courier_id || $amount <= 0 ) {
                break;
            }

            $to_status  = ($mode === 'hold') ? 'held' : 'paid';
            $allocation = self::move_available_entries($courier_id, $amount, $to_status, $id);

            if ( ! $allocation ) {
                return false;
            }

            $r['status']               = ($mode === 'hold') ? 'held' : 'approved';
            $r['processed_at']         = time();
            $r['processed_mode']       = $mode;
            $r['allocation_count']     = count($allocation);
            $r['allocated_earning_ids']= wp_list_pluck($allocation, 'eid');
            $r['allocated_amounts']    = wp_list_pluck($allocation, 'amount');

            if ( $mode === 'hold' ) {
                $r['held_at'] = time();
            } else {
                $r['approved_at'] = time();
            }

            $changed = true;
            break;
        }
        unset($r);

        if ( $changed ) {
            self::save_requests($req);
        }

        return $changed;
    }

    protected static function consume_available_to_paid($courier_id, $amount_gyd, $request_id = '') {
        return self::move_available_entries($courier_id, $amount_gyd, 'paid', $request_id);
    }

    protected static function move_available_entries($courier_id, $amount_gyd, $to_status = 'paid', $request_id = '') {
        $courier_id = intval($courier_id);
        $amount_gyd = round(floatval($amount_gyd), 2);

        if ( $courier_id <= 0 || $amount_gyd <= 0 ) {
            return false;
        }

        if ( ! in_array($to_status, array('paid', 'held'), true) ) {
            $to_status = 'paid';
        }

        $entries = get_posts(array(
            'post_type'      => Caricove_Courier_Earnings_Engine::CPT_EARNING,
            'post_status'    => 'any',
            'posts_per_page' => 500,
            'orderby'        => 'date',
            'order'          => 'ASC',
            'fields'         => 'ids',
            'meta_query'     => array(
                array(
                    'key'   => Caricove_Courier_Earnings_Engine::META_COURIER_ID,
                    'value' => $courier_id,
                ),
                array(
                    'key'   => Caricove_Courier_Earnings_Engine::META_STATUS,
                    'value' => 'available',
                ),
            ),
        ));

        $remaining   = $amount_gyd;
        $allocations = array();

        foreach ( (array) $entries as $eid ) {
            if ( $remaining <= 0 ) {
                break;
            }

            $eid        = intval($eid);
            $row_amount = round(floatval(get_post_meta($eid, Caricove_Courier_Earnings_Engine::META_AMOUNT_GYD, true)), 2);

            if ( $row_amount <= 0 ) {
                continue;
            }

            if ( $row_amount <= $remaining ) {
                // Full consume of this row.
                if ( $to_status === 'held' ) {
                    $ok = Caricove_Courier_Earnings_Engine::hold_entry(
                        $eid,
                        'payout_request_hold',
                        'Held from payout request ' . $request_id,
                        get_current_user_id()
                    );
                    if ( ! $ok ) {
                        return false;
                    }
                } else {
                    update_post_meta($eid, Caricove_Courier_Earnings_Engine::META_STATUS, 'paid');
                    update_post_meta($eid, Caricove_Courier_Earnings_Engine::META_PAID_AT_TS, current_time('timestamp', true));
                }

                if ( $request_id !== '' ) {
                    update_post_meta($eid, self::META_PAYOUT_REQUEST_ID, sanitize_text_field($request_id));
                }

                $allocations[] = array(
                    'eid'    => $eid,
                    'amount' => $row_amount,
                );

                $remaining = round($remaining - $row_amount, 2);
                continue;
            }

            // Partial consume: split the row.
            $move_amount     = $remaining;
            $leftover_amount = round($row_amount - $move_amount, 2);

            if ( $leftover_amount < 0 ) {
                $leftover_amount = 0.0;
            }

            // Reduce original available row to the leftover.
            update_post_meta($eid, Caricove_Courier_Earnings_Engine::META_AMOUNT_GYD, $leftover_amount);

            // Create a clone row for the moved portion.
            $new_id = wp_insert_post(array(
                'post_type'   => Caricove_Courier_Earnings_Engine::CPT_EARNING,
                'post_status' => 'publish',
                'post_title'  => get_the_title($eid) . ' — ' . (($to_status === 'held') ? 'Held Split' : 'Paid Split'),
            ));

            if ( ! $new_id || is_wp_error($new_id) ) {
                return false;
            }

            self::clone_earning_meta($eid, $new_id);

            update_post_meta($new_id, Caricove_Courier_Earnings_Engine::META_AMOUNT_GYD, $move_amount);

            if ( $to_status === 'held' ) {
                // Start as available, then use engine hold flow so held metadata is populated cleanly.
                update_post_meta($new_id, Caricove_Courier_Earnings_Engine::META_STATUS, 'available');

                $ok = Caricove_Courier_Earnings_Engine::hold_entry(
                    $new_id,
                    'payout_request_hold',
                    'Held from payout request ' . $request_id,
                    get_current_user_id()
                );

                if ( ! $ok ) {
                    return false;
                }
            } else {
                update_post_meta($new_id, Caricove_Courier_Earnings_Engine::META_STATUS, 'paid');
                update_post_meta($new_id, Caricove_Courier_Earnings_Engine::META_PAID_AT_TS, current_time('timestamp', true));
            }

            if ( $request_id !== '' ) {
                update_post_meta($new_id, self::META_PAYOUT_REQUEST_ID, sanitize_text_field($request_id));
            }

            $allocations[] = array(
                'eid'    => intval($new_id),
                'amount' => $move_amount,
            );

            $remaining = 0.0;
            break;
        }

        if ( $remaining > 0 ) {
            return false;
        }

        return $allocations;
    }

    protected static function clone_earning_meta($from_id, $to_id) {
        $from_id = intval($from_id);
        $to_id   = intval($to_id);

        if ( ! $from_id || ! $to_id ) {
            return;
        }

        $all_meta = get_post_meta($from_id);

        foreach ( $all_meta as $meta_key => $values ) {
            foreach ( (array) $values as $value ) {
                add_post_meta($to_id, $meta_key, maybe_unserialize($value));
            }
        }
    }

    protected static function admin_tab_for_request($id, $fallback = 'payout_requests') {
        return 'payout_requests';
    }
}

Caricove_Courier_Earnings_Payouts::boot();

}