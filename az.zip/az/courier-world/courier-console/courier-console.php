<?php
/**
 * Plugin Name: Caricove Logistics — Courier Console
 * Description: Folderized courier console shell for the Caricove logistics universe.
 * Author: Caricove
 * Version: 3.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'CARICOVE_COURIER_CONSOLE_FILE', __FILE__ );
define( 'CARICOVE_COURIER_CONSOLE_DIR', plugin_dir_path( __FILE__ ) );
define( 'CARICOVE_COURIER_CONSOLE_URL', plugin_dir_url( __FILE__ ) );

require_once CARICOVE_COURIER_CONSOLE_DIR . 'includes/helpers-courier-console.php';
require_once CARICOVE_COURIER_CONSOLE_DIR . 'includes/class-courier-console-assets.php';
require_once CARICOVE_COURIER_CONSOLE_DIR . 'includes/class-courier-console-auth.php';
require_once CARICOVE_COURIER_CONSOLE_DIR . 'includes/class-courier-console-balances.php';
require_once CARICOVE_COURIER_CONSOLE_DIR . 'includes/class-courier-console-card-builder.php';
require_once CARICOVE_COURIER_CONSOLE_DIR . 'includes/class-courier-console-data.php';
require_once CARICOVE_COURIER_CONSOLE_DIR . 'includes/class-courier-console-jobs.php';
require_once CARICOVE_COURIER_CONSOLE_DIR . 'includes/class-courier-console-settings.php';
require_once CARICOVE_COURIER_CONSOLE_DIR . 'includes/class-courier-console-shortcode.php';
require_once CARICOVE_COURIER_CONSOLE_DIR . 'includes/class-courier-console-module.php';

Caricove_Courier_Console_Module::boot();
