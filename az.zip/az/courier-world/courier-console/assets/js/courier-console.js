
(function(window, document){
  'use strict';

  function qs(sel, ctx){ return (ctx || document).querySelector(sel); }
  function qsa(sel, ctx){ return Array.prototype.slice.call((ctx || document).querySelectorAll(sel)); }
  function isObject(value){ return !!value && typeof value === 'object' && !Array.isArray(value); }
  function stringVal(value){ return value == null ? '' : String(value); }
  function numberVal(value){ var num = Number(value || 0); return isFinite(num) ? num : 0; }
  function intVal(value){ var num = parseInt(value || 0, 10); return isFinite(num) ? num : 0; }
  function nowSec(){ return Math.floor(Date.now() / 1000); }
  function bridge(){ return window.CaricoveCourierBridge || null; }

  function escapeHtml(value){
    return stringVal(value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function money(value){
    return numberVal(value).toFixed(2);
  }

  function buildAttr(name, value){
    return ' ' + name + '="' + escapeHtml(value) + '"';
  }

  var bucketSignatureCache = { incoming: '', assigned: '', queued: '' };
  var currentState = {
    jobs: { incoming: [], assigned: [], queued: [] },
    balances: { available: 0, clearing: 0, held: 0, currency: 'GYD' },
    settings: { availability: 'online', max_jobs: 3, range: 'local_area', radius_km: 7 },
    payout_method: { configured: false, type: '', destination_label: 'No payout method saved' },
    mission: {},
    focus_job_id: ''
  };
  var currentListMode = 'assigned';
  var manualListMode = '';
  var offerState = {
    jobId: '',
    expiresAt: 0,
    countdownTimer: null,
    active: false,
    locked: false
  };
  var pendingCodeJob = null;
  var settingsInflight = false;
  var queuedSettingsPayload = null;
  var splashDone = false;

  function meta(){ return qs('#ccv-courier-js-meta'); }
  function ajaxUrl(){ return meta() ? stringVal(meta().getAttribute('data-ajax-url')) : ''; }
  function payoutNonce(){ return meta() ? stringVal(meta().getAttribute('data-payout-nonce')) : ''; }

  function bucketJobs(bucket){
    return (currentState.jobs && Array.isArray(currentState.jobs[bucket])) ? currentState.jobs[bucket] : [];
  }

  function findJob(jobId){
    jobId = stringVal(jobId);
    if (!jobId) return null;
    var all = [].concat(bucketJobs('assigned')).concat(bucketJobs('incoming')).concat(bucketJobs('queued'));
    for (var i = 0; i < all.length; i++) {
      if (stringVal(all[i] && all[i].job_id) === jobId) return all[i];
    }
    return null;
  }

  function bucketForJob(jobId){
    jobId = stringVal(jobId);
    var buckets = ['assigned', 'incoming', 'queued'];
    for (var i = 0; i < buckets.length; i++) {
      var jobs = bucketJobs(buckets[i]);
      for (var j = 0; j < jobs.length; j++) {
        if (stringVal(jobs[j] && jobs[j].job_id) === jobId) return buckets[i];
      }
    }
    return '';
  }

  function emptyText(bucket){
    if (bucket === 'incoming') return 'No incoming offers right now. New dispatches will appear here instantly.';
    if (bucket === 'assigned') return 'No active assigned trip right now. Your live trip appears here when you accept one.';
    return 'No queued jobs right now. Accepted follow-up jobs wait here until your active trip clears.';
  }

  function jobSignature(job){
    job = isObject(job) ? job : {};
    return [
      stringVal(job.job_id),
      stringVal(job.status),
      stringVal(job.status_label),
      stringVal(job.queue_bucket),
      stringVal(job.next_state),
      stringVal(job.next_state_label),
      stringVal(job.offer_is_live ? '1' : '0'),
      stringVal(job.offer_expires_at || 0),
      stringVal(job.deadline_ts || 0),
      stringVal(job.pay_label || ''),
      stringVal(job.distance_label || ''),
      stringVal(job.deadline_label || ''),
      stringVal(job.courier_lat || ''),
      stringVal(job.courier_lng || ''),
      stringVal(job.phase || '')
    ].join('|');
  }

  function bucketSignature(jobs){
    jobs = Array.isArray(jobs) ? jobs : [];
    return jobs.map(jobSignature).join('||');
  }

  function computeRouteSummary(job){
    var fromArea = stringVal(job.pickup_city || job.pickup_text);
    var toArea = stringVal(job.dropoff_city || job.dropoff_text);
    if (fromArea && toArea) return fromArea + ' → ' + toArea;
    return fromArea || toArea || '';
  }

  function computeOfferSecondsLeft(job){
    var expires = intVal(job.offer_expires_at || 0);
    if (!expires) return intVal(job.offer_seconds_left || 0);
    return Math.max(0, expires - nowSec());
  }

  function computeTimeChip(job){
    if (job.offer_is_live) {
      var secs = computeOfferSecondsLeft(job);
      if (secs > 0) return 'Respond in ' + secs + 's';
    }
    return stringVal(job.deadline_label || job.eta_label || '');
  }

  function buildJobCardHtml(job, bucket){
    job = isObject(job) ? job : {};
    bucket = stringVal(bucket || job.queue_bucket || 'queued');
    var timeChip = computeTimeChip(job);
    var routeSummary = computeRouteSummary(job);

    var html = '<article class="ccv-job-card ccv-job-card--active"';
    html += buildAttr('data-job-id', stringVal(job.job_id));
    html += buildAttr('data-job-label', stringVal(job.label));
    html += buildAttr('data-job-status', stringVal(job.status));
    html += buildAttr('data-job-status-label', stringVal(job.status_label));
    html += buildAttr('data-job-pay', stringVal(job.pay_label));
    html += buildAttr('data-job-currency', stringVal(job.currency || 'GYD'));
    html += buildAttr('data-pickup-title', stringVal(job.pickup_title || 'Pickup'));
    html += buildAttr('data-pickup-text', stringVal(job.pickup_text));
    html += buildAttr('data-pickup-city', stringVal(job.pickup_city));
    html += buildAttr('data-pickup-name', stringVal(job.pickup_name));
    html += buildAttr('data-pickup-phone', stringVal(job.pickup_phone));
    html += buildAttr('data-dropoff-title', stringVal(job.dropoff_title || 'Dropoff'));
    html += buildAttr('data-dropoff-text', stringVal(job.dropoff_text));
    html += buildAttr('data-dropoff-city', stringVal(job.dropoff_city));
    html += buildAttr('data-dropoff-name', stringVal(job.dropoff_name));
    html += buildAttr('data-dropoff-phone', stringVal(job.dropoff_phone));
    html += buildAttr('data-dropoff-instructions', stringVal(job.dropoff_instructions));
    html += buildAttr('data-delivery-instructions', stringVal(job.delivery_instructions || job.dropoff_instructions));
    html += buildAttr('data-eta-label', stringVal(job.eta_label));
    html += buildAttr('data-distance-label', stringVal(job.distance_label));
    html += buildAttr('data-deadline-label', stringVal(job.deadline_label));
    html += buildAttr('data-deadline-ts', intVal(job.deadline_ts || 0));
    html += buildAttr('data-map-url', stringVal(job.map_url));
    html += buildAttr('data-nav-url', stringVal(job.nav_url));
    html += buildAttr('data-next-state', stringVal(job.next_state));
    html += buildAttr('data-next-state-label', stringVal(job.next_state_label));
    html += buildAttr('data-requires-code', job.requires_code ? '1' : '0');
    html += buildAttr('data-phase', stringVal(job.phase || 'to_pickup'));
    html += buildAttr('data-pickup-lat', stringVal(job.pickup_lat));
    html += buildAttr('data-pickup-lng', stringVal(job.pickup_lng));
    html += buildAttr('data-dropoff-lat', stringVal(job.dropoff_lat));
    html += buildAttr('data-dropoff-lng', stringVal(job.dropoff_lng));
    html += buildAttr('data-mission-id', stringVal(job.mission_id));
    html += buildAttr('data-mission-seq', intVal(job.mission_seq || 0));
    html += buildAttr('data-queue-bucket', bucket);
    html += buildAttr('data-offer-created-at', intVal(job.offer_created_at || 0));
    html += buildAttr('data-offer-expires-at', intVal(job.offer_expires_at || 0));
    html += buildAttr('data-offer-response-window', intVal(job.offer_response_window || 0));
    html += buildAttr('data-offer-seconds-left', computeOfferSecondsLeft(job));
    html += buildAttr('data-offer-live', job.offer_is_live ? '1' : '0');
    html += buildAttr('data-courier-lat', stringVal(job.courier_lat));
    html += buildAttr('data-courier-lng', stringVal(job.courier_lng));
    html += buildAttr('data-courier-vehicle-type', stringVal(job.courier_vehicle_type));
    html += buildAttr('data-distance-band', stringVal(job.distance_band));
    html += buildAttr('data-quote-total-gyd', numberVal(job.quote_total_gyd || 0));
    html += '>';
    html += '<div class="ccv-job-card-row ccv-job-card-row--thin-top">';
    html += '<div class="ccv-job-card-label">' + escapeHtml(job.label || '') + '</div>';
    if (job.status_label) {
      html += '<div class="ccv-job-card-state">' + escapeHtml(job.status_label) + '</div>';
    }
    html += '</div>';
    html += '<div class="ccv-job-card-row ccv-job-card-row--thin-middle">';
    if (routeSummary) {
      html += '<div class="ccv-job-card-route">' + escapeHtml(routeSummary) + '</div>';
    }
    html += '</div>';
    html += '<div class="ccv-job-card-row ccv-job-card-row--thin-bottom">';
    html += '<div class="ccv-job-card-meta">';
    if (timeChip) {
      html += '<span class="ccv-job-pill ccv-job-pill--time">' + escapeHtml(timeChip) + '</span>';
    }
    if (job.distance_label) {
      html += '<span class="ccv-job-pill ccv-job-pill--distance">' + escapeHtml(job.distance_label) + '</span>';
    }
    html += '</div>';
    html += '<div class="ccv-job-card-pay"><span class="ccv-job-pay-currency">' + escapeHtml(job.currency || 'GYD') + '</span><span class="ccv-job-pay-amount">' + escapeHtml(job.pay_label || '') + '</span></div>';
    html += '</div>';
    html += '</article>';
    return html;
  }

  function renderBucket(bucket, jobs){
    var list = qs('#ccv-job-list-' + bucket);
    if (!list) return;
    var signature = bucketSignature(jobs);
    if (bucketSignatureCache[bucket] === signature) return;
    if (!jobs || !jobs.length) {
      list.innerHTML = '<div class="ccv-job-empty">' + escapeHtml(emptyText(bucket)) + '</div>';
      bucketSignatureCache[bucket] = signature;
      return;
    }
    list.innerHTML = jobs.map(function(job){ return buildJobCardHtml(job, bucket); }).join('');
    bucketSignatureCache[bucket] = signature;
  }

  function renderBalances(balances){
    balances = isObject(balances) ? balances : {};
    var available = money(balances.available || 0);
    var clearing = money(balances.clearing || 0);
    var held = money(balances.held || 0);

    [[qs('#ccv-balance-available'), available], [qs('#ccv-balance-clearing'), clearing], [qs('#ccv-balance-held'), held], [qs('[data-bind="available"]'), available], [qs('[data-bind="clearing"]'), clearing], [qs('[data-bind="held"]'), held], [qs('#ccv-payout-available-display'), available]].forEach(function(pair){
      if (pair[0]) pair[0].textContent = pair[1];
    });

    qsa('.ccv-balance-currency').forEach(function(el){
      el.textContent = stringVal(balances.currency || 'GYD');
    });
  }

  function rangeLabel(range){
    var labels = {
      very_close: 'Very close',
      local_area: 'Local area',
      across_georgetown: 'Across Georgetown',
      extended_routes: 'Extended routes'
    };
    return labels[stringVal(range)] || 'Preference';
  }

  function workloadLabel(maxJobs){
    maxJobs = intVal(maxJobs || 3);
    if (maxJobs === 1) return 'Focused';
    if (maxJobs === 5) return 'High Capacity';
    return 'Balanced';
  }

  function syncSettingsUi(settings){
    settings = isObject(settings) ? settings : {};
    var availability = stringVal(settings.availability || 'online');
    if (availability !== 'offline') availability = 'online';
    var maxJobs = intVal(settings.max_jobs || 3);
    if ([1,3,5].indexOf(maxJobs) === -1) maxJobs = 3;
    var range = stringVal(settings.range || 'local_area');

    qsa('[data-setting="availability"]').forEach(function(el){
      el.classList.toggle('is-active', stringVal(el.getAttribute('data-value')) === availability);
      if (el.classList.contains('ccv-set-chip')) {
        el.classList.toggle('is-online', availability === 'online' && stringVal(el.getAttribute('data-value')) === 'online');
        el.classList.toggle('is-offline', availability === 'offline' && stringVal(el.getAttribute('data-value')) === 'offline');
      }
    });

    qsa('[data-setting="max_jobs"]').forEach(function(el){
      el.classList.toggle('is-active', intVal(el.getAttribute('data-value')) === maxJobs);
    });

    qsa('[data-setting="range"]').forEach(function(el){
      el.classList.toggle('is-active', stringVal(el.getAttribute('data-value')) === range);
    });

    var availabilityBadge = qs('[data-bind="availability-badge"]');
    if (availabilityBadge) availabilityBadge.textContent = availability === 'offline' ? 'OFFLINE' : 'ONLINE';
    var maxJobsLabel = qs('[data-bind="maxjobs-label"]');
    if (maxJobsLabel) maxJobsLabel.textContent = workloadLabel(maxJobs);
    var rangeLabelEl = qs('[data-bind="range-label"]');
    if (rangeLabelEl) rangeLabelEl.textContent = rangeLabel(range);
  }

  function toast(message, isError){
    var el = qs('#ccv-settings-toast');
    if (!el) return;
    el.textContent = stringVal(message || (isError ? 'Unable to save settings.' : 'Settings updated — dispatcher adjusted.'));
    el.classList.add('is-show');
    el.classList.toggle('is-error', !!isError);
    window.clearTimeout(window.__ccvSettingsToastTimer);
    window.__ccvSettingsToastTimer = window.setTimeout(function(){
      el.classList.remove('is-show');
      el.classList.remove('is-error');
    }, 1600);
  }

  function getActiveSettingValue(setting){
    var active = qs('[data-setting="' + setting + '"].is-active');
    return active ? stringVal(active.getAttribute('data-value')) : '';
  }

  function queueSettingsSave(payload){
    var runtime = bridge();
    if (!runtime) return;
    queuedSettingsPayload = {
      availability: stringVal(payload.availability || 'online'),
      max_jobs: intVal(payload.max_jobs || 3),
      range: stringVal(payload.range || 'local_area')
    };
    if (settingsInflight) return;

    function flush(){
      if (!queuedSettingsPayload) return;
      settingsInflight = true;
      var nextPayload = queuedSettingsPayload;
      queuedSettingsPayload = null;

      runtime.saveSettings(nextPayload).then(function(resp){
        if (!resp || !resp.success) {
                toast(resp && resp.data && resp.data.message ? resp.data.message : 'Unable to save settings.', true);
          return;
        }
        toast(resp.data && resp.data.message ? resp.data.message : 'Settings updated — dispatcher adjusted.');
        if (nextPayload.availability === 'online' && typeof runtime.nudgeHeartbeat === 'function') {
          runtime.nudgeHeartbeat('settings_online');
        }
      }).catch(function(){
            toast('Network error — try again.', true);
      }).then(function(){
        settingsInflight = false;
        if (queuedSettingsPayload) flush();
      });
    }

    flush();
  }

  function listModeTargets(){
    return ['incoming', 'assigned', 'queued'];
  }

  function setListMode(mode){
    mode = listModeTargets().indexOf(mode) >= 0 ? mode : 'assigned';
    currentListMode = mode;

    qsa('.ccv-list-toggle-btn').forEach(function(btn){
      var isActive = stringVal(btn.getAttribute('data-list-target')) === mode;
      btn.classList.toggle('ccv-list-toggle-btn--active', isActive);
    });

    listModeTargets().forEach(function(bucket){
      var list = qs('#ccv-job-list-' + bucket);
      if (!list) return;
      list.classList.toggle('ccv-job-list--hidden', bucket !== mode);
    });
  }

  function preferredListMode(){
    if (manualListMode) return manualListMode;
    if ((bucketJobs(currentListMode) || []).length) return currentListMode;
    if (bucketJobs('assigned').length) return 'assigned';
    if (bucketJobs('incoming').length) return 'incoming';
    if (bucketJobs('queued').length) return 'queued';
    return currentListMode || 'assigned';
  }

  function clearSelectedJobCards(){
    qsa('.ccv-job-card').forEach(function(card){
      card.classList.remove('ccv-job-card--selected');
      card.classList.remove('is-active');
    });
  }

  function notifyMapFocus(job){
    try {
      window.dispatchEvent(new CustomEvent('caricove:activeTripFocus', { detail: { jobId: job ? stringVal(job.job_id) : '', card: null, job: job || null } }));
    } catch (err) {}
  }

  function buildMapAndNav(job){
    job = isObject(job) ? job : {};
    var phase = stringVal(job.phase || 'to_pickup').toLowerCase();
    var pickupLat = stringVal(job.pickup_lat);
    var pickupLng = stringVal(job.pickup_lng);
    var dropLat = stringVal(job.dropoff_lat);
    var dropLng = stringVal(job.dropoff_lng);
    var pickupAddress = [stringVal(job.pickup_text), stringVal(job.pickup_city)].filter(Boolean).join(', ');
    var dropoffAddress = [stringVal(job.dropoff_text), stringVal(job.dropoff_city)].filter(Boolean).join(', ');
    var mapUrl = stringVal(job.map_url);
    var navUrl = stringVal(job.nav_url);

    if (!mapUrl) {
      if (phase === 'to_dropoff') {
        if (dropLat && dropLng) mapUrl = 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(dropLat + ',' + dropLng);
        else if (dropoffAddress) mapUrl = 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(dropoffAddress);
      } else {
        if (pickupLat && pickupLng) mapUrl = 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(pickupLat + ',' + pickupLng);
        else if (pickupAddress) mapUrl = 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(pickupAddress);
      }
    }

    if (!navUrl) {
      if (phase === 'to_dropoff') {
        if (dropLat && dropLng) navUrl = 'https://www.google.com/maps/dir/?api=1&destination=' + encodeURIComponent(dropLat + ',' + dropLng);
        else if (dropoffAddress) navUrl = 'https://www.google.com/maps/dir/?api=1&destination=' + encodeURIComponent(dropoffAddress);
      } else {
        if (pickupLat && pickupLng) navUrl = 'https://www.google.com/maps/dir/?api=1&destination=' + encodeURIComponent(pickupLat + ',' + pickupLng);
        else if (pickupAddress) navUrl = 'https://www.google.com/maps/dir/?api=1&destination=' + encodeURIComponent(pickupAddress);
      }
    }

    return { mapUrl: mapUrl, navUrl: navUrl };
  }

  function renderDetailFromJob(job){
    var detailShell = qs('#ccv-job-detail-shell');
    if (!detailShell) return;
    if (!job) {
      detailShell.innerHTML = '<div class="ccv-detail-empty">Your active assigned trip appears here. Incoming offers stay in the left panel until you accept or reject them.</div>';
      notifyMapFocus(null);
      return;
    }

    var stateLabel = stringVal(job.status_label || job.status || '').toUpperCase();
    var payLine = '';
    if (job.pay_label && job.currency) {
      payLine = '<span class="ccv-pay-gold">' + escapeHtml(job.currency) + ' ' + escapeHtml(job.pay_label) + '</span>';
    }

    var pickupPhone = stringVal(job.pickup_phone);
    var dropoffPhone = stringVal(job.dropoff_phone);
    var pickupTel = pickupPhone ? 'tel:' + pickupPhone : '';
    var dropoffTel = dropoffPhone ? 'tel:' + dropoffPhone : '';
    var pickupWa = pickupPhone ? 'https://wa.me/' + pickupPhone.replace(/\D+/g, '') : '';
    var dropoffWa = dropoffPhone ? 'https://wa.me/' + dropoffPhone.replace(/\D+/g, '') : '';
    var notesText = stringVal(job.dropoff_instructions || job.delivery_instructions);
    var urls = buildMapAndNav(job);

    var html = '';
    html += '<div class="ccv-detail">';
    html += '<div class="ccv-detail-header">';
    html += '<div class="ccv-detail-title-group">';
    html += '<div class="ccv-detail-title">' + escapeHtml(job.label || '') + '</div>';
    if (payLine) html += '<div class="ccv-detail-payline">' + payLine + '</div>';
    html += '</div>';
    html += '<div class="ccv-detail-state-tag">' + escapeHtml(stateLabel) + '</div>';
    html += '</div>';

    html += '<div class="ccv-detail-grid">';
    html += '<div class="ccv-detail-card">';
    html += '<div class="ccv-detail-label">Pickup</div>';
    if (job.pickup_name) html += '<div class="ccv-addr-name">' + escapeHtml(job.pickup_name) + '</div>';
    if (job.pickup_text) html += '<div class="ccv-addr-street">' + escapeHtml(job.pickup_text) + '</div>';
    if (job.pickup_city) html += '<div class="ccv-addr-city">' + escapeHtml(job.pickup_city) + '</div>';
    if (pickupTel || pickupWa) {
      html += '<div class="ccv-detail-call-row"><div class="ccv-detail-call-actions">';
      if (pickupTel) html += '<a class="ccv-call-btn ccv-call-btn--voice" href="' + escapeHtml(pickupTel) + '">📞</a>';
      if (pickupWa) html += '<a class="ccv-call-btn ccv-call-btn--wa" href="' + escapeHtml(pickupWa) + '" target="_blank" rel="noopener noreferrer">📞</a>';
      html += '</div></div>';
    }
    html += '</div>';

    html += '<div class="ccv-detail-card">';
    html += '<div class="ccv-detail-label">Dropoff</div>';
    if (job.dropoff_name) html += '<div class="ccv-addr-name">' + escapeHtml(job.dropoff_name) + '</div>';
    if (job.dropoff_text) html += '<div class="ccv-addr-street">' + escapeHtml(job.dropoff_text) + '</div>';
    if (job.dropoff_city) html += '<div class="ccv-addr-city">' + escapeHtml(job.dropoff_city) + '</div>';
    if (dropoffTel || dropoffWa) {
      html += '<div class="ccv-detail-call-row"><div class="ccv-detail-call-actions">';
      if (dropoffTel) html += '<a class="ccv-call-btn ccv-call-btn--voice" href="' + escapeHtml(dropoffTel) + '">📞</a>';
      if (dropoffWa) html += '<a class="ccv-call-btn ccv-call-btn--wa" href="' + escapeHtml(dropoffWa) + '" target="_blank" rel="noopener noreferrer">📞</a>';
      html += '</div></div>';
    }
    html += '</div>';
    html += '</div>';

    html += '<div class="ccv-detail-actions">';
    html += '<div class="ccv-detail-codes">';
    if (job.deadline_label) html += '<span class="ccv-detail-deadline-pill">' + escapeHtml(job.deadline_label) + '</span>';
    html += '</div>';
    html += '<div class="ccv-detail-map-link">';
    html += '<button type="button" class="ccv-notes-trigger" data-role="delivery-notes" title="Delivery Notes" aria-label="Delivery Notes">';
    html += '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 2h9l5 5v13a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2zm8 1.5V8h4.5"></path><path d="M8 11h8v1.8H8zm0 3.7h8v1.8H8zm0-7.4h4.5v1.8H8z"></path></svg>';
    html += '</button>';
    html += '<button type="button" class="ccv-map-inline-btn" data-role="open-map">Open in Map</button>';
    html += '</div>';
    html += '</div>';

    if (job.next_state && job.next_state_label) {
      html += '<div class="ccv-detail-actions"><button type="button" class="ccv-btn ccv-btn--primary" data-role="primary-action">' + escapeHtml(job.next_state_label) + '</button></div>';
    }

    html += '</div>';
    detailShell.innerHTML = html;

    var notesBtn = detailShell.querySelector('[data-role="delivery-notes"]');
    if (notesBtn) {
      notesBtn.addEventListener('click', function(e){
        e.preventDefault();
        openNotesModal(notesText);
      });
    }

    var openMapBtn = detailShell.querySelector('[data-role="open-map"]');
    if (openMapBtn) {
      openMapBtn.addEventListener('click', function(e){
        e.preventDefault();
        openJobInMap(job);
      });
    }

    var primaryBtn = detailShell.querySelector('[data-role="primary-action"]');
    if (primaryBtn) {
      primaryBtn.addEventListener('click', function(){
        if (job.requires_code) {
          pendingCodeJob = job;
          openCodeModal();
          return;
        }

        primaryBtn.disabled = true;
        primaryBtn.textContent = job.next_state === 'en_route' ? 'Starting…' : 'Processing…';
        bridge().transition({
          job_id: stringVal(job.job_id),
          from_state: stringVal(job.status),
          to_state: stringVal(job.next_state),
          label: stringVal(job.next_state_label),
          requires_code: !!job.requires_code
        }).then(function(resp){
          if (!resp || !resp.success) {
            primaryBtn.disabled = false;
            primaryBtn.textContent = stringVal(job.next_state_label || 'Try Again');
            return;
          }
          if (job.next_state === 'en_route') {
            openJobInMap(job);
          }
        }).catch(function(){
          primaryBtn.disabled = false;
          primaryBtn.textContent = stringVal(job.next_state_label || 'Try Again');
        });
      });
    }

    notifyMapFocus(job);
  }

  function focusAssignedJob(){
    var assigned = bucketJobs('assigned')[0] || null;
    clearSelectedJobCards();
    if (!assigned) {
      renderDetailFromJob(null);
      return;
    }

    var card = qs('#ccv-job-list-assigned .ccv-job-card[data-job-id="' + stringVal(assigned.job_id) + '"]');
    if (card) {
      card.classList.add('ccv-job-card--selected');
      card.classList.add('is-active');
    }
    renderDetailFromJob(assigned);
  }

  function openModal(backdrop){
    if (!backdrop) return;
    backdrop.classList.add('ccv-modal-backdrop--show');
    document.body.style.overflow = 'hidden';
  }

  function closeModal(backdrop){
    if (!backdrop) return;
    backdrop.classList.remove('ccv-modal-backdrop--show');
    document.body.style.overflow = '';
  }

  function openCodeModal(){
    var backdrop = qs('#ccv-code-modal-backdrop');
    var input = qs('#ccv-code-input');
    var status = qs('#ccv-code-modal-status');
    if (status) {
      status.textContent = '';
      status.className = 'ccv-modal-status';
    }
    if (input) input.value = '';
    openModal(backdrop);
    window.setTimeout(function(){ if (input) input.focus(); }, 10);
  }

  function closeCodeModal(){
    closeModal(qs('#ccv-code-modal-backdrop'));
  }

  function openNotesModal(text){
    var body = qs('#ccv-notes-modal-body');
    if (body) body.textContent = stringVal(text || 'No delivery instructions provided.').trim() || 'No delivery instructions provided.';
    openModal(qs('#ccv-notes-modal-backdrop'));
  }

  function closeNotesModal(){
    closeModal(qs('#ccv-notes-modal-backdrop'));
  }

 function openPayoutModal(type){
    var selectedType = 'scheduled';
    var runtime = bridge();
    var state = runtime && typeof runtime.getState === 'function' ? runtime.getState() : currentState;
    var payoutMethod = state && state.payout_method ? state.payout_method : {};
    if (!payoutMethod.configured) {
      activateView('payout-method');
      var pmToast = qs('#ccv-payout-method-toast');
      if (pmToast) {
        pmToast.textContent = 'Add a payout method before requesting cashout.';
        pmToast.classList.add('is-error');
      }
      return;
    }


    if (false && selectedType === 'instant') {
      if (window.CaricoveCourierConsole && typeof window.CaricoveCourierConsole.toast === 'function') {
        window.CaricoveCourierConsole.toast('Not eligible at this moment.');
      } else {
        window.alert('Not eligible at this moment.');
      }
      return;
    }

    var backdrop = qs('#ccv-payout-modal-backdrop');
    var input = qs('#ccv-payout-amount');
    var status = qs('#ccv-payout-modal-status');
    var dest = qs('#ccv-payout-destination-display');
    if (dest) dest.textContent = payoutMethod.destination_label || 'Saved payout method';

    qsa('.ccv-pill').forEach(function(pill){
      var thisType = stringVal(pill.getAttribute('data-payout-type') || 'scheduled');
      pill.classList.toggle('ccv-pill--active', thisType === selectedType);
      pill.style.display = thisType === 'scheduled' ? 'inline-flex' : 'none';
    });
    
    

    if (status) {
      status.textContent = '';
      status.className = 'ccv-modal-status';
    }
    if (input) input.value = '';
    openModal(backdrop);
    window.setTimeout(function(){ if (input) input.focus(); }, 10);
  }

  function closePayoutModal(){
    closeModal(qs('#ccv-payout-modal-backdrop'));
  }

  function clearOfferTimer(){
    if (offerState.countdownTimer) {
      window.clearInterval(offerState.countdownTimer);
      offerState.countdownTimer = null;
    }
  }

function ensureOfferModal(){
    var backdrop = qs('#ccv-offer-modal-backdrop');
    if (!backdrop) {
      backdrop = document.createElement('div');
      backdrop.id = 'ccv-offer-modal-backdrop';
      document.body.appendChild(backdrop);
    }

    var styleId = 'ccv-offer-modal-inline-style';
    if (!document.getElementById(styleId)) {
      var style = document.createElement('style');
      style.id = styleId;
      style.textContent = ''+
        '.ccv-offer-backdrop{position:fixed;inset:0;background:rgba(2,7,18,.78);backdrop-filter:blur(10px);display:none;align-items:center;justify-content:center;z-index:99999;padding:24px}'+
        '.ccv-offer-backdrop--show{display:flex}'+
        '.ccv-offer-modal{width:min(480px,100%);border:1px solid rgba(70,160,255,.35);background:linear-gradient(180deg,rgba(8,18,38,.98),rgba(4,10,22,.98));box-shadow:0 20px 80px rgba(0,0,0,.6),0 0 24px rgba(18,122,255,.22);border-radius:24px;padding:22px;color:#eef6ff}'+
        '.ccv-offer-title{font-size:20px;font-weight:700;letter-spacing:.02em;margin-bottom:8px}'+
        '.ccv-offer-route{font-size:14px;opacity:.86;line-height:1.45;margin-bottom:18px}'+
        '.ccv-offer-chip{display:inline-flex;align-items:center;gap:8px;padding:8px 12px;border-radius:999px;background:rgba(16,38,78,.92);border:1px solid rgba(64,140,255,.35);font-size:13px;font-weight:600;margin-bottom:16px}'+
        '.ccv-offer-actions{display:flex;gap:12px;margin-top:18px}'+
        '.ccv-offer-actions .ccv-btn{flex:1;min-height:52px;font-size:15px}'+
        '.ccv-offer-meta{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:10px}'+
        '.ccv-offer-meta-card{padding:12px 14px;border-radius:16px;background:rgba(9,20,42,.88);border:1px solid rgba(255,255,255,.06)}'+
        '.ccv-offer-meta-label{font-size:11px;letter-spacing:.08em;text-transform:uppercase;opacity:.6;margin-bottom:4px}'+
        '.ccv-offer-meta-value{font-size:14px;font-weight:600}'+
        '.ccv-btn--danger{background:linear-gradient(135deg,#7d1020,#ff465d);color:#fff;border:1px solid rgba(255,110,132,.5)}'+
        '.ccv-btn--danger:disabled,.ccv-btn--primary:disabled{opacity:.55;cursor:not-allowed;filter:saturate(.65)}';
      document.head.appendChild(style);
    }

    if (backdrop.innerHTML) return backdrop;

    backdrop.className = 'ccv-offer-backdrop';
    backdrop.innerHTML = ''+
      '<div class="ccv-offer-modal" role="dialog" aria-modal="true" aria-labelledby="ccv-offer-modal-title">'+
      '  <div class="ccv-offer-title" id="ccv-offer-modal-title">Incoming Offer</div>'+
      '  <div class="ccv-offer-route" id="ccv-offer-modal-route"></div>'+
      '  <div class="ccv-offer-chip" id="ccv-offer-modal-countdown">Respond in 12s</div>'+
      '  <div class="ccv-offer-meta">'+
      '    <div class="ccv-offer-meta-card"><div class="ccv-offer-meta-label">Distance band</div><div class="ccv-offer-meta-value" id="ccv-offer-distance-band">�</div></div>'+
      '    <div class="ccv-offer-meta-card"><div class="ccv-offer-meta-label">Quote</div><div class="ccv-offer-meta-value" id="ccv-offer-quote">�</div></div>'+
      '  </div>'+
      '  <div class="ccv-offer-actions">'+
      '    <button type="button" class="ccv-btn ccv-btn--primary" id="ccv-offer-accept">Accept</button>'+
      '    <button type="button" class="ccv-btn ccv-btn--danger" id="ccv-offer-reject">Reject</button>'+
      '  </div>'+
      '</div>';
    return backdrop;
  }
  
  
  function closeOfferModal(){
    clearOfferTimer();
    offerState.jobId = '';
    offerState.expiresAt = 0;
    offerState.active = false;
    offerState.locked = false;
    var backdrop = qs('#ccv-offer-modal-backdrop');
    if (backdrop) backdrop.classList.remove('ccv-offer-backdrop--show');
  }

  function updateOfferCountdown(){
    var countdown = qs('#ccv-offer-modal-countdown');
    var acceptBtn = qs('#ccv-offer-accept');
    var rejectBtn = qs('#ccv-offer-reject');
    if (!countdown) return;
    var secs = Math.max(0, Math.ceil(numberVal(offerState.expiresAt) - (Date.now() / 1000)));
    countdown.textContent = secs > 0 ? ('Respond in ' + secs + 's') : 'Offer expired';
    if (acceptBtn) acceptBtn.disabled = offerState.locked || secs <= 0;
    if (rejectBtn) rejectBtn.disabled = offerState.locked || secs <= 0;
    if (secs <= 0) {
      clearOfferTimer();
      offerState.active = false;
      window.setTimeout(function(){ if (bridge()) bridge().refresh('offer_timeout'); }, 600);
    }
  }

  function openOfferModal(job){
    if (!job) return;
    var runtime = bridge();
    if (!runtime) return;
    ensureOfferModal();

    var title = qs('#ccv-offer-modal-title');
    var route = qs('#ccv-offer-modal-route');
    var distanceBand = qs('#ccv-offer-distance-band');
    var quote = qs('#ccv-offer-quote');
    var acceptBtn = qs('#ccv-offer-accept');
    var rejectBtn = qs('#ccv-offer-reject');
    var backdrop = qs('#ccv-offer-modal-backdrop');

    var fromArea = stringVal(job.pickup_city || job.pickup_text || 'Pickup');
    var toArea = stringVal(job.dropoff_city || job.dropoff_text || 'Dropoff');
    if (title) title.textContent = stringVal(job.label || ('Shipment #' + stringVal(job.job_id)));
    if (route) route.textContent = fromArea + ' → ' + toArea;
    if (distanceBand) distanceBand.textContent = stringVal(job.distance_band || '—').replace(/_/g, ' ');
    if (quote) quote.textContent = job.quote_total_gyd ? ('GYD ' + money(job.quote_total_gyd)) : '—';

    offerState.jobId = stringVal(job.job_id);
    offerState.expiresAt = numberVal(job.offer_expires_at || 0);
    offerState.active = true;
    offerState.locked = false;

    clearOfferTimer();
    offerState.countdownTimer = window.setInterval(updateOfferCountdown, 1000);
    updateOfferCountdown();

    if (acceptBtn) {
      acceptBtn.onclick = function(){
        offerState.locked = true;
        updateOfferCountdown();
        runtime.setFocusedJob(stringVal(job.job_id));
        runtime.acceptOffer(stringVal(job.job_id)).then(function(resp){
          if (!resp || !resp.success) {
            offerState.locked = false;
            updateOfferCountdown();
            return;
          }
          closeOfferModal();
        }).catch(function(){
          offerState.locked = false;
          updateOfferCountdown();
        });
      };
    }

    if (rejectBtn) {
      rejectBtn.onclick = function(){
        offerState.locked = true;
        updateOfferCountdown();
        runtime.rejectOffer(stringVal(job.job_id)).then(function(){
          closeOfferModal();
        }).catch(function(){
          offerState.locked = false;
          updateOfferCountdown();
        });
      };
    }

    if (backdrop) backdrop.classList.add('ccv-offer-backdrop--show');
  }

  function maybeShowOfferModal(){
    var offers = bucketJobs('incoming').filter(function(job){
      return !!job && !!job.offer_is_live && intVal(job.offer_expires_at || 0) > nowSec();
    }).sort(function(a, b){
      return intVal(a.offer_expires_at || 0) - intVal(b.offer_expires_at || 0);
    });

    if (!offers.length) {
      closeOfferModal();
      return;
    }

    var nextOffer = offers[0];
    if (offerState.active && offerState.jobId === stringVal(nextOffer.job_id)) {
      offerState.expiresAt = numberVal(nextOffer.offer_expires_at || 0);
      updateOfferCountdown();
      return;
    }

    openOfferModal(nextOffer);
  }

  function formatDeadlineCountdown(diff){
    var remaining = Math.max(0, Math.round(diff));
    var mins = Math.floor(remaining / 60);
    var secs = remaining % 60;
    if (mins >= 60) {
      var hrs = Math.floor(mins / 60);
      var minsR = mins % 60;
      return hrs + 'h ' + minsR + 'm left';
    }
    return mins + 'm ' + String(secs).padStart(2, '0') + 's left';
  }

  function updateCountdownPills(){
    qsa('.ccv-job-pill--time').forEach(function(pill){
      var card = pill.closest('.ccv-job-card');
      if (!card) return;

      var ts = intVal(card.getAttribute('data-deadline-ts') || 0);
      var deadlineLabel = stringVal(card.getAttribute('data-deadline-label') || '').trim();
      var offerLive = stringVal(card.getAttribute('data-offer-live')) === '1';

      if (!ts && !deadlineLabel) return;

      var diff = ts ? (ts - (Date.now() / 1000)) : 0;
      var currentMode = pill.getAttribute('data-display-mode') || 'countdown';
      var nextSwitchAt = intVal(pill.getAttribute('data-next-switch-at') || 0);

      if (!offerLive && deadlineLabel) {
        if (!nextSwitchAt) {
          nextSwitchAt = Math.floor(Date.now() / 1000) + 30;
          pill.setAttribute('data-next-switch-at', String(nextSwitchAt));
        } else if ((Date.now() / 1000) >= nextSwitchAt) {
          currentMode = currentMode === 'deadline' ? 'countdown' : 'deadline';
          pill.setAttribute('data-display-mode', currentMode);
          pill.setAttribute('data-next-switch-at', String(Math.floor(Date.now() / 1000) + 30));
        }
      } else {
        currentMode = 'countdown';
        pill.setAttribute('data-display-mode', 'countdown');
        pill.removeAttribute('data-next-switch-at');
      }

      var showDeadline = (!offerLive && deadlineLabel && currentMode === 'deadline');
      var label = deadlineLabel || pill.textContent || '';
      var bg = 'linear-gradient(135deg,#12406b,#23b1ff)';
      var color = '#e9f6ff';
      var border = '1px solid rgba(120,190,255,0.9)';
      var shadow = '0 0 10px rgba(60,170,255,0.7), 0 0 16px rgba(0,0,0,1)';

      if (!showDeadline) {
        if (!ts) return;
        if (diff <= -60) {
          label = 'Late';
          bg = 'linear-gradient(135deg,#3c0b10,#a21424)';
          color = '#ffe6ea';
          border = '1px solid rgba(255,120,140,0.9)';
          shadow = '0 0 10px rgba(255,80,110,0.9), 0 0 20px rgba(0,0,0,1)';
        } else {
          label = formatDeadlineCountdown(diff);
          if (diff <= 0) {
            bg = 'linear-gradient(135deg,#4a1b00,#ff7b00)';
            color = '#fff3e5';
            border = '1px solid rgba(255,180,90,0.9)';
            shadow = '0 0 10px rgba(255,150,60,0.9), 0 0 20px rgba(0,0,0,1)';
          } else if (diff <= 5 * 60) {
            bg = 'linear-gradient(135deg,#4c0c11,#e7384b)';
            color = '#ffe6ea';
            border = '1px solid rgba(255,122,140,0.9)';
            shadow = '0 0 10px rgba(231,56,75,0.9), 0 0 20px rgba(0,0,0,1)';
          } else if (diff <= 15 * 60) {
            bg = 'linear-gradient(135deg,#473307,#f4c048)';
            color = '#fff7df';
            border = '1px solid rgba(244,192,72,0.9)';
            shadow = '0 0 10px rgba(244,192,72,0.7), 0 0 16px rgba(0,0,0,1)';
          }
        }
      } else {
        pill.setAttribute('data-display-mode', 'deadline');
      }

      if (pill.textContent !== label) pill.textContent = label;
      if (pill.style.background !== bg) pill.style.background = bg;
      if (pill.style.color !== color) pill.style.color = color;
      if (pill.style.border !== border) pill.style.border = border;
      if (pill.style.boxShadow !== shadow) pill.style.boxShadow = shadow;
      pill.style.fontWeight = '600';
      pill.style.letterSpacing = '0.06em';
    });
  }

  function activateView(view){
    view = stringVal(view || 'today');
    var activeTab = qs('.ccv-console-tab[data-view="' + view + '"]');
    qsa('.ccv-console-tab').forEach(function(tab){
      tab.classList.toggle('ccv-console-tab--active', tab === activeTab);
    });
    qsa('.ccv-console-body').forEach(function(body){
      body.classList.toggle('ccv-console-body--hidden', stringVal(body.getAttribute('data-view')) !== view);
    });
    if (view === 'map' && window.CaricoveCourierMap && typeof window.CaricoveCourierMap.ensureLoaded === 'function') {
      window.CaricoveCourierMap.ensureLoaded();
    }
    return activeTab;
  }

  function openJobInMap(job){
    var targetJob = typeof job === 'string' ? findJob(job) : job;
    var jobId = targetJob ? stringVal(targetJob.job_id) : stringVal(job);
    if (bridge() && jobId) {
      bridge().setFocusedJob(jobId);
    }
    if (targetJob) {
      notifyMapFocus(targetJob);
    }
    var mapTab = qs('.ccv-console-tab[data-view="map"]');
    if (mapTab && typeof mapTab.click === 'function') {
      mapTab.click();
    } else {
      activateView('map');
    }
    window.setTimeout(function(){
      if (window.CaricoveCourierMap && typeof window.CaricoveCourierMap.refresh === 'function') {
        window.CaricoveCourierMap.refresh();
      }
    }, 160);
  }

  function bindTabs(){
    qsa('.ccv-console-tab').forEach(function(tab){
      tab.addEventListener('click', function(){
        var view = stringVal(tab.getAttribute('data-view') || 'today');
        activateView(view);
      });
    });
  }

  function bindListToggle(){
    document.addEventListener('click', function(e){
      var btn = e.target.closest('.ccv-list-toggle-btn');
      if (!btn) return;
      manualListMode = stringVal(btn.getAttribute('data-list-target') || 'assigned');
      setListMode(manualListMode);
    }, true);
  }

  function bindCardClicks(){
    document.addEventListener('click', function(e){
      var card = e.target.closest('.ccv-job-card');
      if (!card) return;
      if (e.target.closest('button, a, input, select, textarea')) return;

      var jobId = stringVal(card.getAttribute('data-job-id') || '');
      var job = findJob(jobId);
      var bucket = stringVal(card.getAttribute('data-queue-bucket') || (job ? job.queue_bucket : ''));
      if (!job || !bridge()) return;

      bridge().setFocusedJob(jobId);

      if (bucket === 'incoming') {
        e.preventDefault();
        e.stopPropagation();
        openOfferModal(job);
        return false;
      }

      if (bucket === 'queued') {
        e.preventDefault();
        e.stopPropagation();
        focusAssignedJob();
        return false;
      }

      clearSelectedJobCards();
      card.classList.add('ccv-job-card--selected');
      card.classList.add('is-active');
      renderDetailFromJob(job);
      return true;
    }, true);
  }

  function bindCodeModal(){
    var backdrop = qs('#ccv-code-modal-backdrop');
    if (backdrop) {
      backdrop.addEventListener('click', function(e){
        if (e.target === backdrop) closeCodeModal();
      });
    }
    var closeBtn = qs('#ccv-code-modal-close');
    if (closeBtn) closeBtn.addEventListener('click', closeCodeModal);
    var cancelBtn = qs('#ccv-code-modal-cancel');
    if (cancelBtn) cancelBtn.addEventListener('click', closeCodeModal);
    var submitBtn = qs('#ccv-code-modal-submit');
    if (submitBtn) {
      submitBtn.addEventListener('click', function(){
        var input = qs('#ccv-code-input');
        var status = qs('#ccv-code-modal-status');
        var code = input ? stringVal(input.value).trim() : '';
        if (!pendingCodeJob) {
          closeCodeModal();
          return;
        }
        if (!code) {
          if (status) {
            status.textContent = 'Please enter the delivery code.';
            status.className = 'ccv-modal-status ccv-modal-status--error';
          }
          return;
        }
        if (status) {
          status.textContent = 'Verifying code…';
          status.className = 'ccv-modal-status';
        }
        bridge().transition({
          job_id: stringVal(pendingCodeJob.job_id),
          from_state: stringVal(pendingCodeJob.status),
          to_state: stringVal(pendingCodeJob.next_state),
          label: stringVal(pendingCodeJob.next_state_label),
          requires_code: true,
          code: code
        }).then(function(resp){
          if (!resp || !resp.success) {
            if (status) {
              status.textContent = resp && resp.data && resp.data.message ? resp.data.message : 'Unable to verify code.';
              status.className = 'ccv-modal-status ccv-modal-status--error';
            }
            return;
          }
          pendingCodeJob = null;
          closeCodeModal();
        }).catch(function(){
          if (status) {
            status.textContent = 'Network error. Please try again.';
            status.className = 'ccv-modal-status ccv-modal-status--error';
          }
        });
      });
    }
  }

  function bindNotesModal(){
    var backdrop = qs('#ccv-notes-modal-backdrop');
    if (backdrop) {
      backdrop.addEventListener('click', function(e){
        if (e.target === backdrop) closeNotesModal();
      });
    }
    var closeBtn = qs('#ccv-notes-modal-close');
    if (closeBtn) closeBtn.addEventListener('click', closeNotesModal);
  }

  function bindPayoutModal(){
    var backdrop = qs('#ccv-payout-modal-backdrop');
    if (backdrop) {
      backdrop.addEventListener('click', function(e){
        if (e.target === backdrop) closePayoutModal();
      });
    }
    var closeBtn = qs('#ccv-payout-modal-close');
    if (closeBtn) closeBtn.addEventListener('click', closePayoutModal);
    var cancelBtn = qs('#ccv-payout-modal-cancel');
    if (cancelBtn) cancelBtn.addEventListener('click', closePayoutModal);

    var btnScheduled = qs('#ccv-btn-payout-scheduled');
    if (btnScheduled) btnScheduled.addEventListener('click', function(){ openPayoutModal('scheduled'); });
    var btnInstant = qs('#ccv-btn-payout-instant');
    if (btnInstant) btnInstant.style.display = 'none';

    qsa('.ccv-pill').forEach(function(pill){
      pill.addEventListener('click', function(){
        var type = 'scheduled';
        qsa('.ccv-pill').forEach(function(item){
          item.classList.toggle('ccv-pill--active', item === pill);
          item.style.display = 'inline-flex';
        });
        var feeNote = qs('#ccv-modal-fee-note');
        if (feeNote) feeNote.textContent = 'Standard courier payout request. Awaiting admin approval.';
      });
    });

    var submitBtn = qs('#ccv-payout-modal-submit');
    if (submitBtn) {
      submitBtn.addEventListener('click', function(){
        var runtime = bridge();
        var amountInput = qs('#ccv-payout-amount');
        var status = qs('#ccv-payout-modal-status');
        if (!runtime || !amountInput || !status) return;

        var amount = parseFloat(amountInput.value || '0');
        if (!(amount > 0)) {
          status.textContent = 'Please enter an amount greater than zero.';
          status.className = 'ccv-modal-status ccv-modal-status--error';
          return;
        }

       var activePill = qs('.ccv-pill.ccv-pill--active');
var type = 'scheduled';

status.textContent = 'Submitting payout request�';
status.className = 'ccv-modal-status';
submitBtn.disabled = true;

runtime.requestPayout({ amount: amount, type: type }).then(function(resp){
          submitBtn.disabled = false;
          if (!resp || !resp.success) {
            status.textContent = resp && resp.data && resp.data.message ? resp.data.message : 'Unable to submit request.';
            status.className = 'ccv-modal-status ccv-modal-status--error';
            return;
          }
          status.textContent = resp.data && resp.data.message ? resp.data.message : 'Payout request submitted.';
          status.className = 'ccv-modal-status ccv-modal-status--success';
          window.setTimeout(closePayoutModal, 900);
        }).catch(function(){
          submitBtn.disabled = false;
          status.textContent = 'Network error. Please try again.';
          status.className = 'ccv-modal-status ccv-modal-status--error';
        });
      });
    }
  }

  function bindSettings(){
    var shell = qs('#ccv-settings-shell');
    if (!shell) return;
    shell.addEventListener('click', function(e){
      var btn = e.target.closest('[data-setting]');
      if (!btn) return;
      var setting = stringVal(btn.getAttribute('data-setting'));
      var value = stringVal(btn.getAttribute('data-value'));
      if (!setting || !value) return;

      if (setting === 'availability') {
        syncSettingsUi({
          availability: value,
          max_jobs: getActiveSettingValue('max_jobs') || currentState.settings.max_jobs,
          range: getActiveSettingValue('range') || currentState.settings.range
        });
      } else if (setting === 'max_jobs') {
        syncSettingsUi({
          availability: getActiveSettingValue('availability') || currentState.settings.availability,
          max_jobs: value,
          range: getActiveSettingValue('range') || currentState.settings.range
        });
      } else if (setting === 'range') {
        syncSettingsUi({
          availability: getActiveSettingValue('availability') || currentState.settings.availability,
          max_jobs: getActiveSettingValue('max_jobs') || currentState.settings.max_jobs,
          range: value
        });
      }

      queueSettingsSave({
        availability: getActiveSettingValue('availability') || currentState.settings.availability,
        max_jobs: getActiveSettingValue('max_jobs') || currentState.settings.max_jobs,
        range: getActiveSettingValue('range') || currentState.settings.range
      });
    });
  }

  function bindEscapeKey(){
    document.addEventListener('keydown', function(e){
      if (e.key !== 'Escape') return;
      closePayoutModal();
      closeCodeModal();
      closeNotesModal();
    });
  }

  function renderState(state){
    currentState = isObject(state) ? state : currentState;
    renderBalances(currentState.balances || {});
    renderBucket('incoming', bucketJobs('incoming'));
    renderBucket('assigned', bucketJobs('assigned'));
    renderBucket('queued', bucketJobs('queued'));
    setListMode(preferredListMode());
    focusAssignedJob();
    maybeShowOfferModal();
    updateCountdownPills();
  }

  function fadeSplash(){
    if (splashDone) return;
    splashDone = true;
    var splash = qs('#ccv-courier-splash');
    var consoleEl = qs('.ccv-console');
    if (!splash || !consoleEl) return;
    window.setTimeout(function(){
      splash.style.opacity = '0';
      splash.style.pointerEvents = 'none';
      consoleEl.style.opacity = '1';
      consoleEl.style.transform = 'translateY(0)';
    }, 240);
  }

  function boot(){
    var runtime = bridge();
    if (!runtime) return;
    bindTabs();
    bindListToggle();
    bindCardClicks();
    bindCodeModal();
    bindNotesModal();
    bindPayoutModal();
    bindEscapeKey();
    runtime.subscribe(function(nextState){
      renderState(nextState || {});
    });
    updateCountdownPills();
    window.setInterval(function(){
      if (document.hidden) return;
      updateCountdownPills();
    }, 1000);
    fadeSplash();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})(window, document);
