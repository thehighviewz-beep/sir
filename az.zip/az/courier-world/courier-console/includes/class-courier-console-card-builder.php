<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Caricove_Courier_Console_Card_Builder {
    public static function render( array $job, $bucket ) {
        return caricove_courier_console_render_template(
            'courier-console-job-card.php',
            array(
                'job'    => $job,
                'bucket' => $bucket,
            )
        );
    }
}
