<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! function_exists( 'caricove_courier_console_template_path' ) ) {
    function caricove_courier_console_template_path( $template_name ) {
        return trailingslashit( CARICOVE_COURIER_CONSOLE_DIR . 'templates' ) . ltrim( $template_name, '/' );
    }
}

if ( ! function_exists( 'caricove_courier_console_render_template' ) ) {
    function caricove_courier_console_render_template( $template_name, array $vars = array() ) {
        $template_path = caricove_courier_console_template_path( $template_name );
        if ( ! file_exists( $template_path ) ) {
            return '';
        }

        if ( ! empty( $vars ) ) {
            extract( $vars, EXTR_SKIP );
        }

        ob_start();
        include $template_path;
        return ob_get_clean();
    }
}

if ( ! function_exists( 'caricove_courier_console_empty_text' ) ) {
    function caricove_courier_console_empty_text( $bucket ) {
        $bucket = sanitize_key( (string) $bucket );
        if ( 'incoming' === $bucket ) {
            return 'No incoming offers right now. New dispatches will appear here instantly.';
        }
        if ( 'assigned' === $bucket ) {
            return 'No active assigned trip right now. Your live trip appears here when you accept one.';
        }
        return 'No queued jobs right now. Accepted follow-up jobs wait here until your active trip clears.';
    }
}

if ( ! function_exists( 'caricove_courier_console_bridge_bootstrap' ) ) {
    function caricove_courier_console_bridge_bootstrap( $courier_id ) {
        if ( function_exists( 'ccv_ccb_render_bootstrap_script' ) ) {
            return ccv_ccb_render_bootstrap_script( $courier_id );
        }
        return '';
    }
}
