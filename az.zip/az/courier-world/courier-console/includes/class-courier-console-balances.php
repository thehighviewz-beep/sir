<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Caricove_Courier_Console_Balances {
    public static function from_state( array $state ) {
        $balances = isset( $state['balances'] ) && is_array( $state['balances'] ) ? $state['balances'] : array();

        return array(
            'available' => floatval( $balances['available'] ?? 0 ),
            'clearing'  => floatval( $balances['clearing'] ?? 0 ),
            'held'      => floatval( $balances['held'] ?? 0 ),
            'currency'  => (string) ( $balances['currency'] ?? 'GYD' ),
        );
    }
}
