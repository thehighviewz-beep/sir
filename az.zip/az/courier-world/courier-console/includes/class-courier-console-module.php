<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Caricove_Courier_Console_Module {
    public static function boot() {
        add_action( 'wp_enqueue_scripts', array( 'Caricove_Courier_Console_Assets', 'register' ), 20 );
        add_action( 'wp_enqueue_scripts', array( 'Caricove_Courier_Console_Assets', 'maybe_enqueue_frontend' ), 25 );
        Caricove_Courier_Console_Shortcode::boot();
    }
}
