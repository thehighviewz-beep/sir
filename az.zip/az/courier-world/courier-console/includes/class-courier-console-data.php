<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Caricove_Courier_Console_Data {
    public static function get_initial_state( $courier_id ) {
        if ( function_exists( 'ccv_ccb_get_runtime_payload' ) ) {
            return ccv_ccb_get_runtime_payload( $courier_id );
        }

        return array(
            'courier_id'   => intval( $courier_id ),
            'generated_at' => time(),
            'jobs'         => array(
                'incoming' => array(),
                'assigned' => array(),
                'queued'   => array(),
            ),
            'balances'     => array(
                'available' => 0,
                'clearing'  => 0,
                'held'      => 0,
                'currency'  => 'GYD',
            ),
            'settings'     => array(
                'availability' => 'online',
                'max_jobs'     => 3,
                'range'        => 'local_area',
                'radius_km'    => 7,
            ),
            'mission'      => array(),
            'focus_job_id' => 0,
        );
    }
}
