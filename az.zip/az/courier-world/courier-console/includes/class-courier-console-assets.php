<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Caricove_Courier_Console_Assets {
    public static function register() {
        wp_register_style(
            'caricove-courier-console',
            CARICOVE_COURIER_CONSOLE_URL . 'assets/css/courier-console.css',
            array(),
            '3.0.1'
        );

        wp_register_script(
            'caricove-courier-console',
            CARICOVE_COURIER_CONSOLE_URL . 'assets/js/courier-console.js',
            array( 'ccv-courier-bridge-runtime' ),
            '3.0.1',
            true
        );
    }

    protected static function should_enqueue_frontend() {
        if ( is_admin() ) {
            return false;
        }

        if ( apply_filters( 'caricove_courier_console_force_enqueue', false ) ) {
            return true;
        }

        global $post;

        return $post
            && isset( $post->post_content )
            && function_exists( 'has_shortcode' )
            && has_shortcode( $post->post_content, 'caricove_courier_console' );
    }

    public static function maybe_enqueue_frontend() {
        self::register();

        if ( ! self::should_enqueue_frontend() ) {
            return;
        }

        if ( function_exists( 'ccv_ccb_enqueue_runtime_script' ) ) {
            ccv_ccb_enqueue_runtime_script();
        }

        wp_enqueue_style( 'caricove-courier-console' );
        wp_enqueue_script( 'caricove-courier-console' );
    }

    public static function enqueue() {
        self::register();

        if ( function_exists( 'ccv_ccb_enqueue_runtime_script' ) ) {
            ccv_ccb_enqueue_runtime_script();
        }

        wp_enqueue_style( 'caricove-courier-console' );
        wp_enqueue_script( 'caricove-courier-console' );
    }
}
