<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Caricove_Courier_Console_Jobs {
    public static function buckets() {
        return array( 'incoming', 'assigned', 'queued' );
    }

    public static function get_bucket_jobs( array $state, $bucket ) {
        $jobs = isset( $state['jobs'] ) && is_array( $state['jobs'] ) ? $state['jobs'] : array();
        return isset( $jobs[ $bucket ] ) && is_array( $jobs[ $bucket ] ) ? $jobs[ $bucket ] : array();
    }
}
