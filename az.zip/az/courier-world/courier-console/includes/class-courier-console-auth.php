<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Caricove_Courier_Console_Auth {
    const ROLE_COURIER = 'caricove_courier';

    public static function current_user_or_error() {
        if ( ! is_user_logged_in() ) {
            return new WP_Error( 'not_logged_in', 'You must be logged in to view the courier console.' );
        }

        $user = wp_get_current_user();
        if ( ! $user || ! $user->ID ) {
            return new WP_Error( 'missing_user', 'Unable to load your courier profile.' );
        }

        $roles = (array) $user->roles;
        if ( ! in_array( self::ROLE_COURIER, $roles, true ) && ! in_array( 'administrator', $roles, true ) ) {
            return new WP_Error( 'forbidden', 'This console is reserved for Caricove couriers.' );
        }

        return $user;
    }
}
