<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Caricove_Courier_Console_Shortcode {
    public static function boot() {
        add_shortcode( 'caricove_courier_console', array( __CLASS__, 'render' ) );
    }

    public static function render() {
        $user = Caricove_Courier_Console_Auth::current_user_or_error();
        if ( is_wp_error( $user ) ) {
            return '<div class="ccv-courier-shell ccv-courier-shell--restricted">' . esc_html( $user->get_error_message() ) . '</div>';
        }

        $courier_id   = intval( $user->ID );
        $display_name = $user->display_name ? $user->display_name : $user->user_login;
        $state        = Caricove_Courier_Console_Data::get_initial_state( $courier_id );
        $balances     = Caricove_Courier_Console_Balances::from_state( $state );

        Caricove_Courier_Console_Assets::enqueue();
        if ( class_exists( 'Caricove_Courier_Map_Assets' ) ) {
            Caricove_Courier_Map_Assets::enqueue();
        }

        return caricove_courier_console_render_template(
            'courier-console-shell.php',
            array(
                'courier_id'   => $courier_id,
                'display_name' => $display_name,
                'state'        => $state,
                'balances'     => $balances,
            )
        );
    }
}
