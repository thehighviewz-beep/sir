<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$bridge_config = function_exists( 'ccv_ccb_get_bootstrap_config' ) ? ccv_ccb_get_bootstrap_config( $courier_id ) : array();
$jobs          = isset( $state['jobs'] ) && is_array( $state['jobs'] ) ? $state['jobs'] : array();
$settings_markup = '';
$payout_method_markup = '';

if ( has_action( 'caricove_logistics_scaffold_settings' ) ) {
    ob_start();
    do_action( 'caricove_logistics_scaffold_settings', $courier_id );
    $settings_markup = trim( ob_get_clean() );
}

if ( has_action( 'caricove_logistics_scaffold_payout_method' ) ) {
    ob_start();
    do_action( 'caricove_logistics_scaffold_payout_method', $courier_id );
    $payout_method_markup = trim( ob_get_clean() );
}


?>
<?php echo caricove_courier_console_bridge_bootstrap( $courier_id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
<style id="ccv-courier-shell-critical">
.ccv-courier-shell{position:relative;display:block;background:radial-gradient(circle at top, rgba(6, 40, 100, 0.92), rgba(1, 4, 12, 0.98));color:#eef6ff;border-radius:24px;overflow:hidden}
.ccv-courier-shell .ccv-console{opacity:0;transform:translateY(8px);transition:opacity .24s ease,transform .24s ease}
.ccv-courier-shell .ccv-splash{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;z-index:4;background:radial-gradient(circle at top, rgba(5,34,84,.92), rgba(2,8,18,.98))}
.ccv-courier-shell .ccv-console-body--hidden{display:none!important}
.ccv-courier-shell .ccv-courier-map-shell{position:relative;width:100%}
.ccv-courier-shell #ccv-map-canvas{margin-top:10px;width:100%;height:75vh;min-height:560px;border-radius:16px;overflow:hidden;border:1px solid rgba(100,160,255,.6);background:radial-gradient(circle at top, rgba(6,40,100,.9), rgba(1,4,12,.98))}
.ccv-offer-backdrop{position:fixed;inset:0;background:rgba(2,7,18,.78);backdrop-filter:blur(10px);display:none;align-items:center;justify-content:center;z-index:99999;padding:24px}
.ccv-offer-backdrop--show{display:flex}
</style>
<div class="ccv-courier-shell ccv-courier-shell--desktop">
    <div id="ccv-courier-splash" class="ccv-splash">
        <div class="ccv-splash-inner">
            <div class="ccv-splash-ring"><div class="ccv-splash-core"></div></div>
            <div class="ccv-splash-title">Caricove Courier</div>
            <div class="ccv-splash-sub">Preparing your workspace…</div>
        </div>
    </div>

    <div class="ccv-console">
        <header class="ccv-console-header">
            <div class="ccv-console-header-left">
                <h1 class="ccv-console-title">Courier Command Center</h1>
                <div class="ccv-console-name">
                    <span class="ccv-console-name-label">Welcome,</span>
                    <span class="ccv-console-name-value"><?php echo esc_html( $display_name ); ?></span>
                </div>
                <div class="ccv-console-meta"></div>
            </div>
            <div class="ccv-console-header-right">
                <div class="ccv-balance-pills">
                    <div class="ccv-balance-pill ccv-balance-pill--green"><div class="ccv-balance-pill-label">Available</div><div class="ccv-balance-pill-value"><span class="ccv-balance-currency"><?php echo esc_html( $balances['currency'] ); ?></span><span class="ccv-balance-amount" id="ccv-balance-available"><?php echo esc_html( number_format_i18n( $balances['available'], 2 ) ); ?></span></div></div>
                    <div class="ccv-balance-pill ccv-balance-pill--yellow"><div class="ccv-balance-pill-label">Clearing</div><div class="ccv-balance-pill-value"><span class="ccv-balance-currency"><?php echo esc_html( $balances['currency'] ); ?></span><span class="ccv-balance-amount" id="ccv-balance-clearing"><?php echo esc_html( number_format_i18n( $balances['clearing'], 2 ) ); ?></span></div></div>
                    <div class="ccv-balance-pill ccv-balance-pill--red"><div class="ccv-balance-pill-label">Held</div><div class="ccv-balance-pill-value"><span class="ccv-balance-currency"><?php echo esc_html( $balances['currency'] ); ?></span><span class="ccv-balance-amount" id="ccv-balance-held"><?php echo esc_html( number_format_i18n( $balances['held'], 2 ) ); ?></span></div></div>
                </div>
                <div class="ccv-payout-actions">
                    <button type="button" class="ccv-btn ccv-btn--primary" id="ccv-btn-payout-scheduled" data-payout-type="scheduled">Schedule Payout</button>
                </div>
            </div>
        </header>

        <div id="ccv-courier-js-meta"
             data-ajax-url="<?php echo esc_url( $bridge_config['ajax_url'] ?? admin_url( 'admin-ajax.php' ) ); ?>"
             data-payout-nonce="<?php echo esc_attr( $bridge_config['nonces']['payout'] ?? '' ); ?>"
             data-start-nonce="<?php echo esc_attr( $bridge_config['nonces']['trip'] ?? '' ); ?>"
             data-settings-nonce="<?php echo esc_attr( $bridge_config['nonces']['settings'] ?? '' ); ?>"
             data-state-nonce="<?php echo esc_attr( $bridge_config['nonces']['state'] ?? '' ); ?>"
             data-heartbeat-nonce="<?php echo esc_attr( $bridge_config['nonces']['heartbeat'] ?? '' ); ?>"
             data-rest-nonce="<?php echo esc_attr( $bridge_config['nonces']['rest'] ?? '' ); ?>"
             data-courier-id="<?php echo esc_attr( $courier_id ); ?>"></div>

        <div class="ccv-console-tabs">
            <button type="button" class="ccv-console-tab ccv-console-tab--active" data-view="today">Today</button>
            <button type="button" class="ccv-console-tab" data-view="map">Map</button>
            <button type="button" class="ccv-console-tab" data-view="earnings">Earnings</button>
            <button type="button" class="ccv-console-tab" data-view="payout-method">Payout Method</button>
            <button type="button" class="ccv-console-tab" data-view="settings">Settings</button>
        </div>

        <div class="ccv-support-call-row">
            <a href="tel:+13474169427" class="ccv-call-btn ccv-call-btn--voice" aria-label="Call Caricove Support">📞</a>
            <a href="https://wa.me/13474169427" class="ccv-call-btn ccv-call-btn--wa" aria-label="WhatsApp Caricove Support" target="_blank" rel="noopener noreferrer">📞</a>
        </div>

        <div class="ccv-console-body" data-view="today">
            <div class="ccv-console-col ccv-console-col--left">
                <div class="ccv-list-header">
                    <div class="ccv-list-header-title">Dispatch</div>
                    <div class="ccv-list-header-sub">Incoming offers, your active assigned trip, and queued follow-up jobs.</div>
                </div>

                <div class="ccv-list-toggle">
                    <button type="button" class="ccv-list-toggle-btn" data-list-target="incoming">Incoming</button>
                    <button type="button" class="ccv-list-toggle-btn ccv-list-toggle-btn--active" data-list-target="assigned">Assigned</button>
                    <button type="button" class="ccv-list-toggle-btn" data-list-target="queued">Queued</button>
                </div>

                <?php foreach ( Caricove_Courier_Console_Jobs::buckets() as $bucket ) : ?>
                    <?php $bucket_jobs = Caricove_Courier_Console_Jobs::get_bucket_jobs( $state, $bucket ); ?>
                    <div class="ccv-job-list ccv-job-list--<?php echo esc_attr( $bucket ); ?><?php echo 'assigned' !== $bucket ? ' ccv-job-list--hidden' : ''; ?>" id="ccv-job-list-<?php echo esc_attr( $bucket ); ?>">
                        <?php if ( ! empty( $bucket_jobs ) ) : ?>
                            <?php foreach ( $bucket_jobs as $job ) : ?>
                                <?php echo Caricove_Courier_Console_Card_Builder::render( $job, $bucket ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                            <?php endforeach; ?>
                        <?php else : ?>
                            <?php echo caricove_courier_console_render_template( 'courier-console-empty.php', array( 'message' => caricove_courier_console_empty_text( $bucket ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="ccv-console-col ccv-console-col--right">
                <div class="ccv-detail-shell" id="ccv-job-detail-shell">
                    <div class="ccv-detail-empty">Your active assigned trip appears here. Incoming offers stay in the left panel until you accept or reject them.</div>
                </div>
            </div>
        </div>

        <div class="ccv-console-body ccv-console-body--hidden" data-view="map">
            <div class="ccv-console-col ccv-console-col--full">
                <div class="ccv-courier-map-shell">
                    <div class="ccv-courier-map-empty" id="ccv-map-empty" hidden>Map unavailable until Google Maps is configured.</div>
                    <div class="ccv-courier-map-panel" id="ccv-map-panel" hidden></div>
                    <div id="ccv-map-canvas"></div>
                </div>
            </div>
        </div>

        <div class="ccv-console-body ccv-console-body--hidden" data-view="earnings">
            <div class="ccv-console-col ccv-console-col--full">
                <div class="ccv-earnings-header"><h2>Earnings Overview</h2></div>
                <div class="ccv-earnings-grid">
                    <div class="ccv-earnings-card"><div class="ccv-earnings-label">Available for Cashout</div><div class="ccv-earnings-value"><span class="ccv-balance-currency"><?php echo esc_html( $balances['currency'] ); ?></span><span class="ccv-earnings-amount" data-bind="available"><?php echo esc_html( number_format_i18n( $balances['available'], 2 ) ); ?></span></div></div>
                    <div class="ccv-earnings-card"><div class="ccv-earnings-label">In Clearing Window</div><div class="ccv-earnings-value"><span class="ccv-balance-currency"><?php echo esc_html( $balances['currency'] ); ?></span><span class="ccv-earnings-amount" data-bind="clearing"><?php echo esc_html( number_format_i18n( $balances['clearing'], 2 ) ); ?></span></div></div>
                    <div class="ccv-earnings-card"><div class="ccv-earnings-label">Temporarily Held</div><div class="ccv-earnings-value"><span class="ccv-balance-currency"><?php echo esc_html( $balances['currency'] ); ?></span><span class="ccv-earnings-amount" data-bind="held"><?php echo esc_html( number_format_i18n( $balances['held'], 2 ) ); ?></span></div></div>
                </div>
                <div class="ccv-earnings-footer"></div>
            </div>
        </div>

        <div class="ccv-console-body ccv-console-body--hidden" data-view="payout-method">
            <div class="ccv-console-col ccv-console-col--full">
                <?php echo $payout_method_markup; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
            </div>
        </div>

        <div class="ccv-console-body ccv-console-body--hidden" data-view="settings">
            <div class="ccv-console-col ccv-console-col--full">
                <?php echo $settings_markup; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
            </div>
        </div>
    </div>

    <?php echo caricove_courier_console_render_template( 'courier-console-payout-modal.php', array( 'balances' => $balances ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
    <?php echo caricove_courier_console_render_template( 'courier-console-code-modal.php' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
    <?php echo caricove_courier_console_render_template( 'courier-console-notes-modal.php' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
</div>
<div class="ccv-modal-backdrop" id="ccv-offer-modal-backdrop" aria-hidden="true"></div>
