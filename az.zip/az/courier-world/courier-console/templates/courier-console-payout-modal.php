<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<div class="ccv-modal-backdrop" id="ccv-payout-modal-backdrop" aria-hidden="true">
    <div class="ccv-modal" role="dialog" aria-modal="true" aria-labelledby="ccv-payout-modal-title">
        <div class="ccv-modal-header">
            <h2 id="ccv-payout-modal-title">Request Payout</h2>
            <button type="button" class="ccv-modal-close" id="ccv-payout-modal-close">&times;</button>
        </div>
        <div class="ccv-modal-body">
            <div class="ccv-modal-row">
                <label for="ccv-payout-amount" class="ccv-modal-label">Amount to cash out</label>
                <div class="ccv-modal-input-wrap">
                    <span class="ccv-modal-currency"><?php echo esc_html( $balances['currency'] ); ?></span>
                    <input type="number" step="0.01" min="0" id="ccv-payout-amount" class="ccv-modal-input" placeholder="0.00" />
                </div>
                <div class="ccv-modal-helper">Available: <span id="ccv-payout-available-display"><?php echo esc_html( number_format_i18n( $balances['available'], 2 ) ); ?></span> <?php echo esc_html( $balances['currency'] ); ?></div>
                <div class="ccv-modal-helper">Destination: <span id="ccv-payout-destination-display">Add payout method first</span></div>
            </div>
            <div class="ccv-modal-row">
                <div class="ccv-modal-label">Payout type</div>
                <div class="ccv-modal-pill-row">
                    <button type="button" class="ccv-pill ccv-pill--active" data-payout-type="scheduled">Standard payout</button>
                </div>
                <div class="ccv-modal-helper" id="ccv-modal-fee-note">Standard courier payout request. Awaiting admin approval.</div>
            </div>
            <div class="ccv-modal-row"><div class="ccv-modal-status" id="ccv-payout-modal-status"></div></div>
        </div>
        <div class="ccv-modal-footer">
            <button type="button" class="ccv-btn ccv-btn--ghost" id="ccv-payout-modal-cancel">Cancel</button>
            <button type="button" class="ccv-btn ccv-btn--primary" id="ccv-payout-modal-submit">Submit Request</button>
        </div>
    </div>
</div>
