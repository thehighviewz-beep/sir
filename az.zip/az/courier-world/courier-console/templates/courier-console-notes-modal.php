<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<div class="ccv-modal-backdrop" id="ccv-notes-modal-backdrop" aria-hidden="true">
    <div class="ccv-modal ccv-notes-modal" role="dialog" aria-modal="true" aria-labelledby="ccv-notes-modal-title">
        <div class="ccv-modal-header">
            <h2 id="ccv-notes-modal-title">Delivery Notes</h2>
            <button type="button" class="ccv-modal-close ccv-notes-modal-close" id="ccv-notes-modal-close">&times;</button>
        </div>
        <div class="ccv-modal-body">
            <div class="ccv-modal-row">
                <div class="ccv-notes-panel" id="ccv-notes-modal-body">No delivery instructions provided.</div>
            </div>
        </div>
    </div>
</div>
