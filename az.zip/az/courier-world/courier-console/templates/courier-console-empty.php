<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<div class="ccv-job-empty"><?php echo esc_html( $message ?? '' ); ?></div>
