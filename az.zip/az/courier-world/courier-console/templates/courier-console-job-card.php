<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$job              = isset( $job ) && is_array( $job ) ? $job : array();
$bucket           = sanitize_key( (string) ( $bucket ?? 'queued' ) );
$id               = (string) ( $job['job_id'] ?? '' );
$label            = (string) ( $job['label'] ?? '' );
$status           = (string) ( $job['status'] ?? '' );
$status_label     = (string) ( $job['status_label'] ?? '' );
$pay_label        = (string) ( $job['pay_label'] ?? '' );
$currency         = (string) ( $job['currency'] ?? 'GYD' );
$pickup_title     = (string) ( $job['pickup_title'] ?? 'Pickup' );
$pickup_text      = (string) ( $job['pickup_text'] ?? '' );
$pickup_city      = (string) ( $job['pickup_city'] ?? '' );
$pickup_name      = (string) ( $job['pickup_name'] ?? '' );
$pickup_phone     = (string) ( $job['pickup_phone'] ?? '' );
$dropoff_title    = (string) ( $job['dropoff_title'] ?? 'Dropoff' );
$dropoff_text     = (string) ( $job['dropoff_text'] ?? '' );
$dropoff_city     = (string) ( $job['dropoff_city'] ?? '' );
$dropoff_name     = (string) ( $job['dropoff_name'] ?? '' );
$dropoff_phone    = (string) ( $job['dropoff_phone'] ?? '' );
$dropoff_instructions = (string) ( $job['dropoff_instructions'] ?? '' );
$delivery_instructions = (string) ( $job['delivery_instructions'] ?? $dropoff_instructions );
$eta_label        = (string) ( $job['eta_label'] ?? '' );
$distance_label   = (string) ( $job['distance_label'] ?? '' );
$deadline_label   = (string) ( $job['deadline_label'] ?? '' );
$deadline_ts      = intval( $job['deadline_ts'] ?? 0 );
$map_url          = (string) ( $job['map_url'] ?? '' );
$nav_url          = (string) ( $job['nav_url'] ?? '' );
$next_state       = (string) ( $job['next_state'] ?? '' );
$next_state_label = (string) ( $job['next_state_label'] ?? '' );
$requires_code    = ! empty( $job['requires_code'] ) ? '1' : '0';
$phase            = (string) ( $job['phase'] ?? 'to_pickup' );
$pickup_lat       = (string) ( $job['pickup_lat'] ?? '' );
$pickup_lng       = (string) ( $job['pickup_lng'] ?? '' );
$dropoff_lat      = (string) ( $job['dropoff_lat'] ?? '' );
$dropoff_lng      = (string) ( $job['dropoff_lng'] ?? '' );
$mission_id       = (string) ( $job['mission_id'] ?? '' );
$mission_seq      = intval( $job['mission_seq'] ?? 0 );
$offer_created_at = intval( $job['offer_created_at'] ?? 0 );
$offer_expires_at = intval( $job['offer_expires_at'] ?? 0 );
$offer_response_window = intval( $job['offer_response_window'] ?? 0 );
$offer_seconds_left = intval( $job['offer_seconds_left'] ?? 0 );
$offer_is_live    = ! empty( $job['offer_is_live'] );
$courier_lat      = (string) ( $job['courier_lat'] ?? '' );
$courier_lng      = (string) ( $job['courier_lng'] ?? '' );
$courier_vehicle_type = (string) ( $job['courier_vehicle_type'] ?? '' );
$distance_band    = (string) ( $job['distance_band'] ?? '' );
$quote_total_gyd  = (float) ( $job['quote_total_gyd'] ?? 0 );

$from_area     = $pickup_city ? $pickup_city : $pickup_text;
$to_area       = $dropoff_city ? $dropoff_city : $dropoff_text;
$route_summary = $from_area && $to_area ? $from_area . ' → ' . $to_area : ( $from_area ?: $to_area );
$time_chip     = $deadline_label ? $deadline_label : $eta_label;
if ( $offer_is_live && $offer_seconds_left > 0 ) {
    $time_chip = 'Respond in ' . intval( $offer_seconds_left ) . 's';
}
?>
<article class="ccv-job-card ccv-job-card--active"
         data-job-id="<?php echo esc_attr( $id ); ?>"
         data-job-label="<?php echo esc_attr( $label ); ?>"
         data-job-status="<?php echo esc_attr( $status ); ?>"
         data-job-status-label="<?php echo esc_attr( $status_label ); ?>"
         data-job-pay="<?php echo esc_attr( $pay_label ); ?>"
         data-job-currency="<?php echo esc_attr( $currency ); ?>"
         data-pickup-title="<?php echo esc_attr( $pickup_title ); ?>"
         data-pickup-text="<?php echo esc_attr( $pickup_text ); ?>"
         data-pickup-city="<?php echo esc_attr( $pickup_city ); ?>"
         data-pickup-name="<?php echo esc_attr( $pickup_name ); ?>"
         data-pickup-phone="<?php echo esc_attr( $pickup_phone ); ?>"
         data-dropoff-title="<?php echo esc_attr( $dropoff_title ); ?>"
         data-dropoff-text="<?php echo esc_attr( $dropoff_text ); ?>"
         data-dropoff-city="<?php echo esc_attr( $dropoff_city ); ?>"
         data-dropoff-name="<?php echo esc_attr( $dropoff_name ); ?>"
         data-dropoff-phone="<?php echo esc_attr( $dropoff_phone ); ?>"
         data-dropoff-instructions="<?php echo esc_attr( $dropoff_instructions ); ?>"
         data-delivery-instructions="<?php echo esc_attr( $delivery_instructions ); ?>"
         data-eta-label="<?php echo esc_attr( $eta_label ); ?>"
         data-distance-label="<?php echo esc_attr( $distance_label ); ?>"
         data-deadline-label="<?php echo esc_attr( $deadline_label ); ?>"
         data-deadline-ts="<?php echo esc_attr( $deadline_ts ); ?>"
         data-map-url="<?php echo esc_url( $map_url ); ?>"
         data-nav-url="<?php echo esc_url( $nav_url ); ?>"
         data-next-state="<?php echo esc_attr( $next_state ); ?>"
         data-next-state-label="<?php echo esc_attr( $next_state_label ); ?>"
         data-requires-code="<?php echo esc_attr( $requires_code ); ?>"
         data-phase="<?php echo esc_attr( $phase ); ?>"
         data-pickup-lat="<?php echo esc_attr( $pickup_lat ); ?>"
         data-pickup-lng="<?php echo esc_attr( $pickup_lng ); ?>"
         data-dropoff-lat="<?php echo esc_attr( $dropoff_lat ); ?>"
         data-dropoff-lng="<?php echo esc_attr( $dropoff_lng ); ?>"
         data-mission-id="<?php echo esc_attr( $mission_id ); ?>"
         data-mission-seq="<?php echo esc_attr( $mission_seq ); ?>"
         data-queue-bucket="<?php echo esc_attr( $bucket ); ?>"
         data-offer-created-at="<?php echo esc_attr( $offer_created_at ); ?>"
         data-offer-expires-at="<?php echo esc_attr( $offer_expires_at ); ?>"
         data-offer-response-window="<?php echo esc_attr( $offer_response_window ); ?>"
         data-offer-seconds-left="<?php echo esc_attr( $offer_seconds_left ); ?>"
         data-offer-live="<?php echo esc_attr( $offer_is_live ? '1' : '0' ); ?>"
         data-courier-lat="<?php echo esc_attr( $courier_lat ); ?>"
         data-courier-lng="<?php echo esc_attr( $courier_lng ); ?>"
         data-courier-vehicle-type="<?php echo esc_attr( $courier_vehicle_type ); ?>"
         data-distance-band="<?php echo esc_attr( $distance_band ); ?>"
         data-quote-total-gyd="<?php echo esc_attr( $quote_total_gyd ); ?>">
    <div class="ccv-job-card-row ccv-job-card-row--thin-top">
        <div class="ccv-job-card-label"><?php echo esc_html( $label ); ?></div>
        <?php if ( $status_label ) : ?>
            <div class="ccv-job-card-state"><?php echo esc_html( $status_label ); ?></div>
        <?php endif; ?>
    </div>
    <div class="ccv-job-card-row ccv-job-card-row--thin-middle">
        <?php if ( $route_summary ) : ?>
            <div class="ccv-job-card-route"><?php echo esc_html( $route_summary ); ?></div>
        <?php endif; ?>
    </div>
    <div class="ccv-job-card-row ccv-job-card-row--thin-bottom">
        <div class="ccv-job-card-meta">
            <?php if ( $time_chip ) : ?>
                <span class="ccv-job-pill ccv-job-pill--time"><?php echo esc_html( $time_chip ); ?></span>
            <?php endif; ?>
            <?php if ( $distance_label ) : ?>
                <span class="ccv-job-pill ccv-job-pill--distance"><?php echo esc_html( $distance_label ); ?></span>
            <?php endif; ?>
        </div>
        <div class="ccv-job-card-pay">
            <span class="ccv-job-pay-currency"><?php echo esc_html( $currency ); ?></span>
            <span class="ccv-job-pay-amount"><?php echo esc_html( $pay_label ); ?></span>
        </div>
    </div>
</article>
