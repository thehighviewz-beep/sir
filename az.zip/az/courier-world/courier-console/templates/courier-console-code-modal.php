<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<div class="ccv-modal-backdrop" id="ccv-code-modal-backdrop" aria-hidden="true">
    <div class="ccv-modal" role="dialog" aria-modal="true" aria-labelledby="ccv-code-modal-title">
        <div class="ccv-modal-header">
            <h2 id="ccv-code-modal-title">Enter Delivery Code</h2>
            <button type="button" class="ccv-modal-close" id="ccv-code-modal-close">&times;</button>
        </div>
        <div class="ccv-modal-body">
            <div class="ccv-modal-row">
                <label for="ccv-code-input" class="ccv-modal-label">Ask the customer for the delivery code and enter it below.</label>
                <div class="ccv-modal-input-wrap">
                    <input type="text" id="ccv-code-input" class="ccv-modal-input" inputmode="numeric" autocomplete="one-time-code" placeholder="4–6 digit code" />
                </div>
                <div class="ccv-modal-helper">This confirms that the parcel reached the correct person.</div>
            </div>
            <div class="ccv-modal-row"><div class="ccv-modal-status" id="ccv-code-modal-status"></div></div>
        </div>
        <div class="ccv-modal-footer">
            <button type="button" class="ccv-btn ccv-btn--ghost" id="ccv-code-modal-cancel">Cancel</button>
            <button type="button" class="ccv-btn ccv-btn--primary" id="ccv-code-modal-submit">Confirm Status</button>
        </div>
    </div>
</div>
