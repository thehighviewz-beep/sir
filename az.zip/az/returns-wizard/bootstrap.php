<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * ============================================================
 * HARD SYNC BRIDGE (NO schema/hook deviations)
 * ============================================================
 */

/** Order metas (KEEP EXACT) */
if ( ! defined( 'CC_RETURNS_META_LAST_SUMMARY' ) ) define( 'CC_RETURNS_META_LAST_SUMMARY', '_caricove_last_refund_summary' );
if ( ! defined( 'CC_RETURNS_META_CASES' ) )        define( 'CC_RETURNS_META_CASES', '_caricove_return_cases' );

/** Per-line prefix (KEEP EXACT) */
if ( ! defined( 'CC_RETURNS_ITEM_META_PREFIX' ) )  define( 'CC_RETURNS_ITEM_META_PREFIX', '_caricove_' );

/** Hook name (KEEP EXACT) */
if ( ! defined( 'CC_RETURNS_HOOK_RETURN_CASES' ) ) define( 'CC_RETURNS_HOOK_RETURN_CASES', 'caricove_returns_wizard_return_cases' );

/** Helper fallbacks (only if your helpers.php wasn’t loaded yet) */
if ( ! function_exists( 'ccr_has_woo' ) ) {
    function ccr_has_woo() {
        return class_exists( 'WooCommerce' ) && function_exists( 'wc_get_order' );
    }
}
if ( ! function_exists( 'ccr_safe_array' ) ) {
    function ccr_safe_array( $v ) { return is_array( $v ) ? $v : []; }
}
if ( ! function_exists( 'ccr_money_plain' ) ) {
    function ccr_money_plain( $amount ) {
        $amount = (float) $amount;
        if ( ! ccr_has_woo() ) return number_format_i18n( $amount, 2 );
        $raw = wc_price( $amount );
        return html_entity_decode( wp_strip_all_tags( (string) $raw ), ENT_QUOTES, 'UTF-8' );
    }
}
