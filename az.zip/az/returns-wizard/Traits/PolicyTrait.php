<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

trait Caricove_Returns_Wizard_Policy_Trait {

    protected function get_low_value_threshold() {
        return 800.0;
    }

    protected function get_low_value_refund_limit() {
        return [
            'limit' => 2,
            'days'  => 60,
        ];
    }

    protected function get_low_value_refund_lifetime_limit() {
        return 5;
    }

    protected function get_non_delivery_grace_days() {
        return 5;
    }

    protected function get_high_value_delivery_review_threshold() {
        // Never-arrived should only be refund-only when the item is low value.
        return (float) $this->get_low_value_threshold();
    }

    protected function get_low_value_refund_reason_codes() {
       return [
    'ordered_by_mistake',
    'found_better_price',
    'no_longer_needed',
    'not_as_expected',
    'damaged_or_defective',
    'wrong_item_received',
    'missing_parts',
];
    }

    protected function get_refund_reason_matrix() {
        return [
            'ordered_by_mistake' => [
                'label'               => __( 'Ordered by mistake', 'caricove' ),
                'fault'               => 'customer',
                'return_required'     => true,
                'use_category_window' => true,
                'requires_evidence'   => false,
            ],
            'found_better_price' => [
                'label'               => __( 'Found a better price', 'caricove' ),
                'fault'               => 'customer',
                'return_required'     => true,
                'use_category_window' => true,
                'requires_evidence'   => false,
            ],
            'no_longer_needed' => [
                'label'               => __( 'Item no longer needed', 'caricove' ),
                'fault'               => 'customer',
                'return_required'     => true,
                'use_category_window' => true,
                'requires_evidence'   => false,
            ],
            'not_as_expected' => [
                'label'               => __( 'Item not as expected', 'caricove' ),
                'fault'               => 'mixed',
                'return_required'     => true,
                'use_category_window' => true,
                'requires_evidence'   => true,
                'manual_review'       => false,
            ],
            'damaged_or_defective' => [
                'label'               => __( 'Damaged or defective', 'caricove' ),
                'fault'               => 'seller',
                'return_required'     => true,
                'use_category_window' => true,
                'requires_evidence'   => false,
            ],
            'never_arrived' => [
                'label'               => __( 'Item never arrived', 'caricove' ),
                'fault'               => 'carrier',
                'return_required'     => false,
                'return_window_days'  => 0,
                'requires_evidence'   => false,
                'immediate_refund'    => true,
            ],
            'wrong_item_received' => [
                'label'               => __( 'Wrong item received', 'caricove' ),
                'fault'               => 'seller',
                'return_required'     => true,
                'use_category_window' => true,
                'requires_evidence'   => false,
            ],
            'missing_parts' => [
                'label'               => __( 'Missing parts or accessories', 'caricove' ),
                'fault'               => 'seller',
                'return_required'     => true,
                'use_category_window' => true,
                'requires_evidence'   => false,
            ],
        ];
    }

    protected function get_cancel_reason_matrix() {
        return [
            'cancel_ordered_by_mistake' => [
                'label' => __( 'Ordered by mistake', 'caricove' ),
                'fault' => 'customer',
            ],
            'cancel_found_better_price' => [
                'label' => __( 'Found a better price', 'caricove' ),
                'fault' => 'customer',
            ],
            'cancel_no_longer_needed' => [
                'label' => __( 'No longer needed', 'caricove' ),
                'fault' => 'customer',
            ],
            'cancel_address_change' => [
                'label' => __( 'Need to change delivery address', 'caricove' ),
                'fault' => 'customer',
            ],
            'cancel_payment_issue' => [
                'label' => __( 'Payment method issue', 'caricove' ),
                'fault' => 'customer',
            ],
        ];
    }

    protected function get_item_return_window_days( WC_Order_Item_Product $item, $reason = '' ) {
        $reason = strtolower( trim( (string) $reason ) );

        if ( in_array( $reason, [ 'damaged_or_defective', 'wrong_item_received', 'not_as_expected' ], true ) ) {
            return 21;
        }

        if ( $reason === 'missing_parts' ) {
            return 14;
        }

        if ( $reason === 'never_arrived' ) {
            return 0;
        }

        if ( ! function_exists( 'wc_get_product_terms' ) ) {
            return 10;
        }

        $product     = $item->get_product();
        $product_ids = [];

        if ( $product && is_object( $product ) ) {
            $product_id = (int) $product->get_id();
            if ( $product_id > 0 ) {
                $product_ids[] = $product_id;
            }

            if ( method_exists( $product, 'get_parent_id' ) ) {
                $parent_id = (int) $product->get_parent_id();
                if ( $parent_id > 0 ) {
                    $product_ids[] = $parent_id;
                }
            }
        }

        $line_product_id = (int) $item->get_product_id();
        if ( $line_product_id > 0 ) {
            $product_ids[] = $line_product_id;
        }

        if ( method_exists( $item, 'get_variation_id' ) ) {
            $variation_id = (int) $item->get_variation_id();
            if ( $variation_id > 0 ) {
                $product_ids[] = $variation_id;
            }
        }

        $product_ids = array_values( array_unique( array_filter( array_map( 'absint', $product_ids ) ) ) );
        $needles     = [];

        foreach ( $product_ids as $product_id ) {
            $terms = wc_get_product_terms( $product_id, 'product_cat', [ 'fields' => 'all' ] );

            foreach ( (array) $terms as $term ) {
                if ( ! is_object( $term ) || empty( $term->term_id ) ) {
                    continue;
                }

                $needles[] = sanitize_title( (string) $term->slug );
                $needles[] = sanitize_title( (string) $term->name );

                if ( function_exists( 'get_ancestors' ) && function_exists( 'get_term' ) ) {
                    $ancestor_ids = get_ancestors( (int) $term->term_id, 'product_cat', 'taxonomy' );
                    foreach ( (array) $ancestor_ids as $ancestor_id ) {
                        $ancestor = get_term( (int) $ancestor_id, 'product_cat' );
                        if ( $ancestor && ! is_wp_error( $ancestor ) ) {
                            $needles[] = sanitize_title( (string) $ancestor->slug );
                            $needles[] = sanitize_title( (string) $ancestor->name );
                        }
                    }
                }
            }
        }

        $needles = array_values( array_unique( array_filter( $needles ) ) );

        if ( array_intersect( $needles, [ 'electronics', 'electronic', 'phones', 'phone', 'computers', 'computer' ] ) ) {
            return 7;
        }

        if ( array_intersect( $needles, [ 'fashion', 'clothing', 'clothes', 'apparel', 'shoes', 'shoe', 'footwear', 'bags', 'bag', 'accessories', 'accessory' ] ) ) {
            return 14;
        }

        return 10;
    }

    protected function get_case_history_customer_keys( WC_Order $order ) {
        $keys = [];

        $customer_id = (int) $order->get_customer_id();
        if ( $customer_id <= 0 ) {
            $customer_id = (int) get_current_user_id();
        }
        if ( $customer_id > 0 ) {
            $keys['customer_id'] = $customer_id;
        }

        $email = '';
        if ( method_exists( $order, 'get_billing_email' ) ) {
            $email = sanitize_email( (string) $order->get_billing_email() );
        }
        if ( ! $email && is_user_logged_in() ) {
            $user = wp_get_current_user();
            if ( $user && ! empty( $user->user_email ) ) {
                $email = sanitize_email( (string) $user->user_email );
            }
        }
        if ( $email ) {
            $keys['billing_email'] = $email;
        }

        return $keys;
    }

    protected function get_returns_meta_key() {
        return defined( 'CC_RETURNS_META_CASES' ) ? CC_RETURNS_META_CASES : '_caricove_return_cases';
    }

    protected function get_order_cases_for_history( $order_or_id ) {
        $order = $order_or_id instanceof WC_Order ? $order_or_id : wc_get_order( $order_or_id );
        if ( ! $order ) {
            return [];
        }

        $meta_key = $this->get_returns_meta_key();
        $cases    = [];

        if ( method_exists( $this, 'order_get_meta' ) ) {
            $cases = $this->order_get_meta( $order, $meta_key );
        }

        if ( ! is_array( $cases ) ) {
            if ( method_exists( $order, 'get_meta' ) ) {
                $cases = $order->get_meta( $meta_key, true );
            } else {
                $cases = get_post_meta( $order->get_id(), $meta_key, true );
            }
        }

        return is_array( $cases ) ? $cases : [];
    }

   protected function case_requires_return( array $case ) {
    $case_type = strtolower( trim( (string) ( $case['case_type'] ?? '' ) ) );
    if ( $case_type === 'cancellation' ) {
        return false;
    }

    $mode = strtolower( trim( (string) ( $case['refund_execution_mode'] ?? '' ) ) );
    if ( in_array( $mode, [ 'returnless', 'never_received' ], true ) ) {
        return false;
    }

    if ( ! empty( $case['low_value_refund_only'] ) ) {
        return false;
    }

    $decision_code = strtolower( (string) ( $case['decision_code'] ?? '' ) );
    if ( in_array( $decision_code, [ 'refund_only', 'refund_immediate' ], true ) ) {
        return false;
    }

    $rr = $case['return_required'] ?? true;

    if ( is_bool( $rr ) ) {
        return $rr;
    }

    if ( is_numeric( $rr ) ) {
        return ( (int) $rr === 1 );
    }

    $rr = strtolower( trim( (string) $rr ) );

    if ( $rr === '' ) {
        return false;
    }

    return in_array( $rr, [ '1', 'true', 'yes', 'y', 'required' ], true );
}

    protected function count_recent_customer_return_cases( WC_Order $order, array $reason_codes, $days = 60, $require_no_return = false ) {
        if ( ! function_exists( 'wc_get_orders' ) ) {
            return 0;
        }

        $keys   = $this->get_case_history_customer_keys( $order );
        $cutoff = time() - ( absint( $days ) * DAY_IN_SECONDS );
        $ids    = [];

        if ( ! empty( $keys['customer_id'] ) ) {
            $found = wc_get_orders( [
                'customer_id' => (int) $keys['customer_id'],
                'limit'       => -1,
                'return'      => 'ids',
                'orderby'     => 'date',
                'order'       => 'DESC',
            ] );
            foreach ( (array) $found as $oid ) {
                $ids[ (int) $oid ] = true;
            }
        }

        if ( ! empty( $keys['billing_email'] ) ) {
            $found = wc_get_orders( [
                'billing_email' => (string) $keys['billing_email'],
                'limit'         => -1,
                'return'        => 'ids',
                'orderby'       => 'date',
                'order'         => 'DESC',
            ] );
            foreach ( (array) $found as $oid ) {
                $ids[ (int) $oid ] = true;
            }
        }

        $ids[ (int) $order->get_id() ] = true;
        $parent_id = (int) $order->get_parent_id();
        if ( $parent_id > 0 ) {
            $ids[ $parent_id ] = true;
        }

        $seen_rmas = [];
        $count     = 0;

        foreach ( array_keys( $ids ) as $order_id ) {
            $cases = $this->get_order_cases_for_history( $order_id );
            if ( ! is_array( $cases ) || empty( $cases ) ) {
                continue;
            }

            foreach ( $cases as $case ) {
                if ( ! is_array( $case ) ) {
                    continue;
                }

                $case_type = strtolower( (string) ( $case['case_type'] ?? 'return' ) );
                if ( $case_type !== 'return' ) {
                    continue;
                }

                $reason_code = (string) ( $case['reason_code'] ?? '' );
                if ( ! in_array( $reason_code, $reason_codes, true ) ) {
                    continue;
                }

                $status = strtolower( trim( (string) ( $case['status'] ?? '' ) ) );
                if ( in_array( $status, [ 'denied', 'cancelled', 'closed' ], true ) ) {
                    continue;
                }

                $created = (int) ( $case['created'] ?? 0 );
                if ( $created > 0 && $created < $cutoff ) {
                    continue;
                }

                if ( $require_no_return && $this->case_requires_return( $case ) ) {
                    continue;
                }

                $case_key = trim( (string) ( $case['rma_id'] ?? ( $case['case_id'] ?? '' ) ) );
                if ( $case_key === '' ) {
                    $case_order_id = (int) ( $case['order_id'] ?? $order_id );
                    $case_item_id  = (int) ( $case['order_item_id'] ?? $case['item_id'] ?? 0 );
                    $case_created  = (int) ( $case['created'] ?? 0 );
                    $case_key = 'CASE-' . $case_order_id . '-' . $case_item_id . '-' . $case_created;
                }

                if ( isset( $seen_rmas[ $case_key ] ) ) {
                    continue;
                }
                $seen_rmas[ $case_key ] = true;

                $count++;
            }
        }

        return (int) $count;
    }

  protected function evaluate_return_policy( WC_Order $order, WC_Order_Item_Product $item, $reason, $qty_req, $per_unit_gross, $delivered_truth, $request_total_gross = 0.0, $current_submit_reserved = 0 ) {
        $matrix         = $this->get_refund_reason_matrix();
        $threshold      = (float) $this->get_low_value_threshold();
        $limit          = $this->get_low_value_refund_limit();
        $lifetime_limit = (int) $this->get_low_value_refund_lifetime_limit();

        if ( empty( $matrix[ $reason ] ) ) {
            return [
                'blocked'    => true,
                'error_code' => 'request_unavailable',
                'error'      => __( 'This request cannot be processed automatically.', 'caricove' ),
            ];
        }

       $row              = $matrix[ $reason ];
        $fault            = (string) ( $row['fault'] ?? 'customer' );
        $window_days      = isset( $row['return_window_days'] )
            ? (int) $row['return_window_days']
            : (int) $this->get_item_return_window_days( $item, $reason );
        $request_total_gross = max( 0.0, (float) $request_total_gross );
        $is_low_value     = ( $request_total_gross > 0 && $request_total_gross <= $threshold );
        $is_never_arrived = ( $reason === 'never_arrived' );
        $is_cx_fault      = ( $fault === 'customer' );
        $is_non_cx_fault  = ! $is_cx_fault && ! $is_never_arrived;

      $global_low_value_recent   = 0;
        $global_low_value_lifetime = 0;
        $current_submit_reserved   = max( 0, (int) $current_submit_reserved );

        // Canonical rule: once returnless cap is exhausted, any non-CX fault
        // should go through the same Need More Info route first, regardless of value.
        if ( $is_non_cx_fault ) {
            $all_low_value_reasons     = $this->get_low_value_refund_reason_codes();
            $global_low_value_recent   = (int) $this->count_recent_customer_return_cases( $order, $all_low_value_reasons, (int) $limit['days'], true );
            $global_low_value_lifetime = (int) $this->count_recent_customer_return_cases( $order, $all_low_value_reasons, 36500, true );

            // Reserve already-approved returnless items from this same submit so
            // batch submissions cannot bypass the 2-in-60 / 5-lifetime caps.
            $global_low_value_recent   += $current_submit_reserved;
            $global_low_value_lifetime += $current_submit_reserved;
        }
        
       if ( $is_never_arrived ) {
            return [
                'fault'                 => 'carrier',
                'window_days'           => 0,
                'return_required'       => false,
                'decision_code'         => 'MORE_INFO_REQUIRED',
                'refund_timing'         => 'after_review',
                'shipping_payer'        => 'platform',
                'requires_evidence'     => false,
                'low_value_refund_only' => false,
                'manual_review'         => true,
            ];
        }

        $caps_exhausted = false;
        if ( $is_non_cx_fault ) {
            $caps_exhausted = ( $global_low_value_recent >= (int) $limit['limit'] ) || ( $global_low_value_lifetime >= $lifetime_limit );
        }

        $shipping_payer_return = 'customer';
        if ( $is_non_cx_fault ) {
            $shipping_payer_return = 'vendor';
        }

        if ( $is_cx_fault ) {
            return [
                'fault'                 => $fault,
                'window_days'           => $window_days,
                'return_required'       => true,
                'decision_code'         => 'RETURN_REQUIRED',
                'refund_timing'         => 'after_inspection',
                'shipping_payer'        => 'customer',
                'requires_evidence'     => false,
                'low_value_refund_only' => false,
                'manual_review'         => false,
            ];
        }

        // Non-CX reasons:
        // - under 800 + cap available => returnless
        // - otherwise => same Need More Info / review-first route as never arrived
        if ( $is_non_cx_fault ) {
            if ( $is_low_value && ! $caps_exhausted ) {
                return [
                    'fault'                 => $fault,
                    'window_days'           => $window_days,
                    'return_required'       => false,
                    'decision_code'         => 'REFUND_ONLY',
                    'refund_timing'         => 'immediate',
                    'shipping_payer'        => 'vendor',
                    'requires_evidence'     => ! empty( $row['requires_evidence'] ),
                    'low_value_refund_only' => true,
                    'manual_review'         => false,
                ];
            }

            return [
                'fault'                 => $fault,
                'window_days'           => $window_days,
                'return_required'       => true,
                'decision_code'         => 'MORE_INFO_REQUIRED',
                'refund_timing'         => 'after_review',
                'shipping_payer'        => $shipping_payer_return,
                'requires_evidence'     => ! empty( $row['requires_evidence'] ),
                'low_value_refund_only' => false,
                'manual_review'         => true,
            ];
        }

        return [
            'fault'                 => $fault,
            'window_days'           => $window_days,
            'return_required'       => true,
            'decision_code'         => 'RETURN_REQUIRED',
            'refund_timing'         => 'after_inspection',
            'shipping_payer'        => $shipping_payer_return,
            'requires_evidence'     => ! empty( $row['requires_evidence'] ),
            'low_value_refund_only' => false,
            'manual_review'         => false,
        ];
  }
        
    protected function get_decision_ui( $decision_code, array $case = [] ) {
        $shipping_payer = (string) ( $case['shipping_payer'] ?? 'platform' );

        $map = [
            'REFUND_ONLY' => [
                'badge' => __( 'Refund Issued', 'caricove' ),
                'tone'  => 'green',
                'body'  => __( 'We’re sorry this item didn’t meet your expectations.', 'caricove' ),
                'next'  => __( 'Your refund will be processed shortly and there is no need to return the item.', 'caricove' ),
            ],
            'REFUND_IMMEDIATE' => [
                'badge' => __( 'Refund Issued', 'caricove' ),
                'tone'  => 'green',
                'body'  => __( 'Your order experienced a delivery issue.', 'caricove' ),
                'next'  => __( 'Your refund will be processed shortly and there is no need to return the item.', 'caricove' ),
            ],
            'RETURN_REQUIRED' => [
                'badge' => __( 'Return Accepted', 'caricove' ),
                'tone'  => 'blue',
                'body'  => __( 'Please follow the return instructions below to complete your return.', 'caricove' ),
                'next'  => $shipping_payer === 'vendor'
                    ? __( 'Return shipping is covered. Your refund will be issued once the item is received.', 'caricove' )
                    : __( 'Please prepare the item for return. Your refund will be issued once the item is received.', 'caricove' ),
            ],
            'MORE_INFO_REQUIRED' => [
                'badge' => __( 'Request Under Review', 'caricove' ),
                'tone'  => 'orange',
                'body'  => __( 'We need a bit more information before this request can move forward.', 'caricove' ),
                'next'  => __( 'Please contact us using the Get Support button in your orders and reference the order number, item, and issue.', 'caricove' ),
            ],
            'REQUEST_ACCEPTED' => [
                'badge' => __( 'Request Received', 'caricove' ),
                'tone'  => 'purple',
                'body'  => __( 'Your request has been received.', 'caricove' ),
                'next'  => __( 'We will keep you updated here.', 'caricove' ),
            ],
        ];

        return $map[ $decision_code ] ?? $map['REQUEST_ACCEPTED'];
    }

    protected function case_is_closed( $status ) {
        $status = (string) $status;
        return in_array( $status, [ 'denied', 'cancelled', 'closed', 'refunded' ], true );
    }

    protected function get_item_remaining_requestable_qty( WC_Order $order, $item_id, $ordered_qty ) {
        $ordered_qty = (int) $ordered_qty;
        if ( $ordered_qty <= 0 ) return 0;

        $existing_cases = $this->get_existing_cases_bundle( $order );

        foreach ( $existing_cases as $c ) {
            if ( ! is_array( $c ) ) continue;
            if ( (int) ( $c['item_id'] ?? 0 ) !== (int) $item_id ) continue;

            $ctype = strtolower( (string) ( $c['case_type'] ?? '' ) );
            $st    = strtolower( trim( (string) ( $c['status'] ?? '' ) ) );

            if ( $ctype === 'cancellation' && $st === 'cancelled' ) {
                return 0;
            }

            if ( ! $this->case_is_closed( $st ) ) {
                return 0;
            }
        }

        return $ordered_qty;
    }

    protected function throttle_key( $order_id, $user_id ) {
        return 'ccr_wiz_throttle_' . absint( $order_id ) . '_' . absint( $user_id );
    }
}