<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }


trait Caricove_Returns_Wizard_Render_Trait {

public function shortcode() {
    if ( ! $this->has_woo() ) {
        return '<div class="ccc-returns-wizard ccv3"><div class="notice notice-error"><strong>WooCommerce required.</strong></div></div>';
    }


    $order = $this->get_order_from_request();







    if ( ! $order ) {
        return '<div class="ccc-returns-wizard ccv3"><div class="notice notice-error"><strong>Order not found or access denied.</strong></div></div>';
    }

    $message = '';
    if ( 'POST' === $_SERVER['REQUEST_METHOD'] && isset( $_POST['caricove_returns_wizard_nonce'] ) ) {
        $result = $this->handle_post( $order );

        if ( is_wp_error( $result ) ) {
            $message = '<div class="notice notice-error"><strong>' . esc_html( $result->get_error_message() ) . '</strong></div>';
        } else {
            // handle_post now returns an array for success.
            $mode = is_array( $result ) ? (string) ( $result['mode'] ?? '' ) : '';
            if ( $mode === 'cancel' ) {
                $refund_id = is_array( $result ) ? (int) ( $result['refund_id'] ?? 0 ) : 0;
                $gateway   = is_array( $result ) ? (int) ( $result['refund_payment'] ?? 0 ) : 0;

                $msg = $gateway
                    ? __( 'Cancellation applied immediately. Your payment refund was initiated.', 'caricove' )
                    : __( 'Cancellation applied immediately. A refund record was created (manual / non-gateway).', 'caricove' );

                if ( $refund_id > 0 ) {
                    $msg .= ' ' . sprintf( __( 'Refund record: #%d', 'caricove' ), $refund_id );
                }

                $message = '<div class="notice notice-success"><strong>' . esc_html( $msg ) . '</strong></div>';
            } else {
                $message = '<div class="notice notice-success"><strong>' . esc_html__( 'Your request has been submitted. Check the update card below for the next step.', 'caricove' ) . '</strong></div>';
            }
        }
    }

    ob_start();
    echo '<div class="ccc-returns-wizard ccv3">';
    echo $message; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    $this->render_form( $order );
    echo '</div>';
    return ob_get_clean();
}





    /* ------------------------ Rendering (skin preserved) ------------------------ */

    protected function render_return_instructions_card( WC_Order $order, $summary ) {
        if ( empty( $summary['return_cases'] ) || ! is_array( $summary['return_cases'] ) ) return;

        $cases = $summary['return_cases'];

     $actionable_statuses = apply_filters(
'caricove_returns_instructions_statuses',
[
    'requested',
    'request',
    'pending',
    'pending_review',
    'info_requested',
    'under_review',
    'approved',
    'awaiting_return',
    'awaiting_return_pickup',
    'return_in_transit',
    'in_transit',
    'received',
]
);
        $eligible = [];

        foreach ( $cases as $case ) {
            if ( ! is_array( $case ) ) continue;

            // Do not show instructions for cancellations.
            $ctype = strtolower( (string) ( $case['case_type'] ?? '' ) );
            if ( $ctype === 'cancellation' ) continue;

            $status = strtolower( trim( (string) ( $case['status'] ?? '' ) ) );
            if ( $status && $this->case_is_closed( $status ) ) continue;

        $decision_code = strtoupper( trim( (string) ( $case['decision_code'] ?? '' ) ) );
            $manual_review = ! empty( $case['manual_review'] );
            $status        = strtolower( trim( (string) ( $case['status'] ?? '' ) ) );

            if ( $manual_review || $decision_code === 'MORE_INFO_REQUIRED' ) {
                if ( $status === '' || in_array( $status, [ 'requested', 'request', 'pending', 'pending_review', 'info_requested', 'under_review', 'admin_review', 'escalated' ], true ) ) {
                    continue;
                }
            }

            $requires_return = $this->case_requires_return( $case );
            if ( ! $requires_return ) continue;

            if ( is_array( $actionable_statuses ) && ! empty( $actionable_statuses ) ) {
                if ( $status && ! in_array( $status, $actionable_statuses, true ) ) {
                    continue;
                }
            }

            $eligible[] = $case;
        }

        if ( empty( $eligible ) ) return;

        $groups = [];
        foreach ( $eligible as $case ) {
            $vendor_id = isset( $case['vendor_id'] ) ? (int) $case['vendor_id'] : 0;

            if ( ! isset( $groups[ $vendor_id ] ) ) {
                $groups[ $vendor_id ] = [
                    'vendor_id'      => $vendor_id,
                    'vendor_name'    => isset( $case['vendor_name'] ) ? (string) $case['vendor_name'] : '',
                    'return_address' => isset( $case['return_address'] ) ? (string) $case['return_address'] : '',
                    'cases'          => [],
                ];
            }
            $groups[ $vendor_id ]['cases'][] = $case;
        }

        if ( empty( $groups ) ) return;
        ?>
        <div class="card cc-return-instructions-card" data-cc-return-instructions="1">
            <div class="card-header cc-return-instructions-toggle" role="button" tabindex="0" aria-expanded="true" aria-controls="cc-return-instructions-body">
                <div class="card-title"><?php esc_html_e( 'Return instructions', 'caricove' ); ?></div>
                <div class="card-sub">
                    <?php esc_html_e( 'Some items require a physical return. Follow the instructions below to complete your return.', 'caricove' ); ?>
                </div>
            </div>

            <div id="cc-return-instructions-body" class="cc-return-instructions-body">
                <div class="small" style="margin-bottom:6px;">
                    <?php esc_html_e( 'Include your order number with the item so the return can be identified correctly.', 'caricove' ); ?>
                </div>

                <?php foreach ( $groups as $vendor_id => $group ) : ?>
                    <?php
                    $address = $group['return_address'];
                    if ( ! $address ) $address = $this->get_return_address_for_vendor( $vendor_id );

                    ?>

                    <?php if ( $address ) : ?>
                        <div class="small" style="margin-bottom:4px; margin-top:8px;"><strong><?php esc_html_e( 'Return address:', 'caricove' ); ?></strong><br>
<?php echo nl2br( esc_html( $address ) ); ?>                    </div>
                    <?php endif; ?>

                    <div class="small" style="margin-bottom:6px;">
                        <?php foreach ( $group['cases'] as $case ) :
                            $deadline_text = '';
                            if ( ! empty( $case['deadline'] ) && is_numeric( $case['deadline'] ) ) {
                                $deadline_text = date_i18n( get_option( 'date_format' ), (int) $case['deadline'] );
                            }
                            ?>
                            <div style="margin-bottom:4px;">
                                <strong><?php echo esc_html( (string) ( $case['rma_id'] ?? '' ) ); ?></strong> –
                                <?php echo esc_html( (string) ( $case['product_name'] ?? '' ) ); ?>
                                <?php
                                printf(
                                    esc_html__( '(qty %d)', 'caricove' ),
                                    isset( $case['qty'] ) ? (int) $case['qty'] : 0
                                );
                                ?>
                                <?php if ( $deadline_text ) : ?>
                                    – <?php
                                    printf(
                                        esc_html__( 'send back by %s', 'caricove' ),
                                        esc_html( $deadline_text )
                                    );
                                    ?>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endforeach; ?>
            </div>

            <style>
                .ccc-returns-wizard .cc-return-instructions-toggle{cursor:pointer}
                .ccc-returns-wizard .cc-return-instructions-body{overflow:hidden;max-height:2000px;opacity:1;transition:max-height .35s ease,opacity .25s ease,margin .25s ease,padding .25s ease}
                .ccc-returns-wizard .cc-return-instructions-card.is-collapsed .cc-return-instructions-body{max-height:0;opacity:0;margin-top:0!important;padding-top:0!important;padding-bottom:0!important}
            </style>

            <script>
            (function(){
                var root = document.currentScript && document.currentScript.closest('.cc-return-instructions-card');
                if(!root){ return; }

                var toggle = root.querySelector('.cc-return-instructions-toggle');
                var body   = root.querySelector('.cc-return-instructions-body');
                if(!toggle || !body){ return; }

                var collapsed = false;
                var timerId   = null;

                function setState(nextCollapsed){
                    collapsed = !!nextCollapsed;
                    root.classList.toggle('is-collapsed', collapsed);
                    toggle.setAttribute('aria-expanded', collapsed ? 'false' : 'true');
                }

                function armAutoCollapse(){
                    if (timerId) {
                        clearTimeout(timerId);
                    }
                    timerId = setTimeout(function(){
                        setState(true);
                    }, 20000);
                }

                function onToggle(){
                    setState(!collapsed);
                    if (!collapsed) {
                        armAutoCollapse();
                    }
                }

                toggle.addEventListener('click', onToggle);
                toggle.addEventListener('keydown', function(e){
                    if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        onToggle();
                    }
                });

                armAutoCollapse();
            })();
            </script>
        </div>
        <?php
    }

    protected function render_form( WC_Order $order ) {
        $refund_reasons = $this->get_refund_reason_matrix();
        $cancel_reasons = $this->get_cancel_reason_matrix();
        $items          = $order->get_items();

        if ( empty( $items ) ) {
            echo '<div class="notice notice-error"><strong>' . esc_html__( 'This order has no items to manage.', 'caricove' ) . '</strong></div>';
            return;
        }

        $order_number = $order->get_order_number();
        $total        = $this->money( $order->get_total() );

       // Use canonical cases bundle (order + parent) so instructions never "disappear"
$bundle_cases = $this->get_existing_cases_bundle( $order );
if ( ! empty( $bundle_cases ) && is_array( $bundle_cases ) ) {
    $latest_cases = [];
    $posted_items = [];
    $just_submitted_mode = ( 'POST' === $_SERVER['REQUEST_METHOD'] && isset( $_POST['caricove_returns_wizard_nonce'] ) );

    if ( $just_submitted_mode && ! empty( $_POST['items'] ) && is_array( $_POST['items'] ) ) {
        foreach ( $_POST['items'] as $posted_item_id => $posted_row ) {
            $pid = isset( $posted_row['qty'] ) ? (int) $posted_row['qty'] : 0;
            if ( $pid > 0 ) {
                $posted_items[] = (int) $posted_item_id;
            }
        }
    }

   foreach ( $bundle_cases as $case ) {
    if ( ! is_array( $case ) ) continue;

    $st = strtolower( (string) ( $case['status'] ?? '' ) );
    if ( $this->case_is_closed( $st ) ) continue;

    if ( $just_submitted_mode ) {
        $case_item_id = isset( $case['item_id'] ) ? (int) $case['item_id'] : 0;
        if ( $case_item_id > 0 && in_array( $case_item_id, $posted_items, true ) ) {
            $latest_cases[] = $case;
        }
    } else {
        $latest_cases[] = $case;
        break;
    }
}
    if ( ! empty( $latest_cases ) ) : ?>
        <div class="card cc-request-updates-card" data-cc-request-updates="1">
            <div class="card-header">
                <div class="card-title"><?php esc_html_e( 'Request updates', 'caricove' ); ?></div>
            </div>
            <?php foreach ( $latest_cases as $case ) :
                $ui = $this->get_decision_ui( (string) ( $case['decision_code'] ?? 'REQUEST_ACCEPTED' ), $case );
                ?>
                <div class="card" style="margin-bottom:10px;">
                    <div class="card-header">
                        <div class="card-title"><?php echo esc_html( (string) ( $case['product_name'] ?? '' ) ); ?></div>
                        <div class="hero-tag"><?php echo esc_html( (string) ( $ui['badge'] ?? __( 'Update', 'caricove' ) ) ); ?></div>
                    </div>
                    <div class="small" style="font-size:.95rem;color:#fff;margin-bottom:6px;"><?php echo esc_html( (string) ( $ui['body'] ?? '' ) ); ?></div>
                    <div class="small"><?php echo esc_html( (string) ( $ui['next'] ?? '' ) ); ?></div>
                </div>
            <?php endforeach; ?>

            <style>
                .ccc-returns-wizard .cc-request-updates-card.is-hiding{opacity:0;transition:opacity .35s ease}
            </style>

            <script>
            (function(){
                var card = document.currentScript && document.currentScript.closest('.cc-request-updates-card');
                if(!card){ return; }
                setTimeout(function(){
                    card.classList.add('is-hiding');
                    setTimeout(function(){
                        if (card && card.parentNode) {
                            card.parentNode.removeChild(card);
                        }
                    }, 350);
                }, 20000);
            })();
            </script>
        </div>
    <?php endif;

   $this->render_return_instructions_card( $order, [ 'return_cases' => ! empty( $latest_cases ) ? $latest_cases : $bundle_cases ] );
}
        ?>
        <div class="hero">
            <div class="hero-inner">
                <div class="hero-main">
                    <h1><?php echo esc_html( sprintf( __( 'Manage requests for order #%s', 'caricove' ), $order_number ) ); ?></h1>
                </div>
                <div class="hero-tag">
                    <?php
                    printf(
                        esc_html__( 'Order total: %s', 'caricove' ),
                        esc_html( $total )
                    );
                    ?>
                </div>
            </div>
        </div>

        <form method="post">
            <?php wp_nonce_field( self::NONCE_ACTION, 'caricove_returns_wizard_nonce' ); ?>
            <input type="hidden" name="order_id" value="<?php echo esc_attr( $order->get_id() ); ?>">

            <div class="card">
                <div class="card-header">
                    <div class="card-title"><?php esc_html_e( 'Items in this order', 'caricove' ); ?></div>
                    <div class="card-sub">
                        <?php esc_html_e( 'Adjust quantity and choose a reason.' , 'caricove' ); ?>
                    </div>
                </div>

                <table>
                    <thead>
                        <tr>
                            <th><?php esc_html_e( 'Item', 'caricove' ); ?></th>
                            <th><?php esc_html_e( 'Ordered', 'caricove' ); ?></th>
                            <th><?php esc_html_e( 'Quantity', 'caricove' ); ?></th>
                            <th><?php esc_html_e( 'Reason', 'caricove' ); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ( $items as $item_id => $item ) :
                            if ( ! $item instanceof WC_Order_Item_Product ) continue;

                            $product    = $item->get_product();
                            $name       = $item->get_name();
                            $qty        = (int) $item->get_quantity();
                            $product_id = $product ? $product->get_id() : 0;

                            $delivered  = $this->item_is_delivered_truth( $order, $item_id, $item );
                            $cancellable= $this->item_is_cancellable_truth( $order, $item_id, $item );

                            // mode: refund for delivered OR never_arrived special; cancel for pre-assign undelivered
                            $mode = $delivered ? 'refund' : ( $cancellable ? 'cancel' : 'blocked' );

                            // server-side anti-dup (not shown)
                            $remaining = $this->get_item_remaining_requestable_qty( $order, $item_id, $qty );
                            ?>
                            <tr>
                                <td>
                                    <div class="prod-name"><?php echo esc_html( $name ); ?></div>
                           <?php
$item_case = $this->get_item_case_for_display( $order, $item_id );
$item_has_case = ( is_array( $item_case ) && ! empty( $item_case ) );

$item_case_url = '';
if ( $item_has_case ) {
    $my  = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : home_url( '/' );
    $url = trailingslashit( $my ) . 'returns/';

    if ( function_exists( 'wc_get_endpoint_url' ) ) {
        $maybe = wc_get_endpoint_url( 'returns', '', $my );
        if ( $maybe && is_string( $maybe ) ) {
            $url = $maybe;
        }
    }

    $item_case_url = add_query_arg(
        array(
            'order_id'   => (int) $order->get_id(),
            'product_id' => (int) $product_id
        ),
        $url
    );
}

if ( $item_has_case ) {
    $item_link_url  = $item_case_url;
    $item_link_text = __( 'View Return', 'caricove' );
} else {
    $item_link_url  = $product_id ? get_permalink( $product_id ) : '';
    $item_link_text = __( 'View item', 'caricove' );
}

$item_policy_messages = [];
$item_now_ts          = (int) current_time( 'timestamp' );
$item_delivered_at    = (int) $this->item_best_delivered_at_ts( $order, (int) $item_id );

if ( $mode === 'refund' && $delivered ) {
    foreach ( $refund_reasons as $reason_code => $reason_meta ) {
        $reason_code = (string) $reason_code;

        if ( $reason_code === 'never_arrived' ) {
            $item_policy_messages[ $reason_code ] = __( 'Handled as a delivery issue and reviewed first', 'caricove' );
            continue;
        }

        $window_days = (int) $this->get_item_return_window_days( $item, $reason_code );
        $deadline_ts = ( $item_delivered_at > 0 && $window_days > 0 )
            ? (int) ( $item_delivered_at + ( $window_days * DAY_IN_SECONDS ) )
            : 0;
        $reason_fault = (string) ( $reason_meta['fault'] ?? 'customer' );
        $is_cx_fault = ( $reason_fault === 'customer' );

        if ( $deadline_ts > 0 && $item_now_ts > $deadline_ts ) {
            $item_policy_messages[ $reason_code ] = __( 'This item is no longer eligible under the selected reason', 'caricove' );
            continue;
        }

        if ( $is_cx_fault ) {
            if ( $deadline_ts > 0 ) {
                $item_policy_messages[ $reason_code ] = sprintf(
                    __( 'Eligible for return until %s', 'caricove' ),
                    date_i18n( get_option( 'date_format' ), $deadline_ts )
                );
            } else {
                $item_policy_messages[ $reason_code ] = __( 'Eligible for return', 'caricove' );
            }
            continue;
        }

        $item_policy_messages[ $reason_code ] = __( 'Check eligibility', 'caricove' );
    }
} elseif ( $mode === 'cancel' ) {
    foreach ( $cancel_reasons as $reason_code => $reason_meta ) {
        $item_policy_messages[ (string) $reason_code ] = __( 'Eligible to submit cancellation request', 'caricove' );
    }
}
?>
<?php if ( $item_link_url ) : ?>
    <div class="small">
        <a href="<?php echo esc_url( $item_link_url ); ?>" style="color:#9ccaff;text-decoration:none">
            <?php echo esc_html( $item_link_text ); ?>
        </a>
    </div>
<?php endif; ?>

<div class="small cc-item-policy-hint"
     data-cc-default-text="<?php echo esc_attr__( 'Select a reason to check eligibility', 'caricove' ); ?>"
     data-cc-fallback-text="<?php echo esc_attr__( 'Eligibility will be checked on submit', 'caricove' ); ?>"
     data-cc-policy-messages="<?php echo esc_attr( wp_json_encode( $item_policy_messages ) ); ?>"
     style="margin-top:4px;color:#dfeaff;opacity:.92;">
    <?php esc_html_e( 'Select a reason to check eligibility', 'caricove' ); ?>
</div>

                                </td>
                                <td><?php echo esc_html( $qty ); ?></td>
                                <td>
                                    <input type="number"
                                           min="0"
                                           max="<?php echo esc_attr( $qty ); ?>"
                                           name="items[<?php echo esc_attr( $item_id ); ?>][qty]"
                                           value="0"
                                           inputmode="numeric"
                                           autocomplete="off">
                                </td>
                                <td>
                                    <select name="items[<?php echo esc_attr( $item_id ); ?>][reason]"
                                            data-cc-mode="<?php echo esc_attr( $mode === 'blocked' ? 'cancel' : $mode ); ?>">
                                        <option value=""><?php esc_html_e( 'Select a reason', 'caricove' ); ?></option>

                                        <?php if ( $mode === 'refund' ) : ?>
                                            <?php foreach ( $refund_reasons as $code => $meta ) : ?>
                                                <option value="<?php echo esc_attr( $code ); ?>"><?php echo esc_html( $meta['label'] ); ?></option>
                                            <?php endforeach; ?>
                                        <?php elseif ( $mode === 'cancel' ) : ?>
                                            <?php foreach ( $cancel_reasons as $code => $meta ) : ?>
                                                <option value="<?php echo esc_attr( $code ); ?>"><?php echo esc_html( $meta['label'] ); ?></option>
                                            <?php endforeach; ?>
                                        <?php else : ?>
                                            <option value="" disabled><?php esc_html_e( 'This item can’t be cancelled once assigned/on the way.', 'caricove' ); ?></option>
                                        <?php endif; ?>
                                    </select>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
              </table>

                <script>
                (function(){
                    var root = document.currentScript && document.currentScript.closest('.card');
                    if ( ! root ) { return; }

                    var rows = root.querySelectorAll('tbody tr');

                    rows.forEach(function(row){
                        var select = row.querySelector('select[name*="[reason]"]');
                        var hint   = row.querySelector('.cc-item-policy-hint');
                        if (!select || !hint) { return; }

                        var messages = {};
                        try {
                            messages = JSON.parse(hint.getAttribute('data-cc-policy-messages') || '{}');
                        } catch (e) {
                            messages = {};
                        }

                        function renderHint(){
                            var code = (select.value || '').trim();

                            if (!code) {
                                hint.textContent = hint.getAttribute('data-cc-default-text') || 'Select a reason to check eligibility';
                                return;
                            }

                            hint.textContent = messages[code] || hint.getAttribute('data-cc-fallback-text') || 'Eligibility will be checked on submit';
                        }

                        select.addEventListener('change', renderHint);
                        renderHint();
                    });
                })();
                </script>

                <div class="summary-row">
                    <div><?php esc_html_e( 'Estimate is calculated on submit based on selection.', 'caricove' ); ?></div>
                    <div class="summary-amount">
                        <?php
                        printf(
                            esc_html__( 'Maximum possible: %s', 'caricove' ),
                            esc_html( $this->money( $order->get_total() ) )
                        );
                        ?>
                    </div>
                </div>

                <div class="actions">
                    <button type="submit"
                            class="btn-pill btn-primary"
                            data-cc-confirm="1"
                            data-cc-label-refund="<?php echo esc_attr__( 'Confirm refund request', 'caricove' ); ?>"
                            data-cc-label-cancel="<?php echo esc_attr__( 'Confirm cancellation request', 'caricove' ); ?>"
                            data-cc-label-neutral="<?php echo esc_attr__( 'Confirm request', 'caricove' ); ?>">
                        <?php esc_html_e( 'Confirm request', 'caricove' ); ?>
                    </button>
                </div>

                <div class="small" style="margin-top:8px;color:rgba(210,220,245,.8);">
                    <?php esc_html_e( 'This submits a request for review. Refunds/cancellations are applied only after approval.', 'caricove' ); ?>
                </div>
            </div>
        </form>
        <?php
    }





/**
 * Apply an immediate cancellation by creating a manual refund for the selected line items.
 * - For COD, refund_payment = false (no gateway call)
 * - Restock = true (adjust if you prefer false)
 * Returns: ['refund_id'=>int,'amount'=>float]
 */
/* ============================================================
 * PATCH 1 — REPLACE your apply_cancellation_now() function
 * (Upgrades: gateway refund when possible + safer defaults)
 * ============================================================ */

}