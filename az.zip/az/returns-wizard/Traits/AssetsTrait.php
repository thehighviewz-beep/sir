<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

trait Caricove_Returns_Wizard_Assets_Trait {

    public function enqueue_assets() {
        if ( ! $this->has_woo() ) return;

        $page_id   = get_queried_object_id();
        $content   = $page_id ? (string) get_post_field( 'post_content', $page_id ) : '';
        $has_short = $page_id ? has_shortcode( $content, 'caricove_returns_wizard' ) : false;
        if ( ! $has_short ) return;

        wp_register_style( 'caricove-returns-wizard-v2', false, [], self::VER );
        wp_enqueue_style( 'caricove-returns-wizard-v2' );

        // CSS unchanged from your baseline (kept verbatim).
        $css = <<<CSS
.ccc-returns-wizard{
  isolation:isolate;
  line-height:1.4;
  font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;
  color:#fff;
}
.ccc-returns-wizard *{box-sizing:border-box}
.ccc-returns-wizard .hero{
  margin-bottom:16px;
  padding:16px 18px 12px;
  border-radius:20px;
  background:linear-gradient(135deg,#050b18,#0b3b85);
  box-shadow:0 16px 36px rgba(0,0,0,.8);
  position:relative;
  overflow:hidden;
}
.ccc-returns-wizard .hero::after{
  content:"";
  position:absolute;
  inset:-70%;
  background:
    radial-gradient(circle at 10% 0,rgba(120,200,255,.2) 0,transparent 60%),
    radial-gradient(circle at 90% 0,rgba(40,150,255,.3) 0,transparent 55%);
  opacity:.9;
  pointer-events:none;
}
.ccc-returns-wizard .hero-inner{
  position:relative;
  z-index:1;
  display:flex;
  flex-wrap:wrap;
  justify-content:space-between;
  gap:10px;
}





.card--title{margin-bottom;100px;}





.ccc-returns-wizard .hero-main h1{
  margin:0 0 4px;
  font-size:1.4rem;
  font-weight:700;
}
.ccc-returns-wizard .hero-main p{
  margin:0;
  font-size:.86rem;
  color:rgba(230,238,255,.85);
}
.ccc-returns-wizard .hero-tag{
  align-self:flex-start;
  padding:6px 12px;
  border-radius:999px;
  font-size:.78rem;
  background:rgba(6,20,50,.8);
  border:1px solid rgba(120,190,255,.7);
}
.ccc-returns-wizard .card{
  border-radius:18px;
  background:linear-gradient(135deg,rgba(6,10,26,.98),rgba(10,18,40,.98));
  box-shadow:0 14px 30px rgba(0,0,0,.8);
  padding:10px 12px 10px;
  margin-bottom:12px;
  border:1px solid rgba(70,130,230,.55);
}
.ccc-returns-wizard .card-header{
  display:flex;
  justify-content:space-between;
  align-items:center;
  gap:6px;
  margin-bottom:5px;
}
.ccc-returns-wizard .card-title{
  font-size:1rem;
  font-weight:600;
}
.ccc-returns-wizard .card-sub{
  font-size:.8rem;
  color:rgba(210,220,245,.85);
}
.ccc-returns-wizard table{
  width:100%;
  border-collapse:collapse;
  font-size:.82rem;
  margin-bottom:8px;
}
.ccc-returns-wizard thead th{
  text-align:left;
  padding:6px 8px;
  border-bottom:1px solid rgba(80,120,190,.7);
  color:rgba(215,225,245,.92);
  font-weight:500;
}
.ccc-returns-wizard tbody td{
  padding:7px 8px;
  border-bottom:1px solid rgba(40,60,110,.6);
  vertical-align:middle;
}
.ccc-returns-wizard .prod-name{
  font-size:.86rem;
  font-weight:500;
}
.ccc-returns-wizard .small{
  font-size:.76rem;
  color:rgba(210,220,245,.8);
}
.ccc-returns-wizard input[type="number"],
.ccc-returns-wizard select{
  width:100%;
  padding:5px 8px;
  border-radius:999px;
  border:1px solid rgba(130,180,255,.8);
  background:rgba(8,16,40,.95);
  color:#fff;
  font-size:.8rem;
  outline:none;
}
.ccc-returns-wizard select{
  padding-right:24px;
}
.ccc-returns-wizard .summary-row{
  display:flex;
  justify-content:space-between;
  align-items:center;
  margin-top:8px;
  font-size:.84rem;
}
.ccc-returns-wizard .summary-amount{
  font-weight:600;
}
.ccc-returns-wizard .actions{
  margin-top:10px;
  display:flex;
  justify-content:flex-end;
  gap:8px;
}
.ccc-returns-wizard .btn-pill{
  border-radius:999px;
  padding:7px 14px;
  font-size:.82rem;
  border:none;
  cursor:pointer;
  transition:.2s all ease-out;
  display:inline-flex;
  align-items:center;
  gap:6px;
  text-decoration:none;
}
.ccc-returns-wizard .btn-primary{
  background:linear-gradient(120deg,#2a88ff,#6ec1e4);
  color:#fff;
  box-shadow:0 0 16px rgba(60,160,255,.75);
}
.ccc-returns-wizard .btn-primary:hover{
  transform:translateY(-1px) scale(1.01);
  box-shadow:0 0 22px rgba(90,190,255,.95);
}
.ccc-returns-wizard .btn-ghost{
  background:rgba(7,15,34,.9);
  border:1px solid rgba(110,170,255,.65);
  color:#e4f0ff;
}
.ccc-returns-wizard .btn-ghost:hover{
  background:rgba(20,40,85,.98);
}
.ccc-returns-wizard .notice{
  margin-bottom:12px;
  border-radius:14px;
  padding:10px 12px;
  font-size:.8rem;
}
.ccc-returns-wizard .notice-error{
  background:rgba(150,40,40,.25);
  border:1px solid rgba(220,80,80,.9);
}
.ccc-returns-wizard .notice-success{
  background:rgba(40,160,90,.25);
  border:1px solid rgba(90,230,150,.9);
}
CSS;

        wp_add_inline_style( 'caricove-returns-wizard-v2', $css );

        // Tiny JS: update button label based on selected mode (refund vs cancel). No layout changes.
        wp_register_script( 'caricove-returns-wizard-v2', '', [], self::VER, true );
        wp_enqueue_script( 'caricove-returns-wizard-v2' );

        $js = <<<JS
(function(){
  function qsa(sel, root){ return Array.prototype.slice.call((root||document).querySelectorAll(sel)); }
  function updateButton(){
    var wrap = document.querySelector('.ccc-returns-wizard');
    if(!wrap) return;

    var btn = wrap.querySelector('button[data-cc-confirm]');
    if(!btn) return;

    var modes = {};
    qsa('tbody tr', wrap).forEach(function(tr){
      var qty = tr.querySelector('input[type="number"]');
      var sel = tr.querySelector('select[data-cc-mode]');
      if(!qty || !sel) return;
      var q = parseInt(qty.value || '0', 10);
      if(!q) return;
      if(!sel.value) return;
      var mode = sel.getAttribute('data-cc-mode') || '';
      if(mode) modes[mode] = true;
    });

    var hasRefund = !!modes.refund;
    var hasCancel = !!modes.cancel;
    if(hasRefund && !hasCancel){
      btn.textContent = btn.getAttribute('data-cc-label-refund') || 'Confirm refund request';
    } else if(hasCancel && !hasRefund){
      btn.textContent = btn.getAttribute('data-cc-label-cancel') || 'Confirm cancellation request';
    } else {
      btn.textContent = btn.getAttribute('data-cc-label-neutral') || 'Confirm request';
    }
  }

  function collapseInstructions(card){
    if(!card || card.classList.contains('is-collapsed')) return;
    card.classList.add('is-collapsed');
    var toggle = card.querySelector('[data-cc-return-toggle]');
    if(toggle) toggle.setAttribute('aria-expanded', 'false');
  }

  function expandInstructions(card){
    if(!card) return;
    card.classList.remove('is-collapsed');
    var toggle = card.querySelector('[data-cc-return-toggle]');
    if(toggle) toggle.setAttribute('aria-expanded', 'true');
  }

  function initFlashUpdates(root){
    var flash = root.querySelector('[data-cc-flash-updates="1"]');
    if(!flash) return;
    var ms = parseInt(flash.getAttribute('data-cc-flash-ms') || '4000', 10);
    window.setTimeout(function(){
      flash.classList.add('is-hiding');
      window.setTimeout(function(){
        flash.classList.add('is-hidden');
      }, 280);
    }, Math.max(0, ms));
  }

  function initReturnInstructions(root){
    var card = root.querySelector('.cc-return-instructions-card');
    if(!card) return;
    var toggle = card.querySelector('[data-cc-return-toggle]');
    if(toggle && !toggle.__ccBound){
      toggle.__ccBound = true;
      toggle.addEventListener('click', function(){
        if(card.classList.contains('is-collapsed')){
          expandInstructions(card);
        } else {
          collapseInstructions(card);
        }
      });
    }
    var autoMs = parseInt(card.getAttribute('data-cc-auto-collapse') || '20000', 10);
    if(autoMs > 0){
      window.setTimeout(function(){
        collapseInstructions(card);
      }, autoMs);
    }
  }

  document.addEventListener('input', function(e){
    if(e.target && (e.target.matches('input[type="number"]') || e.target.matches('select[data-cc-mode]'))){
      updateButton();
    }
  });

  document.addEventListener('change', function(e){
    if(e.target && e.target.matches('select[data-cc-mode]')) updateButton();
  });

  document.addEventListener('DOMContentLoaded', function(){
    updateButton();
    var wrap = document.querySelector('.ccc-returns-wizard');
    if(!wrap) return;
    initFlashUpdates(wrap);
    initReturnInstructions(wrap);
  });
})();
JS;

        wp_add_inline_script( 'caricove-returns-wizard-v2', $js );
    }

    /* ------------------------ Shortcode ------------------------ */

   /* ============================================================
 * PATCH 3 — REPLACE your shortcode() success messaging block
 * (So cancellation shows “applied immediately”)
 * ============================================================ */

}
