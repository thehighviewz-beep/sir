<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

trait Caricove_Returns_Wizard_Finance_Trait {

protected function apply_cancellation_now( WC_Order $order, array $line_items_map, $amount, $reason_note = '' ) {
    if ( empty( $line_items_map ) ) {
        throw new \Exception( 'No line items to refund for cancellation.' );
    }

    $amount = (float) $amount;
    if ( $amount <= 0 ) {
        throw new \Exception( 'Cancellation amount is zero.' );
    }

    // If this cancellation is effectively a full-order cancellation (all product items fully cancelled),
    // also refund shipping lines (shipping + shipping tax) so customer gets the full amount paid.
    try {
        $is_full_cancel = true;
        foreach ( $order->get_items( 'line_item' ) as $iid => $it ) {
            $iid = (int) $iid;
            if ( ! isset( $line_items_map[ $iid ] ) ) { $is_full_cancel = false; break; }
            $want_qty = isset( $line_items_map[ $iid ]['qty'] ) ? (int) $line_items_map[ $iid ]['qty'] : 0;
            $have_qty = (int) ( $it && method_exists( $it, 'get_quantity' ) ? $it->get_quantity() : 0 );
            if ( $have_qty <= 0 ) $have_qty = 1;
            if ( $want_qty < $have_qty ) { $is_full_cancel = false; break; }
        }

        if ( $is_full_cancel ) {
            $ship_total = (float) $order->get_shipping_total();
            $ship_tax   = (float) $order->get_shipping_tax();

            if ( ( $ship_total + $ship_tax ) > 0 ) {
                foreach ( $order->get_items( 'shipping' ) as $ship_item_id => $ship_item ) {
                    $ship_item_id = (int) $ship_item_id;
                    if ( $ship_item_id <= 0 ) continue;

                    // Refund the full shipping line (total + tax broken out by rate)
                    $taxes = ( is_object( $ship_item ) && method_exists( $ship_item, 'get_taxes' ) ) ? $ship_item->get_taxes() : [];
                    $refund_tax = [];
                    if ( is_array( $taxes ) && ! empty( $taxes['total'] ) && is_array( $taxes['total'] ) ) {
                        foreach ( $taxes['total'] as $rate_id => $amt ) {
                            $amt = (float) $amt;
                            if ( $amt <= 0 ) continue;
                            $refund_tax[ (int) $rate_id ] = wc_format_decimal( $amt, wc_get_price_decimals() );
                        }
                    }

                    $line_items_map[ $ship_item_id ] = [
                        'qty'          => 1,
                        'refund_total' => wc_format_decimal( (float) ( method_exists( $ship_item, 'get_total' ) ? $ship_item->get_total() : $ship_total ), wc_get_price_decimals() ),
                        'refund_tax'   => $refund_tax,
                    ];
                }

                // Increase refund amount by shipping (total + tax) if not already included.
                $amount += ( $ship_total + $ship_tax );
            }
        }
    } catch ( \Throwable $e ) {
        // Never block cancellation if shipping math fails; fall back to item-only refund.
    }

    // Decide whether to actually hit the gateway (refund_payment=true) or create a manual refund record only.
    $refund_payment = false;

    try {
        $pm = (string) $order->get_payment_method();
        $gateway = wc_get_payment_gateway_by_order( $order );

        // COD should never call gateway.
        $is_cod = in_array( $pm, [ 'cod', 'cash_on_delivery' ], true );

        // Gateways can refund only if they support it and we have a transaction id.
        $supports_refunds = ( $gateway && method_exists( $gateway, 'can_refund_order' ) )
            ? (bool) $gateway->can_refund_order( $order )
            : ( $gateway && method_exists( $gateway, 'supports' ) ? (bool) $gateway->supports( 'refunds' ) : false );

        $has_txn = (string) $order->get_transaction_id();
        $has_txn = trim( $has_txn ) !== '';

        if ( ! $is_cod && $supports_refunds && $has_txn ) {
            $refund_payment = true;
        }

        // Allow you to force this one way or the other if needed.
        $refund_payment = (bool) apply_filters(
            'caricove_cancellation_refund_payment',
            $refund_payment,
            $order,
            $line_items_map,
            $amount
        );

    } catch ( \Throwable $e ) {
        // If gateway probing fails, fall back to manual refund record.
        $refund_payment = false;
    }

    $refund = wc_create_refund( [
        'amount'         => wc_format_decimal( $amount, wc_get_price_decimals() ),
        'reason'         => $reason_note ? $reason_note : 'Caricove: cancellation applied',
        'order_id'       => $order->get_id(),
        'line_items'     => $line_items_map, // item_id => ['qty'=>X, 'refund_total'=>Y, 'refund_tax'=>[rate=>amt]]
        'refund_payment' => $refund_payment,
        'restock_items'  => true,
    ] );

    if ( is_wp_error( $refund ) ) {
        throw new \Exception( $refund->get_error_message() );
    }
    if ( ! $refund || ! is_a( $refund, 'WC_Order_Refund' ) ) {
        throw new \Exception( 'Refund creation failed for cancellation.' );
    }

    return [
        'refund_id'      => (int) $refund->get_id(),
        'amount'         => (float) $amount,
        'refund_payment' => (int) ( $refund_payment ? 1 : 0 ),
    ];
}








/* ============================================================
 * PATCH 2 — ADD this NEW method (logistics cancellation)
 * Put it right under apply_cancellation_now()
 * ============================================================ */

protected function apply_cancellation_logistics_now( WC_Order $order, array $cancel_line_items_map, $refund_id = 0, $note = '' ) {
    $order_id = (int) $order->get_id();
    $uid      = (int) get_current_user_id();
    $refund_id = (int) $refund_id;

    if ( empty( $cancel_line_items_map ) || ! is_array( $cancel_line_items_map ) ) return;

    // Commission rate must match payout engine. Default 12%.
    $commission_rate = 0.12;
    if ( class_exists( '\Caricove\SellerPayouts\Settings' ) ) {
        try { $commission_rate = (float) \Caricove\SellerPayouts\Settings::get( 'commission_rate', 0.12 ); } catch ( \Throwable $e ) {}
    }

    // Build list of affected shipment IDs for post-meta recompute.
    $shipment_ids = [];

    foreach ( $cancel_line_items_map as $item_id => $row ) {
        $item_id = (int) $item_id;
        $qty_cancel = isset( $row['qty'] ) ? (int) $row['qty'] : 0;
        if ( $qty_cancel <= 0 ) continue;

        // Canonical link: line-item -> shipment post id
        $sid = (int) wc_get_order_item_meta( $item_id, '_cc_item_shipment_id', true );
        if ( $sid <= 0 ) continue;

        $shipment_ids[ $sid ] = true;

        // Payout protection: create an idempotent DEBIT for this cancellation delta qty.
        if ( ! class_exists( '\Caricove\SellerPayouts\Ledger' ) ) continue;

        $item = $order->get_item( $item_id );
        if ( ! ( $item instanceof WC_Order_Item_Product ) ) continue;

        $max_qty = max( 1, (int) $item->get_quantity() );
        if ( $qty_cancel > $max_qty ) $qty_cancel = $max_qty;

        $gross_line = (float) $item->get_total() + (float) $item->get_total_tax();
        $per_unit   = $max_qty > 0 ? ( $gross_line / $max_qty ) : $gross_line;
        $cancel_gross = max( 0.0, $per_unit * $qty_cancel );

        $vendor_id = (int) $this->resolve_vendor_id_for_item( $order, $item_id, $item );
        if ( $vendor_id <= 0 || $cancel_gross <= 0 ) continue;

        $delta_net = max( 0.0, $cancel_gross * ( 1.0 - (float) $commission_rate ) );

        // Delta model: make unique key depend on refund id (best identity) + item + qty.
        // This prevents double-charge on refresh, and allows multiple partial cancels via new refund ids.
        $uk = 'cancel_adj:order:' . $order_id . ':ship:' . $sid . ':item:' . $item_id . ':refund:' . $refund_id . ':qty:' . $qty_cancel;

        // Idempotency marker (shipment postmeta)
        $rb_key = '_cc_sp_retbridge_' . md5( $uk );
        $already = get_post_meta( $sid, $rb_key, true );
        if ( ! empty( $already ) ) continue;

        try {
            \Caricove\SellerPayouts\Ledger::create_vendor_debit_idempotent(
                $uk,
                $vendor_id,
                $order_id,
                $sid,
                (float) $delta_net,
                ( $note ? (string) $note : 'cancellation_adjustment' ),
                [
                    'type'            => 'cancellation_adjustment',
                    'note'            => ( $note ? (string) $note : '' ),
                    'order_id'        => $order_id,
                    'shipment_id'     => $sid,
                    'item_id'         => $item_id,
                    'cancel_qty'      => $qty_cancel,
                    'gross_cancelled' => (float) $cancel_gross,
                    'commission_rate' => (float) $commission_rate,
                    'by_user'         => $uid,
                    'refund_id'       => $refund_id,
                ]
            );

            update_post_meta( $sid, $rb_key, wp_json_encode([
                'unique_key' => $uk,
                'did'        => 'debit',
                'net_debit'  => (float) $delta_net,
                'cancel_qty' => (int) $qty_cancel,
                'gross'      => (float) $cancel_gross,
                'at'         => current_time('mysql'),
            ]) );

        } catch ( \Throwable $e ) {
            // Never break UX; record the error for debugging
            update_post_meta( $sid, $rb_key, wp_json_encode([
                'unique_key' => $uk,
                'did'        => 'error',
                'err'        => sanitize_text_field( $e->getMessage() ),
                'at'         => current_time('mysql'),
            ]) );
        }
    }

    // Recompute shipment aggregates (declared value + count) for affected shipments.
    foreach ( array_keys( $shipment_ids ) as $sid ) {
        $sid = (int) $sid;
        if ( $sid <= 0 ) continue;

        // Derive remaining items by scanning order items linked to this shipment, excluding cancelled ones.
        $remaining_count = 0;
        $remaining_value = 0.0;

        foreach ( $order->get_items() as $oid => $oit ) {
            $oid = (int) $oid;
            if ( (int) wc_get_order_item_meta( $oid, '_cc_item_shipment_id', true ) !== $sid ) continue;

            $t = strtolower( (string) wc_get_order_item_meta( $oid, '_caricove_case_type', true ) );
            $s = strtolower( (string) wc_get_order_item_meta( $oid, '_caricove_case_status', true ) );

            // If fully cancelled, exclude. If partially cancelled, include remaining qty portion.
            $max_qty = ( $oit instanceof WC_Order_Item_Product ) ? max( 1, (int) $oit->get_quantity() ) : 1;

            if ( $t === 'cancellation' && in_array( $s, [ 'cancelled', 'refunded', 'closed' ], true ) ) {
                continue;
            }

            $gross_line = (float) $oit->get_total() + (float) $oit->get_total_tax();
            $per_unit   = $max_qty > 0 ? ( $gross_line / $max_qty ) : $gross_line;

            if ( $t === 'cancellation' && $s === 'cancelled_partial' ) {
                // Remaining qty = max_qty - total_cancelled_qty (from cases meta if present)
                $cancelled_total = (int) wc_get_order_item_meta( $oid, '_caricove_cancel_qty_total', true );
                if ( $cancelled_total < 0 ) $cancelled_total = 0;
                if ( $cancelled_total > $max_qty ) $cancelled_total = $max_qty;
                $rem_qty = max( 0, $max_qty - $cancelled_total );
                if ( $rem_qty <= 0 ) continue;

                $remaining_count += $rem_qty;
                $remaining_value += ( $per_unit * $rem_qty );
            } else {
                $remaining_count += $max_qty;
                $remaining_value += $gross_line;
            }
        }

        update_post_meta( $sid, '_cc_shipment_item_count', (int) $remaining_count );
        update_post_meta( $sid, '_cc_shipment_declared_value', (float) $remaining_value );

        // If no remaining items, cancel shipment only if not already delivered.
        $st = strtolower( (string) get_post_meta( $sid, '_cc_shipment_status', true ) );
        if ( $remaining_count <= 0 && ! in_array( $st, [ 'delivered' ], true ) ) {
            update_post_meta( $sid, '_cc_shipment_status', 'cancelled' );
            delete_post_meta( $sid, '_cc_courier_id' );
            delete_post_meta( $sid, '_caricove_job_courier_id' );
        }
    }



    $shipment_ids = [];

    // Ensure cancelled_item_ids is always defined (prevents warnings)
    $cancelled_item_ids = is_array( $cancel_line_items_map ) ? array_map( 'intval', array_keys( $cancel_line_items_map ) ) : [];

    if ( ! empty( $cancelled_item_ids ) ) {
        foreach ( $cancelled_item_ids as $item_id ) {
        // Canonical link: line-item -> shipment post id
        $sid = (int) wc_get_order_item_meta( $item_id, '_cc_item_shipment_id', true );
        if ( $sid > 0 ) $shipment_ids[ $sid ] = true;

        // Payout protection: create an idempotent debit for this cancelled item,
        // so even if a delivered/pending credit exists, net is reduced.
        if ( $sid > 0 && class_exists( '\Caricove\SellerPayouts\Ledger' ) ) {
            $item = $order->get_item( $item_id );
            if ( $item instanceof WC_Order_Item_Product ) {
                $max_qty = (int) $item->get_quantity();
                $gross   = (float) $item->get_total() + (float) $item->get_total_tax();

                // If partial cancellation qty is supported later, derive qty from meta; for now cancel == full qty.
                $qty_cancel = $max_qty > 0 ? $max_qty : 1;

                $per_unit = $max_qty > 0 ? ( $gross / $max_qty ) : $gross;
                $cancel_gross = $per_unit * $qty_cancel;

                $vendor_id = (int) $this->resolve_vendor_id_for_item( $order, $item_id, $item );
                if ( $vendor_id > 0 && $cancel_gross > 0 ) {
                    $delta_net = max( 0.0, $cancel_gross * ( 1.0 - $commission_rate ) );

                    $uk = 'cancel_adj:order:' . $order_id . ':ship:' . $sid . ':item:' . $item_id;

                    try {
                        \Caricove\SellerPayouts\Ledger::create_vendor_debit_idempotent(
                            $uk,
                            $vendor_id,
                            $order_id,
                            $sid,
                            (float) $delta_net,
                            ( $note ? (string) $note : 'cancellation_adjustment' ),
                            [
                                'type' => 'cancellation_adjustment',
                                'item_id' => (int) $item_id,
                                'gross_cancelled' => (float) $cancel_gross,
                                'commission_rate' => (float) $commission_rate,
                                'by_user' => $uid,
                            ]
                        );

                        // Mark bridge flag for audit/debug
                        update_post_meta( $sid, '_cc_sp_retbridge_' . md5( $uk ), wp_json_encode([
                            'unique_key' => $uk,
                            'did' => 'debit',
                            'net_debit' => (float) $delta_net,
                            'at' => current_time('mysql'),
                        ]) );

                    } catch ( \Throwable $e ) {
                        // Never break cancellation UX; record error for debugging
                        update_post_meta( $sid, '_cc_sp_retbridge_' . md5( $uk ), wp_json_encode([
                            'unique_key' => $uk,
                            'did' => 'error',
                            'error' => $e->getMessage(),
                            'at' => current_time('mysql'),
                        ]) );
                    }
                }
            }
        }
    }
    }

    // Recompute shipment aggregates and cancel shipment only if empty
    foreach ( array_keys( $shipment_ids ) as $sid ) {
        $sid = (int) $sid;
        if ( $sid <= 0 ) continue;

        // Derive remaining items by scanning order items linked to this shipment and skipping cancelled ones
        $remaining_count = 0;
        $remaining_gross = 0.0;

        foreach ( $order->get_items() as $iid => $it ) {
            $iid = (int) $iid;
            if ( (int) wc_get_order_item_meta( $iid, '_cc_item_shipment_id', true ) !== $sid ) continue;

            // Cancellation truth: our canonical keys
            $t = strtolower( (string) wc_get_order_item_meta( $iid, '_caricove_case_type', true ) );
            $s = strtolower( (string) wc_get_order_item_meta( $iid, '_caricove_case_status', true ) );

            $is_cancelled = ( $t === 'cancellation' && in_array( $s, [ 'cancelled', 'refunded', 'closed' ], true ) );

            if ( $is_cancelled ) continue;

            $remaining_count++;
            if ( $it instanceof WC_Order_Item_Product ) {
                $remaining_gross += (float) $it->get_total() + (float) $it->get_total_tax();
            }
        }

        update_post_meta( $sid, '_cc_shipment_item_count', (int) $remaining_count );
        update_post_meta( $sid, '_cc_shipment_declared_value', (float) $remaining_gross );

        if ( $remaining_count <= 0 ) {
            // Cancel shipment only if it hasn't been delivered already
            $st = strtolower( (string) get_post_meta( $sid, '_cc_shipment_status', true ) );
            if ( $st !== 'delivered' ) {
                update_post_meta( $sid, '_cc_shipment_status', 'cancelled' );

                // Clear assignment fields (best-effort, safe)
                foreach ( [
                    '_cc_shipment_courier_id',
                    '_cc_shipment_assignment_id',
                    '_cc_shipment_mission_id',
                    '_cc_shipment_ready_for_assignment_at',
                ] as $k ) {
                    delete_post_meta( $sid, $k );
                }
            }
        }
    }
}
            
        
    







    /* ------------------------ POST handler (policy-true + item-scoped state) ------------------------ */

}
