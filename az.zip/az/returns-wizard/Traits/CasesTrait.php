<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

trait Caricove_Returns_Wizard_Cases_Trait {

    protected function get_existing_cases_bundle( WC_Order $order ) {
        $cases = [];
        $parent_cases = [];

        if ( class_exists( '\\Caricove\\Bank\\BankRefundCases' ) ) {
            $cases = \Caricove\Bank\BankRefundCases::list_legacy_cases_for_order( (int) $order->get_id() );

            $parent_id = (int) $order->get_parent_id();
            if ( $parent_id > 0 ) {
                $parent_cases = \Caricove\Bank\BankRefundCases::list_legacy_cases_for_order( $parent_id );
            }
        } else {
            $cases = $this->order_get_meta( $order, CC_RETURNS_META_CASES );
            $cases = is_array( $cases ) ? $cases : [];

            $parent_id = (int) $order->get_parent_id();
            if ( $parent_id > 0 ) {
                $p = wc_get_order( $parent_id );
                if ( $p instanceof WC_Order ) {
                    $pc = $this->order_get_meta( $p, CC_RETURNS_META_CASES );
                    $parent_cases = is_array( $pc ) ? $pc : [];
                }
            }
        }

        $seen = [];
        $out  = [];

        foreach ( array_merge( $cases, $parent_cases ) as $c ) {
            if ( ! is_array( $c ) ) {
                continue;
            }

            $rid = isset( $c['rma_id'] ) ? (string) $c['rma_id'] : (string) ( $c['case_id'] ?? '' );
            if ( $rid && isset( $seen[ $rid ] ) ) {
                continue;
            }

            if ( $rid ) {
                $seen[ $rid ] = true;
            }

            $out[] = $c;
        }

        return $out;
    }

   protected function is_returnless_refund_case( array $case ) {
    $mode = strtolower( trim( (string) ( $case['refund_execution_mode'] ?? '' ) ) );
    if ( in_array( $mode, [ 'returnless', 'never_received' ], true ) ) {
        return true;
    }

    if ( ! empty( $case['low_value_refund_only'] ) ) {
        return true;
    }

    $decision_code   = strtoupper( trim( (string) ( $case['decision_code'] ?? '' ) ) );
    $return_required = ! empty( $case['return_required'] );

    if ( in_array( $decision_code, [ 'REFUND_ONLY', 'REFUND_IMMEDIATE' ], true ) && ! $return_required ) {
        return true;
    }

    return false;
}

protected function get_item_case_for_display( WC_Order $order, $item_id ) {
    $item_id = (int) $item_id;
    if ( $item_id <= 0 ) {
        return null;
    }

    $existing_cases = $this->get_existing_cases_bundle( $order );
    $best_open      = null;
    $best_closed    = null;
    $best_open_ts   = -1;
    $best_closed_ts = -1;

    foreach ( $existing_cases as $c ) {
        if ( ! is_array( $c ) ) {
            continue;
        }

        $case_item_id = (int) ( $c['order_item_id'] ?? $c['item_id'] ?? $c['line_item_id'] ?? 0 );
        if ( $case_item_id !== $item_id ) {
            continue;
        }

        $ts = max(
            (int) ( $c['updated_at'] ?? 0 ),
            (int) ( $c['updated'] ?? 0 ),
            (int) ( $c['created_at'] ?? 0 ),
            (int) ( $c['created'] ?? 0 )
        );

        $st = strtolower( trim( (string) ( $c['status'] ?? '' ) ) );
        if ( ! $this->case_is_closed( $st ) ) {
            if ( $best_open === null || $ts >= $best_open_ts ) {
                $best_open    = $c;
                $best_open_ts = $ts;
            }
            continue;
        }

        if ( $best_closed === null || $ts >= $best_closed_ts ) {
            $best_closed    = $c;
            $best_closed_ts = $ts;
        }
    }

    return $best_open ?: $best_closed;
}

    protected function get_item_case_view_url( WC_Order $order, array $case ) {
        $order_id = (int) $order->get_id();
        $rma_id   = (string) ( $case['rma_id'] ?? ( $case['case_id'] ?? '' ) );

        if ( $order_id <= 0 || $rma_id === '' ) {
            return '';
        }

        return add_query_arg(
            [
                'view_order_returns' => $order_id,
                'rma_id'             => $rma_id,
            ],
            wc_get_account_endpoint_url( 'orders' )
        );
    }
}