<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

trait Caricove_Returns_Wizard_Shipment_Trait {

private function item_best_delivered_at_ts(\WC_Order $order, int $item_id): int {

    $order_id = (int) $order->get_id();
    if ($order_id <= 0 || $item_id <= 0) return 0;

    // 1) Preferred: shipment delivered timestamp (shipment truth)
    $sid = (int) wc_get_order_item_meta($item_id, '_cc_item_shipment_id', true);
    if ($sid > 0) {
        $st = strtolower((string) get_post_meta($sid, '_cc_shipment_status', true));
        if ($st === 'delivered') {

            // Try common delivered-at metas (best effort)
            foreach (['_cc_shipment_delivered_at', '_cc_delivered_at', '_caricove_job_delivered_at'] as $k) {
                $v = (string) get_post_meta($sid, $k, true);
                if ($v) {
                    $ts = strtotime($v);
                    if ($ts) return (int) $ts;
                }
            }

            // Fallback: shipment post modified time if it's marked delivered
            $p = get_post($sid);
            if ($p && !empty($p->post_modified_gmt)) {
                $ts = strtotime($p->post_modified_gmt . ' GMT');
                if ($ts) return (int) $ts;
            }
        }
    }

    // 2) Fallback: Woo order delivered-ish timestamps
    // (Not item-specific, but prevents blocking legitimate returns)
    $dc = $order->get_date_completed();
    if ($dc) return (int) $dc->getTimestamp();

    // Sometimes orders are "delivered" in your system while Woo is still processing.
    // Paid date is a reasonable fallback.
    $dp = $order->get_date_paid();
    if ($dp) return (int) $dp->getTimestamp();

    // 3) Last resort: order created (only if your policy allows; otherwise keep 0)
    // We keep it strict: unknown means not eligible for delivered-only returns.
    return 0;
}





    /**
     * Cancellation reasons (pre-assignment / pre-transit only).
     * Keep these separate from refund reasons so policy stays explicit.
     */

    protected function ccr_norm_ship_status( $raw ) {
        $s = strtolower( trim( (string) $raw ) );
        $s = preg_replace( '/\s+/', '_', $s );
        $s = sanitize_key( $s );
        return $s ?: 'unknown';
    }

    protected function ccr_get_shipments_for_order( WC_Order $order ) {
        $order_id = (int) $order->get_id();
        if ( $order_id <= 0 ) return [];

        if ( isset( $this->ccr_ship_cache[ $order_id ] ) ) {
            return $this->ccr_ship_cache[ $order_id ];
        }

        $ids = [];

        $filtered = apply_filters( 'caricove_returns_shipments_for_order', null, $order );
        if ( is_array( $filtered ) && ! empty( $filtered ) ) {
            $ids = array_values( array_unique( array_filter( array_map( 'intval', $filtered ) ) ) );
            $this->ccr_ship_cache[ $order_id ] = $ids;
            return $ids;
        }

        $core_candidates = [
            [ '\Caricove\Logistics\Core\ShipmentManager', 'get_shipments_for_order' ],
            [ '\Caricove_Shipment_Manager', 'get_shipments_for_order' ],
            [ '\Caricove_Logistics_Shipment_Manager', 'get_shipments_for_order' ],
        ];
        foreach ( $core_candidates as $cand ) {
            $cls  = $cand[0];
            $meth = $cand[1];
            if ( class_exists( $cls ) && method_exists( $cls, $meth ) ) {
                try {
                    $out = $cls::$meth( $order_id );
                    if ( is_array( $out ) && ! empty( $out ) ) {
                        $ids = array_values( array_unique( array_filter( array_map( 'intval', $out ) ) ) );
                        break;
                    }
                } catch ( \Throwable $e ) {}
            }
            if ( ! empty( $ids ) ) break;
        }

        if ( empty( $ids ) ) {
            $q = new WP_Query( [
                'post_type'      => 'cc_shipment',
                'post_status'    => 'any',
                'posts_per_page' => -1,
                'fields'         => 'ids',
                'no_found_rows'  => true,
                'meta_query'     => [
                    [
                        'key'     => '_cc_shipment_order_id',
                        'value'   => (string) $order_id,
                        'compare' => '=',
                    ],
                ],
            ] );
            if ( $q->have_posts() ) {
                $ids = array_map( 'intval', (array) $q->posts );
            }
        }

        if ( empty( $ids ) ) {
            $q2 = new WP_Query( [
                'post_type'      => 'cc_shipment',
                'post_status'    => 'any',
                'posts_per_page' => -1,
                'fields'         => 'ids',
                'no_found_rows'  => true,
                'post_parent'    => $order_id,
            ] );
            if ( $q2->have_posts() ) {
                $ids = array_map( 'intval', (array) $q2->posts );
            }
        }

        $ids = array_values( array_unique( array_filter( array_map( 'intval', $ids ) ) ) );
        $this->ccr_ship_cache[ $order_id ] = $ids;
        return $ids;
    }

    protected function ccr_shipment_status_raw( $shipment_id ) {
        $shipment_id = (int) $shipment_id;
        if ( $shipment_id <= 0 ) return '';

        $raw = (string) get_post_meta( $shipment_id, '_cc_shipment_status', true );
        if ( $raw === '' ) $raw = (string) get_post_meta( $shipment_id, '_cc_status', true );
        if ( $raw === '' ) $raw = (string) get_post_meta( $shipment_id, 'status', true );

        // Fallback: WP post_status sometimes carries meaning in legacy setups.
        if ( $raw === '' ) {
            $pst = get_post_status( $shipment_id );
            if ( is_string( $pst ) && $pst ) $raw = $pst;
        }

        return (string) $raw;
    }

    protected function ccr_shipment_is_delivered( $shipment_id ) {
        $st = $this->ccr_norm_ship_status( $this->ccr_shipment_status_raw( $shipment_id ) );
        $delivered = [
            'delivered',
            'delivered_confirmed',
            'delivered_to_customer',
            'delivered_success',
            'completed',
            'complete',
        ];
        return in_array( $st, $delivered, true );
    }

    protected function ccr_shipment_delivered_ts( $shipment_id ) {
        $shipment_id = (int) $shipment_id;
        if ( $shipment_id <= 0 ) return 0;

        $keys = [
            '_cc_shipment_delivered_at',
            '_cc_delivered_at',
            '_caricove_delivered_at',
            'delivered_at',
            '_cc_shipment_status_updated_at',
            '_cc_status_updated_at',
        ];

        foreach ( $keys as $k ) {
            $v = get_post_meta( $shipment_id, $k, true );
            if ( $v === '' || $v === null ) continue;

            if ( is_numeric( $v ) && (int) $v > 0 ) return (int) $v;

            $ts = strtotime( (string) $v );
            if ( $ts ) return (int) $ts;
        }

        return 0;
    }

   protected function ccr_shipment_contains_item( $shipment_id, $order_item_id ) {
    $shipment_id   = (int) $shipment_id;
    $order_item_id = (int) $order_item_id;
    if ( $shipment_id <= 0 || $order_item_id <= 0 ) return false;

    $ids = get_post_meta( $shipment_id, '_cc_shipment_item_ids', true );
    if ( is_string( $ids ) ) $ids = maybe_unserialize( $ids );

    if ( is_array( $ids ) && ! empty( $ids ) ) {
        $ids = array_values( array_filter( array_map( 'intval', $ids ) ) );
        if ( in_array( $order_item_id, $ids, true ) ) {
            return true;
        }
    }

    $single = (int) get_post_meta( $shipment_id, '_cc_order_item_id', true );
    if ( $single && $single === $order_item_id ) return true;

    foreach ( [ '_cc_shipment_items', '_cc_shipment_line_items', '_cc_shipment_order_items' ] as $mk ) {
        $meta = get_post_meta( $shipment_id, $mk, true );
        $meta = is_string( $meta ) ? maybe_unserialize( $meta ) : $meta;

        if ( ! is_array( $meta ) || empty( $meta ) ) {
            continue;
        }

        foreach ( $meta as $row ) {
            if ( ! is_array( $row ) ) continue;

            $maybe_it = (int) ( $row['order_item_id'] ?? $row['item_id'] ?? $row['line_item_id'] ?? 0 );
            if ( $maybe_it === $order_item_id ) {
                return true;
            }
        }
    }

    return false;
}
    /**
     * Find the shipment for a specific item (to avoid "wrong shipment blocks cancellation").
     */

    protected function ccr_find_shipment_for_item( WC_Order $order, $item_id ) {
        $order_id = (int) $order->get_id();
        $item_id  = (int) $item_id;
        $ck       = $order_id . ':' . $item_id;

        if ( isset( $this->ccr_item_ship_cache[ $ck ] ) ) {
            return $this->ccr_item_ship_cache[ $ck ];
        }

        $shipment_id = 0;
        $status      = 'unknown';

      // 1) Direct item meta references (common patterns).
$direct_keys = [ '_cc_item_shipment_id', '_cc_shipment_id', '_caricove_shipment_id', 'cc_shipment_id' ];
foreach ( $direct_keys as $k ) {
    $v = wc_get_order_item_meta( $item_id, $k, true );
    if ( $v && is_numeric( $v ) && (int) $v > 0 ) {
        $shipment_id = (int) $v;
        break;
    }
}

        // 2) Otherwise: scan order shipments and match by explicit mapping.
        if ( $shipment_id <= 0 ) {
            $ships = $this->ccr_get_shipments_for_order( $order );
            if ( ! empty( $ships ) ) {
                foreach ( $ships as $sid ) {
                    $sid = (int) $sid;
                    if ( $sid <= 0 ) continue;
                    if ( $this->ccr_shipment_contains_item( $sid, $item_id ) ) {
                        $shipment_id = $sid;
                        break;
                    }
                }
            }
        }

        // 3) Never silently guess the first shipment when mapping is ambiguous.
        // Leave shipment_id unresolved so downstream logic can stay strict.

        if ( $shipment_id > 0 ) {
            $status = $this->ccr_norm_ship_status( $this->ccr_shipment_status_raw( $shipment_id ) );
        }

        $out = [
            'shipment_id' => (int) $shipment_id,
            'status'      => (string) $status,
        ];
        $this->ccr_item_ship_cache[ $ck ] = $out;
        return $out;
    }

   protected function ccr_logistics_probe_item( WC_Order $order, $item_id, WC_Order_Item_Product $item ) {
    $order_id = (int) $order->get_id();
    $item_id  = (int) $item_id;
    $ck       = $order_id . ':' . $item_id;

    if ( isset( $this->ccr_item_probe_cache[ $ck ] ) ) {
        return $this->ccr_item_probe_cache[ $ck ];
    }

    $ship = $this->ccr_find_shipment_for_item( $order, $item_id );

    // Strict shipment-first truth:
    // if this item is mapped to a shipment, only that shipment can make it delivered.
    if ( ! empty( $ship['shipment_id'] ) ) {
        $sid = (int) $ship['shipment_id'];

        if ( $sid > 0 && $this->ccr_shipment_is_delivered( $sid ) ) {
            $ts = (int) $this->ccr_shipment_delivered_ts( $sid );
            $out = [ 'delivered' => true, 'ts' => $ts ];
            $this->ccr_item_probe_cache[ $ck ] = $out;
            return $out;
        }

        $out = [ 'delivered' => false, 'ts' => 0 ];
        $this->ccr_item_probe_cache[ $ck ] = $out;
        return $out;
    }

    // If the order has shipment truth but this item could not be mapped,
    // stay strict and do NOT inherit delivered truth from global helpers.
    $ships = $this->ccr_get_shipments_for_order( $order );
    if ( ! empty( $ships ) ) {
        $out = [ 'delivered' => false, 'ts' => 0 ];
        $this->ccr_item_probe_cache[ $ck ] = $out;
        return $out;
    }

    // Legacy fallback only when no shipment truth exists at all.
    $delivered = null;
    if ( function_exists( 'cc_item_is_delivered_truth' ) ) {
        try {
            $delivered = (bool) cc_item_is_delivered_truth( $order_id, $item_id );
        } catch ( \Throwable $e ) {
            $delivered = null;
        }
    }

    if ( is_bool( $delivered ) ) {
        $out = [ 'delivered' => $delivered, 'ts' => 0 ];
        $this->ccr_item_probe_cache[ $ck ] = $out;
        return $out;
    }

    $out = [ 'delivered' => false, 'ts' => 0 ];
    $this->ccr_item_probe_cache[ $ck ] = $out;
    return $out;
}

   protected function get_item_delivered_at_ts( WC_Order $order, $item_id, WC_Order_Item_Product $item ) {
    $ts = (int) apply_filters( 'caricove_returns_item_delivered_at', 0, $order, $item_id, $item );
    if ( $ts > 0 ) return $ts;

    $probe = $this->ccr_logistics_probe_item( $order, $item_id, $item );
    if ( ! empty( $probe['ts'] ) && (int) $probe['ts'] > 0 ) return (int) $probe['ts'];

    $v = wc_get_order_item_meta( $item_id, CC_RETURNS_ITEM_META_PREFIX . 'delivered_at', true );
    if ( is_numeric( $v ) && (int) $v > 0 ) return (int) $v;

    $ship = $this->ccr_find_shipment_for_item( $order, $item_id );
    if ( ! empty( $ship['shipment_id'] ) ) {
        $sid = (int) $ship['shipment_id'];
        if ( $sid > 0 && $this->ccr_shipment_is_delivered( $sid ) ) {
            $ship_ts = (int) $this->ccr_shipment_delivered_ts( $sid );
            if ( $ship_ts > 0 ) return $ship_ts;
        }

        // Shipment is known and this item's shipment is not delivered.
        // Never let order-level completed timestamps falsely convert this row into a return row.
        return 0;
    }

    $ships = $this->ccr_get_shipments_for_order( $order );
    if ( ! empty( $ships ) ) {
        // Order has shipment truth, but this item could not be mapped reliably.
        // Stay strict: do not inherit order-level delivery onto the item.
        return 0;
    }

    // Legacy / non-logistics fallback only when the order has no shipment truth at all.
    $ov = $this->order_get_meta( $order, CC_RETURNS_ITEM_META_PREFIX . 'delivered_at' );
    if ( is_numeric( $ov ) && (int) $ov > 0 ) return (int) $ov;

    $dt = $order->get_date_completed();
    if ( $dt instanceof WC_DateTime ) return (int) $dt->getTimestamp();

    return 0;
}

protected function item_is_delivered_truth( WC_Order $order, $item_id, WC_Order_Item_Product $item ) {
    $filtered = apply_filters( 'caricove_returns_item_delivered_truth', null, $order, $item_id, $item );
    if ( is_bool( $filtered ) ) return $filtered;

    $probe = $this->ccr_logistics_probe_item( $order, $item_id, $item );
    if ( ! empty( $probe['delivered'] ) ) return true;

    $ship = $this->ccr_find_shipment_for_item( $order, $item_id );
    if ( ! empty( $ship['shipment_id'] ) ) {
        $sid = (int) $ship['shipment_id'];
        return ( $sid > 0 && $this->ccr_shipment_is_delivered( $sid ) );
    }

    $ships = $this->ccr_get_shipments_for_order( $order );
    if ( ! empty( $ships ) ) {
        // Order has real shipment truth, so do not let order-level status mark unmapped items as delivered.
        return false;
    }

    $ts = $this->get_item_delivered_at_ts( $order, $item_id, $item );
    if ( $ts > 0 ) return true;

    $st = (string) $order->get_status();
    if ( in_array( $st, [ 'completed', 'delivered' ], true ) ) return true;

    return false;
}

    /**
     * Cancellation eligibility: item-scoped shipment status (pre-assignment / pre-transit).
     * If we cannot resolve a shipment for the item, we DO NOT falsely block cancellation.
     */

    protected function item_is_cancellable_truth( WC_Order $order, $item_id, WC_Order_Item_Product $item ) {
        // Never cancellable if delivered.
        if ( $this->item_is_delivered_truth( $order, $item_id, $item ) ) return false;

        $ship = $this->ccr_find_shipment_for_item( $order, $item_id );
        $st   = isset( $ship['status'] ) ? (string) $ship['status'] : 'unknown';

        // If we have no shipment id, avoid false positives (allow cancellation).
        if ( empty( $ship['shipment_id'] ) ) return true;

        // Block-list: once assigned / in motion, cancellation is disallowed.
        $blocked = [
            'assigned',
            'courier_assigned',
            'accepted',
            'dispatch',
            'dispatched',
            'picked_up',
            'pickup_complete',
            'in_transit',
            'out_for_delivery',
            'delivering',
            'delivered',
            'completed',
            'complete',
        ];

        // Your known pre-assign states (explicit allow).
       $allowed_pre = [
    'pending_vendor_ready',
    'ready_for_assignment',
    'vendor_ready',
    'pending',
    'created',
    'new',
    'unassigned',
    'awaiting_dispatch',
    'ready_for_dispatch',
    'processing',
    'manual',
    'hold',
];

        if ( in_array( $st, $blocked, true ) ) return false;
        if ( in_array( $st, $allowed_pre, true ) ) return true;

        // Unknown states: default allow (safer than blocking wrongly).
        return true;
    }

    /* ------------------------ Existing cases / anti-dup ------------------------ */

}
