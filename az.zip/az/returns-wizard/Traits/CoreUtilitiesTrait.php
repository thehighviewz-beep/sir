<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

trait Caricove_Returns_Wizard_CoreUtilities_Trait {

    protected function has_woo() {
        return function_exists( 'ccr_has_woo' ) ? ccr_has_woo() : ( class_exists( 'WooCommerce' ) && function_exists( 'wc_get_order' ) );
    }

    protected function money( $amount ) {
        return function_exists( 'ccr_money_plain' ) ? ccr_money_plain( $amount ) : number_format_i18n( (float) $amount, 2 );
    }

    protected function current_user_can_review() {
        return current_user_can( 'manage_woocommerce' ) || current_user_can( 'manage_options' );
    }

    /**
     * Refund/Return reasons (post-delivery) + never_arrived (pre-delivery allowed).
     */

private function resolve_vendor_return_address(int $vendor_id): string {
    if ($vendor_id <= 0) return '';

    $store_name        = trim((string) get_user_meta($vendor_id, '_cc_store_name', true));
    $street1           = trim((string) get_user_meta($vendor_id, '_cc_store_street_1', true));
    $street2           = trim((string) get_user_meta($vendor_id, '_cc_store_street_2', true));
    $city              = trim((string) get_user_meta($vendor_id, '_cc_store_city', true));
    $postcode          = trim((string) get_user_meta($vendor_id, '_cc_store_postcode', true));
    $country_code      = trim((string) get_user_meta($vendor_id, '_cc_store_country_code', true));
    $subdivision_label = trim((string) get_user_meta($vendor_id, '_cc_store_subdivision_label', true));

    $country_name = $country_code;
    if (function_exists('WC') && WC() && isset(WC()->countries)) {
        $countries = WC()->countries->get_countries();
        if (!empty($countries[$country_code])) {
            $country_name = $countries[$country_code];
        }
    }

    $lines = [];
    if ($store_name !== '') $lines[] = $store_name;
    if ($street1 !== '') $lines[] = $street1;
    if ($street2 !== '') $lines[] = $street2;

    $city_line = $city;
    if ($postcode !== '') {
        $city_line .= ($city_line !== '' ? ', ' : '') . $postcode;
    }
    if ($city_line !== '') $lines[] = $city_line;

    if ($country_name !== '') $lines[] = $country_name;
    if ($subdivision_label !== '') $lines[] = $subdivision_label;

    $out = trim(implode("\n", array_filter($lines)));
    if ($out !== '') return $out;

    return 'Return address will be provided after approval.';
}


private function ccv_get_post_cancel_qty_for_item(int $item_id, int $max_qty): int {
    // Your UI has a quantity field. We accept a few possible POST shapes safely.
    $candidates = [];

    foreach (['quantity', 'qty', 'cancel_qty'] as $k) {
        if (!empty($_POST[$k]) && is_array($_POST[$k])) {
            $candidates[] = $_POST[$k];
        }
    }

    $raw = null;
    foreach ($candidates as $arr) {
        if (isset($arr[$item_id])) { $raw = $arr[$item_id]; break; }
    }

    $q = is_numeric($raw) ? (int)$raw : 0;
    if ($q < 0) $q = 0;
    if ($q > $max_qty) $q = $max_qty;
    return $q;
}

private function ccv_unit_gross_from_item(\WC_Order_Item_Product $item): float {
    $ordered_qty = max(1, (int)$item->get_quantity());

    // Use subtotal + subtotal_tax to match your earlier "line value (subtotal+tax)" logic.
    $gross_line = (float)$item->get_subtotal() + (float)$item->get_subtotal_tax();

    return $gross_line / $ordered_qty;
}

private function ccv_get_commission_rate_for_shipment(int $shipment_id): float {
    global $wpdb;

    if (!class_exists('\Caricove\SellerPayouts\Ledger')) return 0.12;

    $table = \Caricove\SellerPayouts\Ledger::table();

    // Prefer the delivered row for this shipment (has gross+commission)
    $row = $wpdb->get_row(
        $wpdb->prepare("SELECT gross, commission FROM {$table} WHERE shipment_id=%d AND gross>0 ORDER BY id DESC LIMIT 1", $shipment_id),
        ARRAY_A
    );

    if (is_array($row)) {
        $g = (float)$row['gross'];
        $c = (float)$row['commission'];
        if ($g > 0 && $c >= 0) {
            $r = $c / $g;
            // Clamp hard to prevent weirdness
            if ($r < 0) $r = 0;
            if ($r > 0.50) $r = 0.50;
            return $r;
        }
    }

    return 0.12;
}

private function resolve_vendor_name(int $vendor_id): string {
    if ($vendor_id <= 0) return '';

    // Prefer display name
    $u = get_user_by('id', $vendor_id);
    if ($u && ! empty($u->display_name)) return (string) $u->display_name;

    // Fallbacks
    if ($u && ! empty($u->user_nicename)) return (string) $u->user_nicename;
    if ($u && ! empty($u->user_login)) return (string) $u->user_login;

    return '';
}

}
