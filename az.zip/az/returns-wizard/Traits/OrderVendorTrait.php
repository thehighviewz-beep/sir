<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

trait Caricove_Returns_Wizard_OrderVendor_Trait {

    protected function get_order_from_request() {
        if ( ! $this->has_woo() ) return null;

        $order_id = isset( $_GET['order_id'] ) ? absint( $_GET['order_id'] ) : 0;
        if ( ! $order_id ) return null;

        $order = wc_get_order( $order_id );
        if ( ! $order instanceof WC_Order ) return null;

        $current_user_id = get_current_user_id();
        $order_user_id   = (int) $order->get_user_id();

        if ( $current_user_id && $order_user_id === $current_user_id ) return $order;
        if ( $this->current_user_can_review() ) return $order;

        return null;
    }

    protected function get_vendor_id_for_item( WC_Order_Item_Product $item ) {
        $product_id = $item->get_product_id();
        if ( ! $product_id ) return 0;

        // If variation, try parent product author for vendor ownership truth.
        $parent_id = (int) wp_get_post_parent_id( $product_id );
        if ( $parent_id > 0 ) $product_id = $parent_id;

        $author_id = (int) get_post_field( 'post_author', $product_id );
        return $author_id > 0 ? $author_id : 0;
    }

    protected function get_default_store_address() {
        $parts = [];
        $addr1 = get_option( 'woocommerce_store_address' );
        $addr2 = get_option( 'woocommerce_store_address_2' );
        $city  = get_option( 'woocommerce_store_city' );
        $zip   = get_option( 'woocommerce_store_postcode' );
        $cntry = get_option( 'woocommerce_default_country' );

        if ( $addr1 ) $parts[] = $addr1;
        if ( $addr2 ) $parts[] = $addr2;
        if ( $city )  $parts[] = $city;
        if ( $zip )   $parts[] = $zip;
        if ( $cntry ) $parts[] = $cntry;

        return trim( implode( ', ', array_filter( $parts ) ) );
    }

protected function get_vendor_return_address($vendor_id){
    $vendor_id = (int) $vendor_id;
    if ($vendor_id <= 0) {
        return $this->get_default_store_address();
    }

    // Match store-settings preview exactly
    $store_name        = trim((string) get_user_meta($vendor_id, '_cc_store_name', true));
    $street1           = trim((string) get_user_meta($vendor_id, '_cc_store_street_1', true));
    $street2           = trim((string) get_user_meta($vendor_id, '_cc_store_street_2', true));
    $city              = trim((string) get_user_meta($vendor_id, '_cc_store_city', true));
    $postcode          = trim((string) get_user_meta($vendor_id, '_cc_store_postcode', true));
    $country_code      = trim((string) get_user_meta($vendor_id, '_cc_store_country_code', true));
    $subdivision_label = trim((string) get_user_meta($vendor_id, '_cc_store_subdivision_label', true));

    $country_name = $country_code;
    if (function_exists('WC') && WC() && isset(WC()->countries)) {
        $countries = WC()->countries->get_countries();
        if (!empty($countries[$country_code])) {
            $country_name = $countries[$country_code];
        }
    }

    $lines = [];

    if ($store_name !== '') {
        $lines[] = $store_name;
    }

    if ($street1 !== '') {
        $lines[] = $street1;
    }

    if ($street2 !== '') {
        $lines[] = $street2;
    }

    $city_line = $city;
    if ($postcode !== '') {
        $city_line .= ($city_line !== '' ? ', ' : '') . $postcode;
    }
    if ($city_line !== '') {
        $lines[] = $city_line;
    }

    if ($country_name !== '') {
        $lines[] = $country_name;
    }

    if ($subdivision_label !== '') {
        $lines[] = $subdivision_label;
    }

    $pickup_address = trim(implode("\n", array_filter($lines)));
    if ($pickup_address !== '') {
        return $pickup_address;
    }

    // Fallback: billing address
    $addr1  = trim((string) get_user_meta($vendor_id, 'billing_address_1', true));
    $addr2  = trim((string) get_user_meta($vendor_id, 'billing_address_2', true));
    $bcity  = trim((string) get_user_meta($vendor_id, 'billing_city', true));
    $bzip   = trim((string) get_user_meta($vendor_id, 'billing_postcode', true));
    $bcn    = trim((string) get_user_meta($vendor_id, 'billing_country', true));
    $bstate = trim((string) get_user_meta($vendor_id, 'billing_state', true));

    $fallback = [];
    if ($addr1 !== '') $fallback[] = $addr1;
    if ($addr2 !== '') $fallback[] = $addr2;

    $fb_line = $bcity;
    if ($bzip !== '') {
        $fb_line .= ($fb_line !== '' ? ', ' : '') . $bzip;
    }
    if ($fb_line !== '') $fallback[] = $fb_line;

    if ($bcn !== '') $fallback[] = $bcn;
    if ($bstate !== '') $fallback[] = $bstate;

    $billing_address = trim(implode("\n", array_filter($fallback)));

    return $billing_address !== '' ? $billing_address : $this->get_default_store_address();
}

    protected function order_get_meta( WC_Order $order, $key ) {
        return $order->get_meta( $key, true );
    }

    protected function order_set_meta( WC_Order $order, $key, $value ) {
        $order->update_meta_data( $key, $value );
    }

    /* ============================================================
     * LOGISTICS SOURCE OF TRUTH — DELIVERED + ITEM-SCOPED SHIPMENT STATE
     * ============================================================ */

    /** Internal caches */
    protected $ccr_ship_cache = [];        // [order_id => shipment_id[]]
    protected $ccr_item_probe_cache = [];  // ["orderId:itemId" => ['delivered'=>bool,'ts'=>int]]
    protected $ccr_item_ship_cache = [];   // ["orderId:itemId" => ['shipment_id'=>int,'status'=>string]]

private function resolve_vendor_id_for_item($order, int $item_id, $item = null): int {
    // $order can be WC_Order or similar
    if (! $order || ! method_exists($order, 'get_item')) return 0;

    $item = $order->get_item($item_id);
    if (! $item || ! method_exists($item, 'get_product')) return 0;

    $product = $item->get_product();
    if (! $product) return 0;

    $pid = (int) $product->get_id();
    if ($pid <= 0) return 0;

    // Your vendor model in the payout UI uses post_author as vendor id
    $author_id = (int) get_post_field('post_author', $pid);
    return max(0, $author_id);
}



/**
 * Best-effort delivered timestamp for a specific line item.
 * Used to gate "return request" eligibility (delivered items only).
 *
 * Returns: unix timestamp (int) or 0 if unknown/not delivered.
 */

}
