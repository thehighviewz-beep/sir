<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

trait Caricove_Returns_Wizard_HandlePost_Trait {

    protected function handle_post( \WC_Order $order ) {

    if ( ! isset( $_POST['caricove_returns_wizard_nonce'] ) ) {
        return new WP_Error( 'no_nonce', __( 'Security check failed.', 'caricove' ) );
    }

    if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['caricove_returns_wizard_nonce'] ) ), self::NONCE_ACTION ) ) {
        return new WP_Error( 'bad_nonce', __( 'Security token expired, please reload the page.', 'caricove' ) );
    }

    $order_id = isset( $_POST['order_id'] ) ? absint( $_POST['order_id'] ) : 0;
    if ( ! $order_id || $order_id !== (int) $order->get_id() ) {
        return new WP_Error( 'order_mismatch', __( 'Order mismatch. Please reload and try again.', 'caricove' ) );
    }

    $uid = (int) get_current_user_id();
    if ( $uid > 0 ) {
        $tk   = $this->throttle_key( $order->get_id(), $uid );
        $last = (int) get_transient( $tk );
        if ( $last && ( time() - $last ) < self::SUBMIT_THROTTLE_SECONDS ) {
            return new WP_Error( 'throttled', __( 'Please wait a moment and try again.', 'caricove' ) );
        }
        set_transient( $tk, time(), self::SUBMIT_THROTTLE_SECONDS );
    }

    $raw_items = ( isset( $_POST['items'] ) && is_array( $_POST['items'] ) ) ? wp_unslash( $_POST['items'] ) : [];
    if ( empty( $raw_items ) ) {
        return new WP_Error( 'no_items', __( 'No items were submitted.', 'caricove' ) );
    }

    $refund_matrix = $this->get_refund_reason_matrix();
    $cancel_matrix = $this->get_cancel_reason_matrix();

    $mode = ''; // 'return' or 'cancel'
    $now  = time();

 $items_meta   = [];
    $return_cases = [];
    $requested_total_gross = 0.0;
    $shipping_refund_selected_assigned = false;

    // Track how many qualifying no-return rows have already consumed a slot
    // during this same submit so only the first two eligible rows can auto-qualify.
    $current_submit_returnless_reserved = 0;
    $request_group_id = 'REQ-' . $order->get_id() . '-' . $now;

    
    // For cancellation immediate refund creation
    $cancel_line_items_map = [];
    $cancel_reason_notes   = [];
    $cancelled_item_ids    = [];


    foreach ( $order->get_items() as $item_id => $item ) {
        if ( ! ( $item instanceof WC_Order_Item_Product ) ) continue;

        $submitted = $raw_items[ $item_id ] ?? null;
        if ( ! is_array( $submitted ) ) continue;

        $qty_req = isset( $submitted['qty'] ) ? (int) $submitted['qty'] : 0;
        if ( $qty_req <= 0 ) continue;

        $reason = isset( $submitted['reason'] ) ? sanitize_text_field( (string) $submitted['reason'] ) : '';
        if ( ! $reason ) {
            return new WP_Error( 'reason_missing', __( 'Please select a reason for each item you want to request.', 'caricove' ) );
        }

        $max_qty = (int) $item->get_quantity();
        if ( $max_qty <= 0 ) continue;
        if ( $qty_req > $max_qty ) $qty_req = $max_qty;

        $delivered_truth = $this->item_is_delivered_truth( $order, $item_id, $item );

        $is_refund_reason = isset( $refund_matrix[ $reason ] );
        $is_cancel_reason = isset( $cancel_matrix[ $reason ] );

        if ( ! $is_refund_reason && ! $is_cancel_reason ) {
            return new WP_Error( 'reason_invalid', __( 'Invalid reason selected. Please reload and try again.', 'caricove' ) );
        }

        // Determine requested mode (do not allow mixing in one submit)
        $this_mode = $is_cancel_reason ? 'cancel' : 'return';
        if ( $mode === '' ) $mode = $this_mode;
        if ( $mode !== $this_mode ) {
            return new WP_Error( 'mixed_modes', __( 'Please submit cancellations and returns separately (one type per request).', 'caricove' ) );
        }

        // Mode guards
        if ( $mode === 'return' ) {
            // Refund reasons (except never_arrived) require delivery truth.
            if ( $reason !== 'never_arrived' && ! $delivered_truth ) {
                return new WP_Error( 'not_delivered', __( 'You can request a return/refund after the item is delivered.', 'caricove' ) );
            }
        } else {
            // Cancellation requires NOT delivered and cancellable
            if ( $delivered_truth ) {
                return new WP_Error( 'cannot_cancel_delivered', __( 'Delivered items cannot be cancelled. Please request a return instead.', 'caricove' ) );
            }
            if ( ! $this->item_is_cancellable_truth( $order, $item_id, $item ) ) {
                return new WP_Error( 'cannot_cancel_assigned', __( 'Items can’t be cancelled once assigned or on the way.', 'caricove' ) );
            }
        }

        // Prevent duplicate open cases: rely on existing cases bundle
        $remaining = $this->get_item_remaining_requestable_qty( $order, $item_id, $max_qty );
        if ( $remaining <= 0 ) {
            return new WP_Error( 'already_requested', __( 'A request for this item is already in progress.', 'caricove' ) );
        }
        if ( $qty_req > $remaining ) $qty_req = $remaining;

        // Reason attributes + policy evaluation
        $line_total = (float) $item->get_total();
        $line_tax   = (float) $item->get_total_tax();
        $line_gross = $line_total + $line_tax;

        $per_unit_gross = $max_qty > 0 ? ( $line_gross / $max_qty ) : 0.0;
        $req_gross      = $per_unit_gross * $qty_req;
        $requested_total_gross += $req_gross;

        $row    = $is_cancel_reason ? $cancel_matrix[ $reason ] : $refund_matrix[ $reason ];
        $label  = (string) ( $row['label'] ?? $reason );

        $policy = $is_cancel_reason
            ? [
                'fault'                 => (string) ( $row['fault'] ?? 'customer' ),
                'window_days'           => (int) ( $row['return_window_days'] ?? 30 ),
                'return_required'       => false,
                'decision_code'         => 'CANCELLATION_ACCEPTED',
                'refund_timing'         => 'immediate',
                'shipping_payer'        => 'platform',
                'requires_evidence'     => false,
                'low_value_refund_only' => false,
                'manual_review'         => false,
            ]
         : $this->evaluate_return_policy(
                $order,
                $item,
                $reason,
                $qty_req,
                $per_unit_gross,
                $delivered_truth,
                $req_gross,
                (int) $current_submit_returnless_reserved
            );

        if ( ! empty( $policy['blocked'] ) ) {
            $error_code = ! empty( $policy['error_code'] ) ? (string) $policy['error_code'] : 'request_unavailable';
            $error_text = ! empty( $policy['error'] )
                ? (string) $policy['error']
                : __( 'This request cannot be processed automatically.', 'caricove' );

            return new WP_Error( $error_code, $error_text );
        }

       $fault                 = (string) ( $policy['fault'] ?? 'unknown' );
        $days                  = (int) ( $policy['window_days'] ?? 30 );
        $return_required       = ! empty( $policy['return_required'] );
        $decision_code         = (string) ( $policy['decision_code'] ?? 'REQUEST_ACCEPTED' );
        $refund_timing         = (string) ( $policy['refund_timing'] ?? 'after_review' );
        $shipping_payer        = (string) ( $policy['shipping_payer'] ?? 'platform' );
        $requires_evidence     = ! empty( $policy['requires_evidence'] );
        $low_value_refund_only = ! empty( $policy['low_value_refund_only'] );
        $manual_review         = ! empty( $policy['manual_review'] );

        // Reserve one no-return slot per qualifying row so only the first two
        // eligible rows in the same submit can stay returnless.
        if (
            $mode === 'return'
            && $low_value_refund_only
            && ! $return_required
            && ! $manual_review
            && strtoupper( $decision_code ) === 'REFUND_ONLY'
            && $reason !== 'never_arrived'
        ) {
            $current_submit_returnless_reserved++;
        }
        $item_received_flag    = ( $mode === 'return' && $reason !== 'never_arrived' && $delivered_truth ) ? 1 : 0;
       $refund_execution_mode = ( $mode === 'return' )
            ? ( $reason === 'never_arrived' ? 'never_received' : ( $return_required ? 'return_required' : 'returnless' ) )
            : 'returnless';

        $shipping_refund_selected_default = 0;

        if (
            $refund_execution_mode === 'returnless'
            && $fault !== 'customer'
            && $reason !== 'never_arrived'
            && ! $shipping_refund_selected_assigned
        ) {
            $shipping_refund_selected_default = 1;
            $shipping_refund_selected_assigned = true;
        } elseif ( $reason === 'never_arrived' && ! $shipping_refund_selected_assigned ) {
            $shipping_refund_selected_default = 1;
            $shipping_refund_selected_assigned = true;
        }

        $delivered_at = 0;
        if ( $delivered_truth ) {
            $delivered_at = (int) $this->item_best_delivered_at_ts( $order, $item_id, $item );
        }

        $window_closes = ( $delivered_at > 0 ) ? ( $delivered_at + ( $days * 86400 ) ) : 0;

        if ( $mode === 'return' && $delivered_at > 0 && $days > 0 && $now > $window_closes ) {
            return new WP_Error(
                'window_expired',
                __( 'This request can’t be processed automatically. Please contact support if you need help.', 'caricove' )
            );
        }

        // Vendor routing
        $vendor_id   = (int) $this->resolve_vendor_id_for_item( $order, $item_id, $item );
        $vendor_name = $vendor_id ? (string) $this->resolve_vendor_name( $vendor_id ) : '';
        $return_address = $vendor_id ? (string) $this->resolve_vendor_return_address( $vendor_id ) : '';

        // Canonical shipment linkage (bank + returns surfaces must agree on one shipment chain)
        $shipment_id = 0;
        if ( method_exists( $this, 'ccr_find_shipment_for_item' ) ) {
            $ship_probe = (array) $this->ccr_find_shipment_for_item( $order, $item_id );
            $shipment_id = isset( $ship_probe['shipment_id'] ) ? (int) $ship_probe['shipment_id'] : 0;
        }
        if ( $shipment_id <= 0 && function_exists( 'wc_get_order_item_meta' ) ) {
            foreach ( [ '_cc_item_shipment_id', '_cc_shipment_id', '_cc_shipment_post_id' ] as $shipment_key ) {
                $shipment_id = (int) wc_get_order_item_meta( $item_id, $shipment_key, true );
                if ( $shipment_id > 0 ) { break; }
            }
        }

        // Canonical case type + status (these are the keys your debug + downstream tooling expects)
        $case_type   = ( $mode === 'cancel' ) ? 'cancellation' : 'return';
        $case_status = ( $mode === 'cancel' ) ? ( ( $qty_req < $max_qty ) ? 'cancelled_partial' : 'cancelled' ) : 'requested';

        // Deterministic RMA id
        $anchor_ts = $delivered_at > 0 ? $delivered_at : (int) $order->get_date_created()->getTimestamp();
        $rma_id = 'RCC-' . $order->get_id() . '-' . $item_id . ( $case_type === 'cancellation' ? '-C-' : '-' ) . (int) $anchor_ts;

        // Delta quantity support (partial cancellations on a single WC line item).
        $cancel_qty_delta = 0;
        $cancel_qty_total = 0;
        if ( $mode === 'cancel' ) {
            $prev_total = (int) wc_get_order_item_meta( $item_id, CC_RETURNS_ITEM_META_PREFIX . 'cancel_qty_total', true );
            if ( $prev_total < 0 ) $prev_total = 0;
            $cancel_qty_delta = (int) $qty_req;
            if ( $cancel_qty_delta < 0 ) $cancel_qty_delta = 0;
            if ( $cancel_qty_delta > $max_qty ) $cancel_qty_delta = $max_qty;

            $cancel_qty_total = $prev_total + $cancel_qty_delta;
            if ( $cancel_qty_total > $max_qty ) $cancel_qty_total = $max_qty;
        }


       $case_status_effective = $case_status;
        if ( $mode === 'cancel' ) {
            $case_status_effective = ( $cancel_qty_total >= $max_qty ) ? 'cancelled' : 'cancelled_partial';
        } elseif ( $manual_review ) {
            $case_status_effective = 'info_requested';
        }
        // Per-item metas written as _caricove_<key>
        $items_meta[ $item_id ] = [
            // required by your UIs and debugging
            'rma_id'       => $rma_id,
            'request_group_id' => $request_group_id,
            'case_type'    => $case_type,      // => _caricove_case_type
            'case_status'  => $case_status_effective,    // => _caricove_case_status

            // legacy compat (existing UIs)
            'return_status'        => $case_status_effective, // => _caricove_return_status (legacy)
            'qty_requested'        => $qty_req,
            'qty_return_requested' => $qty_req,
            'qty_refunded'         => 0,

            // delta-cancel accounting
            'cancel_qty_delta'   => ( $mode === 'cancel' ) ? (int) $cancel_qty_delta : 0,
            'cancel_qty_total'   => ( $mode === 'cancel' ) ? (int) $cancel_qty_total : 0,

           'reason_code'           => $reason,
            'reason_label'          => $label,
            'fault'                 => $fault,
            'decision_code'         => $decision_code,
            'refund_execution_mode' => (string) $refund_execution_mode,
            'refund_timing'         => $refund_timing,
            'shipping_payer'        => $shipping_payer,
            'requires_evidence' => $requires_evidence ? 1 : 0,
            'manual_review' => $manual_review ? 1 : 0,
            'low_value_refund_only' => $low_value_refund_only ? 1 : 0,

            'return_required' => $return_required ? 1 : 0,
            'refund_line_total' => function_exists( 'wc_format_decimal' ) ? wc_format_decimal( $req_gross, wc_get_price_decimals() ) : (string) $req_gross,

            'vendor_id'      => $vendor_id,
            'vendor_name'    => $vendor_name,
            'return_address' => $return_address,

            'request_only'   => ( $mode === 'cancel' ) ? 0 : 1,
            'delivered_at'   => (int) $delivered_at,
            'window_closes'  => (int) $window_closes,
        ];

        $return_cases[] = [
            'rma_id'           => $rma_id,
            'case_id'          => $rma_id,
            'order_id'         => (int) $order->get_id(),
            'order_number'     => (string) $order->get_order_number(),
            'request_group_id' => $request_group_id,
            'parent_order_id'  => (int) $order->get_parent_id(),
            'item_id'          => (int) $item_id,
            'order_item_id'    => (int) $item_id,
            'product_id'       => (int) $item->get_product_id(),
            'product_name'     => (string) $item->get_name(),
            'shipment_id'      => (int) $shipment_id,
            'qty'              => (int) $qty_req,
            'qty_requested'    => (int) $qty_req,
            'cancel_qty_delta' => ( $mode === 'cancel' ) ? (int) $cancel_qty_delta : 0,
            'cancel_qty_total' => ( $mode === 'cancel' ) ? (int) $cancel_qty_total : 0,
            'reason_code'      => $reason,
            'reason_label'     => $label,
            'reason_text'      => $label,
            'fault'            => $fault,
            'initial_fault'    => $fault,
            'decision_code'    => $decision_code,
            'refund_timing'    => $refund_timing,
            'shipping_payer'   => $shipping_payer,
            'requires_evidence'=> $requires_evidence ? true : false,
            'manual_review'    => $manual_review ? true : false,
            'low_value_refund_only' => $low_value_refund_only ? true : false,
            'return_required'  => $return_required ? true : false,
            'deadline'         => (int) $window_closes,
            'currency'         => (string) $order->get_currency(),
            'requested_amount' => round( (float) $req_gross, 2 ),
            'amount_requested' => round( (float) $req_gross, 2 ),
            'refund_suggested' => round( (float) $req_gross, 2 ),
            'refund_amount'    => 0,
            'amount_refunded'  => 0,

            'status'           => $case_status_effective,
            'created'          => (int) $now,

            'vendor_id'        => (int) $vendor_id,
            'vendor_name'      => $vendor_name,
            'return_address'   => $return_address,

            'case_type'        => $case_type,
            'delivered_at'     => (int) $delivered_at,
            'window_days'      => (int) $days,
            'request_only'     => ( $mode === 'cancel' ) ? 0 : 1,
            'item_received_flag' => (int) $item_received_flag,
            'refund_execution_mode' => (string) $refund_execution_mode,
           'shipping_refund_selected' => (int) $shipping_refund_selected_default,
            'item_refund_amount_customer' => round( (float) $req_gross, 2 ),
            'outbound_shipping_refund_amount_customer' => (
                $refund_execution_mode === 'returnless'
                && $fault !== 'customer'
                && $reason !== 'never_arrived'
            ) ? (float) $order->get_shipping_total() : 0.0,
            'return_shipping_cost_internal' => 0.0,
            'shipping_liability_amount_internal' => 0.0,
            'shipping_liability_party' => '',
            'shipping_posting_status' => '',
            'shipping_visibility_status' => '',
            'shipping_posting_key' => '',
            'shipping_reversal_parent_key' => '',
        ];

        // Build Woo refund line-items map for cancellation only (immediate)
        if ( $mode === 'cancel' ) {
            $cancelled_item_ids[] = (int) $item_id;

            $per_unit_total = $max_qty > 0 ? ( $line_total / $max_qty ) : 0.0;

            $refund_total_line = $per_unit_total * $qty_req;

            $taxes = $item->get_taxes();
            $refund_tax_by_rate = [];
            if ( is_array( $taxes ) && ! empty( $taxes['total'] ) && is_array( $taxes['total'] ) ) {
                foreach ( $taxes['total'] as $rate_id => $tax_amount ) {
                    $tax_amount = (float) $tax_amount;
                    $per_unit_rate_tax = $max_qty > 0 ? ( $tax_amount / $max_qty ) : 0.0;
                    $refund_tax_by_rate[ (int) $rate_id ] = wc_format_decimal( $per_unit_rate_tax * $qty_req, wc_get_price_decimals() );
                }
            } else {
                if ( $line_tax > 0 ) {
                    $per_unit_tax = $max_qty > 0 ? ( $line_tax / $max_qty ) : 0.0;
                    $refund_tax_by_rate[0] = wc_format_decimal( $per_unit_tax * $qty_req, wc_get_price_decimals() );
                }
            }

            $cancel_line_items_map[ (int) $item_id ] = [
                'qty'          => (int) $qty_req,
                'refund_total' => wc_format_decimal( $refund_total_line, wc_get_price_decimals() ),
                'refund_tax'   => $refund_tax_by_rate,
            ];

            $cancel_reason_notes[] = $item->get_name() . ' — ' . $label;
        }
    }

    if ( empty( $return_cases ) ) {
        return new WP_Error( 'no_selection', __( 'Choose at least one item and quantity to request.', 'caricove' ) );
    }

    $requested_amount = (float) $requested_total_gross;
    if ( $requested_amount <= 0 ) {
        return new WP_Error( 'zero_amount', __( 'Calculated amount is zero. Please adjust your quantities.', 'caricove' ) );
    }

    $exec = null;

    // Apply cancellation immediately (creates Woo refund record)
    if ( $mode === 'cancel' ) {
        try {
            $reason_note = 'Caricove cancellation: ' . implode( ' | ', array_filter( $cancel_reason_notes ) );
            $exec = $this->apply_cancellation_now( $order, $cancel_line_items_map, (float) $requested_amount, $reason_note );

            // Adjust shipment(s) and payouts deterministically
            $this->apply_cancellation_logistics_now( $order, $cancel_line_items_map, ( is_array($exec) && ! empty($exec['refund_id']) ? (int)$exec['refund_id'] : 0 ), $reason_note );

        } catch ( \Throwable $e ) {
            return new WP_Error( 'cancel_apply_failed', sprintf( __( 'Cancellation failed to apply: %s', 'caricove' ), $e->getMessage() ) );
        }

        // Annotate execution facts into metas/cases
        foreach ( $items_meta as $iid => &$m ) {
            if ( ! is_array( $m ) ) continue;
            if ( (string) ( $m['case_type'] ?? '' ) !== 'cancellation' ) continue;

            $m['executed']       = 1;
            $m['cancelled_at']   = (int) $now;
            $m['refund_id']      = (int) ( $exec['refund_id'] ?? 0 );
            $m['refund_payment'] = (int) ( $exec['refund_payment'] ?? 0 );
        }
        unset( $m );

        foreach ( $return_cases as &$c ) {
            if ( ! is_array( $c ) ) continue;
            if ( (string) ( $c['case_type'] ?? '' ) !== 'cancellation' ) continue;

            $c['executed']       = 1;
            $c['cancelled_at']   = (int) $now;
            $c['refund_id']      = (int) ( $exec['refund_id'] ?? 0 );
            $c['refund_payment'] = (int) ( $exec['refund_payment'] ?? 0 );
            $c['refund_amount']  = round( (float) ( $c['requested_amount'] ?? 0 ), 2 );
            $c['amount_refunded']= round( (float) ( $c['requested_amount'] ?? 0 ), 2 );
            $c['financial_status']= 'completed';
        }
        unset( $c );
    }


    // Canonical bank cases are the system truth; legacy order meta becomes a mirror projection.
    if ( class_exists( '\Caricove\Bank\BankRefundCases' ) ) {
        foreach ( $return_cases as $idx => $case_payload ) {
            if ( ! is_array( $case_payload ) ) continue;

            $line_item = $order->get_item( (int) ( $case_payload['item_id'] ?? 0 ) );
            $context = [
                'customer_id'     => (int) $order->get_customer_id(),
                'currency'        => (string) $order->get_currency(),
                'order_number'    => (string) $order->get_order_number(),
                'parent_order_id' => (int) $order->get_parent_id(),
                'product_id'      => ( $line_item instanceof WC_Order_Item_Product ) ? (int) $line_item->get_product_id() : (int) ( $case_payload['product_id'] ?? 0 ),
                'product_name'    => ( $line_item instanceof WC_Order_Item_Product ) ? (string) $line_item->get_name() : (string) ( $case_payload['product_name'] ?? '' ),
            ];

            $canonical_case = \Caricove\Bank\BankRefundCases::upsert_legacy_case_for_order( (int) $order->get_id(), $case_payload, $context );
            if ( is_array( $canonical_case ) ) {
                $return_cases[ $idx ] = \Caricove\Bank\BankRefundCases::project_case_to_legacy( $canonical_case );
            }
        }
    }

    // Summary used by UIs
    $summary = [
        'amount'         => function_exists('wc_format_decimal') ? wc_format_decimal( $requested_amount, wc_get_price_decimals() ) : (string) $requested_amount,
        'is_full'        => 0,
        'items'          => $items_meta,
        'timestamp'      => (int) $now,
        'return_cases'   => $return_cases,
        'request_only'   => ( $mode === 'cancel' ? 0 : 1 ),
        'status'         => ( $mode === 'cancel' ? 'cancelled' : 'requested' ),
        'refund_id'      => ( $mode === 'cancel' ? (int) ( $exec['refund_id'] ?? 0 ) : 0 ),
        'cancelled_at'   => ( $mode === 'cancel' ? (int) $now : 0 ),
        'refund_payment' => ( $mode === 'cancel' ? (int) ( $exec['refund_payment'] ?? 0 ) : 0 ),
    ];

    $this->order_set_meta( $order, CC_RETURNS_META_LAST_SUMMARY, $summary );

    // Persist cases (append, dedupe by rma_id)
    $existing = $this->order_get_meta( $order, CC_RETURNS_META_CASES );
    $existing = is_array( $existing ) ? $existing : [];

    $seen = [];
    foreach ( $existing as $c ) {
        if ( is_array( $c ) && ! empty( $c['rma_id'] ) ) $seen[ (string) $c['rma_id'] ] = true;
    }
    foreach ( $return_cases as $c ) {
        $rid = is_array( $c ) && ! empty( $c['rma_id'] ) ? (string) $c['rma_id'] : '';
        if ( $rid && isset( $seen[ $rid ] ) ) continue;
        if ( $rid ) $seen[ $rid ] = true;
        $existing[] = $c;
    }
    $this->order_set_meta( $order, CC_RETURNS_META_CASES, $existing );

    // Mirror to parent for discovery
    $parent_id = (int) $order->get_parent_id();
    if ( $parent_id > 0 ) {
        $p = wc_get_order( $parent_id );
        if ( $p instanceof WC_Order ) {
            $pc = $this->order_get_meta( $p, CC_RETURNS_META_CASES );
            $pc = is_array( $pc ) ? $pc : [];

            $pseen = [];
            foreach ( $pc as $c ) {
                if ( is_array( $c ) && ! empty( $c['rma_id'] ) ) $pseen[ (string) $c['rma_id'] ] = true;
            }
            foreach ( $return_cases as $c ) {
                $rid = is_array( $c ) && ! empty( $c['rma_id'] ) ? (string) $c['rma_id'] : '';
                if ( $rid && isset( $pseen[ $rid ] ) ) continue;
                if ( $rid ) $pseen[ $rid ] = true;
                $pc[] = $c;
            }

            $this->order_set_meta( $p, CC_RETURNS_META_CASES, $pc );
            $this->order_set_meta( $p, CC_RETURNS_META_LAST_SUMMARY, $summary );
            $p->save();
        }
    }

    // Per-line meta: write only what we declared above
    foreach ( $items_meta as $item_id => $meta_arr ) {
        if ( ! is_array( $meta_arr ) ) continue;
        foreach ( $meta_arr as $k => $v ) {
            wc_update_order_item_meta( $item_id, CC_RETURNS_ITEM_META_PREFIX . $k, $v );
        }
    }

    // Persist
    $order->save();

   if ( ! empty( $return_cases ) ) {
        do_action( CC_RETURNS_HOOK_RETURN_CASES, $order, $return_cases );

        foreach ( $return_cases as $case ) {
            if ( ! is_array( $case ) ) continue;

            $is_returnless = (
                (string) ( $case['refund_execution_mode'] ?? '' ) === 'returnless'
                && empty( $case['return_required'] )
                && (string) ( $case['case_type'] ?? '' ) === 'return'
            );

            if ( ! $is_returnless ) continue;

            do_action( 'caricove_auto_create_ticket', [
                'source'        => 'returns_wizard',
                'mode'          => 'returnless_liability_review',
                'order_id'      => (int) $order->get_id(),
                'order_number'  => (string) $order->get_order_number(),
                'customer_id'   => (int) $order->get_customer_id(),
                'rma_id'        => (string) ( $case['rma_id'] ?? '' ),
                'case_id'       => (string) ( $case['case_id'] ?? '' ),
                'item_id'       => (int) ( $case['item_id'] ?? 0 ),
                'order_item_id' => (int) ( $case['order_item_id'] ?? 0 ),
                'product_id'    => (int) ( $case['product_id'] ?? 0 ),
                'product_name'  => (string) ( $case['product_name'] ?? '' ),
                'shipment_id'   => (int) ( $case['shipment_id'] ?? 0 ),
                'vendor_uid'    => (int) ( $case['vendor_id'] ?? 0 ),
                'vendor_name'   => (string) ( $case['vendor_name'] ?? '' ),
                'reason_code'   => (string) ( $case['reason_code'] ?? '' ),
                'reason_label'  => (string) ( $case['reason_label'] ?? '' ),
                'initial_fault' => (string) ( $case['initial_fault'] ?? $case['fault'] ?? 'unknown' ),
                'amount'        => (float) ( $case['requested_amount'] ?? 0 ),
                'currency'      => (string) ( $case['currency'] ?? $order->get_currency() ),
            ] );
        }
    }

    // Order note
    if ( $mode === 'cancel' ) {
        $order->add_order_note( sprintf(
            'Caricove wizard: cancellation applied immediately. Amount: %s. Refund record ID: #%d. Gateway refund attempted: %s.',
            $this->money( $requested_amount ),
            (int) ( $exec['refund_id'] ?? 0 ),
            ! empty( $exec['refund_payment'] ) ? 'yes' : 'no'
        ) );
        return [
            'ok'            => 1,
            'mode'          => 'cancel',
            'refund_id'     => (int) ( $exec['refund_id'] ?? 0 ),
            'refund_payment'=> (int) ( $exec['refund_payment'] ?? 0 ),
        ];
    }

    $order->add_order_note( sprintf(
        'Caricove wizard: return request submitted for review. Requested amount: %s. No refund has been applied yet.',
        $this->money( $requested_amount )
    ) );

    return [
        'ok'   => 1,
        'mode' => 'refund',
    ];

}

}