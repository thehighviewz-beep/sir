# Install

1. Put `returns-wizard-loader.php` in `/wp-content/mu-plugins/`
2. Put the entire `returns-wizard/` folder in `/wp-content/mu-plugins/returns-wizard/`
3. Remove or disable the old single-file monolith after confirming this split loads correctly.

This is a structural split of the original `returns-wizard (12).php` file.
No hook names, constants, shortcode name, or core method names were changed.
