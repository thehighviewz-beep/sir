# Caricove Returns Wizard — Dependency Map

UI asks for action
→ Domain verifies truth
→ Policy decides outcome
→ Finance moves money
→ Persistence records truth
→ UI reflects truth

## Primary files

- `returns-wizard.php` — main MU-loaded class shell
- `bootstrap.php` — constants + helper fallbacks
- `Traits/PolicyTrait.php` — refund/cancel rules and requestability
- `Traits/ShipmentTrait.php` — shipment truth and delivery logic
- `Traits/FinanceTrait.php` — cancellation refund + logistics payout adjustment
- `Traits/HandlePostTrait.php` — request handling and canonical writes
- `Traits/RenderTrait.php` — shortcode + UI rendering
- `Traits/AssetsTrait.php` — CSS/JS enqueue
