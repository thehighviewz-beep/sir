<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

require_once __DIR__ . '/bootstrap.php';
require_once __DIR__ . '/Traits/CoreUtilitiesTrait.php';
require_once __DIR__ . '/Traits/PolicyTrait.php';
require_once __DIR__ . '/Traits/OrderVendorTrait.php';
require_once __DIR__ . '/Traits/ShipmentTrait.php';
require_once __DIR__ . '/Traits/CasesTrait.php';
require_once __DIR__ . '/Traits/AssetsTrait.php';
require_once __DIR__ . '/Traits/RenderTrait.php';
require_once __DIR__ . '/Traits/FinanceTrait.php';
require_once __DIR__ . '/Traits/HandlePostTrait.php';

if ( ! class_exists( 'Caricove_Returns_Wizard_V2' ) ) {

class Caricove_Returns_Wizard_V2 {
    use Caricove_Returns_Wizard_CoreUtilities_Trait;
    use Caricove_Returns_Wizard_Policy_Trait;
    use Caricove_Returns_Wizard_OrderVendor_Trait;
    use Caricove_Returns_Wizard_Shipment_Trait;
    use Caricove_Returns_Wizard_Cases_Trait;
    use Caricove_Returns_Wizard_Assets_Trait;
    use Caricove_Returns_Wizard_Render_Trait;
    use Caricove_Returns_Wizard_Finance_Trait;
    use Caricove_Returns_Wizard_HandlePost_Trait;

    const VER                 = '1.5.1';
    const NONCE_ACTION        = 'caricove_returns_wizard_v2';

    /**
     * Anti-abuse threshold:
     * If per-unit line value is BELOW this amount, NO physical return is required.
     */
    const NO_RETURN_THRESHOLD = 3.50;

    /**
     * Basic submit throttle (seconds) per user+order to prevent spam/double-clicks.
     */
    const SUBMIT_THROTTLE_SECONDS = 10;

    public function __construct() {
        add_shortcode( 'caricove_returns_wizard', [ $this, 'shortcode' ] );
        add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_assets' ] );
    }
}

new Caricove_Returns_Wizard_V2();

}
