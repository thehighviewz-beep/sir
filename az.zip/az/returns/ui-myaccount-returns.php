<?php

if (!function_exists('caricove_order_details_url')) {
    function caricove_order_details_url($order_id, $order_item_id = 0) {
        $order_id = (int)$order_id;
        $order_item_id = (int)$order_item_id;
        $base = site_url('/order-details/');
        $args = ['order_id' => $order_id];
        if ($order_item_id > 0) $args['item_id'] = $order_item_id;
        return add_query_arg($args, $base);
    }
}

/**
 * Plugin Name: Caricove — Customer Returns UI (My Account) v2.1.1 (Perfect)
 * Description: Customer-facing Returns UI. Reads canonical wizard cases (_caricove_return_cases), parent/sub-order safe, fallback to item metas. Adds returnless refund timeline + terminal label flip + refunded amount copy + reliable support launcher + requested button/search tweaks.
 * Version: 2.1.1
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }


if ( ! function_exists( 'cccxr_case_is_shipping_only_pre_return' ) ) {
    function cccxr_case_is_shipping_only_pre_return( array $case ) : bool {
        $financial_status = sanitize_key( (string) ( $case['financial_status'] ?? '' ) );
        $decision_code    = strtoupper( trim( (string) ( $case['decision_code'] ?? '' ) ) );
        $return_required  = ! empty( $case['return_required'] ) || $decision_code === 'RETURN_REQUIRED';
        $qty_received     = (int) ( $case['qty_received'] ?? 0 );
        $item_received    = ! empty( $case['item_received_flag'] ) || $qty_received > 0;
        $shipping_amount  = (float) ( $case['outbound_shipping_refund_amount_customer'] ?? 0 );
        $item_amount      = (float) ( $case['item_refund_amount_customer'] ?? 0 );

        return $return_required
            && ! $item_received
            && $shipping_amount > 0
            && $item_amount <= 0
            && in_array( $financial_status, [ 'shipping_posted', 'refund_posted' ], true );
    }
}


/* ============================================================
 * CANONICAL META (DO NOT CHANGE)
 * ============================================================ */
if ( ! defined( 'CC_RETURNS_META_CASES' ) )        define( 'CC_RETURNS_META_CASES', '_caricove_return_cases' );
if ( ! defined( 'CC_RETURNS_META_LAST_SUMMARY' ) ) define( 'CC_RETURNS_META_LAST_SUMMARY', '_caricove_last_refund_summary' );








add_action( 'template_redirect', function () {

    $path = parse_url( $_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH );
    if ( ! $path ) { return; }

    $path = rtrim( $path, '/' );

    // Only intercept the deep-link style URL (with args), not normal help browsing.
    if ( $path !== '/help/returns' ) { return; }

    if ( empty($_GET['order_id']) && empty($_GET['item_id']) && empty($_GET['product_id']) && empty($_GET['rma']) ) {
        return;
    }

    $target = home_url( '/returns-tab/' );

    $args = [];
    foreach ( ['order_id','item_id','product_id','rma'] as $k ) {
        if ( isset($_GET[$k]) ) {
            $args[$k] = sanitize_text_field( wp_unslash( (string) $_GET[$k] ) );
        }
    }

    if ( ! empty($args) ) {
        $target = add_query_arg( $args, $target );
    }

    wp_safe_redirect( $target, 302 );
    exit;

}, 0 );



/* ============================================================
 * HELPERS
 * ============================================================ */
function cccxr_money_plain( $amount ) {
    $amount = is_numeric( $amount ) ? (float) $amount : 0.0;
    if ( $amount <= 0 ) return '';
    if ( function_exists( 'wc_price' ) ) return wp_strip_all_tags( wc_price( $amount ) );
    return '$' . number_format( $amount, 2 );
}

function cccxr_case_get_refund_amount( $case ) {
    if ( ! is_array( $case ) ) return 0.0;

    foreach ( [
        'refund_amount',
        'refund_total',
        'refunded_amount',
        'amount_refunded',
        'refund_value',
        'refund',
        'refund_usd',
        'refund_gyd',
    ] as $k ) {
        if ( isset( $case[ $k ] ) && is_numeric( $case[ $k ] ) ) {
            $v = (float) $case[ $k ];
            if ( $v > 0 ) return $v;
        }
    }
    return 0.0;
}

/**
 * ROOT ORDER resolver (gospel truth)
 * - UI must anchor to the ROOT (parent) order when sub-orders exist.
 * - Deep-links must match the ROOT id, not whichever sub-order happened to be scanned.
 */
function cccxr_get_root_order( $order ) {
    if ( ! $order instanceof WC_Order ) return null;
    $pid = (int) $order->get_parent_id();
    if ( $pid > 0 ) {
        $p = wc_get_order( $pid );
        if ( $p instanceof WC_Order ) return $p;
    }
    return $order;
}

/**
 * If a deep-link passes a sub-order id, normalize it to root.
 */
function cccxr_focus_to_root_order_id( $maybe_order_id ) {
    $maybe_order_id = absint( $maybe_order_id );
    if ( ! $maybe_order_id ) return 0;
    $o = wc_get_order( $maybe_order_id );
    if ( ! $o instanceof WC_Order ) return $maybe_order_id;
    $root = cccxr_get_root_order( $o );
    return $root instanceof WC_Order ? (int) $root->get_id() : $maybe_order_id;
}

/** 
 * Title dedupe + REAL variation pills (order-item truth)
 */
function cccxr_title_and_pills_from_order_item( $root_order_id, $order_item_id, $fallback_title = '' ) {
    $out = [ 'title' => (string) $fallback_title, 'pills_html' => '', 'has_pills' => false ];

    $root_order_id  = absint( $root_order_id );
    $order_item_id  = absint( $order_item_id );
    $fallback_title = (string) $fallback_title;

    if ( ! $root_order_id || ! $order_item_id || ! function_exists('wc_get_order') ) return $out;

    $order = wc_get_order( $root_order_id );
    if ( ! $order instanceof WC_Order ) return $out;

    $item = $order->get_item( $order_item_id );
    if ( ! $item || ! is_object($item) || ! method_exists($item,'get_product') ) return $out;

    $product = $item->get_product();

    // DEDUPE title: if variation, show parent title
    if ( $product && is_object($product) ) {
        if ( method_exists($product,'is_type') && $product->is_type('variation') && method_exists($product,'get_parent_id') ) {
            $pid = (int) $product->get_parent_id();
            if ( $pid > 0 ) {
                $pt = get_the_title( $pid );
                if ( $pt ) $out['title'] = (string) $pt;
            }
        } else {
            $nm = method_exists($product,'get_name') ? (string) $product->get_name() : '';
            if ( $nm !== '' ) $out['title'] = $nm;
        }
    }

    // Variation attributes (truth)
    $raw = [];
    if ( $product && is_object($product) && method_exists($product,'is_type') && $product->is_type('variation') && method_exists($product,'get_variation_attributes') ) {
        $raw = (array) $product->get_variation_attributes();
    }

    // Fallback: order-item meta keys attribute_*
    if ( empty($raw) && method_exists($item,'get_meta_data') ) {
        foreach ( (array) $item->get_meta_data() as $md ) {
            if ( ! is_object($md) || ! method_exists($md,'get_data') ) continue;
            $d = (array) $md->get_data();
            $k = isset($d['key']) ? (string) $d['key'] : '';
            $v = $d['value'] ?? '';
            if ( $k === '' || strpos($k,'attribute_') !== 0 ) continue;
            if ( is_array($v) || is_object($v) ) continue;
            $raw[$k] = (string) $v;
        }
    }

    if ( empty($raw) || ! is_array($raw) ) return $out;

    $pairs = [];
    foreach ( $raw as $k => $v ) {
        $v = trim((string)$v);
        if ( $v === '' ) continue;

        $tax = sanitize_key( str_replace('attribute_','',(string)$k) );

        $label = function_exists('wc_attribute_label') ? wc_attribute_label($tax) : $tax;
        $label = $label ? (string)$label : $tax;

        $val_disp = $v;
        if ( taxonomy_exists($tax) ) {
            $term = get_term_by('slug',$v,$tax);
            if ( $term && ! is_wp_error($term) && isset($term->name) ) $val_disp = (string)$term->name;
        }

        // One-letter values should stay UPPER (L/M/S)
        if ( strlen($val_disp) == 1 ) $val_disp = strtoupper($val_disp);

        $label = trim($label); $val_disp = trim($val_disp);
        if ( $label === '' || $val_disp === '' ) continue;

        $pairs[] = [$label,$val_disp];
    }

    if ( empty($pairs) ) return $out;

    $html = '<div class="cccxr-vpills" aria-label="Variation">';
    $max = 3; $shown = 0;
    foreach ( $pairs as $pair ) {
        if ( $shown >= $max ) break;
        $html .= '<span class="cccxr-vpill"><span class="cccxr-vpill-k">'.esc_html(strtolower($pair[0])).':</span> <span class="cccxr-vpill-v">'.esc_html($pair[1]).'</span></span>';
        $shown++;
    }
    $rem = count($pairs) - $shown;
    if ( $rem > 0 ) $html .= '<span class="cccxr-vpill cccxr-vpill-more">+'.(int)$rem.' more</span>';
    $html .= '</div>';

    $out['pills_html'] = $html;
    $out['has_pills']  = true;
    return $out;
}

/* ============================================================
 * SHORTCODE: [caricove_my_account_returns]
 * ============================================================ */
add_shortcode( 'caricove_my_account_returns', function () {

    if ( ! is_user_logged_in() ) {
        return '<div class="cccxr"><div class="cccxr-empty"><div class="cccxr-empty-title">Please log in</div><div class="cccxr-empty-sub">You must be logged in to view returns.</div></div></div>';
    }

    if ( ! class_exists( 'WooCommerce' ) || ! function_exists( 'wc_get_orders' ) ) {
        return '<div class="cccxr"><div class="cccxr-empty"><div class="cccxr-empty-title">WooCommerce required</div><div class="cccxr-empty-sub">This page requires WooCommerce to load orders.</div></div></div>';
    }

    $uid   = (int) get_current_user_id();

    // Tunables (filters let you override without editing code)
    $limit = (int) apply_filters( 'cccxr_customer_limit', 120 );
    $days  = (int) apply_filters( 'cccxr_customer_days', 365 );
    $since = gmdate( 'Y-m-d', time() - ( $days * DAY_IN_SECONDS ) );


    // ===== Deep-link focus (from Orders: ?order_id=&item_id=&product_id=&rma=) =====
    $focus_order_id   = isset($_GET['order_id']) ? absint($_GET['order_id']) : 0;
    $focus_item_id    = isset($_GET['item_id']) ? absint($_GET['item_id']) : 0;
    $focus_product_id = isset($_GET['product_id']) ? absint($_GET['product_id']) : 0;

    $focus_rma = '';
    if ( isset($_GET['rma']) ) {
        $focus_rma = sanitize_text_field( wp_unslash( (string) $_GET['rma'] ) );
        if ( $focus_rma === '0' ) $focus_rma = '';
    }

    // Normalize focus order to ROOT (critical)
    if ( $focus_order_id ) {
        $focus_order_id = cccxr_focus_to_root_order_id( $focus_order_id );
    }

    $focus_active = ( $focus_order_id || $focus_item_id || $focus_product_id || $focus_rma !== '' );


    // Micro-cache (prevents heavy rescans on refresh spam)
    // IMPORTANT: bypass cache when deep-linking, so you don't chase stale data while testing.
    $cache_key = 'cccxr_cases_' . $uid;
    $cached = ( ! $focus_active ) ? get_transient( $cache_key ) : false;

    if ( is_array( $cached ) && isset( $cached['cases'], $cached['counts'] ) ) {
        $cases  = $cached['cases'];
        $counts = $cached['counts'];
    } else {
        $out = cccxr_collect_customer_cases( $uid, $since, $limit );
        $cases  = $out['cases'];
        $counts = $out['counts'];
        if ( ! $focus_active ) {
            set_transient( $cache_key, [ 'cases' => $cases, 'counts' => $counts ], 60 ); // 60s
        }
    }

    /**
     * FIX (gospel truth):
     * Deep-link "focus" must NEVER hide other items from the same ROOT order.
     *
     * Rules:
     * - If order_id exists: show ALL cases for that ROOT order.
     * - Else if only rma exists: show single case.
     * - Else: no filtering.
     */
    if ( $focus_active && ! empty($cases) ) {

        $cases = array_values( array_filter( $cases, function( $c ) use ( $focus_order_id, $focus_rma ) {

            $c = is_array($c) ? $c : [];

            // ROOT is the authority, not sub-order
            $c_root_id = absint( $c['_root_order_id'] ?? $c['_order_id'] ?? $c['order_id'] ?? 0 );
            $c_rma     = (string) ( $c['rma_id'] ?? '' );

            if ( $focus_order_id ) {
                return ( $c_root_id === $focus_order_id );
            }

            if ( $focus_rma !== '' ) {
                return ( $c_rma !== '' && $c_rma === $focus_rma );
            }

            return true;
        }));

        // Recompute counts for the filtered view
        $counts = [
            'total'     => count( $cases ),
            'active'    => 0,
            'due_soon'  => 0,
            'completed' => 0,
        ];

        foreach ( $cases as $c ) {
            $st = (string) ( $c['_cx_status_key'] ?? 'awaiting' );
            if ( in_array( $st, [ 'declined', 'closed' ], true ) || ( $st === 'refunded' && ! cccxr_case_is_shipping_only_pre_return( $c ) ) ) {
                $counts['completed']++;
            } else {
                $counts['active']++;
                if ( (string) ( $c['_deadline_bucket'] ?? '' ) === 'due_soon' ) $counts['due_soon']++;
            }
        }
    }

    $nonce = wp_create_nonce( 'cccxr_nonce' );

    ob_start();
    ?>
    <div class="cccxr" data-cccxr-nonce="<?php echo esc_attr( $nonce ); ?>">
        <div class="cccxr-hero">
            <div class="cccxr-hero-left">
                <div class="cccxr-title">Returns</div>
                <div class="cccxr-sub">Track status, deadlines, and next steps — instantly.</div>
                <div class="cccxr-micro">
                    <span class="cccxr-micro-dot"></span>
                    <span class="cccxr-micro-txt">Tip: Copy the Return ID and write it clearly on the package.</span>
                </div>
            </div>

            <div class="cccxr-kpis" role="group" aria-label="Returns summary">
                <div class="cccxr-kpi">
                    <div class="cccxr-kpi-k">Active</div>
                    <div class="cccxr-kpi-v"><?php echo (int) $counts['active']; ?></div>
                </div>
                <div class="cccxr-kpi">
                    <div class="cccxr-kpi-k">Due soon</div>
                    <div class="cccxr-kpi-v"><?php echo (int) $counts['due_soon']; ?></div>
                </div>
                <div class="cccxr-kpi cccxr-kpi-ok">
                    <div class="cccxr-kpi-k">Completed</div>
                    <div class="cccxr-kpi-v"><?php echo (int) $counts['completed']; ?></div>
                </div>
            </div>
        </div>

        <div class="cccxr-controls">
            <div class="cccxr-search">
                <span class="cccxr-search-ico" aria-hidden="true"></span>
                <input type="text" class="cccxr-search-in" placeholder="Search product, order #, Return ID, reason…" autocomplete="off" spellcheck="false">
            </div>

            <div class="cccxr-filters">
                <select class="cccxr-select" data-filter="status" aria-label="Filter status">
                    <option value="">All statuses</option>
                    <option value="requested">Requested</option>
                    <option value="approved">Approved</option>
                    <option value="awaiting">Awaiting return</option>
                    <option value="received">Received</option>
                    <option value="refunded">Refunded</option>
                    <option value="declined">Declined</option>
                    <option value="closed">Closed</option>
                </select>

                <select class="cccxr-select" data-filter="deadline" aria-label="Filter deadline">
                    <option value="">Any deadline</option>
                    <option value="due_soon">Due soon</option>
                    <option value="overdue">Overdue</option>
                    <option value="future">Future</option>
                </select>

                <div class="cccxr-pill" aria-label="Total cases">
                    <span class="cccxr-pill-num"><?php echo (int) $counts['total']; ?></span>
                    <span class="cccxr-pill-lbl">cases</span>
                </div>
            </div>
        </div>

        <?php if ( empty( $cases ) ) : ?>
            <div class="cccxr-empty">
                <div class="cccxr-empty-title">No returns found</div>
                <div class="cccxr-empty-sub">If you just submitted a return, refresh in a few seconds.</div>
            </div>
        <?php else : ?>
            <div class="cccxr-list" role="list">
                <?php foreach ( $cases as $c ) :
                    $rma          = (string) ( $c['rma_id'] ?? '' );
                    $product      = (string) ( $c['product_name'] ?? '' );
                    $qty          = isset( $c['qty'] ) ? (int) $c['qty'] : 0;
                    $reason       = (string) ( $c['reason_label'] ?? '' );

                    // ROOT order is the UI truth
                    $root_order_id     = (int) ( $c['_root_order_id'] ?? $c['_order_id'] ?? 0 );
                    $root_order_number = (string) ( $c['_root_order_number'] ?? $c['_order_number'] ?? '' );

                    // keep source/sub for internal use if needed later
                    $source_order_id   = (int) ( $c['_source_order_id'] ?? 0 );

                    $thumb        = (string) ( $c['_thumb'] ?? '' );
                    $item_id      = (int) ( $c['item_id'] ?? 0 );
                    $qty_received = null;
                    $has_qty_received = false;
                    
                    // Fallback: if item_id missing but RMA carries it (RCC-ORDER-ITEM), extract it.
if ( $item_id <= 0 ) {
    $rma_tmp = (string) ( $c['rma_id'] ?? '' );
    if ( $rma_tmp && preg_match( '/RCC-\d+-(\d+)/', $rma_tmp, $mm ) ) {
        $item_id = (int) $mm[1];
    }
}

$qty_received = null;
$has_qty_received = false;

// Prefer seller-confirmed item meta (editable, including 0).
if ( $item_id > 0 ) {
    $qr = wc_get_order_item_meta( $item_id, '_caricove_qty_received', true );
    if ( $qr !== '' && $qr !== null ) {
        $has_qty_received = true;
        $qty_received = is_numeric( $qr ) ? max( 0, (int) $qr ) : 0;
    }
}

// Fallback: materialized case qty_received (snapshot)
if ( ! $has_qty_received && array_key_exists( 'qty_received', $c ) ) {
    $has_qty_received = true;
    $qty_received = is_numeric( $c['qty_received'] ) ? max( 0, (int) $c['qty_received'] ) : 0;
}

                    // Prefer seller-confirmed item meta (editable, including 0).
                    if ( $item_id > 0 ) {
                        $qr = wc_get_order_item_meta( $item_id, '_caricove_qty_received', true );
                        if ( $qr !== '' && $qr !== null ) {
                            $has_qty_received = true;
                            $qty_received = is_numeric( $qr ) ? max( 0, (int) $qr ) : 0;
                        }
                    }

                    // Fallback: materialized case qty_received (read-only snapshot)
                    if ( ! $has_qty_received && array_key_exists( 'qty_received', $c ) ) {
                        $has_qty_received = true;
                        $qty_received = is_numeric( $c['qty_received'] ) ? max( 0, (int) $c['qty_received'] ) : 0;
                    }

$qty_received = 0;
                    if ( $item_id > 0 && $root_order_id > 0 && function_exists('wc_get_order') ) {
                        // Seller-confirmed received qty (truth)
                        $qr = wc_get_order_item_meta( $item_id, '_caricove_qty_received', true );
                        if ( is_numeric( $qr ) ) $qty_received = max( 0, (int) $qr );
                    }
                    $product_id   = (int) ( $c['_product_id'] ?? 0 );

                    $status_key   = (string) ( $c['_cx_status_key'] ?? 'awaiting' );
                    $status_label = (string) ( $c['_cx_status_label'] ?? 'Awaiting Return' );

                    $deadline_ts  = (int) ( $c['_deadline_ts'] ?? 0 );
                    $deadline_lbl = (string) ( $c['_deadline_label'] ?? '' );
                    $deadline_bucket = (string) ( $c['_deadline_bucket'] ?? '' );

                    $action_title = (string) ( $c['_cx_action_title'] ?? '' );
                    $action_text  = (string) ( $c['_cx_action_text'] ?? '' );

                    $ship_party   = (string) ( $c['_cx_ship_party'] ?? 'Customer' );
                    $refund_timing= (string) ( $c['_cx_refund_timing'] ?? 'After item is received' );
                    $return_addr  = (string) ( $c['_return_address'] ?? '' );

                    $return_required = isset( $c['_return_required'] ) ? (int) $c['_return_required'] : 1;

                    // Timeline sizing
                    $timeline_max  = $return_required === 0 ? 3 : 5;
                    $timeline_step = (int) ( $c['_timeline_step'] ?? 1 );
                    if ( $timeline_step < 1 ) $timeline_step = 1;
                    if ( $timeline_step > $timeline_max ) $timeline_step = $timeline_max;

                    $row_key = esc_attr( $c['_key'] ?? ( $rma ?: ( $root_order_id . '-' . $item_id ) ) );
                    $search_blob = strtolower( trim( $rma . ' ' . $product . ' ' . $reason . ' ' . $root_order_number . ' ' . $root_order_id ) );

                    // Terminal pill label (Closed by default; flips only when resolved)
                    $terminal_lbl = 'Closed';
                    if ( $status_key === 'refunded' ) $terminal_lbl = 'Refunded';
                    if ( $status_key === 'declined' ) $terminal_lbl = 'Declined';
                    ?>
                    <div class="cccxr-case"
                        role="listitem"
                        data-key="<?php echo $row_key; ?>"
                        data-search="<?php echo esc_attr( $search_blob ); ?>"
                        data-status="<?php echo esc_attr( $status_key ); ?>"
                        data-deadline="<?php echo esc_attr( $deadline_bucket ); ?>"
                        data-deadline-ts="<?php echo esc_attr( $deadline_ts ); ?>"
                        data-root-order-id="<?php echo esc_attr( $root_order_id ); ?>"
                        data-source-order-id="<?php echo esc_attr( $source_order_id ); ?>"
                    >
                        <div class="cccxr-card">
                            <div class="cccxr-top">
                                <div class="cccxr-thumb">
                                    <?php if ( $thumb ) : ?>
                                        <img src="<?php echo esc_url( $thumb ); ?>" alt="">
                                    <?php else : ?>
                                        <div class="cccxr-thumb-ph" aria-hidden="true"></div>
                                    <?php endif; ?>
                                </div>

                                <div class="cccxr-main">
                                   <?php $tp = cccxr_title_and_pills_from_order_item( $root_order_id, $item_id, (string) ($product ?: '—') ); ?>
<div class="cccxr-product"><?php echo esc_html( (string) $tp['title'] ); ?></div>
<?php if ( ! empty($tp['has_pills']) && ! empty($tp['pills_html']) ) { echo $tp['pills_html']; } ?>

                                    <div class="cccxr-meta">
                                        <span class="cccxr-meta-item">Order <strong>#<?php echo esc_html( $root_order_number ?: (string) $root_order_id ); ?></strong></span>

                                        <?php if ( $reason ) : ?>
                                            <span class="cccxr-dot" aria-hidden="true"></span>
                                            <span class="cccxr-meta-item"><?php echo esc_html( $reason ); ?></span>
                                        <?php endif; ?>

                                        <?php if ( $qty ) : ?>
                                            <span class="cccxr-dot" aria-hidden="true"></span>
                                            <span class="cccxr-meta-item">Qty <strong><?php echo (int) $qty; ?></strong></span>
                                        <?php endif; ?>
                                      
                                        <?php
$status = isset($status) ? (string) $status : (string) ($case['status'] ?? $case['state'] ?? '');
$status_l = strtolower(trim($status));
?>

                                        <?php if ( $has_qty_received || strtolower((string)$status) === 'received' ) : ?>
    <span class="cccxr-dot" aria-hidden="true"></span>
    <span class="cccxr-meta-item">Received <strong><?php echo (int) ($qty_received ?? 0); ?>/<?php echo (int) $qty; ?></strong></span>
<?php endif; ?>



                                        <?php if ( $deadline_lbl ) : ?>
                                            <span class="cccxr-dot" aria-hidden="true"></span>
                                            <span class="cccxr-meta-item">Deadline <strong><?php echo esc_html( $deadline_lbl ); ?></strong></span>
                                        <?php endif; ?>
                                    </div>

                                    <div class="cccxr-status-row">
                                        <div class="cccxr-status cccxr-status-<?php echo esc_attr( $status_key ); ?>">
                                            <?php echo esc_html( $status_label ); ?>
                                        </div>

                                        <?php if ( $deadline_bucket === 'overdue' ) : ?>
                                            <div class="cccxr-chip cccxr-chip-bad">Overdue</div>
                                        <?php elseif ( $deadline_bucket === 'due_soon' ) : ?>
                                            <div class="cccxr-chip cccxr-chip-warn">Due soon</div>
                                        <?php endif; ?>
                                    </div>

                                    <?php if ( $action_title || $action_text ) : ?>
                                        <div class="cccxr-next">
                                            <?php if ( $action_title ) : ?>
                                                <div class="cccxr-next-k"><?php echo esc_html( $action_title ); ?></div>
                                            <?php endif; ?>
                                            <?php if ( $action_text ) : ?>
                                                <div class="cccxr-next-v"><?php echo esc_html( $action_text ); ?></div>
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>

                                    <div class="cccxr-timeline" aria-label="Return timeline">
                                        <?php
                                            if ( $timeline_max === 3 ) {
                                                $steps = [
                                                    1 => 'Requested',
                                                    2 => 'Approved',
                                                    3 => $terminal_lbl,
                                                ];
                                            } else {
                                                $steps = [
                                                    1 => 'Requested',
                                                    2 => 'Approved',
                                                    3 => 'Awaiting Return',
                                                    4 => 'Received',
                                                    5 => $terminal_lbl,
                                                ];
                                            }

                                            foreach ( $steps as $i => $lbl ) {
                                                $cls = 'cccxr-step';
                                                if ( $i < $timeline_step ) $cls .= ' is-done';
                                                if ( $i === $timeline_step ) $cls .= ' is-now';

                                                if ( $status_key === 'declined' && $timeline_max === 5 && in_array( $i, [3,4], true ) ) {
                                                    $cls .= ' is-off';
                                                }

                                                echo '<div class="' . esc_attr( $cls ) . '"><span class="cccxr-dot2" aria-hidden="true"></span><span class="cccxr-step-lbl">' . esc_html( $lbl ) . '</span></div>';
                                            }
                                        ?>
                                    </div>
                                </div>
                            </div>

                            <div class="cccxr-right">
                                <div class="cccxr-rma-wrap">
                                    <div class="cccxr-rma-k">Return ID</div>
                                    <div class="cccxr-rma-v"><?php echo esc_html( $rma ?: '—' ); ?></div>
                                </div>

                                <div class="cccxr-actions">
                                    <button type="button" class="cccxr-btn" data-act="toggle" aria-expanded="false">Details</button>

                                    <button type="button"
                                        class="cccxr-btn-primary"
                                        data-cc-support
                                        data-order-id="<?php echo esc_attr( $root_order_id ); ?>"
                                        data-order-number="<?php echo esc_attr( $root_order_number ); ?>"
                                        data-rma="<?php echo esc_attr( $rma ); ?>"
                                        data-order-item-id="<?php echo esc_attr( $item_id ); ?>"
                                        data-product-id="<?php echo esc_attr( $product_id ); ?>">
                                        Get Help
                                    </button>

                                    <button type="button" class="cccxr-btn cccxr-btn-ghost" data-act="copy" data-copy="<?php echo esc_attr( $rma ); ?>">Copy ID</button>
                                </div>
                            </div>
                        </div>

                        <div class="cccxr-drawer" hidden>
                            <div class="cccxr-drawer-grid">
                                <div class="cccxr-box">
                                    <div class="cccxr-box-k">Return Shipping</div>
                                    <div class="cccxr-box-v"><?php echo esc_html( $ship_party ); ?></div>
                                </div>
                                <div class="cccxr-box">
                                    <div class="cccxr-box-k">Refund</div>
                                    <div class="cccxr-box-v"><?php echo esc_html( $refund_timing ); ?></div>
                                </div>
                                <div class="cccxr-box">
                                    <div class="cccxr-box-k">Order</div>
                                    <div class="cccxr-box-v">#<?php echo esc_html( $root_order_number ?: (string) $root_order_id ); ?></div>
                                </div>

                                <div class="cccxr-box cccxr-box-wide">
                                    <div class="cccxr-box-k">Return Address</div>
                                    <div class="cccxr-box-v"><?php echo esc_html( $return_addr ? $return_addr : 'Will appear after approval (if required).' ); ?></div>
                                    <?php if ( $return_addr ) : ?>
                                        <div class="cccxr-box-actions">
                                            <button type="button" class="cccxr-mini" data-act="copy" data-copy="<?php echo esc_attr( $return_addr ); ?>">Copy Address</button>
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <div class="cccxr-foot">
                                    <a class="cccxr-link" href="<?php echo esc_url( caricove_order_details_url( $root_order_id, (int)($item_id ?? 0) ) ); ?>">
                                        View Order
                                    </a>

                                    <?php if ( $rma ) : ?>
                                        <button type="button" class="cccxr-mini" data-act="copy" data-copy="<?php echo esc_attr( $rma ); ?>">Copy Return ID</button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <div class="cccxr-toast" aria-live="polite" aria-atomic="true" hidden></div>
    </div>
    <?php
    return ob_get_clean();
});




function cccxr_get_order_cases_for_ui( $order ) {
    if ( ! $order instanceof WC_Order ) return [];

    if ( class_exists( '\Caricove\Bank\BankRefundCases' ) ) {
        $cases = \Caricove\Bank\BankRefundCases::list_legacy_cases_for_order( (int) $order->get_id() );
        if ( empty( $cases ) && (int) $order->get_parent_id() > 0 ) {
            $cases = \Caricove\Bank\BankRefundCases::list_legacy_cases_for_order( (int) $order->get_parent_id() );
        }
        if ( is_array( $cases ) ) {
            return array_values( array_filter( $cases, 'is_array' ) );
        }
    }

    $stored = get_post_meta( (int) $order->get_id(), CC_RETURNS_META_CASES, true );
    if ( is_array( $stored ) ) {
        return $stored;
    }

    if ( (int) $order->get_parent_id() > 0 ) {
        $stored = get_post_meta( (int) $order->get_parent_id(), CC_RETURNS_META_CASES, true );
        if ( is_array( $stored ) ) {
            return $stored;
        }
    }

    return [];
}

/* ============================================================
 * DATA: case discovery (customer-safe + parent/sub-order fix)
 * ============================================================ */
function cccxr_collect_customer_cases( $uid, $since_ymd, $limit ) {

    $orders = wc_get_orders([
        'limit'        => max( 1, (int) $limit ),
        'orderby'      => 'date',
        'order'        => 'DESC',
        'date_after'   => (string) $since_ymd,
        'return'       => 'objects',
        'status'       => array_keys( wc_get_order_statuses() ),
        'type'         => 'shop_order',
        'customer_id'  => (int) $uid,
    ]);

    $cases = [];
    $seen  = []; // rma/keys
    $seen_item = []; // ROOT_ORDER_ID:ITEM_ID => true

    foreach ( $orders as $order ) {
        if ( ! $order instanceof WC_Order ) continue;
        if ( (int) $order->get_customer_id() !== (int) $uid ) continue;

        // ROOT is the display truth
        $root = cccxr_get_root_order( $order );
        if ( ! $root instanceof WC_Order ) continue;

        $root_order_id     = (int) $root->get_id();
        $root_order_number = (string) $root->get_order_number();

        // Source/sub order currently being iterated (can be same as root)
        $loop_order_id     = (int) $order->get_id();
        $loop_order_number = (string) $order->get_order_number();

        // Candidate orders to READ from (root + the current one)
        $candidate_orders = [ $order ];
        if ( $root_order_id !== $loop_order_id ) {
            $candidate_orders[] = $root;
        }

        // 1) Primary: order-level wizard cases
        $found_order_level = false;

        foreach ( $candidate_orders as $src_order ) {
            $src_id = (int) $src_order->get_id();
            $stored = cccxr_get_order_cases_for_ui( $src_order );

            if ( is_array( $stored ) && ! empty( $stored ) ) {
                $found_order_level = true;

                foreach ( $stored as $case ) {
                    if ( ! is_array( $case ) ) continue;

                    // Optional clamp if stored
                    if ( isset( $case['customer_id'] ) && (int) $case['customer_id'] !== (int) $uid ) continue;

                    $rma     = ! empty( $case['rma_id'] ) ? (string) $case['rma_id'] : '';
                    $item_id = isset( $case['item_id'] ) ? (int) $case['item_id'] : 0;

                    $key = $rma ? $rma : ( $src_id . ':' . $item_id . ':' . (int) ( $case['created'] ?? 0 ) );
                    if ( isset( $seen[ $key ] ) ) continue;
                    $seen[ $key ] = true;

                    if ( $item_id > 0 ) {
                        $seen_item[ $root_order_id . ':' . $item_id ] = true;
                    }

                    // Best-effort item lookup across candidate orders (root/sub)
                    $item = null;
                    if ( $item_id > 0 ) {
                        foreach ( $candidate_orders as $try ) {
                            $tmp = $try->get_item( $item_id );
                            if ( $tmp instanceof WC_Order_Item_Product ) { $item = $tmp; break; }
                        }
                    }

                    $product_id   = 0;
                    $product_name = (string) ( $case['product_name'] ?? '' );
                    if ( $item instanceof WC_Order_Item_Product ) {
                        $product_id = (int) $item->get_product_id();
                        if ( ! $product_name ) $product_name = (string) $item->get_name();
                    }

                    $thumb_url = '';
                    if ( $product_id > 0 ) {
                        $thumb_id = get_post_thumbnail_id( $product_id );
                        if ( $thumb_id ) {
                            $thumb = wp_get_attachment_image_src( $thumb_id, 'thumbnail' );
                            if ( is_array( $thumb ) && ! empty( $thumb[0] ) ) $thumb_url = (string) $thumb[0];
                        }
                    }

                    $qty = 0;
                    if ( isset( $case['qty'] ) ) $qty = (int) $case['qty'];
                    if ( ! $qty && $item instanceof WC_Order_Item_Product ) $qty = (int) $item->get_quantity();
                    if ( ! $qty ) $qty = 1;

                    $reason = (string) ( $case['reason_label'] ?? '' );
                    if ( ! $reason && $item_id > 0 ) $reason = (string) wc_get_order_item_meta( $item_id, '_caricove_reason_label', true );

                   $status_raw   = (string) ( $case['status'] ?? 'awaiting_return' );
$deadline_ts  = (int) ( $case['deadline'] ?? 0 );

// Returnless (0) vs return required (1) — support multiple possible keys
$return_required = null;
foreach ( ['return_required','return_required_flag','is_return_required','returnless_refund','returnless'] as $rk ) {
    if ( array_key_exists( $rk, $case ) ) {
        $return_required = (int) $case[ $rk ];
        if ( in_array( $rk, ['returnless_refund','returnless'], true ) ) $return_required = $return_required ? 0 : 1;
        break;
    }
}
if ( $return_required === null ) $return_required = 1;

$decision_code         = strtoupper( trim( (string) ( $case['decision_code'] ?? '' ) ) );
$low_value_refund_only = ! empty( $case['low_value_refund_only'] );
$returnless_case       = (
    (int) $return_required === 0
    || $low_value_refund_only
    || ( in_array( $decision_code, [ 'REFUND_ONLY', 'REFUND_IMMEDIATE' ], true ) && (int) $return_required !== 1 )
);

if ( $returnless_case ) {
    continue;
}

$norm = cccxr_normalize_customer_case( [
                        'rma_id'          => $rma,
                        'item_id'         => $item_id,
                        'product_name'    => $product_name,
                        'qty'             => $qty,
                        'reason_label'    => $reason,
                        'status'          => $status_raw,
                        'deadline'        => $deadline_ts,
                        'created'         => (int) ( $case['created'] ?? 0 ),
                        'return_required' => $return_required,
                        'raw'             => $case,
                    ] );

                    $return_addr = cccxr_extract_return_address_customer( $case );

                    $cases[] = array_merge( $case, [
                        'rma_id'            => $norm['rma_id'],
                        'item_id'           => $item_id,
                        'product_name'      => $product_name,
                        'qty'               => $qty,
                        'reason_label'      => $reason,

                        '_key'              => $key,

                        '_root_order_id'     => $root_order_id,
                        '_root_order_number' => $root_order_number,

                        '_source_order_id'   => $src_id,
                        '_loop_order_id'     => $loop_order_id,

                        // Back-compat fields (now set to ROOT so nothing breaks)
                        '_order_id'          => $root_order_id,
                        '_order_number'      => $root_order_number,

                        '_product_id'        => $product_id,
                        '_thumb'             => $thumb_url,

                        '_return_required'   => (int) $return_required,

                        '_cx_status_key'     => $norm['status_key'],
                        '_cx_status_label'   => $norm['status_label'],
                        '_timeline_step'     => $norm['timeline_step'],

                        '_cx_action_title'   => $norm['action_title'],
                        '_cx_action_text'    => $norm['action_text'],
                        '_cx_ship_party'     => $norm['ship_party'],
                        '_cx_refund_timing'  => $norm['refund_timing'],

                        '_deadline_ts'       => $norm['deadline_ts'],
                        '_deadline_label'    => $norm['deadline_label'],
                        '_deadline_bucket'   => $norm['deadline_bucket'],

                        '_return_address'    => $return_addr,
                    ] );
                }
            }
        }

        /**
         * 2) Merge-back safety net (GOSPEL FIX):
         * Even if order-level meta exists, we STILL scan item metas and merge any missing cases.
         * This prevents "mark received" writers from accidentally dropping cases and making CX UI lose them.
         */
        $scan_orders = [];
        foreach ( $candidate_orders as $so ) {
            if ( ! $so instanceof WC_Order ) continue;
            $scan_orders[ (int) $so->get_id() ] = $so;
        }

        foreach ( $scan_orders as $scan_order_id => $scan_order ) {

            foreach ( $scan_order->get_items() as $item_id => $item ) {
                $item_id = (int) $item_id;
                if ( ! ( $item instanceof WC_Order_Item_Product ) ) continue;

                // If order-level cases already included this item (for this ROOT order), don't duplicate it.
                if ( isset( $seen_item[ $root_order_id . ':' . $item_id ] ) ) {
                    continue;
                }

                $ev_rma    = (string) wc_get_order_item_meta( $item_id, '_caricove_rma_id', true );
                $ev_status = (string) wc_get_order_item_meta( $item_id, '_caricove_return_status', true );
                $ev_reason = (string) wc_get_order_item_meta( $item_id, '_caricove_reason_label', true );

                $ev_qty_req = wc_get_order_item_meta( $item_id, '_caricove_qty_return_requested', true );
                if ( $ev_qty_req === '' ) $ev_qty_req = wc_get_order_item_meta( $item_id, '_caricove_qty_requested', true );

                $ev_qty_ref = wc_get_order_item_meta( $item_id, '_caricove_qty_refunded', true );

                // Hard evidence gate — we only create a fallback case if there's real return evidence.
                $has_evidence = false;
                if ( $ev_rma !== '' ) $has_evidence = true;
                if ( ! $has_evidence && trim( $ev_status ) !== '' ) $has_evidence = true;
                if ( ! $has_evidence && trim( $ev_reason ) !== '' ) $has_evidence = true;
                if ( ! $has_evidence && is_numeric( $ev_qty_req ) && (float) $ev_qty_req > 0 ) $has_evidence = true;
                if ( ! $has_evidence && is_numeric( $ev_qty_ref ) && (float) $ev_qty_ref > 0 ) $has_evidence = true;

                if ( ! $has_evidence ) continue;

                $qty = 0;
                if ( is_numeric( $ev_qty_req ) && (float) $ev_qty_req > 0 ) {
                    $qty = (int) $ev_qty_req;
                } elseif ( is_numeric( $ev_qty_ref ) && (float) $ev_qty_ref > 0 ) {
                    $qty = (int) $ev_qty_ref;
                } else {
                    $qty = (int) $item->get_quantity();
                }
                if ( ! $qty ) $qty = 1;

                $product_id   = (int) $item->get_product_id();
                $product_name = (string) $item->get_name();

                $thumb_url = '';
                if ( $product_id > 0 ) {
                    $thumb_id = get_post_thumbnail_id( $product_id );
                    if ( $thumb_id ) {
                        $thumb = wp_get_attachment_image_src( $thumb_id, 'thumbnail' );
                        if ( is_array( $thumb ) && ! empty( $thumb[0] ) ) $thumb_url = (string) $thumb[0];
                    }
                }

                // RMA: prefer explicit meta; otherwise guess (only for evidenced cases)
                $rma = $ev_rma !== '' ? $ev_rma : ( 'RCC-' . $root_order_id . '-' . $item_id );
                $key = $rma;

                if ( isset( $seen[ $key ] ) ) continue;
                $seen[ $key ] = true;
                $seen_item[ $root_order_id . ':' . $item_id ] = true;

                $status_raw = $ev_status !== '' ? $ev_status : 'awaiting_return';

               $ret_req = wc_get_order_item_meta( $item_id, '_caricove_return_required', true );
if ( (string) $ret_req === '' ) $ret_req = 1;
$return_required = ((int)$ret_req === 1) ? 1 : 0;

if ( $return_required === 0 ) {
    continue;
}

$norm = cccxr_normalize_customer_case([
                    'rma_id'          => $rma,
                    'item_id'         => $item_id,
                    'product_name'    => $product_name,
                    'qty'             => $qty,
                    'reason_label'    => $ev_reason,
                    'status'          => $status_raw,
                    'deadline'        => 0,
                    'created'         => 0,
                    'return_required' => $return_required,
                    'raw'             => [],
                ]);

                $cases[] = [
                    'rma_id'            => $rma,
                    'item_id'           => $item_id,
                    'product_name'      => $product_name,
                    'qty'               => $qty,
                    'reason_label'      => $ev_reason,
                    'status'            => $status_raw,

                    '_key'              => $key,

                    '_root_order_id'     => $root_order_id,
                    '_root_order_number' => $root_order_number,

                    // We read the item metas from THIS scanned order (root or sub)
                    '_source_order_id'   => (int) $scan_order_id,
                    '_loop_order_id'     => $loop_order_id,

                    // Back-compat fields (ROOT)
                    '_order_id'          => $root_order_id,
                    '_order_number'      => $root_order_number,

                    '_product_id'        => $product_id,
                    '_thumb'             => $thumb_url,

                    '_return_required'   => (int) $return_required,

                    '_cx_status_key'     => $norm['status_key'],
                    '_cx_status_label'   => $norm['status_label'],
                    '_timeline_step'     => $norm['timeline_step'],

                    '_cx_action_title'   => $norm['action_title'],
                    '_cx_action_text'    => $norm['action_text'],
                    '_cx_ship_party'     => $norm['ship_party'],
                    '_cx_refund_timing'  => $norm['refund_timing'],

                    '_deadline_ts'       => $norm['deadline_ts'],
                    '_deadline_label'    => $norm['deadline_label'],
                    '_deadline_bucket'   => $norm['deadline_bucket'],

                    '_return_address'    => '',
                ];
            }
        }
    }

    // Sort newest first (created desc, else deadline desc, else root order id desc)
    usort( $cases, function( $a, $b ) {
        $ta = (int) ( $a['created'] ?? 0 );
        $tb = (int) ( $b['created'] ?? 0 );
        if ( $ta !== $tb ) return $tb <=> $ta;

        $da = (int) ( $a['_deadline_ts'] ?? 0 );
        $db = (int) ( $b['_deadline_ts'] ?? 0 );
        if ( $da !== $db ) return $db <=> $da;

        $oa = (int) ( $a['_root_order_id'] ?? $a['_order_id'] ?? 0 );
        $ob = (int) ( $b['_root_order_id'] ?? $b['_order_id'] ?? 0 );
        return $ob <=> $oa;
    });

    $counts = [
        'total'     => count( $cases ),
        'active'    => 0,
        'due_soon'  => 0,
        'completed' => 0,
    ];

    foreach ( $cases as $c ) {
        $st = (string) ( $c['_cx_status_key'] ?? 'awaiting' );
        if ( in_array( $st, [ 'declined', 'closed' ], true ) || ( $st === 'refunded' && ! cccxr_case_is_shipping_only_pre_return( $c ) ) ) {
            $counts['completed']++;
        } else {
            $counts['active']++;
            if ( (string) ( $c['_deadline_bucket'] ?? '' ) === 'due_soon' ) $counts['due_soon']++;
        }
    }

    return [
        'cases'  => $cases,
        'counts' => $counts,
    ];
}
/* ============================================================
 * NORMALIZATION (customer-safe mapping + “next step”)
 * - Adds: returnless refund behavior + terminal label flip support
 * - Adds: refunded amount text when available
 * ============================================================ */
function cccxr_normalize_customer_case( $in ) {

    $rma            = (string) ( $in['rma_id'] ?? '' );
    $status_raw     = strtolower( trim( (string) ( $in['status'] ?? 'awaiting_return' ) ) );
    $deadline_ts    = (int) ( $in['deadline'] ?? 0 );
    $return_required= isset( $in['return_required'] ) ? (int) $in['return_required'] : 1;

    $raw = is_array( $in['raw'] ?? null ) ? (array) $in['raw'] : [];
    $fault = strtolower( trim( (string) ( $raw['fault'] ?? $raw['initial_fault'] ?? '' ) ) );
    $decision_code_raw = strtoupper( trim( (string) ( $raw['decision_code'] ?? '' ) ) );
    $investigation_first = in_array( $fault, [ 'seller', 'carrier', 'mixed' ], true ) || $decision_code_raw === 'MORE_INFO_REQUIRED';

    // Refund amount label (used when refunded)
    $refund_amount = cccxr_case_get_refund_amount( $raw );
    $refund_amount_lbl = $refund_amount > 0 ? cccxr_money_plain( $refund_amount ) : '';

    // Map statuses
    $status_key   = 'awaiting';
    $status_label = 'Awaiting Return';
    $timeline_step = 3;

    if ( in_array( $status_raw, [ 'requested', 'request', 'pending', 'pending_review', 'seller_review', 'admin_review', 'info_requested', 'under_review' ], true ) ) {
        $status_key = 'requested';
        $status_label = $investigation_first ? 'Under Review' : 'Requested';
        $timeline_step = 1;

    } elseif ( in_array( $status_raw, [ 'approved', 'accepted' ], true ) ) {
        $status_key = 'approved';
        $status_label = 'Approved';
        $timeline_step = 2;

    } elseif ( in_array( $status_raw, [ 'awaiting_return', 'awaiting', 'return_required', 'return_pending', 'awaiting_pickup', 'awaiting_dropoff', 'approved_return_pickup', 'return_in_progress', 'in_transit' ], true ) ) {
        $status_key = 'awaiting';
        $status_label = 'Awaiting Return';
        $timeline_step = 3;

    } elseif ( in_array( $status_raw, [ 'received', 'return_received' ], true ) ) {
        $status_key = 'received';
        $status_label = 'Received';
        $timeline_step = ($return_required === 0) ? 2 : 4; // returnless doesn't use "received"

    } elseif ( in_array( $status_raw, [ 'refunded', 'refund_issued', 'refund_completed' ], true ) ) {
        if ( cccxr_case_is_shipping_only_pre_return( $raw ) ) {
            $status_key = 'awaiting';
            $status_label = 'Awaiting Return';
            $timeline_step = 3;
        } else {
            $status_key = 'refunded';
            $status_label = 'Refunded';
            $timeline_step = ($return_required === 0) ? 3 : 5;
        }

    } elseif ( in_array( $status_raw, [ 'denied', 'rejected', 'declined' ], true ) ) {
        $status_key = 'declined';
        $status_label = 'Declined';
        $timeline_step = ($return_required === 0) ? 3 : 5;

    } elseif ( in_array( $status_raw, [ 'closed', 'resolved', 'completed' ], true ) ) {
        // Closed without explicit outcome (rare) — still terminal for KPI
        $status_key = 'closed';
        $status_label = 'Closed';
        $timeline_step = ($return_required === 0) ? 3 : 5;

    } elseif ( in_array( $status_raw, [ 'cancelled', 'canceled', 'cancelled_partial', 'canceled_partial' ], true ) ) {
        if ( ! empty( $raw['refund_id'] ) || cccxr_case_get_refund_amount( $raw ) > 0 ) {
            $status_key = 'refunded';
            $status_label = 'Refunded';
        } else {
            $status_key = 'closed';
            $status_label = 'Cancelled';
        }
        $timeline_step = ($return_required === 0) ? 3 : 5;

    } elseif ( $status_raw === 'escalated' ) {
        $status_key = 'approved';
        $status_label = 'Approved';
        $timeline_step = 2;
    }

    // Deadline label + bucket
    $deadline_label = '';
    $deadline_bucket = '';
    if ( $deadline_ts > 0 ) {
        $deadline_label = date_i18n( get_option( 'date_format' ), $deadline_ts );

        $now = time();
        if ( $deadline_ts < $now - 1 ) {
            $deadline_bucket = 'overdue';
        } else {
            $days_left = (int) floor( ( $deadline_ts - $now ) / DAY_IN_SECONDS );
            $deadline_bucket = ( $days_left <= 3 ) ? 'due_soon' : 'future';
        }
    }

    // Next step copy
    $action_title = '';
    $action_text  = '';

    if ( $status_key === 'requested' ) {
        $action_title = 'Next step';
        $action_text  = $investigation_first
            ? 'We need a bit more information before confirming the next step for this issue.'
            : 'Waiting for approval. We’ll update this page once it’s approved.';

    } elseif ( $status_key === 'approved' ) {
        $action_title = 'Next step';
        if ( $return_required === 0 ) {
            $action_text = 'No return is needed. Admin will review and close this request.';
        } else {
            $action_text = $deadline_label
                ? ('Return your item before ' . $deadline_label . ' to keep your refund on track.')
                : 'Return instructions will appear here once the return is scheduled.';
        }

    } elseif ( $status_key === 'awaiting' ) {
        $action_title = 'Next step';
        $action_text  = $deadline_label
            ? ('Return your item before ' . $deadline_label . ' to keep your refund on track.')
            : 'Return your item to keep your refund on track.';

    } elseif ( $status_key === 'received' ) {
        $action_title = 'Next step';
        $action_text  = 'No action needed. Your refund is processing.';

    } elseif ( $status_key === 'refunded' ) {
        $action_title = 'Completed';
        $action_text  = $refund_amount_lbl
            ? ('Refunded ' . $refund_amount_lbl . '. If you don’t see it yet, allow your bank a short processing window.')
            : 'Refund issued. If you don’t see it yet, allow your bank a short processing window.';

    } elseif ( $status_key === 'declined' ) {
        $action_title = 'Update';
        $action_text  = 'Refund declined. If you think this is a mistake, tap “Get Help”.';

    } elseif ( $status_key === 'closed' ) {
        $action_title = 'Completed';
        $action_text  = 'This request is closed. Tap “Get Help” if you need assistance.';
    }

    // Customer-safe defaults
    $ship_party = 'Customer';
    $refund_timing = 'After item is received';

    // Refund box: show terminal outcomes exactly as you requested
    if ( $status_key === 'refunded' ) {
        $refund_timing = $refund_amount_lbl ? ( 'Refunded ' . $refund_amount_lbl ) : 'Refunded';
    } elseif ( $status_key === 'declined' ) {
        $refund_timing = 'Refund declined — contact support';
    } elseif ( $return_required === 0 ) {
        // Returnless (avoid misleading “After item is received”)
        if ( in_array( $status_key, [ 'requested', 'approved' ], true ) ) {
            $refund_timing = $investigation_first ? 'Issue review in progress' : 'Admin review in progress';
        }
    } elseif ( $investigation_first && in_array( $status_key, [ 'requested', 'approved', 'awaiting' ], true ) ) {
        $refund_timing = 'Issue review in progress';
    }

    foreach ( [ 'return_shipping', 'shipping_party', 'return_shipping_party' ] as $k ) {
        if ( ! empty( $raw[ $k ] ) ) {
            $v = strtolower( trim( (string) $raw[ $k ] ) );
            if ( strpos( $v, 'vendor' ) !== false )   $ship_party = 'Seller';
            if ( strpos( $v, 'caricove' ) !== false ) $ship_party = 'Caricove';
            if ( strpos( $v, 'customer' ) !== false ) $ship_party = 'Customer';
        }
    }
    foreach ( [ 'refund_timing', 'refund_line', 'refund_release' ] as $k ) {
        if ( ! empty( $raw[ $k ] ) ) $refund_timing = (string) $raw[ $k ];
    }

    return [
        'rma_id'          => $rma,
        'status_key'      => $status_key,
        'status_label'    => $status_label,
        'timeline_step'   => $timeline_step,
        'deadline_ts'     => $deadline_ts,
        'deadline_label'  => $deadline_label,
        'deadline_bucket' => $deadline_bucket,
        'action_title'    => $action_title,
        'action_text'     => $action_text,
        'ship_party'      => $ship_party,
        'refund_timing'   => $refund_timing,
    ];
}

function cccxr_extract_return_address_customer( $case ) {
    if ( ! is_array( $case ) ) return '';

    $keys = [
        'return_address',
        'return_address_line',
        'return_to',
        'return_to_address',
        'return_address_text',
        'return_label_address',
        'vendor_return_address',
        'warehouse_address',
    ];

    foreach ( $keys as $k ) {
        if ( ! empty( $case[ $k ] ) && is_string( $case[ $k ] ) ) {
            $v = trim( (string) $case[ $k ] );
            if ( $v !== '' ) return $v;
        }
    }

    foreach ( $keys as $k ) {
        if ( ! empty( $case[ $k ] ) && is_array( $case[ $k ] ) ) {
            $lines = array_filter( array_map( function( $x ){ return trim( (string) $x ); }, (array) $case[ $k ] ) );
            if ( ! empty( $lines ) ) return implode( ', ', $lines );
        }
    }

    return '';
}

/* ============================================================
 * ASSETS (scoped to .cccxr)
 * ============================================================ */
add_action( 'wp_enqueue_scripts', function () {
    if ( is_admin() ) return;

    wp_register_style( 'cccxr-style', false, [], '2.1.1' );
    wp_enqueue_style( 'cccxr-style' );

    wp_register_script( 'cccxr-script', '', [], '2.1.1', true );
    wp_enqueue_script( 'cccxr-script' );

    // IMPORTANT: this is your original v2.0.0 CSS, kept as-is.
    // Only changes are appended at the very bottom (search lever + button black gradient tweaks).
    wp_add_inline_style( 'cccxr-style', <<<CSS
.cccxr{ color:#fff; font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif; line-height:1.25; --cccxr-search-shift: 0px; }
.cccxr *{ box-sizing:border-box; }
.cccxr a{ color:inherit; text-decoration:none; }
.cccxr a:focus, .cccxr button:focus, .cccxr input:focus, .cccxr select:focus{ outline:none; }






/* Push search bar up (negative = up). Adjust value as needed */
.cccxr{ --cccxr-search-shift: -48px; }




/* Cool, premium search / filter box */
.cccxr-search-wrap,
.cccxr-search,
.cccxr-filters{
  border-radius: 18px;
  padding: 14px;
  background:
    linear-gradient(180deg, rgba(10,18,38,.95), rgba(6,10,22,.95));
  border: 1px solid rgba(120,200,255,.28);

  box-shadow:
    0 18px 40px rgba(0,0,0,.65),
    inset 0 0 0 1px rgba(120,200,255,.08),
    0 0 32px rgba(60,150,255,.18);

  backdrop-filter: blur(14px);
  -webkit-backdrop-filter: blur(14px);
}

/* Inner input field polish */
.cccxr-search input{
  background: rgba(6,10,22,.85) !important;
  border-radius: 14px !important;
  border: 1px solid rgba(120,200,255,.22) !important;
  color: #fff !important;
  padding: 14px 16px !important;

  box-shadow:
    inset 0 2px 6px rgba(0,0,0,.6),
    0 0 0 1px rgba(120,200,255,.06);
}

/* Placeholder glow */
.cccxr-search input::placeholder{
  color: rgba(190,220,255,.55);
}

/* Hover / focus = alive */
.cccxr-search-wrap:hover,
.cccxr-search:focus-within{
  border-color: rgba(160,225,255,.45);
  box-shadow:
    0 22px 48px rgba(0,0,0,.75),
    0 0 42px rgba(90,190,255,.28);
}

/* Filters on the right (All statuses / Any deadline) */
.cccxr-filter-pill{
  border-radius: 999px;
  padding: 10px 14px;
  background: linear-gradient(180deg, rgba(14,20,38,.95), rgba(6,10,22,.95));
  border: 1px solid rgba(120,200,255,.25);
  box-shadow:
    0 10px 22px rgba(0,0,0,.5),
    0 0 20px rgba(90,190,255,.14);
}



















/* Variation pills under title (slim, sleek) */
.cccxr-vpills{ display:flex; flex-wrap:wrap; gap:8px; margin-top:6px; }
.cccxr-vpill{
  display:inline-flex; align-items:center; gap:6px;
  padding:10px 7px; border-radius:999px;
  background:rgba(0,0,0,.35);
  border:1px solid rgba(180,200,255,.18);
  color:rgba(255,255,255,.92);
  font-size:.76rem; line-height:1; letter-spacing:.2px;
}
.cccxr-vpill-k{ opacity:.78; font-weight:600; }
.cccxr-vpill-v{ font-weight:800; }
.cccxr-vpill-more{ border-style:dashed; opacity:.9; }








/* Make Details / Get Help / Copy ID into slick pills + push them down */
.cccxr-actions{
  margin-top: 85px;            /* pushes the button row down */
  gap: 10px;
}

/* pill shape + tighter, slick look */
.cccxr-actions .cccxr-btn,
.cccxr-actions .cccxr-btn-primary,
.cccxr-actions .cccxr-btn-ghost{
  border-radius: 999px !important;
  padding: 10px 16px !important;
  min-height: 40px !important;
  line-height: 1 !important;
  font-weight: 950 !important;
  letter-spacing: .15px;
  border: 1px solid rgba(120,205,255,.30) !important;

  background: linear-gradient(180deg, rgba(12,16,28,.98), rgba(4,6,12,.98)) !important;
  box-shadow:
    0 14px 32px rgba(0,0,0,.62),
    0 0 0 1px rgba(90,190,255,.10),
    0 0 22px rgba(90,190,255,.14) !important;
  backdrop-filter: blur(10px);
  -webkit-backdrop-filter: blur(10px);
}

/* hover glow */
.cccxr-actions .cccxr-btn:hover,
.cccxr-actions .cccxr-btn-primary:hover,
.cccxr-actions .cccxr-btn-ghost:hover{
  transform: translateY(-1px);
  border-color: rgba(140,220,255,.46) !important;
  box-shadow:
    0 18px 40px rgba(0,0,0,.70),
    0 0 30px rgba(90,190,255,.22) !important;
}

/* keep Get Help subtly “premium” while still a pill */
.cccxr-actions .cccxr-btn-primary{
  position: relative;
}
.cccxr-actions .cccxr-btn-primary::after{
  content:"";
  position:absolute; inset:-2px;
  border-radius: 999px;
  pointer-events:none;
  box-shadow: 0 0 0 1px rgba(90,190,255,.26), 0 0 34px rgba(90,190,255,.18);
}

/* optional: make row feel more centered/clean */
.cccxr-right{ gap: 12px; }




.cccxr-hero{
  display:flex; justify-content:space-between; gap:14px; flex-wrap:wrap;
  padding:18px 18px 16px; border-radius:22px;
  background:linear-gradient(135deg,#050b18,#0b3b85);
  box-shadow:0 18px 44px rgba(0,0,0,.85);
  border:1px solid rgba(110,170,255,.26);
  position:relative; overflow:hidden; margin-bottom:14px;
}
.cccxr-hero::after{
  content:""; position:absolute; inset:-70%;
  background:
    radial-gradient(circle at 10% 0,rgba(120,200,255,.22) 0,transparent 60%),
    radial-gradient(circle at 90% 0,rgba(40,150,255,.32) 0,transparent 55%),
    radial-gradient(circle at 45% 90%,rgba(255,80,150,.10) 0,transparent 55%);
  opacity:.95; pointer-events:none;
}
.cccxr-hero-left{ position:relative; z-index:1; min-width:280px; }
.cccxr-title{ font-size:1.65rem; font-weight:900; letter-spacing:.2px; text-shadow:0 8px 26px rgba(0,0,0,.55); }
.cccxr-sub{ margin-top:6px; font-size:.90rem; color:rgba(230,238,255,.88); }
.cccxr-micro{ margin-top:10px; display:flex; align-items:center; gap:10px; color:rgba(230,238,255,.84); font-size:.84rem; }
.cccxr-micro-dot{ width:10px; height:10px; border-radius:50%; background:rgba(110,190,255,.9); box-shadow:0 0 18px rgba(110,190,255,.55); }

.cccxr-kpis{ display:flex; gap:10px; align-items:stretch; position:relative; z-index:1; }
.cccxr-kpi{
  min-width:120px;
  padding:10px 12px; border-radius:16px;
  background:rgba(6,20,50,.55);
  border:1px solid rgba(120,190,255,.35);
  box-shadow:0 10px 24px rgba(0,0,0,.35);
}
.cccxr-kpi-k{ font-size:.72rem; opacity:.82; }
.cccxr-kpi-v{ margin-top:4px; font-size:1.25rem; font-weight:900; }
.cccxr-kpi-ok{ border-color:rgba(134,239,172,.25); background:rgba(10,60,45,.26); }

.cccxr-controls{
  display:flex; justify-content:space-between; gap:12px; flex-wrap:wrap;
  padding:12px 12px; border-radius:18px;
  background:linear-gradient(135deg,rgba(6,10,26,.95),rgba(10,18,40,.95));
  border:1px solid rgba(90,150,255,.35);
  box-shadow:0 14px 30px rgba(0,0,0,.72);
  margin-bottom:12px;
  align-items:center;
}

.cccxr-search{
  flex: 1 1 360px;
  display:flex; align-items:center; gap:12px;
  height:52px;
  padding:0 14px;
  border-radius:16px;
  background: linear-gradient(180deg, rgba(255,255,255,.14), rgba(255,255,255,.08));
  border: 1px solid rgba(255,255,255,.14);
  backdrop-filter: blur(10px);
  -webkit-backdrop-filter: blur(10px);
  box-shadow: 0 10px 26px rgba(0,0,0,.25);
}
.cccxr-search:focus-within{
  box-shadow:
    0 0 0 1px rgba(90,190,255,.28),
    0 0 0 4px rgba(90,190,255,.10),
    0 18px 50px rgba(0,0,0,.35);
}
.cccxr-search-ico{
  width:34px; min-width:34px; height:34px;
  border-radius:12px;
  background: rgba(0,0,0,.12);
  border: 1px solid rgba(255,255,255,.14);
  box-shadow: 0 0 0 1px rgba(90,190,255,.12), 0 10px 26px rgba(0,0,0,.20);
  position:relative;
}
.cccxr-search-ico::before{
  content:"";
  position:absolute; inset:0; margin:auto;
  width:16px; height:16px;
  background: no-repeat center/contain url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3E%3Cpath fill='%23000000' d='M10 18a8 8 0 1 1 5.293-14.002A8 8 0 0 1 10 18m0-14a6 6 0 1 0 0 12a6 6 0 0 0 0-12m9.707 16.293l-4.11-4.11a1 1 0 0 1 1.414-1.415l4.11 4.111a1 1 0 0 1-1.414 1.414'/%3E%3C/svg%3E");
  opacity:.9;
}
.cccxr-search-in{
  flex:1 1 auto;
  height:100%;
  border:0; outline:0;
  background: transparent;
  box-shadow:none;
color: rgba(235,250,255,.96) !important; 
  font-size:15px;
  line-height:52px;
  padding:0 6px;
}
.cccxr-search-in::placeholder{ /* typography */
  font-size:15px !important;
  line-height:52px !important; /* centers placeholder/text */
  color: rgba(235,250,255,.96) !important; }

.cccxr-filters{ display:flex; gap:10px; align-items:center; flex:0 0 auto; flex-wrap:wrap; justify-content:flex-end; }
.cccxr-select{
  border-radius:999px;
  padding:10px 12px;
  border:1px solid rgba(130,180,255,.26);
  background:rgba(8,16,40,.92);
  color:#fff;
  font-size:.86rem;
  outline:none;
  min-width:190px;
}
.cccxr-select option{ background:#0b1022; color:#fff; }

.cccxr-pill{
  display:flex; gap:8px; align-items:center;
  padding:10px 12px; border-radius:999px;
  background:rgba(6,20,50,.55);
  border:1px solid rgba(120,190,255,.25);
}
.cccxr-pill-num{ font-weight:900; }
.cccxr-pill-lbl{ opacity:.78; font-size:.82rem; }

.cccxr-list{ display:flex; flex-direction:column; gap:12px; }

.cccxr-case{
  border-radius:20px;
  background:linear-gradient(135deg,rgba(6,10,26,.98),rgba(10,18,40,.98));
  border:1px solid rgba(90,150,255,.32);
  box-shadow:0 16px 36px rgba(0,0,0,.80);
  overflow:hidden;
  position:relative;
}
.cccxr-case::before{
  content:""; position:absolute; inset:0;
  background: radial-gradient(circle at 20% 0, rgba(110,190,255,.14), transparent 55%);
  pointer-events:none; opacity:.9;
}

.cccxr-card{
  display:flex; justify-content:space-between; gap:14px;
  padding:14px 14px;
  position:relative;
  z-index:1;
}

.cccxr-top{ display:flex; gap:12px; align-items:flex-start; flex:1 1 auto; min-width:0; }
.cccxr-thumb{
  width:48px; height:48px; border-radius:16px;
  overflow:hidden;
  border:1px solid rgba(140,190,255,.30);
  background:rgba(255,255,255,.06);
  box-shadow:0 0 18px rgba(80,170,255,.12);
  flex:0 0 auto;
}
.cccxr-thumb img{ width:100%; height:100%; object-fit:cover; display:block; }
.cccxr-thumb-ph{
  width:100%; height:100%;
  background:radial-gradient(circle at 30% 30%, rgba(120,200,255,.18), transparent 60%);
}

.cccxr-main{ min-width:0; flex:1 1 auto; }

.cccxr-product{
  font-size:1.08rem; font-weight:950;
  letter-spacing:.2px;
  text-shadow:0 8px 22px rgba(0,0,0,.55);
  white-space:nowrap; overflow:hidden; text-overflow:ellipsis;
}

.cccxr-meta{
  margin-top:6px;
  font-size:.84rem;
  color:rgba(210,220,245,.86);
  display:flex; gap:8px; flex-wrap:wrap;
}
.cccxr-meta strong{ color:#fff; }
.cccxr-dot{ opacity:.55; }

.cccxr-status-row{ margin-top:10px; display:flex; gap:10px; align-items:center; flex-wrap:wrap; }
.cccxr-status{ font-size:1.05rem; font-weight:950; }
.cccxr-status-requested{ color:#fde68a; }
.cccxr-status-approved{ color:#93c5fd; }
.cccxr-status-awaiting{ color:#7dd3fc; }
.cccxr-status-received{ color:#86efac; }
.cccxr-status-refunded{ color:#6ee7b7; }
.cccxr-status-declined{ color:#fca5a5; }
.cccxr-status-closed{ color:rgba(235,246,255,.90); }

.cccxr-chip{
  padding:6px 10px;
  border-radius:999px;
  font-weight:950;
  font-size:.78rem;
  border:1px solid rgba(120,190,255,.18);
  background: rgba(8,16,40,.62);
}
.cccxr-chip-warn{ border-color: rgba(253,230,138,.22); box-shadow:0 0 22px rgba(253,230,138,.08); }
.cccxr-chip-bad{ border-color: rgba(252,165,165,.22); box-shadow:0 0 22px rgba(252,165,165,.08); }

.cccxr-next{
  margin-top:10px;
  padding:10px 12px;
  border-radius:16px;
  background:rgba(8,16,40,.62);
  border:1px solid rgba(120,190,255,.18);
  box-shadow:0 10px 22px rgba(0,0,0,.32);
}
.cccxr-next-k{ font-size:.78rem; opacity:.78; font-weight:900; letter-spacing:.2px; }
.cccxr-next-v{ margin-top:6px; font-size:.92rem; font-weight:900; color:rgba(235,246,255,.96); }

.cccxr-timeline{
  margin-top:12px;
  display:grid;
  grid-template-columns: repeat(5, minmax(0,1fr));
  gap:8px;
}
.cccxr-step{
  border-radius:14px;
  padding:8px 8px;
  background:rgba(8,16,40,.52);
  border:1px solid rgba(120,190,255,.12);
  display:flex; align-items:center; gap:8px;
  min-width:0;
}
.cccxr-step.is-done{
  border-color: rgba(110,190,255,.26);
  box-shadow: 0 0 22px rgba(90,190,255,.10);
}
.cccxr-step.is-now{
  border-color: rgba(110,190,255,.44);
  box-shadow: 0 0 32px rgba(90,190,255,.22);
}
.cccxr-step.is-off{ opacity:.55; }
.cccxr-dot2{ width:10px; height:10px; border-radius:50%; background:rgba(120,190,255,.55); box-shadow:0 0 18px rgba(90,190,255,.18); flex:0 0 auto; }
.cccxr-step.is-done .cccxr-dot2{ background:rgba(134,239,172,.75); box-shadow:0 0 18px rgba(134,239,172,.18); }
.cccxr-step.is-now .cccxr-dot2{ background:rgba(110,190,255,.95); box-shadow:0 0 22px rgba(110,190,255,.35); }
.cccxr-step-lbl{
  font-size:.72rem;
  font-weight:950;
  letter-spacing:.15px;
  white-space:nowrap;
  overflow:hidden;
  text-overflow:ellipsis;
}

.cccxr-right{
  display:flex;
  flex-direction:column;
  gap:10px;
  align-items:flex-end;
  flex:0 0 auto;
  text-align:right;
}
.cccxr-rma-wrap{
  padding:10px 12px;
  border-radius:16px;
  background:rgba(8,16,40,.58);
  border:1px solid rgba(120,190,255,.18);
  min-width:190px;
}
.cccxr-rma-k{ font-size:.72rem; opacity:.72; font-weight:900; }
.cccxr-rma-v{ margin-top:6px; font-size:.92rem; font-weight:950; color:rgba(230,245,255,.94); word-break:break-word; }

.cccxr-actions{ display:flex; gap:8px; flex-wrap:wrap; justify-content:flex-end; }

.cccxr-btn{
  padding:9px 12px;
  border-radius:999px;
  border:1px solid rgba(120,190,255,.22);
  background:rgba(8,16,40,.72);
  color:rgba(240,248,255,.95);
  font-size:.82rem;
  font-weight:950;
  cursor:pointer;
  transition: transform .16s ease, box-shadow .16s ease, background .16s ease, border-color .16s ease;
  user-select:none;
  min-height:34px;
}
.cccxr-btn:hover{
  transform: translateY(-1px);
  background: rgba(20,40,85,.88);
  border-color: rgba(140,205,255,.38);
  box-shadow: 0 12px 28px rgba(0,0,0,.46), 0 0 26px rgba(90,190,255,.18);
}
.cccxr-btn:active{ transform: translateY(0); }
.cccxr-btn-primary{
  border:0;
  background: linear-gradient(120deg,#2a88ff,#6ec1e4);
  color:#fff;
  box-shadow: 0 12px 26px rgba(0,0,0,.42), 0 0 26px rgba(60,160,255,.28);
}
.cccxr-btn-primary:hover{
  box-shadow: 0 16px 34px rgba(0,0,0,.48), 0 0 36px rgba(90,190,255,.55);
}
.cccxr-btn-ghost{
  background:rgba(255,255,255,.06);
  border-color:rgba(255,255,255,.14);
}

.cccxr-drawer{
  border-top:1px solid rgba(120,190,255,.18);
  background:linear-gradient(135deg,rgba(6,10,26,.88),rgba(10,18,40,.88));
  padding:12px 14px 14px;
  position:relative;
  z-index:1;
}
.cccxr-drawer-grid{
  display:grid;
  grid-template-columns: repeat(3, minmax(0,1fr));
  gap:10px;
}
.cccxr-box{
  border-radius:16px;
  padding:12px 12px;
  background:rgba(8,16,40,.70);
  border:1px solid rgba(120,190,255,.20);
  box-shadow:0 10px 22px rgba(0,0,0,.35);
  min-width:0;
}
.cccxr-box-k{ font-size:.72rem; opacity:.72; font-weight:900; }
.cccxr-box-v{ margin-top:6px; font-size:.90rem; font-weight:900; color:rgba(235,246,255,.96); }
.cccxr-box-wide{ grid-column: 1 / -1; }
.cccxr-box-actions{ margin-top:10px; display:flex; gap:10px; justify-content:flex-end; }

.cccxr-foot{
  grid-column: 1 / -1;
  display:flex;
  justify-content:space-between;
  align-items:center;
  gap:10px;
  margin-top:4px;
}
.cccxr-link{
  padding:9px 12px;
  border-radius:999px;
  background:rgba(255,255,255,.06);
  border:1px solid rgba(120,190,255,.18);
  font-weight:950;
}
.cccxr-link:hover{
  background: rgba(20,40,85,.88);
  border-color: rgba(140,205,255,.34);
  box-shadow: 0 0 22px rgba(90,190,255,.16);
}

.cccxr-mini{
  border:1px solid rgba(120,190,255,.18);
  background: rgba(8,16,40,.62);
  padding:8px 12px;
  border-radius:999px;
  font-weight:950;
  cursor:pointer;
  color:#fff;
}
.cccxr-mini:hover{
  background: rgba(20,40,85,.88);
  border-color: rgba(140,205,255,.34);
  box-shadow: 0 0 22px rgba(90,190,255,.16);
}

.cccxr-empty{
  padding:18px;
  border-radius:18px;
  background:linear-gradient(135deg,rgba(6,10,26,.95),rgba(10,18,40,.95));
  border:1px solid rgba(90,150,255,.25);
  box-shadow:0 14px 30px rgba(0,0,0,.72);
}
.cccxr-empty-title{ font-size:1.05rem; font-weight:950; }
.cccxr-empty-sub{ margin-top:6px; opacity:.82; font-size:.90rem; }

.cccxr-toast{
  position:fixed;
  right:18px;
  bottom:18px;
  z-index:999999;
  padding:12px 14px;
  border-radius:16px;
  background:rgba(8,16,40,.92);
  border:1px solid rgba(120,190,255,.22);
  box-shadow:0 18px 40px rgba(0,0,0,.75);
  font-weight:950;
}

@media (max-width: 1100px){
  .cccxr-timeline{ grid-template-columns: repeat(2, minmax(0,1fr)); }
}
@media (max-width: 980px){
  .cccxr-card{ flex-direction:column; }
  .cccxr-right{ align-items:flex-start; text-align:left; }
  .cccxr-rma-wrap{ width:100%; min-width:0; }.cccxr-actions{ justify-content:flex-start; }
  .cccxr-drawer-grid{ grid-template-columns: 1fr; }
  .cccxr-foot{ flex-direction:column; align-items:flex-start; }
}
@media (max-width: 768px){
  .cccxr-search{ height:46px; border-radius:14px; }
  .cccxr-search-in{ line-height:46px; font-size:14px; }
  .cccxr-select{ min-width:160px; }
  
}
body.cc-support-open .cccxr{
  z-index: 0 !important;
  position: relative;
}
/* ============================================================
 * REQUESTED TWEAKS (safe overrides; no layout refactor)
 * 1) Manual “lever” to push search up/down
 *    -> edit --cccxr-search-shift on .cccxr (px, negative = up)
 * 2) Style Details / Get Help / Copy ID + drawer minis as black gradient
 *    with faint neon blue glow (sleek/slim)
 * 3) Slightly tighten the search to visually match those buttons
 * ============================================================ */

.cccxr-search{
  transform: translateY(var(--cccxr-search-shift));
}

/* Button family: black gradient + neon blue edge */
.cccxr-actions .cccxr-btn,
.cccxr-actions .cccxr-btn-primary,
.cccxr-actions .cccxr-btn-ghost,
.cccxr-drawer .cccxr-mini,
.cccxr-drawer .cccxr-link,
.cccxr-drawer .cccxr-mini{
  background: linear-gradient(180deg, rgba(10,14,26,.98), rgba(4,6,12,.98));
  border: 1px solid rgba(90,190,255,.26);
  color: rgba(240,248,255,.96);
  box-shadow:
    0 12px 28px rgba(0,0,0,.55),
    0 0 0 1px rgba(90,190,255,.10),
    0 0 18px rgba(90,190,255,.10);
}

.cccxr-actions .cccxr-btn:hover,
.cccxr-actions .cccxr-btn-primary:hover,
.cccxr-actions .cccxr-btn-ghost:hover,
.cccxr-drawer .cccxr-mini:hover,
.cccxr-drawer .cccxr-link:hover{
  transform: translateY(-1px);
  border-color: rgba(120,205,255,.38);
  box-shadow:
    0 16px 34px rgba(0,0,0,.62),
    0 0 24px rgba(90,190,255,.18);
}

/* Keep “Get Help” visually special, but still black-gradient */
.cccxr-actions .cccxr-btn-primary{
  position:relative;
}
.cccxr-actions .cccxr-btn-primary::after{
  content:"";
  position:absolute; inset:-1px;
  border-radius:999px;
  pointer-events:none;
  box-shadow: 0 0 0 1px rgba(90,190,255,.28), 0 0 26px rgba(90,190,255,.18);
}

/* Search: slightly more “button-like” while keeping black input text */
.cccxr-search{
  border: 1px solid rgba(90,190,255,.20);
  box-shadow:
    0 12px 28px rgba(0,0,0,.28),
    0 0 0 1px rgba(90,190,255,.08);
}
.cccxr-search:focus-within{
  box-shadow:
    0 0 0 1px rgba(90,190,255,.28),
    0 0 0 4px rgba(90,190,255,.10),
    0 18px 50px rgba(0,0,0,.35);
}

















CSS
    );

    wp_add_inline_script( 'cccxr-script', <<<JS
(function(){
  const root = document.querySelector('.cccxr');
  if(!root) return;

  const toast = root.querySelector('.cccxr-toast');
  function showToast(msg){
    if(!toast) return;
    toast.textContent = msg;
    toast.hidden = false;
    toast.style.opacity = '1';
    clearTimeout(showToast._t);
    showToast._t = setTimeout(()=>{ toast.style.opacity='0'; setTimeout(()=>{ toast.hidden=true; }, 220); }, 1600);
  }

  function toggleDrawer(caseEl){
    const drawer = caseEl.querySelector('.cccxr-drawer');
    if(!drawer) return;
    const btn = caseEl.querySelector('[data-act="toggle"]');
    const open = !drawer.hidden;
    drawer.hidden = open ? true : false;
    if(btn) btn.setAttribute('aria-expanded', open ? 'false' : 'true');
    showToast(open ? 'Closed' : 'Opened');
  }

  // ===== Fix: “Get Help” reliability =====
  // We do NOT assume how your support system is wired.
  // We fire multiple safe signals so ANY existing listener can catch it.
  function fireSupportOpen(btn){
    const d = btn.dataset || {};
    const payload = {
      order_id: d.orderId || d.order_id || '',
      order_number: d.orderNumber || d.order_number || '',
      rma: d.rma || '',
      item_id: d.itemId || d.item_id || '',
      product_id: d.productId || d.product_id || ''
    };

    try{
      window.dispatchEvent(new CustomEvent('cc-support-open', { detail: payload }));
      window.dispatchEvent(new CustomEvent('cc_support_open', { detail: payload }));
    }catch(_){}

    // Optional direct-call fallbacks (won’t throw)
    try{
      if (window.CaricoveSupport && typeof window.CaricoveSupport.open === 'function') {
        window.CaricoveSupport.open(payload);
      }
    }catch(_){}

    showToast('Opening support…');
  }

  root.addEventListener('click', async function(e){
    // Support launcher (must come first; it’s not data-act)
 const supportBtn = e.target.closest('[data-cc-support]');
if (supportBtn && root.contains(supportBtn)) {

  const d = supportBtn.dataset || {};
  const payload = {
    order_id: d.orderId || '',
    order_number: d.orderNumber || '',
    rma: d.rma || '',
    item_id: d.itemId || '',
    product_id: d.productId || ''
  };

  // Mark body so CSS stacking fix activates
  document.body.classList.add('cc-support-open');

  // Fire to body (not root) so MU always receives it
  document.body.dispatchEvent(
    new CustomEvent('caricove:support_open', {
      bubbles: true,
      detail: payload
    })
  );

  showToast('Opening support…');
  return;
}

    const actBtn = e.target.closest('[data-act]');
    if(!actBtn) return;

    const caseEl = actBtn.closest('.cccxr-case');
    if(!caseEl) return;

    const act = actBtn.getAttribute('data-act');

    if(act === 'toggle'){
      toggleDrawer(caseEl);
      return;
    }

    if(act === 'copy'){
      const v = actBtn.getAttribute('data-copy') || '';
      if(!v){ showToast('Nothing to copy'); return; }
      try{
        await navigator.clipboard.writeText(v);
        showToast('Copied');
      }catch(_){
        try{
          const ta = document.createElement('textarea');
          ta.value = v;
          document.body.appendChild(ta);
          ta.select();
          document.execCommand('copy');
          document.body.removeChild(ta);
          showToast('Copied');
        }catch(__){
          showToast('Copy failed');
        }
      }
      return;
    }
  });

  // Search + filters
  const search = root.querySelector('.cccxr-search-in');
  const selStatus = root.querySelector('[data-filter="status"]');
  const selDeadline = root.querySelector('[data-filter="deadline"]');

  function applyFilters(){
    const q = (search && search.value ? search.value.trim().toLowerCase() : '');
    const fs = (selStatus && selStatus.value) ? selStatus.value : '';
    const fd = (selDeadline && selDeadline.value) ? selDeadline.value : '';

    const rows = root.querySelectorAll('.cccxr-case');
    rows.forEach(row=>{
      const blob = row.getAttribute('data-search') || '';
      const st = row.getAttribute('data-status') || '';
      const dl = row.getAttribute('data-deadline') || '';

      let ok = true;

      if(q){ ok = blob.includes(q); }
      if(ok && fs){ ok = (st === fs); }
      if(ok && fd){ ok = (dl === fd); }

      row.style.display = ok ? '' : 'none';
    });
  }

  if(search) search.addEventListener('input', applyFilters);
  if(selStatus) selStatus.addEventListener('change', applyFilters);
  if(selDeadline) selDeadline.addEventListener('change', applyFilters);
  
  
  
  

 
  
  
  
  
})();
JS
    );
});