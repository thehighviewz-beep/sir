<?php
/**
 * Plugin Name: Caricove — Seller Returns Console (Sexy) v3
 * Description: Seller-facing Returns & RMAs console. Uses proven discovery logic (scan recent orders + read _caricove_return_cases; fallback to line-item metas). Includes search/filters + action drawer + AJAX status updates.
 * Version: 3.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ============================================================
 * CANONICAL META (DO NOT CHANGE)
 * ============================================================ */
if ( ! defined( 'CC_RETURNS_META_CASES' ) ) {
    define( 'CC_RETURNS_META_CASES', '_caricove_return_cases' );
}
if ( ! defined( 'CC_RETURNS_META_LAST_SUMMARY' ) ) {
    define( 'CC_RETURNS_META_LAST_SUMMARY', '_caricove_last_refund_summary' );
}


if ( ! function_exists( 'ccsr3_get_order_cases_for_discovery' ) ) {
    function ccsr3_get_order_cases_for_discovery( $order ) {
        if ( ! $order instanceof WC_Order ) return [];

        if ( class_exists( '\Caricove\Bank\BankRefundCases' ) ) {
            $cases = \Caricove\Bank\BankRefundCases::list_legacy_cases_for_order( (int) $order->get_id() );
            if ( empty( $cases ) && (int) $order->get_parent_id() > 0 ) {
                $cases = \Caricove\Bank\BankRefundCases::list_legacy_cases_for_order( (int) $order->get_parent_id() );
            }
            if ( is_array( $cases ) ) {
                return array_values( array_filter( $cases, 'is_array' ) );
            }
        }

        $stored = get_post_meta( (int) $order->get_id(), CC_RETURNS_META_CASES, true );
        if ( is_array( $stored ) ) {
            return $stored;
        }

        if ( (int) $order->get_parent_id() > 0 ) {
            $stored = get_post_meta( (int) $order->get_parent_id(), CC_RETURNS_META_CASES, true );
            if ( is_array( $stored ) ) {
                return $stored;
            }
        }

        return [];
    }
}

/* ============================================================
 * ADMIN FINALITY GUARD (gospel): once admin marks Refunded/Declined,
 * no seller action may override or change that case again.
 * ============================================================ */

if ( ! function_exists( 'ccsr3_case_is_shipping_only_pre_return' ) ) {
    function ccsr3_case_is_shipping_only_pre_return( $case ) {
        if ( ! is_array( $case ) ) return false;

        $financial_status = sanitize_key( (string) ( $case['financial_status'] ?? '' ) );
        $decision_code    = strtoupper( trim( (string) ( $case['decision_code'] ?? '' ) ) );
        $return_required  = ! empty( $case['return_required'] ) || $decision_code === 'RETURN_REQUIRED';
        $qty_received     = (int) ( $case['qty_received'] ?? 0 );
        $item_received    = ! empty( $case['item_received_flag'] ) || $qty_received > 0;
        $shipping_amount  = (float) ( $case['outbound_shipping_refund_amount_customer'] ?? 0 );
        $item_amount      = (float) ( $case['item_refund_amount_customer'] ?? 0 );

        return $return_required
            && ! $item_received
            && $shipping_amount > 0
            && $item_amount <= 0
            && in_array( $financial_status, [ 'shipping_posted', 'refund_posted' ], true );
    }
}

if ( ! function_exists( 'ccsr3_case_admin_is_final' ) ) {
    function ccsr3_case_admin_is_final( $case ) {
        if ( ! is_array( $case ) ) return false;

        $norm = function( $v ) {
            $v = strtolower( trim( (string) $v ) );
            $v = str_replace( [ ' ', '-' ], '_', $v );
            return $v;
        };

        // 1) Most common: case status itself becomes refunded/declined
        $status = $norm( $case['status'] ?? '' );
        if ( in_array( $status, [ 'declined' ], true ) ) return true;
        if ( $status === 'refunded' && ! ccsr3_case_is_shipping_only_pre_return( $case ) ) return true;

        // 2) Defensive: admin console may store final decision under other keys
        $keys = [
            'admin_status',
            'admin_action',
            'admin_decision',
            'refund_admin_status',
            'refund_decision',
            'refund_status',
            'final_decision',
            'final_status',
            'admin_refund_status',
            'admin_refund_decision',
            'admin_outcome',
        ];

        foreach ( $keys as $k ) {
            if ( ! isset( $case[ $k ] ) ) continue;
            $v = $norm( $case[ $k ] );
            if ( in_array( $v, [ 'refunded', 'declined' ], true ) ) return true;
        }

        return false;
    }
}

if ( ! function_exists( 'ccsr3_case_admin_final_label' ) ) {
    function ccsr3_case_admin_final_label( $case ) {
        if ( ! is_array( $case ) ) return '';

        $norm = function( $v ) {
            $v = strtolower( trim( (string) $v ) );
            $v = str_replace( [ ' ', '-' ], '_', $v );
            return $v;
        };

        $candidates = [];
        $candidates[] = $case['status'] ?? '';

        foreach ( [
            'admin_status','admin_action','admin_decision','refund_admin_status','refund_decision','refund_status',
            'final_decision','final_status','admin_refund_status','admin_refund_decision','admin_outcome'
        ] as $k ) {
            if ( isset( $case[ $k ] ) ) $candidates[] = $case[ $k ];
        }

        foreach ( $candidates as $v ) {
            $n = $norm( $v );
            if ( $n === 'refunded' ) return 'Refunded';
            if ( $n === 'declined' ) return 'Declined';
        }

        return '';
    }
}









// --- Returns UI: Dedupe title + slim variation pills (max 3 +N) ---
if ( ! function_exists('ccsr3_norm_size_value') ) {
  function ccsr3_norm_size_value( $v ) {
    $v = trim((string)$v);
    if ( $v === '' ) return '';
    // Force one-letter sizes to uppercase (l->L, m->M, s->S)
    if ( mb_strlen($v) === 1 ) return strtoupper($v);
    // Also handle common 2–3 letter sizes (xs/xl/xxl etc)
    $raw = preg_replace('/\s+/', '', $v);
    if ( preg_match('/^[a-z]{2,4}$/i', $raw) ) return strtoupper($raw);
    return $v;
  }
}

if ( ! function_exists('ccsr3_title_and_pills_from_order_item') ) {
  function ccsr3_title_and_pills_from_order_item( $order_id, $order_item_id, $fallback_name = '' ) {

    $out = [
      'title'      => (string)$fallback_name,
      'pills_html' => '',
    ];

    if ( ! function_exists('wc_get_order') ) return $out;

    $order_id = (int)$order_id;
    $order_item_id = (int)$order_item_id;

    if ( $order_id <= 0 || $order_item_id <= 0 ) return $out;

    $order = wc_get_order($order_id);
    if ( ! $order ) return $out;

    $item = $order->get_item($order_item_id);
    if ( ! $item || ! is_a($item, 'WC_Order_Item_Product') ) return $out;

    $product = $item->get_product();
    if ( ! $product ) {
      $out['title'] = (string)($item->get_name() ?: $fallback_name);
      return $out;
    }

    // DEDUPE TITLE: if variation, show parent title
    $title = (string)$product->get_name();
    if ( method_exists($product,'is_type') && $product->is_type('variation') && method_exists($product,'get_parent_id') ) {
      $parent_id = (int)$product->get_parent_id();
      if ( $parent_id > 0 && function_exists('wc_get_product') ) {
        $parent = wc_get_product($parent_id);
        if ( $parent ) $title = (string)$parent->get_name();
      }
    }
    $out['title'] = $title;

    // REAL variation attributes from the ORDER ITEM (truth; no dokan/meta junk)
// REAL variation attributes (Woo-safe): prefer variation PRODUCT attrs, fallback to order-item meta
$raw = [];

if ( $product && method_exists($product,'is_type') && $product->is_type('variation') && method_exists($product,'get_variation_attributes') ) {
  // Best source: WC_Product_Variation attributes (truth)
  $raw = (array) $product->get_variation_attributes(); // ['attribute_pa_size'=>'l', 'attribute_color'=>'white', ...]
} else {
  // Fallback: order-item meta keys like attribute_pa_size / attribute_color
  if ( method_exists($item,'get_meta_data') ) {
    foreach ( (array) $item->get_meta_data() as $md ) {
      if ( ! is_object($md) || ! method_exists($md,'get_data') ) continue;
     $d = $md->get_data();
$k = isset($d['key']) ? (string) $d['key'] : '';

// value can be string|array|object — normalize to string safely
$v = '';
if ( array_key_exists('value', $d) ) {
  $vv = $d['value'];

  if ( is_array($vv) ) {
    $flat = [];
    foreach ( $vv as $one ) {
      if ( is_scalar($one) ) $flat[] = (string) $one;
      elseif ( is_object($one) && method_exists($one,'__toString') ) $flat[] = (string) $one;
    }
    $v = trim(implode(', ', array_filter($flat)));
  } elseif ( is_scalar($vv) ) {
    $v = trim((string) $vv);
  } elseif ( is_object($vv) && method_exists($vv,'__toString') ) {
    $v = trim((string) $vv);
  }
}

if ( $k === '' || $v === '' ) continue;

if ( strpos($k,'attribute_') === 0 ) {
  $raw[$k] = $v; // already in attribute_* form
}
    }
  }
}

if ( empty($raw) || ! is_array($raw) ) return $out;    if ( empty($raw) || ! is_array($raw) ) return $out;

    $pairs = [];
    foreach ( $raw as $k => $v ) {
      $v = trim((string)$v);
      if ( $v === '' ) continue;

      $tax = sanitize_key( str_replace('attribute_', '', (string)$k) );

      // Label
      $label = function_exists('wc_attribute_label') ? wc_attribute_label($tax) : $tax;
      $label = $label ? $label : $tax;

      // If taxonomy, convert slug->term name (so l becomes L if term name is "L")
      if ( taxonomy_exists($tax) ) {
        $term = get_term_by('slug', $v, $tax);
        if ( $term && ! is_wp_error($term) && ! empty($term->name) ) {
          $v = (string)$term->name;
        }
      }

      // Normalize sizes (L/M/S/XS/XL)
      if ( stripos($label, 'size') !== false ) {
        $v = ccsr3_norm_size_value($v);
      } else {
        // keep value as-is (no guessing)
        $v = trim((string)$v);
      }

      $label = trim((string)$label);
      if ( $label === '' || $v === '' ) continue;

      $pairs[] = [$label, $v];
    }

    if ( empty($pairs) ) return $out;

    $max = 3;
    $shown = array_slice($pairs, 0, $max);
    $more  = max(0, count($pairs) - count($shown));

    $html = '<div class="ccsr3-vpills">';
    foreach ($shown as $p) {
      $html .= '<span class="ccsr3-vpill"><span class="ccsr3-vpill-k">'.esc_html($p[0]).':</span><span class="ccsr3-vpill-v">'.esc_html($p[1]).'</span></span>';
    }
    if ( $more > 0 ) {
      $html .= '<span class="ccsr3-vpill ccsr3-vpill--more">+'.intval($more).' more</span>';
    }
    $html .= '</div>';

    $out['pills_html'] = $html;
    return $out;
  }
}








/* ============================================================
 * PATCH: show refund/declined amounts on the status pill
 * - Refund amount: case keys -> _caricove_last_refund_summary -> Woo refund totals (fallback)
 * - Declined amount: case “requested” keys -> prorated line total (fallback)
 * ============================================================ */
if ( ! function_exists( 'ccsr3_money_text' ) ) {
    function ccsr3_money_text( $amount, $currency = '' ) {
        $amount = (float) $amount;
        if ( $amount <= 0 ) return '';
        if ( function_exists( 'wc_price' ) ) {
            $cur = $currency ?: ( function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : '' );
            return wp_strip_all_tags( wc_price( $amount, [ 'currency' => $cur ] ) );
        }
        return number_format( $amount, 2 );
    }
}

if ( ! function_exists( 'ccsr3_case_amounts' ) ) {
    function ccsr3_case_amounts( $order, $case ) {
        $refund_amt = 0.0;
        $req_amt    = 0.0;
        $currency   = '';

        if ( is_array( $case ) ) {
            $currency = (string) ( $case['refund_currency'] ?? $case['currency'] ?? '' );

            // 1) Direct refund amount keys on the case (if admin console wrote it)
            foreach ( [
                'refund_amount', 'refunded_amount', 'refund_total', 'refund', 'amount_refunded',
                'refund_amount_value', 'refund_value'
            ] as $k ) {
                if ( isset( $case[ $k ] ) && is_numeric( $case[ $k ] ) ) {
                    $refund_amt = max( $refund_amt, (float) $case[ $k ] );
                }
            }

            // 2) Requested/declined amount keys on the case
            foreach ( [
                'requested_amount', 'request_amount', 'refund_amount_requested', 'amount_requested',
                'declined_amount', 'deny_amount'
            ] as $k ) {
                if ( isset( $case[ $k ] ) && is_numeric( $case[ $k ] ) ) {
                    $req_amt = max( $req_amt, (float) $case[ $k ] );
                }
            }
        }

        // 3) Pull from canonical order meta summary (if your wizard stored it)
        if ( $order instanceof WC_Order ) {
            $sum = get_post_meta( (int) $order->get_id(), CC_RETURNS_META_LAST_SUMMARY, true );
            $rma = is_array( $case ) ? (string) ( $case['rma_id'] ?? '' ) : '';
            $iid = is_array( $case ) ? (int) ( $case['item_id'] ?? 0 ) : 0;

            if ( is_array( $sum ) ) {
                // common nested shapes
                $paths = [
                    [ 'by_rma', $rma, 'amount' ],
                    [ 'by_rma', $rma, 'refund_amount' ],
                    [ 'cases',  $rma, 'amount' ],
                    [ 'rmas',   $rma, 'amount' ],
                    [ 'refunds',$rma, 'amount' ],
                ];
                foreach ( $paths as $p ) {
                    if ( ! $rma ) continue;
                    $v = $sum;
                    foreach ( $p as $seg ) {
                        if ( ! is_array( $v ) || ! array_key_exists( $seg, $v ) ) { $v = null; break; }
                        $v = $v[ $seg ];
                    }
                    if ( is_numeric( $v ) ) $refund_amt = max( $refund_amt, (float) $v );
                }

                // scan list-like summaries
                foreach ( $sum as $row ) {
                    if ( ! is_array( $row ) ) continue;

                    $row_rma = (string) ( $row['rma_id'] ?? $row['rma'] ?? '' );
                    $row_iid = (int) ( $row['item_id'] ?? 0 );

                    $matches = false;
                    if ( $rma && $row_rma === $rma ) $matches = true;
                    if ( ! $matches && $iid && $row_iid === $iid ) $matches = true;
                    if ( ! $matches ) continue;

                    foreach ( [ 'amount','refund_amount','refunded','refunded_amount','total','refund_total' ] as $k ) {
                        if ( isset( $row[$k] ) && is_numeric( $row[$k] ) ) {
                            $refund_amt = max( $refund_amt, (float) $row[$k] );
                        }
                    }
                    foreach ( [ 'requested_amount','amount_requested','requested','request' ] as $k ) {
                        if ( isset( $row[$k] ) && is_numeric( $row[$k] ) ) {
                            $req_amt = max( $req_amt, (float) $row[$k] );
                        }
                    }
                    if ( ! $currency && ! empty( $row['currency'] ) ) $currency = (string) $row['currency'];
                }
            }

            // 4) Woo fallback: if refunded but still no amount, use order total refunded
            if ( $refund_amt <= 0 && method_exists( $order, 'get_total_refunded' ) ) {
                $refund_amt = max( $refund_amt, (float) $order->get_total_refunded() );
            }

            // 5) Declined fallback: compute “requested” from line total prorated by qty
            if ( $req_amt <= 0 && is_array( $case ) ) {
                $iid = (int) ( $case['item_id'] ?? 0 );
                if ( $iid > 0 ) {
                    $oi = $order->get_item( $iid );
                    if ( $oi instanceof WC_Order_Item_Product ) {
                        $line_total = (float) $oi->get_total(); // excludes tax/shipping
                        $line_qty   = (int) $oi->get_quantity();
                        $case_qty   = isset( $case['qty'] ) ? max( 1, (int) $case['qty'] ) : max( 1, $line_qty );
                        if ( $line_qty > 0 ) {
                            $req_amt = max( $req_amt, ( $line_total / $line_qty ) * $case_qty );
                        }
                    }
                }
            }
        }

        return [ $refund_amt, $req_amt, $currency ];
    }
}








function ccsr3_materialize_all_vendor_cases_from_item_metas( WC_Order $order, $vendor_id ) {
    $vendor_id = (int) $vendor_id;
    $out = [];

    foreach ( $order->get_items() as $item_id => $item ) {
        $item_id = (int) $item_id;
        if ( $item_id <= 0 ) continue;

        // Resolve vendor ownership (prefer explicit meta, fallback to product author)
        $vid = (int) wc_get_order_item_meta( $item_id, '_caricove_vendor_id', true );
        if ( $vid <= 0 && is_object($item) && method_exists($item,'get_product') ) {
            $p = $item->get_product();
            $pid = $p ? (int) $p->get_id() : 0;
            if ( $pid > 0 ) $vid = (int) get_post_field( 'post_author', $pid );
        }
        if ( $vid !== $vendor_id ) continue;

        // --- NEW truth layer: item-scoped case_type/status (return requests + lifecycle) ---
        $case_type   = strtolower( (string) wc_get_order_item_meta( $item_id, '_caricove_case_type', true ) );
        $case_status = strtolower( (string) wc_get_order_item_meta( $item_id, '_caricove_case_status', true ) );

        // --- Legacy fallback layer (older refund/return flows) ---
        $legacy_ret_status = strtolower( (string) wc_get_order_item_meta( $item_id, '_caricove_return_status', true ) );
       $ret_req = (int) wc_get_order_item_meta( $item_id, '_caricove_return_required', true );
$qty_ref = (float) wc_get_order_item_meta( $item_id, '_caricove_qty_refunded', true );

if ( $ret_req === 0 ) {
    continue;
}

$is_new_return = ( $case_type === 'return' && $case_status !== '' );
$is_legacy_return = ( $ret_req === 1 && $qty_ref > 0 );

        if ( ! $is_new_return && ! $is_legacy_return && $legacy_ret_status === '' ) {
            continue;
        }

        $order_id     = (int) $order->get_id();
        $order_number = (string) $order->get_order_number();
        $rma_guess    = 'RCC-' . $order_id . '-' . $item_id;

        // Quantity: prefer explicit requested qty, then refunded qty, then line qty
        $qty_req = wc_get_order_item_meta( $item_id, '_caricove_qty_return_requested', true );
        if ( $qty_req === '' ) $qty_req = wc_get_order_item_meta( $item_id, '_caricove_qty_requested', true );
        $qty = (int) ( is_numeric($qty_req) ? $qty_req : 0 );
        if ( $qty <= 0 && $qty_ref > 0 ) $qty = (int) $qty_ref;
        if ( $qty <= 0 && is_object($item) && method_exists($item,'get_quantity') ) $qty = (int) $item->get_quantity();
        if ( $qty < 0 ) $qty = 0;

        // Status mapping: prefer new case_status, then legacy return_status, then awaiting_return
        $status = $case_status ?: $legacy_ret_status;
        if ( $status === '' && $is_legacy_return ) $status = 'awaiting_return';
        if ( $status === '' ) $status = 'requested';

        // Normalize common aliases
        if ( $status === 'request' ) $status = 'requested';
        if ( $status === 'awaiting_return' ) $status = 'awaiting_return';

        $out[] = [
            'rma_id'          => $rma_guess,
            'order_id'        => $order_id,
            'order_number'    => $order_number,
            'item_id'         => $item_id,
            'product_name'    => is_object( $item ) && method_exists( $item, 'get_name' ) ? (string) $item->get_name() : '',
            'qty'             => $qty,
            'reason_label'    => (string) wc_get_order_item_meta( $item_id, '_caricove_reason_label', true ),
            'status'          => $status,
            'deadline'        => 0,
            'created'         => time(),
            'updated'         => time(),
            'vendor_id'       => $vendor_id,
            'vendor_name'     => (string) wc_get_order_item_meta( $item_id, '_caricove_vendor_name', true ),
            'return_address'  => (string) wc_get_order_item_meta( $item_id, '_caricove_return_address', true ),
        ];
    }

    return $out;
}

















/* ============================================================
 * PATCH (CRITICAL): inferred cases are now actionable.
 * If order-level cases meta is missing OR the vendor case isn't found,
 * we materialize the case from item-level metas (safe vendor-locked),
 * then proceed with the status update.
 * ============================================================ */
if ( ! function_exists( 'ccsr3_try_materialize_case_from_item_metas' ) ) {
    function ccsr3_try_materialize_case_from_item_metas( WC_Order $order, $vendor_id, $rma_id ) {
    $vendor_id = (int) $vendor_id;
    $rma_id    = (string) $rma_id;

    // Parse RCC-<order_id>-<item_id> if possible (fast path)
    $parsed_item_id = 0;
    if ( preg_match( '/^RCC\-\d+\-(\d+)$/', $rma_id, $m ) ) {
        $parsed_item_id = absint( $m[1] );
    }

    $items = $order->get_items();
    if ( empty( $items ) ) return null;

    foreach ( $items as $item_id => $item ) {
        $item_id = (int) $item_id;
        if ( $parsed_item_id && $item_id !== $parsed_item_id ) continue;

        // Resolve vendor ownership (prefer explicit meta, fallback to product author)
        $vid = (int) wc_get_order_item_meta( $item_id, '_caricove_vendor_id', true );
        if ( $vid <= 0 && is_object($item) && method_exists($item,'get_product') ) {
            $p = $item->get_product();
            $pid = $p ? (int) $p->get_id() : 0;
            if ( $pid > 0 ) $vid = (int) get_post_field( 'post_author', $pid );
        }
        if ( $vid !== $vendor_id ) continue;

        // NEW truth layer
        $case_type   = strtolower( (string) wc_get_order_item_meta( $item_id, '_caricove_case_type', true ) );
        $case_status = strtolower( (string) wc_get_order_item_meta( $item_id, '_caricove_case_status', true ) );
        $legacy_ret_status = strtolower( (string) wc_get_order_item_meta( $item_id, '_caricove_return_status', true ) );

        // Legacy layer (older refund-required returns)
       $ret_req = (int) wc_get_order_item_meta( $item_id, '_caricove_return_required', true );
$qty_ref = (float) wc_get_order_item_meta( $item_id, '_caricove_qty_refunded', true );

if ( $ret_req === 0 ) {
    continue;
}

$ok = false;
if ( $case_type === 'return' && $case_status !== '' ) $ok = true;
        if ( $legacy_ret_status !== '' ) $ok = true;
        if ( $ret_req === 1 && $qty_ref > 0 ) $ok = true;
        if ( ! $ok ) continue;

        $order_id     = (int) $order->get_id();
        $order_number = (string) $order->get_order_number();
        $rma_guess    = $rma_id ?: ( 'RCC-' . $order_id . '-' . $item_id );

        // Quantity: requested > refunded > line qty
        $qty_req = wc_get_order_item_meta( $item_id, '_caricove_qty_return_requested', true );
        if ( $qty_req === '' ) $qty_req = wc_get_order_item_meta( $item_id, '_caricove_qty_requested', true );
        $qty = (int) ( is_numeric($qty_req) ? $qty_req : 0 );
        if ( $qty <= 0 && $qty_ref > 0 ) $qty = (int) $qty_ref;
        if ( $qty <= 0 && is_object($item) && method_exists($item,'get_quantity') ) $qty = (int) $item->get_quantity();
        if ( $qty < 0 ) $qty = 0;

        // Status mapping
        $status = $case_status ?: $legacy_ret_status;
        if ( $status === '' && $ret_req === 1 && $qty_ref > 0 ) $status = 'awaiting_return';
        if ( $status === '' ) $status = 'requested';

        return [
            'rma_id'          => $rma_guess,
            'order_id'        => $order_id,
            'order_number'    => $order_number,
            'item_id'         => $item_id,
            'product_name'    => is_object( $item ) && method_exists( $item, 'get_name' ) ? (string) $item->get_name() : '',
            'qty'             => $qty,
            'reason_label'    => (string) wc_get_order_item_meta( $item_id, '_caricove_reason_label', true ),
            'status'          => $status,
            'deadline'        => 0,
            'created'         => time(),
            'updated'         => time(),
            'vendor_id'       => $vendor_id,
            'vendor_name'     => (string) wc_get_order_item_meta( $item_id, '_caricove_vendor_name', true ),
            'return_address'  => (string) wc_get_order_item_meta( $item_id, '_caricove_return_address', true ),
        ];
    }

    return null;
}

}

/* ============================================================
 * SHORTCODE: [caricove_seller_returns_console]
 * ============================================================ */
add_shortcode( 'caricove_seller_returns_console', function () {

    if ( ! is_user_logged_in() ) {
        return '<div class="ccsr3">Please log in.</div>';
    }

    if ( ! class_exists( 'WooCommerce' ) || ! function_exists( 'wc_get_orders' ) ) {
        return '<div class="ccsr3">WooCommerce required.</div>';
    }

    $vendor_id = (int) get_current_user_id();

    // Scan window (tune-safe defaults)
    $limit = 300;
    $days  = 365;
    $since = gmdate( 'Y-m-d', time() - ( $days * DAY_IN_SECONDS ) );

    // Normalize statuses (wc_get_orders typically expects sans "wc-")
    $all_statuses = array_map( function( $s ) {
        return str_replace( 'wc-', '', (string) $s );
    }, array_keys( wc_get_order_statuses() ) );

    // Pull recent orders WITHOUT meta filtering (read meta ourselves)
    // Use date_created filter for better compatibility.
    $orders = wc_get_orders( [
        'limit'        => $limit,
        'orderby'      => 'date',
        'order'        => 'DESC',
        'date_created' => '>' . $since,
        'return'       => 'objects',
        'status'       => $all_statuses,
        'type'         => 'shop_order',
    ] );

    $cases = [];
    $seen  = []; // dedupe

    foreach ( $orders as $order ) {
        if ( ! $order instanceof WC_Order ) continue;

        $order_id     = (int) $order->get_id();
        $order_number = (string) $order->get_order_number();
        $order_status = (string) $order->get_status();
        $parent_id    = (int) $order->get_parent_id();

       // Read order-level cases (may be partial)
$stored = ccsr3_get_order_cases_for_discovery( $order );
if ( ! is_array( $stored ) ) $stored = [];

/**
 * Build a fast index of already-present cases by a stable per-item key.
 * IMPORTANT: key by item_id first (truth), rma_id second.
 */
$present = []; // [ "item:<id>" => true, "rma:<rma>" => true ]

foreach ( $stored as $case ) {
    if ( ! is_array( $case ) ) continue;

    $cid = isset( $case['vendor_id'] ) ? (int) $case['vendor_id'] : 0;
    if ( $cid !== $vendor_id ) continue;

    $return_required = null;
    foreach ( [ 'return_required', 'return_required_flag', 'is_return_required', 'returnless_refund', 'returnless' ] as $rk ) {
        if ( array_key_exists( $rk, $case ) ) {
            $return_required = (int) $case[ $rk ];
            if ( in_array( $rk, [ 'returnless_refund', 'returnless' ], true ) ) {
                $return_required = $return_required ? 0 : 1;
            }
            break;
        }
    }
    if ( $return_required === null ) $return_required = 1;

    $decision_code         = strtoupper( trim( (string) ( $case['decision_code'] ?? '' ) ) );
    $low_value_refund_only = ! empty( $case['low_value_refund_only'] );
    $returnless_case       = (
        (int) $return_required === 0
        || $low_value_refund_only
        || ( in_array( $decision_code, [ 'REFUND_ONLY', 'REFUND_IMMEDIATE' ], true ) && (int) $return_required !== 1 )
    );

    if ( $returnless_case ) continue;

    $item_id = isset( $case['item_id'] ) ? (int) $case['item_id'] : 0;
    $rma     = isset( $case['rma_id'] ) ? (string) $case['rma_id'] : '';

    if ( $item_id > 0 ) $present[ 'item:' . $item_id ] = true;
    if ( $rma !== '' )  $present[ 'rma:' . strtolower( $rma ) ] = true;

    // Existing behavior: add stored case to list
    $key = $rma ? $rma : ( $order_id . ':' . $item_id . ':' . ( $case['created'] ?? '' ) );
    if ( isset( $seen[ $key ] ) ) continue;
    $seen[ $key ] = true;

    // Derive product thumb (your existing logic, unchanged)
    $product_id = 0;
    $thumb_url  = '';
    if ( $item_id > 0 ) {
        $oi = $order->get_item( $item_id );
        if ( $oi instanceof WC_Order_Item_Product ) {
            $product_id = (int) $oi->get_product_id();
        }
    }
    if ( $product_id > 0 ) {
        $thumb_id = get_post_thumbnail_id( $product_id );
        if ( $thumb_id ) {
            $thumb = wp_get_attachment_image_src( $thumb_id, 'thumbnail' );
            if ( is_array( $thumb ) && ! empty( $thumb[0] ) ) $thumb_url = (string) $thumb[0];
        }
    }

    $case['_order_id']     = $order_id;
    $case['_order_number'] = $order_number;
    $case['_order_status'] = $order_status;
    $case['_parent_id']    = $parent_id;
    $case['_product_id']   = $product_id;
    $case['_thumb']        = $thumb_url;
    $case['_is_inferred']  = 0;

    $cases[] = $case;
}

// ALWAYS synthesize from item metas too — but only add cases that aren't already present in stored
foreach ( $order->get_items() as $item_id => $item ) {
    $item_id = (int) $item_id;

    // Vendor resolution: prefer explicit meta, fallback to product author
    $vid = (int) wc_get_order_item_meta( $item_id, '_caricove_vendor_id', true );
    if ( $vid <= 0 && is_object( $item ) && method_exists( $item, 'get_product' ) ) {
        $p = $item->get_product();
        $pid = $p ? (int) $p->get_id() : 0;
        if ( $pid > 0 ) $vid = (int) get_post_field( 'post_author', $pid );
    }
    if ( $vid !== $vendor_id ) continue;

    // --- NEW truth layer: item-scoped case_type/status (return requests + lifecycle) ---
    $case_type   = strtolower( (string) wc_get_order_item_meta( $item_id, '_caricove_case_type', true ) );
    $case_status = strtolower( (string) wc_get_order_item_meta( $item_id, '_caricove_case_status', true ) );

    // --- Legacy fallback layer (older refund/return flows) ---
    $legacy_ret_status = strtolower( (string) wc_get_order_item_meta( $item_id, '_caricove_return_status', true ) );
   $ret_req = (int) wc_get_order_item_meta( $item_id, '_caricove_return_required', true );
$qty_ref = (float) wc_get_order_item_meta( $item_id, '_caricove_qty_refunded', true );

if ( $ret_req === 0 ) {
    continue;
}

$is_new_return = ( $case_type === 'return' && $case_status !== '' );
$is_legacy_return = ( $ret_req === 1 && $qty_ref > 0 );

    // If neither new nor legacy has any signal, skip
    if ( ! $is_new_return && ! $is_legacy_return && $legacy_ret_status === '' ) {
        continue;
    }

    // Stable RMA id guess (matches your CX UI + wizard convention)
    $rma_guess = (string) wc_get_order_item_meta( $item_id, '_caricove_rma_id', true );
    if ( $rma_guess === '' ) {
        $rma_guess = 'RCC-' . $order_id . '-' . $item_id;
    }

    // If stored already has this item (or rma), don't synthesize a duplicate
    if ( isset( $present[ 'item:' . $item_id ] ) ) continue;
    if ( isset( $present[ 'rma:' . strtolower( $rma_guess ) ] ) ) continue;

    // Dedupe list-level
    if ( isset( $seen[ $rma_guess ] ) ) continue;
    $seen[ $rma_guess ] = true;

    $product_id = 0;
    if ( $item instanceof WC_Order_Item_Product ) {
        $product_id = (int) $item->get_product_id();
    }

    $thumb_url = '';
    if ( $product_id > 0 ) {
        $thumb_id = get_post_thumbnail_id( $product_id );
        if ( $thumb_id ) {
            $thumb = wp_get_attachment_image_src( $thumb_id, 'thumbnail' );
            if ( is_array( $thumb ) && ! empty( $thumb[0] ) ) $thumb_url = (string) $thumb[0];
        }
    }

    // Quantity: prefer explicit requested qty (for new return requests), else refunded qty (legacy), else item qty
    $qty_requested = (float) wc_get_order_item_meta( $item_id, '_caricove_qty_return_requested', true );
    if ( $qty_requested <= 0 ) $qty_requested = (float) wc_get_order_item_meta( $item_id, '_caricove_qty_requested', true );
    if ( $qty_requested <= 0 ) $qty_requested = (float) wc_get_order_item_meta( $item_id, '_caricove_qty_return_request', true );

    $qty = 0;
    if ( $is_new_return ) {
        $qty = (int) ( $qty_requested > 0 ? $qty_requested : ( is_object($item) && method_exists($item,'get_quantity') ? (int)$item->get_quantity() : 0 ) );
    } else {
        $qty = (int) ( $qty_ref > 0 ? $qty_ref : ( is_object($item) && method_exists($item,'get_quantity') ? (int)$item->get_quantity() : 0 ) );
    }

    // Status mapping (keep your UI vocabulary)
    $status = 'awaiting_return';
    if ( $is_new_return ) {
        $status = $case_status;
        // normalize some common variants
        if ( $status === 'request' ) $status = 'requested';
        if ( $status === 'receive' ) $status = 'received';
    } elseif ( $legacy_ret_status !== '' ) {
        $status = $legacy_ret_status;
    }

    // Reason label
    $reason_label = (string) wc_get_order_item_meta( $item_id, '_caricove_reason_label', true );
    if ( $reason_label === '' ) {
        $reason_label = (string) wc_get_order_item_meta( $item_id, '_caricove_reason', true );
    }

    $cases[] = [
        'rma_id'          => $rma_guess,
        'order_id'        => $order_id,
        'order_number'    => $order_number,
        'item_id'         => $item_id,
        'product_name'    => $item->get_name(),
        'qty'             => $qty,
        'reason_label'    => $reason_label,
        'status'          => $status,
        'deadline'        => 0,
        'created'         => 0,
        'vendor_id'       => $vendor_id,
        'vendor_name'     => (string) wc_get_order_item_meta( $item_id, '_caricove_vendor_name', true ),
        'return_address'  => (string) wc_get_order_item_meta( $item_id, '_caricove_return_address', true ),

        '_order_id'       => $order_id,
        '_order_number'   => $order_number,
        '_order_status'   => $order_status,
        '_parent_id'      => $parent_id,
        '_product_id'     => $product_id,
        '_thumb'          => $thumb_url,
        '_is_inferred'    => 1,
    ];
}
}
        
    

    // Sort newest first (created if available)
    usort( $cases, function( $a, $b ) {
        $now = time();

        $sa = (string) ( $a['status'] ?? 'awaiting_return' );
        $sb = (string) ( $b['status'] ?? 'awaiting_return' );

        $da = isset( $a['deadline'] ) ? (int) $a['deadline'] : 0;
        $db = isset( $b['deadline'] ) ? (int) $b['deadline'] : 0;

        $closed = [ 'received', 'closed', 'resolved', 'completed', 'declined' ];
        $a_closed = in_array( $sa, $closed, true );
        $b_closed = in_array( $sb, $closed, true );

        // Priority buckets:
        // 0 = overdue & needs action
        // 1 = awaiting return / vendor action (not closed)
        // 2 = everything else
        $a_overdue = ( $da > 0 && ! $a_closed && $da < $now );
        $b_overdue = ( $db > 0 && ! $b_closed && $db < $now );

        $awaiting_states = [ 'awaiting_return', 'requested', 'under_review', 'return_in_progress', 'approved', 'approved_return_pickup' ];
        $a_await = ( ! $a_closed && in_array( $sa, $awaiting_states, true ) );
        $b_await = ( ! $b_closed && in_array( $sb, $awaiting_states, true ) );

        $pa = $a_overdue ? 0 : ( $a_await ? 1 : 2 );
        $pb = $b_overdue ? 0 : ( $b_await ? 1 : 2 );

        if ( $pa !== $pb ) return $pa <=> $pb;

        // Within bucket: newest first (updated, then created)
        $ta = isset( $a['updated'] ) ? (int) $a['updated'] : ( isset( $a['created'] ) ? (int) $a['created'] : 0 );
        $tb = isset( $b['updated'] ) ? (int) $b['updated'] : ( isset( $b['created'] ) ? (int) $b['created'] : 0 );
        return $tb <=> $ta;
    });

// KPI counts
    $now = time();
    $counts = [
        'needs_action' => 0,
        'awaiting'     => 0,
        'overdue'      => 0,
        'total'        => count( $cases ),
    ];
// === SORT: active first, newest first (server-side) ===
$active_states = ['requested','awaiting_return','under_review','return_in_progress','approved','approved_return_pickup'];
$closed_states = ['received','declined','closed','resolved','completed','cancelled','cancelled_partial'];

$norm = function($s){ return strtolower(trim((string)$s)); };

$case_ts = function($sc) use ($norm) {
    // Use rma suffix timestamp if present, else 0
    $rma = $norm($sc['rma_id'] ?? $sc['rma'] ?? '');
    if ($rma && preg_match('/(\d{10})$/', $rma, $m)) return (int)$m[1];
    return 0;
};

usort($cases, function($a, $b) use ($active_states, $closed_states, $norm, $case_ts) {
    $sa = $norm($a['status'] ?? ''); 
    $sb = $norm($b['status'] ?? '');

    $a_active = in_array($sa, $active_states, true);
    $b_active = in_array($sb, $active_states, true);

    $a_closed = in_array($sa, $closed_states, true);
    $b_closed = in_array($sb, $closed_states, true);

    // Bucket order:
    // 0 = active, 1 = other, 2 = closed
    $pa = $a_active ? 0 : ($a_closed ? 2 : 1);
    $pb = $b_active ? 0 : ($b_closed ? 2 : 1);
    if ($pa !== $pb) return $pa <=> $pb;

    // Within bucket: newest first by timestamp
    $ta = $case_ts($a);
    $tb = $case_ts($b);
    return $tb <=> $ta;
});
    foreach ( $cases as $c ) {
        $status   = (string) ( $c['status'] ?? 'awaiting_return' );
                    // --- created_ts: authoritative per-case timestamp for 12h escalation ---
                    // Priority: case created/updated/requested_at/ts -> order_item meta -> RMA suffix -> order created -> 0
                    $created_ts = 0;

                    foreach ( ['created_at','created','requested_at','ts','updated_at','updated'] as $k ) {
                        if ( isset($c[$k]) && is_numeric($c[$k]) ) { $created_ts = (int)$c[$k]; break; }
                        if ( isset($c[$k]) && is_string($c[$k]) && $c[$k] !== '' ) {
                            $tmp = strtotime($c[$k]);
                            if ($tmp) { $created_ts = (int)$tmp; break; }
                        }
                    }

                    // Order item meta fallback (if available)
                    $order_item_id = (int)($c['order_item_id'] ?? $c['item_id'] ?? 0);
                    if ( $created_ts <= 0 && $order_item_id > 0 ) {
                        $meta_ts = get_metadata('order_item', $order_item_id, '_cc_return_requested_at', true);
                        if ( is_numeric($meta_ts) ) { $created_ts = (int)$meta_ts; }
                    }

                    // RMA suffix fallback (10-digit unix)
                    $rma_for_ts = (string)($c['rma_id'] ?? '');
                    if ( $created_ts <= 0 && $rma_for_ts && preg_match('/-(\d{10})$/', $rma_for_ts, $mm) ) {
                        $created_ts = (int)$mm[1];
                    }

                    // Order created fallback
                    $oid_for_ts = (int)($c['order_id'] ?? 0);
                    if ( $created_ts <= 0 && $oid_for_ts > 0 && function_exists('wc_get_order') ) {
                        $o = wc_get_order($oid_for_ts);
                        if ( $o && method_exists($o,'get_date_created') && $o->get_date_created() ) {
                            $created_ts = (int)$o->get_date_created()->getTimestamp();
                        }
                    }

                    // Final: 0 (means "do not escalate")
                    $now_ts = time();
                    if ( $created_ts > $now_ts ) $created_ts = 0;
                    if ( $created_ts > 0 && $created_ts < ($now_ts - 730*24*60*60) ) $created_ts = 0;

        $deadline = isset( $c['deadline'] ) ? (int) $c['deadline'] : 0;

        $is_closed = in_array( $status, [ 'received', 'closed', 'resolved', 'completed' ], true );

        if ( $deadline > 0 && ! $is_closed ) {
            if ( $deadline < $now ) {
                $counts['overdue']++;
                $counts['needs_action']++;
            } elseif ( ( $deadline - $now ) <= ( 3 * DAY_IN_SECONDS ) ) {
                $counts['needs_action']++;
            } else {
                $counts['awaiting']++;
            }
        } else {
            if ( ! $is_closed ) $counts['awaiting']++;
        }
    }

    $nonce = wp_create_nonce( 'ccsr3_nonce' );

    /* ============================================================
     * PATCHES BAKED IN: liability + refund timing helpers
     * ============================================================ */
    $ccsr3_get_reason_code = function( $case ) {
        $rc = '';
        foreach ( [ 'reason_code', 'reasonCode', 'code', 'rma_reason_code', '_reason_code' ] as $k ) {
            if ( isset( $case[ $k ] ) && is_string( $case[ $k ] ) && $case[ $k ] !== '' ) {
                $rc = $case[ $k ];
                break;
            }
        }
        $rc = strtoupper( trim( (string) $rc ) );
        return $rc;
    };

$ccsr3_shipping_liability_label = function( $case ) {
        // Refresh from canonical case first so seller returns reads the latest synced verdict.
        if ( class_exists( '\Caricove\Bank\BankRefundCases' ) ) {
            $case_id = (string) ( $case['case_id'] ?? $case['rma_id'] ?? '' );
            if ( $case_id !== '' ) {
                $live = \Caricove\Bank\BankRefundCases::get_case( $case_id );
                if ( is_array( $live ) && ! empty( $live ) ) {
                    $case = array_merge( $case, $live );
                }
            }
        }

        $rc_raw = strtolower( trim( (string) ( $case['reason_code'] ?? $case['reasonCode'] ?? $case['code'] ?? $case['rma_reason_code'] ?? $case['_reason_code'] ?? '' ) ) );
        $lbl    = strtolower( trim( (string) ( $case['reason_label'] ?? '' ) ) );

        // Prefer explicit shipping liability first, then resolved fault.
        $resolved = '';
        foreach ( [ 'shipping_liability_party', 'resolved_fault_party' ] as $k ) {
            if ( isset( $case[ $k ] ) && $case[ $k ] !== '' && $case[ $k ] !== null ) {
                $resolved = strtolower( trim( (string) $case[ $k ] ) );
                break;
            }
        }

        $status = strtolower( trim( (string) ( $case['fault_resolution_status'] ?? '' ) ) );

        // Normalize aliases.
        if ( in_array( $resolved, [ 'vendor', 'merchant' ], true ) ) {
            $resolved = 'seller';
        } elseif ( in_array( $resolved, [ 'courier', 'shipping', 'logistics' ], true ) ) {
            $resolved = 'carrier';
        } elseif ( in_array( $resolved, [ 'buyer', 'user', 'cx' ], true ) ) {
            $resolved = 'customer';
        }

        // Explicit ticket/admin verdict wins.
        if ( $resolved !== '' || in_array( $status, [ 'resolved', 'complete', 'completed' ], true ) ) {
            if ( $resolved === 'seller' ) {
                return 'Return shipping handled by Vendor';
            }
            if ( $resolved === 'carrier' ) {
                return 'Return shipping handled by Courier';
            }
            if ( $resolved === 'customer' ) {
                return 'Return shipping handled by Customer';
            }
            return 'Return shipping pending fault review';
        }

        // Always-CX reasons.
        if (
            in_array( $rc_raw, [ 'ordered_by_mistake', 'found_better_price', 'no_longer_needed' ], true ) ||
            preg_match( '/mistake|better price|no longer needed|no longer|changed my mind|regret/', $lbl )
        ) {
            return 'Return shipping handled by Customer';
        }

        // Never arrived is not a physical return path.
        if ( $rc_raw === 'never_arrived' || preg_match( '/never arrived|didn.?t arrive|not arrived/', $lbl ) ) {
            return 'No return shipping — no physical return';
        }

        // For all other return-required / reviewed flows, wait for the ticket verdict.
        return 'Return shipping pending fault review';
    };
    
    
    $ccsr3_refund_timing_label = function( $case ) {
        $status = isset( $case['status'] ) ? (string) $case['status'] : 'awaiting_return';

        if ( in_array( $status, [ 'received', 'closed', 'resolved', 'completed' ], true ) ) {
            return 'Refund: after receipt (ready)';
        }
        return 'Refund: releases after item received';
    };

    ob_start();
    ?>
    <div class="ccsr3" data-ccsr3-nonce="<?php echo esc_attr( $nonce ); ?>">
        <div class="ccsr3-hero">
            <div class="ccsr3-hero-left">
                <div class="ccsr3-title">Returns &amp; RMAs</div>
                <div class="ccsr3-sub"></div>
            </div>

            <div class="ccsr3-kpis" role="group" aria-label="Returns KPIs">
                <div class="ccsr3-kpi">
                    <div class="ccsr3-kpi-k">Needs action</div>
                    <div class="ccsr3-kpi-v"><?php echo (int) $counts['needs_action']; ?></div>
                </div>
                <div class="ccsr3-kpi">
                    <div class="ccsr3-kpi-k">Awaiting</div>
                    <div class="ccsr3-kpi-v"><?php echo (int) $counts['awaiting']; ?></div>
                </div>
                <div class="ccsr3-kpi ccsr3-kpi-warn">
                    <div class="ccsr3-kpi-k">Overdue</div>
                    <div class="ccsr3-kpi-v"><?php echo (int) $counts['overdue']; ?></div>
                </div>
            </div>
        </div>

        <div class="ccsr3-controls">
            <div class="ccsr3-search">
                <span class="ccsr3-search-ico" aria-hidden="true">⌕</span>
                <input type="text" class="ccsr3-search-in" placeholder="Search RMA, product, order #, reason…" autocomplete="off">
            </div>

            <div class="ccsr3-filters">
                <select class="ccsr3-select" data-filter="status">
                    <option value="">All statuses</option>
                    <option value="awaiting_return">Awaiting return</option>
                    <option value="received">Received</option>
                    <option value="escalated">Escalated</option>
                </select>

                <select class="ccsr3-select" data-filter="deadline">
                    <option value="">Any deadline</option>
                    <option value="overdue">Overdue</option>
                    <option value="soon">Due soon (≤ 3 days)</option>
                    <option value="future">Future</option>
                    <option value="none">No deadline</option>
                </select>

                <div class="ccsr3-pill">
                    <span class="ccsr3-pill-num"><?php echo (int) $counts['total']; ?></span>
                    <span class="ccsr3-pill-lbl">cases</span>
                </div>
            </div>
        </div>

        <?php if ( empty( $cases ) ) : ?>
            <div class="ccsr3-empty">
                <div class="ccsr3-empty-title">No return cases found</div>
                <div class="ccsr3-empty-sub">If you just filed a return, refresh in a few seconds. This console reads order meta + item metas.</div>
            </div>
        <?php else : ?>
            <div class="ccsr3-list" role="list">
                <?php foreach ( $cases as $c ) :
                    $rma      = (string) ( $c['rma_id'] ?? '' );
                    $product  = (string) ( $c['product_name'] ?? '' );
                    $qty      = isset( $c['qty'] ) ? (int) $c['qty'] : 0;
                    $reason   = (string) ( $c['reason_label'] ?? '' );
                    $status   = (string) ( $c['status'] ?? 'awaiting_return' );
                    $deadline = isset( $c['deadline'] ) ? (int) $c['deadline'] : 0;

                    $order_id     = isset( $c['_order_id'] ) ? (int) $c['_order_id'] : 0;
                    $order_number = (string) ( $c['_order_number'] ?? '' );
                    $order_status = (string) ( $c['_order_status'] ?? '' );
                    $parent_id    = isset( $c['_parent_id'] ) ? (int) $c['_parent_id'] : 0;

                    $thumb = (string) ( $c['_thumb'] ?? '' );

                    $is_inferred = ! empty( $c['_is_inferred'] );
                    $is_closed   = in_array( $status, [ 'received', 'closed', 'resolved', 'completed' ], true );

                    // 🔒 Admin finality lock (Refunded/Declined = irreversible)
                    $is_admin_final   = ccsr3_case_admin_is_final( $c );
                    $admin_final_lbl  = $is_admin_final ? ccsr3_case_admin_final_label( $c ) : '';
                    $lock_title       = $is_admin_final
                        ? ( 'Admin decision is final (' . ( $admin_final_lbl ?: 'Final' ) . '). Seller cannot override.' )
                        : '';

                    $deadline_text = $deadline ? date_i18n( get_option( 'date_format' ), $deadline ) : '';
                    $due_bucket = 'none';
                    $due_text   = '';
                    if ( $deadline > 0 ) {
                        $diff = $deadline - $now;
                        if ( $diff < 0 ) {
                            $due_bucket = 'overdue';
                            $due_text   = 'Overdue';
                        } elseif ( $diff <= ( 3 * DAY_IN_SECONDS ) ) {
                            $due_bucket = 'soon';
                            $days_left  = max( 0, (int) ceil( $diff / DAY_IN_SECONDS ) );
                            $due_text   = 'Due in ' . $days_left . ' day' . ( $days_left === 1 ? '' : 's' );
                        } else {
                            $due_bucket = 'future';
                            $days_left  = (int) ceil( $diff / DAY_IN_SECONDS );
                            $due_text   = 'Due in ' . $days_left . ' days';
                        }
                    }

                    $refund_amt  = isset( $c['refund_amount'] ) ? (float) $c['refund_amount'] : 0.0;
                    $refund_cur  = (string) ( $c['refund_currency'] ?? ( function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : '' ) );
                    $refund_text = '';

                    if ( $refund_amt > 0 ) {
                        if ( function_exists( 'wc_price' ) ) {
                            $refund_text = wp_strip_all_tags( wc_price( $refund_amt, [ 'currency' => $refund_cur ] ) );
                        } else {
                            $refund_text = number_format( $refund_amt, 2 );
                        }
                    }

                    $status_label = ucwords( str_replace( '_', ' ', $status ) );
                    $status_class = 'awaiting';
                    if ( $is_closed ) $status_class = 'ok';
                    if ( 'escalated' === $status ) $status_class = 'warn';
                    if ( 'overdue' === $due_bucket && ! $is_closed ) $status_class = 'danger';

                    $return_address = (string) ( $c['return_address'] ?? '' );
                    $item_id        = isset( $c['item_id'] ) ? (int) $c['item_id'] : 0;

                    // BAKED IN: render the two new info lines
                    $ship_line   = $ccsr3_shipping_liability_label( $c );
                    $refund_line = $ccsr3_refund_timing_label( $c );

                    $row_key = esc_attr( $rma ?: ( $order_id . '-' . $item_id ) );

// Awaiting-return priority (UI only): glow until vendor marks RECEIVED.
$ccsr3_closed_statuses = [ 'received', 'closed', 'resolved', 'completed', 'declined', 'refunded' ];
$ccsr3_is_closed = in_array( (string)$status, $ccsr3_closed_statuses, true );
$ccsr3_awaiting_states = [ 'awaiting_return', 'requested', 'under_review', 'return_in_progress', 'approved', 'approved_return_pickup' ];
$ccsr3_is_awaiting = ( ! $ccsr3_is_closed && in_array( (string)$status, $ccsr3_awaiting_states, true ) );
?>





                    <div class="ccsr3-case<?php echo $ccsr3_is_awaiting ? ' ccsr3-awaiting' : ''; ?>"
                         role="listitem"
                         data-key="<?php echo $row_key; ?>"
                         data-rma="<?php echo esc_attr( strtolower( $rma ) ); ?>"
                         data-product="<?php echo esc_attr( strtolower( $product ) ); ?>"
                         data-reason="<?php echo esc_attr( strtolower( $reason ) ); ?>"
                         data-order="<?php echo esc_attr( strtolower( $order_number ?: (string) $order_id ) ); ?>"
                         data-status="<?php echo esc_attr( $status ); ?>"
                         data-deadlinebucket="<?php echo esc_attr( $due_bucket ); ?>"
                      data-created-ts="<?php
  $ts = 0;
  if (!empty($rma) && preg_match('/-(\d{10})$/', $rma, $m)) {
    $ts = (int)$m[1];
  }
  echo esc_attr($ts);
?>"                  >
                        <div class="ccsr3-card">
                            <div class="ccsr3-left">
                                <div class="ccsr3-thumb">
                                    <?php if ( $thumb ) : ?>
                                        <img src="<?php echo esc_url( $thumb ); ?>" alt="">
                                    <?php else : ?>
                                        <div class="ccsr3-thumb-ph" aria-hidden="true"></div>
                                    <?php endif; ?>
                                </div>

                                <div class="ccsr3-main">
                                   <?php
  $tp = ccsr3_title_and_pills_from_order_item(
    (int)$order_id,
    (int)$item_id,
    (string)($product ?: '—')
  );
?>
<div class="ccsr3-product"><?php echo esc_html( $tp['title'] ?: '—' ); ?></div>
<?php if ( ! empty($tp['pills_html']) ) echo wp_kses_post($tp['pills_html']); ?>
                                    <div class="ccsr3-meta">
                                        <span class="ccsr3-meta-item">Order <strong>#<?php echo esc_html( $order_number ?: (string) $order_id ); ?></strong></span>
                                        <?php if ( $order_status ) : ?>
                                            <span class="ccsr3-dot" aria-hidden="true"></span>
                                            <span class="ccsr3-meta-item"><?php echo esc_html( $order_status ); ?></span>
                                        <?php endif; ?>
                                        <?php if ( $parent_id ) : ?>
                                            <span class="ccsr3-dot" aria-hidden="true"></span>
                                            <span class="ccsr3-meta-item">parent #<?php echo esc_html( (string) $parent_id ); ?></span>
                                        <?php endif; ?>
                                        <?php if ( $is_inferred ) : ?>
                                            <span class="ccsr3-dot" aria-hidden="true">•</span>
                                            <span class="ccsr3-meta-item ccsr3-infer">inferred</span>
                                        <?php endif; ?>
                                    </div>

                              <div class="ccsr3-tags">
    <?php if ( $reason ) : ?>
        <span class="ccsr3-tag ccsr3-tag-soft"><?php echo esc_html( $reason ); ?></span>
    <?php endif; ?>

    <span class="ccsr3-tag ccsr3-tag-qty">Qty <?php echo (int) $qty; ?></span>

    <?php
        // Always compute amounts once (so status pill can always show money)
        $order_obj = ( $order_id ? wc_get_order( $order_id ) : null );
        list( $r_amt, $q_amt, $cur ) = ccsr3_case_amounts( $order_obj, $c );

        $pill_text = $status_label;
        if ( $status === 'refunded' ) {
            $t = ccsr3_money_text( $r_amt, $cur );
            $pill_text = $t ? ( 'Refunded • ' . $t ) : $status_label;
        } elseif ( $status === 'declined' ) {
            $t = ccsr3_money_text( $q_amt, $cur );
            $pill_text = $t ? ( 'Declined • ' . $t ) : $status_label;
        }
    ?>

    <!-- STATUS PILL: always render (this is what was missing when a deadline existed) -->
    <span class="ccsr3-tag ccsr3-tag-status ccsr3-tag-<?php echo esc_attr( $status_class ); ?>">
        <?php echo esc_html( $pill_text ); ?>
    </span>

    <!-- DEADLINE PILL: render if exists, otherwise show "No deadline" -->
    <?php if ( $deadline_text ) : ?>
        <span class="ccsr3-tag ccsr3-tag-date">
            <?php echo esc_html( $deadline_text ); ?>
            <?php if ( $due_text ) : ?>
                <span class="ccsr3-tag-sub"><?php echo esc_html( $due_text ); ?></span>
            <?php endif; ?>
        </span>
    <?php else : ?>
        <span class="ccsr3-tag ccsr3-tag-date">No deadline</span>
    <?php endif; ?>
</div>
                                </div>
                            </div>

                            <div class="ccsr3-micro">
                                <div class="ccsr3-micro-line"><?php echo esc_html( $ship_line ); ?></div>
                                <div class="ccsr3-micro-line"><?php echo esc_html( $refund_line ); ?></div>
                            </div>

                            <div class="ccsr3-right">
                                <div class="ccsr3-rma">
                                    <div class="ccsr3-rma-v"><?php echo esc_html( $rma ?: '—' ); ?></div>
                                </div>

                                <div class="ccsr3-actions">
                                    <button type="button" class="ccsr3-btn ccsr3-btn-ghost" data-act="toggle">Details</button>
                                    <button type="button" class="ccsr3-btn ccsr3-btn-primary" data-act="copy" data-copy="<?php echo esc_attr( $rma ); ?>">Copy RMA</button>
                                </div>
                            </div>
                        </div>

                        <div class="ccsr3-drawer" hidden>
                            <div class="ccsr3-drawer-grid">
                                <div class="ccsr3-drawer-box">
                                    <div class="ccsr3-dk">Return address</div>
                                    <div class="ccsr3-dv"><?php echo esc_html( $return_address ?: '—' ); ?></div>
                                </div>

                                <div class="ccsr3-drawer-box">
                                    <div class="ccsr3-dk">Order</div>
                                    <div class="ccsr3-dv">#<?php echo esc_html( $order_number ?: (string) $order_id ); ?></div>
                                </div>

                                <div class="ccsr3-drawer-box">
                                    <div class="ccsr3-dk">Case</div>
                                    <div class="ccsr3-dv">
                                        <?php echo esc_html( $status_label ); ?>
                                        <?php if ( $deadline_text ) : ?>
                                            <span class="ccsr3-muted"> • <?php echo esc_html( $deadline_text ); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="ccsr3-drawer-box">
                                    <div class="ccsr3-dk">Liability</div>
                                    <div class="ccsr3-dv">
                                        <span class="ccsr3-micro-strong"><?php echo esc_html( $ship_line ); ?></span><br>
                                        <span class="ccsr3-muted"><?php echo esc_html( $refund_line ); ?></span>
                                    </div>
                                </div>

                                <div class="ccsr3-drawer-box ccsr3-drawer-box-wide">
                                    <div class="ccsr3-dk">Actions</div>
                                    <div class="ccsr3-drawer-actions">
                                        <?php if ( $is_admin_final ) : ?>
                                            <button type="button" class="ccsr3-btn ccsr3-btn-disabled" disabled title="<?php echo esc_attr( $lock_title ); ?>">Mark received</button>
                                            <button type="button" class="ccsr3-btn ccsr3-btn-disabled" disabled title="<?php echo esc_attr( $lock_title ); ?>">Escalate</button>
                                        <?php else : ?>
                                            <!-- Inferred is now actionable: backend will materialize safely -->
                                            <div class="ccsr3-recv-inline" role="group" aria-label="Mark received quantity">
                                                <span class="ccsr3-muted" style="opacity:.85;font-weight:800">Received qty</span>
                                                <input type="number"
                                                       class="ccsr3-rq-in"
                                                       min="0"
                                                       max="<?php echo esc_attr( (string)$qty ); ?>"
                                                       step="1"
                                                       value="<?php
$saved = wc_get_order_item_meta( $item_id, '_caricove_qty_received', true );
echo esc_attr( ( $saved !== '' && $saved !== null ) ? (string)$saved : (string)$qty );
?>"
                                                       inputmode="numeric"
                                                       aria-label="received quantity"
                                                />
                                                <button type="button" class="ccsr3-btn ccsr3-btn-good"
                                                        data-act="received"
                                                        data-order="<?php echo esc_attr( $order_id ); ?>"
                                                        data-rma="<?php echo esc_attr( $rma ); ?>"
                                                        data-item="<?php echo esc_attr( (string)$item_id ); ?>"
                                                        data-max="<?php echo esc_attr( (string)$qty ); ?>">
                                                    Confirm received
                                                </button>
                                            </div>
                                            <button type="button" class="ccsr3-btn ccsr3-btn-warn"
                                                    data-act="escalate"
                                                    data-order="<?php echo esc_attr( $order_id ); ?>"
                                                    data-rma="<?php echo esc_attr( $rma ); ?>">
                                                Escalate
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="ccsr3-drawer-foot"></div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <div class="ccsr3-toast" aria-live="polite" aria-atomic="true" hidden></div>
    </div>
    <?php

    return ob_get_clean();
} );

/* ============================================================
 *
 * AJAX: update case status inside _caricove_return_cases
 *
 * received => received
 * escalate => escalated
 *
 * HARD RULE: if admin finalized (Refunded/Declined), seller cannot change.
 *
 * PATCH: if order-level case missing (inferred), materialize from item metas then update.
 *
 * ============================================================ */
add_action( 'wp_ajax_ccsr3_update_case', function () {

    if ( ! is_user_logged_in() ) {
        wp_send_json_error( [ 'message' => 'Not logged in.' ], 403 );
    }

    if ( ! class_exists( 'WooCommerce' ) || ! function_exists( 'wc_get_order' ) ) {
        wp_send_json_error( [ 'message' => 'WooCommerce missing.' ], 400 );
    }

    $nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
    if ( ! wp_verify_nonce( $nonce, 'ccsr3_nonce' ) ) {
        wp_send_json_error( [ 'message' => 'Bad nonce.' ], 403 );
    }

    $order_id = isset( $_POST['order_id'] ) ? absint( $_POST['order_id'] ) : 0;
    $rma_id   = isset( $_POST['rma_id'] ) ? sanitize_text_field( wp_unslash( $_POST['rma_id'] ) ) : '';
    $action   = isset( $_POST['case_action'] ) ? sanitize_text_field( wp_unslash( $_POST['case_action'] ) ) : '';

        $qty_received = isset( $_POST['qty_received'] ) ? absint( $_POST['qty_received'] ) : 0;

if ( ! $order_id || ! $rma_id || ! in_array( $action, [ 'received', 'escalate' ], true ) ) {
        wp_send_json_error( [ 'message' => 'Missing parameters.' ], 400 );
    }

    
// Resolve item_id (preferred) or derive from rma_id (RCC-<order>-<item>)
$item_id = isset( $_POST['item_id'] ) ? absint( $_POST['item_id'] ) : 0;
if ( ! $item_id && $rma_id && preg_match( '/(\d+)\s*$/', $rma_id, $m ) ) {
    $item_id = absint( $m[1] );
}
// Stable base RMA for this item
$base_rma = ( $order_id && $item_id ) ? ( 'RCC-' . $order_id . '-' . $item_id ) : $rma_id;

$order = wc_get_order( $order_id );
    if ( ! $order instanceof WC_Order ) {
        wp_send_json_error( [ 'message' => 'Order not found.' ], 404 );
    }

    $vendor_id = (int) get_current_user_id();

    if ( class_exists( '\Caricove\Bank\BankRefundCases' ) ) {
        $canonical_case = \Caricove\Bank\BankRefundCases::resolve_case( $order_id, (int) $item_id, (string) $rma_id );
        if ( ! $canonical_case && ! empty( $base_rma ) && $base_rma !== $rma_id ) {
            $canonical_case = \Caricove\Bank\BankRefundCases::resolve_case( $order_id, (int) $item_id, (string) $base_rma );
        }

        if ( is_array( $canonical_case ) && ! empty( $canonical_case['case_id'] ) ) {
            $case_vendor_id = isset( $canonical_case['vendor_id'] ) ? (int) $canonical_case['vendor_id'] : 0;
            if ( $case_vendor_id > 0 && $case_vendor_id !== $vendor_id ) {
                wp_send_json_error( [ 'message' => 'Case not found for this vendor.' ], 404 );
            }

            if (
                in_array( (string) ( $canonical_case['status'] ?? '' ), [ 'declined', 'closed' ], true )
                || ( (string) ( $canonical_case['status'] ?? '' ) === 'refunded' && ! ccsr3_case_is_shipping_only_pre_return( $canonical_case ) )
            ) {
                $lbl = ccsr3_case_admin_final_label( [ 'status' => (string) ( $canonical_case['status'] ?? '' ) ] );
                $blocked_reason = $lbl ? ( 'Admin decision is final (' . $lbl . '). Seller cannot change this case.' )
                                       : 'Admin decision is final. Seller cannot change this case.';
                wp_send_json_error( [ 'message' => $blocked_reason ], 409 );
            }

            if ( 'received' === $action ) {
                $updated_case = \Caricove\Bank\BankRefundCases::set_received_qty(
                    (string) $canonical_case['case_id'],
                    (int) $qty_received,
                    [ 'status' => 'received' ]
                );
            } else {
                $updated_case = \Caricove\Bank\BankRefundCases::set_status(
                    (string) $canonical_case['case_id'],
                    'escalated',
                    [ 'seller_note' => 'Seller escalated this case from the seller returns console.' ]
                );
            }

            if ( $updated_case ) {
                $order->add_order_note( sprintf(
                    'Seller Returns Console: case %s marked %s by vendor #%d',
                    (string) ( $canonical_case['case_id'] ?? $rma_id ),
                    ( 'received' === $action ? 'RECEIVED' : 'ESCALATED' ),
                    $vendor_id
                ) );

                wp_send_json_success( [ 'message' => 'Updated.' ] );
            }
        }
    }

    $cases = ccsr3_get_order_cases_for_discovery( $order );
    if ( ! is_array( $cases ) ) $cases = [];

    // If no order-level cases exist, materialize ALL vendor cases for this order (prevents "one case turns off fallback")
if ( empty( $cases ) ) {
    $all = ccsr3_materialize_all_vendor_cases_from_item_metas( $order, $vendor_id );

    if ( empty( $all ) ) {
        wp_send_json_error( [ 'message' => 'Cannot materialize inferred case(s) for this vendor.' ], 409 );
    }

    $cases = $all;
// Normalize materialized cases to stable base rma_id (RCC-<order>-<item>)
foreach ( $cases as &$cc ) {
    if ( ! is_array( $cc ) ) continue;
    $iid = isset( $cc['item_id'] ) ? (int) $cc['item_id'] : 0;
    if ( $iid > 0 ) {
        $cc['rma_id'] = 'RCC-' . $order_id . '-' . $iid;
    }
}
unset( $cc );

    update_post_meta( $order_id, CC_RETURNS_META_CASES, $cases );
}

    $updated = false;
    $blocked = false;
    $blocked_reason = '';

    // First try: update existing matching case
    foreach ( $cases as &$c ) {
        if ( ! is_array( $c ) ) continue;

        $cid = isset( $c['vendor_id'] ) ? (int) $c['vendor_id'] : 0;
        if ( $cid !== $vendor_id ) continue;

        $rid = isset( $c['rma_id'] ) ? (string) $c['rma_id'] : '';
$cid_item = isset( $c['item_id'] ) ? (int) $c['item_id'] : 0;

// Match by stable primary key: (order_id, item_id)
// Accept any rma_id that begins with base_rma (covers older timestamped variants).
if ( $item_id > 0 ) {
    if ( $cid_item !== $item_id && strpos( $rid, $base_rma ) !== 0 ) continue;
} else {
    // Fallback: if no item_id resolved, require exact rma match
    if ( $rid !== $rma_id ) continue;
}


        // 🔒 Admin finality guard (Refunded/Declined cannot be overridden)
        if ( ccsr3_case_admin_is_final( $c ) ) {
            $blocked = true;
            $lbl = ccsr3_case_admin_final_label( $c );
            $blocked_reason = $lbl ? ( 'Admin decision is final (' . $lbl . '). Seller cannot change this case.' )
                                   : 'Admin decision is final. Seller cannot change this case.';
            break;
        }

        if ( 'received' === $action ) {
            $c['status'] = 'received';
            $c['qty_received'] = min( (int)$qty_received, (int)($c['qty'] ?? $qty_received) );
        } else {
            $c['status'] = 'escalated';
        }
        // Normalize to stable base RMA for this item (prevents duplicate cards)
        if ( $base_rma ) $c['rma_id'] = $base_rma;
        if ( $item_id > 0 ) $c['item_id'] = $item_id;

        $c['updated'] = time();
        $updated = true;
        break;
    }
    unset( $c );

    // Second try (PATCH): if not found, attempt to materialize + append then update
    if ( ! $blocked && ! $updated ) {
        $new_case = ccsr3_try_materialize_case_from_item_metas( $order, $vendor_id, $base_rma );
        if ( $new_case && ! empty( $new_case['item_id'] ) ) {
            $new_case['status']  = ( 'received' === $action ) ? 'received' : 'escalated';
            if ( 'received' === $action ) { $new_case['qty_received'] = min( (int)$qty_received, (int)($new_case['qty'] ?? $qty_received) ); }
            $new_case['updated'] = time();
            // Normalize to stable base RMA for this item
            if ( $base_rma ) $new_case['rma_id'] = $base_rma;
            if ( $item_id > 0 ) $new_case['item_id'] = $item_id;


            // Dedupe by rma_id
            $has = false;
            foreach ( $cases as $cc ) {
                if ( is_array( $cc ) && (string)($cc['rma_id'] ?? '') === (string)$new_case['rma_id'] ) { $has = true; break; }
            }
            if ( ! $has ) {
                $cases[] = $new_case;
            } else {
                // If it exists but didn't match due to casing/format, still persist updated payload
                foreach ( $cases as &$cc ) {
                    if ( ! is_array( $cc ) ) continue;
                    if ( (string)($cc['rma_id'] ?? '') !== (string)$new_case['rma_id'] ) continue;
                    if ( ccsr3_case_admin_is_final( $cc ) ) {
                        $blocked = true;
                        $lbl = ccsr3_case_admin_final_label( $cc );
                        $blocked_reason = $lbl ? ( 'Admin decision is final (' . $lbl . '). Seller cannot change this case.' )
                                               : 'Admin decision is final. Seller cannot change this case.';
                        break;
                    }
                    $cc['status']  = $new_case['status'];
                    $cc['updated'] = $new_case['updated'];
                    $updated = true;
                    break;
                }
                unset( $cc );
            }

            if ( ! $blocked && ! $updated ) {
                $updated = true;
            }
        }
    }

    if ( $blocked ) {
        wp_send_json_error( [ 'message' => $blocked_reason ], 409 );
    }

    if ( ! $updated ) {
        wp_send_json_error( [ 'message' => 'Case not found for this vendor.' ], 404 );
    }

    // Dedupe: keep only one case per item_id (prefer most-recent status update)
$uniq = [];
foreach ( $cases as $cc ) {
    if ( ! is_array( $cc ) ) continue;
    $iid = isset( $cc['item_id'] ) ? (int) $cc['item_id'] : 0;
    if ( $iid <= 0 ) continue;
    // overwrite to keep last one encountered
    $uniq[ $iid ] = $cc;
}
if ( $uniq ) {
    $cases = array_values( $uniq );
}

update_post_meta( $order_id, CC_RETURNS_META_CASES, $cases );

// Keep item-level truth in sync so inferred cards collapse into a single card
if ( $item_id > 0 ) {
    $new_status = ( 'received' === $action ) ? 'received' : 'escalated';
    wc_update_order_item_meta( $item_id, '_caricove_case_status', $new_status );
   wc_update_order_item_meta( $item_id, '_caricove_qty_received', (int)$qty_received );
    if ( $base_rma ) wc_update_order_item_meta( $item_id, '_caricove_rma_id', $base_rma );
    // Legacy mirror (best-effort)
    wc_update_order_item_meta( $item_id, '_caricove_return_status', $new_status );
}

    // Note (lightweight)
    $order->add_order_note( sprintf(
        'Seller Returns Console: case %s marked %s by vendor #%d',
        $rma_id,
        ( 'received' === $action ? 'RECEIVED' : 'ESCALATED' ),
        $vendor_id
    ) );

    wp_send_json_success( [ 'message' => 'Updated.' ] );
} );

/* ============================================================
 *
 * ASSETS (inline, scoped)
 *
 * ============================================================ */
add_action( 'wp_enqueue_scripts', function () {

    // Only load if shortcode exists on current page
    $page_id  = get_queried_object_id();
    $content  = $page_id ? (string) get_post_field( 'post_content', $page_id ) : '';
    if ( ! $page_id || ! has_shortcode( $content, 'caricove_seller_returns_console' ) ) return;

    wp_register_style( 'ccsr3-style', false, [], '3.0.0' );
    wp_enqueue_style( 'ccsr3-style' );

    wp_register_script( 'ccsr3-script', '', [], '3.0.0', true );
    wp_enqueue_script( 'ccsr3-script' );

    wp_add_inline_style( 'ccsr3-style', <<<CSS
.ccsr3{ color:#fff; font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif; line-height:1.25; }
.ccsr3 *{ box-sizing:border-box; }

/* Anti theme-bleed reset (scoped) */
.ccsr3 button,
.ccsr3 input,
.ccsr3 select,
.ccsr3 a{
font-family: inherit !important;
letter-spacing: inherit !important;
}
.ccsr3 button,
.ccsr3 [type="button"],
.ccsr3 [type="submit"]{
-webkit-appearance:none !important;
appearance:none !important;
background-image:none !important;
text-transform:none !important;
box-shadow:none;
outline:none;
}
.ccsr3 button:focus,
.ccsr3 button:focus-visible,
.ccsr3 a:focus,
.ccsr3 a:focus-visible,
.ccsr3 input:focus,
.ccsr3 input:focus-visible,
.ccsr3 select:focus,
.ccsr3 select:focus-visible{
outline:none !important;
}
.ccsr3 a{ color:inherit; text-decoration:none; }
.ccsr3 ::selection{ background: rgba(110,190,255,.28); }
.ccsr3 button::before,
.ccsr3 button::after{ content:none !important; }

/* Hero */
.ccsr3-hero{
display:flex; justify-content:space-between; gap:14px; flex-wrap:wrap;
padding:18px 18px 16px; border-radius:22px;
background:linear-gradient(135deg,#050b18,#0b3b85);
box-shadow:0 18px 44px rgba(0,0,0,.85);
border:1px solid rgba(110,170,255,.26);
position:relative; overflow:hidden; margin-bottom:14px;
}
.ccsr3-hero::after{
content:""; position:absolute; inset:-70%;
background:
radial-gradient(circle at 10% 0,rgba(120,200,255,.22) 0,transparent 60%),
radial-gradient(circle at 90% 0,rgba(40,150,255,.32) 0,transparent 55%),
radial-gradient(circle at 45% 90%,rgba(255,80,150,.12) 0,transparent 55%);
opacity:.95; pointer-events:none;
}
.ccsr3-hero-left{ position:relative; z-index:1; min-width:260px; }
.ccsr3-title{
font-size:1.55rem; font-weight:800; letter-spacing:.2px;
text-shadow:0 8px 26px rgba(0,0,0,.55);
}
.ccsr3-sub{ margin-top:6px; font-size:.86rem; color:rgba(230,238,255,.86); }

.ccsr3-kpis{ display:flex; gap:10px; align-items:stretch; position:relative; z-index:1; }
.ccsr3-kpi{
min-width:108px;
padding:10px 12px; border-radius:16px;
background:rgba(6,20,50,.55);
border:1px solid rgba(120,190,255,.35);
box-shadow:0 10px 24px rgba(0,0,0,.35);
}
.ccsr3-kpi-k{ font-size:.72rem; opacity:.82; }
.ccsr3-kpi-v{ margin-top:4px; font-size:1.25rem; font-weight:900; }
.ccsr3-kpi-warn{
background:rgba(80,10,30,.28);
border-color:rgba(255,140,190,.35);
}

/* Controls */
.ccsr3-controls{
display:flex; justify-content:space-between; gap:12px; flex-wrap:wrap;
padding:12px 12px; border-radius:18px;
background:linear-gradient(135deg,rgba(6,10,26,.95),rgba(10,18,40,.95));
border:1px solid rgba(90,150,255,.35);
box-shadow:0 14px 30px rgba(0,0,0,.72);
margin-bottom:12px;
}

/* Search bar replacement patch (HUD style) */
.ccsr3 .ccsr3-search{
flex:1 1 340px;
display:flex !important;
align-items:center !important;
gap:12px !important;
height:52px !important;
padding:0 14px !important;
border-radius:16px !important;
border:0 !important;
outline:0 !important;
box-shadow:none !important;
background: linear-gradient(180deg, rgba(255,255,255,.06), rgba(255,255,255,.03)) !important;
backdrop-filter: blur(10px);
-webkit-backdrop-filter: blur(10px);
margin:0 !important;
}
.ccsr3 .ccsr3-search *{ box-shadow:none !important; }

/* Force single icon */
.ccsr3 .ccsr3-search-ico *{ display:none !important; visibility:hidden !important; }
.ccsr3 .ccsr3-search-ico{
position:relative !important;
width:40px !important;
min-width:40px !important;
height:34px !important;
padding:0 !important;
margin:0 !important;
border-radius:12px !important;
overflow:hidden !important;
font-size:0 !important;
color:transparent !important;
background: rgba(255,255,255,.06) !important;
border: 1px solid rgba(255,255,255,.10) !important;
box-shadow: 0 0 0 1px rgba(90,190,255,.12), 0 10px 26px rgba(0,0,0,.25) !important;
}
.ccsr3 .ccsr3-search-ico::before{
content:"" !important;
position:absolute !important;
inset:0 !important;
margin:auto !important;
width:16px !important;
height:16px !important;
background: no-repeat center/contain url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3E%3Cpath fill='%23EAF7FF' d='M10 18a8 8 0 1 1 5.293-14.002A8 8 0 0 1 10 18m0-14a6 6 0 1 0 0 12a6 6 0 0 0 0-12m9.707 16.293l-4.11-4.11a1 1 0 0 1 1.414-1.415l4.11 4.111a1 1 0 0 1-1.414 1.414'/%3E%3C/svg%3E") !important;
filter: drop-shadow(0 0 10px rgba(90,190,255,.35));
}

.ccsr3 input.ccsr3-search-in{
flex:1 1 auto !important;
height:100% !important;
border:0 !important;
outline:0 !important;
background:transparent !important;
box-shadow:none !important;
font-size:15px !important;
line-height:52px !important;
color: rgba(235,250,255,.96) !important;
padding:0 6px !important;
}
.ccsr3 input.ccsr3-search-in::placeholder{
color: rgba(200,235,255,.60) !important;
letter-spacing:.2px !important;
}
.ccsr3 .ccsr3-search:focus-within{
background: linear-gradient(180deg, rgba(90,190,255,.14), rgba(255,255,255,.04)) !important;
box-shadow:
0 0 0 1px rgba(90,190,255,.28),
0 0 0 4px rgba(90,190,255,.10),
0 18px 50px rgba(0,0,0,.35) !important;
}
.ccsr3 .ccsr3-search:focus-within .ccsr3-search-ico{
border-color: rgba(90,190,255,.35) !important;
box-shadow:
0 0 0 1px rgba(90,190,255,.25),
0 0 22px rgba(90,190,255,.20),
0 10px 26px rgba(0,0,0,.25) !important;
}

.ccsr3-filters{ display:flex; gap:10px; align-items:center; flex:0 0 auto; flex-wrap:wrap; justify-content:flex-end; }
.ccsr3-select{
border-radius:999px;
padding:10px 12px;
border:1px solid rgba(130,180,255,.32);
background:rgba(8,16,40,.92);
color:#fff;
font-size:.86rem;
outline:none;
min-width:170px;
}
.ccsr3-pill{
display:flex; gap:8px; align-items:center;
padding:10px 12px; border-radius:999px;
background:rgba(6,20,50,.55);
border:1px solid rgba(120,190,255,.25);
}
.ccsr3-pill-num{ font-weight:900; }
.ccsr3-pill-lbl{ opacity:.78; font-size:.82rem; }

/* List */
.ccsr3-list{ display:flex; flex-direction:column; gap:12px; }

.ccsr3-case{
border-radius:20px;
background:linear-gradient(135deg,rgba(6,10,26,.98),rgba(10,18,40,.98));
border:1px solid rgba(90,150,255,.32);
box-shadow:0 16px 36px rgba(0,0,0,.80);
overflow:hidden;
}
.ccsr3-card{
display:flex; justify-content:space-between; gap:12px;
padding:14px 14px;
}
.ccsr3-left{ display:flex; gap:12px; align-items:flex-start; min-width:0; flex: 1 1 auto; }
.ccsr3-thumb{
width:44px; height:44px; border-radius:14px;
overflow:hidden;
border:1px solid rgba(140,190,255,.30);
background:rgba(255,255,255,.06);
box-shadow:0 0 18px rgba(80,170,255,.12);
flex:0 0 auto;
}
.ccsr3-thumb img{ width:100%; height:100%; object-fit:cover; display:block; }
.ccsr3-thumb-ph{
width:100%; height:100%;
background:radial-gradient(circle at 30% 30%, rgba(120,200,255,.18), transparent 60%);
}







/* Slim variation pills under title */
.ccsr3-vpills{
  display:flex;
  flex-wrap:wrap;
  gap:6px;
  margin-top:6px;
  align-items:center;
}

.ccsr3-vpill{
  display:inline-flex;
  align-items:center;
  gap:6px;
  padding:5px 10px;          /* slim */
  border-radius:999px;
  background:rgba(0,0,0,.34);
  border:1px solid rgba(255,255,255,.16);
  color:rgba(255,255,255,.92);
  font-size:11.5px;         /* smaller */
  line-height:1.05;
  letter-spacing:.15px;
  white-space:nowrap;
}

.ccsr3-vpill-k{
  opacity:.72;
  font-weight:600;
}

.ccsr3-vpill-v{
  font-weight:700;
  opacity:.98;
}

.ccsr3-vpill--more{
  border-style:dashed;
  opacity:.90;
}











.ccsr3-main{ min-width:0; }
.ccsr3-product{
font-size:1.05rem; font-weight:900;
letter-spacing:.2px;
text-shadow:0 8px 22px rgba(0,0,0,.55);
white-space:normal;
overflow:visible;
text-overflow:unset;}
.ccsr3-meta{
margin-top:6px;
font-size:.82rem;
color:rgba(210,220,245,.82);
display:flex; gap:8px; flex-wrap:wrap;
}
.ccsr3 .ccsr3-meta-item > strong{
color: rgba(220, 230, 245, 0.85) !important;
font-weight: 500 !important;
}
span.ccsr3-meta-item{ text-transform: capitalize !important; }
.ccsr3-infer{ color:rgba(255,200,235,.9); }

.ccsr3-tags{
margin-top:10px;
display:flex; gap:8px; flex-wrap:wrap;
}
.ccsr3-tag{
display:inline-flex; align-items:center; gap:8px;
padding:8px 10px;
border-radius:999px;
border:1px solid rgba(120,190,255,.22);
background:rgba(8,16,40,.78);
font-size:.82rem;
box-shadow:0 10px 20px rgba(0,0,0,.35);
}
.ccsr3-tag-soft{ border-color:rgba(255,140,210,.16); background:rgba(80,20,45,.22); }
.ccsr3-tag-qty{ border-color:rgba(120,190,255,.28); }
.ccsr3-tag-date{ border-color:rgba(120,190,255,.18); opacity:.95; }
.ccsr3-tag-sub{ opacity:.72; font-size:.78rem; }

.ccsr3-tag-status{ font-weight:800; }
.ccsr3-tag-awaiting{ color:#7dd3fc; }
.ccsr3-tag-ok{ color:#86efac; background:rgba(20,70,45,.24); border-color:rgba(134,239,172,.22); }
.ccsr3-tag-warn{ color:#fda4af; background:rgba(70,15,35,.24); border-color:rgba(253,164,175,.22); }
.ccsr3-tag-danger{ color:#fecaca; background:rgba(110,10,25,.28); border-color:rgba(254,202,202,.22); }

.ccsr3-right{ display:flex; flex-direction:column; gap:10px; align-items:flex-end; flex:0 0 auto; }
.ccsr3-rma{ text-align:right; }
.ccsr3-rma-v{ font-size:.92rem; font-weight:900; letter-spacing:.35px; }

.ccsr3-actions{ display:flex; gap:8px; flex-wrap:wrap; justify-content:flex-end; }

/* Buttons: thin + slick */
.ccsr3 .ccsr3-btn{
padding:7px 12px !important;
border-radius:999px !important;
border:1px solid rgba(120,190,255,.22) !important;
font-size:.82rem !important;
font-weight:800 !important;
line-height:1 !important;
background: rgba(8,16,40,.72) !important;
color: rgba(240,248,255,.95) !important;
transition: transform .16s ease, box-shadow .16s ease, background .16s ease, border-color .16s ease, filter .16s ease !important;
user-select:none;
min-height:30px !important;
cursor:pointer;
}
.ccsr3 .ccsr3-btn:hover{
transform: translateY(-1px) !important;
background: rgba(20,40,85,.88) !important;
border-color: rgba(140,205,255,.38) !important;
box-shadow: 0 12px 28px rgba(0,0,0,.46), 0 0 26px rgba(90,190,255,.18) !important;
}
.ccsr3 .ccsr3-btn:active{
transform: translateY(0) scale(.99) !important;
filter: saturate(1.05) !important;
}
.ccsr3 .ccsr3-btn:focus-visible{
box-shadow:
0 14px 30px rgba(0,0,0,.46),
0 0 0 2px rgba(110,190,255,.35),
0 0 28px rgba(90,190,255,.22) !important;
}

/* Ghost (Details / View order) */
.ccsr3 .ccsr3-btn-ghost{
background: rgba(8,16,40,.62) !important;
border-color: rgba(120,190,255,.18) !important;
color: rgba(228,240,255,.92) !important;
}
.ccsr3 .ccsr3-btn-ghost:hover{
background: rgba(18,36,80,.86) !important;
border-color: rgba(140,205,255,.34) !important;
}

/* Primary (Copy RMA) glossy */
.ccsr3 .ccsr3-btn-primary{
border:0 !important;
background: linear-gradient(120deg,#2a88ff,#6ec1e4) !important;
color:#fff !important;
box-shadow: 0 12px 26px rgba(0,0,0,.42), 0 0 26px rgba(60,160,255,.28) !important;
position:relative;
overflow:hidden;
}
.ccsr3 .ccsr3-btn-primary:hover{
box-shadow: 0 16px 34px rgba(0,0,0,.48), 0 0 36px rgba(90,190,255,.55) !important;
}
.ccsr3 .ccsr3-btn-primary::after{
content:"";
position:absolute;
inset:-60% -40%;
background: radial-gradient(circle at 30% 30%, rgba(255,255,255,.22), transparent 55%);
opacity:.55;
transform: rotate(12deg);
pointer-events:none;
}

/* Good / Warn */
.ccsr3 .ccsr3-btn-good{
background: rgba(10,60,45,.34) !important;
border-color: rgba(134,239,172,.22) !important;
color: rgba(134,239,172,.95) !important;
box-shadow: 0 12px 24px rgba(0,0,0,.40), 0 0 22px rgba(134,239,172,.10) !important;
}
.ccsr3 .ccsr3-btn-good:hover{
background: rgba(12,76,52,.40) !important;
border-color: rgba(134,239,172,.30) !important;
box-shadow: 0 16px 30px rgba(0,0,0,.46), 0 0 32px rgba(134,239,172,.18) !important;
}
.ccsr3 .ccsr3-btn-warn{
background: rgba(70,15,35,.34) !important;
border-color: rgba(253,164,175,.22) !important;
color: rgba(253,164,175,.95) !important;
box-shadow: 0 12px 24px rgba(0,0,0,.40), 0 0 22px rgba(253,164,175,.10) !important;
}
.ccsr3 .ccsr3-btn-warn:hover{
background: rgba(92,18,42,.40) !important;
border-color: rgba(253,164,175,.30) !important;
box-shadow: 0 16px 30px rgba(0,0,0,.46), 0 0 32px rgba(253,164,175,.18) !important;
}
.ccsr3 .ccsr3-btn-disabled,
.ccsr3 .ccsr3-btn:disabled{
opacity:.45 !important;
filter:saturate(.85) !important;
cursor:not-allowed !important;
transform:none !important;
box-shadow: 0 10px 22px rgba(0,0,0,.34) !important;
}

/* Micro lines (liability/refund) */
.ccsr3 .ccsr3-micro{
margin-top:8px;
display:flex;
flex-direction:column;
gap:4px;
}
.ccsr3 .ccsr3-micro-line{
font-size:.78rem;
line-height:1.25;
color: rgba(210,235,255,.78);
text-shadow: 0 10px 22px rgba(0,0,0,.35);
}
.ccsr3 .ccsr3-micro-strong{
color: rgba(235,250,255,.92);
font-weight: 800;
}

/* Drawer */
.ccsr3-drawer{
border-top:1px solid rgba(120,190,255,.18);
background:linear-gradient(135deg,rgba(6,10,26,.88),rgba(10,18,40,.88));
padding:12px 14px 14px;
}
.ccsr3-drawer-grid{
display:grid;
grid-template-columns: 1.3fr 1fr 1fr 1.4fr;
gap:10px;
}
.ccsr3-drawer-box{
border-radius:16px;
padding:12px 12px;
background:rgba(8,16,40,.70);
border:1px solid rgba(120,190,255,.20);
box-shadow:0 10px 22px rgba(0,0,0,.35);
min-width:0;
}
.ccsr3-drawer-box-wide{ grid-column: 1 / -1; }
.ccsr3-dk{ font-size:.72rem; opacity:.72; }
.ccsr3-dv{ margin-top:6px; font-size:.90rem; font-weight:700; }
.ccsr3-muted{ opacity:.72; font-weight:600; }

.ccsr3-drawer-actions{
margin-top:10px;
display:flex;
gap:8px;
flex-wrap:wrap;
}

/* Always-visible receive qty selector (no drawer dependency) */
.ccsr3-recv-inline{
display:inline-flex;
align-items:center;
gap:8px;
flex-wrap:wrap;
padding:6px 8px;
border-radius:999px;
background:rgba(8,16,40,.55);
border:1px solid rgba(120,190,255,.16);
box-shadow:0 10px 22px rgba(0,0,0,.30);
}
.ccsr3 .ccsr3-recv-inline .ccsr3-rq-in{
width:90px !important;
height:32px !important;
border-radius:12px !important;
border:1px solid rgba(120,190,255,.22) !important;
background:rgba(8,16,40,.72) !important;
color:#fff !important;
font-weight:900 !important;
text-align:center !important;
outline:none !important;
}
.ccsr3-drawer-foot{
margin-top:10px;
font-size:.82rem;
opacity:.85;
}
@keyframes ccsr3Pulse {
  0% {
    box-shadow: 0 0 0 rgba(0, 190, 255, 0.0);
  }
  50% {
    box-shadow:
      0 0 14px rgba(0, 190, 255, 0.65),
      0 0 32px rgba(0, 190, 255, 0.35);
  }
  100% {
    box-shadow: 0 0 0 rgba(0, 190, 255, 0.0);
  }
}

.ccsr3-glow-awaiting {
  animation: ccsr3Pulse 2.8s ease-in-out infinite;
  border-radius: 14px;
}
/* Empty + toast */
.ccsr3-empty{
padding:18px;
border-radius:18px;
background:linear-gradient(135deg,rgba(6,10,26,.95),rgba(10,18,40,.95));
border:1px solid rgba(90,150,255,.25);
box-shadow:0 14px 30px rgba(0,0,0,.72);
}
.ccsr3-empty-title{ font-size:1.05rem; font-weight:900; }
.ccsr3-empty-sub{ margin-top:6px; opacity:.78; font-size:.86rem; }

.ccsr3-toast{
position:fixed;
right:18px;
bottom:18px;
z-index:999999;
padding:12px 14px;
border-radius:16px;
background:rgba(8,16,40,.92);
border:1px solid rgba(120,190,255,.22);
box-shadow:0 18px 40px rgba(0,0,0,.75);
font-weight:800;
}

@media (max-width: 980px){
.ccsr3-drawer-grid{ grid-template-columns: 1fr; }
.ccsr3-right{ align-items:flex-start; }
.ccsr3-card{ flex-direction:column; }
}
@media (max-width: 768px){
.ccsr3 .ccsr3-search{ height:46px !important; border-radius:14px !important; }
.ccsr3 input.ccsr3-search-in{ line-height:46px !important; font-size:14px !important; }
.ccsr3 .ccsr3-search-ico{ width:32px !important; min-width:32px !important; height:32px !important; border-radius:11px !important; }
}
CSS
    );

    $ajax_url = admin_url( 'admin-ajax.php' );

    wp_add_inline_script( 'ccsr3-script', <<<JS
(function(){
  var root = document.querySelector('.ccsr3');
  if(!root) return;

  var ajaxUrl = (window.ajaxurl || (window.woocommerce_params && window.woocommerce_params.ajax_url) || '/wp-admin/admin-ajax.php');
  var nonce = root.getAttribute('data-ccsr3-nonce') || '';

  function q(sel, ctx){ return (ctx||document).querySelector(sel); }
  function qa(sel, ctx){ return Array.prototype.slice.call((ctx||document).querySelectorAll(sel)); }

  var toastEl = q('.ccsr3-toast', root);
  var toastTimer = null;

  function toast(msg){
    if(!toastEl) return;
    toastEl.textContent = msg;
    toastEl.hidden = false;
    if(toastTimer) window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(function(){ toastEl.hidden = true; }, 2200);
  }

document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.ccsr3-card').forEach(card => {
    const text = card.innerText.toLowerCase();

    const isAwaiting =
      text.includes('awaiting return') ||
      text.includes('requested');

    if (isAwaiting) {
      card.classList.add('ccsr3-glow-awaiting');
    }
  });
});


  // Filtering
  var searchIn = q('.ccsr3-search-in', root);
  var statusSel = q('.ccsr3-select[data-filter="status"]', root);
  var deadSel = q('.ccsr3-select[data-filter="deadline"]', root);
  var cases = qa('.ccsr3-case', root);

  function norm(s){ return String(s || '').toLowerCase().trim(); }

  function applyFilters(){
    var term = norm(searchIn && searchIn.value);
    var st = statusSel ? statusSel.value : '';
    var dl = deadSel ? deadSel.value : '';

    for(var i=0;i<cases.length;i++){
      var card = cases[i];
      var hay = [
        card.getAttribute('data-rma'),
        card.getAttribute('data-product'),
        card.getAttribute('data-reason'),
        card.getAttribute('data-order')
      ].join(' ');
      var matchesTerm = !term || hay.indexOf(term) !== -1;
      var matchesStatus = !st || card.getAttribute('data-status') === st;
      var matchesDl = !dl || card.getAttribute('data-deadlinebucket') === dl;

      card.style.display = (matchesTerm && matchesStatus && matchesDl) ? '' : 'none';
    }
  }

  if(searchIn){ searchIn.addEventListener('input', applyFilters); }
  if(statusSel){ statusSel.addEventListener('change', applyFilters); }
  if(deadSel){ deadSel.addEventListener('change', applyFilters); }

  function xhrPost(params, cb){
    try{
      var xhr = new XMLHttpRequest();
      xhr.open('POST', ajaxUrl, true);
      xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded; charset=UTF-8');
      xhr.withCredentials = true;
      xhr.onreadystatechange = function(){
        if(xhr.readyState !== 4) return;
        var json = null;
        try{ json = JSON.parse(xhr.responseText); }catch(e){ json = null; }
        cb(json, xhr.status);
      };
      xhr.send(params);
    }catch(e){
      cb(null, 0);
    }
  }

  function encodeParams(obj){
    var parts = [];
    for(var k in obj){
      if(!obj.hasOwnProperty(k)) continue;
      parts.push(encodeURIComponent(k) + '=' + encodeURIComponent(String(obj[k])));
    }
    return parts.join('&');
  }

  // Drawer toggle + actions
  root.addEventListener('click', function(e){
    var btn = e.target.closest ? e.target.closest('button[data-act]') : null;
    if(!btn) return;

    var act = btn.getAttribute('data-act');
    var card = btn.closest ? btn.closest('.ccsr3-case') : null;
    if(!card) return;

    if(act === 'toggle'){
      var drawer = q('.ccsr3-drawer', card);
      if(!drawer) return;
      var isHidden = drawer.hasAttribute('hidden');
      if(isHidden){
        drawer.removeAttribute('hidden');
        btn.textContent = 'Hide';
      }else{
        drawer.setAttribute('hidden','');
        btn.textContent = 'Details';
      }
      return;
    }

    if(act === 'copy'){
      var val = btn.getAttribute('data-copy') || '';
      // robust fallback: execCommand copy
      var ta = document.createElement('textarea');
      ta.value = val;
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      try{
        document.execCommand('copy');
        toast('Copied RMA');
      }catch(_e){
        toast('Copy failed');
      }
      document.body.removeChild(ta);
      return;
    }
    if(act === 'received' || act === 'escalate'){
      var orderId = btn.getAttribute('data-order') || '';
      var rmaId = btn.getAttribute('data-rma') || card.getAttribute('data-rma') || '';
      var itemId = btn.getAttribute('data-item') || '';
      var maxQty = parseInt(btn.getAttribute('data-max') || '0', 10) || 0;

      if(!orderId || !rmaId){ toast('Missing case identifiers'); return; }

      btn.disabled = true;
      var oldTxt = btn.textContent;
      btn.textContent = 'Saving…';

      var payload = {
        action: 'ccsr3_update_case',
        nonce: nonce,
        order_id: orderId,
        rma_id: rmaId,
        case_action: act
      };
      if(itemId) payload.item_id = itemId;

      if(act === 'received'){
        var inp = btn.parentElement ? btn.parentElement.querySelector('.ccsr3-rq-in') : null;
        var qv = inp ? parseInt(inp.value || '0', 10) : maxQty;
        if(isNaN(qv)) qv = 0;
        if(qv < 0) qv = 0;
        if(maxQty > 0 && qv > maxQty) qv = maxQty;
        payload.qty_received = qv;
      }

      xhrPost(encodeParams(payload), function(json){
        if(!json || !json.success){
          var msg = (json && json.data && json.data.message) ? json.data.message : 'Update failed.';
          toast(msg);
          btn.disabled = false;
          btn.textContent = oldTxt;
          return;
        }

        toast('Updated');

        var newStatus = (act === 'received') ? 'received' : 'escalated';
        card.setAttribute('data-status', newStatus);

        var pill = q('.ccsr3-tag-status', card);
        if(pill){
          pill.classList.remove('ccsr3-tag-awaiting','ccsr3-tag-ok','ccsr3-tag-warn','ccsr3-tag-danger');
          if(newStatus === 'received'){
            pill.classList.add('ccsr3-tag-ok');
            if(act === 'received'){
              var inp2 = btn.parentElement ? btn.parentElement.querySelector('.ccsr3-rq-in') : null;
              var qv2 = inp2 ? parseInt(inp2.value || '0', 10) : 0;
              if(maxQty > 0 && qv2 >= 0 && qv2 < maxQty){
                pill.textContent = 'Received ('+qv2+'/'+maxQty+')';
              }else{
                pill.textContent = 'Received';
              }
            }else{
              pill.textContent = 'Received';
            }
          }else{
            pill.classList.add('ccsr3-tag-warn');
            pill.textContent = 'Escalated';
          }
        }

        applyFilters();
        btn.disabled = false;
        btn.textContent = oldTxt;
      });

      return;
    }
  });

  applyFilters();
})();
JS
);

}, 20 );


  add_action('wp_footer', function () {
?>
<script>
(function(){
  function norm(t){
    return (t||'').toLowerCase().replace(/\s+/g,' ').trim();
  }

  function applyUrgentGlow(){
    document.querySelectorAll('div.ccsr3-card').forEach(card => {
      const text = norm(card.innerText);

      const needsAttention =
        text.includes('requested') ||
        text.includes('awaiting return');

      const closed =
        text.includes('received') ||
        text.includes('refunded') ||
        text.includes('declined') ||
        text.includes('closed') ||
        text.includes('resolved');

      if (needsAttention && !closed) {
        card.classList.add('ccsr3-attention');
      } else {
        card.classList.remove('ccsr3-attention');
      }
    });
  }

  applyUrgentGlow();
  setTimeout(applyUrgentGlow, 300);
  setTimeout(applyUrgentGlow, 900);
  setInterval(applyUrgentGlow, 2000);
})();
</script>
<?php
}, 9999);

add_action('wp_footer', function(){ echo '<style>
/* === Tiered aging glow (single source of truth) ===
   0-4h: none
   5-10h: soft blue pulse
   10h+: moderate red pulse
*/
@keyframes ccsr3BlueSoft {
  0%   { box-shadow: 0 0 0 rgba(0,190,255,0); }
  50%  { box-shadow: 0 0 12px rgba(0,190,255,.45), 0 0 26px rgba(0,190,255,.22); }
  100% { box-shadow: 0 0 0 rgba(0,190,255,0); }
}
@keyframes ccsr3RedModerate {
  0%   { box-shadow: 0 0 0 rgba(255,0,0,0); }
  50%  { box-shadow: 0 0 14px rgba(255,60,60,.70), 0 0 34px rgba(255,60,60,.35); }
  100% { box-shadow: 0 0 0 rgba(255,0,0,0); }
}

/* Disable legacy glow classes if present */
.ccsr3-glow-awaiting,
.ccsr3-attention {
  animation: none !important;
  box-shadow: none !important;
  outline: none !important;
}

/* Apply tiered glow on card */
div.ccsr3-case.ccsr3-tier-blue > div.ccsr3-card{
  animation: ccsr3BlueSoft 3.0s ease-in-out infinite !important;
  border: 1px solid rgba(0,190,255,.28) !important;
}
div.ccsr3-case.ccsr3-tier-red > div.ccsr3-card{
  animation: ccsr3RedModerate 2.0s ease-in-out infinite !important;
  border: 2px solid rgba(255,70,70,.55) !important;
}
</style>'; }, 999999);



add_action('wp_footer', function(){ ?>
<script>
(function(){
  var HOUR = 3600;

  function norm(s){ return (s||'').toLowerCase().trim(); }
  function isActive(st){
    st = norm(st);
    return st === 'requested' || st === 'awaiting_return' || st === 'under_review' || st === 'return_in_progress' || st === 'approved' || st === 'approved_return_pickup';
  }
  function isClosed(st){
    st = norm(st);
    return st === 'received' || st === 'declined' || st === 'closed' || st === 'resolved' || st === 'completed' || st === 'cancelled' || st === 'cancelled_partial';
  }
  function apply(){
    var now = Math.floor(Date.now()/1000);
    var cases = document.querySelectorAll('.ccsr3-case[data-created-ts]');
    if(!cases || !cases.length) return;

    cases.forEach(function(cs){
      var st = norm(cs.getAttribute('data-status')||'');
      var created = parseInt(cs.getAttribute('data-created-ts')||'0',10) || 0;
      if(created > 1000000000000) created = Math.floor(created/1000);

      cs.classList.remove('ccsr3-tier-blue','ccsr3-tier-red');

      if(!created || !isActive(st) || isClosed(st)) return;

      var ageH = (now - created) / HOUR;

      if(ageH >= 10){
        cs.classList.add('ccsr3-tier-red');
      } else if(ageH >= 5){
        cs.classList.add('ccsr3-tier-blue');
      }
    });
  }

  apply();
  setTimeout(apply, 600);
  setTimeout(apply, 1600);

  document.addEventListener('click', function(e){
    if(e.target && (e.target.closest('.ccsr3-btn') || e.target.closest('.ccsr3-control'))) {
      setTimeout(apply, 120);
    }
  }, true);
})();
</script>
<?php }, 999999);



add_action('wp_footer', function(){ echo '<style>
/* === Aggressive tier glow override (unmistakeably obvious) === */
@keyframes ccsr3BlueBlast {
  0%   { box-shadow: 0 0 0 rgba(0,180,255,0), inset 0 0 0 rgba(0,180,255,0); transform: translateZ(0); }
  50%  { box-shadow: 0 0 18px rgba(0,180,255,.95), 0 0 44px rgba(0,180,255,.75), inset 0 0 26px rgba(0,180,255,.55); }
  100% { box-shadow: 0 0 0 rgba(0,180,255,0), inset 0 0 0 rgba(0,180,255,0); }
}
@keyframes ccsr3RedAlarm {
  0%   { box-shadow: 0 0 0 rgba(255,0,0,0), inset 0 0 0 rgba(255,0,0,0); transform: translateZ(0); }
  50%  { box-shadow: 0 0 28px rgba(255,40,40,1), 0 0 70px rgba(255,0,0,.95), inset 0 0 32px rgba(255,0,0,.70); }
  100% { box-shadow: 0 0 0 rgba(255,0,0,0), inset 0 0 0 rgba(255,0,0,0); }
}

/* Nuke legacy subtle styles */
div.ccsr3-case.ccsr3-tier-blue > div.ccsr3-card,
div.ccsr3-case.ccsr3-tier-red > div.ccsr3-card{
  position: relative !important;
  z-index: 50 !important;
  overflow: visible !important;
  border-radius: 16px !important;
}

/* 5–10h: loud BLUE pulse */
div.ccsr3-case.ccsr3-tier-blue > div.ccsr3-card{
  outline: 5px solid rgba(0,180,255,.92) !important;
  outline-offset: 4px !important;
  border: 2px solid rgba(0,180,255,.55) !important;
  animation: ccsr3BlueBlast 2.2s ease-in-out infinite !important;
}

/* 10h+: BLARING RED fast alarm */
div.ccsr3-case.ccsr3-tier-red > div.ccsr3-card{
  outline: 6px solid rgba(255,60,60,1) !important;
  outline-offset: 5px !important;
  border: 3px solid rgba(255,60,60,.90) !important;
  animation: ccsr3RedAlarm 1.05s linear infinite !important;
}
</style>'; }, 999999);
