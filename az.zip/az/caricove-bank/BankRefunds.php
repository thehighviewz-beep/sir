<?php
namespace Caricove\Bank;

if (!defined('ABSPATH')) exit;

final class BankRefunds
{
    private static function money($value): float
    {
        return round((float) $value, 2);
    }

    private static function build_trace_context(array $case, array $extra = []): array
    {
        $seed = array_merge($case, $extra);
        $case_id = self::normalize_case_id($seed);
        $existing = trim((string) ($seed['correlation_id'] ?? $seed['trace_context']['correlation_id'] ?? ''));
        if ($existing === '') {
            $existing = 'refund-' . substr(md5($case_id . '|' . (string) ($seed['shipment_id'] ?? 0) . '|' . (string) ($seed['order_item_id'] ?? 0) . '|' . microtime(true)), 0, 16);
        }
        return [
            'correlation_id' => $existing,
            'command_source' => 'bank_refunds',
            'case_id' => $case_id,
            'refund_case_id' => $case_id,
            'shipment_id' => (int) ($seed['shipment_id'] ?? 0),
            'order_id' => (int) ($seed['order_id'] ?? 0),
            'order_item_id' => (int) ($seed['order_item_id'] ?? 0),
            'vendor_id' => (int) ($seed['vendor_id'] ?? 0),
            'customer_id' => (int) ($seed['customer_id'] ?? 0),
            'actor_user_id' => function_exists('get_current_user_id') ? (int) get_current_user_id() : 0,
            'captured_at' => function_exists('current_time') ? current_time('mysql') : gmdate('Y-m-d H:i:s'),
        ];
    }

    private static function with_trace_meta(array $meta, array $trace, string $operation = ''): array
    {
        $existing = isset($meta['trace_context']) && is_array($meta['trace_context']) ? $meta['trace_context'] : [];
        $meta['trace_context'] = array_merge($existing, $trace);
        if ($operation !== '') {
            $meta['trace_operation'] = $operation;
        }
        if (!empty($trace['correlation_id'])) {
            $meta['correlation_id'] = (string) $trace['correlation_id'];
        }
        return $meta;
    }

    private static function is_return_required(array $case): bool
    {
        $case_type = sanitize_key((string) ($case['case_type'] ?? 'return'));
        if (in_array($case_type, ['cancel', 'cancellation'], true)) {
            return false;
        }

        if (array_key_exists('return_required', $case)) {
            return !empty($case['return_required']);
        }

        return true;
    }

    private static function is_non_customer_fault_case(array $case, array $overrides = []): bool
    {
        $merged = array_merge($case, $overrides);
        foreach (['resolved_fault_party', 'shipping_liability_party', 'fault', 'initial_fault'] as $key) {
            if (!array_key_exists($key, $merged)) {
                continue;
            }
            $party = sanitize_key((string) $merged[$key]);
            if ($party === '') {
                continue;
            }
            if (in_array($party, ['seller', 'carrier', 'mixed'], true)) {
                return true;
            }
            if ($party === 'customer') {
                return false;
            }
        }
        return false;
    }

   private static function resolve_effective_qty(array $case, array $overrides = []): int
{
    $merged = array_merge($case, array_intersect_key($overrides, array_flip([
        'qty_received',
        'qty_rec',
        'qty_refundable',
        'qty_requested',
        'return_required',
        'case_type',
        'resolved_fault_party',
        'shipping_liability_party',
        'fault',
        'initial_fault',
        'refund_execution_mode',
    ])));

    $return_required = self::is_return_required($merged);
    $mode = self::resolve_refund_execution_mode($merged, []);

    /*
     * Hard rule:
     * - return_required cases remain item-receive-gated
     * - never_received / returnless paths may still resolve qty earlier
     * This prevents item refund + seller debit exposure from surfacing
     * before the item is actually returned.
     */
    if ($return_required && $mode !== 'never_received') {
        foreach (['qty_received', 'qty_rec'] as $key) {
            if (!array_key_exists($key, $merged)) {
                continue;
            }
            $received = max(0, (int) $merged[$key]);
            if ($received > 0) {
                return $received;
            }
        }
        return 0;
    }

    if (array_key_exists('qty_refundable', $merged)) {
        return max(0, (int) $merged['qty_refundable']);
    }

    if (array_key_exists('qty_requested', $merged)) {
        return max(0, (int) $merged['qty_requested']);
    }

    return 0;
}
    private static function resolve_refund_amount(array $case, array $overrides = []): float
    {
        $merged = array_merge($case, array_intersect_key($overrides, array_flip([
            'refund_amount_approved',
            'refund_amount_requested',
            'refund_suggested',
            'item_refund_amount_customer',
            'outbound_shipping_refund_amount_customer',
            'customer_total_refund',
            'order_item_id',
            'order_id',
            'unit_price',
            'qty_received',
            'qty_rec',
            'qty_refundable',
            'qty_requested',
            'return_required',
            'case_type',
            'resolved_fault_party',
            'shipping_liability_party',
            'fault',
            'initial_fault',
        ])));

        $effective_qty = self::resolve_effective_qty($merged);
        if ($effective_qty <= 0) {
            return 0.0;
        }

        $return_required = self::is_return_required($merged);
        $refund_amount = 0.0;

        if (array_key_exists('item_refund_amount_customer', $merged) && (float) $merged['item_refund_amount_customer'] > 0) {
            $refund_amount = (float) $merged['item_refund_amount_customer'];
        } elseif (
            array_key_exists('customer_total_refund', $merged)
            && (float) $merged['customer_total_refund'] > 0
            && array_key_exists('outbound_shipping_refund_amount_customer', $merged)
        ) {
            $refund_amount = max(0.0, (float) $merged['customer_total_refund'] - max(0.0, (float) $merged['outbound_shipping_refund_amount_customer']));
        } elseif (array_key_exists('refund_amount_approved', $merged) && (float) $merged['refund_amount_approved'] > 0) {
            $refund_amount = (float) $merged['refund_amount_approved'];
        } elseif (array_key_exists('refund_amount_requested', $merged) && (float) $merged['refund_amount_requested'] > 0) {
            $refund_amount = (float) $merged['refund_amount_requested'];
        } elseif (array_key_exists('refund_suggested', $merged) && (float) $merged['refund_suggested'] > 0) {
            $refund_amount = (float) $merged['refund_suggested'];
        }

        $max_refundable = 0.0;

        if (!empty($merged['order_item_id'])) {
            $order = function_exists('wc_get_order') ? wc_get_order((int) ($merged['order_id'] ?? 0)) : null;
            if ($order) {
                $item = $order->get_item((int) $merged['order_item_id']);
                if ($item) {
                    $item_total = (float) $item->get_total();
                    $item_qty = max(1, (int) $item->get_quantity());
                    $per_unit = $item_qty > 0 ? ($item_total / $item_qty) : $item_total;
                    $max_refundable = self::money($per_unit * min($item_qty, $effective_qty));
                }
            }
        }

        if ($max_refundable <= 0.0 && !empty($merged['unit_price'])) {
            $max_refundable = self::money((float) $merged['unit_price'] * $effective_qty);
        }

       if ($return_required) {
            if ($max_refundable > 0.0) {
                $refund_amount = $refund_amount > 0.0 ? min($refund_amount, $max_refundable) : $max_refundable;
            } elseif (self::is_non_customer_fault_case($merged)) {
                /*
                 * Non-customer-fault return-required cases are allowed to surface
                 * refund amounts earlier at request / approved / awaiting-return stage.
                 * Keep any known requested/approved/suggested amount visible here
                 * instead of collapsing to zero just because seller-received is not set yet.
                 */
                $refund_amount = self::money(max(0.0, $refund_amount));
            } else {
                $refund_amount = 0.0;
            }
        } elseif ($refund_amount <= 0.0 && $max_refundable > 0.0) {
            $refund_amount = $max_refundable;
        }

        return self::money(max(0.0, $refund_amount));
    }

    private static function normalize_case_id(array $case): string
    {
        $case_id = trim((string) ($case['case_id'] ?? ''));
        if ($case_id !== '') {
            return $case_id;
        }

        $shipment_id = (int) ($case['shipment_id'] ?? 0);
        $order_item_id = (int) ($case['order_item_id'] ?? 0);
        $refund_id = (int) ($case['refund_id'] ?? 0);

        return 'shipment-' . $shipment_id . '-item-' . $order_item_id . '-refund-' . $refund_id;
    }

    private static function compute_reversible_unpaid_bridge(int $shipment_id, int $vendor_id): float
    {
        global $wpdb;

        if ($shipment_id <= 0 || $vendor_id <= 0) {
            return 0.0;
        }

        $sum = (float) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COALESCE(SUM(net), 0)
                 FROM " . Ledger::table() . "
                 WHERE shipment_id = %d
                   AND vendor_id = %d
                   AND state IN ('pending','hold')
                   AND net > 0",
                $shipment_id,
                $vendor_id
            )
        );

        return self::money(max(0.0, $sum));
    }

    private static function normalize_liability_party($party): string
    {
        $party = sanitize_key((string) $party);
        return in_array($party, ['seller', 'carrier'], true) ? $party : '';
    }

    private static function is_explicit_seller_fault_case(array $case, array $overrides = []): bool
    {
        $merged = array_merge($case, $overrides);
        foreach (['resolved_fault_party', 'shipping_liability_party', 'shipping_payer'] as $key) {
            if (!array_key_exists($key, $merged)) {
                continue;
            }
            $party = sanitize_key((string) $merged[$key]);
            if (in_array($party, ['seller', 'vendor', 'merchant'], true)) {
                return true;
            }
            if (in_array($party, ['carrier', 'courier', 'customer', 'buyer', 'user', 'none', 'clear'], true)) {
                return false;
            }
        }
        return false;
    }

    private static function resolve_order_shipping_amount(array $case): float
    {
        $order_id = (int) ($case['order_id'] ?? 0);
        if ($order_id <= 0) {
            return 0.0;
        }

        $amount = 0.0;

        if (function_exists('wc_get_order')) {
            $order = wc_get_order($order_id);
            if ($order) {
                $amount = max(0.0, (float) $order->get_shipping_total() + (float) $order->get_shipping_tax());
                if ($amount <= 0.0) {
                    foreach ((array) $order->get_items('shipping') as $ship_item) {
                        if (!is_object($ship_item)) {
                            continue;
                        }
                        $line_total = method_exists($ship_item, 'get_total') ? (float) $ship_item->get_total() : 0.0;
                        $tax_total = 0.0;
                        if (method_exists($ship_item, 'get_taxes')) {
                            $taxes = (array) $ship_item->get_taxes();
                            if (!empty($taxes['total']) && is_array($taxes['total'])) {
                                foreach ($taxes['total'] as $amt) {
                                    $tax_total += (float) $amt;
                                }
                            }
                        }
                        $amount += max(0.0, $line_total + $tax_total);
                    }
                }
            }
        }

        if ($amount <= 0.0) {
            $amount = max(0.0,
                (float) get_post_meta($order_id, '_order_shipping', true)
                + (float) get_post_meta($order_id, '_order_shipping_tax', true)
            );
        }

        if ($amount <= 0.0) {
            foreach (['outbound_shipping_refund_amount_customer', 'shipping_liability_amount_internal'] as $key) {
                if (!empty($case[$key]) && (float) $case[$key] > 0) {
                    $amount = max($amount, (float) $case[$key]);
                }
            }
        }

        if ($amount <= 0.0 && class_exists(__NAMESPACE__ . '\BankRefundCases')) {
            $rows = BankRefundCases::list_order_cases($order_id);
            if (is_array($rows)) {
                foreach ($rows as $row) {
                    if (!is_array($row)) {
                        continue;
                    }
                    $candidate = max(
                        (float) ($row['outbound_shipping_refund_amount_customer'] ?? 0),
                        (float) ($row['shipping_liability_amount_internal'] ?? 0)
                    );
                    if ($candidate > $amount) {
                        $amount = $candidate;
                    }
                }
            }
        }

        return self::money(max(0.0, $amount));
    }

   private static function shipping_family_anchor(array $case): string
    {
        /*
         * Shipping consumption is order-scoped even when item cases are case-scoped.
         * Keep one order-wide anchor so outbound shipping can never be refunded or charged twice
         * for the same order-level shipping family.
         */
        $order_id = (int) ($case['order_id'] ?? 0);
        if ($order_id > 0) {
            return 'order-' . $order_id;
        }

        $shipment_id = (int) ($case['shipment_id'] ?? 0);
        if ($shipment_id > 0) {
            return 'shipment-' . $shipment_id;
        }

        $case_id = self::normalize_case_id($case);
        if ($case_id !== '') {
            return 'case-' . $case_id;
        }

        return 'order-unknown';
    }

  private static function shipping_bucket_meta_key(): string
{
    /*
     * One order → one shipping bucket.
     * This prevents duplicate shipping charges across multiple cases/items.
     */
    return '_caricove_bank_shipping_refund_bucket';
}

    private static function default_shipping_bucket(array $case): array
    {
        return [
            'order_id' => (int) ($case['order_id'] ?? 0),
            'owner_case_id' => '',
            'total_shipping_refundable' => self::resolve_order_shipping_amount($case),
            'already_allocated_shipping' => 0.0,
            'posting_key' => '',
            'status' => 'open',
            'updated_at' => time(),
        ];
    }

    private static function normalize_shipping_bucket(array $case, array $bucket): array
    {
        $bucket = array_merge(self::default_shipping_bucket($case), $bucket);

        $bucket['order_id'] = (int) ($bucket['order_id'] ?? ($case['order_id'] ?? 0));
        $bucket['owner_case_id'] = trim((string) ($bucket['owner_case_id'] ?? ''));
        $bucket['total_shipping_refundable'] = self::money(max(0.0, (float) ($bucket['total_shipping_refundable'] ?? 0)));
        if ($bucket['total_shipping_refundable'] <= 0) {
            $bucket['total_shipping_refundable'] = self::resolve_order_shipping_amount($case);
        }
        $bucket['already_allocated_shipping'] = self::money(max(0.0, (float) ($bucket['already_allocated_shipping'] ?? 0)));
        if ($bucket['already_allocated_shipping'] > $bucket['total_shipping_refundable']) {
            $bucket['already_allocated_shipping'] = $bucket['total_shipping_refundable'];
        }
        $bucket['posting_key'] = sanitize_text_field((string) ($bucket['posting_key'] ?? ''));
        $bucket['status'] = sanitize_key((string) ($bucket['status'] ?? 'open'));
        if ($bucket['status'] === '') {
            $bucket['status'] = 'open';
        }
        $bucket['updated_at'] = max(0, (int) ($bucket['updated_at'] ?? time()));

        return $bucket;
    }

   private static function infer_shipping_bucket_from_cases(array $case): array
    {
        /*
         * Shipping truth must be recovered across the whole order.
         * If any earlier case already consumed or posted the outbound shipping refund,
         * later item cases must inherit that exhausted order-wide state.
         */
        $bucket = self::default_shipping_bucket($case);
        $order_id = (int) ($case['order_id'] ?? 0);

        if ($order_id <= 0 || !class_exists(__NAMESPACE__ . '\\BankRefundCases')) {
            return $bucket;
        }

        $rows = BankRefundCases::list_order_cases($order_id);
        if (!$rows) {
            return self::normalize_shipping_bucket($case, $bucket);
        }

        $best_amount = 0.0;
        $best_case_id = '';
        $best_posting_key = '';
        $best_status = 'open';

        foreach ((array) $rows as $row) {
            if (!is_array($row)) {
                continue;
            }

            $row_bucket = $row['order_shipping_refund_bucket'] ?? [];
            if (is_string($row_bucket) && $row_bucket !== '') {
                $maybe_bucket = maybe_unserialize($row_bucket);
                if (is_array($maybe_bucket)) {
                    $row_bucket = $maybe_bucket;
                }
            }
            if (!is_array($row_bucket)) {
                $row_bucket = [];
            }

            $row_shipping = max(
                self::money((float) ($row['outbound_shipping_refund_amount_customer'] ?? 0)),
                self::money((float) ($row_bucket['already_allocated_shipping'] ?? 0))
            );

            $shipping_posting_key = trim((string) ($row['shipping_refund_posting_key'] ?? $row['shipping_liability_posting_key'] ?? $row['shipping_posting_key'] ?? ''));
            $shipping_posting_status = sanitize_key((string) ($row['shipping_posting_status'] ?? ''));
            $shipping_visibility_status = sanitize_key((string) ($row['shipping_visibility_status'] ?? ''));
            $financial_status = sanitize_key((string) ($row['financial_status'] ?? ''));

            $posted = (
                $shipping_posting_key !== ''
                || in_array($shipping_posting_status, ['posted', 'visible'], true)
                || in_array($shipping_visibility_status, ['posted', 'visible'], true)
                || in_array($financial_status, ['shipping_posted', 'completed', 'debit_posted', 'reversal_posted'], true)
            );

            if (!$posted || $row_shipping <= 0) {
                continue;
            }

            if ($row_shipping > $best_amount) {
                $best_amount = $row_shipping;
                $best_case_id = self::normalize_case_id($row);
                $best_posting_key = $shipping_posting_key;
                $best_status = 'posted';
            }
        }

        if ($best_amount > 0) {
            $bucket['owner_case_id'] = $best_case_id;
            $bucket['already_allocated_shipping'] = $best_amount;
            $bucket['posting_key'] = $best_posting_key;
            $bucket['status'] = $best_status;
        }

        return self::normalize_shipping_bucket($case, $bucket);
    }

  private static function read_shipping_bucket(array $case): array
    {
        $order_id = (int) ($case['order_id'] ?? 0);
        if ($order_id <= 0) {
            return self::default_shipping_bucket($case);
        }

        $raw = get_post_meta($order_id, self::shipping_bucket_meta_key(), true);
        $bucket = is_array($raw) ? $raw : [];

        if (!$bucket) {
            $bucket = self::infer_shipping_bucket_from_cases($case);
        }

        return self::normalize_shipping_bucket($case, $bucket);
    }
    
    
   private static function write_shipping_bucket(array $case, array $bucket): void
{
    $order_id = (int) ($case['order_id'] ?? 0);
    if ($order_id <= 0) {
        return;
    }

    update_post_meta(
        $order_id,
        self::shipping_bucket_meta_key(),
        self::normalize_shipping_bucket($case, $bucket)
    );
}

    private static function shipping_bucket_owner_case_id(array $case): string
    {
        $bucket = self::read_shipping_bucket($case);
        $owner = trim((string) ($bucket['owner_case_id'] ?? ''));
        return $owner !== '' ? $owner : self::normalize_case_id($case);
    }

    private static function already_posted_shipping_amount(array $case): float
    {
        $bucket = self::read_shipping_bucket($case);
        return self::money((float) ($bucket['already_allocated_shipping'] ?? 0));
    }

    private static function remaining_shipping_refund_amount(array $case): float
{
    $bucket = self::read_shipping_bucket($case);
    $total  = self::money((float) ($bucket['total_shipping_refundable'] ?? 0));

    if ($total <= 0) {
        return 0.0;
    }

    $posted = self::money((float) ($bucket['already_allocated_shipping'] ?? 0));

    /*
     * CRITICAL RULE:
     * If shipping has already been consumed once, no other case can claim it.
     */
    if ($posted > 0) {
        return 0.0;
    }

    return $total;
}


   private static function claim_shipping_bucket(array $case, float $shipping_refund_amount, string $posting_key): array
{
    $bucket = self::read_shipping_bucket($case);

    /*
     * If already claimed, do nothing.
     */
    if ((float) ($bucket['already_allocated_shipping'] ?? 0) > 0) {
        return $bucket;
    }

    $bucket['owner_case_id'] = self::normalize_case_id($case);
    $bucket['already_allocated_shipping'] = self::money($shipping_refund_amount);
    $bucket['posting_key'] = sanitize_text_field($posting_key);
    $bucket['status'] = 'posted';
    $bucket['updated_at'] = time();

    self::write_shipping_bucket($case, $bucket);

    return $bucket;
}


    private static function release_shipping_bucket(array $case): void
    {
        $bucket = self::read_shipping_bucket($case);
        if (trim((string) ($bucket['owner_case_id'] ?? '')) !== self::normalize_case_id($case)) {
            return;
        }

        $bucket['owner_case_id'] = '';
        $bucket['already_allocated_shipping'] = 0.0;
        $bucket['posting_key'] = '';
        $bucket['status'] = 'open';
        $bucket['updated_at'] = time();
        self::write_shipping_bucket($case, $bucket);
    }


    private static function case_matches_shipping_bucket(array $case, array $bucket): bool
    {
        $case_id = self::normalize_case_id($case);
        $owner_case_id = trim((string) ($bucket['owner_case_id'] ?? ''));
        if ($case_id !== '' && $owner_case_id !== '' && $owner_case_id === $case_id) {
            return true;
        }

        $bucket_posting_key = trim((string) ($bucket['posting_key'] ?? ''));
        if ($bucket_posting_key !== '') {
            foreach (['shipping_refund_posting_key', 'shipping_liability_posting_key', 'shipping_posting_key'] as $key) {
                $case_posting_key = trim((string) ($case[$key] ?? ''));
                if ($case_posting_key !== '' && $case_posting_key === $bucket_posting_key) {
                    return true;
                }
            }
        }

        return false;
    }

    private static function posted_shipping_component_for_case(array $case, ?array $bucket = null): float
    {
        $bucket = is_array($bucket) ? self::normalize_shipping_bucket($case, $bucket) : self::read_shipping_bucket($case);
        $raw = self::money(max(
            (float) ($case['outbound_shipping_refund_amount_customer'] ?? 0),
            (float) ($case['shipping_refund_amount'] ?? 0)
        ));
        $allocated = self::money((float) ($bucket['already_allocated_shipping'] ?? 0));

        if ($allocated > 0) {
            if (!self::case_matches_shipping_bucket($case, $bucket)) {
                return 0.0;
            }
            return $raw > 0 ? min($raw, $allocated) : $allocated;
        }

        $shipping_posting_key = trim((string) ($case['shipping_refund_posting_key'] ?? $case['shipping_liability_posting_key'] ?? $case['shipping_posting_key'] ?? ''));
        $shipping_posting_status = sanitize_key((string) ($case['shipping_posting_status'] ?? ''));
        $shipping_visibility_status = sanitize_key((string) ($case['shipping_visibility_status'] ?? ''));
        $financial_status = sanitize_key((string) ($case['financial_status'] ?? ''));
        $posted = (
            $shipping_posting_key !== ''
            || in_array($shipping_posting_status, ['posted', 'visible'], true)
            || in_array($shipping_visibility_status, ['posted', 'visible'], true)
            || in_array($financial_status, ['shipping_posted', 'completed', 'debit_posted', 'reversal_posted', 'refund_posted'], true)
        );

        return $posted ? $raw : 0.0;
    }


    private static function posted_item_component_for_case(array $case): float
    {
        $raw = self::money((float) ($case['item_refund_amount_customer'] ?? 0));
        if ($raw <= 0.0) {
            return 0.0;
        }

        $item_posting_key = trim((string) ($case['item_refund_posting_key'] ?? ''));
        $financial_status = sanitize_key((string) ($case['financial_status'] ?? ''));
        $status = sanitize_key((string) ($case['status'] ?? ''));

        $posted = (
            $item_posting_key !== ''
            || in_array($financial_status, ['refund_posted', 'completed', 'debit_posted', 'reversal_posted'], true)
            || $status === 'refunded'
        );

        return $posted ? $raw : 0.0;
    }

   private static function resolve_item_received_flag(array $case, array $overrides = []): int
{
    $mode = self::resolve_refund_execution_mode($case, $overrides);

    $qty_received = 0;
    if (array_key_exists('qty_received', $overrides)) {
        $qty_received = (int) $overrides['qty_received'];
    } elseif (array_key_exists('qty_received', $case)) {
        $qty_received = (int) $case['qty_received'];
    }

    /*
     * Hard rule for return-required flow:
     * physical return receipt is driven by qty_received only.
     * Do not let stored item_received_flag drift prematurely advance
     * item refund / seller debit exposure before the item is actually back.
     */
    if ($mode === 'return_required') {
        return $qty_received > 0 ? 1 : 0;
    }

    if (array_key_exists('item_received_flag', $overrides)) {
        return !empty($overrides['item_received_flag']) ? 1 : 0;
    }
    if (array_key_exists('item_received_flag', $case)) {
        return !empty($case['item_received_flag']) ? 1 : 0;
    }

    if ($qty_received > 0) {
        return 1;
    }

    if ((string) ($case['reason_code'] ?? '') === 'never_arrived') {
        return 0;
    }

    return 0;
}
    private static function resolve_refund_execution_mode(array $case, array $overrides = []): string
    {
        $mode = sanitize_key((string) ($overrides['refund_execution_mode'] ?? $case['refund_execution_mode'] ?? ''));
        if (in_array($mode, ['never_received', 'return_required', 'returnless'], true)) {
            return $mode;
        }

        if ((string) ($case['reason_code'] ?? '') === 'never_arrived') {
            return 'never_received';
        }

        return self::is_return_required(array_merge($case, $overrides)) ? 'return_required' : 'returnless';
    }

    private static function resolve_shipping_liability_party(array $case, array $overrides = []): string
    {
        foreach (['shipping_liability_party', 'resolved_fault_party', 'shipping_payer'] as $key) {
            if (array_key_exists($key, $overrides)) {
                $party = self::normalize_liability_party($overrides[$key]);
                if ($party !== '') {
                    return $party;
                }
            }
            if (array_key_exists($key, $case)) {
                $party = self::normalize_liability_party($case[$key]);
                if ($party !== '') {
                    return $party;
                }
            }
        }

        return '';
    }





private static function is_pre_return_shipping_only_eligible(array $case, array $overrides = []): bool
{
    $mode = self::resolve_refund_execution_mode($case, $overrides);
    $return_required = self::is_return_required(array_merge($case, $overrides));

    $shipping_posted = trim((string) ($case['shipping_refund_posting_key'] ?? '')) !== ''
        || trim((string) ($case['shipping_liability_posting_key'] ?? '')) !== ''
        || trim((string) ($case['shipping_posting_key'] ?? '')) !== '';

    /*
     * IMPORTANT:
     * Shipping eligibility should not disappear just because the item was later received.
     * If seller fault applies and outbound shipping has not yet been consumed, keep the
     * shipping refund option alive until shipping is actually posted.
     */
    $remaining_shipping = self::remaining_shipping_refund_amount(array_merge($case, $overrides));

    return (
        $return_required
        && $mode !== 'never_received'
        && !$shipping_posted
        && $remaining_shipping > 0
        && self::is_explicit_seller_fault_case($case, $overrides)
    );
}











    private static function resolve_shipping_refund_amount(array $case, array $overrides = []): float
{
    $candidate = 0.0;
    foreach (['outbound_shipping_refund_amount_customer', 'shipping_refund_amount'] as $key) {
        if (array_key_exists($key, $overrides) && is_numeric($overrides[$key])) {
            $candidate = self::money(max(0.0, (float) $overrides[$key]));
            break;
        }
        if (array_key_exists($key, $case) && is_numeric($case[$key]) && (float) $case[$key] > 0) {
            $candidate = self::money(max(0.0, (float) $case[$key]));
            break;
        }
    }

    $selected = array_key_exists('shipping_refund_selected', $overrides)
        ? !empty($overrides['shipping_refund_selected'])
        : !empty($case['shipping_refund_selected']);

    $refund_execution_mode = self::resolve_refund_execution_mode($case, $overrides);
    $pre_return_shipping_only = self::is_pre_return_shipping_only_eligible($case, $overrides);

    /*
     * Shipping may surface before item receipt only for seller-fault,
     * return-required, shipping-first flow. Customer-fault / unassigned cases
     * must keep shipping at zero until the normal received-item path.
     */
   $liability_party = self::resolve_shipping_liability_party($case, $overrides);

/*
 * Shipping refund may only exist if a valid liability party exists.
 */
if ($candidate <= 0.0 && (
    $selected
    || $refund_execution_mode === 'never_received'
    || $pre_return_shipping_only
)) {
    if ($liability_party !== '') {
        $candidate = self::resolve_order_shipping_amount($case);
    } else {
        $candidate = 0.0;
    }
}

    if ($candidate <= 0.0) {
        return 0.0;
    }

    $remaining = self::remaining_shipping_refund_amount($case);
    if ($remaining <= 0.0) {
        return 0.0;
    }

    return self::money(min($candidate, $remaining));
}

    private static function resolve_return_shipping_cost_internal(array $case, array $overrides = []): float
    {
        if (array_key_exists('return_shipping_cost_internal', $overrides)) {
            return self::money(max(0.0, (float) $overrides['return_shipping_cost_internal']));
        }
        if (array_key_exists('return_shipping_cost_internal', $case)) {
            return self::money(max(0.0, (float) $case['return_shipping_cost_internal']));
        }
        return 0.0;
    }

    private static function item_refund_posting_key(array $case): string
    {
        return 'refund:' . self::normalize_case_id($case) . ':item';
    }

    private static function shipping_posting_key(array $case, string $party, string $type): string
    {
        return implode(':', array_filter([
            'shipping',
            self::shipping_family_anchor($case),
            sanitize_key($party),
            sanitize_key($type),
        ], static function ($value) {
            return $value !== '' && $value !== null;
        }));
    }

    private static function courier_id_for_case(array $case): int
    {
        $shipment_id = (int) ($case['shipment_id'] ?? 0);
        if ($shipment_id > 0) {
            if (class_exists('\Caricove\Logistics\Core\ShipmentManager') && method_exists('\Caricove\Logistics\Core\ShipmentManager', 'get_shipment_summary')) {
                $summary = \Caricove\Logistics\Core\ShipmentManager::get_shipment_summary($shipment_id);
                $cid = (int) ($summary['courier_id'] ?? 0);
                if ($cid > 0) {
                    return $cid;
                }
            }

            $meta_key = '_cc_shipment_courier_id';
            if (class_exists('\Caricove\Logistics\Core\Schema')) {
                $meta_key = \Caricove\Logistics\Core\Schema::META_SHIPMENT_COURIER_ID;
            }
            $cid = (int) get_post_meta($shipment_id, $meta_key, true);
            if ($cid > 0) {
                return $cid;
            }
        }

        return (int) ($case['courier_id'] ?? 0);
    }

    private static function upsert_courier_shipping_liability(array $case, array $preview): array
    {
        $fronted_option = 'caricove_bank_platform_fronted_v1';
        $recovery_option = 'caricove_bank_courier_recovery_v1';
        $case_id = self::normalize_case_id($case);
        $fronted = get_option($fronted_option, []);
        $recovery = get_option($recovery_option, []);
        if (!is_array($fronted)) $fronted = [];
        if (!is_array($recovery)) $recovery = [];

       $posting_key = self::shipping_posting_key($case, 'carrier', 'shipping_liability_carrier');
        $courier_id = self::courier_id_for_case($case);

        $item_amount = self::money((float) ($preview['courier_liability_item_amount'] ?? 0));
        $shipping_amount = self::money((float) ($preview['courier_liability_shipping_amount'] ?? $preview['courier_shipping_impact'] ?? $preview['shipping_liability_amount_internal'] ?? 0));
        $total_amount = self::money((float) ($preview['courier_liability_total_amount'] ?? ($item_amount + $shipping_amount)));
        $customer_total = self::money((float) ($preview['customer_total_refund'] ?? ($item_amount + $shipping_amount)));

        $fronted_id = '';
        $fronted_index = null;
       foreach ($fronted as $idx => $row) {
            if ((string) ($row['source_case_id'] ?? '') === $case_id) {
                $fronted_index = $idx;
                $fronted_id = (string) ($row['fronted_case_id'] ?? '');
                break;
            }
        }
        if ($fronted_id === '') {
            $fronted_id = 'pf_' . wp_generate_password(12, false, false);
        }

        $fronted_record = [
            'fronted_case_id'                 => $fronted_id,
            'source_case_id'                  => $case_id,
            'shipping_posting_key'            => $posting_key,
            'created_at'                      => $fronted_index === null ? time() : (int) ($fronted[$fronted_index]['created_at'] ?? time()),
            'updated_at'                      => time(),
            'created_by_admin_id'             => get_current_user_id(),
            'status'                          => 'refunded',
            'customer_id'                     => (int) ($case['customer_id'] ?? 0),
            'vendor_id'                       => (int) ($case['vendor_id'] ?? 0),
            'courier_id'                      => $courier_id,
            'order_id'                        => (int) ($case['order_id'] ?? 0),
            'shipment_id'                     => (int) ($case['shipment_id'] ?? 0),
            'product_id'                      => (int) ($case['product_id'] ?? 0),
            'product_name'                    => (string) ($case['product_name'] ?? ''),
            'reason_code'                     => (string) ($case['reason_code'] ?? ''),
            'reason_text'                     => (string) ($case['reason_text'] ?? ''),
            'qty_requested'                   => (int) ($case['qty_requested'] ?? 0),
            'qty_received'                    => (int) ($case['qty_received'] ?? 0),
            'customer_item_refund_amount'     => self::money((float) ($preview['item_refund_amount_customer'] ?? 0)),
            'customer_shipping_refund_amount' => self::money((float) ($preview['outbound_shipping_refund_amount_customer'] ?? 0)),
            'customer_refund_amount'          => $customer_total,
            'total_fronted_amount'            => $customer_total,
            'shipping_liability_party'        => 'carrier',
            'shipping_liability_amount'       => $shipping_amount,
           'courier_liability_item_amount'   => $item_amount,
            'courier_liability_shipping_amount' => $shipping_amount,
            'courier_liability_total_amount'  => $total_amount,
            'remaining_amount_total'          => $total_amount,
            'recovery_case_id'                => '',
        ];
        if ($fronted_index === null) {
            $fronted[] = $fronted_record;
        } else {
            $fronted[$fronted_index] = array_merge((array) $fronted[$fronted_index], $fronted_record);
        }

        $recovery_id = '';
        $recovery_index = null;
      foreach ($recovery as $idx => $row) {
            if ((string) ($row['source_case_id'] ?? '') === $case_id) {
                $recovery_index = $idx;
                $recovery_id = (string) ($row['recovery_case_id'] ?? '');
                break;
            }
        }
        
        if ($recovery_id === '') {
            $recovery_id = 'cr_' . wp_generate_password(12, false, false);
        }

        $recovery_record = [
            'recovery_case_id'         => $recovery_id,
            'platform_fronted_case_id' => $fronted_id,
            'shipping_posting_key'     => $posting_key,
            'created_at'               => $recovery_index === null ? time() : (int) ($recovery[$recovery_index]['created_at'] ?? time()),
            'updated_at'               => time(),
            'created_by_admin_id'      => get_current_user_id(),
           'status'                   => $total_amount > 0 ? 'open' : 'recovered',
            'courier_id'               => $courier_id,
            'order_id'                 => (int) ($case['order_id'] ?? 0),
            'shipment_id'              => (int) ($case['shipment_id'] ?? 0),
            'source_case_id'           => $case_id,
            'recoverable_amount_total' => $total_amount,
            'recovered_amount_total'   => 0.0,
            'remaining_amount_total'   => $total_amount,
            'shipping_liability_amount'=> $shipping_amount,
            'courier_liability_item_amount' => $item_amount,
            'courier_liability_shipping_amount' => $shipping_amount,
            'courier_liability_total_amount' => $total_amount,
            'reason_code'              => (string) ($case['reason_code'] ?? ''),
            'reason_text'              => (string) ($case['reason_text'] ?? ''),
        ];
        if ($recovery_index === null) {
            $recovery[] = $recovery_record;
        } else {
            $recovery[$recovery_index] = array_merge((array) $recovery[$recovery_index], $recovery_record);
        }

       foreach ($fronted as &$row) {
            if ((string) ($row['source_case_id'] ?? '') === $case_id) {
                $row['recovery_case_id'] = $recovery_id;
                $row['remaining_amount_total'] = $total_amount;
                break;
            }
        }
        
        
        unset($row);

        update_option($fronted_option, array_values($fronted), false);
        update_option($recovery_option, array_values($recovery), false);

        return [
            'fronted_case_id' => $fronted_id,
            'recovery_case_id' => $recovery_id,
            'shipping_posting_key' => $posting_key,
            'shipping_liability_posting_key' => $posting_key,
'courier_liability_total_amount' => $total_amount,        ];
    }

    public static function preview_refund(array $case, array $overrides = []): array
    {
        $case = array_merge($case, array_intersect_key($overrides, array_flip([
            'refund_amount_approved',
            'refund_amount_requested',
            'refund_suggested',
            'qty_requested',
            'qty_refundable',
            'qty_received',
            'qty_rec',
            'item_refund_amount_customer',
            'outbound_shipping_refund_amount_customer',
            'shipping_liability_party',
            'return_shipping_cost_internal',
            'refund_execution_mode',
            'item_received_flag',
            'shipping_refund_selected',
        ])));

        $shipment_id   = (int) ($case['shipment_id'] ?? 0);
        $order_id      = (int) ($case['order_id'] ?? 0);
        $vendor_id     = (int) ($case['vendor_id'] ?? 0);
        $order_item_id = (int) ($case['order_item_id'] ?? 0);
        $case_id       = self::normalize_case_id($case);
        $effective_qty = self::resolve_effective_qty($case, $overrides);

        $refund_amount = self::resolve_refund_amount($case, $overrides);
        $commission_reversal = self::money((float) Ledger::compute_commission_reversal_for_refund(
            $shipment_id,
            $order_id,
            $refund_amount
        ));

        $item_snapshot = method_exists(Ledger::class, 'inspect_item_chain_state')
            ? Ledger::inspect_item_chain_state($shipment_id, $vendor_id, $order_item_id, (float) $effective_qty, $order_id)
            : [
                'slice_id' => 'ship:' . $shipment_id . ':item:' . $order_item_id,
                'seller_impact_amount' => max(0.0, $refund_amount - $commission_reversal),
                'reversible_unpaid_amount' => self::compute_reversible_unpaid_bridge($shipment_id, $vendor_id),
                'available_amount' => 0.0,
                'paid_cash_amount' => 0.0,
                'active_target_allocated_amount' => 0.0,
                'active_source_amount' => 0.0,
                'unit_amount' => self::money($effective_qty > 0 ? (max(0.0, $refund_amount - $commission_reversal) / $effective_qty) : 0.0),
                'role_state' => 'NEUTRAL',
            ];

        $snapshot_seller_impact = self::money((float) ($item_snapshot['seller_impact_amount'] ?? 0));
        $live_seller_impact = self::money(max(0.0, $refund_amount - $commission_reversal));

        if ($snapshot_seller_impact > 0) {
            $seller_impact = self::money(min($live_seller_impact, $snapshot_seller_impact));
        } else {
            $seller_impact = $live_seller_impact;
        }

        if ($effective_qty <= 0) {
            $seller_impact = 0.0;
        }

        $reversible_unpaid = self::money((float) ($item_snapshot['reversible_unpaid_amount'] ?? 0));
        $reversal_amount = self::money(min($seller_impact, $reversible_unpaid));
        $debit_amount = self::money(max(0.0, $seller_impact - $reversal_amount));
        $commission_absorbed = self::money(min(
            $commission_reversal,
            max(0.0, $refund_amount - $seller_impact)
        ));

        $chain_snapshot = [
            'role_state' => (string) ($item_snapshot['role_state'] ?? 'RESOLVED'),
            'reversible_unpaid_amount' => $reversible_unpaid,
            'available_amount' => self::money((float) ($item_snapshot['available_amount'] ?? 0)),
            'paid_cash_amount' => self::money((float) ($item_snapshot['paid_cash_amount'] ?? 0)),
            'active_target_allocated_amount' => self::money((float) ($item_snapshot['active_target_allocated_amount'] ?? 0)),
            'active_source_amount' => self::money((float) ($item_snapshot['active_source_amount'] ?? 0)),
            'seller_impact_amount' => $seller_impact,
            'slice_id' => (string) ($item_snapshot['slice_id'] ?? ('ship:' . $shipment_id . ':item:' . $order_item_id)),
            'matched_qty' => (float) ($item_snapshot['matched_qty'] ?? $effective_qty),
            'unit_amount' => self::money($effective_qty > 0 ? ($seller_impact / $effective_qty) : 0.0),
        ];

        $role_state_before = strtoupper((string) ($chain_snapshot['role_state'] ?? 'RESOLVED'));
        $active_target_allocated_amount = self::money((float) ($chain_snapshot['active_target_allocated_amount'] ?? 0));
        $active_source_amount = self::money((float) ($chain_snapshot['active_source_amount'] ?? 0));
        $paid_cash_amount = self::money((float) ($chain_snapshot['paid_cash_amount'] ?? 0));
        $target_unwind_amount = self::money(min($debit_amount, $active_target_allocated_amount));
        $source_open_amount = $debit_amount;

        $financial_mode = 'debit';
        if ($reversal_amount > 0 && $debit_amount > 0) {
            $financial_mode = 'mixed';
        } elseif ($reversal_amount > 0 && $debit_amount <= 0) {
            $financial_mode = 'reversal';
        }

        $chain_mode = 'resolved_noop';
        if ($debit_amount <= 0 && $reversal_amount > 0) {
            $chain_mode = 'unpaid_reversal_only';
        } elseif ($debit_amount <= 0 && $commission_absorbed > 0) {
            $chain_mode = 'platform_absorbed_only';
        } elseif ($debit_amount > 0 && $target_unwind_amount > 0 && $reversal_amount > 0) {
            $chain_mode = 'mixed_reversal_target_unwind_source';
        } elseif ($debit_amount > 0 && $target_unwind_amount > 0) {
            $chain_mode = 'target_unwind_then_source';
        } elseif ($debit_amount > 0 && $active_source_amount > 0 && $reversal_amount > 0) {
            $chain_mode = 'mixed_reversal_additive_source';
        } elseif ($debit_amount > 0 && $active_source_amount > 0) {
            $chain_mode = 'additive_source';
        } elseif ($debit_amount > 0 && $reversal_amount > 0) {
            $chain_mode = 'mixed_reversal_source';
        } elseif ($debit_amount > 0) {
            $chain_mode = 'source_open';
        }

        $seller_outcome_label = 'Added to seller debt';
        if ($chain_mode === 'unpaid_reversal_only') {
            $seller_outcome_label = 'Removed from unpaid seller earnings';
        } elseif ($chain_mode === 'platform_absorbed_only') {
            $seller_outcome_label = 'Absorbed by platform commission reversal';
        } elseif ($chain_mode === 'target_unwind_then_source' || $chain_mode === 'mixed_reversal_target_unwind_source') {
            $seller_outcome_label = 'Unwinds prior recovery, reopens prior debt, then opens this shipment as source debt';
        } elseif ($chain_mode === 'additive_source' || $chain_mode === 'mixed_reversal_additive_source') {
            $seller_outcome_label = 'Added as a new source slice on top of existing source exposure';
        } elseif ($chain_mode === 'source_open' || $chain_mode === 'mixed_reversal_source') {
            $seller_outcome_label = 'Opened as source debt for the seller impact amount';
        }

        $item_refund_amount_customer = self::money($refund_amount);
        $outbound_shipping_refund_amount_customer = self::resolve_shipping_refund_amount($case, $overrides);
        $shipping_liability_party = self::resolve_shipping_liability_party($case, $overrides);
        $shipping_liability_amount_internal = $shipping_liability_party !== '' ? $outbound_shipping_refund_amount_customer : 0.0;
        $return_shipping_cost_internal = self::resolve_return_shipping_cost_internal($case, $overrides);
        $refund_execution_mode = self::resolve_refund_execution_mode($case, $overrides);
        $item_received_flag = self::resolve_item_received_flag($case, $overrides);
      $seller_shipping_impact  = $shipping_liability_party === 'seller'  ? $shipping_liability_amount_internal : 0.0;
        $courier_shipping_impact = $shipping_liability_party === 'carrier' ? $shipping_liability_amount_internal : 0.0;

        $resolved_fault_party = sanitize_key((string) ($overrides['resolved_fault_party'] ?? $case['resolved_fault_party'] ?? ''));
        $carrier_fault_case = in_array($resolved_fault_party, ['carrier', 'courier', 'shipping', 'logistics'], true)
            || $shipping_liability_party === 'carrier';

        $courier_item_impact = $carrier_fault_case ? $item_refund_amount_customer : 0.0;
        $courier_total_impact = self::money($courier_item_impact + $courier_shipping_impact);

        $customer_total_refund = self::money($item_refund_amount_customer + $outbound_shipping_refund_amount_customer);

        /*
         * DOMAIN SEPARATION:
         * - item exposure comes only from unresolved item-side seller obligation
         * - shipping exposure comes only from unresolved shipping-side seller obligation
         * - commission gap must NEVER become seller debt
         */
        $item_exposure_amount = self::money(max(0.0, $debit_amount));

        /*
         * For now, shipping is posted as seller liability directly when seller is the payer.
         * Do NOT duplicate it again as seller debit exposure.
         */
        $shipping_exposure_amount = 0.0;

        /*
         * Commission disappearing on an unpaid reversal is neutralized platform margin,
         * not seller debt.
         */
        $commission_gap_amount = self::money(max(
            0.0,
            $customer_total_refund
            - ($seller_impact + $seller_shipping_impact + $courier_shipping_impact + $item_exposure_amount)
        ));

        if ($chain_mode === 'unpaid_reversal_only') {
            $item_exposure_amount = 0.0;
        }

        /*
         * refund-debit already represents the exact item-side debt once payout is available/paid.
         * Seller Debit Exposure must only be used for true residual / special non-item seller top-up,
         * never as a duplicate mirror of the same item amount.
         *
         * No extra residual is resolved here unless a separate flow computes one explicitly,
         * so keep seller debit exposure at zero by default.
         */
        $seller_debit_exposure_amount = 0.0;
        $seller_outcome_amount        = self::money($seller_impact + $seller_shipping_impact);

        /*
         * "Caricove pays now" should reflect temporary operational outlay, not fake seller debt.
         * Keep commission gap out of seller exposure.
         */
        $caricove_pays_now = self::money(max(
            0.0,
            $customer_total_refund
            - $seller_outcome_amount
            - $seller_debit_exposure_amount
            - $courier_shipping_impact
        ));
        $caricove_loss = self::money($caricove_pays_now);
        if ($seller_shipping_impact > 0) {
            $seller_outcome_label .= ' + shipping charge to seller';
        } elseif ($courier_shipping_impact > 0) {
            $seller_outcome_label .= ' + shipping routed to courier';
        }

        return [
            'case_id'                       => $case_id,
            'refund_amount'                 => $refund_amount,
            'item_refund_amount_customer'   => $item_refund_amount_customer,
            'outbound_shipping_refund_amount_customer' => $outbound_shipping_refund_amount_customer,
            'customer_total_refund'         => $customer_total_refund,
            'commission_reversal'           => $commission_reversal,
            'commission_absorbed'           => $commission_absorbed,
            'financial_mode'                => $financial_mode,
            'mode'                          => $financial_mode,
            'chain_mode'                    => $chain_mode,
            'seller_debit_amount'           => $debit_amount,
            'seller_impact'                 => $seller_impact,
            'seller_shipping_impact'        => $seller_shipping_impact,
            'item_exposure_amount'          => $item_exposure_amount,
            'shipping_exposure_amount'      => $shipping_exposure_amount,
            'commission_gap_amount'         => $commission_gap_amount,
            'seller_debit_exposure_amount'  => $seller_debit_exposure_amount,
           'courier_shipping_impact'       => $courier_shipping_impact,
            'courier_liability_item_amount' => $courier_item_impact,
            'courier_liability_shipping_amount' => $courier_shipping_impact,
            'courier_liability_total_amount' => $courier_total_impact,
            'shipping_liability_amount_internal' => $shipping_liability_amount_internal,
            'shipping_liability_party'      => $shipping_liability_party,
            'return_shipping_cost_internal' => $return_shipping_cost_internal,
            'refund_execution_mode'         => $refund_execution_mode,
            'item_received_flag'            => $item_received_flag,
            'return_required'               => self::is_return_required($case),
            'available_bridge'              => $reversible_unpaid,
            'reversal_amount'               => $reversal_amount,
            'debit_amount'                  => $debit_amount,
            'source_open_amount'            => $source_open_amount,
            'target_unwind_amount'          => $target_unwind_amount,
            'active_target_allocated_amount'=> $active_target_allocated_amount,
            'active_source_amount'          => $active_source_amount,
            'paid_cash_amount'              => $paid_cash_amount,
            'role_state_before'             => $role_state_before,
            'needs_target_unwind'           => $target_unwind_amount > 0,
            'needs_source_open'             => $source_open_amount > 0,
            'customer_gets_back'            => $customer_total_refund,
            'seller_outcome_label'          => $seller_outcome_label,
            'seller_outcome_amount'         => $seller_outcome_amount,
            'caricove_profit'               => $caricove_loss,
            'caricove_loss'                 => $caricove_loss,
            'caricove_pays_now'             => $caricove_pays_now,
            'chain_snapshot'                => $chain_snapshot,
            'slice_id'                      => (string) ($chain_snapshot['slice_id'] ?? ''),
            'unit_price_net'                => self::money((float) ($chain_snapshot['unit_amount'] ?? 0)),
            'qty_refundable'                => $effective_qty,
        ];
    }

    public static function commit_refund(array $case, array $overrides = []): array
    {
        $case = array_merge($case, array_intersect_key($overrides, array_flip([
            'refund_amount_approved',
            'refund_amount_requested',
            'refund_suggested',
            'qty_requested',
            'qty_refundable',
            'qty_received',
            'qty_rec',
            'item_refund_amount_customer',
            'outbound_shipping_refund_amount_customer',
            'shipping_liability_party',
            'return_shipping_cost_internal',
            'refund_execution_mode',
            'item_received_flag',
            'shipping_refund_selected',
        ])));

        $case_id       = self::normalize_case_id($case);
        $shipment_id   = (int) ($case['shipment_id'] ?? 0);
        $order_id      = (int) ($case['order_id'] ?? 0);
        $vendor_id     = (int) ($case['vendor_id'] ?? 0);
        $order_item_id = (int) ($case['order_item_id'] ?? 0);
        $effective_qty = self::resolve_effective_qty($case, $overrides);
        $case_status = sanitize_key((string) ($case['status'] ?? ''));
        $case_financial_status = sanitize_key((string) ($case['financial_status'] ?? ''));
        if (trim((string) ($case['item_refund_posting_key'] ?? '')) !== '' || $case_status === 'refunded' || in_array($case_financial_status, ['refund_posted', 'reversal_posted', 'debit_posted', 'completed'], true)) {
            return [
                'success' => true,
                'already_processed' => true,
                'mode' => 'already_processed',
                'amount' => self::money((float) ($case['item_refund_amount_customer'] ?? $case['refund_amount_approved'] ?? 0)),
                'item_refund_amount_customer' => self::money((float) ($case['item_refund_amount_customer'] ?? $case['refund_amount_approved'] ?? 0)),
                'outbound_shipping_refund_amount_customer' => 0.0,
                'customer_total_refund' => self::money((float) ($case['customer_total_refund'] ?? $case['item_refund_amount_customer'] ?? $case['refund_amount_approved'] ?? 0)),
                'reversed_amount' => 0.0,
                'commission_absorbed' => 0.0,
                'debit_amount' => 0.0,
                'source_open_amount' => 0.0,
                'target_unwind_total' => 0.0,
                'invalidated_targets' => [],
                'reopened_sources' => [],
                'role_state_before' => '',
                'role_state_after' => '',
            ];
        }

        $shipment_resolution_status = sanitize_key((string) ($case['shipment_resolution_status'] ?? ($shipment_id > 0 ? 'resolved' : 'ambiguous')));
        if ($shipment_id <= 0 || $vendor_id <= 0 || $shipment_resolution_status !== 'resolved') {
            return [
                'success' => false,
                'error'   => 'Invalid refund case context.'
            ];
        }

        $preview = self::preview_refund($case, $overrides);
        $refund_amount = (float) ($preview['refund_amount'] ?? 0);
        if ($refund_amount <= 0) {
            return [
                'success' => false,
                'error'   => 'Refund amount resolved to zero.'
            ];
        }

        $case['case_id'] = $case_id;
        $trace_context = self::build_trace_context($case, $overrides);
        $case['correlation_id'] = $trace_context['correlation_id'];
        $case['trace_context'] = $trace_context;
        $case['refund_amount_approved'] = $refund_amount;

        $bridge_meta = self::with_trace_meta(self::build_return_bridge_meta($case, $preview), $trace_context, 'refund_commit');
        $unique_key = self::item_refund_posting_key($case);

        $reversal_budget = self::money((float) ($preview['reversal_amount'] ?? 0));

        $reversed = self::money((float) Ledger::reverse_unpaid_shipment_earnings_amount_idempotent(
            $unique_key,
            $shipment_id,
            $vendor_id,
            $reversal_budget,
            [
                'case_id'       => $case_id,
                'order_item_id' => $order_item_id,
                'qty_requested' => $effective_qty,
                'slice_id'      => (string) ($preview['slice_id'] ?? ''),
                'chain_mode'    => (string) ($preview['chain_mode'] ?? ''),
                'role_state_before' => (string) ($preview['role_state_before'] ?? ''),
                'return_bridge' => array_merge($bridge_meta, [
                    'original_net' => self::money((float) ($preview['seller_impact'] ?? 0)),
                    'refunded_customer_amount' => $refund_amount,
                ]),
                'trace_context' => $trace_context,
                'correlation_id' => $trace_context['correlation_id'],
            ]
        ));

        $commission_reversal = self::money((float) ($preview['commission_reversal'] ?? 0));
        $commission_absorbed = self::money((float) ($preview['commission_absorbed'] ?? 0));
        $remaining = self::money(max(0.0, (float) ($preview['seller_impact'] ?? 0) - $reversed));

        $post_reversal_chain = method_exists(Ledger::class, 'inspect_item_chain_state')
            ? Ledger::inspect_item_chain_state($shipment_id, $vendor_id, $order_item_id, (float) $effective_qty, $order_id)
            : [
                'role_state' => 'RESOLVED',
                'active_target_allocated_amount' => 0.0,
                'active_source_amount' => 0.0,
            ];

        $target_unwind_budget = self::money(min(
            $remaining,
            (float) ($post_reversal_chain['active_target_allocated_amount'] ?? 0)
        ));

        $txn_refs = [];
        if ($reversed > 0) {
            $txn_refs[] = $unique_key;

            self::record_bank_event('reversal', $case, $reversed, 'Refund reversed unpaid seller earnings before payout', [
                'financial_mode'    => $remaining > 0 ? 'mixed' : 'reversal',
                'chain_mode'        => (string) ($preview['chain_mode'] ?? ''),
                'role_state_before' => (string) ($preview['role_state_before'] ?? ''),
                'role_state_after'  => (string) ($post_reversal_chain['role_state'] ?? ''),
                'return_bridge'     => array_merge($bridge_meta, [
                    'reversed_amount' => $reversed,
                    'original_net'    => self::money((float) ($preview['seller_impact'] ?? $reversed)),
                ]),
            ]);
        }

        $target_unwind = [
            'success' => true,
            'invalidated_total' => 0.0,
            'reopened_total' => 0.0,
            'invalidated_targets' => [],
            'reopened_sources' => [],
        ];

        if ($target_unwind_budget > 0 && method_exists(Ledger::class, 'invalidate_recovery_targets_for_refunded_shipment')) {
            $target_ref = 'refund-target:' . $case_id;
            $target_unwind = Ledger::invalidate_recovery_targets_for_refunded_shipment(
                $target_ref,
                $shipment_id,
                $vendor_id,
                $target_unwind_budget,
                [
                    'case_id'            => $case_id,
                    'order_item_id'      => $order_item_id,
                    'slice_id'           => (string) ($preview['slice_id'] ?? ''),
                    'qty_requested'      => $effective_qty,
                    'chain_mode'         => (string) ($preview['chain_mode'] ?? ''),
                    'role_state_before'  => (string) ($preview['role_state_before'] ?? ''),
                    'role_state_after_reversal' => (string) ($post_reversal_chain['role_state'] ?? ''),
                    'return_bridge'      => array_merge($bridge_meta, [
                        'vendor_impact' => $remaining,
                    ]),
                    'trace_context'      => $trace_context,
                    'correlation_id'     => $trace_context['correlation_id'],
                ]
            );

            if (empty($target_unwind['success'])) {
                return [
                    'success' => false,
                    'error'   => (string) ($target_unwind['error'] ?? 'Refund could not invalidate the prior recovery role of the shipment safely.'),
                ];
            }

            if ((float) ($target_unwind['reopened_total'] ?? 0) > 0) {
                $txn_refs[] = $target_ref;
                self::record_bank_event('seller_offset_reopened_by_refund', $case, (float) $target_unwind['reopened_total'], 'Refund removed this shipment from recovery, reopened prior source debt, and prepared this shipment for source opening', [
                    'financial_mode'     => $reversed > 0 ? 'mixed' : 'debit',
                    'chain_mode'         => (string) ($preview['chain_mode'] ?? ''),
                    'role_state_before'  => (string) ($preview['role_state_before'] ?? ''),
                    'role_state_after_reversal' => (string) ($post_reversal_chain['role_state'] ?? ''),
                    'reopened_total'     => self::money((float) ($target_unwind['reopened_total'] ?? 0)),
                    'invalidated_total'  => self::money((float) ($target_unwind['invalidated_total'] ?? 0)),
                    'invalidated_targets'=> (array) ($target_unwind['invalidated_targets'] ?? []),
                    'reopened_sources'   => (array) ($target_unwind['reopened_sources'] ?? []),
                    'return_bridge'      => array_merge($bridge_meta, [
                        'vendor_impact' => $remaining,
                    ]),
                ]);
            }
        }

        if ($remaining > 0) {
            $debit_ref = 'refund-debit:' . $case_id;

            Ledger::create_vendor_debit_idempotent(
                $debit_ref,
                $vendor_id,
                $order_id,
                $shipment_id,
                $remaining,
                'Refund debit exposure',
                [
                    'case_id'                 => $case_id,
                    'order_item_id'           => $order_item_id,
                    'slice_id'                => (string) ($preview['slice_id'] ?? ''),
                    'financial_slices'        => [[
                        'slice_id' => (string) ($preview['slice_id'] ?? ''),
                        'order_item_id' => $order_item_id,
                        'product_id' => (int) ($case['product_id'] ?? 0),
                        'name' => (string) ($case['product_name'] ?? ''),
                        'qty' => $effective_qty,
                        'amount' => $remaining,
                    ]],
                    'chain_mode'              => (string) ($preview['chain_mode'] ?? ''),
                    'role_state_before'       => (string) ($preview['role_state_before'] ?? ''),
                    'role_state_after_reversal'=> (string) ($post_reversal_chain['role_state'] ?? ''),
                    'return_bridge'           => array_merge($bridge_meta, [
                        'vendor_impact' => $remaining,
                    ]),
                    'target_unwind_total'     => self::money((float) ($target_unwind['reopened_total'] ?? 0)),
                    'target_unwind_ref'       => 'refund-target:' . $case_id,
                    'existing_active_source_before' => self::money((float) ($preview['active_source_amount'] ?? 0)),
                    'active_target_before'    => self::money((float) ($preview['active_target_allocated_amount'] ?? 0)),
                ]
            );

            $txn_refs[] = $debit_ref;

            self::record_bank_event('seller_deduction_created', $case, $remaining, 'Refund opened seller source debt after chain-aware classification', [
                'financial_mode'    => $reversed > 0 ? 'mixed' : 'debit',
                'chain_mode'        => (string) ($preview['chain_mode'] ?? ''),
                'role_state_before' => (string) ($preview['role_state_before'] ?? ''),
                'return_bridge'     => array_merge($bridge_meta, [
                    'vendor_impact' => $remaining,
                ]),
                'target_unwind_total' => self::money((float) ($target_unwind['reopened_total'] ?? 0)),
            ]);
        }

        $final_chain = method_exists(Ledger::class, 'inspect_item_chain_state')
            ? Ledger::inspect_item_chain_state($shipment_id, $vendor_id, $order_item_id, (float) $effective_qty, $order_id)
            : [
                'role_state' => $remaining > 0 ? 'SOURCE' : 'RESOLVED',
                'active_source_amount' => $remaining,
            ];

        self::record_bank_event('customer_refund_issued', $case, $refund_amount, 'Customer refund committed from bank refund flow', [
            'financial_mode'       => $remaining > 0 ? ($reversed > 0 ? 'mixed' : 'debit') : 'reversal',
            'mode'                 => $remaining > 0 ? ($reversed > 0 ? 'mixed' : 'debit') : 'reversal',
            'refund_component'     => 'item',
            'item_refund_posting_key' => $unique_key,
            'item_component_amount' => $refund_amount,
            'shipping_component_amount' => 0.0,
            'customer_total_refund' => $refund_amount,
            'chain_mode'           => (string) ($preview['chain_mode'] ?? ''),
            'role_state_before'    => (string) ($preview['role_state_before'] ?? ''),
            'role_state_after'     => (string) ($final_chain['role_state'] ?? ''),
            'reversed_amount'      => $reversed,
            'debit_amount'         => $remaining,
            'commission_reversal'  => $commission_reversal,
            'commission_absorbed'  => $commission_absorbed,
            'target_unwind_total'  => self::money((float) ($target_unwind['reopened_total'] ?? 0)),
            'invalidated_targets'  => (array) ($target_unwind['invalidated_targets'] ?? []),
            'reopened_sources'     => (array) ($target_unwind['reopened_sources'] ?? []),
            'source_open_amount'   => $remaining,
        ]);

        $financial_status = $remaining > 0 ? 'debit_posted' : 'reversal_posted';
        if ($reversed <= 0 && $remaining <= 0) {
            $financial_status = 'completed';
        }

        if (class_exists(__NAMESPACE__ . '\BankRefundCases')) {
            $existing_shipping_refund = self::posted_shipping_component_for_case($case);
            $cumulative_customer_total = self::money(max(
                (float) ($case['customer_total_refund'] ?? 0),
                $refund_amount + $existing_shipping_refund
            ));

            BankRefundCases::update_case($case_id, [
                'refund_amount_requested' => $refund_amount,
                'refund_amount_approved'  => $refund_amount,
                'item_refund_amount_customer' => $refund_amount,
                'outbound_shipping_refund_amount_customer' => $existing_shipping_refund,
                'customer_total_refund' => $cumulative_customer_total,
                'item_refund_posting_key' => $unique_key,
                'qty_refundable'          => $effective_qty,
            ]);

            BankRefundCases::mark_financial_state(
                $case_id,
                $financial_status,
                [
                    'financial_txn_ref'      => implode(',', array_filter($txn_refs)),
                    'refund_amount_approved' => $refund_amount,
                ]
            );
        }

        return [
            'success'               => true,
            'mode'                  => $remaining > 0 ? ($reversed > 0 ? 'mixed' : 'debit') : 'reversal',
            'financial_status'      => $financial_status,
            'item_refund_posting_key' => $unique_key,
            'financial_txn_ref'     => implode(',', array_filter($txn_refs)),
            'chain_mode'            => (string) ($preview['chain_mode'] ?? ''),
            'amount'                => $refund_amount,
            'reversed_amount'       => $reversed,
            'commission_absorbed'   => $commission_absorbed,
            'debit_amount'          => $remaining,
            'source_open_amount'    => $remaining,
            'target_unwind_total'   => self::money((float) ($target_unwind['reopened_total'] ?? 0)),
            'invalidated_targets'   => (array) ($target_unwind['invalidated_targets'] ?? []),
            'reopened_sources'      => (array) ($target_unwind['reopened_sources'] ?? []),
            'role_state_before'     => (string) ($preview['role_state_before'] ?? ''),
            'role_state_after'      => (string) ($final_chain['role_state'] ?? ''),
        ];
    }

    public static function commit_refund_universe(array $case, array $overrides = []): array
    {
        $case_id = self::normalize_case_id($case);
        $case_status = sanitize_key((string) ($case['status'] ?? ''));
        $case_financial_status = sanitize_key((string) ($case['financial_status'] ?? ''));
        $item_posted = trim((string) ($case['item_refund_posting_key'] ?? '')) !== '' || $case_status === 'refunded' || in_array($case_financial_status, ['refund_posted', 'reversal_posted', 'debit_posted', 'completed'], true);
        $shipping_posted = trim((string) ($case['shipping_refund_posting_key'] ?? $case['shipping_liability_posting_key'] ?? $case['shipping_posting_key'] ?? '')) !== '' || in_array($case_financial_status, ['shipping_posted', 'refund_posted', 'reversal_posted', 'debit_posted', 'completed'], true);
        if ($item_posted && $shipping_posted) {
            return [
                'success' => true,
                'already_processed' => true,
                'mode' => 'already_processed',
                'amount' => self::money((float) ($case['customer_total_refund'] ?? 0)),
                'item_refund_amount_customer' => self::money((float) ($case['item_refund_amount_customer'] ?? 0)),
                'outbound_shipping_refund_amount_customer' => self::money((float) ($case['outbound_shipping_refund_amount_customer'] ?? 0)),
                'customer_total_refund' => self::money((float) ($case['customer_total_refund'] ?? 0)),
            ];
        }
        $preview = self::preview_refund($case, $overrides);
        $item_refund_amount = self::money((float) ($preview['item_refund_amount_customer'] ?? $preview['refund_amount'] ?? 0));
        $shipping_refund_amount = self::money((float) ($preview['outbound_shipping_refund_amount_customer'] ?? 0));
        $customer_total_refund = self::money((float) ($preview['customer_total_refund'] ?? ($item_refund_amount + $shipping_refund_amount)));
       $shipping_liability_party        = (string) ($preview['shipping_liability_party'] ?? '');
        $shipping_liability_amount_internal = self::money((float) ($preview['shipping_liability_amount_internal'] ?? 0));
        $seller_debit_exposure_amount    = self::money((float) ($preview['seller_debit_exposure_amount'] ?? 0));
        $item_exposure_amount            = self::money((float) ($preview['item_exposure_amount'] ?? $seller_debit_exposure_amount));
        $shipping_exposure_amount        = self::money((float) ($preview['shipping_exposure_amount'] ?? 0));
        $commission_gap_amount           = self::money((float) ($preview['commission_gap_amount'] ?? 0));
       $courier_liability_item_amount   = self::money((float) ($preview['courier_liability_item_amount'] ?? 0));
        $courier_liability_shipping_amount = self::money((float) ($preview['courier_liability_shipping_amount'] ?? 0));
        $courier_liability_total_amount  = self::money((float) ($preview['courier_liability_total_amount'] ?? $courier_liability_shipping_amount));
        $return_shipping_cost_internal   = self::money((float) ($preview['return_shipping_cost_internal'] ?? 0));

        $resolved_fault_party = sanitize_key((string) ($preview['resolved_fault_party'] ?? $case['resolved_fault_party'] ?? ''));
        $carrier_fault_case = in_array($resolved_fault_party, ['carrier', 'courier', 'shipping', 'logistics'], true)
            || $shipping_liability_party === 'carrier'
            || $courier_liability_total_amount > 0;

        /*
         * HARD GUARD:
         * If this case resolved as unpaid reversal only, commission gap must not become seller debt.
         */
        if ((string) ($preview['chain_mode'] ?? '') === 'unpaid_reversal_only') {
            $seller_debit_exposure_amount = self::money($shipping_exposure_amount);
        }

        if ($customer_total_refund <= 0) {
            return [
                'success' => false,
                'error'   => 'Customer refund amount resolved to zero.',
            ];
        }

        $item_result = [
            'success' => true,
            'mode' => 'shipping_only',
            'amount' => 0.0,
            'reversed_amount' => 0.0,
            'commission_absorbed' => 0.0,
            'debit_amount' => 0.0,
            'source_open_amount' => 0.0,
            'target_unwind_total' => 0.0,
            'invalidated_targets' => [],
            'reopened_sources' => [],
            'role_state_before' => '',
            'role_state_after' => '',
        ];

       if ($item_refund_amount > 0 && !$carrier_fault_case) {
            $item_overrides = $overrides;
            $item_overrides['refund_amount_requested'] = $item_refund_amount;
            $item_overrides['refund_amount_approved']  = $item_refund_amount;
            $item_overrides['item_refund_amount_customer'] = $item_refund_amount;
            $item_overrides['outbound_shipping_refund_amount_customer'] = 0.0;
            $item_overrides['shipping_refund_selected'] = 0;
            $item_result = self::commit_refund($case, $item_overrides);
            if (empty($item_result['success'])) {
                return $item_result;
            }
        } elseif ($item_refund_amount > 0 && $carrier_fault_case) {
            $item_result = [
                'success' => true,
                'mode' => 'platform_fronted',
                'amount' => $item_refund_amount,
                'reversed_amount' => 0.0,
                'commission_absorbed' => 0.0,
                'debit_amount' => 0.0,
                'source_open_amount' => 0.0,
                'target_unwind_total' => 0.0,
                'invalidated_targets' => [],
                'reopened_sources' => [],
                'role_state_before' => '',
                'role_state_after' => '',
            ];

            self::record_bank_event('customer_refund_issued', $case, $item_refund_amount, 'Customer item refund fronted for courier-liable case', [
                'refund_component' => 'item',
                'mode' => 'platform_fronted',
                'item_component_amount' => $item_refund_amount,
                'shipping_component_amount' => 0.0,
                'customer_total_refund' => $customer_total_refund,
                'resolved_fault_party' => 'carrier',
            ]);
        }

        $shipping_refund_posting_key = $shipping_refund_amount > 0
            ? self::shipping_posting_key($case, $shipping_liability_party !== '' ? $shipping_liability_party : 'platform', 'shipping_refund_outbound')
            : '';
        $shipping_liability_posting_key = '';
        $shipping_posting_key = '';
        $shipping_visibility_status = '';
        $shipping_posting_status = '';
        $shipping_refs = [];

        if ($shipping_refund_amount > 0) {
            self::record_bank_event('customer_refund_issued', $case, $shipping_refund_amount, 'Customer shipping refund committed from bank refund flow', [
                'refund_component' => 'shipping',
                'mode' => 'shipping_only',
                'item_component_amount' => $item_refund_amount,
                'shipping_component_amount' => $shipping_refund_amount,
                'customer_total_refund' => $customer_total_refund,
                'shipping_liability_party' => $shipping_liability_party,
                'refund_execution_mode' => (string) ($preview['refund_execution_mode'] ?? ''),
                'shipping_refund_posting_key' => $shipping_refund_posting_key,
                'shipping_posting_key' => $shipping_refund_posting_key,
            ]);
            self::claim_shipping_bucket($case, $shipping_refund_amount, $shipping_refund_posting_key);
        }

        if ($shipping_liability_amount_internal > 0 && $shipping_liability_party === 'seller') {
            $shipping_liability_posting_key = self::shipping_posting_key($case, 'seller', 'shipping_liability_seller');
            $shipping_posting_key = $shipping_liability_posting_key;
            Ledger::create_vendor_debit_idempotent(
                $shipping_liability_posting_key,
                (int) ($case['vendor_id'] ?? 0),
                (int) ($case['order_id'] ?? 0),
                (int) ($case['shipment_id'] ?? 0),
                $shipping_liability_amount_internal,
                'Shipping fee charge — refund case',
                [
                   'case_id' => $case_id,
                    'order_item_id' => (int) ($case['order_item_id'] ?? 0),
                    'shipping_liability' => 1,
                    'shipping_scope' => 'order',
                    'shipping_liability_party' => 'seller',
                    'shipping_liability_posting_key' => $shipping_liability_posting_key,
                    'shipping_posting_key' => $shipping_liability_posting_key,
                    'shipping_liability_amount' => $shipping_liability_amount_internal,
                    'commission_reversed_override' => 0.0,
                    'trace_context' => self::build_trace_context($case, $overrides),
                    'trace_operation' => 'shipping_liability_debit',
                    'return_bridge' => [
                        'case_id' => $case_id,
                        'kind' => 'shipping',
                        'is_shipping_component' => 1,
                        'item_id' => 0,
                        'product_id' => 0,
                        'item_name' => 'Shipping fee charge',
                        'qty_refundable' => 0,
                        'unit_price_net' => $shipping_liability_amount_internal,
                        'item_price_net' => $shipping_liability_amount_internal,
                        'original_net' => $shipping_liability_amount_internal,
                        'seller_impact' => $shipping_liability_amount_internal,
                        'vendor_impact' => $shipping_liability_amount_internal,
                        'customer_refund' => $shipping_refund_amount,
                        'commission_reversal' => 0.0,
                        'currency' => (string) ($case['currency'] ?? get_woocommerce_currency()),
                        'source_shipment_id' => (int) ($case['shipment_id'] ?? 0),
                    ],
                ]
            );
            $shipping_posting_status = 'posted';
            $shipping_visibility_status = 'visible';
            $shipping_refs[] = $shipping_posting_key;

            self::record_bank_event('return_shipping_charge', $case, $shipping_liability_amount_internal, 'Shipping fee charged to seller after refund fault resolution', [
                'refund_component' => 'shipping',
                'shipping_liability_party' => 'seller',
                'shipping_liability_posting_key' => $shipping_liability_posting_key,
                'shipping_posting_key' => $shipping_liability_posting_key,
                'customer_total_refund' => $customer_total_refund,
            ]);
        } elseif ($courier_liability_total_amount > 0 && $carrier_fault_case) {
            $persisted = self::upsert_courier_shipping_liability($case, $preview);
            $shipping_liability_posting_key = (string) ($persisted['shipping_liability_posting_key'] ?? ($persisted['shipping_posting_key'] ?? ''));
            $shipping_posting_key = $shipping_liability_posting_key;
            $shipping_posting_status = $shipping_liability_posting_key !== '' ? 'posted' : '';
            $shipping_visibility_status = $shipping_liability_posting_key !== '' ? 'visible' : '';
            $shipping_refs[] = (string) ($persisted['fronted_case_id'] ?? '');
            $shipping_refs[] = (string) ($persisted['recovery_case_id'] ?? '');

            self::record_bank_event('return_shipping_charge', $case, $shipping_liability_amount_internal, 'Shipping fee charged to courier after refund fault resolution', [
                'refund_component' => 'shipping',
'shipping_scope' => 'order',
                'shipping_liability_party' => 'carrier',                'shipping_liability_posting_key' => $shipping_liability_posting_key,
                'shipping_posting_key' => $shipping_liability_posting_key,
                'courier_id' => self::courier_id_for_case($case),
                'customer_total_refund' => $customer_total_refund,
            ]);
        }

        $seller_debit_exposure_posting_key = '';
        $seller_debit_exposure_status = '';
        $seller_debit_exposure_refs = [];
        
        
        
        
        if (
            (string) ($preview['chain_mode'] ?? '') === 'unpaid_reversal_only'
            && $item_exposure_amount <= 0
            && $commission_gap_amount > 0
        ) {
            $seller_debit_exposure_amount = 0.0;
        }

        /*
         * commit_refund() already opens the canonical item-side refund debt via refund-debit.
         * Never create a second seller-debit-exposure for that same item amount.
         */
        $opened_item_side_debt_amount = self::money((float) ($item_result['debit_amount'] ?? 0));
        $seller_debit_exposure_amount = self::money(max(0.0, $seller_debit_exposure_amount - $opened_item_side_debt_amount));

       if ($seller_debit_exposure_amount > 0) {
            $seller_debit_exposure_posting_key = 'seller-debit-exposure:' . $case_id;
            Ledger::create_vendor_debit_idempotent(
                $seller_debit_exposure_posting_key,
                (int) ($case['vendor_id'] ?? 0),
                (int) ($case['order_id'] ?? 0),
                (int) ($case['shipment_id'] ?? 0),
                $seller_debit_exposure_amount,
                'Seller Debit Exposure',
                [
                    'case_id' => $case_id,
                    'order_item_id' => (int) ($case['order_item_id'] ?? 0),
                    'seller_debit_exposure' => 1,
                    'debit_component' => 'seller_debit_exposure',
                    'commission_reversed_override' => 0.0,
                    'trace_context' => self::build_trace_context($case, $overrides),
                    'trace_operation' => 'seller_debit_exposure',
                    'return_bridge' => [
                        'case_id' => $case_id,
                        'kind' => 'seller_debit_exposure',
                        'is_seller_debit_exposure' => 1,
                        'item_id' => 0,
                        'product_id' => 0,
                        'item_name' => 'Seller Debit Exposure',
                        'qty_refundable' => 0,
                        'unit_price_net' => $seller_debit_exposure_amount,
                        'item_price_net' => $seller_debit_exposure_amount,
                        'original_net' => $seller_debit_exposure_amount,
                        'seller_impact' => $seller_debit_exposure_amount,
                        'vendor_impact' => $seller_debit_exposure_amount,
                        'customer_refund' => $seller_debit_exposure_amount,
                        'commission_reversal' => 0.0,
                        'commission_gap_amount' => $commission_gap_amount,
                        'item_exposure_amount' => $item_exposure_amount,
                        'shipping_exposure_amount' => $shipping_exposure_amount,
                        'currency' => (string) ($case['currency'] ?? get_woocommerce_currency()),
                        'source_shipment_id' => (int) ($case['shipment_id'] ?? 0),
                    ],
                ]
            );
            $seller_debit_exposure_status = 'posted';
            $seller_debit_exposure_refs[] = $seller_debit_exposure_posting_key;

            self::record_bank_event('seller_deduction_created', $case, $seller_debit_exposure_amount, 'Seller Debit Exposure posted for refund top-up after seller-fault routing', [
                'refund_component' => 'seller_debit_exposure',
                'seller_debit_exposure' => 1,
                'seller_debit_exposure_posting_key' => $seller_debit_exposure_posting_key,
                'customer_total_refund' => $customer_total_refund,
                'shipping_liability_party' => $shipping_liability_party,
            ]);
        }

        if (class_exists(__NAMESPACE__ . '\BankRefundCases')) {
            $shipping_bucket = self::read_shipping_bucket($case);
            $existing_item_refund = self::posted_item_component_for_case($case);
            $existing_shipping_refund = self::posted_shipping_component_for_case($case, $shipping_bucket);
            $cumulative_item_refund = self::money(max($existing_item_refund, $item_refund_amount));
            $cumulative_shipping_refund = self::money(max($existing_shipping_refund, $shipping_refund_amount));
            $cumulative_customer_total = self::money(max(
                (float) ($case['customer_total_refund'] ?? 0),
                $cumulative_item_refund + $cumulative_shipping_refund
            ));
            $cumulative_shipping_liability_internal = self::money(max(
                (float) ($case['shipping_liability_amount_internal'] ?? 0),
                $shipping_liability_amount_internal
            ));
            $cumulative_courier_item_liability = self::money(max(
                (float) ($case['courier_liability_item_amount'] ?? 0),
                $courier_liability_item_amount
            ));
            $cumulative_courier_shipping_liability = self::money(max(
                (float) ($case['courier_liability_shipping_amount'] ?? 0),
                $courier_liability_shipping_amount
            ));
            $cumulative_courier_total_liability = self::money(max(
                (float) ($case['courier_liability_total_amount'] ?? 0),
                $cumulative_courier_item_liability + $cumulative_courier_shipping_liability
            ));
            $persisted_item_posting_key = $item_refund_amount > 0 ? self::item_refund_posting_key($case) : (string) ($case['item_refund_posting_key'] ?? '');

            BankRefundCases::update_case($case_id, [
                'item_refund_amount_customer' => $cumulative_item_refund,
                'outbound_shipping_refund_amount_customer' => $cumulative_shipping_refund,
                'customer_total_refund' => $cumulative_customer_total,
                'return_shipping_cost_internal' => max((float) ($case['return_shipping_cost_internal'] ?? 0), $return_shipping_cost_internal),
                'shipping_liability_amount_internal' => $cumulative_shipping_liability_internal,
                'shipping_liability_party' => $shipping_liability_party !== '' ? $shipping_liability_party : (string) ($case['shipping_liability_party'] ?? ''),
                'shipping_refund_selected' => $cumulative_shipping_refund > 0 ? 1 : 0,
                'shipping_posting_status' => $shipping_posting_status !== '' ? $shipping_posting_status : (string) ($case['shipping_posting_status'] ?? ''),
                'shipping_visibility_status' => $shipping_visibility_status !== '' ? $shipping_visibility_status : (string) ($case['shipping_visibility_status'] ?? ''),
                'item_refund_posting_key' => $persisted_item_posting_key,
                'shipping_refund_posting_key' => $shipping_refund_posting_key !== '' ? $shipping_refund_posting_key : (string) ($case['shipping_refund_posting_key'] ?? ''),
                'shipping_liability_posting_key' => $shipping_liability_posting_key !== '' ? $shipping_liability_posting_key : (string) ($case['shipping_liability_posting_key'] ?? ''),
                'shipping_posting_key' => $shipping_liability_posting_key !== '' ? $shipping_liability_posting_key : ($shipping_refund_posting_key !== '' ? $shipping_refund_posting_key : (string) ($case['shipping_posting_key'] ?? '')),
                'seller_debit_exposure_amount' => $seller_debit_exposure_amount,
                'seller_debit_exposure_status' => $seller_debit_exposure_status,
                'seller_debit_exposure_posting_key' => $seller_debit_exposure_posting_key,
                'courier_liability_item_amount' => $cumulative_courier_item_liability,
                'courier_liability_shipping_amount' => $cumulative_courier_shipping_liability,
                'courier_liability_total_amount' => $cumulative_courier_total_liability,
                'order_shipping_refund_bucket' => $shipping_bucket,
                'qty_refundable' => (int) ($preview['qty_refundable'] ?? 0),
                'item_received_flag' => !empty($preview['item_received_flag']) ? 1 : 0,
                'refund_execution_mode' => (string) ($preview['refund_execution_mode'] ?? ''),
            ]);

           $is_pre_return_shipping_only = (
    $item_refund_amount <= 0
    && (string) ($preview['refund_execution_mode'] ?? '') === 'return_required'
    && $shipping_refund_amount > 0
    && $shipping_liability_amount_internal > 0
);

           if ($is_pre_return_shipping_only) {
                BankRefundCases::mark_financial_state($case_id, 'shipping_posted', [
                    'financial_txn_ref' => implode(',', array_filter($shipping_refs)),
                    'customer_total_refund' => $customer_total_refund,
                ]);
            } elseif ($carrier_fault_case) {
                BankRefundCases::mark_financial_state($case_id, 'completed', [
                    'financial_txn_ref' => implode(',', array_filter(array_merge($shipping_refs, $seller_debit_exposure_refs))),
                    'customer_total_refund' => $customer_total_refund,
                ]);
            } elseif ($item_refund_amount <= 0) {
                BankRefundCases::mark_financial_state($case_id, 'completed', [
                    'financial_txn_ref' => implode(',', array_filter(array_merge($shipping_refs, $seller_debit_exposure_refs))),
                    'customer_total_refund' => $customer_total_refund,
                ]);
            }
        }

        return [
            'success' => true,
           'mode'    => $carrier_fault_case ? 'platform_fronted' : ($item_refund_amount > 0 ? (string) ($item_result['mode'] ?? 'mixed') : 'shipping_only'),
            'financial_status' => (string) ($item_result['financial_status'] ?? ($item_refund_amount > 0 ? 'refund_posted' : 'completed')),
            'item_refund_posting_key' => (string) ($item_result['item_refund_posting_key'] ?? self::item_refund_posting_key($case)),
            'financial_txn_ref' => (string) ($item_result['financial_txn_ref'] ?? ''),
            'amount'  => $customer_total_refund,
            'item_refund_amount_customer' => $item_refund_amount,
            'outbound_shipping_refund_amount_customer' => $shipping_refund_amount,
            'customer_total_refund' => $customer_total_refund,
            'shipping_liability_party' => $shipping_liability_party,
            'shipping_liability_amount_internal' => $shipping_liability_amount_internal,
            'shipping_refund_posting_key' => $shipping_refund_posting_key,
            'shipping_liability_posting_key' => $shipping_liability_posting_key,
            'shipping_posting_key' => $shipping_liability_posting_key !== '' ? $shipping_liability_posting_key : $shipping_refund_posting_key,
            'seller_debit_exposure_amount' => $seller_debit_exposure_amount,
            'seller_debit_exposure_posting_key' => $seller_debit_exposure_posting_key,
            'courier_liability_item_amount' => $courier_liability_item_amount,
            'courier_liability_shipping_amount' => $courier_liability_shipping_amount,
            'courier_liability_total_amount' => $courier_liability_total_amount,
            'reversed_amount' => (float) ($item_result['reversed_amount'] ?? 0),
            'commission_absorbed' => (float) ($item_result['commission_absorbed'] ?? 0),
            'debit_amount' => (float) ($item_result['debit_amount'] ?? 0),
            'source_open_amount' => (float) ($item_result['source_open_amount'] ?? 0),
            'target_unwind_total' => (float) ($item_result['target_unwind_total'] ?? 0),
            'invalidated_targets' => (array) ($item_result['invalidated_targets'] ?? []),
            'reopened_sources' => (array) ($item_result['reopened_sources'] ?? []),
            'role_state_before' => (string) ($item_result['role_state_before'] ?? ''),
            'role_state_after' => (string) ($item_result['role_state_after'] ?? ''),
        ];
    }

    public static function rollback_financials_for_case(array $case): array
    {
        $case_id     = self::normalize_case_id($case);
        $trace_context = self::build_trace_context($case);
        $case['correlation_id'] = $trace_context['correlation_id'];
        $case['trace_context'] = $trace_context;
        $shipment_id = (int) ($case['shipment_id'] ?? 0);
        $vendor_id   = (int) ($case['vendor_id'] ?? 0);

        if ($case_id === '' || $shipment_id <= 0 || $vendor_id <= 0) {
            return [
                'success' => false,
                'error'   => 'Invalid refund rollback case context.',
            ];
        }

        if (!method_exists(Ledger::class, 'rollback_refund_case_financials')) {
            return [
                'success' => false,
                'error'   => 'Ledger rollback support is unavailable.',
            ];
        }

        $rolled = Ledger::rollback_refund_case_financials($case_id, $shipment_id, $vendor_id);
        if (empty($rolled['success'])) {
            return [
                'success' => false,
                'error'   => (string) ($rolled['error'] ?? 'Refund rollback failed.'),
            ];
        }

        $restored_reversal = self::money((float) ($rolled['reversal_restored_amount'] ?? 0));
        $rolled_debit      = self::money((float) ($rolled['debit_rolled_back_amount'] ?? 0));
        $restored_total    = self::money($restored_reversal + $rolled_debit);

        if ($restored_total > 0) {
            self::release_shipping_bucket($case);
            self::record_bank_event('refund_financial_rollback', $case, $restored_total, 'Refund case rollback restored seller balances, neutralized seller debit exposure, and reclosed any reopened chain debt safely', [
                'reversal_restored_amount' => $restored_reversal,
                'debit_rolled_back_amount' => $rolled_debit,
                'financial_txn_ref'        => (string) ($rolled['financial_txn_ref'] ?? ''),
                'restored_target_rows'     => (array) ($rolled['restored_target_rows'] ?? []),
                'reversal_rows'            => (array) ($rolled['reversal_rows'] ?? []),
                'restored_refund_targets'  => (array) ($rolled['restored_refund_targets'] ?? []),
                'reclosed_sources'         => (array) ($rolled['reclosed_sources'] ?? []),
            ]);
        }

        return [
            'success'                  => true,
            'financial_txn_ref'        => (string) ($rolled['financial_txn_ref'] ?? ''),
            'reversal_restored_amount' => $restored_reversal,
            'debit_rolled_back_amount' => $rolled_debit,
            'restored_refund_targets'  => (array) ($rolled['restored_refund_targets'] ?? []),
            'reclosed_sources'         => (array) ($rolled['reclosed_sources'] ?? []),
        ];
    }

    private static function build_return_bridge_meta(array $case, array $preview): array
    {
        $qty = self::resolve_effective_qty($case);
        $refund_amount = self::money((float) ($preview['refund_amount'] ?? 0));
        $seller_impact = self::money((float) ($preview['seller_impact'] ?? 0));
        $unit_price_net = self::money((float) ($preview['unit_price_net'] ?? ($qty > 0 ? ($seller_impact / $qty) : 0.0)));
        $chain_snapshot = isset($preview['chain_snapshot']) && is_array($preview['chain_snapshot']) ? $preview['chain_snapshot'] : [];

        return [
            'case_id'               => self::normalize_case_id($case),
            'slice_id'              => (string) ($preview['slice_id'] ?? ($chain_snapshot['slice_id'] ?? ('ship:' . (int) ($case['shipment_id'] ?? 0) . ':item:' . (int) ($case['order_item_id'] ?? 0)))),
            'item_id'               => (int) ($case['order_item_id'] ?? 0),
            'product_id'            => (int) ($case['product_id'] ?? 0),
            'item_name'             => (string) ($case['product_name'] ?? ''),
            'qty_refundable'        => $qty,
            'unit_price_net'        => $unit_price_net,
            'item_price_net'        => $seller_impact,
            'seller_impact'         => $seller_impact,
            'vendor_impact'         => $seller_impact,
            'customer_refund'       => $refund_amount,
            'commission_reversal'   => self::money((float) ($preview['commission_reversal'] ?? 0)),
            'currency'              => (string) ($case['currency'] ?? get_woocommerce_currency()),
        ];
    }

    private static function record_bank_event(string $event_type, array $case, float $amount, string $reason_label, array $meta = []): void
    {
        if (!class_exists(__NAMESPACE__ . '\BankLedger') || $amount <= 0) {
            return;
        }

        $case_id = self::normalize_case_id($case);
        $direction = 'debit';
        $payer_type = 'platform';
        $payer_id = 0;
        $payee_type = 'vendor';
        $payee_id = (int) ($case['vendor_id'] ?? 0);

        if ($event_type === 'customer_refund_issued') {
            $direction = 'debit';
            $payer_type = 'platform';
            $payer_id = 0;
            $payee_type = 'customer';
            $payee_id = (int) ($case['customer_id'] ?? 0);
        } elseif (in_array($event_type, ['reversal', 'seller_deduction_created', 'seller_offset_reopened_by_refund'], true)) {
            $direction = 'debit';
            $payer_type = 'vendor';
            $payer_id = (int) ($case['vendor_id'] ?? 0);
            $payee_type = 'platform';
            $payee_id = 0;
        } elseif ($event_type === 'return_shipping_charge') {
            $direction = 'debit';
            if (($meta['shipping_liability_party'] ?? '') === 'carrier') {
                $payer_type = 'courier';
                $payer_id = (int) ($meta['courier_id'] ?? self::courier_id_for_case($case));
                $payee_type = 'platform';
                $payee_id = 0;
            } else {
                $payer_type = 'vendor';
                $payer_id = (int) ($case['vendor_id'] ?? 0);
                $payee_type = 'platform';
                $payee_id = 0;
            }
        } elseif ($event_type === 'refund_financial_rollback') {
            $direction = 'credit';
            $payer_type = 'platform';
            $payer_id = 0;
            $payee_type = 'vendor';
            $payee_id = (int) ($case['vendor_id'] ?? 0);
        }

        $lineage_key = 'refund|' . $case_id;
        $trace_context = self::build_trace_context($case, $meta);
        $meta = self::with_trace_meta($meta, $trace_context, 'bank_event_record');
        if (!isset($meta['mode']) && isset($meta['financial_mode'])) {
            $meta['mode'] = (string) $meta['financial_mode'];
        }
        $canonical_suffix = sanitize_key((string) ($meta['refund_component'] ?? ''));
        $canonical_anchor = $case_id;
        foreach (['item_refund_posting_key', 'shipping_refund_posting_key', 'shipping_liability_posting_key', 'seller_debit_exposure_posting_key', 'shipping_posting_key'] as $anchor_key) {
            if (!empty($meta[$anchor_key])) {
                $canonical_anchor = (string) $meta[$anchor_key];
                break;
            }
        }
        $canonical_event_key = implode('|', array_filter([
            'refund',
            $canonical_anchor,
            $event_type,
            (int) ($case['shipment_id'] ?? 0),
            number_format(self::money($amount), 2, '.', ''),
            $canonical_suffix,
        ], static function ($v) {
            return (string) $v !== '';
        }));

        $meta['canonical_event_key'] = $canonical_event_key;
        $meta['lineage_key'] = $lineage_key;
        $meta['case_id'] = $case_id;

        BankLedger::record([
            'event_type'          => $event_type,
            'event_status'        => 'posted',
            'canonical_event_key' => $canonical_event_key,
            'lineage_key'         => $lineage_key,
            'order_id'            => (int) ($case['order_id'] ?? 0),
            'shipment_id'         => (int) ($case['shipment_id'] ?? 0),
            'return_case_id'      => $case_id,
            'vendor_id'           => (int) ($case['vendor_id'] ?? 0),
            'courier_id'          => (int) ($meta['courier_id'] ?? self::courier_id_for_case($case)),
            'customer_id'         => (int) ($case['customer_id'] ?? 0),
            'woo_refund_id'       => (int) ($case['refund_id'] ?? 0),
            'currency'            => (string) ($case['currency'] ?? get_woocommerce_currency()),
            'amount'              => self::money($amount),
            'direction'           => $direction,
            'payer_type'          => $payer_type,
            'payer_id'            => $payer_id,
            'payee_type'          => $payee_type,
            'payee_id'            => $payee_id,
            'reason_code'         => sanitize_key($event_type),
            'reason_label'        => $reason_label,
            'source_system'       => 'bank_refunds',
            'source_ref'          => 'bank_refund:' . $case_id . ':' . sanitize_key($event_type),
            'meta_json'           => $meta,
        ]);
    }
}
