<?php
namespace Caricove\Bank;
if (!defined('ABSPATH')) exit;

final class BankLedger {
    private static ?array $table_columns_cache = null;

    public static function table(): string {
        global $wpdb;
        return $wpdb->prefix . 'caricove_bank_events';
    }

    public static function install(): void {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $table = self::table();
        $charset = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE {$table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            event_uuid CHAR(36) NOT NULL,
            event_type VARCHAR(64) NOT NULL,
            event_status VARCHAR(20) NOT NULL DEFAULT 'posted',
            canonical_event_key VARCHAR(191) NOT NULL DEFAULT '',
            lineage_key VARCHAR(191) NOT NULL DEFAULT '',
            supersedes_event_uuid CHAR(36) NOT NULL DEFAULT '',
            superseded_by_event_uuid CHAR(36) NOT NULL DEFAULT '',
            order_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            shipment_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            return_case_id VARCHAR(120) NOT NULL DEFAULT '',
            vendor_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            courier_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            customer_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            woo_refund_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            currency VARCHAR(10) NOT NULL DEFAULT 'GYD',
            amount DECIMAL(20,2) NOT NULL DEFAULT 0.00,
            direction VARCHAR(10) NOT NULL DEFAULT 'credit',
            payer_type VARCHAR(20) NOT NULL DEFAULT '',
            payer_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            payee_type VARCHAR(20) NOT NULL DEFAULT '',
            payee_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            reason_code VARCHAR(64) NOT NULL DEFAULT '',
            reason_label VARCHAR(190) NOT NULL DEFAULT '',
            source_system VARCHAR(64) NOT NULL DEFAULT '',
            source_ref VARCHAR(190) NOT NULL DEFAULT '',
            notes TEXT NULL,
            meta_json LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            effective_at DATETIME NOT NULL,
            created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
            PRIMARY KEY  (id),
            UNIQUE KEY event_uuid (event_uuid),
            KEY event_type (event_type),
            KEY event_status (event_status),
            KEY canonical_event_key (canonical_event_key),
            KEY lineage_key (lineage_key),
            KEY supersedes_event_uuid (supersedes_event_uuid),
            KEY superseded_by_event_uuid (superseded_by_event_uuid),
            KEY shipment_id (shipment_id),
            KEY order_id (order_id),
            KEY vendor_id (vendor_id),
            KEY courier_id (courier_id),
            KEY customer_id (customer_id),
            KEY return_case_id (return_case_id),
            KEY created_at (created_at)
        ) {$charset};";
        dbDelta($sql);
        self::$table_columns_cache = null;
    }

    private static function normalize_string($value): string {
        if (is_bool($value)) {
            return $value ? '1' : '0';
        }
        if ($value === null) {
            return '';
        }
        if (is_scalar($value)) {
            return trim((string) $value);
        }
        return trim(wp_json_encode($value));
    }

    private static function normalize_meta($value): array {
        if (is_array($value)) {
            return $value;
        }
        if (is_string($value) && trim($value) !== '') {
            $decoded = json_decode((string) $value, true);
            if (is_array($decoded)) {
                return $decoded;
            }
        }
        return [];
    }

    private static function table_columns(): array {
        if (self::$table_columns_cache !== null) {
            return self::$table_columns_cache;
        }

        global $wpdb;
        $table = self::table();
        $rows = $wpdb->get_results("SHOW COLUMNS FROM {$table}", ARRAY_A);
        $columns = [];
        foreach ((array) $rows as $row) {
            $field = (string) ($row['Field'] ?? '');
            if ($field !== '') {
                $columns[$field] = true;
            }
        }
        self::$table_columns_cache = $columns;
        return $columns;
    }

    private static function supports_column(string $column): bool {
        $columns = self::table_columns();
        return !empty($columns[$column]);
    }

    private static function supported_payload(array $event): array {
        $supported = [];
        foreach ($event as $column => $value) {
            if (self::supports_column((string) $column)) {
                $supported[$column] = $value;
            }
        }
        return $supported;
    }

    private static function derive_canonical_event_key(array $event, array $meta = []): string {
        if (!empty($event['canonical_event_key'])) {
            return self::normalize_string($event['canonical_event_key']);
        }
        if (!empty($meta['canonical_event_key'])) {
            return self::normalize_string($meta['canonical_event_key']);
        }

        $parts = [
            self::normalize_string($event['event_type'] ?? ''),
            self::normalize_string($event['source_system'] ?? ''),
            self::normalize_string($event['source_ref'] ?? ''),
            (int) ($event['order_id'] ?? 0),
            (int) ($event['shipment_id'] ?? 0),
            (int) ($event['vendor_id'] ?? 0),
            self::normalize_string($event['return_case_id'] ?? ''),
            self::normalize_string($event['direction'] ?? ''),
            number_format((float) ($event['amount'] ?? 0), 4, '.', ''),
            self::normalize_string($event['reason_code'] ?? ''),
        ];

        return implode('|', $parts);
    }

    private static function derive_lineage_key(array $event, array $meta = []): string {
        if (!empty($event['lineage_key'])) {
            return self::normalize_string($event['lineage_key']);
        }
        if (!empty($meta['lineage_key'])) {
            return self::normalize_string($meta['lineage_key']);
        }

        $return_case_id = self::normalize_string($event['return_case_id'] ?? '');
        if ($return_case_id !== '') {
            return 'return_case|' . $return_case_id;
        }

        $shipment_id = (int) ($event['shipment_id'] ?? 0);
        $event_type = self::normalize_string($event['event_type'] ?? '');
        if ($shipment_id > 0 && $event_type !== '') {
            return 'shipment|' . $shipment_id . '|' . $event_type;
        }

        return self::derive_canonical_event_key($event, $meta);
    }

    private static function derive_idempotency_key(array $event, array $meta = []): string {
        if (!empty($event['idempotency_key'])) {
            return self::normalize_string($event['idempotency_key']);
        }
        if (!empty($meta['idempotency_key'])) {
            return self::normalize_string($meta['idempotency_key']);
        }

        return self::derive_canonical_event_key($event, $meta);
    }

    private static function find_existing_by_canonical_event_key(string $canonical_event_key): int {
        global $wpdb;

        $canonical_event_key = self::normalize_string($canonical_event_key);
        if ($canonical_event_key === '' || !self::supports_column('canonical_event_key')) {
            return 0;
        }

        return (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT id
                 FROM " . self::table() . "
                 WHERE canonical_event_key = %s
                 LIMIT 1",
                $canonical_event_key
            )
        );
    }

    private static function find_existing_idempotent_event_id(array $event, array $meta = []): int {
        global $wpdb;

        $canonical_event_key = self::derive_canonical_event_key($event, $meta);
        $existing = self::find_existing_by_canonical_event_key($canonical_event_key);
        if ($existing > 0) {
            return $existing;
        }

        $source_system = self::normalize_string($event['source_system'] ?? '');
        $source_ref    = self::normalize_string($event['source_ref'] ?? '');
        if ($source_system === '' || $source_ref === '') {
            return 0;
        }

        return (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT id
                 FROM " . self::table() . "
                 WHERE event_type = %s
                   AND source_system = %s
                   AND source_ref = %s
                   AND order_id = %d
                   AND shipment_id = %d
                   AND vendor_id = %d
                   AND return_case_id = %s
                   AND direction = %s
                   AND amount = %s
                 LIMIT 1",
                (string) ($event['event_type'] ?? ''),
                $source_system,
                $source_ref,
                (int) ($event['order_id'] ?? 0),
                (int) ($event['shipment_id'] ?? 0),
                (int) ($event['vendor_id'] ?? 0),
                (string) ($event['return_case_id'] ?? ''),
                (string) ($event['direction'] ?? ''),
                number_format((float) ($event['amount'] ?? 0), 4, '.', '')
            )
        );
    }

    private static function mark_superseded(string $supersedes_event_uuid, string $replacement_event_uuid): void {
        global $wpdb;

        $supersedes_event_uuid = self::normalize_string($supersedes_event_uuid);
        $replacement_event_uuid = self::normalize_string($replacement_event_uuid);
        if ($supersedes_event_uuid === '' || $replacement_event_uuid === '') {
            return;
        }

        $updates = [];
        if (self::supports_column('superseded_by_event_uuid')) {
            $updates['superseded_by_event_uuid'] = $replacement_event_uuid;
        }
        if (!$updates) {
            return;
        }

        $wpdb->update(
            self::table(),
            $updates,
            ['event_uuid' => $supersedes_event_uuid]
        );
    }

    public static function record(array $event): int {
        global $wpdb;
        $table = self::table();
        $defaults = [
            'event_uuid'              => wp_generate_uuid4(),
            'event_type'              => '',
            'event_status'            => 'posted',
            'canonical_event_key'     => '',
            'lineage_key'             => '',
            'supersedes_event_uuid'   => '',
            'superseded_by_event_uuid'=> '',
            'order_id'                => 0,
            'shipment_id'             => 0,
            'return_case_id'          => '',
            'vendor_id'               => 0,
            'courier_id'              => 0,
            'customer_id'             => 0,
            'woo_refund_id'           => 0,
            'currency'                => 'GYD',
            'amount'                  => 0,
            'direction'               => 'credit',
            'payer_type'              => '',
            'payer_id'                => 0,
            'payee_type'              => '',
            'payee_id'                => 0,
            'reason_code'             => '',
            'reason_label'            => '',
            'source_system'           => '',
            'source_ref'              => '',
            'notes'                   => '',
            'meta_json'               => '',
            'created_at'              => current_time('mysql'),
            'effective_at'            => current_time('mysql'),
            'created_by'              => get_current_user_id(),
            'idempotency_key'         => '',
        ];
        $event = wp_parse_args($event, $defaults);

        if (!BankEvents::is_valid_type((string) $event['event_type'])) return 0;
        if (!in_array((string) $event['direction'], BankEvents::DIRECTIONS, true)) {
            return 0;
        }

        $meta = self::normalize_meta($event['meta_json']);
        $canonical_event_key = self::derive_canonical_event_key($event, $meta);
        $lineage_key = self::derive_lineage_key($event, $meta);
        $idempotency_key = self::derive_idempotency_key($event, $meta);

        $existing_id = self::find_existing_by_canonical_event_key($canonical_event_key);
        if ($existing_id > 0) {
            return $existing_id;
        }

        $existing_id = self::find_existing_idempotent_event_id($event, $meta);
        if ($existing_id > 0) {
            return $existing_id;
        }

        $meta['canonical_event_key'] = $canonical_event_key;
        $meta['lineage_key'] = $lineage_key;
        if ($idempotency_key !== '') {
            $meta['idempotency_key'] = $idempotency_key;
        }
        if (!empty($event['supersedes_event_uuid'])) {
            $meta['supersedes_event_uuid'] = self::normalize_string($event['supersedes_event_uuid']);
        }

        $event['canonical_event_key'] = $canonical_event_key;
        $event['lineage_key'] = $lineage_key;
        $event['meta_json'] = $meta ? wp_json_encode($meta) : '';
        unset($event['idempotency_key']);

        $insert = self::supported_payload($event);

        $ok = $wpdb->insert($table, $insert);
        if (!$ok) {
            $existing_id = self::find_existing_by_canonical_event_key($canonical_event_key);
            if ($existing_id > 0) {
                return $existing_id;
            }

            $existing_id = self::find_existing_idempotent_event_id($event, $meta);
            if ($existing_id > 0) {
                return $existing_id;
            }

            return 0;
        }

        $insert_id = (int) $wpdb->insert_id;
        if (!empty($event['supersedes_event_uuid'])) {
            self::mark_superseded((string) $event['supersedes_event_uuid'], (string) ($event['event_uuid'] ?? ''));
        }

        if (class_exists(__NAMESPACE__ . '\\BankBalances') && method_exists(BankBalances::class, 'refresh_related')) {
            BankBalances::refresh_related($event);
        }

        return $insert_id;
    }

    public static function list(array $filters = [], int $limit = 100): array {
        global $wpdb;
        $table = self::table();
        $where = ['1=1'];
        $args = [];

        foreach (['shipment_id','order_id','vendor_id','courier_id','customer_id'] as $k) {
            if (!empty($filters[$k])) {
                $where[] = "$k = %d";
                $args[] = (int) $filters[$k];
            }
        }

        if (!empty($filters['event_type'])) {
            $where[] = 'event_type = %s';
            $args[] = (string) $filters['event_type'];
        }
        if (!empty($filters['event_status'])) {
            $where[] = 'event_status = %s';
            $args[] = (string) $filters['event_status'];
        }
        if (!empty($filters['return_case_id'])) {
            $where[] = 'return_case_id = %s';
            $args[] = (string) $filters['return_case_id'];
        }
        if (!empty($filters['lineage_key']) && self::supports_column('lineage_key')) {
            $where[] = 'lineage_key = %s';
            $args[] = (string) $filters['lineage_key'];
        }

        $sql = "SELECT * FROM {$table} WHERE " . implode(' AND ', $where) . " ORDER BY id DESC LIMIT %d";
        $args[] = max(1, min(1000, $limit));
        return $wpdb->get_results($wpdb->prepare($sql, ...$args), ARRAY_A) ?: [];
    }

    public static function sum(array $filters = []): float {
        global $wpdb;
        $table = self::table();
        $where = ['1=1'];
        $args = [];

        if (!empty($filters['event_type'])) {
            $where[] = 'event_type = %s';
            $args[] = (string) $filters['event_type'];
        }
        if (!empty($filters['event_status'])) {
            $where[] = 'event_status = %s';
            $args[] = (string) $filters['event_status'];
        }
        if (!empty($filters['return_case_id'])) {
            $where[] = 'return_case_id = %s';
            $args[] = (string) $filters['return_case_id'];
        }
        if (!empty($filters['date_from'])) {
            $where[] = 'created_at >= %s';
            $args[] = (string) $filters['date_from'];
        }
        if (!empty($filters['date_to'])) {
            $where[] = 'created_at <= %s';
            $args[] = (string) $filters['date_to'];
        }

        $sql = "SELECT COALESCE(SUM(amount),0) FROM {$table} WHERE " . implode(' AND ', $where);
        return (float) $wpdb->get_var($args ? $wpdb->prepare($sql, ...$args) : $sql);
    }
}
