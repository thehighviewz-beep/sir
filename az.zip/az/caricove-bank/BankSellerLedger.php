<?php
namespace Caricove\Bank;

if (!defined('ABSPATH')) exit;

final class Ledger
{
    public static function table(): string
    {
        global $wpdb;
        return $wpdb->prefix . 'cc_sp_ledger';
    }

    public static function payouts_table(): string
    {
        global $wpdb;
        return $wpdb->prefix . 'cc_sp_payouts';
    }

    private const SELLER_LEDGER_AUDIT_REPAIR_VERSION = '20260428-audit-v1';

    private static function sql_identifier(string $identifier): string
    {
        return '`' . str_replace('`', '``', $identifier) . '`';
    }

    public static function maybe_install_schema_repairs(): void
    {
        global $wpdb;

        $table = self::table();
        $safe_table = self::sql_identifier($table);

        $exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table));
        if ((string) $exists !== $table) {
            return;
        }

        $installed = (string) get_option('caricove_bank_seller_ledger_audit_repair_version', '');
        if ($installed === self::SELLER_LEDGER_AUDIT_REPAIR_VERSION) {
            return;
        }

        $event_capacity = 0;
        $col = $wpdb->get_row("SHOW COLUMNS FROM {$safe_table} LIKE 'event_type'", ARRAY_A);
        if (is_array($col) && !empty($col['Type']) && preg_match('/varchar\((\d+)\)/i', (string) $col['Type'], $m)) {
            $event_capacity = (int) $m[1];
        }

        if ($event_capacity > 0 && $event_capacity < 64) {
            $wpdb->query("ALTER TABLE {$safe_table} MODIFY event_type VARCHAR(64) NOT NULL DEFAULT ''");
            $col = $wpdb->get_row("SHOW COLUMNS FROM {$safe_table} LIKE 'event_type'", ARRAY_A);
            if (is_array($col) && !empty($col['Type']) && preg_match('/varchar\((\d+)\)/i', (string) $col['Type'], $m)) {
                $event_capacity = (int) $m[1];
            }
        }

        $schema_ok = $event_capacity >= 64;
        $full_partial_reopen_event = 'seller_deduction_partially_reopened_by_refunded_target';
        $safe_partial_reopen_event = ($schema_ok && $event_capacity >= strlen($full_partial_reopen_event))
            ? $full_partial_reopen_event
            : 'seller_deduction_reopened_by_ref';

        $wpdb->query(
            $wpdb->prepare(
                "UPDATE {$safe_table}
                 SET event_type=%s
                 WHERE state='debit'
                   AND event_type=%s",
                $safe_partial_reopen_event,
                'seller_deduction_partially_reope'
            )
        );

        self::repair_debit_open_slice_net_mismatches();

        if ($schema_ok) {
            update_option('caricove_bank_seller_ledger_audit_repair_version', self::SELLER_LEDGER_AUDIT_REPAIR_VERSION, false);
        }
    }

    private static function repair_debit_open_slice_net_mismatches(): int
    {
        global $wpdb;

        $table = self::table();
        $safe_table = self::sql_identifier($table);
        $rows = $wpdb->get_results(
            "SELECT id, unique_key, shipment_id, order_id, vendor_id, currency, state, net, meta
             FROM {$safe_table}
             WHERE state='debit'
               AND net < 0
             ORDER BY id ASC",
            ARRAY_A
        );

        if (!$rows) {
            return 0;
        }

        $fixed = 0;
        $now = self::now();

        foreach ($rows as $row) {
            $row_id = (int) ($row['id'] ?? 0);
            $open_abs = self::money(abs((float) ($row['net'] ?? 0)));
            if ($row_id <= 0 || $open_abs <= 0) {
                continue;
            }

            $meta = self::decode_meta($row['meta'] ?? '');
            $current_slice_total = self::financial_slices_total((array) ($meta['financial_slices'] ?? []));
            if (abs($current_slice_total - $open_abs) <= 0.02) {
                continue;
            }

            $meta = self::sync_debit_open_slices_to_net($row, $meta, $open_abs);
            $meta = self::sync_chain_snapshot($meta, [
                'state' => 'debit',
                'net'   => -1 * $open_abs,
            ]);
            $meta['audit_repair_last'] = [
                'repair' => 'debit_open_slice_net_mismatch',
                'previous_slice_total' => self::money($current_slice_total),
                'abs_net' => $open_abs,
                'repaired_at' => $now,
            ];

            $updated = $wpdb->query(
                $wpdb->prepare(
                    "UPDATE {$safe_table}
                     SET meta=%s,
                         updated_at=%s
                     WHERE id=%d
                       AND state='debit'",
                    self::encode_meta($meta),
                    $now,
                    $row_id
                )
            );

            if ($updated !== false) {
                $fixed++;
            }
        }

        return $fixed;
    }

    /* -------------------------------------------------------------------------
     * Canonical settings resolver
     * ---------------------------------------------------------------------- */

    private static function setting(string $key, $default = null)
    {
        $filtered = apply_filters('caricove_bank_seller_ledger_setting', null, $key, $default);
        if ($filtered !== null) {
            return $filtered;
        }

        $bank_store = get_option('caricove_bank_settings', []);
        if (is_array($bank_store) && array_key_exists($key, $bank_store)) {
            return $bank_store[$key];
        }

        $bank_seller_store = get_option('caricove_bank_seller_settings', []);
        if (is_array($bank_seller_store) && array_key_exists($key, $bank_seller_store)) {
            return $bank_seller_store[$key];
        }

        $single_keys = [
            'caricove_bank_' . $key,
            'caricove_bank_seller_' . $key,
        ];

        foreach ($single_keys as $opt_key) {
            $value = get_option($opt_key, null);
            if ($value !== null) {
                return $value;
            }
        }

        return $default;
    }

    private static function currency(): string
    {
        $currency = (string) self::setting('currency', 'GYD');
        $currency = strtoupper(trim($currency));
        return $currency !== '' ? substr($currency, 0, 10) : 'GYD';
    }

    private static function commission_rate(): float
    {
        return max(0.0, (float) self::setting('commission_rate', 0.12));
    }

    private static function clearing_hours(): int
    {
        return max(0, (int) self::setting('clearing_hours', 72));
    }

    private static function reserve_rate(): float
    {
        return max(0.0, (float) self::setting('new_vendor_reserve_rate', 0.0));
    }

    private static function reserve_days(): int
    {
        return max(0, (int) self::setting('new_vendor_reserve_days', 0));
    }

    private static function default_hold_state(): string
    {
        return 'hold';
    }

    /* -------------------------------------------------------------------------
     * Helpers
     * ---------------------------------------------------------------------- */

    private static function now(): string
    {
        return current_time('mysql');
    }

    private static function decode_meta($raw): array
    {
        if (is_array($raw)) return $raw;
        if (!is_string($raw) || trim($raw) === '') return [];

        $decoded = json_decode($raw, true);
        return is_array($decoded) ? $decoded : [];
    }

    private static function encode_meta(array $meta): string
    {
        return wp_json_encode($meta);
    }

    private static function row_unique_key(string $base): string
    {
        return $base . ':' . wp_generate_password(10, false, false);
    }


    private static function build_trace_context(array $context = []): array
    {
        $existing = trim((string) ($context['correlation_id'] ?? $context['trace_context']['correlation_id'] ?? ''));
        if ($existing === '') {
            $existing = 'ledger-' . substr(md5(wp_json_encode($context) . '|' . microtime(true)), 0, 16);
        }
        return [
            'correlation_id' => $existing,
            'command_source' => 'bank_seller_ledger',
            'case_id' => (string) ($context['case_id'] ?? $context['refund_case_id'] ?? ''),
            'refund_case_id' => (string) ($context['refund_case_id'] ?? $context['case_id'] ?? ''),
            'shipment_id' => (int) ($context['shipment_id'] ?? 0),
            'order_id' => (int) ($context['order_id'] ?? 0),
            'order_item_id' => (int) ($context['order_item_id'] ?? 0),
            'vendor_id' => (int) ($context['vendor_id'] ?? 0),
            'captured_at' => self::now(),
        ];
    }

    private static function with_trace_meta(array $meta, array $context = [], string $operation = ''): array
    {
        $trace = self::build_trace_context($context);
        $existing = isset($meta['trace_context']) && is_array($meta['trace_context']) ? $meta['trace_context'] : [];
        $meta['trace_context'] = array_merge($existing, $trace);
        if ($operation !== '') {
            $meta['trace_operation'] = $operation;
        }
        if (!empty($trace['correlation_id'])) {
            $meta['correlation_id'] = (string) $trace['correlation_id'];
        }
        return $meta;
    }

    private static function money($value): float
    {
        return round((float) $value, 2);
    }

    private static function max0($value): float
    {
        return max(0.0, self::money($value));
    }

    /**
     * Convert a live seller-net amount back into ledger columns that obey the
     * strict earning formula: net = gross - commission - courier_fees - reserve.
     */
    private static function seller_net_columns_for_remaining_amount(float $seller_net): array
    {
        $seller_net = self::money(max(0.0, (float) $seller_net));
        if ($seller_net <= 0.0) {
            return [
                'gross' => 0.0,
                'commission' => 0.0,
                'courier_fees' => 0.0,
                'reserve' => 0.0,
                'net' => 0.0,
            ];
        }

        $rate = self::commission_rate();
        if ($rate <= 0.0 || $rate >= 1.0) {
            return [
                'gross' => $seller_net,
                'commission' => 0.0,
                'courier_fees' => 0.0,
                'reserve' => 0.0,
                'net' => $seller_net,
            ];
        }

        $gross = self::money($seller_net / (1.0 - $rate));
        $commission = self::money($gross - $seller_net);

        return [
            'gross' => $gross,
            'commission' => max(0.0, $commission),
            'courier_fees' => 0.0,
            'reserve' => 0.0,
            'net' => $seller_net,
        ];
    }

    private static function invalidate_vendor_truth_cache(int $vendor_id): void
    {
        $vendor_id = max(0, $vendor_id);
        if ($vendor_id <= 0) {
            return;
        }

        delete_user_meta($vendor_id, '_cc_sp_trace_graph_v4');
    }


    private static function slice_qty($value): float
    {
        $qty = (float) $value;
        if ($qty <= 0) {
            $qty = 1.0;
        }
        return round($qty, 6);
    }

    private static function fallback_slice_id(int $shipment_id, int $order_item_id = 0): string
    {
        if ($order_item_id > 0) {
            return 'ship:' . $shipment_id . ':item:' . $order_item_id;
        }
        return 'ship:' . $shipment_id . ':fallback';
    }

    private static function build_fallback_slice(int $shipment_id, float $amount, array $context = []): array
    {
        $amount = self::money(max(0.0, $amount));
        return [
            'slice_id' => (string) ($context['slice_id'] ?? self::fallback_slice_id($shipment_id, (int) ($context['order_item_id'] ?? 0))),
            'shipment_id' => $shipment_id,
            'order_item_id' => (int) ($context['order_item_id'] ?? 0),
            'product_id' => (int) ($context['product_id'] ?? 0),
            'name' => (string) ($context['name'] ?? ''),
            'qty' => self::slice_qty($context['qty'] ?? 1),
            'amount' => $amount,
            'unit_amount' => self::money($amount / max(0.000001, (float) self::slice_qty($context['qty'] ?? 1))),
            'legacy_fallback' => !empty($context['legacy_fallback']),
        ];
    }

    private static function normalize_financial_slices($raw, int $shipment_id, float $fallback_amount = 0.0, array $context = []): array
    {
        $out = [];
        foreach ((array) $raw as $slice) {
            if (!is_array($slice)) {
                continue;
            }
            $amount = self::money(max(0.0, (float) ($slice['amount'] ?? 0)));
            if ($amount <= 0) {
                continue;
            }
            $qty = self::slice_qty($slice['qty'] ?? 1);
            $order_item_id = (int) ($slice['order_item_id'] ?? 0);
            $slice_id = trim((string) ($slice['slice_id'] ?? ''));
            if ($slice_id === '') {
                $slice_id = self::fallback_slice_id($shipment_id, $order_item_id);
            }
            $out[] = [
                'slice_id' => $slice_id,
                'shipment_id' => $shipment_id,
                'order_item_id' => $order_item_id,
                'product_id' => (int) ($slice['product_id'] ?? 0),
                'name' => (string) ($slice['name'] ?? ''),
                'qty' => $qty,
                'amount' => $amount,
                'unit_amount' => self::money($amount / max(0.000001, $qty)),
                'legacy_fallback' => !empty($slice['legacy_fallback']),
            ];
        }

        if (!$out && $fallback_amount > 0) {
            $out[] = self::build_fallback_slice($shipment_id, $fallback_amount, $context);
        }

        return $out;
    }

    private static function financial_slices_total(array $slices): float
    {
        $sum = 0.0;
        foreach ((array) $slices as $slice) {
            if (!is_array($slice)) {
                continue;
            }
            $sum += (float) ($slice['amount'] ?? 0);
        }
        return self::money($sum);
    }

    private static function seller_earning_slices_are_doctrine_safe(array $slices): bool
    {
        if (!$slices) {
            return false;
        }

        foreach ((array) $slices as $slice) {
            if (!is_array($slice)) {
                return false;
            }

            $slice_id = trim((string) ($slice['slice_id'] ?? ''));
            $order_item_id = (int) ($slice['order_item_id'] ?? 0);
            $amount = self::money((float) ($slice['amount'] ?? 0));

            if ($amount <= 0) {
                continue;
            }

            if ($slice_id === '' || strpos($slice_id, ':fallback') !== false) {
                return false;
            }

            if ($order_item_id <= 0 || strpos($slice_id, ':item:') === false) {
                return false;
            }
        }

        return self::financial_slices_total($slices) > 0;
    }

    private static function block_seller_earning_write(int $shipment_id, int $order_id, int $vendor_id, float $net, string $reason, array $context = []): void
    {
        $now = self::now();
        $payload = [
            'blocked_at' => $now,
            'reason' => $reason,
            'shipment_id' => $shipment_id,
            'order_id' => $order_id,
            'vendor_id' => $vendor_id,
            'net' => self::money($net),
            'context' => $context,
        ];

        if ($shipment_id > 0) {
            update_post_meta($shipment_id, '_cc_seller_ledger_blocked', 'yes');
            update_post_meta($shipment_id, '_cc_seller_ledger_blocked_at', $now);
            update_post_meta($shipment_id, '_cc_seller_ledger_blocked_reason', $reason);
            update_post_meta($shipment_id, '_cc_seller_ledger_blocked_payload', $payload);
        }

        if (function_exists('wc_get_order') && $order_id > 0) {
            $order = wc_get_order($order_id);
            if ($order && method_exists($order, 'add_order_note')) {
                $order->add_order_note(sprintf(
                    'Caricove seller ledger blocked settlement for shipment #%d: %s. Item-level financial slices could not be proven, so no payable ledger row was created.',
                    $shipment_id,
                    $reason
                ));
            }
        }

        do_action('caricove_bank_seller_ledger_blocked', $payload);
    }

    private static function scale_financial_slices_to_total(array $slices, float $target_total, int $shipment_id = 0): array
    {
        $target_total = self::money(max(0.0, (float) $target_total));
        $slices = self::normalize_financial_slices($slices, $shipment_id, 0.0, [
            'legacy_fallback' => false,
        ]);

        if ($target_total <= 0 || !$slices) {
            return [];
        }

        $current_total = self::financial_slices_total($slices);
        if (abs($current_total - $target_total) <= 0.02) {
            return $slices;
        }

        $weighted = [];
        foreach ($slices as $slice) {
            $slice['weight'] = max(0.0, (float) ($slice['amount'] ?? 0));
            $weighted[] = $slice;
        }

        $allocated = self::allocate_total_by_weights($weighted, $target_total);
        foreach ($allocated as &$slice) {
            unset($slice['weight']);
        }
        unset($slice);

        return self::normalize_financial_slices($allocated, $shipment_id, 0.0, [
            'legacy_fallback' => false,
        ]);
    }

    private static function sync_debit_open_slices_to_net(array $row, array $meta, float $open_abs): array
    {
        $open_abs = self::money(max(0.0, (float) $open_abs));
        $shipment_id = (int) ($row['shipment_id'] ?? ($meta['shipment_id'] ?? 0));

        if ($shipment_id > 0 && empty($meta['shipment_id'])) {
            $meta['shipment_id'] = $shipment_id;
        }

        if ($open_abs <= 0) {
            return self::set_row_financial_slices($meta, []);
        }

        $slices = self::row_financial_slices($row, $meta);
        $slices = self::scale_financial_slices_to_total($slices, $open_abs, $shipment_id);

        return self::set_row_financial_slices($meta, $slices);
    }

    private static function allocate_total_by_weights(array $rows, float $total): array
    {
        $total = self::money(max(0.0, $total));
        if ($total <= 0 || !$rows) {
            return [];
        }

        $weight_sum = 0.0;
        foreach ($rows as $row) {
            $weight_sum += max(0.0, (float) ($row['weight'] ?? 0));
        }
        if ($weight_sum <= 0) {
            $weight_sum = (float) count($rows);
            foreach ($rows as &$row) {
                $row['weight'] = 1.0;
            }
            unset($row);
        }

        $alloc = [];
        $remaining_cents = (int) round($total * 100);
        $fracs = [];
        foreach ($rows as $idx => $row) {
            $raw = ($total * max(0.0, (float) ($row['weight'] ?? 0))) / $weight_sum;
            $cents = (int) floor($raw * 100);
            $alloc[$idx] = $cents;
            $remaining_cents -= $cents;
            $fracs[$idx] = ($raw * 100) - $cents;
        }
        arsort($fracs);
        foreach (array_keys($fracs) as $idx) {
            if ($remaining_cents <= 0) {
                break;
            }
            $alloc[$idx] += 1;
            $remaining_cents -= 1;
        }

        $out = [];
        foreach ($rows as $idx => $row) {
            $row['amount'] = self::money(($alloc[$idx] ?? 0) / 100);
            $out[] = $row;
        }
        return $out;
    }

    private static function build_initial_financial_slices(int $shipment_id, int $order_id, float $net, float $commission_base = 0.0): array
    {
        $net = self::money(max(0.0, $net));
        if ($net <= 0) {
            return [];
        }

        $rows = [];
        if (function_exists('wc_get_order') && $order_id > 0) {
            $order = wc_get_order($order_id);
            if ($order) {
                foreach ($order->get_items() as $item_id => $item) {
                    $sid = (int) wc_get_order_item_meta($item_id, '_cc_item_shipment_id', true);
                    if ($sid !== $shipment_id) {
                        continue;
                    }
                    $qty = self::slice_qty($item->get_quantity());
                    $weight = max(0.0, (float) $item->get_total());
                    if ($weight <= 0 && $commission_base > 0) {
                        $weight = max(0.0, (float) $item->get_total());
                    }
                    $name = method_exists($item, 'get_name') ? (string) $item->get_name() : ('Item #' . (int) $item_id);
                    $rows[] = [
                        'slice_id' => self::fallback_slice_id($shipment_id, (int) $item_id),
                        'shipment_id' => $shipment_id,
                        'order_item_id' => (int) $item_id,
                        'product_id' => (int) ($item->get_product_id() ?: 0),
                        'name' => $name,
                        'qty' => $qty,
                        'weight' => $weight,
                    ];
                }
            }
        }

        if (!$rows) {
            return [self::build_fallback_slice($shipment_id, $net, ['legacy_fallback' => false])];
        }

        $weighted = self::allocate_total_by_weights($rows, $net);
        $out = [];
        foreach ($weighted as $slice) {
            $out[] = [
                'slice_id' => (string) $slice['slice_id'],
                'shipment_id' => $shipment_id,
                'order_item_id' => (int) $slice['order_item_id'],
                'product_id' => (int) ($slice['product_id'] ?? 0),
                'name' => (string) ($slice['name'] ?? ''),
                'qty' => self::slice_qty($slice['qty'] ?? 1),
                'amount' => self::money($slice['amount'] ?? 0),
                'unit_amount' => self::money((float) ($slice['amount'] ?? 0) / max(0.000001, (float) self::slice_qty($slice['qty'] ?? 1))),
                'legacy_fallback' => false,
            ];
        }
        return self::normalize_financial_slices($out, $shipment_id, $net);
    }

    private static function row_financial_slices(array $row, ?array $meta = null): array
    {
        $meta = is_array($meta) ? $meta : self::decode_meta($row['meta'] ?? '');
        $shipment_id = (int) ($row['shipment_id'] ?? ($meta['shipment_id'] ?? 0));
        $state = strtolower((string) ($row['state'] ?? ''));
        $net = self::money((float) ($row['net'] ?? 0));
        $positive_amount = $net > 0 ? $net : abs($net);

        if (!empty($meta['financial_slices']) && is_array($meta['financial_slices'])) {
            return self::normalize_financial_slices($meta['financial_slices'], $shipment_id, $positive_amount, [
                'legacy_fallback' => false,
            ]);
        }

        $bridge = isset($meta['return_bridge']) && is_array($meta['return_bridge']) ? $meta['return_bridge'] : [];
        if ($bridge) {
            $amount = self::money(max(0.0, (float) ($bridge['vendor_impact'] ?? $bridge['seller_impact'] ?? $bridge['original_net'] ?? $positive_amount)));
            if ($amount > 0) {
                return self::normalize_financial_slices([[ 
                    'slice_id' => (string) ($bridge['slice_id'] ?? self::fallback_slice_id($shipment_id, (int) ($bridge['item_id'] ?? 0))),
                    'order_item_id' => (int) ($bridge['item_id'] ?? 0),
                    'product_id' => (int) ($bridge['product_id'] ?? 0),
                    'name' => (string) ($bridge['item_name'] ?? ''),
                    'qty' => self::slice_qty($bridge['qty_refundable'] ?? 1),
                    'amount' => $amount,
                    'legacy_fallback' => true,
                ]], $shipment_id, $amount, ['legacy_fallback' => true, 'order_item_id' => (int) ($bridge['item_id'] ?? 0)]);
            }
        }

        if ($positive_amount > 0 && $state !== 'reversed') {
            $order_id = (int) ($row['order_id'] ?? ($meta['order_id'] ?? 0));
            $commission_base = (float) ($meta['commission_base'] ?? 0);
            return self::build_initial_financial_slices($shipment_id, $order_id, $positive_amount, $commission_base);
        }

        return [];
    }

    private static function set_row_financial_slices(array $meta, array $slices): array
    {
        $shipment_id = (int) ($meta['shipment_id'] ?? 0);
        $meta['financial_slices'] = self::normalize_financial_slices($slices, $shipment_id, 0.0, [
            'legacy_fallback' => false,
        ]);
        $meta['slice_truth_version'] = 'v6';
        return $meta;
    }

    private static function split_slice_by_amount(array $slice, float $take_amount): array
    {
        $slice_amount = self::money(max(0.0, (float) ($slice['amount'] ?? 0)));
        $take_amount = self::money(max(0.0, min($slice_amount, $take_amount)));
        if ($slice_amount <= 0 || $take_amount <= 0) {
            return ['taken' => null, 'remaining' => $slice_amount > 0 ? $slice : null];
        }

        $qty = self::slice_qty($slice['qty'] ?? 1);
        $take_qty = $take_amount + 0.009 >= $slice_amount ? $qty : round($qty * ($take_amount / max(0.000001, $slice_amount)), 6);
        $remaining_amount = self::money($slice_amount - $take_amount);
        $remaining_qty = max(0.0, round($qty - $take_qty, 6));

        $taken = $slice;
        $taken['amount'] = $take_amount;
        $taken['qty'] = $take_qty;
        $taken['unit_amount'] = self::money($take_amount / max(0.000001, $take_qty));

        $remaining = null;
        if ($remaining_amount > 0.009) {
            $remaining = $slice;
            $remaining['amount'] = $remaining_amount;
            $remaining['qty'] = max(0.000001, $remaining_qty);
            $remaining['unit_amount'] = self::money($remaining_amount / max(0.000001, (float) $remaining['qty']));
        }

        return ['taken' => $taken, 'remaining' => $remaining];
    }

    private static function take_slices_by_amount(array $slices, float $amount, array $filter = []): array
    {
        $amount = self::money(max(0.0, $amount));
        $remaining_amount = $amount;
        $taken = [];
        $remaining = [];

        foreach ((array) $slices as $slice) {
            if (!is_array($slice)) {
                continue;
            }
            $match = true;
            if (!empty($filter['slice_id'])) {
                $match = ((string) ($slice['slice_id'] ?? '') === (string) $filter['slice_id']);
            }
            if ($match && !empty($filter['order_item_id'])) {
                $match = ((int) ($slice['order_item_id'] ?? 0) === (int) $filter['order_item_id']);
            }

            if (!$match || $remaining_amount <= 0.009) {
                $remaining[] = $slice;
                continue;
            }

            $slice_amount = self::money((float) ($slice['amount'] ?? 0));
            if ($slice_amount <= 0) {
                continue;
            }

            $split = self::split_slice_by_amount($slice, min($slice_amount, $remaining_amount));
            if (!empty($split['taken'])) {
                $taken[] = $split['taken'];
                $remaining_amount = self::money($remaining_amount - (float) $split['taken']['amount']);
            }
            if (!empty($split['remaining'])) {
                $remaining[] = $split['remaining'];
            }
        }

        return [
            'taken_slices' => self::normalize_financial_slices($taken, (int) ($filter['shipment_id'] ?? 0), 0.0),
            'remaining_slices' => self::normalize_financial_slices($remaining, (int) ($filter['shipment_id'] ?? 0), 0.0),
            'taken_amount' => self::money($amount - max(0.0, $remaining_amount)),
            'remaining_amount' => self::money(max(0.0, $remaining_amount)),
        ];
    }

    private static function split_row_financial_slices(array $row, float $amount, array $requested_by_slice = []): array
    {
        $shipment_id = (int) ($row['shipment_id'] ?? 0);
        $meta = self::decode_meta($row['meta'] ?? '');
        $slices = self::row_financial_slices($row, $meta);
        $amount = self::money(max(0.0, $amount));
        if ($amount <= 0) {
            return ['taken_slices' => [], 'remaining_slices' => $slices, 'taken_amount' => 0.0];
        }

        if (!$requested_by_slice) {
            $split = self::take_slices_by_amount($slices, $amount, ['shipment_id' => $shipment_id]);
            if (abs(self::financial_slices_total($split['taken_slices']) - $amount) <= 0.02) {
                return $split;
            }
            return $split;
        }

        $taken = [];
        $remaining = [];
        $taken_total = 0.0;
        foreach ($slices as $slice) {
            $sid = (string) ($slice['slice_id'] ?? '');
            $want = self::money((float) ($requested_by_slice[$sid] ?? 0));
            if ($want <= 0) {
                $remaining[] = $slice;
                continue;
            }
            $split = self::split_slice_by_amount($slice, $want);
            if (!empty($split['taken'])) {
                $taken[] = $split['taken'];
                $taken_total = self::money($taken_total + (float) $split['taken']['amount']);
            }
            if (!empty($split['remaining'])) {
                $remaining[] = $split['remaining'];
            }
        }

        if ($taken_total + 0.02 < $amount) {
            $fallback = self::take_slices_by_amount($remaining, self::money($amount - $taken_total), ['shipment_id' => $shipment_id]);
            $taken = array_merge($taken, (array) ($fallback['taken_slices'] ?? []));
            $remaining = (array) ($fallback['remaining_slices'] ?? []);
            $taken_total = self::money($taken_total + (float) ($fallback['taken_amount'] ?? 0));
        }

        return [
            'taken_slices' => self::normalize_financial_slices($taken, $shipment_id),
            'remaining_slices' => self::normalize_financial_slices($remaining, $shipment_id),
            'taken_amount' => $taken_total,
            'remaining_amount' => self::money(max(0.0, self::financial_slices_total($remaining))),
        ];
    }


    private static function consume_financial_slices_by_request(array $slices, array $requested_by_slice, int $shipment_id = 0): array
    {
        $taken = [];
        $remaining = [];
        foreach ((array) $slices as $slice) {
            if (!is_array($slice)) {
                continue;
            }
            $sid = (string) ($slice['slice_id'] ?? '');
            $want = self::money((float) ($requested_by_slice[$sid] ?? 0));
            if ($want <= 0) {
                $remaining[] = $slice;
                continue;
            }
            $split = self::split_slice_by_amount($slice, $want);
            if (!empty($split['taken'])) {
                $taken[] = $split['taken'];
            }
            if (!empty($split['remaining'])) {
                $remaining[] = $split['remaining'];
            }
        }

        return [
            'taken_slices' => self::normalize_financial_slices($taken, $shipment_id),
            'remaining_slices' => self::normalize_financial_slices($remaining, $shipment_id),
            'taken_amount' => self::money(self::financial_slices_total($taken)),
            'remaining_amount' => self::money(self::financial_slices_total($remaining)),
        ];
    }

    /**
     * CC_BANK_DOCTRINE_REOPEN_TOTAL_BOUNDED
     *
     * Reopen history is a trace aid, but the doctrine-facing reopen total must
     * never exceed the original source exposure. A source can be recovered,
     * reopened, recovered again, and reopened again over time; that lifecycle
     * may create multiple audit events, but the live source exposure can never
     * be more than the original debt slice.
     */
    private static function normalize_reopen_history(array $events, float $source_original_amount = 0.0): array
    {
        $source_original_amount = self::money(max(0.0, $source_original_amount));
        $out = [];
        $seen = [];
        $total = 0.0;

        foreach ((array) $events as $event) {
            if (!is_array($event)) {
                continue;
            }

            $amount = self::money((float) ($event["amount"] ?? 0));
            if ($amount <= 0) {
                continue;
            }

            $key = implode("|", [
                (string) ((int) ($event["target_row_id"] ?? 0)),
                (string) ($event["target_slice_id"] ?? ""),
                (string) ($event["source_slice_id"] ?? ""),
                (string) ($event["case_id"] ?? ($event["refund_case_id"] ?? "")),
                number_format($amount, 2, ".", ""),
            ]);
            if (isset($seen[$key])) {
                continue;
            }
            $seen[$key] = true;

            if ($source_original_amount > 0) {
                $remaining_cap = self::money($source_original_amount - $total);
                if ($remaining_cap <= 0) {
                    break;
                }
                $amount = self::money(min($amount, $remaining_cap));
            }

            $event["amount"] = $amount;
            $out[] = $event;
            $total = self::money($total + $amount);
        }

        return self::normalize_target_edges($out);
    }

    private static function add_amount_to_slice_map(array $slices, array $template, float $amount): array
    {
        $amount = self::money(max(0.0, $amount));
        if ($amount <= 0) {
            return $slices;
        }

        $shipment_id = (int) ($template['shipment_id'] ?? ($template['shipment'] ?? 0));
        $slice_id = (string) ($template['slice_id'] ?? self::fallback_slice_id($shipment_id, (int) ($template['order_item_id'] ?? 0)));
        foreach ($slices as &$slice) {
            if ((string) ($slice['slice_id'] ?? '') !== $slice_id) {
                continue;
            }
            $slice['amount'] = self::money((float) ($slice['amount'] ?? 0) + $amount);
            $slice['qty'] = round(max(0.000001, (float) ($slice['qty'] ?? 1) + (float) ($template['qty'] ?? 0)), 6);
            $slice['unit_amount'] = self::money($slice['amount'] / max(0.000001, (float) $slice['qty']));
            return self::normalize_financial_slices($slices, $shipment_id);
        }
        unset($slice);

        $base = self::build_fallback_slice($shipment_id, $amount, [
            'slice_id' => $slice_id,
            'order_item_id' => (int) ($template['order_item_id'] ?? 0),
            'product_id' => (int) ($template['product_id'] ?? 0),
            'name' => (string) ($template['name'] ?? ''),
            'qty' => max(0.000001, (float) ($template['qty'] ?? 1)),
            'legacy_fallback' => !empty($template['legacy_fallback']),
        ]);
        $slices[] = $base;
        return self::normalize_financial_slices($slices, $shipment_id);
    }

    public static function inspect_item_chain_state(int $shipment_id, int $vendor_id, int $order_item_id, float $qty_requested = 0.0, int $order_id = 0): array
    {
        global $wpdb;

        $shipment_id = max(0, $shipment_id);
        $vendor_id = max(0, $vendor_id);
        $order_item_id = max(0, $order_item_id);
        $qty_requested = max(0.0, (float) $qty_requested);

        $out = [
            'shipment_id' => $shipment_id,
            'vendor_id' => $vendor_id,
            'order_item_id' => $order_item_id,
            'slice_id' => $order_item_id > 0 ? self::fallback_slice_id($shipment_id, $order_item_id) : self::fallback_slice_id($shipment_id),
            'seller_impact_amount' => 0.0,
            'reversible_unpaid_amount' => 0.0,
            'available_amount' => 0.0,
            'paid_cash_amount' => 0.0,
            'active_target_allocated_amount' => 0.0,
            'active_source_amount' => 0.0,
            'matched_qty' => 0.0,
            'unit_amount' => 0.0,
            'role_state' => 'RESOLVED',
        ];

        if ($shipment_id <= 0 || $vendor_id <= 0) {
            return $out;
        }

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM " . self::table() . " WHERE shipment_id=%d AND vendor_id=%d ORDER BY id ASC",
                $shipment_id,
                $vendor_id
            ),
            ARRAY_A
        );
        if (!$rows) {
            return $out;
        }

        $state_order = ['pending' => 10, 'hold' => 20, 'available' => 30, 'paid' => 40, 'debit' => 50, 'reversed' => 60];
        usort($rows, static function (array $a, array $b) use ($state_order): int {
            $as = strtolower((string) ($a['state'] ?? ''));
            $bs = strtolower((string) ($b['state'] ?? ''));
            $cmp = ((int) ($state_order[$as] ?? 999)) <=> ((int) ($state_order[$bs] ?? 999));
            if ($cmp !== 0) {
                return $cmp;
            }
            return ((int) ($a['id'] ?? 0)) <=> ((int) ($b['id'] ?? 0));
        });

        $remaining_qty = $qty_requested > 0 ? $qty_requested : 0.0;
        foreach ($rows as $row) {
            $state = strtolower((string) ($row['state'] ?? ''));
            if (in_array($state, ['reversed'], true)) {
                continue;
            }
            $meta = self::decode_meta($row['meta'] ?? '');
            $payout_mode = strtolower((string) ($meta['payout_mode'] ?? ''));
            $slices = self::row_financial_slices($row, $meta);
            foreach ($slices as $slice) {
                if ($order_item_id > 0 && (int) ($slice['order_item_id'] ?? 0) !== $order_item_id) {
                    continue;
                }
                $slice_qty = max(0.000001, (float) ($slice['qty'] ?? 1));
                $take_qty = $qty_requested > 0 ? min($slice_qty, $remaining_qty) : $slice_qty;
                if ($take_qty <= 0.000001) {
                    continue;
                }
                $take_amount = self::money((float) ($slice['amount'] ?? 0) * ($take_qty / $slice_qty));
                if ($take_amount <= 0) {
                    continue;
                }
                $out['seller_impact_amount'] = self::money($out['seller_impact_amount'] + $take_amount);
                $out['matched_qty'] = round($out['matched_qty'] + $take_qty, 6);
                $out['slice_id'] = (string) ($slice['slice_id'] ?? $out['slice_id']);
                $out['unit_amount'] = self::money($out['seller_impact_amount'] / max(0.000001, (float) $out['matched_qty']));

                if (in_array($state, ['pending', 'hold'], true)) {
                    $out['reversible_unpaid_amount'] = self::money($out['reversible_unpaid_amount'] + $take_amount);
                } elseif ($state === 'available') {
                    $out['available_amount'] = self::money($out['available_amount'] + $take_amount);
                } elseif ($state === 'paid') {
                    if ($payout_mode === 'offset') {
                        $target_total = 0.0;
                        foreach ((array) ($meta['offset_sources'] ?? []) as $edge) {
                            if (!is_array($edge)) {
                                continue;
                            }
                            $match_edge = false;
                            if (!empty($edge['target_slice_id'])) {
                                $match_edge = ((string) $edge['target_slice_id'] === (string) ($slice['slice_id'] ?? ''));
                            } elseif (!empty($edge['target_order_item_id'])) {
                                $match_edge = ((int) $edge['target_order_item_id'] === (int) ($slice['order_item_id'] ?? 0));
                            } elseif ($order_item_id > 0) {
                                $match_edge = true;
                            }
                            if ($match_edge) {
                                $target_total += (float) ($edge['amount'] ?? 0);
                            }
                        }
                        if ($target_total <= 0) {
                            $target_total = $take_amount;
                        }
                        $out['active_target_allocated_amount'] = self::money($out['active_target_allocated_amount'] + min($take_amount, $target_total));
                    } else {
                        $out['paid_cash_amount'] = self::money($out['paid_cash_amount'] + $take_amount);
                    }
                } elseif ($state === 'debit') {
                    $source_total = 0.0;
                    $bridge = isset($meta['return_bridge']) && is_array($meta['return_bridge']) ? $meta['return_bridge'] : [];
                    if (!empty($bridge['slice_id']) && (string) $bridge['slice_id'] !== (string) ($slice['slice_id'] ?? '')) {
                        if ($order_item_id > 0 && (int) ($bridge['item_id'] ?? 0) !== $order_item_id) {
                            continue;
                        }
                    }
                    $source_total = $take_amount;
                    $out['active_source_amount'] = self::money($out['active_source_amount'] + $source_total);
                }

                if ($qty_requested > 0) {
                    $remaining_qty = round(max(0.0, $remaining_qty - $take_qty), 6);
                    if ($remaining_qty <= 0.000001) {
                        break 2;
                    }
                }
            }
        }

        if ($out['active_source_amount'] > 0 && $out['active_target_allocated_amount'] > 0) {
            $out['role_state'] = 'MIXED';
        } elseif ($out['active_source_amount'] > 0) {
            $out['role_state'] = 'SOURCE';
        } elseif ($out['active_target_allocated_amount'] > 0) {
            $out['role_state'] = 'TARGET';
        } elseif ($out['reversible_unpaid_amount'] > 0 || $out['available_amount'] > 0 || $out['paid_cash_amount'] > 0) {
            $out['role_state'] = 'NEUTRAL';
        }

        return $out;
    }

    private static function normalize_source_edges($raw): array
    {
        $out = [];
        foreach ((array) $raw as $entry) {
            if (!is_array($entry)) {
                continue;
            }

            $amount = self::money($entry['amount'] ?? 0);
            if ($amount <= 0) {
                continue;
            }

            $entry['debit_row_id'] = (int) ($entry['debit_row_id'] ?? 0);
            $entry['source_shipment_id'] = (int) ($entry['source_shipment_id'] ?? 0);
            $entry['source_order_id'] = (int) ($entry['source_order_id'] ?? 0);
            $entry['source_slice_id'] = (string) ($entry['source_slice_id'] ?? '');
            $entry['source_order_item_id'] = (int) ($entry['source_order_item_id'] ?? 0);
            $entry['target_row_id'] = (int) ($entry['target_row_id'] ?? 0);
            $entry['target_slice_id'] = (string) ($entry['target_slice_id'] ?? '');
            $entry['target_order_item_id'] = (int) ($entry['target_order_item_id'] ?? 0);
            $entry['amount'] = $amount;
            $out[] = $entry;
        }

        usort($out, static function (array $a, array $b): int {
            foreach (['debit_row_id', 'source_shipment_id', 'source_order_id', 'target_row_id'] as $key) {
                $cmp = ((int) ($a[$key] ?? 0)) <=> ((int) ($b[$key] ?? 0));
                if ($cmp !== 0) {
                    return $cmp;
                }
            }
            return strcmp((string) ($a['reference'] ?? ''), (string) ($b['reference'] ?? ''));
        });

        return $out;
    }

    private static function normalize_target_edges($raw): array
    {
        $out = [];
        foreach ((array) $raw as $entry) {
            if (!is_array($entry)) {
                continue;
            }

            $amount = self::money($entry['amount'] ?? 0);
            if ($amount <= 0) {
                continue;
            }

            $entry['target_row_id'] = (int) ($entry['target_row_id'] ?? 0);
            $entry['target_shipment_id'] = (int) ($entry['target_shipment_id'] ?? 0);
            $entry['target_order_id'] = (int) ($entry['target_order_id'] ?? 0);
            $entry['target_slice_id'] = (string) ($entry['target_slice_id'] ?? '');
            $entry['target_order_item_id'] = (int) ($entry['target_order_item_id'] ?? 0);
            $entry['source_slice_id'] = (string) ($entry['source_slice_id'] ?? '');
            $entry['source_order_item_id'] = (int) ($entry['source_order_item_id'] ?? 0);
            $entry['amount'] = $amount;
            $out[] = $entry;
        }

        usort($out, static function (array $a, array $b): int {
            foreach (['target_row_id', 'target_shipment_id', 'target_order_id'] as $key) {
                $cmp = ((int) ($a[$key] ?? 0)) <=> ((int) ($b[$key] ?? 0));
                if ($cmp !== 0) {
                    return $cmp;
                }
            }
            return strcmp((string) ($a['reference'] ?? ''), (string) ($b['reference'] ?? ''));
        });

        return $out;
    }

    private static function source_edges_total($raw): float
    {
        $sum = 0.0;
        foreach (self::normalize_source_edges($raw) as $entry) {
            $sum += (float) ($entry['amount'] ?? 0);
        }
        return self::money($sum);
    }

    private static function target_edges_total($raw): float
    {
        $sum = 0.0;
        foreach (self::normalize_target_edges($raw) as $entry) {
            $sum += (float) ($entry['amount'] ?? 0);
        }
        return self::money($sum);
    }

    private static function doctrine_first_slice_id_from_slices(array $slices): string
    {
        foreach ($slices as $slice) {
            if (!is_array($slice)) {
                continue;
            }
            $slice_id = trim((string) ($slice['slice_id'] ?? ''));
            if ($slice_id !== '') {
                return $slice_id;
            }
        }
        return '';
    }

    private static function doctrine_source_slice_id_for_edge(array $source_row, array $source_meta): string
    {
        $slice_id = trim((string) ($source_meta['slice_id'] ?? ''));
        if ($slice_id !== '') {
            return $slice_id;
        }

        $slices = self::row_financial_slices($source_row, $source_meta);
        $slice_id = self::doctrine_first_slice_id_from_slices($slices);
        if ($slice_id !== '') {
            return $slice_id;
        }

        $bridge = isset($source_meta['return_bridge']) && is_array($source_meta['return_bridge']) ? $source_meta['return_bridge'] : [];
        $slice_id = trim((string) ($bridge['slice_id'] ?? ''));
        if ($slice_id !== '') {
            return $slice_id;
        }

        if (!empty($source_meta['shipping_liability'])) {
            $shipment_id = (int) ($source_row['shipment_id'] ?? ($source_meta['shipment_id'] ?? 0));
            $scope = trim((string) ($source_meta['shipping_scope'] ?? 'order'));
            $party = trim((string) ($source_meta['shipping_liability_party'] ?? 'seller'));
            $scope = $scope !== '' ? sanitize_key($scope) : 'order';
            $party = $party !== '' ? sanitize_key($party) : 'seller';
            if ($shipment_id > 0) {
                return 'ship:' . $shipment_id . ':shipping:' . $scope . ':' . $party;
            }
        }

        return '';
    }

    private static function doctrine_first_target_slice_id_for_edge(array $target_slices, int $available_row_id, int $source_id): string
    {
        $slice_id = self::doctrine_first_slice_id_from_slices($target_slices);
        if ($slice_id !== '') {
            return $slice_id;
        }

        if ($available_row_id > 0 && $source_id > 0) {
            return 'offset-target:' . $available_row_id . ':' . $source_id;
        }

        return '';
    }

    private static function assign_offset_edges_to_target_slices(array $source_updates, array $taken_slices, int $available_row_id, string $now): array
    {
        // CC_BANK_DOCTRINE_TARGET_SLICE_SPLIT_STRICT_V3
        // Each recovery edge must point to the exact target item slice that supplied the cash.
        // Never collapse every edge onto the first target slice; later refunds unwind by slice.
        $target_queue = [];
        foreach ((array) $taken_slices as $slice) {
            if (!is_array($slice)) {
                continue;
            }

            $slice_amount = self::money((float) ($slice['amount'] ?? 0));
            if ($slice_amount <= 0) {
                continue;
            }

            $slice_id = trim((string) ($slice['slice_id'] ?? ''));
            if ($slice_id === '' || strpos($slice_id, ':fallback') !== false || strpos($slice_id, 'offset-target:') === 0) {
                continue;
            }

            $target_queue[] = [
                'slice_id'          => $slice_id,
                'order_item_id'     => (int) ($slice['order_item_id'] ?? 0),
                'amount_remaining'  => $slice_amount,
            ];
        }

        if (!$target_queue) {
            return [
                'ok'             => false,
                'offset_sources' => [],
                'source_updates' => $source_updates,
                'error'          => 'No doctrine-valid target slices were available for offset allocation.',
            ];
        }

        $queue_index = 0;
        $offset_sources = [];
        $rewritten_updates = [];

        foreach ((array) $source_updates as $source_update) {
            if (!is_array($source_update)) {
                continue;
            }

            $source_amount_remaining = self::money((float) ($source_update['amount'] ?? 0));
            if ($source_amount_remaining <= 0) {
                continue;
            }

            $base_edge = isset($source_update['edge']) && is_array($source_update['edge']) ? $source_update['edge'] : [];
            $source_row = isset($source_update['row']) && is_array($source_update['row']) ? $source_update['row'] : [];
            $source_meta = self::decode_meta($source_row['meta'] ?? '');

            $source_slice_id = trim((string) ($base_edge['source_slice_id'] ?? ''));
            if ($source_slice_id === '') {
                $source_slice_id = self::doctrine_source_slice_id_for_edge($source_row, $source_meta);
            }
            if ($source_slice_id === '') {
                return [
                    'ok'             => false,
                    'offset_sources' => [],
                    'source_updates' => $source_updates,
                    'error'          => 'Source debit row has no doctrine-valid source slice for offset allocation.',
                ];
            }

            $split_edges = [];

            while ($source_amount_remaining > 0.009) {
                while (isset($target_queue[$queue_index]) && self::money((float) ($target_queue[$queue_index]['amount_remaining'] ?? 0)) <= 0) {
                    $queue_index++;
                }

                if (!isset($target_queue[$queue_index])) {
                    return [
                        'ok'             => false,
                        'offset_sources' => [],
                        'source_updates' => $source_updates,
                        'error'          => 'Target slice capacity was exhausted before all source debit edges were assigned.',
                    ];
                }

                $target_remaining = self::money((float) ($target_queue[$queue_index]['amount_remaining'] ?? 0));
                $take = self::money(min($source_amount_remaining, $target_remaining));
                if ($take <= 0) {
                    break;
                }

                $edge = $base_edge;
                $edge['source_slice_id'] = $source_slice_id;
                $edge['source_order_item_id'] = (int) (($edge['source_order_item_id'] ?? 0) ?: ($source_meta['order_item_id'] ?? 0));
                $edge['target_row_id'] = 0;
                $edge['target_slice_id'] = (string) ($target_queue[$queue_index]['slice_id'] ?? '');
                $edge['target_order_item_id'] = (int) ($target_queue[$queue_index]['order_item_id'] ?? 0);
                $edge['amount'] = $take;
                $edge['allocation_status'] = 'consumed';
                $edge['finalized_at'] = $now;

                if (empty($edge['reference'])) {
                    $edge['reference'] = 'offset-allocation:' . (int) ($edge['debit_row_id'] ?? 0) . '->' . $available_row_id;
                }
                if (empty($edge['allocated_at'])) {
                    $edge['allocated_at'] = $now;
                }

                $split_edges[] = $edge;
                $offset_sources[] = $edge;

                $source_amount_remaining = self::money($source_amount_remaining - $take);
                $target_queue[$queue_index]['amount_remaining'] = self::money($target_remaining - $take);
            }

            if (!$split_edges) {
                continue;
            }

            $source_update['edge'] = $split_edges[0];
            $source_update['edges'] = $split_edges;
            $source_update['amount'] = self::source_edges_total($split_edges);
            $rewritten_updates[] = $source_update;
        }

        return [
            'ok'             => true,
            'offset_sources' => self::normalize_source_edges($offset_sources),
            'source_updates' => array_values($rewritten_updates),
        ];
    }

    private static function rebalance_legacy_target_trace_meta(array $meta, float $budget): array
    {
        $budget = self::money(max(0.0, (float) $budget));

        $raw_map = [];
        if (isset($meta['trace_source_shipment_amounts']) && is_array($meta['trace_source_shipment_amounts'])) {
            $raw_map = $meta['trace_source_shipment_amounts'];
        } elseif (isset($meta['source_shipment_amounts']) && is_array($meta['source_shipment_amounts'])) {
            $raw_map = $meta['source_shipment_amounts'];
        }

        if (!$raw_map) {
            return $meta;
        }

        $ordered_ids = [];
        foreach ((array) ($meta['trace_source_shipment_ids'] ?? []) as $sid) {
            $sid = (int) $sid;
            if ($sid > 0 && !in_array($sid, $ordered_ids, true)) $ordered_ids[] = $sid;
        }
        foreach ((array) ($meta['source_shipment_ids'] ?? []) as $sid) {
            $sid = (int) $sid;
            if ($sid > 0 && !in_array($sid, $ordered_ids, true)) $ordered_ids[] = $sid;
        }
        foreach ((array) $raw_map as $sid => $_amount) {
            $sid = (int) $sid;
            if ($sid > 0 && !in_array($sid, $ordered_ids, true)) $ordered_ids[] = $sid;
        }

        $normalized = [];
        foreach ($ordered_ids as $sid) {
            $amt = self::money(max(0.0, (float) ($raw_map[$sid] ?? $raw_map[(string) $sid] ?? 0)));
            if ($amt > 0) {
                $normalized[$sid] = $amt;
            }
        }

        $remaining = $budget;
        $trimmed = [];
        foreach ($ordered_ids as $sid) {
            if ($remaining <= 0.009) break;
            $amt = (float) ($normalized[$sid] ?? 0);
            if ($amt <= 0) continue;
            $take = self::money(min($amt, $remaining));
            if ($take > 0) {
                $trimmed[$sid] = $take;
                $remaining = self::money($remaining - $take);
            }
        }

        $trimmed_ids = array_map('intval', array_keys($trimmed));

        $meta['trace_source_shipment_amounts'] = $trimmed;
        $meta['source_shipment_amounts'] = $trimmed;
        $meta['trace_source_shipment_ids'] = $trimmed_ids;
        $meta['source_shipment_ids'] = $trimmed_ids;
        $meta['trace_source_shipment_id'] = !empty($trimmed_ids) ? (int) $trimmed_ids[0] : 0;
        $meta['source_shipment_id'] = !empty($trimmed_ids) ? (int) $trimmed_ids[0] : 0;

        if (isset($meta['trace_return_rows']) && is_array($meta['trace_return_rows'])) {
            $meta['trace_return_rows'] = array_values(array_filter(
                $meta['trace_return_rows'],
                static function ($row) use ($trimmed) {
                    $sid = (int) ($row['source_shipment_id'] ?? 0);
                    return $sid > 0 && isset($trimmed[$sid]);
                }
            ));
        }

        if (isset($meta['trace_historical_offset_snapshot']) && is_array($meta['trace_historical_offset_snapshot'])) {
            $snap = $meta['trace_historical_offset_snapshot'];
            $snap['source_shipment_ids'] = $trimmed_ids;
            $snap['source_shipment_amounts'] = $trimmed;
            if (isset($snap['return_rows']) && is_array($snap['return_rows'])) {
                $snap['return_rows'] = array_values(array_filter(
                    $snap['return_rows'],
                    static function ($row) use ($trimmed) {
                        $sid = (int) ($row['source_shipment_id'] ?? 0);
                        return $sid > 0 && isset($trimmed[$sid]);
                    }
                ));
            }
            $meta['trace_historical_offset_snapshot'] = $snap;
        }

        return $meta;
    }



    /**
     * Canonical source exposure math for debit rows.
     *
     * Rule:
     * - offset_targets = amount already recovered by target payout rows.
     * - row net < 0 = amount currently open.
     * - original exposure = currently open + still recovered.
     *
     * This intentionally avoids dirty legacy financial_slices / chain_source_slice
     * when the row already has live edge truth. The wallet should never have to
     * guess around doubled reopened slices again.
     */
    private static function canonical_source_amounts(array $meta, string $state, float $net): array
    {
        $state = strtolower(trim($state));
        $net = self::money($net);

        $offset_targets = self::normalize_target_edges($meta['offset_targets'] ?? []);
        $still_recovered = self::money(self::target_edges_total($offset_targets));

        $currently_open = 0.0;
        if ($state === 'debit' && $net < 0) {
            $currently_open = self::money(abs($net));
        } elseif ($state === 'reversed') {
            $currently_open = 0.0;
        } elseif (isset($meta['source_amount_currently_open'])) {
            $currently_open = self::money(max(0.0, (float) $meta['source_amount_currently_open']));
        }

        $edge_original = self::money($currently_open + $still_recovered);

        $explicit_original = self::money(max(0.0, (float) ($meta['source_amount_original'] ?? 0)));
        $bridge_original = 0.0;
        if (isset($meta['return_bridge']) && is_array($meta['return_bridge'])) {
            $bridge = $meta['return_bridge'];
            $bridge_original = self::money(max(
                0.0,
                (float) ($bridge['seller_impact'] ?? 0),
                (float) ($bridge['vendor_impact'] ?? 0),
                (float) ($bridge['item_price_net'] ?? 0),
                (float) ($bridge['original_net'] ?? 0)
            ));
        }

        $slice_total = self::money(self::financial_slices_total((array) ($meta['financial_slices'] ?? [])));

        if ($edge_original > 0) {
            $original = $edge_original;
        } elseif ($explicit_original > 0) {
            $original = $explicit_original;
        } else {
            $original = max($bridge_original, $slice_total, $currently_open, $still_recovered);
        }

        // If an old dirty row has explicit/chain values larger than live edge truth,
        // trust the live edge truth. This is the exact row-shape problem that made
        // reopened debts appear doubled.
        if ($edge_original > 0 && $explicit_original > 0 && abs($explicit_original - $edge_original) <= 0.02) {
            $original = $explicit_original;
        }

        if ($currently_open <= 0 && $state === 'debit' && $net < 0) {
            $currently_open = self::money(abs($net));
        }

        return [
            'original' => self::money($original),
            'still_recovered' => self::money($still_recovered),
            'currently_open' => self::money($currently_open),
            'offset_targets' => $offset_targets,
        ];
    }

    private static function sync_chain_snapshot(array $meta, array $context = []): array
    {
        $state = strtolower((string) ($context['state'] ?? ($meta['settlement_state'] ?? '')));
        $net = self::money($context['net'] ?? ($meta['net'] ?? 0));
        $payout_mode = strtolower((string) ($context['payout_mode'] ?? ($meta['payout_mode'] ?? '')));

        $offset_sources = self::normalize_source_edges($meta['offset_sources'] ?? []);
        $offset_targets = self::normalize_target_edges($meta['offset_targets'] ?? []);

        $target_allocated = self::source_edges_total($offset_sources);
        $source_offset_applied = self::target_edges_total($offset_targets);
        $target_reopened_history = self::target_edges_total($meta['historical_offset_targets_reopened'] ?? []);

        $financial_slice_total = self::financial_slices_total((array) ($meta['financial_slices'] ?? []));
        $explicit_target_candidate = !empty($meta['auto_target_candidate']) || !empty($meta['auto_target_assignment']) || !empty($meta['target_assignment_status']);

        $available_slice = 0.0;
        $withdrawn_slice = 0.0;
        $target_slice = 0.0;
        $source_slice = 0.0;
        $source_remaining = 0.0;
        $repair_slice = 0.0;

        if ($state === 'available' && $net > 0) {
            $available_slice = $net;
        } elseif ($state === 'paid' && $net > 0) {
            if ($payout_mode === 'offset') {
                $target_slice = max($net, $target_allocated);
            } else {
                $withdrawn_slice = $net;
            }
        } elseif ($state === 'debit' && $net < 0) {
            $source_slice = abs($net);
            $source_remaining = abs($net);
        }

        // Source rows must keep original exposure and remaining exposure distinct.
        // Old logic left fully-resolved sources carrying the original amount as
        // chain_source_remaining, which made resolved debit rows look open again.
        $looks_like_source = ($state === 'debit')
            || ($source_offset_applied > 0)
            || (strtolower((string) ($meta['type'] ?? '')) === 'debit');

        if ($looks_like_source) {
            $source_amounts = self::canonical_source_amounts($meta, $state, $net);
            $source_original = self::money($source_amounts['original'] ?? 0);
            $source_offset_applied = self::money($source_amounts['still_recovered'] ?? $source_offset_applied);
            $source_remaining = self::money($source_amounts['currently_open'] ?? 0);
            $offset_targets = isset($source_amounts['offset_targets']) && is_array($source_amounts['offset_targets'])
                ? $source_amounts['offset_targets']
                : $offset_targets;

            if ($source_original > 0) {
                $source_slice = $source_original;
                $meta['source_amount_original'] = self::money($source_original);
                $meta['source_amount_still_recovered'] = self::money($source_offset_applied);
                $meta['source_amount_currently_open'] = self::money($source_remaining);
            }
        }

        if (!empty($meta['restoration_amount'])) {
            $repair_slice = self::money($meta['restoration_amount']);
        }

        $role_state = 'RESOLVED';
        if ($state === 'debit' && $source_remaining > 0) {
            $role_state = 'SOURCE';
        } elseif (($state === 'paid' && $payout_mode === 'offset' && $target_slice > 0) || ($target_allocated > 0)) {
            $role_state = 'TARGET';
        } elseif (in_array($state, ['pending', 'available', 'hold'], true) && $net > 0 && $explicit_target_candidate) {
            $role_state = 'TARGET';
        } elseif (in_array($state, ['pending', 'available', 'hold'], true) && $net > 0) {
            $role_state = 'NEUTRAL';
        } elseif (!empty($meta['refund_target_unwind_case_id']) || !empty($meta['rollback_released_case_id'])) {
            $role_state = 'RESET';
        }

        if ($role_state === 'RESOLVED' && ($available_slice > 0 || $withdrawn_slice > 0)) {
            $role_state = 'NEUTRAL';
        }

        if ($state === 'reversed' && (!empty($meta['refund_target_unwind_case_id']) || !empty($meta['reversal_case_id']))) {
            $role_state = 'RESET';
        }

        if ($state === 'reversed' && $source_offset_applied > 0 && $source_remaining <= 0) {
            $role_state = 'RESOLVED';
        }

        $target_capacity_original = self::money($context['target_capacity_original'] ?? ($meta['chain_target_capacity_original'] ?? 0));
        if ($target_capacity_original <= 0) {
            if ($payout_mode === 'offset' || $target_allocated > 0) {
                $target_capacity_original = max($target_allocated, $target_slice, $net, $financial_slice_total);
            } elseif ($explicit_target_candidate && in_array($state, ['pending', 'available', 'hold'], true) && $net > 0) {
                $target_capacity_original = $net;
            } elseif ($state === 'available' && $net > 0) {
                $target_capacity_original = $net;
            }
        }

        $target_remaining_capacity = self::money(max(0.0, $target_capacity_original - $target_allocated - $target_reopened_history));

        $meta['offset_sources'] = $offset_sources;
        $meta['offset_targets'] = $offset_targets;
        $meta['chain_role_state'] = $role_state;
        $meta['chain_available_slice'] = self::money($available_slice);
        $meta['chain_withdrawn_slice'] = self::money($withdrawn_slice);
        $meta['chain_target_allocated_slice'] = self::money($target_allocated > 0 ? $target_allocated : $target_slice);
        $meta['chain_source_slice'] = self::money($source_slice);
        $meta['chain_repair_slice'] = self::money($repair_slice);
        $meta['chain_source_remaining'] = self::money($source_remaining);
        $meta['chain_target_capacity'] = self::money($target_capacity_original);
        $meta['chain_target_remaining_capacity'] = $target_remaining_capacity;
        $meta['chain_historical_target_reopen_total'] = self::money($target_reopened_history);
        $meta['chain_last_recomputed_at'] = self::now();
        $meta['chain_truth_version'] = 'v5.3';

        if ($target_capacity_original > 0) {
            $meta['chain_target_capacity_original'] = self::money($target_capacity_original);
        }

        return $meta;
    }

    public static function inspect_shipment_chain_state(int $shipment_id, int $vendor_id): array
    {
        global $wpdb;

        $shipment_id = max(0, $shipment_id);
        $vendor_id = max(0, $vendor_id);

        if ($shipment_id <= 0 || $vendor_id <= 0) {
            return [
                'shipment_id' => $shipment_id,
                'vendor_id' => $vendor_id,
                'role_state' => 'RESOLVED',
                'reversible_unpaid_amount' => 0.0,
                'available_slice_amount' => 0.0,
                'hold_slice_amount' => 0.0,
                'pending_slice_amount' => 0.0,
                'paid_cash_amount' => 0.0,
                'paid_target_amount' => 0.0,
                'active_target_allocated_amount' => 0.0,
                'active_source_amount' => 0.0,
                'withdrawn_cash_history' => 0.0,
                'target_row_ids' => [],
                'source_row_ids' => [],
                'row_ids' => [],
                'rows' => [],
            ];
        }

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM " . self::table() . "
                 WHERE shipment_id=%d
                   AND vendor_id=%d
                 ORDER BY id ASC",
                $shipment_id,
                $vendor_id
            ),
            ARRAY_A
        );

        $out = [
            'shipment_id' => $shipment_id,
            'vendor_id' => $vendor_id,
            'role_state' => 'RESOLVED',
            'reversible_unpaid_amount' => 0.0,
            'available_slice_amount' => 0.0,
            'hold_slice_amount' => 0.0,
            'pending_slice_amount' => 0.0,
            'paid_cash_amount' => 0.0,
            'paid_target_amount' => 0.0,
            'active_target_allocated_amount' => 0.0,
            'active_source_amount' => 0.0,
            'withdrawn_cash_history' => 0.0,
            'target_row_ids' => [],
            'source_row_ids' => [],
            'row_ids' => [],
            'rows' => [],
        ];

        foreach ((array) $rows as $row) {
            $row_id = (int) ($row['id'] ?? 0);
            $state = (string) ($row['state'] ?? '');
            $net = self::money($row['net'] ?? 0);
            $meta = self::sync_chain_snapshot(self::decode_meta($row['meta'] ?? ''), [
                'state' => $state,
                'net' => $net,
            ]);
            $payout_mode = strtolower((string) ($meta['payout_mode'] ?? ''));

            if ($row_id > 0) {
                $out['row_ids'][] = $row_id;
            }

            $out['rows'][] = [
                'row_id' => $row_id,
                'state' => $state,
                'net' => $net,
                'event_type' => (string) ($row['event_type'] ?? ''),
                'payout_mode' => $payout_mode,
                'role_state' => (string) ($meta['chain_role_state'] ?? 'RESOLVED'),
                'active_source_amount' => self::money($state === 'debit' ? abs($net) : 0),
                'active_target_amount' => self::money($state === 'paid' && $payout_mode === 'offset' ? max($net, self::source_edges_total($meta['offset_sources'] ?? [])) : 0),
                'available_amount' => self::money($state === 'available' && $net > 0 ? $net : 0),
                'withdrawn_amount' => self::money($state === 'paid' && $payout_mode !== 'offset' && $net > 0 ? $net : 0),
                'meta' => $meta,
            ];

            if (in_array($state, ['pending', 'available', 'hold'], true) && $net > 0) {
                $out['reversible_unpaid_amount'] = self::money($out['reversible_unpaid_amount'] + $net);
            }

            if ($state === 'available' && $net > 0) {
                $out['available_slice_amount'] = self::money($out['available_slice_amount'] + $net);
            }

            if ($state === 'hold' && $net > 0) {
                $out['hold_slice_amount'] = self::money($out['hold_slice_amount'] + $net);
            }

            if ($state === 'pending' && $net > 0) {
                $out['pending_slice_amount'] = self::money($out['pending_slice_amount'] + $net);
            }

            if ($state === 'paid' && $net > 0) {
                if ($payout_mode === 'offset') {
                    $active_target = max($net, self::source_edges_total($meta['offset_sources'] ?? []));
                    $out['paid_target_amount'] = self::money($out['paid_target_amount'] + $net);
                    $out['active_target_allocated_amount'] = self::money($out['active_target_allocated_amount'] + $active_target);
                    if ($row_id > 0) {
                        $out['target_row_ids'][] = $row_id;
                    }
                } else {
                    $out['paid_cash_amount'] = self::money($out['paid_cash_amount'] + $net);
                    $out['withdrawn_cash_history'] = self::money($out['withdrawn_cash_history'] + $net);
                }
            }

            if ($state === 'debit' && $net < 0) {
                $out['active_source_amount'] = self::money($out['active_source_amount'] + abs($net));
                if ($row_id > 0) {
                    $out['source_row_ids'][] = $row_id;
                }
            }
        }

        if ($out['active_source_amount'] > 0 && $out['active_target_allocated_amount'] > 0) {
            $out['role_state'] = 'MIXED';
        } elseif ($out['active_source_amount'] > 0) {
            $out['role_state'] = 'SOURCE';
        } elseif ($out['active_target_allocated_amount'] > 0) {
            $out['role_state'] = 'TARGET';
        } elseif ($out['reversible_unpaid_amount'] > 0 || $out['paid_cash_amount'] > 0) {
            $out['role_state'] = 'NEUTRAL';
        }

        return $out;
    }


    private static function append_meta_note_by_shipment(int $shipment_id, array $extra): void
    {
        global $wpdb;

        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT id, meta FROM " . self::table() . " WHERE shipment_id=%d ORDER BY id DESC LIMIT 1",
                $shipment_id
            ),
            ARRAY_A
        );

        if (!$row) return;

        $id   = (int) ($row['id'] ?? 0);
        $meta = self::decode_meta($row['meta'] ?? '');

        $meta = array_merge($meta, $extra);

        $wpdb->query(
            $wpdb->prepare(
                "UPDATE " . self::table() . "
                 SET meta=%s, updated_at=%s
                 WHERE id=%d",
                self::encode_meta($meta),
                self::now(),
                $id
            )
        );
    }

    private static function fetch_available_rows(int $vendor_id): array
    {
        global $wpdb;

        return (array) $wpdb->get_results(
            $wpdb->prepare(
                "SELECT *
                 FROM " . self::table() . "
                 WHERE vendor_id=%d
                   AND state='available'
                   AND net > 0
                 ORDER BY id ASC",
                $vendor_id
            ),
            ARRAY_A
        );
    }

    private static function fetch_available_rows_for_update(int $vendor_id): array
    {
        global $wpdb;

        return (array) $wpdb->get_results(
            $wpdb->prepare(
                "SELECT *
                 FROM " . self::table() . "
                 WHERE vendor_id=%d
                   AND state='available'
                   AND net > 0
                 ORDER BY id ASC
                 FOR UPDATE",
                $vendor_id
            ),
            ARRAY_A
        );
    }

    private static function fetch_debit_rows(int $vendor_id): array
    {
        global $wpdb;

        return (array) $wpdb->get_results(
            $wpdb->prepare(
                "SELECT *
                 FROM " . self::table() . "
                 WHERE vendor_id=%d
                   AND state='debit'
                   AND net < 0
                 ORDER BY id ASC",
                $vendor_id
            ),
            ARRAY_A
        );
    }

    private static function fetch_debit_rows_for_update(int $vendor_id): array
    {
        global $wpdb;

        return (array) $wpdb->get_results(
            $wpdb->prepare(
                "SELECT *
                 FROM " . self::table() . "
                 WHERE vendor_id=%d
                   AND state='debit'
                   AND net < 0
                 ORDER BY id ASC
                 FOR UPDATE",
                $vendor_id
            ),
            ARRAY_A
        );
    }

    private static function vendor_has_open_debit_exposure(int $vendor_id): bool
    {
        global $wpdb;

        $vendor_id = max(0, $vendor_id);
        if ($vendor_id <= 0) {
            return false;
        }

        $rows = (array) $wpdb->get_results(
            $wpdb->prepare(
                "SELECT net, meta
                 FROM " . self::table() . "
                 WHERE vendor_id=%d
                   AND state='debit'
                   AND net < 0",
                $vendor_id
            ),
            ARRAY_A
        );

        foreach ($rows as $row) {
            $meta = self::decode_meta($row['meta'] ?? '');
            $remaining = self::money($meta['chain_source_remaining'] ?? abs((float) ($row['net'] ?? 0)));
            if ($remaining > 0) {
                return true;
            }
        }

        return false;
    }

    private static function payout_lock_key(int $vendor_id): string
    {
        return 'caricove_bank_seller_payout_lock_' . $vendor_id;
    }

    private static function acquire_payout_lock(int $vendor_id, int $ttl = 120): bool
    {
        $vendor_id = max(0, $vendor_id);
        if ($vendor_id <= 0) return false;

        $key = self::payout_lock_key($vendor_id);
        $now = time();

        $existing = get_option($key, null);
        if (is_array($existing)) {
            $expires_at = (int) ($existing['expires_at'] ?? 0);
            if ($expires_at > $now) {
                return false;
            }
            delete_option($key);
        }

        return add_option($key, [
            'acquired_at' => $now,
            'expires_at'  => $now + max(30, $ttl),
        ], '', false);
    }

    private static function release_payout_lock(int $vendor_id): void
    {
        $vendor_id = max(0, $vendor_id);
        if ($vendor_id <= 0) return;

        delete_option(self::payout_lock_key($vendor_id));
    }

    private static function commit_transaction_or_throw(bool $in_tx): void
    {
        global $wpdb;

        if (!$in_tx) {
            return;
        }

        $commit_result = $wpdb->query('COMMIT');
        if ($commit_result === false) {
            throw new \RuntimeException('Failed committing seller payout transaction.');
        }
    }

    private static function rollback_transaction(bool $in_tx): void
    {
        global $wpdb;

        if ($in_tx) {
            $wpdb->query('ROLLBACK');
        }
    }

    private static function dispatch_deferred_events(array $offset_events, array $payout_events): void
    {
        foreach ($offset_events as $event) {
            do_action('caricove_bank_debit_offset_applied', $event);
        }

        foreach ($payout_events as $event) {
            do_action('caricove_bank_payout_completed', $event);
        }
    }

    private static function clone_row_as_paid_slice(array $row, float $slice_amount, string $reason, array $meta_extra = []): int
    {
        global $wpdb;

        $slice_amount = self::money(max(0.0, $slice_amount));
        if ($slice_amount <= 0) return 0;

        $now  = self::now();
        $meta = self::decode_meta($row['meta'] ?? '');

        $payout_mode = (string) ($meta_extra['payout_mode'] ?? 'cash');
        if (!empty($meta_extra['financial_slices']) && is_array($meta_extra['financial_slices'])) {
            $meta = self::set_row_financial_slices($meta, (array) $meta_extra['financial_slices']);
        } else {
            $split = self::split_row_financial_slices($row, $slice_amount);
            $taken_slices = (array) ($split['taken_slices'] ?? []);
            if (!$taken_slices) {
                $taken_slices = self::scale_financial_slices_to_total(self::row_financial_slices($row, $meta), $slice_amount, (int) ($row['shipment_id'] ?? 0));
            }
            $meta = self::set_row_financial_slices($meta, $taken_slices);
        }

        $meta['settlement_stage']  = $payout_mode === 'offset' ? 'recovery' : 'payout_complete';
        $meta['settlement_state']  = 'paid';
        $meta['settlement_reason'] = $reason;
        $meta['state_timestamp']   = $now;
        $meta['payout_mode']       = $payout_mode;
        $meta = array_merge($meta, $meta_extra);

        $trace_context = [];
        if (isset($meta_extra['trace_context']) && is_array($meta_extra['trace_context'])) {
            $trace_context = $meta_extra['trace_context'];
        }
        $meta = self::with_trace_meta($meta, array_merge($trace_context, [
            'shipment_id' => (int) ($row['shipment_id'] ?? 0),
            'order_id'    => (int) ($row['order_id'] ?? 0),
            'vendor_id'   => (int) ($row['vendor_id'] ?? 0),
        ]), $payout_mode === 'offset' ? 'auto_allocate_open_debits_to_target' : 'clone_row_as_paid_slice');

        $meta = self::sync_chain_snapshot($meta, [
            'state' => 'paid',
            'net' => $slice_amount,
            'payout_mode' => $payout_mode,
        ]);

        $event_type = $payout_mode === 'offset' ? 'seller_offset_consumed' : 'vendor_withdrawal_paid';

        $insert = [
            'unique_key'    => self::row_unique_key((string) ($row['unique_key'] ?? ('split:' . (int) ($row['id'] ?? 0)))),
            'shipment_id'   => (int) ($row['shipment_id'] ?? 0),
            'order_id'      => (int) ($row['order_id'] ?? 0),
            'vendor_id'     => (int) ($row['vendor_id'] ?? 0),
            'currency'      => (string) ($row['currency'] ?? self::currency()),
            'state'         => 'paid',
            'event_type'    => $event_type,
            'note'          => $reason,
            'created_at'    => $now,
            'updated_at'    => $now,
            'delivered_at'  => $row['delivered_at'] ?? null,
            'pending_until' => (string) ($meta['pending_until'] ?? ($row['pending_until'] ?? '')) ?: null,
            'gross'         => 0,
            'commission'    => 0,
            'courier_fees'  => 0,
            'reserve'       => 0,
            'net'           => $slice_amount,
            'meta'          => self::encode_meta($meta),
        ];

        $result = $wpdb->insert(self::table(), $insert);
        if ($result === false) {
            return 0;
        }

        return (int) $wpdb->insert_id;
    }

    private static function reduce_available_row(int $row_id, float $new_net, array $meta): void
    {
        global $wpdb;

        $new_net = self::money(max(0.0, $new_net));
        $now     = self::now();

        if ($new_net <= 0) {
            $meta['settlement_stage']  = 'reversed';
            $meta['settlement_state']  = 'reversed';
            $meta['settlement_reason'] = 'Available row was fully consumed during offset processing';
            $meta['state_timestamp']   = $now;
            $meta = self::set_row_financial_slices($meta, []);
            $meta = self::sync_chain_snapshot($meta, [
                'state' => 'reversed',
                'net' => 0.0,
                'target_capacity_original' => (float) ($meta['chain_target_capacity_original'] ?? 0),
            ]);

            $wpdb->query(
                $wpdb->prepare(
                    "UPDATE " . self::table() . "
                     SET state='reversed',
                         event_type='available_row_fully_consumed',
                         note='Available row was fully consumed during offset processing',
                         gross=0,
                         commission=0,
                         courier_fees=0,
                         reserve=0,
                         net=0,
                         updated_at=%s,
                         meta=%s
                     WHERE id=%d
                       AND state='available'",
                    $now,
                    self::encode_meta($meta),
                    $row_id
                )
            );
            return;
        }

        $meta['settlement_stage']  = 'payout_ready';
        $meta['settlement_state']  = 'available';
        $meta['settlement_reason'] = 'Part of this row was consumed during offset processing; remaining balance is still available';
        $meta['state_timestamp']   = $now;
        $meta = self::sync_chain_snapshot($meta, [
            'state' => 'available',
            'net' => $new_net,
            'target_capacity_original' => (float) ($meta['chain_target_capacity_original'] ?? $new_net),
        ]);

        $columns = self::seller_net_columns_for_remaining_amount($new_net);

        $wpdb->query(
            $wpdb->prepare(
                "UPDATE " . self::table() . "
                 SET event_type='available_row_partially_consumed',
                     note='Part of this row was consumed during offset processing; remaining balance is still available',
                     gross=%s,
                     commission=%s,
                     courier_fees=%s,
                     reserve=%s,
                     net=%s,
                     updated_at=%s,
                     meta=%s
                 WHERE id=%d
                   AND state='available'",
                number_format((float) ($columns['gross'] ?? 0), 2, '.', ''),
                number_format((float) ($columns['commission'] ?? 0), 2, '.', ''),
                number_format((float) ($columns['courier_fees'] ?? 0), 2, '.', ''),
                number_format((float) ($columns['reserve'] ?? 0), 2, '.', ''),
                number_format((float) ($columns['net'] ?? $new_net), 2, '.', ''),
                $now,
                self::encode_meta($meta),
                $row_id
            )
        );
    }



    private static function offset_debit_rows(int $vendor_id, float $credit_to_apply): array
    {
        global $wpdb;

        $credit_to_apply = round(max(0.0, $credit_to_apply), 2);
        if ($credit_to_apply <= 0) {
            return ['applied' => 0.0, 'events' => []];
        }

        $rows = self::fetch_debit_rows_for_update($vendor_id);
        if (!$rows) {
            return ['applied' => 0.0, 'events' => []];
        }

        $remaining = $credit_to_apply;
        $applied   = 0.0;
        $now       = self::now();

        foreach ($rows as $row) {
            if ($remaining <= 0) break;

            $id        = (int) ($row['id'] ?? 0);
            $abs_debit = abs((float) ($row['net'] ?? 0));
            if ($id <= 0 || $abs_debit <= 0) continue;

            $apply_here = min($remaining, $abs_debit);
            $remaining  = round($remaining - $apply_here, 2);
            $applied    = round($applied + $apply_here, 2);

            $meta = self::decode_meta($row['meta'] ?? '');
            $meta['debit_offset_applied'] = round((float) ($meta['debit_offset_applied'] ?? 0) + $apply_here, 2);
            $meta['settlement_stage']     = 'recovery';
            $meta['state_timestamp']      = $now;

            $new_abs = round($abs_debit - $apply_here, 2);

            if ($new_abs <= 0) {
                $meta['settlement_state']  = 'reversed';
                $meta['settlement_reason'] = 'Vendor debit fully offset by available earnings';
                $meta = self::set_row_financial_slices($meta, []);
                $meta = self::sync_chain_snapshot($meta, [
                    'state' => 'reversed',
                    'net'   => 0.0,
                ]);

                $wpdb->query(
                    $wpdb->prepare(
                        "UPDATE " . self::table() . "
                         SET state='reversed',
                             event_type='seller_deduction_fully_offset',
                             note='Vendor debit fully offset by available earnings',
                             net=0,
                             updated_at=%s,
                             meta=%s
                         WHERE id=%d
                           AND state='debit'",
                        $now,
                        self::encode_meta($meta),
                        $id
                    )
                );
            } else {
                $meta['settlement_state']  = 'debit';
                $meta['settlement_reason'] = 'Vendor debit partially offset by available earnings';
                $meta = self::sync_debit_open_slices_to_net($row, $meta, $new_abs);
                $meta = self::sync_chain_snapshot($meta, [
                    'state' => 'debit',
                    'net'   => -1 * $new_abs,
                ]);

                $wpdb->query(
                    $wpdb->prepare(
                        "UPDATE " . self::table() . "
                         SET event_type='seller_deduction_partial_offset',
                             note='Vendor debit partially offset by available earnings',
                             net=%s,
                             updated_at=%s,
                             meta=%s
                         WHERE id=%d
                           AND state='debit'",
                        number_format(-1 * $new_abs, 2, '.', ''),
                        $now,
                        self::encode_meta($meta),
                        $id
                    )
                );
            }
        }

        $events = [];
        if ($applied > 0) {
            $events[] = [
                'vendor_id' => $vendor_id,
                'currency'  => self::currency(),
                'amount'    => $applied,
                'reference' => 'debit_offset:' . $vendor_id . ':' . $now,
            ];
        }

        return [
            'applied' => $applied,
            'events'  => $events,
        ];
    }

    /* -------------------------------------------------------------------------
     * Commission reversal helper
     * ---------------------------------------------------------------------- */

    public static function compute_commission_reversal_for_refund(
        int $shipment_id,
        int $order_id,
        float $refund_amount
    ): float {
        $refund_amount = round(max(0.0, (float) $refund_amount), 2);
        if ($shipment_id <= 0 || $order_id <= 0 || $refund_amount <= 0) return 0.0;

        $commission_rate = self::commission_rate();
        if ($commission_rate <= 0) return 0.0;

        $commission_base = 0.0;

        if (function_exists('wc_get_order')) {
            $order = wc_get_order($order_id);
            if ($order) {
                foreach ($order->get_items() as $item_id => $item) {
                    $sid = (int) wc_get_order_item_meta($item_id, '_cc_item_shipment_id', true);
                    if ($sid !== (int) $shipment_id) continue;
                    $commission_base += (float) $item->get_total();
                }
            }
        }

        $commission_base = max(0.0, round($commission_base, 2));
        if ($commission_base <= 0) return 0.0;

        $refunded_goods = min($refund_amount, $commission_base);
        $reversal = round($refunded_goods * $commission_rate, 2);

        $original_commission = round($commission_base * $commission_rate, 2);
        if ($reversal > $original_commission) {
            $reversal = $original_commission;
        }

        return max(0.0, $reversal);
    }

    /* -------------------------------------------------------------------------
     * Reverse unpaid shipment earnings
     * ---------------------------------------------------------------------- */
    public static function reverse_unpaid_shipment_earnings_idempotent(
        string $unique_key,
        int $shipment_id,
        int $vendor_id,
        array $extra_meta = []
    ): float {
        global $wpdb;

        $unique_key = trim((string) $unique_key);
        if ($unique_key === '' || $shipment_id <= 0 || $vendor_id <= 0) return 0.0;

        $flag_key = '_cc_sp_retbridge_' . md5($unique_key);

        $already = get_post_meta($shipment_id, $flag_key, true);
        if ($already !== '') {
            $j = json_decode((string) $already, true);
            if (is_array($j) && isset($j['reversed_amount'])) {
                return (float) $j['reversed_amount'];
            }
            return 0.0;
        }

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, net, meta
                 FROM " . self::table() . "
                 WHERE shipment_id=%d
                   AND vendor_id=%d
                   AND state IN ('pending','available','hold')
                   AND net > 0
                 ORDER BY id ASC",
                $shipment_id,
                $vendor_id
            ),
            ARRAY_A
        );

        if (!$rows) {
            update_post_meta($shipment_id, $flag_key, wp_json_encode([
                'unique_key'       => $unique_key,
                'did'              => 'none_to_reverse',
                'reversed_amount'  => 0.0,
                'ts'               => self::now(),
                'extra'            => $extra_meta,
            ]));
            return 0.0;
        }

        $sum = 0.0;
        $ids = [];
        $now = self::now();

        foreach ($rows as $r) {
            $id  = (int) ($r['id'] ?? 0);
            $net = (float) ($r['net'] ?? 0);
            if ($id <= 0 || $net <= 0) continue;

            $meta = self::decode_meta($r['meta'] ?? '');
            $meta['settlement_stage']  = 'reversal';
            $meta['settlement_state']  = 'reversed';
            $meta['settlement_reason'] = 'Return refund reversed seller earnings before payout';
            $meta['state_timestamp']   = $now;
            $meta = array_merge($meta, $extra_meta);
            $meta = self::sync_chain_snapshot($meta, [
                'state' => 'reversed',
                'net' => 0.0,
            ]);

            $wpdb->query(
                $wpdb->prepare(
                    "UPDATE " . self::table() . "
                     SET state='reversed',
                         event_type='seller_earnings_reversed_unpaid',
                         note='Return refund reversed seller earnings before payout',
                         gross='0.00',
                         commission='0.00',
                         courier_fees='0.00',
                         reserve='0.00',
                         net='0.00',
                         updated_at=%s,
                         meta=%s
                     WHERE id=%d
                       AND state IN ('pending','available','hold')",
                    $now,
                    self::encode_meta($meta),
                    $id
                )
            );

            if ((int) $wpdb->rows_affected > 0) {
                $ids[] = $id;
                $sum += $net;
            }
        }

        update_post_meta($shipment_id, $flag_key, wp_json_encode([
            'unique_key'       => $unique_key,
            'did'              => 'reversed_unpaid_rows',
            'reversed_amount'  => (float) $sum,
            'row_ids'          => $ids,
            'ts'               => $now,
            'extra'            => $extra_meta,
        ]));

        if ($sum > 0) {
            self::invalidate_vendor_truth_cache($vendor_id);
        }

        return (float) $sum;
    }



    /* -------------------------------------------------------------------------
     * Shipment delivered -> pending earnings
     * ---------------------------------------------------------------------- */

    public static function handle_delivered(
        string $unique_key,
        int $shipment_id,
        int $order_id,
        int $vendor_id,
        string $delivered_at_mysql
    ): void {
        global $wpdb;

        $exists = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT id FROM " . self::table() . " WHERE unique_key = %s LIMIT 1",
                $unique_key
            )
        );
        if ($exists) return;

        $shipment_exists = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT id
                 FROM " . self::table() . "
                 WHERE shipment_id = %d
                   AND state IN ('pending','available','hold','paid')
                 ORDER BY id DESC
                 LIMIT 1",
                $shipment_id
            )
        );
        if ($shipment_exists) return;

        $currency = self::currency();

        $gross = (float) get_post_meta($shipment_id, '_cc_shipment_declared_value', true);
        if ($gross < 0) $gross = 0.0;

        $courier_fees = (float) get_post_meta($shipment_id, '_cc_shipment_courier_fee', true);
        if ($courier_fees < 0) $courier_fees = 0.0;

        $commission_rate = self::commission_rate();
        $commission_base = 0.0;

        if (function_exists('wc_get_order') && $order_id > 0) {
            $order = wc_get_order($order_id);
            if ($order) {
                foreach ($order->get_items() as $item_id => $item) {
                    $sid = (int) wc_get_order_item_meta($item_id, '_cc_item_shipment_id', true);
                    if ($sid !== (int) $shipment_id) continue;
                    $commission_base += (float) $item->get_total();
                }
            }
        }

        $commission_base = max(0.0, round($commission_base, 2));
        $commission      = max(0.0, round($commission_base * $commission_rate, 2));

        $reserve = 0.0;
        $reserve_rate = self::reserve_rate();
        $reserve_days = self::reserve_days();

        if ($reserve_rate > 0 && $reserve_days > 0) {
            $user = get_user_by('id', $vendor_id);
            if ($user && !empty($user->user_registered)) {
                $reg_ts = strtotime((string) $user->user_registered);
                if ($reg_ts && (time() - $reg_ts) <= ($reserve_days * DAY_IN_SECONDS)) {
                    $reserve = max(0.0, round(($gross - $commission - $courier_fees) * $reserve_rate, 2));
                }
            }
        }

        $net = max(0.0, round($gross - $commission - $courier_fees - $reserve, 2));

        $clearing_hours = self::clearing_hours();
        $del_ts = strtotime($delivered_at_mysql);
        if (!$del_ts) $del_ts = time();

        $pending_until = date('Y-m-d H:i:s', $del_ts + ($clearing_hours * HOUR_IN_SECONDS));
        $now = self::now();

        $finance_hold = strtolower(trim((string) get_post_meta($shipment_id, '_cc_shipment_finance_hold', true)));
        $is_hold = ($finance_hold === 'yes' || $finance_hold === '1' || $finance_hold === 'true');

        $state = $is_hold ? self::default_hold_state() : 'pending';

        $settlement_stage  = ($state === 'hold') ? 'hold' : 'clearing';
        $settlement_state  = $state;
        $settlement_reason = ($state === 'hold')
            ? 'Seller earnings were placed on finance hold before payout readiness'
            : 'Seller earnings entered clearing window';

        $financial_slices = self::build_initial_financial_slices($shipment_id, $order_id, $net, $commission_base);

        if ($net > 0 && !self::seller_earning_slices_are_doctrine_safe($financial_slices)) {
            self::block_seller_earning_write($shipment_id, $order_id, $vendor_id, $net, 'missing_item_level_slice_truth', [
                'operation'       => 'shipment_earnings_created',
                'commission_base' => $commission_base,
                'gross'           => $gross,
                'net'             => $net,
                'slices'          => $financial_slices,
            ]);
            return;
        }

        $meta = [
            'shipment_id'        => $shipment_id,
            'order_id'           => $order_id,
            'vendor_id'          => $vendor_id,
            'delivered_at'       => $delivered_at_mysql,
            'pending_until'      => $pending_until,
            'finance_hold'       => $finance_hold ?: 'no',
            'reserve_rate'       => $reserve_rate,
            'reserve_days'       => $reserve_days,
            'commission_base'    => $commission_base,
            'commission_rate'    => $commission_rate,
            'settlement_stage'   => $settlement_stage,
            'settlement_state'   => $settlement_state,
            'settlement_reason'  => $settlement_reason,
            'state_timestamp'    => $now,
            'financial_slices'   => $financial_slices,
            'slice_truth_version'=> 'v6',
        ];

        $has_open_debit_exposure = false;

        $meta = self::with_trace_meta($meta, [
            'shipment_id' => $shipment_id,
            'order_id'    => $order_id,
            'vendor_id'   => $vendor_id,
        ], 'shipment_earnings_created');

        $meta = self::sync_chain_snapshot($meta, [
            'state' => $state,
            'net' => $net,
            'target_capacity_original' => 0,
        ]);

        $payload = [
            'unique_key'    => $unique_key,
            'shipment_id'   => $shipment_id,
            'order_id'      => $order_id,
            'vendor_id'     => $vendor_id,
            'currency'      => $currency,
            'state'         => $state,
            'event_type'    => 'shipment_earnings_created',
            'note'          => 'Shipment earnings created on delivery',
            'hold_reason'   => $state === 'hold' ? 'finance_hold' : null,
            'hold_set_at'   => $state === 'hold' ? $now : null,
            'created_at'    => $now,
            'updated_at'    => $now,
            'delivered_at'  => $delivered_at_mysql,
            'pending_until' => $pending_until,
            'gross'         => $gross,
            'commission'    => $commission,
            'courier_fees'  => $courier_fees,
            'reserve'       => $reserve,
            'net'           => $net,
            'meta'          => self::encode_meta($meta),
        ];

        $payload = apply_filters('caricove_bank_seller_ledger_payload_on_delivered', $payload, $shipment_id, $order_id, $vendor_id);

        $filtered_meta = self::decode_meta($payload['meta'] ?? '');
        $filtered_slices = isset($filtered_meta['financial_slices']) && is_array($filtered_meta['financial_slices'])
            ? (array) $filtered_meta['financial_slices']
            : [];

        if ((float) ($payload['net'] ?? 0) > 0 && !self::seller_earning_slices_are_doctrine_safe($filtered_slices)) {
            self::block_seller_earning_write($shipment_id, $order_id, $vendor_id, (float) ($payload['net'] ?? 0), 'filtered_payload_missing_item_level_slice_truth', [
                'operation'       => 'shipment_earnings_created',
                'commission_base' => $commission_base,
                'gross'           => (float) ($payload['gross'] ?? 0),
                'net'             => (float) ($payload['net'] ?? 0),
                'slices'          => $filtered_slices,
            ]);
            return;
        }

        $result = $wpdb->insert(self::table(), $payload);
        if ($result === false) {
            return;
        }

        $row_id = (int) $wpdb->insert_id;

        if ($row_id > 0 && $has_open_debit_exposure && $state === 'pending' && $net > 0) {
            self::reserve_open_debits_to_pending_target_row($row_id, [
                'operation' => 'shipment_earnings_created',
                'reason'    => 'Open vendor debit exposure existed when shipment earnings were created',
            ]);
        }

        if ($row_id > 0) {
            self::invalidate_vendor_truth_cache($vendor_id);
            do_action('caricove_shipment_earnings_created', [
                'shipment_id'       => $shipment_id,
                'order_id'          => $order_id,
                'vendor_id'         => $vendor_id,
                'amount'            => (float) ($payload['net'] ?? 0),
                'gross'             => (float) ($payload['gross'] ?? 0),
                'commission'        => (float) ($payload['commission'] ?? 0),
                'courier_fees'      => (float) ($payload['courier_fees'] ?? 0),
                'reserve'           => (float) ($payload['reserve'] ?? 0),
                'net'               => (float) ($payload['net'] ?? 0),
                'state'             => (string) ($payload['state'] ?? ''),
                'currency'          => (string) ($payload['currency'] ?? ''),
                'delivered_at'      => (string) ($payload['delivered_at'] ?? ''),
                'pending_until'     => (string) ($payload['pending_until'] ?? ''),
                'unique_key'        => (string) ($payload['unique_key'] ?? ''),
                'source_row_id'     => $row_id,
                'settlement_stage'  => (string) ($meta['settlement_stage'] ?? ''),
                'settlement_state'  => (string) ($meta['settlement_state'] ?? ''),
                'settlement_reason' => (string) ($meta['settlement_reason'] ?? ''),
                'state_timestamp'   => (string) ($meta['state_timestamp'] ?? ''),
            ]);

            do_action('caricove_bank_seller_ledger_created', [
                'ledger_row_id'     => $row_id,
                'shipment_id'       => $shipment_id,
                'order_id'          => $order_id,
                'vendor_id'         => $vendor_id,
                'currency'          => $currency,
                'gross'             => $gross,
                'commission'        => $commission,
                'courier_fees'      => $courier_fees,
                'reserve'           => $reserve,
                'net'               => $net,
                'pending_until'     => $pending_until,
            ]);
        }
    }

    /* -------------------------------------------------------------------------
     * Pending -> available
     * ---------------------------------------------------------------------- */

    public static function promote_pending_to_available(): int
    {
        global $wpdb;

        $now = self::now();

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, net, delivered_at, pending_until, meta
                 FROM " . self::table() . "
                 WHERE state='pending'
                   AND pending_until IS NOT NULL
                   AND pending_until <= %s",
                $now
            ),
            ARRAY_A
        );

        if (!$rows) return 0;

        $count = 0;

        foreach ($rows as $r) {
            $id = (int) ($r['id'] ?? 0);
            if ($id <= 0) continue;

            $meta = self::decode_meta($r['meta'] ?? '');

            if (empty($meta['delivered_at']) && !empty($r['delivered_at'])) {
                $meta['delivered_at'] = (string) $r['delivered_at'];
            }
            if (empty($meta['pending_until']) && !empty($r['pending_until'])) {
                $meta['pending_until'] = (string) $r['pending_until'];
            }

            $meta['settlement_stage']  = 'payout_ready';
            $meta['settlement_state']  = 'available';
            $meta['settlement_reason'] = 'Clearing window completed';
            $meta['state_timestamp']   = $now;

            $promotion_net = self::money((float) ($r['net'] ?? 0));
            if ($promotion_net > 0 && (self::vendor_has_open_debit_exposure((int) ($meta['vendor_id'] ?? 0)) || !empty($meta['auto_target_candidate']))) {
                $meta['auto_target_candidate'] = true;
                $meta['target_assignment_status'] = 'available_for_recovery';
                $meta['target_assignment_reason'] = 'Open vendor debit exposure existed when funds became available';
                $meta['chain_target_capacity_original'] = self::money($meta['chain_target_capacity_original'] ?? $promotion_net);
            }

            $meta = self::sync_chain_snapshot($meta, [
                'state' => 'available',
                'net' => $promotion_net,
                'target_capacity_original' => (float) ($meta['chain_target_capacity_original'] ?? 0),
            ]);

            $wpdb->query(
                $wpdb->prepare(
                    "UPDATE " . self::table() . "
                     SET state='available',
                         event_type='funds_became_available',
                         note='Clearing window completed',
                         updated_at=%s,
                         meta=%s
                     WHERE id=%d
                       AND state='pending'",
                    $now,
                    self::encode_meta($meta),
                    $id
                )
            );

            if ((int) $wpdb->rows_affected > 0) {
                self::auto_allocate_open_debits_to_available_row($id, [
                    'operation' => 'promote_pending_to_available',
                    'reason'    => 'Clearing window completed',
                ]);

                do_action('caricove_bank_funds_became_available', [
                    'ledger_row_id' => $id,
                    'shipment_id'   => (int) ($meta['shipment_id'] ?? 0),
                    'order_id'      => (int) ($meta['order_id'] ?? 0),
                    'vendor_id'     => (int) ($meta['vendor_id'] ?? 0),
                    'currency'      => self::currency(),
                    'amount'        => (float) ($r['net'] ?? 0),
                    'pending_until' => (string) ($meta['pending_until'] ?? ''),
                    'delivered_at'  => (string) ($meta['delivered_at'] ?? ''),
                    'source_ref'    => 'ledger_available:' . $id,
                ]);
            }

            $count += (int) $wpdb->rows_affected;
        }

        if ($count > 0 && !empty($rows[0]['meta'])) {
            $vendor_probe = self::decode_meta($rows[0]['meta'] ?? '');
            self::invalidate_vendor_truth_cache((int) ($vendor_probe['vendor_id'] ?? 0));
        }

        return $count;
    }

    public static function force_clear_pending(): int
    {
        global $wpdb;

        $now = self::now();

        $rows = $wpdb->get_results(
            "SELECT id, net, delivered_at, pending_until, meta
             FROM " . self::table() . "
             WHERE state='pending'",
            ARRAY_A
        );

        if (!$rows) return 0;

        $count = 0;

        foreach ($rows as $r) {
            $id = (int) ($r['id'] ?? 0);
            if ($id <= 0) continue;

            $meta = self::decode_meta($r['meta'] ?? '');

            if (empty($meta['delivered_at']) && !empty($r['delivered_at'])) {
                $meta['delivered_at'] = (string) $r['delivered_at'];
            }
            if (empty($meta['pending_until']) && !empty($r['pending_until'])) {
                $meta['pending_until'] = (string) $r['pending_until'];
            }

            $meta['settlement_stage']  = 'payout_ready';
            $meta['settlement_state']  = 'available';
            $meta['settlement_reason'] = 'Force cleared for testing';
            $meta['state_timestamp']   = $now;
            $meta = self::sync_chain_snapshot($meta, [
                'state' => 'available',
                'net' => (float) ($r['net'] ?? 0),
            ]);

            $wpdb->query(
                $wpdb->prepare(
                    "UPDATE " . self::table() . "
                     SET state='available',
                         event_type='funds_force_cleared_available',
                         note='Force cleared for testing',
                         updated_at=%s,
                         meta=%s
                     WHERE id=%d
                       AND state='pending'",
                    $now,
                    self::encode_meta($meta),
                    $id
                )
            );

            if ((int) $wpdb->rows_affected > 0) {
                self::auto_allocate_open_debits_to_available_row($id, [
                    'operation' => 'force_clear_pending',
                    'reason'    => 'Force cleared for testing',
                ]);

                do_action('caricove_bank_funds_became_available', [
                    'ledger_row_id' => $id,
                    'shipment_id'   => (int) ($meta['shipment_id'] ?? 0),
                    'order_id'      => (int) ($meta['order_id'] ?? 0),
                    'vendor_id'     => (int) ($meta['vendor_id'] ?? 0),
                    'currency'      => self::currency(),
                    'amount'        => (float) ($r['net'] ?? 0),
                    'pending_until' => (string) ($meta['pending_until'] ?? ''),
                    'delivered_at'  => (string) ($meta['delivered_at'] ?? ''),
                    'source_ref'    => 'ledger_force_available:' . $id,
                ]);
            }

            $count += (int) $wpdb->rows_affected;
        }

        return $count;
    }

    /**
     * Immediately reserve open vendor debit exposure against a newly-created pending
     * target shipment. This does NOT move money and does NOT reduce source debit rows;
     * it writes a deterministic target-side reservation so the ledger has a real
     * source -> target plan as soon as the shipment row is born. When the row later
     * becomes available, auto_allocate_open_debits_to_available_row() clears the
     * reservation and performs the actual money-moving recovery once.
     */
    private static function reserve_open_debits_to_pending_target_row(int $target_row_id, array $context = []): array
    {
        // Doctrine mode: no pending reservation scars. Allocation is written only when money is actually available.
        return ['reserved' => 0.0, 'target_row_id' => max(0, (int) $target_row_id), 'sources' => []];
        global $wpdb;

        $target_row_id = max(0, $target_row_id);
        if ($target_row_id <= 0) {
            return ['reserved' => 0.0, 'target_row_id' => 0, 'sources' => []];
        }

        $in_tx = false;

        try {
            $in_tx = ($wpdb->query('START TRANSACTION') !== false);

            $row = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT * FROM " . self::table() . " WHERE id=%d AND state='pending' AND net > 0 FOR UPDATE",
                    $target_row_id
                ),
                ARRAY_A
            );

            if (!$row) {
                self::commit_transaction_or_throw($in_tx);
                return ['reserved' => 0.0, 'target_row_id' => $target_row_id, 'sources' => []];
            }

            $vendor_id = (int) ($row['vendor_id'] ?? 0);
            if ($vendor_id <= 0) {
                self::commit_transaction_or_throw($in_tx);
                return ['reserved' => 0.0, 'target_row_id' => $target_row_id, 'sources' => []];
            }

            $row_meta = self::decode_meta($row['meta'] ?? '');
            if (!empty($row_meta['offset_slice_created']) || self::source_edges_total($row_meta['offset_sources'] ?? []) > 0) {
                self::commit_transaction_or_throw($in_tx);
                return ['reserved' => 0.0, 'target_row_id' => $target_row_id, 'sources' => []];
            }

            $target_capacity = self::money($row_meta['chain_target_capacity_original'] ?? $row['net'] ?? 0);
            if ($target_capacity <= 0) {
                $target_capacity = self::money((float) ($row['net'] ?? 0));
            }
            if ($target_capacity <= 0) {
                self::commit_transaction_or_throw($in_tx);
                return ['reserved' => 0.0, 'target_row_id' => $target_row_id, 'sources' => []];
            }

            $debit_rows = self::fetch_debit_rows_for_update($vendor_id);
            if (!$debit_rows) {
                self::commit_transaction_or_throw($in_tx);
                return ['reserved' => 0.0, 'target_row_id' => $target_row_id, 'sources' => []];
            }

            $now = self::now();
            $remaining_capacity = $target_capacity;
            $offset_sources = [];
            $source_updates = [];

            foreach ($debit_rows as $source_row) {
                if ($remaining_capacity <= 0) {
                    break;
                }

                $source_id = (int) ($source_row['id'] ?? 0);
                if ($source_id <= 0) {
                    continue;
                }

                $source_meta = self::decode_meta($source_row['meta'] ?? '');
                $source_remaining = self::money($source_meta['chain_source_remaining'] ?? abs((float) ($source_row['net'] ?? 0)));
                if ($source_remaining <= 0) {
                    continue;
                }

                $source_slice_id = (string) ($source_meta['slice_id'] ?? '');
                $source_order_item_id = (int) ($source_meta['order_item_id'] ?? 0);

                $take = self::money(min($remaining_capacity, $source_remaining));
                if ($take <= 0) {
                    continue;
                }

                $edge = [
                    'debit_row_id'         => $source_id,
                    'source_shipment_id'   => (int) ($source_row['shipment_id'] ?? 0),
                    'source_order_id'      => (int) ($source_row['order_id'] ?? 0),
                    'source_slice_id'      => $source_slice_id,
                    'source_order_item_id' => $source_order_item_id,
                    'target_row_id'        => $target_row_id,
                    'target_slice_id'      => 'offset-pending:' . $target_row_id . ':' . $source_id,
                    'target_order_item_id' => 0,
                    'amount'               => $take,
                    'reference'            => 'pending-offset-plan:' . $source_id . '->' . $target_row_id,
                    'allocation_status'    => 'reserved_pending',
                    'allocated_at'         => $now,
                ];

                $offset_sources[] = $edge;
                $source_updates[] = [
                    'row' => $source_row,
                    'meta' => $source_meta,
                    'amount' => $take,
                    'edge' => $edge,
                ];

                $remaining_capacity = self::money($remaining_capacity - $take);
            }

            $reserved_total = self::source_edges_total($offset_sources);
            if ($reserved_total <= 0) {
                self::commit_transaction_or_throw($in_tx);
                return ['reserved' => 0.0, 'target_row_id' => $target_row_id, 'sources' => []];
            }

            $trace_context = array_merge($context, [
                'vendor_id'       => $vendor_id,
                'shipment_id'     => (int) ($row['shipment_id'] ?? 0),
                'order_id'        => (int) ($row['order_id'] ?? 0),
                'target_row_id'   => $target_row_id,
                'trace_operation' => 'reserve_open_debits_to_pending_target_row',
                'correlation_id'  => (string) ($context['correlation_id'] ?? ('pending-alloc-' . $target_row_id . '-' . time())),
            ]);

            $row_meta['auto_target_candidate'] = true;
            $row_meta['target_assignment_status'] = 'reserved_pending';
            $row_meta['target_assignment_reason'] = 'Open vendor debit exposure reserved against newly-created pending shipment';
            $row_meta['chain_target_capacity_original'] = $target_capacity;
            $row_meta['offset_sources'] = self::normalize_source_edges($offset_sources);
            $row_meta['pending_offset_reserved_total'] = $reserved_total;
            $row_meta['pending_offset_reserved_at'] = $now;
            $row_meta = self::with_trace_meta($row_meta, $trace_context, 'reserve_open_debits_to_pending_target_row');
            $row_meta = self::sync_chain_snapshot($row_meta, [
                'state' => 'pending',
                'net' => (float) ($row['net'] ?? 0),
                'target_capacity_original' => $target_capacity,
            ]);

            $wpdb->update(
                self::table(),
                ['meta' => self::encode_meta($row_meta), 'updated_at' => $now],
                ['id' => $target_row_id],
                ['%s', '%s'],
                ['%d']
            );

            foreach ($source_updates as $source_update) {
                $source_row = (array) ($source_update['row'] ?? []);
                $source_id = (int) ($source_row['id'] ?? 0);
                $amount = self::money($source_update['amount'] ?? 0);
                if ($source_id <= 0 || $amount <= 0) {
                    continue;
                }

                $source_meta = (array) ($source_update['meta'] ?? []);
                $source_edge = (array) ($source_update['edge'] ?? []);
                $source_edge['target_shipment_id'] = (int) ($row['shipment_id'] ?? 0);
                $source_edge['target_order_id'] = (int) ($row['order_id'] ?? 0);

                $existing_targets = self::normalize_target_edges($source_meta['offset_targets'] ?? []);
                $existing_targets[] = $source_edge;
                $source_meta['offset_targets'] = self::normalize_target_edges($existing_targets);
                $source_meta['pending_debit_reserved_total'] = self::money((float) ($source_meta['pending_debit_reserved_total'] ?? 0) + $amount);
                $source_meta['pending_debit_reserved_at'] = $now;
                $source_meta['settlement_stage'] = 'recovery';
                $source_meta['settlement_state'] = 'debit';
                $source_meta['settlement_reason'] = 'Vendor debit reserved against pending shipment recovery';
                $source_meta['state_timestamp'] = $now;
                $source_meta = self::with_trace_meta($source_meta, $trace_context, 'reserve_open_debits_to_pending_source');
                $source_meta = self::sync_chain_snapshot($source_meta, [
                    'state' => 'debit',
                    'net' => (float) ($source_row['net'] ?? 0),
                ]);

                $wpdb->update(
                    self::table(),
                    ['meta' => self::encode_meta($source_meta), 'updated_at' => $now],
                    ['id' => $source_id],
                    ['%s', '%s'],
                    ['%d']
                );
            }

            self::commit_transaction_or_throw($in_tx);
            self::invalidate_vendor_truth_cache($vendor_id);

            return [
                'reserved' => $reserved_total,
                'target_row_id' => $target_row_id,
                'sources' => $offset_sources,
                'remaining_capacity' => self::money($target_capacity - $reserved_total),
            ];
        } catch (\Throwable $e) {
            self::rollback_transaction($in_tx);
            return [
                'reserved' => 0.0,
                'target_row_id' => $target_row_id,
                'sources' => [],
                'error' => $e->getMessage(),
            ];
        }
    }

    /**
     * Convert a newly-available positive shipment row into a real recovery target
     * when the same vendor has open debit exposure.
     *
     * This is intentionally engine-level (not UI-level): it writes both sides of the
     * recovery chain so the inspector, reversal logic, and payout logic all see the
     * same truth.
     */
    private static function auto_allocate_open_debits_to_available_row(int $available_row_id, array $context = []): array
    {
        // CC_BANK_DOCTRINE_FORCE_PROMOTE_OFFSET_EDGES_FIXED
        global $wpdb;

        $available_row_id = max(0, $available_row_id);
        if ($available_row_id <= 0) {
            return ['applied' => 0.0, 'target_row_id' => 0, 'sources' => []];
        }

        $in_tx = false;
        $lock_vendor_id = 0;

        try {
            $in_tx = ($wpdb->query('START TRANSACTION') !== false);

            $row = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT * FROM " . self::table() . " WHERE id=%d AND state='available' AND net > 0 FOR UPDATE",
                    $available_row_id
                ),
                ARRAY_A
            );

            if (!$row) {
                self::commit_transaction_or_throw($in_tx);
                return ['applied' => 0.0, 'target_row_id' => $available_row_id, 'sources' => []];
            }

            $vendor_id = (int) ($row['vendor_id'] ?? 0);
            $lock_vendor_id = $vendor_id;
            if ($vendor_id <= 0) {
                self::commit_transaction_or_throw($in_tx);
                return ['applied' => 0.0, 'target_row_id' => $available_row_id, 'sources' => []];
            }

            // If this row was already converted into a target/offset slice, never duplicate it.
            // Pending targets may already carry reserved offset_sources for audit visibility;
            // those are reservations, not money movement, so clear/recompute them when funds
            // actually become available.
            $row_meta = self::decode_meta($row['meta'] ?? '');
            $reserved_pending_edges = self::normalize_source_edges($row_meta['offset_sources'] ?? []);
            $is_pending_reservation = (($row_meta['target_assignment_status'] ?? '') === 'reserved_pending');
            if (!empty($row_meta['offset_slice_created']) || (self::source_edges_total($reserved_pending_edges) > 0 && !$is_pending_reservation)) {
                self::commit_transaction_or_throw($in_tx);
                return ['applied' => 0.0, 'target_row_id' => $available_row_id, 'sources' => []];
            }
            if ($is_pending_reservation && self::source_edges_total($reserved_pending_edges) > 0) {
                $row_meta['reserved_offset_sources'] = $reserved_pending_edges;
                $row_meta['offset_sources'] = [];
            }

            $available_net = self::money((float) ($row['net'] ?? 0));
            if ($available_net <= 0) {
                self::commit_transaction_or_throw($in_tx);
                return ['applied' => 0.0, 'target_row_id' => $available_row_id, 'sources' => []];
            }

            $now = self::now();
            $remaining_capacity = $available_net;
            $offset_sources = [];
            $source_updates = [];

            if ($is_pending_reservation && self::source_edges_total($reserved_pending_edges) > 0) {
                foreach ($reserved_pending_edges as $reserved_edge) {
                    if ($remaining_capacity <= 0) {
                        break;
                    }

                    $source_id = (int) ($reserved_edge['debit_row_id'] ?? 0);
                    $reserved_amount = self::money($reserved_edge['amount'] ?? 0);
                    if ($source_id <= 0 || $reserved_amount <= 0) {
                        continue;
                    }

                    $source_row = $wpdb->get_row(
                        $wpdb->prepare("SELECT * FROM " . self::table() . " WHERE id=%d AND state='debit' AND net < 0 FOR UPDATE", $source_id),
                        ARRAY_A
                    );
                    if (!$source_row) {
                        continue;
                    }

                    $source_abs = self::money(abs((float) ($source_row['net'] ?? 0)));
                    $take = self::money(min($remaining_capacity, $reserved_amount, $source_abs));
                    if ($take <= 0) {
                        continue;
                    }

                    $source_meta = self::decode_meta($source_row['meta'] ?? '');
                    $edge = $reserved_edge;
                    $edge['amount'] = $take;
                    $edge['source_slice_id'] = (string) (($edge['source_slice_id'] ?? '') ?: self::doctrine_source_slice_id_for_edge($source_row, $source_meta));
                    $edge['source_order_item_id'] = (int) (($edge['source_order_item_id'] ?? 0) ?: ($source_meta['order_item_id'] ?? 0));
                    $edge['target_row_id'] = 0; // filled after the paid offset slice is created
                    $edge['allocation_status'] = 'consumed';
                    $edge['finalized_at'] = $now;

                    $offset_sources[] = $edge;
                    $source_updates[] = [
                        'row'    => $source_row,
                        'amount' => $take,
                        'edge'   => $edge,
                        'reserved_target_row_id' => $available_row_id,
                    ];

                    $remaining_capacity = self::money($remaining_capacity - $take);
                }
            } else {
                $debit_rows = self::fetch_debit_rows_for_update($vendor_id);
                if (!$debit_rows) {
                    self::commit_transaction_or_throw($in_tx);
                    return ['applied' => 0.0, 'target_row_id' => $available_row_id, 'sources' => []];
                }

                foreach ($debit_rows as $source_row) {
                    if ($remaining_capacity <= 0) {
                        break;
                    }

                    $source_id = (int) ($source_row['id'] ?? 0);
                    if ($source_id <= 0) {
                        continue;
                    }

                    $source_meta = self::decode_meta($source_row['meta'] ?? '');
                    $source_remaining = self::money($source_meta['chain_source_remaining'] ?? abs((float) ($source_row['net'] ?? 0)));
                    if ($source_remaining <= 0) {
                        continue;
                    }

                    $take = self::money(min($remaining_capacity, $source_remaining));
                    if ($take <= 0) {
                        continue;
                    }

                    $edge = [
                        'debit_row_id'         => $source_id,
                        'source_shipment_id'   => (int) ($source_row['shipment_id'] ?? 0),
                        'source_order_id'      => (int) ($source_row['order_id'] ?? 0),
                        'source_slice_id'      => self::doctrine_source_slice_id_for_edge($source_row, $source_meta),
                        'source_order_item_id' => (int) ($source_meta['order_item_id'] ?? 0),
                        'target_row_id'        => 0, // filled after the paid offset slice is created
                        'target_slice_id'      => 'offset-target:' . $available_row_id . ':' . $source_id,
                        'target_order_item_id' => 0,
                        'amount'               => $take,
                        'reference'            => 'offset-allocation:' . $source_id . '->' . $available_row_id,
                        'allocation_status'    => 'consumed',
                        'allocated_at'         => $now,
                        'finalized_at'         => $now,
                    ];

                    $offset_sources[] = $edge;
                    $source_updates[] = [
                        'row'    => $source_row,
                        'amount' => $take,
                        'edge'   => $edge,
                    ];

                    $remaining_capacity = self::money($remaining_capacity - $take);
                }
            }

            $applied_total = self::source_edges_total($offset_sources);
            if ($applied_total <= 0) {
                self::commit_transaction_or_throw($in_tx);
                return ['applied' => 0.0, 'target_row_id' => $available_row_id, 'sources' => []];
            }

            $trace_context = array_merge($context, [
                'vendor_id'        => $vendor_id,
                'shipment_id'      => (int) ($row['shipment_id'] ?? 0),
                'order_id'         => (int) ($row['order_id'] ?? 0),
                'target_row_id'    => $available_row_id,
                'trace_operation'  => 'auto_allocate_open_debits_to_available_row',
                'correlation_id'   => (string) ($context['correlation_id'] ?? ('offset-alloc-' . $available_row_id . '-' . time())),
            ]);

            $target_slice_split = self::split_row_financial_slices($row, $applied_total);
            $taken_target_slices = (array) ($target_slice_split['taken_slices'] ?? []);

            $assignment = self::assign_offset_edges_to_target_slices($source_updates, $taken_target_slices, $available_row_id, $now);
            if (empty($assignment['ok'])) {
                throw new \RuntimeException((string) ($assignment['error'] ?? 'Failed assigning offset edges to exact target slices.'));
            }

            $offset_sources = (array) ($assignment['offset_sources'] ?? []);
            $source_updates = (array) ($assignment['source_updates'] ?? []);
            $applied_total = self::source_edges_total($offset_sources);
            if ($applied_total <= 0) {
                self::commit_transaction_or_throw($in_tx);
                return ['applied' => 0.0, 'target_row_id' => $available_row_id, 'sources' => []];
            }
            $paid_offset_row_id = self::clone_row_as_paid_slice(
                $row,
                $applied_total,
                'Available seller earnings used to offset debit exposure',
                [
                    'financial_slices'         => (array) ($target_slice_split['taken_slices'] ?? []),
                    'offset_from_row_id'       => $available_row_id,
                    'payout_mode'              => 'offset',
                    'offset_sources'           => $offset_sources,
                    'linked_source_shipments'  => array_values(array_unique(array_map(static function ($entry) {
                        return (int) ($entry['source_shipment_id'] ?? 0);
                    }, $offset_sources))),
                    'target_assignment_status' => 'allocated',
                    'target_assignment_reason' => 'Open vendor debit exposure existed when shipment became available',
                    'chain_target_capacity_original' => $applied_total,
                    'chain_target_remaining_capacity' => 0,
                    'trace_context'            => $trace_context,
                    'correlation_id'           => (string) ($trace_context['correlation_id'] ?? ''),
                ]
            );

            if ($paid_offset_row_id <= 0) {
                throw new \RuntimeException('Failed creating automatic paid offset target slice.');
            }

            foreach ($offset_sources as $idx => $edge) {
                $offset_sources[$idx]['target_row_id'] = $paid_offset_row_id;
                $offset_sources[$idx]['allocation_status'] = 'consumed';
                $offset_sources[$idx]['finalized_at'] = $now;
            }
            foreach ($source_updates as $update_idx => $source_update) {
                $edges = isset($source_update['edges']) && is_array($source_update['edges'])
                    ? array_values($source_update['edges'])
                    : (isset($source_update['edge']) && is_array($source_update['edge']) ? [$source_update['edge']] : []);

                foreach ($edges as $edge_idx => $edge) {
                    $edges[$edge_idx]['target_row_id'] = $paid_offset_row_id;
                    $edges[$edge_idx]['allocation_status'] = 'consumed';
                    $edges[$edge_idx]['finalized_at'] = $now;
                }

                $source_updates[$update_idx]['edges'] = $edges;
                if ($edges) {
                    $source_updates[$update_idx]['edge'] = $edges[0];
                }
            }

            // Re-write the target slice with the final target_row_id in its offset_sources.
            $target_slice = $wpdb->get_row(
                $wpdb->prepare("SELECT * FROM " . self::table() . " WHERE id=%d LIMIT 1", $paid_offset_row_id),
                ARRAY_A
            );
            if ($target_slice) {
                $target_meta = self::decode_meta($target_slice['meta'] ?? '');
                $target_meta['offset_sources'] = $offset_sources;
                $target_meta['target_assignment_status'] = 'allocated';
                $target_meta['target_assignment_reason'] = 'Open vendor debit exposure existed when shipment became available';
                $target_meta['chain_target_capacity_original'] = $applied_total;
                $target_meta = self::sync_chain_snapshot($target_meta, [
                    'state' => 'paid',
                    'net' => $applied_total,
                    'payout_mode' => 'offset',
                    'target_capacity_original' => $applied_total,
                ]);
                $wpdb->update(
                    self::table(),
                    ['meta' => self::encode_meta($target_meta), 'updated_at' => $now],
                    ['id' => $paid_offset_row_id],
                    ['%s', '%s'],
                    ['%d']
                );
            }

            $remaining_net = self::money($available_net - $applied_total);
            if (isset($target_slice_split) && is_array($target_slice_split)) {
                $row_meta = self::set_row_financial_slices($row_meta, (array) ($target_slice_split['remaining_slices'] ?? []));
            } elseif ($remaining_net > 0) {
                $row_meta = self::set_row_financial_slices($row_meta, self::scale_financial_slices_to_total(self::row_financial_slices($row, $row_meta), $remaining_net, (int) ($row['shipment_id'] ?? 0)));
            } else {
                $row_meta = self::set_row_financial_slices($row_meta, []);
            }
            $row_meta['offset_slice_created'] = true;
            $row_meta['offset_slice_amount'] = $applied_total;
            $row_meta['offset_slice_row_id'] = $paid_offset_row_id;
            $row_meta['auto_target_candidate'] = true;
            $row_meta['target_assignment_status'] = $remaining_net > 0 ? 'partially_allocated' : 'fully_allocated';
            $row_meta['chain_target_capacity_original'] = self::money($row_meta['chain_target_capacity_original'] ?? $available_net);
            $row_meta['settlement_reason'] = $remaining_net > 0
                ? 'Shipment became available after automatic debit recovery was reserved'
                : 'Shipment earnings fully consumed by automatic debit recovery';
            $row_meta['state_timestamp'] = $now;
            $row_meta = self::with_trace_meta($row_meta, $trace_context, 'auto_allocate_open_debits_to_available_row');
            self::reduce_available_row($available_row_id, $remaining_net, $row_meta);

            foreach ($source_updates as $source_update) {
                $source_row = (array) ($source_update['row'] ?? []);
                $source_id = (int) ($source_row['id'] ?? 0);
                $amount = self::money($source_update['amount'] ?? 0);
                if ($source_id <= 0 || $amount <= 0) {
                    continue;
                }

                $source_meta = self::decode_meta($source_row['meta'] ?? '');
                $source_abs = self::money(abs((float) ($source_row['net'] ?? 0)));
                $new_abs = self::money(max(0.0, $source_abs - $amount));

                $target_edges = isset($source_update['edges']) && is_array($source_update['edges'])
                    ? array_values($source_update['edges'])
                    : (isset($source_update['edge']) && is_array($source_update['edge']) ? [$source_update['edge']] : []);

                $existing_targets = self::normalize_target_edges($source_meta['offset_targets'] ?? []);
                $reserved_target_row_id = (int) ($source_update['reserved_target_row_id'] ?? 0);
                if ($reserved_target_row_id > 0) {
                    $existing_targets = array_values(array_filter($existing_targets, static function ($edge) use ($reserved_target_row_id) {
                        return (int) ($edge['target_row_id'] ?? 0) !== $reserved_target_row_id;
                    }));
                }

                foreach ($target_edges as $target_edge) {
                    if (!is_array($target_edge)) {
                        continue;
                    }

                    $target_edge['target_row_id'] = $paid_offset_row_id;
                    $target_edge['target_shipment_id'] = (int) ($row['shipment_id'] ?? 0);
                    $target_edge['target_order_id'] = (int) ($row['order_id'] ?? 0);
                    $target_edge['target_slice_id'] = (string) ($target_edge['target_slice_id'] ?? '');
                    $target_edge['target_order_item_id'] = (int) ($target_edge['target_order_item_id'] ?? 0);
                    $target_edge['source_slice_id'] = (string) (($target_edge['source_slice_id'] ?? '') ?: self::doctrine_source_slice_id_for_edge($source_row, $source_meta));
                    $target_edge['source_order_item_id'] = (int) (($target_edge['source_order_item_id'] ?? 0) ?: ($source_meta['order_item_id'] ?? 0));
                    $target_edge['amount'] = self::money((float) ($target_edge['amount'] ?? 0));
                    $target_edge['reference'] = (string) (($target_edge['reference'] ?? '') ?: ('offset-allocation:' . $source_id . '->' . $available_row_id));
                    $target_edge['allocation_status'] = 'consumed';
                    $target_edge['allocated_at'] = (string) (($target_edge['allocated_at'] ?? '') ?: $now);
                    $target_edge['finalized_at'] = $now;

                    if ($target_edge['amount'] > 0 && $target_edge['source_slice_id'] !== '' && $target_edge['target_slice_id'] !== '') {
                        $existing_targets[] = $target_edge;
                    }
                }

                $source_meta['offset_targets'] = self::normalize_target_edges($existing_targets);
                $source_meta['pending_debit_reserved_total'] = self::money(max(0.0, (float) ($source_meta['pending_debit_reserved_total'] ?? 0) - $amount));
                $source_meta['debit_offset_applied'] = self::money((float) ($source_meta['debit_offset_applied'] ?? 0) + $amount);
                $source_meta['settlement_stage'] = 'recovery';
                $source_meta['state_timestamp'] = $now;
                $source_meta = self::with_trace_meta($source_meta, $trace_context, 'auto_allocate_open_debits_to_source');

                if ($new_abs <= 0) {
                    $source_meta['settlement_state'] = 'reversed';
                    $source_meta['settlement_reason'] = 'Vendor debit fully offset by automatic shipment recovery';
                    $source_meta = self::sync_chain_snapshot($source_meta, [
                        'state' => 'reversed',
                        'net' => 0.0,
                    ]);
                    $wpdb->query(
                        $wpdb->prepare(
                            "UPDATE " . self::table() . "
                             SET state='reversed',
                                 event_type='seller_deduction_fully_offset',
                                 note='Vendor debit fully offset by automatic shipment recovery',
                                 net=0,
                                 updated_at=%s,
                                 meta=%s
                             WHERE id=%d",
                            $now,
                            self::encode_meta($source_meta),
                            $source_id
                        )
                    );
                } else {
                    $source_meta['settlement_state'] = 'debit';
                    $source_meta['settlement_reason'] = 'Vendor debit partially offset by automatic shipment recovery';

                    // Doctrine: an open debit row's remaining financial_slices must match abs(row.net).
                    // Automatic recovery can partially consume a debit; when it does, residualize
                    // the source debit slices to the still-open amount before persisting the row.
                    $source_meta = self::sync_debit_open_slices_to_net($source_row, $source_meta, $new_abs);

                    $source_meta = self::sync_chain_snapshot($source_meta, [
                        'state' => 'debit',
                        'net' => -1 * $new_abs,
                    ]);
                    $wpdb->query(
                        $wpdb->prepare(
                            "UPDATE " . self::table() . "
                             SET event_type='seller_deduction_partial_offset',
                                 note='Vendor debit partially offset by automatic shipment recovery',
                                 net=%s,
                                 updated_at=%s,
                                 meta=%s
                             WHERE id=%d",
                            number_format(-1 * $new_abs, 2, '.', ''),
                            $now,
                            self::encode_meta($source_meta),
                            $source_id
                        )
                    );
                }
            }

            self::commit_transaction_or_throw($in_tx);
            self::invalidate_vendor_truth_cache($vendor_id);

            return [
                'applied' => $applied_total,
                'target_row_id' => $paid_offset_row_id,
                'sources' => $offset_sources,
                'remaining_available' => $remaining_net,
            ];
        } catch (\Throwable $e) {
            self::rollback_transaction($in_tx);
            return [
                'applied' => 0.0,
                'target_row_id' => $available_row_id,
                'sources' => [],
                'error' => $e->getMessage(),
            ];
        }
    }

    /* -------------------------------------------------------------------------
     * Seller metrics / listing
     * ---------------------------------------------------------------------- */

    public static function sums_for_vendor(int $vendor_id): array
    {
        global $wpdb;

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT state, net, meta
                 FROM " . self::table() . "
                 WHERE vendor_id=%d",
                $vendor_id
            ),
            ARRAY_A
        );

        $out = [
            'pending'         => 0.0,
            'available'       => 0.0,
            'paid'            => 0.0,
            'hold'            => 0.0,
            'debit'           => 0.0,
            'reversed'        => 0.0,
            'offset_consumed' => 0.0,
        ];

        foreach ((array) $rows as $row) {
            $state = (string) ($row['state'] ?? '');
            $net   = (float) ($row['net'] ?? 0);
            $meta  = self::decode_meta($row['meta'] ?? '');
            $mode  = (string) ($meta['payout_mode'] ?? '');

            if ($state === 'paid') {
                if ($mode === 'offset') {
                    $out['offset_consumed'] += $net;
                } else {
                    $out['paid'] += $net;
                }
                continue;
            }

            if (array_key_exists($state, $out)) {
                $out[$state] += $net;
            }
        }

        foreach ($out as $k => $v) {
            $out[$k] = round((float) $v, 2);
        }

        return $out;
    }

    public static function seller_metrics(int $vendor_id, int $epoch_id = 0): array
    {
        global $wpdb;

        $where = "vendor_id = %d";
        $args  = [$vendor_id];

        if ($epoch_id > 0) {
            $where .= " AND id >= %d";
            $args[] = $epoch_id;
        }

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT state, net, meta
                 FROM " . self::table() . "
                 WHERE {$where}",
                ...$args
            ),
            ARRAY_A
        );

        $sums = [
            'pending'         => 0.0,
            'available'       => 0.0,
            'paid'            => 0.0,
            'hold'            => 0.0,
            'debit'           => 0.0,
            'reversed'        => 0.0,
            'offset_consumed' => 0.0,
        ];

        $canonical_available_pool    = 0.0;
        $active_source_exposure_pool = 0.0;
        $active_live_holds           = 0.0;

        foreach ((array) $rows as $row) {
            $state = (string) ($row['state'] ?? '');
            $net   = (float) ($row['net'] ?? 0);
            $meta  = self::sync_chain_snapshot(self::decode_meta($row['meta'] ?? ''), [
                'state' => $state,
                'net'   => $net,
            ]);
            $mode  = (string) ($meta['payout_mode'] ?? '');

            if ($state === 'paid') {
                if ($mode === 'offset') {
                    $sums['offset_consumed'] += $net;
                } else {
                    $sums['paid'] += $net;
                }
                continue;
            }

            if (array_key_exists($state, $sums)) {
                $sums[$state] += $net;
            }

            $role_state = strtoupper((string) ($meta['chain_role_state'] ?? ''));

            if ($state === 'available' && $net > 0) {
                $available_slice        = self::money($meta['chain_available_slice'] ?? $net);
                $target_allocated_slice = self::money($meta['chain_target_allocated_slice'] ?? 0);
                $withdrawn_slice        = self::money($meta['chain_withdrawn_slice'] ?? 0);
                $available_residual     = self::money(max(0.0, $available_slice - $target_allocated_slice - $withdrawn_slice));

                if ($available_residual > 0) {
                    $canonical_available_pool += $available_residual;
                }
            }

            if ($state === 'hold' && $net > 0) {
                $hold_slice = self::money($meta['chain_available_slice'] ?? 0);
                if ($hold_slice <= 0) {
                    $hold_slice = self::money($net);
                }
                if ($hold_slice > 0) {
                    $active_live_holds += $hold_slice;
                }
            }

            if ($state === 'debit' && $net < 0) {
                $remaining = self::money($meta['chain_source_remaining'] ?? abs($net));
                $role_is_open_source = in_array($role_state, ['SOURCE', 'RESET', 'RESOLVED'], true) || $remaining > 0;

                if ($role_is_open_source && $remaining > 0) {
                    $active_source_exposure_pool += $remaining;
                }
            }
        }

        $canonical_available_pool    = self::money($canonical_available_pool);
        $active_source_exposure_pool = self::money($active_source_exposure_pool);
        $active_live_holds           = self::money($active_live_holds);
        $withdrawable_now            = self::money(max(0.0, $canonical_available_pool - $active_source_exposure_pool - $active_live_holds));

        return [
            'pending'                    => self::money($sums['pending']),
            'available'                  => self::money($sums['available']),
            'paid'                       => self::money($sums['paid']),
            'hold'                       => self::money($sums['hold']),
            'debit'                      => self::money($sums['debit']),
            'reversed'                   => self::money($sums['reversed']),
            'offset_consumed'            => self::money($sums['offset_consumed']),
            'canonical_available_pool'   => $canonical_available_pool,
            'active_source_exposure'     => $active_source_exposure_pool,
            'debit_exposure'             => $active_source_exposure_pool,
            'active_debit_exposure'      => $active_source_exposure_pool,
            'active_live_holds'          => $active_live_holds,
            'withdrawable_now'           => $withdrawable_now,
            'residual_withdrawable'      => $withdrawable_now,
            'available_payable'          => $withdrawable_now,
        ];
    }



    public static function list_for_vendor(int $vendor_id, string $state = '', int $epoch_id = 0, int $limit = 200): array
    {
        global $wpdb;

        $limit = max(1, min(500, (int) $limit));

        $where = "vendor_id = %d";
        $args  = [$vendor_id];

        if ($state !== '') {
            $where .= " AND state = %s";
            $args[] = $state;
        }

        if ($epoch_id > 0) {
            $where .= " AND id >= %d";
            $args[] = $epoch_id;
        }

        $args[] = $limit;

        $sql = "SELECT * FROM " . self::table() . " WHERE {$where} ORDER BY id DESC LIMIT %d";
        $rows = (array) $wpdb->get_results($wpdb->prepare($sql, ...$args), ARRAY_A);

        // Doctrine mode: list_for_vendor is a pure reader. No read-time meta normalization.

        return $rows;
    }

    /* -------------------------------------------------------------------------
     * Hold / release
     * ---------------------------------------------------------------------- */

    public static function hold_shipment(int $shipment_id, string $reason = 'issue'): int
    {
        global $wpdb;

        $now = self::now();

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, meta
                 FROM " . self::table() . "
                 WHERE shipment_id=%d
                   AND state IN ('pending','available')
                 ORDER BY id ASC",
                $shipment_id
            ),
            ARRAY_A
        );

        if (!$rows) return 0;

        $count = 0;

        foreach ($rows as $row) {
            $id = (int) ($row['id'] ?? 0);
            if ($id <= 0) continue;

            $meta = self::decode_meta($row['meta'] ?? '');
            $meta['hold_active']       = 'yes';
            $meta['hold_reason']       = $reason;
            $meta['hold_set_at']       = $now;
            $meta['settlement_stage']  = 'hold';
            $meta['settlement_state']  = 'hold';
            $meta['settlement_reason'] = 'Seller earnings were manually placed on hold';
            $meta['state_timestamp']   = $now;

            $wpdb->query(
                $wpdb->prepare(
                    "UPDATE " . self::table() . "
                     SET state='hold',
                         event_type='seller_earnings_hold_set',
                         note=%s,
                         hold_reason=%s,
                         hold_set_at=%s,
                         updated_at=%s,
                         meta=%s
                     WHERE id=%d
                       AND state IN ('pending','available')",
                    'Seller earnings were manually placed on hold',
                    $reason,
                    $now,
                    $now,
                    self::encode_meta($meta),
                    $id
                )
            );

            $count += (int) $wpdb->rows_affected;
        }

        return $count;
    }

    public static function release_hold_shipment(int $shipment_id): int
    {
        global $wpdb;

        $now  = self::now();
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, pending_until, meta
                 FROM " . self::table() . "
                 WHERE shipment_id=%d
                   AND state='hold'
                 ORDER BY id ASC",
                $shipment_id
            ),
            ARRAY_A
        );

        if (!$rows) return 0;

        $count = 0;

        foreach ($rows as $r) {
            $id = (int) ($r['id'] ?? 0);
            if ($id <= 0) continue;

            $pending_until = (string) ($r['pending_until'] ?? '');
            $target = ($pending_until && strtotime($pending_until) <= time()) ? 'available' : 'pending';

            $meta = self::decode_meta($r['meta'] ?? '');
            $meta['hold_released_at'] = $now;
            $meta['hold_active']      = 'no';
            $meta['hold_reason']      = '';
            $meta['settlement_stage'] = $target === 'available' ? 'payout_ready' : 'clearing';
            $meta['settlement_state'] = $target;
            $meta['settlement_reason'] = $target === 'available'
                ? 'Hold released after clearing completed'
                : 'Hold released; row returned to clearing';
            $meta['state_timestamp'] = $now;

            $wpdb->query(
                $wpdb->prepare(
                    "UPDATE " . self::table() . "
                     SET state=%s,
                         event_type=%s,
                         note=%s,
                         hold_reason=NULL,
                         hold_set_at=NULL,
                         updated_at=%s,
                         meta=%s
                     WHERE id=%d
                       AND state='hold'",
                    $target,
                    $target === 'available' ? 'seller_hold_released_available' : 'seller_hold_released_pending',
                    $target === 'available'
                        ? 'Hold released after clearing completed'
                        : 'Hold released; row returned to clearing',
                    $now,
                    self::encode_meta($meta),
                    $id
                )
            );

            $count += (int) $wpdb->rows_affected;
        }

        return $count;
    }

    /* -------------------------------------------------------------------------
     * Debit creation / reversal
     * ---------------------------------------------------------------------- */

    public static function reverse_unpaid_shipment_earnings_amount_idempotent(
        string $unique_key,
        int $shipment_id,
        int $vendor_id,
        float $amount,
        array $extra_meta = []
    ): float {
        global $wpdb;

        $unique_key = trim((string) $unique_key);
        $amount = self::money(max(0.0, (float) $amount));
        if ($unique_key === '' || $shipment_id <= 0 || $vendor_id <= 0 || $amount <= 0) return 0.0;

        $flag_key = '_cc_sp_retbridge_' . md5($unique_key);
        $already = get_post_meta($shipment_id, $flag_key, true);
        if ($already !== '') {
            $j = json_decode((string) $already, true);
            if (is_array($j) && isset($j['reversed_amount'])) {
                return (float) $j['reversed_amount'];
            }
            return 0.0;
        }

        $order_item_id = (int) ($extra_meta['order_item_id'] ?? 0);
        $slice_id = trim((string) ($extra_meta['slice_id'] ?? ''));

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, net, state, event_type, note, order_id, shipment_id, vendor_id, currency, created_at, updated_at, delivered_at, pending_until, meta
                 FROM " . self::table() . "
                 WHERE shipment_id=%d
                   AND vendor_id=%d
                   AND state IN ('pending','hold')
                   AND net > 0
                 ORDER BY id ASC",
                $shipment_id,
                $vendor_id
            ),
            ARRAY_A
        );

        if (!$rows) {
            update_post_meta($shipment_id, $flag_key, wp_json_encode([
                'unique_key'        => $unique_key,
                'requested_amount'  => $amount,
                'did'               => 'none_to_reverse',
                'reversed_amount'   => 0.0,
                'remaining_amount'  => $amount,
                'ts'                => self::now(),
                'extra'             => $extra_meta,
            ]));
            return 0.0;
        }

        $remaining = $amount;
        $sum = 0.0;
        $ids = [];
        $now = self::now();

        foreach ($rows as $r) {
            if ($remaining <= 0.009) {
                break;
            }

            $id    = (int) ($r['id'] ?? 0);
            $net   = self::money(max(0.0, (float) ($r['net'] ?? 0)));
            $state = (string) ($r['state'] ?? 'pending');
            if ($id <= 0 || $net <= 0) continue;

            $meta = self::decode_meta($r['meta'] ?? '');
            $slices = self::row_financial_slices($r, $meta);
            $split = self::take_slices_by_amount($slices, $remaining, [
                'shipment_id' => $shipment_id,
                'slice_id' => $slice_id,
                'order_item_id' => $order_item_id,
            ]);
            $consume = self::money((float) ($split['taken_amount'] ?? 0));
            if ($consume <= 0) {
                continue;
            }

            $taken_slices = (array) ($split['taken_slices'] ?? []);
            $remaining_slices = (array) ($split['remaining_slices'] ?? []);
            $new_net = self::money($net - $consume);

            $bridge = isset($meta['return_bridge']) && is_array($meta['return_bridge']) ? $meta['return_bridge'] : [];
            $taken_qty = 0.0;
            $taken_item_name = '';
            $taken_product_id = 0;
            $taken_item_id = $order_item_id;
            $taken_slice_key = $slice_id;
            foreach ($taken_slices as $slice) {
                $taken_qty += (float) ($slice['qty'] ?? 0);
                if ($taken_item_name === '' && !empty($slice['name'])) {
                    $taken_item_name = (string) $slice['name'];
                }
                if ($taken_product_id <= 0 && !empty($slice['product_id'])) {
                    $taken_product_id = (int) $slice['product_id'];
                }
                if ($taken_item_id <= 0 && !empty($slice['order_item_id'])) {
                    $taken_item_id = (int) $slice['order_item_id'];
                }
                if ($taken_slice_key === '' && !empty($slice['slice_id'])) {
                    $taken_slice_key = (string) $slice['slice_id'];
                }
            }
            $taken_qty = self::slice_qty($taken_qty > 0 ? $taken_qty : ($bridge['qty_refundable'] ?? 1));
            if ($taken_slice_key === '') {
                $taken_slice_key = self::fallback_slice_id($shipment_id, $taken_item_id);
            }

            $history_entry = array_merge($bridge, isset($extra_meta['return_bridge']) && is_array($extra_meta['return_bridge']) ? $extra_meta['return_bridge'] : []);
            $history_entry['original_net'] = $consume;
            $history_entry['original_state'] = $state;
            $history_entry['original_event_type'] = (string) ($r['event_type'] ?? '');
            $history_entry['original_note'] = (string) ($r['note'] ?? '');
            $history_entry['reversed_amount'] = self::money((float) ($history_entry['reversed_amount'] ?? 0) + $consume);
            $history_entry['unique_key'] = $unique_key;
            $history_entry['slice_id'] = $taken_slice_key;
            $history_entry['item_id'] = $taken_item_id;
            $history_entry['product_id'] = $taken_product_id;
            $history_entry['item_name'] = $taken_item_name;
            $history_entry['qty_refundable'] = $taken_qty;
            $history_entry['unit_price_net'] = self::money($consume / max(0.000001, $taken_qty));
            $history_entry['item_price_net'] = $consume;
            $history_entry['seller_impact'] = $consume;
            $history_entry['vendor_impact'] = $consume;

            $history = array_values(isset($meta['historical_return_slices']) && is_array($meta['historical_return_slices']) ? $meta['historical_return_slices'] : []);
            $history[] = array_merge($history_entry, [
                'recorded_at' => $now,
                'state' => 'reversed_unpaid',
            ]);
            $meta['historical_return_slices'] = $history;
            $meta['audit_return_bridge'] = $history_entry;
            $meta = self::set_row_financial_slices($meta, $remaining_slices);
            $meta['reversal_case_id'] = (string) ($extra_meta['case_id'] ?? '');
            $meta['settlement_stage']  = 'reversal';
            $meta['settlement_state']  = ($new_net <= 0.009 || !self::financial_slices_total($remaining_slices)) ? 'reversed' : $state;
            $meta['settlement_reason'] = ($new_net <= 0.009 || !self::financial_slices_total($remaining_slices))
                ? 'Return refund reversed seller earnings before payout'
                : 'Return refund partially reversed seller earnings before payout';
            $meta['state_timestamp']   = $now;

            foreach ($extra_meta as $k => $v) {
                if ($k === 'return_bridge' && is_array($v)) {
                    continue;
                }
                $meta[$k] = $v;
            }
            $meta = self::with_trace_meta($meta, array_merge($extra_meta, [
                'shipment_id' => $shipment_id,
                'order_id' => (int) ($r['order_id'] ?? 0),
                'vendor_id' => $vendor_id,
                'order_item_id' => $order_item_id,
            ]), 'reverse_unpaid_shipment_earnings');

            $row_state_after = ($new_net <= 0.009 || !self::financial_slices_total($remaining_slices)) ? 'reversed' : $state;
            $row_net_after = $row_state_after === 'reversed' ? 0.0 : $new_net;
            $live_columns_after = self::seller_net_columns_for_remaining_amount($row_net_after);

            if ($row_state_after === 'reversed') {
                $meta['return_bridge'] = $history_entry;
                unset($meta['embedded_return_history_only']);
            } else {
                unset($meta['return_bridge']);
                $meta['embedded_return_history_only'] = 1;
            }
            // LAW 087 guard: when a contributor shipment shrinks due to partial unpaid reversal,
            // its legacy target/source trace map must be rebalanced down to the new remaining live net.
            $meta = self::rebalance_legacy_target_trace_meta($meta, $row_net_after);
            $meta = self::sync_chain_snapshot($meta, [
                'state' => $row_state_after,
                'net' => $row_net_after,
            ]);

            if ($row_state_after === 'reversed') {
                $wpdb->query(
                    $wpdb->prepare(
                        "UPDATE " . self::table() . "
                         SET state='reversed',
                             event_type='seller_earnings_reversed_unpaid',
                             note='Return refund reversed seller earnings before payout',
                             gross='0.00',
                             commission='0.00',
                             courier_fees='0.00',
                             reserve='0.00',
                             net='0.00',
                             updated_at=%s,
                             meta=%s
                         WHERE id=%d
                           AND state IN ('pending','hold')",
                        $now,
                        self::encode_meta($meta),
                        $id
                    )
                );
            } else {
                $wpdb->query(
                    $wpdb->prepare(
                        "UPDATE " . self::table() . "
                         SET event_type='seller_earnings_partially_reversed_unpaid',
                             note='Return refund partially reversed seller earnings before payout',
                             gross=%s,
                             commission=%s,
                             courier_fees=%s,
                             reserve=%s,
                             net=%s,
                             updated_at=%s,
                             meta=%s
                         WHERE id=%d
                           AND state IN ('pending','hold')",
                        number_format((float) $live_columns_after['gross'], 2, '.', ''),
                        number_format((float) $live_columns_after['commission'], 2, '.', ''),
                        number_format((float) $live_columns_after['courier_fees'], 2, '.', ''),
                        number_format((float) $live_columns_after['reserve'], 2, '.', ''),
                        number_format((float) $live_columns_after['net'], 2, '.', ''),
                        $now,
                        self::encode_meta($meta),
                        $id
                    )
                );
            }

            if ((int) $wpdb->rows_affected > 0) {
                $ids[] = $id;
                $sum = self::money($sum + $consume);
                $remaining = self::money($remaining - $consume);
            }
        }

        update_post_meta($shipment_id, $flag_key, wp_json_encode([
            'unique_key'        => $unique_key,
            'requested_amount'  => $amount,
            'did'               => $sum > 0 ? 'reversed' : 'none_to_reverse',
            'reversed_amount'   => self::money($sum),
            'remaining_amount'  => max(0.0, self::money($remaining)),
            'row_ids'           => $ids,
            'ts'                => $now,
            'extra'             => $extra_meta,
        ]));

        if ($sum > 0) {
            self::invalidate_vendor_truth_cache($vendor_id);
        }

        return self::money($sum);
    }

    public static function create_vendor_debit_idempotent(
        string $unique_key,
        int $vendor_id,
        int $order_id,
        int $shipment_id,
        float $amount,
        string $note = 'refund',
        array $extra_meta = []
    ): int {
        global $wpdb;

        $unique_key = trim((string) $unique_key);
        if ($unique_key === '') return 0;

        $exists = (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT id FROM " . self::table() . " WHERE unique_key=%s LIMIT 1",
                $unique_key
            )
        );
        if ($exists > 0) return $exists;

        $amount = self::money((float) $amount);
        if ($amount <= 0) return 0;

        $debit_component = sanitize_key((string) ($extra_meta['debit_component'] ?? ''));
        $is_non_commission_debit = !empty($extra_meta['shipping_liability'])
            || !empty($extra_meta['seller_debit_exposure'])
            || !empty($extra_meta['commission_gap'])
            || in_array($debit_component, ['shipping', 'shipping_liability', 'seller_debit_exposure', 'commission_gap'], true);

        $commission_reversed = array_key_exists('commission_reversed_override', $extra_meta)
            ? self::money((float) $extra_meta['commission_reversed_override'])
            : ($is_non_commission_debit
                ? 0.0
                : self::compute_commission_reversal_for_refund(
                    $shipment_id,
                    $order_id,
                    $amount
                ));

        $now = self::now();

        $meta = array_merge([
            'type'                => 'debit',
            'note'                => $note,
            'order_id'            => $order_id,
            'shipment_id'         => $shipment_id,
            'commission_reversed' => $commission_reversed,
            'settlement_stage'    => 'recovery',
            'settlement_state'    => 'debit',
            'settlement_reason'   => 'Seller payout recovered due to refund or adjustment',
            'state_timestamp'     => $now,
        ], $extra_meta);
        $meta = self::with_trace_meta($meta, array_merge($extra_meta, [
            'shipment_id' => $shipment_id,
            'order_id' => $order_id,
            'vendor_id' => $vendor_id,
        ]), !empty($extra_meta['trace_operation']) ? (string) $extra_meta['trace_operation'] : 'create_vendor_debit');

        $bridge = isset($meta['return_bridge']) && is_array($meta['return_bridge']) ? $meta['return_bridge'] : [];

        // CC_BANK_DOCTRINE_NO_FALLBACK_SHIPPING_SLICE_V3
        // Seller shipping liabilities are first-class ledger facts, not item fallbacks.
        // Doctrine forbids `ship:{shipment}:fallback`, so seller shipping charge rows
        // must receive deterministic non-fallback slices.
        $is_shipping_liability_debit = !empty($meta['shipping_liability'])
            || !empty($bridge['is_shipping_component'])
            || strtolower((string) ($bridge['kind'] ?? '')) === 'shipping'
            || strtolower((string) ($debit_component ?? '')) === 'shipping'
            || strtolower((string) ($debit_component ?? '')) === 'shipping_liability'
            || self::money((float) ($meta['shipping_liability_amount'] ?? 0)) > 0;

        $default_slice_id = trim((string) ($bridge['slice_id'] ?? ''));
        if (($default_slice_id === '' || strpos($default_slice_id, ':fallback') !== false) && $is_shipping_liability_debit) {
            $scope = sanitize_key((string) ($meta['shipping_scope'] ?? $bridge['shipping_scope'] ?? 'order'));
            if ($scope === '') { $scope = 'order'; }
            $party = sanitize_key((string) ($meta['shipping_liability_party'] ?? $bridge['shipping_liability_party'] ?? 'seller'));
            if ($party === '') { $party = 'seller'; }
            $default_slice_id = 'ship:' . $shipment_id . ':shipping:' . $scope . ':' . $party;
        }
        if ($default_slice_id === '') {
            $default_slice_id = self::fallback_slice_id($shipment_id, (int) ($bridge['item_id'] ?? 0));
        }

        $financial_slices = !empty($meta['financial_slices']) && is_array($meta['financial_slices'])
            ? (array) $meta['financial_slices']
            : [[
                'slice_id' => $default_slice_id,
                'order_item_id' => (int) ($bridge['item_id'] ?? 0),
                'product_id' => (int) ($bridge['product_id'] ?? 0),
                'name' => (string) ($bridge['item_name'] ?? ($is_shipping_liability_debit ? 'Shipping fee charge' : '')),
                'qty' => self::slice_qty($bridge['qty_refundable'] ?? 1),
                'amount' => $amount,
                'legacy_fallback' => empty($bridge) && !$is_shipping_liability_debit,
            ]];

        if ($is_shipping_liability_debit) {
            foreach ($financial_slices as &$slice) {
                if (!is_array($slice)) {
                    continue;
                }
                $slice_id = trim((string) ($slice['slice_id'] ?? ''));
                if ($slice_id === '' || strpos($slice_id, ':fallback') !== false) {
                    $slice['slice_id'] = $default_slice_id;
                }
                if (empty($slice['name'])) {
                    $slice['name'] = 'Shipping fee charge';
                }
                $slice['legacy_fallback'] = false;
            }
            unset($slice);
        }

        $meta = self::set_row_financial_slices($meta, $financial_slices);

        $meta['source_amount_original'] = self::money($amount);
        $meta['source_amount_previously_recovered'] = self::money(0);
        $meta['source_amount_reopened_total'] = self::money(0);
        $meta['source_amount_reopened_by_this_refund'] = self::money(0);
        $meta['source_amount_still_recovered'] = self::money(0);
        $meta['source_amount_currently_open'] = self::money($amount);

        $meta = self::sync_chain_snapshot($meta, [
            'state' => 'debit',
            'net' => -1 * abs($amount),
        ]);

        $result = $wpdb->insert(self::table(), [
            'unique_key'    => $unique_key,
            'shipment_id'   => $shipment_id,
            'order_id'      => $order_id,
            'vendor_id'     => $vendor_id,
            'currency'      => self::currency(),
            'state'         => 'debit',
            'event_type'    => 'seller_deduction_created',
            'note'          => $note,
            'created_at'    => $now,
            'updated_at'    => $now,
            'delivered_at'  => null,
            'pending_until' => null,
            'gross'         => 0,
            'commission'    => 0,
            'courier_fees'  => 0,
            'reserve'       => 0,
            'net'           => -1 * abs($amount),
            'meta'          => self::encode_meta($meta),
        ]);

        if ($result === false) {
            $exists_after = (int) $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT id FROM " . self::table() . " WHERE unique_key=%s LIMIT 1",
                    $unique_key
                )
            );
            return $exists_after > 0 ? $exists_after : 0;
        }

        $row_id = (int) $wpdb->insert_id;

        if ($row_id > 0) {
            self::invalidate_vendor_truth_cache($vendor_id);
            do_action('caricove_bank_vendor_debit_created', [
                'ledger_row_id' => $row_id,
                'vendor_id'     => $vendor_id,
                'order_id'      => $order_id,
                'shipment_id'   => $shipment_id,
                'currency'      => self::currency(),
                'amount'        => (float) $amount,
                'reference'     => $unique_key,
                'note'          => $note,
            ]);
        }

        return $row_id;
    }



    public static function create_vendor_debit(
        int $vendor_id,
        int $order_id,
        int $shipment_id,
        float $amount,
        string $note = 'refund'
    ): int {
        $unique_key = 'debit:' . $vendor_id . ':order:' . $order_id . ':ship:' . $shipment_id . ':' . time() . ':' . wp_generate_password(4, false, false);

        return self::create_vendor_debit_idempotent(
            $unique_key,
            $vendor_id,
            $order_id,
            $shipment_id,
            $amount,
            $note,
            []
        );
    }

    public static function debit_balance(int $vendor_id): float
    {
        global $wpdb;

        $sum = (float) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COALESCE(SUM(net),0)
                 FROM " . self::table() . "
                 WHERE vendor_id=%d
                   AND state='debit'",
                $vendor_id
            )
        );

        return $sum;
    }

    /* -------------------------------------------------------------------------
     * Mark paid cleanly
     * ---------------------------------------------------------------------- */


    private static function infer_restoration_state_from_row(array $row, array $meta): string
    {
        $state = strtolower((string) ($row['state'] ?? ''));
        if (in_array($state, ['pending', 'available', 'hold'], true)) {
            return $state;
        }

        $bridge = isset($meta['return_bridge']) && is_array($meta['return_bridge']) ? $meta['return_bridge'] : [];
        $original_state = strtolower((string) ($bridge['original_state'] ?? ''));
        if (in_array($original_state, ['pending', 'available', 'hold'], true)) {
            return $original_state;
        }

        $finance_hold = strtolower((string) ($meta['finance_hold'] ?? ''));
        if (in_array($finance_hold, ['yes', '1', 'true'], true)) {
            return 'hold';
        }

        $pending_until = (string) ($row['pending_until'] ?? ($meta['pending_until'] ?? ''));
        if ($pending_until !== '') {
            $ts = strtotime($pending_until);
            if ($ts !== false && $ts > time()) {
                return 'pending';
            }
        }

        return 'available';
    }

    private static function create_available_restoration_row(array $source_row, float $amount, string $reason, array $meta_extra = []): int
    {
        global $wpdb;

        $amount = self::money(max(0.0, (float) $amount));
        if ($amount <= 0) {
            return 0;
        }

        $now = self::now();
        $meta = self::decode_meta($source_row['meta'] ?? '');
        if (!empty($meta_extra['financial_slices']) && is_array($meta_extra['financial_slices'])) {
            $meta = self::set_row_financial_slices($meta, (array) $meta_extra['financial_slices']);
        }
        $meta['settlement_stage']  = 'payout_ready';
        $meta['settlement_state']  = 'available';
        $meta['settlement_reason'] = $reason;
        $meta['state_timestamp']   = $now;
        foreach ($meta_extra as $k => $v) {
            $meta[$k] = $v;
        }
        $meta = self::sync_chain_snapshot($meta, [
            'state' => 'available',
            'net' => $amount,
        ]);

        $insert = [
            'unique_key'    => self::row_unique_key('restore:' . (int) ($source_row['id'] ?? 0)),
            'shipment_id'   => (int) ($source_row['shipment_id'] ?? 0),
            'order_id'      => (int) ($source_row['order_id'] ?? 0),
            'vendor_id'     => (int) ($source_row['vendor_id'] ?? 0),
            'currency'      => (string) ($source_row['currency'] ?? self::currency()),
            'state'         => 'available',
            'event_type'    => 'seller_earnings_restored_after_refund_rollback',
            'note'          => $reason,
            'created_at'    => $now,
            'updated_at'    => $now,
            'delivered_at'  => $source_row['delivered_at'] ?? null,
            'pending_until' => $source_row['pending_until'] ?? null,
            'gross'         => 0,
            'commission'    => 0,
            'courier_fees'  => 0,
            'reserve'       => 0,
            'net'           => $amount,
            'meta'          => self::encode_meta($meta),
        ];

        $result = $wpdb->insert(self::table(), $insert);
        if ($result === false) {
            return 0;
        }

        return (int) $wpdb->insert_id;
    }
    private static function release_offset_consumed_row_as_available(int $target_row_id, float $amount, int $source_debit_row_id, string $case_id = ''): array
    {
        global $wpdb;

        $target_row_id = max(0, $target_row_id);
        $amount = round(max(0.0, (float) $amount), 2);
        if ($target_row_id <= 0 || $amount <= 0) {
            return ['ok' => false, 'error' => 'Invalid offset target release request.'];
        }

        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM " . self::table() . " WHERE id=%d LIMIT 1 FOR UPDATE",
                $target_row_id
            ),
            ARRAY_A
        );

        if (!$row) {
            return ['ok' => false, 'error' => 'Offset target row could not be found.'];
        }

        $current_net = round(max(0.0, (float) ($row['net'] ?? 0)), 2);
        if ($current_net <= 0.0) {
            return ['ok' => false, 'error' => 'Offset target row has no remaining consumed value to release.'];
        }
        if ($amount - $current_net > 0.009) {
            return ['ok' => false, 'error' => 'Offset target release exceeds the row balance.'];
        }

        $now = self::now();
        $meta = self::decode_meta($row['meta'] ?? '');
        $offset_sources = isset($meta['offset_sources']) && is_array($meta['offset_sources']) ? array_values($meta['offset_sources']) : [];
        $remaining_to_release = $amount;
        $normalized_sources = [];

        foreach ($offset_sources as $entry) {
            if (!is_array($entry)) {
                continue;
            }
            $entry_amount = round(max(0.0, (float) ($entry['amount'] ?? 0)), 2);
            if ($entry_amount <= 0) {
                continue;
            }

            if ((int) ($entry['debit_row_id'] ?? 0) === $source_debit_row_id && $remaining_to_release > 0) {
                $consume = min($entry_amount, $remaining_to_release);
                $entry_amount = round($entry_amount - $consume, 2);
                $remaining_to_release = round($remaining_to_release - $consume, 2);
            }

            if ($entry_amount > 0) {
                $entry['amount'] = $entry_amount;
                $normalized_sources[] = $entry;
            }
        }

        if ($remaining_to_release > 0.009) {
            return ['ok' => false, 'error' => 'Offset target release could not be matched to the original debit source.'];
        }

        $remaining_net = round($current_net - $amount, 2);
        $meta['offset_sources'] = array_values($normalized_sources);
        $meta['linked_source_shipments'] = array_values(array_unique(array_filter(array_map(static function ($entry) {
            return (int) ($entry['source_shipment_id'] ?? 0);
        }, $normalized_sources))));
        $meta['offset_release_case_id'] = $case_id;
        $meta['offset_release_amount'] = round((float) ($meta['offset_release_amount'] ?? 0) + $amount, 2);
        $meta['offset_release_at'] = $now;
        $meta['state_timestamp'] = $now;

        if ($remaining_net <= 0) {
            $meta['settlement_stage'] = 'reversal';
            $meta['settlement_state'] = 'reversed';
            $meta['settlement_reason'] = 'Refund rollback released all seller earnings previously consumed by debit recovery';
            $meta = self::sync_chain_snapshot($meta, [
                'state' => 'reversed',
                'net' => 0.0,
                'payout_mode' => 'offset',
            ]);

            $updated = $wpdb->query(
                $wpdb->prepare(
                    "UPDATE " . self::table() . "
                     SET state='reversed',
                         event_type='seller_offset_released',
                         note='Refund rollback released seller earnings previously consumed by debit recovery',
                         net=0,
                         updated_at=%s,
                         meta=%s
                     WHERE id=%d",
                    $now,
                    self::encode_meta($meta),
                    $target_row_id
                )
            );
        } else {
            $meta['settlement_stage'] = 'recovery';
            $meta['settlement_state'] = 'paid';
            $meta['settlement_reason'] = 'Refund rollback partially released seller earnings previously consumed by debit recovery';
            $meta = self::sync_chain_snapshot($meta, [
                'state' => 'paid',
                'net' => $remaining_net,
                'payout_mode' => 'offset',
            ]);

            $updated = $wpdb->query(
                $wpdb->prepare(
                    "UPDATE " . self::table() . "
                     SET event_type='seller_offset_partially_released',
                         note='Refund rollback partially released seller earnings previously consumed by debit recovery',
                         net=%s,
                         updated_at=%s,
                         meta=%s
                     WHERE id=%d",
                    number_format($remaining_net, 2, '.', ''),
                    $now,
                    self::encode_meta($meta),
                    $target_row_id
                )
            );
        }

        if ($updated === false) {
            return ['ok' => false, 'error' => 'Failed updating offset-consumed row during rollback.'];
        }

        $restore_row_id = self::create_available_restoration_row(
            $row,
            $amount,
            'Refund rollback restored seller earnings previously used for debit recovery',
            [
                'rollback_source_case_id' => $case_id,
                'released_from_row_id'    => $target_row_id,
                'released_from_debit_id'  => $source_debit_row_id,
            ]
        );

        if ($restore_row_id <= 0) {
            return ['ok' => false, 'error' => 'Failed creating restored available balance during rollback.'];
        }

        return [
            'ok' => true,
            'restored_amount' => $amount,
            'restore_row_id' => $restore_row_id,
            'target_row_id' => $target_row_id,
        ];
    }




    private static function consume_offset_sources_for_amount(array $offset_sources, float $amount, array $filter = []): array
    {
        $amount = round(max(0.0, (float) $amount), 2);
        if ($amount <= 0) {
            return [
                'ok' => true,
                'consumed' => [],
                'remaining_sources' => array_values($offset_sources),
                'remaining_amount' => 0.0,
                'match_mode' => 'none',
            ];
        }

        $consume_pass = static function (array $sources, float $requested, array $active_filter, string $mode): array {
            $remaining = round(max(0.0, (float) $requested), 2);
            $consumed = [];
            $remaining_sources = [];

            foreach ((array) $sources as $entry) {
                if (!is_array($entry)) {
                    continue;
                }
                $entry_amount = round(max(0.0, (float) ($entry['amount'] ?? 0)), 2);
                if ($entry_amount <= 0) {
                    continue;
                }

                $match = true;
                $has_target_slice_filter = !empty($active_filter['target_slice_id']);
                if ($has_target_slice_filter) {
                    // CC_BANK_DOCTRINE_STRICT_UNWIND_SLICE_ONLY
                    // The canonical unwind edge is the target financial slice. Some offset
                    // edges intentionally have target_order_item_id=0 when the target row
                    // was created as a recovery slice, so requiring order_item_id after a
                    // slice match forces a dirty fallback. Ultra-strict doctrine wants the
                    // match mode to remain strict_target_slice, not edge fallback.
                    $match = ((string) ($entry['target_slice_id'] ?? '') === (string) $active_filter['target_slice_id']);
                } elseif (!empty($active_filter['target_order_item_id'])) {
                    $match = ((int) ($entry['target_order_item_id'] ?? 0) === (int) $active_filter['target_order_item_id']);
                }

                if ($remaining > 0 && $match) {
                    $take = round(min($entry_amount, $remaining), 2);
                    if ($take > 0) {
                        $consumed_entry = $entry;
                        $consumed_entry['amount'] = $take;
                        $consumed_entry['match_mode'] = $mode;
                        $consumed[] = $consumed_entry;
                        $entry_amount = round($entry_amount - $take, 2);
                        $remaining = round($remaining - $take, 2);
                    }
                }

                if ($entry_amount > 0) {
                    $entry['amount'] = $entry_amount;
                    $remaining_sources[] = $entry;
                }
            }

            return [
                'ok' => $remaining <= 0.009,
                'consumed' => array_values($consumed),
                'remaining_sources' => array_values($remaining_sources),
                'remaining_amount' => round(max(0.0, $remaining), 2),
                'match_mode' => $mode,
            ];
        };

        $has_filter = !empty($filter['target_slice_id']) || !empty($filter['target_order_item_id']);
        $strict = $consume_pass($offset_sources, $amount, $filter, 'strict_target_slice');
        if (!empty($strict['ok']) || !$has_filter) {
            return $strict;
        }

        // CC_BANK_DOCTRINE_NO_UNWIND_EDGE_FALLBACK
        // Ultra-strict doctrine forbids fallback unwind matching. If the target slice does
        // not match, the write must fail closed instead of consuming unrelated stored edges.
        return [
            'ok' => false,
            'consumed' => [],
            'remaining_sources' => array_values($offset_sources),
            'remaining_amount' => self::money((float) ($strict['remaining_amount'] ?? $amount)),
            'match_mode' => 'strict_target_slice_failed',
        ];
    }

    private static function reverse_offset_target_row_after_refund(int $target_row_id, float $amount, string $case_id, array $context = []): array
    {
        global $wpdb;

        $target_row_id = max(0, $target_row_id);
        $amount = self::money(max(0.0, (float) $amount));
        if ($target_row_id <= 0 || $amount <= 0) {
            return ['ok' => false, 'error' => 'Invalid target refund unwind request.'];
        }

        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM " . self::table() . " WHERE id=%d LIMIT 1 FOR UPDATE",
                $target_row_id
            ),
            ARRAY_A
        );

        if (!$row) {
            return ['ok' => false, 'error' => 'Refund target row could not be found.'];
        }

        $current_net = self::money(max(0.0, (float) ($row['net'] ?? 0)));
        if ($current_net <= 0) {
            return ['ok' => false, 'error' => 'Refund target row has no active recovery amount left.'];
        }
        if ($amount - $current_net > 0.009) {
            return ['ok' => false, 'error' => 'Refund target unwind exceeds the target row balance.'];
        }

        $meta = self::decode_meta($row['meta'] ?? '');
        $payout_mode = strtolower((string) ($meta['payout_mode'] ?? ''));
        if ($payout_mode !== 'offset') {
            return ['ok' => false, 'error' => 'Target row is not an offset-recovery row.'];
        }

        $offset_sources = isset($meta['offset_sources']) && is_array($meta['offset_sources']) ? array_values($meta['offset_sources']) : [];
        if (!$offset_sources) {
            return ['ok' => false, 'error' => 'Target row has no exact offset source mapping.'];
        }

        $filter = [
            'target_slice_id' => (string) ($context['slice_id'] ?? ''),
            'target_order_item_id' => (int) ($context['order_item_id'] ?? 0),
        ];
        $consumed = self::consume_offset_sources_for_amount($offset_sources, $amount, $filter);
        if (empty($consumed['ok'])) {
            return [
                'ok' => false,
                'error' => 'Target row could not be matched cleanly to source debit rows.',
                'target_row_id' => $target_row_id,
                'requested_amount' => $amount,
                'remaining_unmatched' => self::money((float) ($consumed['remaining_amount'] ?? 0)),
                'match_mode' => (string) ($consumed['match_mode'] ?? ''),
            ];
        }

        $now = self::now();
        $remaining_net = self::money($current_net - $amount);
        $historical = array_values((array) ($meta['historical_offset_sources_unwound'] ?? []));
        $consumed_entries = [];
        $slice_allocations = [];
        foreach ((array) ($consumed['consumed'] ?? []) as $edge) {
            if (!is_array($edge)) {
                continue;
            }
            $edge['refund_case_id'] = $case_id;
            $edge['refund_unwound_at'] = $now;
            $consumed_entries[] = $edge;
            $target_slice_id = (string) ($edge['target_slice_id'] ?? '');
            if ($target_slice_id !== '') {
                $slice_allocations[$target_slice_id] = self::money((float) ($slice_allocations[$target_slice_id] ?? 0) + (float) ($edge['amount'] ?? 0));
            }
        }

        $meta['offset_sources'] = array_values((array) ($consumed['remaining_sources'] ?? []));
        $meta['linked_source_shipments'] = array_values(array_unique(array_filter(array_map(static function ($entry) {
            return (int) ($entry['source_shipment_id'] ?? 0);
        }, $meta['offset_sources']))));
        $meta['historical_offset_sources_unwound'] = array_merge($historical, $consumed_entries);
        $meta['refund_target_unwind_case_id'] = $case_id;
        $meta['refund_target_unwind_amount'] = self::money((float) ($meta['refund_target_unwind_amount'] ?? 0) + $amount);
        $meta['refund_target_unwind_at'] = $now;
        $meta['refund_target_unwind_match_mode'] = (string) ($consumed['match_mode'] ?? '');
        if (!empty($consumed['fallback_reason'])) {
            $meta['refund_target_unwind_fallback_reason'] = (string) $consumed['fallback_reason'];
        }
        $meta['state_timestamp'] = $now;
        foreach ($context as $k => $v) {
            if ($k === 'return_bridge' && is_array($v)) {
                $existing = isset($meta['return_bridge']) && is_array($meta['return_bridge']) ? $meta['return_bridge'] : [];
                $meta['return_bridge'] = array_merge($existing, $v);
                continue;
            }
            $meta[$k] = $v;
        }
        $meta = self::with_trace_meta($meta, array_merge($context, [
            'refund_case_id' => $case_id,
            'case_id' => $case_id,
            'shipment_id' => (int) ($row['shipment_id'] ?? 0),
            'order_id' => (int) ($row['order_id'] ?? 0),
        ]), 'reverse_offset_target_after_refund');

        $split_result = self::split_row_financial_slices($row, $amount, $slice_allocations);
        $remaining_slices = (array) ($split_result['remaining_slices'] ?? []);
        $meta = self::set_row_financial_slices($meta, $remaining_slices);

        if ($remaining_net <= 0) {
            $meta['settlement_stage'] = 'reversal';
            $meta['settlement_state'] = 'reversed';
            $meta['settlement_reason'] = 'Refund invalidated seller earnings previously used for debit recovery';
            $meta = self::sync_chain_snapshot($meta, [
                'state' => 'reversed',
                'net' => 0.0,
                'payout_mode' => 'offset',
            ]);

            $updated = $wpdb->query(
                $wpdb->prepare(
                    "UPDATE " . self::table() . "
                     SET state='reversed',
                         event_type='seller_offset_reversed_by_refund',
                         note='Refund invalidated seller earnings previously used for debit recovery',
                         net=0,
                         updated_at=%s,
                         meta=%s
                     WHERE id=%d",
                    $now,
                    self::encode_meta($meta),
                    $target_row_id
                )
            );
        } else {
            $meta['settlement_stage'] = 'recovery';
            $meta['settlement_state'] = 'paid';
            $meta['settlement_reason'] = 'Refund partially invalidated seller earnings previously used for debit recovery';
            $meta = self::sync_chain_snapshot($meta, [
                'state' => 'paid',
                'net' => $remaining_net,
                'payout_mode' => 'offset',
            ]);

            $updated = $wpdb->query(
                $wpdb->prepare(
                    "UPDATE " . self::table() . "
                     SET event_type='seller_offset_partially_reversed_by_refund',
                         note='Refund partially invalidated seller earnings previously used for debit recovery',
                         net=%s,
                         updated_at=%s,
                         meta=%s
                     WHERE id=%d",
                    number_format($remaining_net, 2, '.', ''),
                    $now,
                    self::encode_meta($meta),
                    $target_row_id
                )
            );
        }

        if ($updated === false) {
            return ['ok' => false, 'error' => 'Failed updating target recovery row during refund unwind.'];
        }

        return [
            'ok' => true,
            'target_row_id' => $target_row_id,
            'target_shipment_id' => (int) ($row['shipment_id'] ?? 0),
            'target_order_id' => (int) ($row['order_id'] ?? 0),
            'unwound_amount' => $amount,
            'remaining_net' => max(0.0, $remaining_net),
            'consumed_sources' => array_values((array) ($consumed['consumed'] ?? [])),
        ];
    }

    private static function reopen_debit_source_after_target_refund(int $source_debit_row_id, int $target_row_id, float $amount, string $case_id, array $context = []): array
    {
        global $wpdb;

        $source_debit_row_id = max(0, $source_debit_row_id);
        $target_row_id = max(0, $target_row_id);
        $amount = self::money(max(0.0, (float) $amount));
        if ($source_debit_row_id <= 0 || $target_row_id <= 0 || $amount <= 0) {
            return ['ok' => false, 'error' => 'Invalid debit reopen request.'];
        }

        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM " . self::table() . " WHERE id=%d LIMIT 1 FOR UPDATE",
                $source_debit_row_id
            ),
            ARRAY_A
        );

        if (!$row) {
            return ['ok' => false, 'error' => 'Debit source row could not be found.'];
        }

        $meta = self::decode_meta($row['meta'] ?? '');
        $offset_targets = isset($meta['offset_targets']) && is_array($meta['offset_targets']) ? array_values($meta['offset_targets']) : [];
        $source_offset_applied_before = self::target_edges_total($offset_targets);
        $source_slices_before = self::row_financial_slices($row, $meta);
        $source_slice_total_before = self::financial_slices_total($source_slices_before);
        $current_abs_seed = self::money(abs((float) ($row['net'] ?? 0)));
        $source_bridge = isset($meta['return_bridge']) && is_array($meta['return_bridge']) ? $meta['return_bridge'] : [];
        $source_bridge_amount = 0.0;
        if ($source_bridge) {
            $source_bridge_amount = self::money(max(
                0.0,
                (float) ($source_bridge['seller_impact'] ?? 0),
                (float) ($source_bridge['vendor_impact'] ?? 0),
                (float) ($source_bridge['item_price_net'] ?? 0),
                (float) ($source_bridge['original_net'] ?? 0)
            ));
        }

        // Canonical original exposure is the current open debt plus whatever target
        // edges still recover it. Do not trust legacy chain_source_slice or dirty
        // financial_slices when reopening; those are exactly what caused doubled rows.
        $source_original_amount = self::money($current_abs_seed + $source_offset_applied_before);
        if ($source_original_amount <= 0) {
            $source_original_amount = self::money(max(
                0.0,
                (float) ($meta['source_amount_original'] ?? 0),
                $source_bridge_amount,
                $source_slice_total_before
            ));
        }
        if (!empty($meta['source_amount_original'])) {
            $explicit_source_original = self::money((float) $meta['source_amount_original']);
            if ($source_original_amount <= 0 || abs($explicit_source_original - $source_original_amount) <= 0.02) {
                $source_original_amount = max($source_original_amount, $explicit_source_original);
            }
        }
        $source_case_id_before = (string) ($meta['case_id'] ?? '');
        $source_order_item_before = (int) ($meta['order_item_id'] ?? 0);
        $source_slice_id_before = (string) ($meta['slice_id'] ?? '');
        $remaining_to_reopen = $amount;
        $normalized_targets = [];

        foreach ($offset_targets as $entry) {
            if (!is_array($entry)) {
                continue;
            }
            $entry_amount = self::money(max(0.0, (float) ($entry['amount'] ?? 0)));
            if ($entry_amount <= 0) {
                continue;
            }

            $entry_target_row_id = (int) ($entry['target_row_id'] ?? 0);
            $match = ($entry_target_row_id === $target_row_id);

            // Some legacy split edges were written before target_row_id was consistently
            // populated on both sides. If the exact row id is missing, fall back to the
            // target shipment / source slice lineage that came from the consumed target edge.
            if (!$match && $entry_target_row_id <= 0 && !empty($context['target_shipment_id'])) {
                $match = ((int) ($entry['target_shipment_id'] ?? 0) === (int) $context['target_shipment_id']);
            }
            if ($match && !empty($context['slice_id']) && !empty($entry['target_slice_id'])) {
                $match = ((string) $entry['target_slice_id'] === (string) $context['slice_id']);
            }
            if ($match && !empty($context['source_slice_id']) && !empty($entry['source_slice_id'])) {
                $match = ((string) $entry['source_slice_id'] === (string) $context['source_slice_id']);
            }

            if ($match && $remaining_to_reopen > 0) {
                $consume = self::money(min($entry_amount, $remaining_to_reopen));
                $entry_amount = self::money($entry_amount - $consume);
                $remaining_to_reopen = self::money($remaining_to_reopen - $consume);
            }

            if ($entry_amount > 0) {
                $entry['amount'] = $entry_amount;
                $normalized_targets[] = $entry;
            }
        }

        if ($remaining_to_reopen > 0.009) {
            return ['ok' => false, 'error' => 'Debit reopen could not be matched to the original target row.'];
        }

        $current_abs = self::money(abs((float) ($row['net'] ?? 0)));
        $new_abs = self::money($current_abs + $amount);
        $now = self::now();
        $still_recovered_after_reopen = self::target_edges_total($normalized_targets);
        $source_original_amount = max(
            $source_original_amount,
            self::money($new_abs + $still_recovered_after_reopen)
        );

        $meta["offset_targets"] = array_values($normalized_targets);
        $reopen_event = [
            'target_row_id' => $target_row_id,
            'target_shipment_id' => (int) ($context['target_shipment_id'] ?? 0),
            'target_order_id' => (int) ($context['target_order_id'] ?? 0),
            'target_slice_id' => (string) ($context['slice_id'] ?? ''),
            'source_slice_id' => (string) ($context['source_slice_id'] ?? $source_slice_id_before),
            'source_order_item_id' => (int) ($context['source_order_item_id'] ?? $source_order_item_before),
            'amount' => $amount,
            'source_original_amount' => self::money($source_original_amount),
            'source_still_recovered_after_reopen' => self::money($still_recovered_after_reopen),
            'source_currently_open_after_reopen' => self::money($new_abs),
            'case_id' => $case_id,
            'at' => $now,
        ];
        $meta["historical_offset_targets_reopened"] = self::normalize_reopen_history(array_merge(
            array_values(isset($meta["historical_offset_targets_reopened"]) && is_array($meta["historical_offset_targets_reopened"]) ? $meta["historical_offset_targets_reopened"] : []),
            [$reopen_event]
        ), self::money($source_original_amount));
        $meta["source_reopen_events"] = self::normalize_reopen_history(array_merge(
            array_values(isset($meta["source_reopen_events"]) && is_array($meta["source_reopen_events"]) ? $meta["source_reopen_events"] : []),
            [$reopen_event]
        ), self::money($source_original_amount));
        $historical_reopened_total = self::money(min(
            self::money($source_original_amount),
            self::target_edges_total($meta["historical_offset_targets_reopened"])
        ));
        $meta["debit_offset_applied"] = self::money(max(0.0, $still_recovered_after_reopen));
        $meta["source_amount_original"] = self::money($source_original_amount);
        $meta["source_amount_previously_recovered"] = self::money($source_offset_applied_before);
        $meta["source_amount_reopened_total"] = self::money($historical_reopened_total);
        $meta["chain_historical_target_reopen_total"] = self::money($historical_reopened_total);
        $meta['source_amount_reopened_by_this_refund'] = $amount;
        $meta['source_amount_still_recovered'] = self::money($still_recovered_after_reopen);
        $meta['source_amount_currently_open'] = self::money($new_abs);
        $meta['source_reopen_last_target_row_id'] = $target_row_id;
        $meta['source_reopen_last_target_shipment_id'] = (int) ($context['target_shipment_id'] ?? 0);
        $meta['source_reopen_last_case_id'] = $case_id;
        $meta['settlement_stage'] = 'recovery';
        $meta['settlement_state'] = 'debit';
        $meta['settlement_reason'] = 'Refunded recovery shipment reopened this debit exposure';
        $meta['state_timestamp'] = $now;
        $meta['refund_target_reopen_case_id'] = $case_id;
        $meta['reopen_trigger_context'] = [
            'case_id' => $case_id,
            'target_row_id' => $target_row_id,
            'target_shipment_id' => (int) ($context['target_shipment_id'] ?? 0),
            'target_order_id' => (int) ($context['target_order_id'] ?? 0),
            'target_slice_id' => (string) ($context['slice_id'] ?? ''),
            'target_order_item_id' => (int) ($context['order_item_id'] ?? 0),
            'source_slice_id' => (string) ($context['source_slice_id'] ?? $source_slice_id_before),
            'source_order_item_id' => (int) ($context['source_order_item_id'] ?? $source_order_item_before),
            'reopened_amount' => $amount,
            'at' => $now,
        ];
        if (isset($context['return_bridge']) && is_array($context['return_bridge'])) {
            $meta['reopen_trigger_return_bridge'] = $context['return_bridge'];
        }
        foreach ($context as $k => $v) {
            if (in_array($k, ['case_id', 'order_item_id', 'slice_id', 'return_bridge'], true)) {
                continue;
            }
            $meta[$k] = $v;
        }
        if ($source_case_id_before !== '') {
            $meta['case_id'] = $source_case_id_before;
        }
        if ($source_order_item_before > 0) {
            $meta['order_item_id'] = $source_order_item_before;
        }
        if ($source_slice_id_before !== '') {
            $meta['slice_id'] = $source_slice_id_before;
        }
        if ($source_bridge) {
            $meta['return_bridge'] = $source_bridge;
        }
        $meta = self::with_trace_meta($meta, array_merge($context, [
            'refund_case_id' => $case_id,
            'case_id' => $case_id,
            'shipment_id' => (int) ($row['shipment_id'] ?? 0),
            'order_id' => (int) ($row['order_id'] ?? 0),
        ]), 'reopen_debit_source_after_target_refund');

        $existing_slices = $current_abs > 0.009
            ? self::scale_financial_slices_to_total(self::row_financial_slices($row, $meta), $current_abs, (int) ($row['shipment_id'] ?? 0))
            : [];
        $source_bridge_for_slice = $source_bridge ?: (isset($meta['return_bridge']) && is_array($meta['return_bridge']) ? $meta['return_bridge'] : []);
        $meta = self::set_row_financial_slices($meta, self::add_amount_to_slice_map($existing_slices, [
            'shipment_id' => (int) ($row['shipment_id'] ?? 0),
            'slice_id' => (string) ($context['source_slice_id'] ?? ($source_bridge_for_slice['slice_id'] ?? self::fallback_slice_id((int) ($row['shipment_id'] ?? 0), (int) ($context['source_order_item_id'] ?? $source_order_item_before)))),
            'order_item_id' => (int) ($context['source_order_item_id'] ?? $source_order_item_before ?? ($source_bridge_for_slice['item_id'] ?? 0)),
            'product_id' => (int) ($source_bridge_for_slice['product_id'] ?? 0),
            'name' => (string) ($source_bridge_for_slice['item_name'] ?? ''),
            'qty' => max(0.000001, (float) (($amount > 0 && !empty($source_bridge_for_slice['seller_impact'])) ? ((float) ($source_bridge_for_slice['qty_refundable'] ?? 1) * ($amount / max(0.000001, (float) ($source_bridge_for_slice['seller_impact'] ?? $amount)))) : 1)),
        ], $amount));

        $meta = self::sync_chain_snapshot($meta, [
            'state' => 'debit',
            'net' => -1 * $new_abs,
        ]);

        $event_type = $current_abs <= 0.009
            ? 'seller_deduction_reopened_by_refunded_target'
            : 'seller_deduction_partially_reopened_by_refunded_target';
        $note = $current_abs <= 0.009
            ? 'Refunded recovery shipment reopened seller debit exposure'
            : 'Refunded recovery shipment increased remaining seller debit exposure';

        $updated = $wpdb->query(
            $wpdb->prepare(
                "UPDATE " . self::table() . "
                 SET state='debit',
                     event_type=%s,
                     note=%s,
                     net=%s,
                     updated_at=%s,
                     meta=%s
                 WHERE id=%d",
                $event_type,
                $note,
                number_format(-1 * $new_abs, 2, '.', ''),
                $now,
                self::encode_meta($meta),
                $source_debit_row_id
            )
        );

        if ($updated === false) {
            return ['ok' => false, 'error' => 'Failed reopening debit source row after target refund.'];
        }

        return [
            'ok' => true,
            'source_debit_row_id' => $source_debit_row_id,
            'source_shipment_id' => (int) ($row['shipment_id'] ?? 0),
            'source_order_id' => (int) ($row['order_id'] ?? 0),
            'reopened_amount' => $amount,
            'new_abs' => $new_abs,
            'source_amount_original' => self::money($source_original_amount),
            'source_amount_still_recovered' => self::money($still_recovered_after_reopen),
            'source_amount_currently_open' => self::money($new_abs),
        ];
    }


    private static function restore_offset_target_row_after_refund_rollback(int $target_row_id, int $source_debit_row_id, float $amount, string $case_id): array
    {
        global $wpdb;

        $target_row_id = max(0, $target_row_id);
        $source_debit_row_id = max(0, $source_debit_row_id);
        $amount = self::money($amount);

        if ($target_row_id <= 0 || $source_debit_row_id <= 0 || $amount <= 0) {
            return ['ok' => false, 'error' => 'Invalid refund-target restore request.'];
        }

        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM " . self::table() . " WHERE id=%d LIMIT 1 FOR UPDATE",
                $target_row_id
            ),
            ARRAY_A
        );

        if (!$row) {
            return ['ok' => false, 'error' => 'Refund target row could not be found for rollback.'];
        }

        $meta = self::decode_meta($row['meta'] ?? '');
        $historical = array_values((array) ($meta['historical_offset_sources_unwound'] ?? []));
        $remaining = $amount;
        $restored_entries = [];
        $remaining_historical = [];

        foreach ($historical as $entry) {
            if (!is_array($entry)) {
                continue;
            }

            $entry_amount = self::money($entry['amount'] ?? 0);
            if ($entry_amount <= 0) {
                continue;
            }

            $matches_case = (string) ($entry['refund_case_id'] ?? '') === $case_id;
            $matches_source = (int) ($entry['debit_row_id'] ?? 0) === $source_debit_row_id;

            if ($matches_case && $matches_source && $remaining > 0) {
                $consume = self::money(min($entry_amount, $remaining));
                if ($consume > 0) {
                    $restored = $entry;
                    $restored['amount'] = $consume;
                    $restored['rollback_case_id'] = $case_id;
                    $restored['rollback_restored_at'] = self::now();
                    unset($restored['refund_unwound_at']);
                    $restored_entries[] = $restored;

                    $entry_amount = self::money($entry_amount - $consume);
                    $remaining = self::money($remaining - $consume);
                }
            }

            if ($entry_amount > 0) {
                $entry['amount'] = $entry_amount;
                $remaining_historical[] = $entry;
            }
        }

        if ($remaining > 0.009) {
            return ['ok' => false, 'error' => 'Refund target rollback could not be matched to historical unwound source edges.'];
        }

        $offset_sources = self::normalize_source_edges($meta['offset_sources'] ?? []);
        foreach ($restored_entries as $restored) {
            $matched = false;
            foreach ($offset_sources as $idx => $existing) {
                if ((int) ($existing['debit_row_id'] ?? 0) === (int) ($restored['debit_row_id'] ?? 0)) {
                    $offset_sources[$idx]['amount'] = self::money(($existing['amount'] ?? 0) + ($restored['amount'] ?? 0));
                    $matched = true;
                    break;
                }
            }
            if (!$matched) {
                $offset_sources[] = $restored;
            }
        }

        $offset_sources = self::normalize_source_edges($offset_sources);
        $now = self::now();
        $current_net = self::max0($row['net'] ?? 0);
        $new_net = self::money($current_net + $amount);

        $meta['offset_sources'] = $offset_sources;
        $meta['linked_source_shipments'] = array_values(array_unique(array_filter(array_map(static function ($entry) {
            return (int) ($entry['source_shipment_id'] ?? 0);
        }, $offset_sources))));
        $meta['historical_offset_sources_unwound'] = $remaining_historical;
        $meta['historical_offset_sources_reapplied'] = array_merge(
            array_values((array) ($meta['historical_offset_sources_reapplied'] ?? [])),
            $restored_entries
        );
        $meta['refund_target_unwind_rollback_case_id'] = $case_id;
        $meta['refund_target_unwind_rollback_amount'] = self::money(($meta['refund_target_unwind_rollback_amount'] ?? 0) + $amount);
        $meta['settlement_stage'] = 'recovery';
        $meta['settlement_state'] = 'paid';
        $meta['settlement_reason'] = 'Refund rollback reapplied seller earnings to prior debit recovery';
        $meta['state_timestamp'] = $now;
        $meta['payout_mode'] = 'offset';
        $meta = self::sync_chain_snapshot($meta, [
            'state' => 'paid',
            'net' => $new_net,
            'payout_mode' => 'offset',
        ]);

        $event_type = $current_net <= 0.009
            ? 'seller_offset_restored_after_refund_rollback'
            : 'seller_offset_partially_restored_after_refund_rollback';
        $note = $current_net <= 0.009
            ? 'Refund rollback restored this shipment as an active debit-recovery contributor'
            : 'Refund rollback increased this shipment\'s active debit-recovery contribution';

        $updated = $wpdb->query(
            $wpdb->prepare(
                "UPDATE " . self::table() . "
                 SET state='paid',
                     event_type=%s,
                     note=%s,
                     net=%s,
                     updated_at=%s,
                     meta=%s
                 WHERE id=%d",
                $event_type,
                $note,
                number_format($new_net, 2, '.', ''),
                $now,
                self::encode_meta($meta),
                $target_row_id
            )
        );

        if ($updated === false) {
            return ['ok' => false, 'error' => 'Failed restoring target recovery row during refund rollback.'];
        }

        return [
            'ok' => true,
            'target_row_id' => $target_row_id,
            'restored_amount' => $amount,
            'restored_sources' => $restored_entries,
        ];
    }

    private static function reclose_debit_source_after_target_refund_rollback(int $source_debit_row_id, int $target_row_id, float $amount, string $case_id): array
    {
        global $wpdb;

        $source_debit_row_id = max(0, $source_debit_row_id);
        $target_row_id = max(0, $target_row_id);
        $amount = self::money($amount);

        if ($source_debit_row_id <= 0 || $target_row_id <= 0 || $amount <= 0) {
            return ['ok' => false, 'error' => 'Invalid debit reclose request.'];
        }

        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM " . self::table() . " WHERE id=%d LIMIT 1 FOR UPDATE",
                $source_debit_row_id
            ),
            ARRAY_A
        );

        if (!$row) {
            return ['ok' => false, 'error' => 'Debit source row could not be found for rollback.'];
        }

        $current_abs = self::money(abs((float) ($row['net'] ?? 0)));
        if ($current_abs + 0.009 < $amount) {
            return ['ok' => false, 'error' => 'Refund rollback would over-close source debt that has already been re-covered by later shipments.'];
        }

        $meta = self::decode_meta($row['meta'] ?? '');
        $historical = array_values((array) ($meta['historical_offset_targets_reopened'] ?? []));
        $remaining = $amount;
        $remaining_historical = [];

        foreach ($historical as $entry) {
            if (!is_array($entry)) {
                continue;
            }

            $entry_amount = self::money($entry['amount'] ?? 0);
            if ($entry_amount <= 0) {
                continue;
            }

            $matches_case = (string) ($entry['case_id'] ?? '') === $case_id;
            $matches_target = (int) ($entry['target_row_id'] ?? 0) === $target_row_id;

            if ($matches_case && $matches_target && $remaining > 0) {
                $consume = self::money(min($entry_amount, $remaining));
                $entry_amount = self::money($entry_amount - $consume);
                $remaining = self::money($remaining - $consume);
            }

            if ($entry_amount > 0) {
                $entry['amount'] = $entry_amount;
                $remaining_historical[] = $entry;
            }
        }

        if ($remaining > 0.009) {
            return ['ok' => false, 'error' => 'Refund rollback could not be matched to historical reopened target edges.'];
        }

        $offset_targets = self::normalize_target_edges($meta['offset_targets'] ?? []);
        $matched = false;
        foreach ($offset_targets as $idx => $entry) {
            if ((int) ($entry['target_row_id'] ?? 0) === $target_row_id) {
                $offset_targets[$idx]['amount'] = self::money(($entry['amount'] ?? 0) + $amount);
                $matched = true;
                break;
            }
        }
        if (!$matched) {
            $offset_targets[] = [
                'target_row_id' => $target_row_id,
                'target_shipment_id' => 0,
                'target_order_id' => 0,
                'amount' => $amount,
                'rollback_case_id' => $case_id,
            ];
        }

        $offset_targets = self::normalize_target_edges($offset_targets);
        $new_abs = self::money(max(0.0, $current_abs - $amount));
        $now = self::now();

        $meta['offset_targets'] = $offset_targets;
        $meta['historical_offset_targets_reopened'] = $remaining_historical;
        $meta['historical_offset_targets_reclosed'] = array_merge(
            array_values((array) ($meta['historical_offset_targets_reclosed'] ?? [])),
            [[
                'target_row_id' => $target_row_id,
                'amount' => $amount,
                'case_id' => $case_id,
                'at' => $now,
            ]]
        );
        $meta['debit_offset_applied'] = self::money(($meta['debit_offset_applied'] ?? 0) + $amount);
        $meta['settlement_stage'] = 'recovery';
        $meta['settlement_state'] = $new_abs <= 0 ? 'reversed' : 'debit';
        $meta['settlement_reason'] = $new_abs <= 0
            ? 'Refund rollback fully reclosed this debit exposure'
            : 'Refund rollback partially reclosed this debit exposure';
        $meta['state_timestamp'] = $now;
        $meta['refund_target_reopen_rollback_case_id'] = $case_id;
        $meta = self::sync_chain_snapshot($meta, [
            'state' => $new_abs <= 0 ? 'reversed' : 'debit',
            'net' => $new_abs <= 0 ? 0.0 : (-1 * $new_abs),
        ]);

        $event_type = $new_abs <= 0
            ? 'seller_deduction_reclosed_after_refund_rollback'
            : 'seller_deduction_partially_reclosed_after_refund_rollback';
        $note = $new_abs <= 0
            ? 'Refund rollback fully reclosed seller debit exposure'
            : 'Refund rollback partially reclosed seller debit exposure';

        $updated = $wpdb->query(
            $wpdb->prepare(
                "UPDATE " . self::table() . "
                 SET state=%s,
                     event_type=%s,
                     note=%s,
                     net=%s,
                     updated_at=%s,
                     meta=%s
                 WHERE id=%d",
                $new_abs <= 0 ? 'reversed' : 'debit',
                $event_type,
                $note,
                number_format($new_abs <= 0 ? 0.0 : (-1 * $new_abs), 2, '.', ''),
                $now,
                self::encode_meta($meta),
                $source_debit_row_id
            )
        );

        if ($updated === false) {
            return ['ok' => false, 'error' => 'Failed reclosing debit source row during refund rollback.'];
        }

        return [
            'ok' => true,
            'source_debit_row_id' => $source_debit_row_id,
            'reclosed_amount' => $amount,
            'new_abs' => $new_abs,
        ];
    }

    public static function invalidate_recovery_targets_for_refunded_shipment(string $unique_key, int $shipment_id, int $vendor_id, float $amount, array $context = []): array
    {
        global $wpdb;

        $unique_key = trim((string) $unique_key);
        $shipment_id = max(0, $shipment_id);
        $vendor_id = max(0, $vendor_id);
        $amount = self::money(max(0.0, (float) $amount));

        if ($unique_key === '' || $shipment_id <= 0 || $vendor_id <= 0 || $amount <= 0) {
            return [
                'success' => true,
                'invalidated_total' => 0.0,
                'reopened_total' => 0.0,
                'invalidated_targets' => [],
                'reopened_sources' => [],
            ];
        }

        $flag_key = '_cc_sp_target_refund_unwind_' . md5($unique_key);
        $already = get_post_meta($shipment_id, $flag_key, true);
        if ($already !== '') {
            $decoded = is_string($already) ? json_decode((string) $already, true) : (is_array($already) ? $already : []);
            if (is_array($decoded) && !empty($decoded['done'])) {
                return [
                    'success' => true,
                    'invalidated_total' => self::money($decoded['invalidated_total'] ?? 0),
                    'reopened_total' => self::money($decoded['reopened_total'] ?? 0),
                    'invalidated_targets' => array_values((array) ($decoded['invalidated_targets'] ?? [])),
                    'reopened_sources' => array_values((array) ($decoded['reopened_sources'] ?? [])),
                ];
            }
        }

        if (!self::acquire_payout_lock($vendor_id)) {
            return ['success' => false, 'error' => 'Seller ledger is busy; target refund unwind could not acquire the vendor lock.'];
        }

        $in_tx = false;
        try {
            $in_tx = ($wpdb->query('START TRANSACTION') !== false);

            $rows = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT *
                     FROM " . self::table() . "
                     WHERE shipment_id=%d
                       AND vendor_id=%d
                       AND state='paid'
                       AND net > 0
                     ORDER BY id ASC
                     FOR UPDATE",
                    $shipment_id,
                    $vendor_id
                ),
                ARRAY_A
            );

            $remaining_budget = $amount;
            $invalidated_total = 0.0;
            $reopened_total = 0.0;
            $invalidated_targets = [];
            $reopened_sources = [];

            foreach ((array) $rows as $row) {
                if ($remaining_budget <= 0.009) {
                    break;
                }

                $row_id = (int) ($row['id'] ?? 0);
                $row_net = self::money(max(0.0, (float) ($row['net'] ?? 0)));
                if ($row_id <= 0 || $row_net <= 0) {
                    continue;
                }

                $meta = self::decode_meta($row['meta'] ?? '');
                $payout_mode = strtolower((string) ($meta['payout_mode'] ?? ''));
                if ($payout_mode !== 'offset') {
                    continue;
                }

                $matchable_row_amount = 0.0;
                foreach ((array) ($meta['offset_sources'] ?? []) as $edge) {
                    if (!is_array($edge)) {
                        continue;
                    }
                    $match = true;
                    if (!empty($context['slice_id']) && !empty($edge['target_slice_id'])) {
                        $match = ((string) $edge['target_slice_id'] === (string) $context['slice_id']);
                    }
                    if ($match && !empty($context['order_item_id']) && !empty($edge['target_order_item_id'])) {
                        $match = ((int) $edge['target_order_item_id'] === (int) $context['order_item_id']);
                    }
                    if ($match) {
                        $matchable_row_amount += (float) ($edge['amount'] ?? 0);
                    }
                }
                $matchable_row_amount = self::money($matchable_row_amount);
                $has_exact_target_context = !empty($context['slice_id']) || !empty($context['order_item_id']);
                if ($has_exact_target_context && $matchable_row_amount <= 0) {
                    // CC_BANK_DOCTRINE_SKIP_UNMATCHED_TARGET_ROWS_V2
                    // The row belongs to the same shipment, but not to the exact refunded target slice.
                    // Do not fallback, do not block, and do not unwind unrelated recovery edges.
                    continue;
                }

                $unwind_here = self::money(min($row_net, $remaining_budget, $has_exact_target_context ? $matchable_row_amount : $row_net));
                if ($unwind_here <= 0) {
                    continue;
                }

                $target_result = self::reverse_offset_target_row_after_refund(
                    $row_id,
                    $unwind_here,
                    (string) ($context['case_id'] ?? $unique_key),
                    $context
                );

                if (empty($target_result['ok'])) {
                    throw new \RuntimeException((string) ($target_result['error'] ?? 'Failed invalidating historical recovery target row during refund.'));
                }

                $invalidated_targets[] = [
                    'target_row_id' => (int) ($target_result['target_row_id'] ?? 0),
                    'target_shipment_id' => (int) ($target_result['target_shipment_id'] ?? 0),
                    'target_order_id' => (int) ($target_result['target_order_id'] ?? 0),
                    'target_slice_id' => (string) ($context['slice_id'] ?? ''),
                    'target_order_item_id' => (int) ($context['order_item_id'] ?? 0),
                    'amount' => self::money((float) ($target_result['unwound_amount'] ?? 0)),
                    'source_rows' => [],
                ];

                foreach ((array) ($target_result['consumed_sources'] ?? []) as $source_entry) {
                    if (!is_array($source_entry)) {
                        continue;
                    }

                    $source_amount = self::money(max(0.0, (float) ($source_entry['amount'] ?? 0)));
                    $source_row_id = (int) ($source_entry['debit_row_id'] ?? 0);
                    if ($source_row_id <= 0 || $source_amount <= 0) {
                        continue;
                    }

                    $source_result = self::reopen_debit_source_after_target_refund(
                        $source_row_id,
                        (int) ($target_result['target_row_id'] ?? 0),
                        $source_amount,
                        (string) ($context['case_id'] ?? $unique_key),
                        array_merge($context, [
                            'source_slice_id' => (string) ($source_entry['source_slice_id'] ?? ''),
                            'source_order_item_id' => (int) ($source_entry['source_order_item_id'] ?? 0),
                            'target_shipment_id' => (int) ($target_result['target_shipment_id'] ?? 0),
                            'target_order_id' => (int) ($target_result['target_order_id'] ?? 0),
                            'slice_id' => (string) ($source_entry['target_slice_id'] ?? ($context['slice_id'] ?? '')),
                        ])
                    );

                    if (empty($source_result['ok'])) {
                        throw new \RuntimeException((string) ($source_result['error'] ?? 'Failed reopening debit source row during target refund unwind.'));
                    }

                    $reopened_sources[] = [
                        'source_debit_row_id' => (int) ($source_result['source_debit_row_id'] ?? 0),
                        'source_shipment_id' => (int) ($source_result['source_shipment_id'] ?? 0),
                        'source_order_id' => (int) ($source_result['source_order_id'] ?? 0),
                        'source_slice_id' => (string) ($source_entry['source_slice_id'] ?? ''),
                        'source_order_item_id' => (int) ($source_entry['source_order_item_id'] ?? 0),
                        'target_row_id' => (int) ($target_result['target_row_id'] ?? 0),
                        'target_slice_id' => (string) ($source_entry['target_slice_id'] ?? ($context['slice_id'] ?? '')),
                        'amount' => self::money((float) ($source_result['reopened_amount'] ?? 0)),
                    ];

                    $invalidated_targets[count($invalidated_targets) - 1]['source_rows'][] = end($reopened_sources);
                    $reopened_total = self::money($reopened_total + (float) ($source_result['reopened_amount'] ?? 0));
                }

                $invalidated_total = self::money($invalidated_total + (float) ($target_result['unwound_amount'] ?? 0));
                $remaining_budget = self::money($remaining_budget - (float) ($target_result['unwound_amount'] ?? 0));
            }

            self::commit_transaction_or_throw($in_tx);
            self::invalidate_vendor_truth_cache($vendor_id);

            update_post_meta($shipment_id, $flag_key, wp_json_encode([
                'done' => true,
                'unique_key' => $unique_key,
                'requested_amount' => $amount,
                'invalidated_total' => $invalidated_total,
                'reopened_total' => $reopened_total,
                'invalidated_targets' => $invalidated_targets,
                'reopened_sources' => $reopened_sources,
                'ts' => self::now(),
            ]));

            return [
                'success' => true,
                'invalidated_total' => $invalidated_total,
                'reopened_total' => $reopened_total,
                'invalidated_targets' => $invalidated_targets,
                'reopened_sources' => $reopened_sources,
            ];
        } catch (\Throwable $e) {
            self::rollback_transaction($in_tx);
            return [
                'success' => false,
                'error' => $e->getMessage(),
            ];
        } finally {
            self::release_payout_lock($vendor_id);
        }
    }

    public static function rollback_refund_case_financials(string $case_id, int $shipment_id, int $vendor_id): array
    {
        global $wpdb;

        $case_id = trim((string) $case_id);
        $shipment_id = max(0, $shipment_id);
        $vendor_id = max(0, $vendor_id);
        if ($case_id === '' || $shipment_id <= 0 || $vendor_id <= 0) {
            return ['success' => false, 'error' => 'Invalid refund rollback context.'];
        }

        if (!self::acquire_payout_lock($vendor_id)) {
            return ['success' => false, 'error' => 'Seller ledger is busy; refund rollback could not acquire the vendor lock.'];
        }

        $in_tx = false;
        try {
            $in_tx = ($wpdb->query('START TRANSACTION') !== false);
            $now = self::now();
            $reversal_key = 'refund:' . $case_id;
            $flag_key = '_cc_sp_retbridge_' . md5($reversal_key);
            $flag_payload = get_post_meta($shipment_id, $flag_key, true);
            $flag = is_string($flag_payload) ? json_decode($flag_payload, true) : (is_array($flag_payload) ? $flag_payload : []);

            $target_unwind_ref = 'refund-target:' . $case_id;
            $target_unwind_flag_key = '_cc_sp_target_refund_unwind_' . md5($target_unwind_ref);
            $target_unwind_payload = get_post_meta($shipment_id, $target_unwind_flag_key, true);
            $target_unwind = is_string($target_unwind_payload) ? json_decode($target_unwind_payload, true) : (is_array($target_unwind_payload) ? $target_unwind_payload : []);

            if (is_array($target_unwind) && !empty($target_unwind['done']) && empty($target_unwind['rollback_done'])) {
                foreach ((array) ($target_unwind['reopened_sources'] ?? []) as $source_entry) {
                    if (!is_array($source_entry)) {
                        continue;
                    }
                    $source_debit_row_id = (int) ($source_entry['source_debit_row_id'] ?? 0);
                    $amount = self::money($source_entry['amount'] ?? 0);
                    if ($source_debit_row_id <= 0 || $amount <= 0) {
                        continue;
                    }

                    $row = $wpdb->get_row(
                        $wpdb->prepare(
                            "SELECT id, net FROM " . self::table() . " WHERE id=%d LIMIT 1 FOR UPDATE",
                            $source_debit_row_id
                        ),
                        ARRAY_A
                    );

                    if (!$row) {
                        throw new \RuntimeException('Financial rollback is blocked because a reopened source debt row can no longer be found.');
                    }

                    $current_abs = self::money(abs((float) ($row['net'] ?? 0)));
                    if ($current_abs + 0.009 < $amount) {
                        throw new \RuntimeException('Financial rollback is blocked because previously reopened source debt has already been re-covered by later shipments.');
                    }
                }
            }

            $reversal_restored = 0.0;
            $reversal_rows = [];

            if (is_array($flag) && !empty($flag['reversed_amount']) && empty($flag['rollback_done'])) {
                $row_ids = array_values(array_filter(array_map('intval', (array) ($flag['row_ids'] ?? []))));
                foreach ($row_ids as $row_id) {
                    $row = $wpdb->get_row(
                        $wpdb->prepare(
                            "SELECT * FROM " . self::table() . " WHERE id=%d LIMIT 1 FOR UPDATE",
                            $row_id
                        ),
                        ARRAY_A
                    );
                    if (!$row) {
                        continue;
                    }

                    $meta = self::decode_meta($row['meta'] ?? '');
                    $bridge = isset($meta['return_bridge']) && is_array($meta['return_bridge']) ? $meta['return_bridge'] : [];
                    $history = array_values(isset($meta['historical_return_slices']) && is_array($meta['historical_return_slices']) ? $meta['historical_return_slices'] : []);
                    $history_idx = null;
                    $history_entry = [];

                    if ((string) ($bridge['unique_key'] ?? '') === $reversal_key) {
                        $history_entry = $bridge;
                    } else {
                        foreach ($history as $idx => $entry) {
                            if (!is_array($entry)) {
                                continue;
                            }
                            if ((string) ($entry['unique_key'] ?? '') === $reversal_key) {
                                $history_idx = $idx;
                                $history_entry = $entry;
                                break;
                            }
                        }
                    }

                    $row_reversed = self::money(max(0.0, (float) ($history_entry['reversed_amount'] ?? 0)));
                    if ($row_reversed <= 0) {
                        continue;
                    }

                    $restore_state = self::infer_restoration_state_from_row($row, $meta);
                    $restored_net = self::money(max(0.0, (float) ($row['net'] ?? 0)) + $row_reversed);
                    if (!isset($history_entry['historical_reversed_amount']) || (float) $history_entry['historical_reversed_amount'] <= 0) {
                        $history_entry['historical_reversed_amount'] = $row_reversed;
                    }
                    $history_entry['rolled_back_amount'] = self::money((float) ($history_entry['rolled_back_amount'] ?? 0) + $row_reversed);
                    $history_entry['reversed_amount'] = 0.0;
                    $history_entry['rolled_back_at'] = $now;
                    $history_entry['rollback_case_id'] = $case_id;
                    if ((string) ($bridge['unique_key'] ?? '') === $reversal_key) {
                        $meta['return_bridge'] = $history_entry;
                    }
                    if ($history_idx !== null) {
                        $history[$history_idx] = $history_entry;
                        $meta['historical_return_slices'] = $history;
                    }
                    $meta['settlement_stage'] = $restore_state === 'available' ? 'payout_ready' : ($restore_state === 'hold' ? 'hold' : 'clearing');
                    $meta['settlement_state'] = $restore_state;
                    $meta['settlement_reason'] = 'Refund case rollback restored seller earnings';
                    $meta['state_timestamp'] = $now;
                    $existing_slices = self::row_financial_slices($row, $meta);
                    $meta = self::set_row_financial_slices($meta, self::add_amount_to_slice_map($existing_slices, [
                        'shipment_id' => (int) ($row['shipment_id'] ?? 0),
                        'slice_id' => (string) ($history_entry['slice_id'] ?? self::fallback_slice_id((int) ($row['shipment_id'] ?? 0), (int) ($history_entry['item_id'] ?? 0))),
                        'order_item_id' => (int) ($history_entry['item_id'] ?? 0),
                        'product_id' => (int) ($history_entry['product_id'] ?? 0),
                        'name' => (string) ($history_entry['item_name'] ?? ''),
                        'qty' => max(0.000001, (float) ($history_entry['qty_refundable'] ?? 1)),
                    ], $row_reversed));
                    $meta = self::sync_chain_snapshot($meta, [
                        'state' => $restore_state,
                        'net' => $restored_net,
                    ]);

                    $updated = $wpdb->query(
                        $wpdb->prepare(
                            "UPDATE " . self::table() . "
                             SET state=%s,
                                 event_type='seller_earnings_restored_after_refund_rollback',
                                 note='Refund case rollback restored seller earnings',
                                 net=%s,
                                 updated_at=%s,
                                 meta=%s
                             WHERE id=%d",
                            $restore_state,
                            number_format($restored_net, 2, '.', ''),
                            $now,
                            self::encode_meta($meta),
                            $row_id
                        )
                    );

                    if ($updated === false) {
                        throw new \RuntimeException('Failed restoring previously reversed seller earnings.');
                    }

                    $reversal_restored = self::money($reversal_restored + $row_reversed);
                    $reversal_rows[] = $row_id;
                }

                $flag['rollback_done'] = true;
                $flag['rollback_restored_amount'] = $reversal_restored;
                $flag['rollback_ts'] = $now;
                update_post_meta($shipment_id, $flag_key, wp_json_encode($flag));
            }

            $debit_ref = 'refund-debit:' . $case_id;
            $debit_row = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT * FROM " . self::table() . " WHERE unique_key=%s LIMIT 1 FOR UPDATE",
                    $debit_ref
                ),
                ARRAY_A
            );

            $debit_rolled_back = 0.0;
            $restored_target_rows = [];

            if ($debit_row) {
                $debit_meta = self::decode_meta($debit_row['meta'] ?? '');
                $offset_applied = self::money(max(0.0, (float) ($debit_meta['debit_offset_applied'] ?? 0)));
                $offset_targets = isset($debit_meta['offset_targets']) && is_array($debit_meta['offset_targets']) ? array_values($debit_meta['offset_targets']) : [];

                if ($offset_applied > 0 && empty($offset_targets)) {
                    throw new \RuntimeException('Financial rollback is blocked because this debit was historically offset without exact target mapping.');
                }

                foreach ($offset_targets as $target) {
                    if (!is_array($target)) {
                        continue;
                    }
                    $release_amount = self::money(max(0.0, (float) ($target['amount'] ?? 0)));
                    $target_row_id = (int) ($target['target_row_id'] ?? 0);
                    if ($release_amount <= 0 || $target_row_id <= 0) {
                        continue;
                    }

                    $released = self::release_offset_consumed_row_as_available(
                        $target_row_id,
                        $release_amount,
                        (int) ($debit_row['id'] ?? 0),
                        $case_id
                    );

                    if (empty($released['ok'])) {
                        throw new \RuntimeException((string) ($released['error'] ?? 'Failed releasing historical offset target.'));
                    }

                    $restored_target_rows[] = [
                        'target_row_id' => $target_row_id,
                        'restore_row_id' => (int) ($released['restore_row_id'] ?? 0),
                        'amount' => self::money((float) ($released['restored_amount'] ?? 0)),
                    ];
                }

                $original_debit_amount = self::money(
                    max(
                        0.0,
                        abs((float) ($debit_row['net'] ?? 0)) + $offset_applied
                    )
                );
                if ($original_debit_amount <= 0) {
                    $original_debit_amount = self::money(max(0.0, (float) (($debit_meta['return_bridge']['vendor_impact'] ?? 0))));
                }

                $debit_meta['historical_debit_offset_applied'] = $offset_applied;
                $debit_meta['historical_offset_targets'] = $offset_targets;
                $debit_meta['debit_offset_applied'] = 0.0;
                $debit_meta['offset_targets'] = [];
                $debit_meta['rolled_back_at'] = $now;
                $debit_meta['rollback_case_id'] = $case_id;
                $debit_meta['rollback_restored_target_rows'] = $restored_target_rows;
                $debit_meta['settlement_stage'] = 'reversal';
                $debit_meta['settlement_state'] = 'reversed';
                $debit_meta['settlement_reason'] = 'Refund case rollback neutralized seller debit exposure';
                $debit_meta['state_timestamp'] = $now;
                $debit_meta = self::sync_chain_snapshot($debit_meta, [
                    'state' => 'reversed',
                    'net' => 0.0,
                ]);

                $updated = $wpdb->query(
                    $wpdb->prepare(
                        "UPDATE " . self::table() . "
                         SET state='reversed',
                             event_type='seller_deduction_rolled_back',
                             note='Refund case rollback neutralized seller debit exposure',
                             net=0,
                             updated_at=%s,
                             meta=%s
                         WHERE id=%d",
                        $now,
                        self::encode_meta($debit_meta),
                        (int) ($debit_row['id'] ?? 0)
                    )
                );

                if ($updated === false) {
                    throw new \RuntimeException('Failed neutralizing seller debit during refund rollback.');
                }

                $debit_rolled_back = $original_debit_amount;
            }

            $reclosed_sources = [];
            $restored_refund_targets = [];

            if (is_array($target_unwind) && !empty($target_unwind['done']) && empty($target_unwind['rollback_done'])) {
                $entries = array_values((array) ($target_unwind['reopened_sources'] ?? []));
                usort($entries, static function (array $a, array $b): int {
                    $cmp = ((int) ($a['source_debit_row_id'] ?? 0)) <=> ((int) ($b['source_debit_row_id'] ?? 0));
                    if ($cmp !== 0) {
                        return $cmp;
                    }
                    return ((int) ($a['target_row_id'] ?? 0)) <=> ((int) ($b['target_row_id'] ?? 0));
                });

                foreach ($entries as $entry) {
                    if (!is_array($entry)) {
                        continue;
                    }

                    $source_debit_row_id = (int) ($entry['source_debit_row_id'] ?? 0);
                    $target_row_id = (int) ($entry['target_row_id'] ?? 0);
                    $amount = self::money(max(0.0, (float) ($entry['amount'] ?? 0)));
                    if ($source_debit_row_id <= 0 || $target_row_id <= 0 || $amount <= 0) {
                        continue;
                    }

                    $restored_target = self::restore_offset_target_row_after_refund_rollback(
                        $target_row_id,
                        $source_debit_row_id,
                        $amount,
                        $case_id
                    );
                    if (empty($restored_target['ok'])) {
                        throw new \RuntimeException((string) ($restored_target['error'] ?? 'Failed restoring refunded contributor target row during rollback.'));
                    }

                    $reclosed_source = self::reclose_debit_source_after_target_refund_rollback(
                        $source_debit_row_id,
                        $target_row_id,
                        $amount,
                        $case_id
                    );
                    if (empty($reclosed_source['ok'])) {
                        throw new \RuntimeException((string) ($reclosed_source['error'] ?? 'Failed reclosing reopened source debt during rollback.'));
                    }

                    $restored_refund_targets[] = [
                        'target_row_id' => $target_row_id,
                        'source_debit_row_id' => $source_debit_row_id,
                        'amount' => $amount,
                    ];
                    $reclosed_sources[] = [
                        'source_debit_row_id' => $source_debit_row_id,
                        'target_row_id' => $target_row_id,
                        'amount' => $amount,
                    ];
                }

                $target_unwind['rollback_done'] = true;
                $target_unwind['rollback_ts'] = $now;
                $target_unwind['rollback_restored_targets'] = $restored_refund_targets;
                $target_unwind['rollback_reclosed_sources'] = $reclosed_sources;
                update_post_meta($shipment_id, $target_unwind_flag_key, wp_json_encode($target_unwind));
            }

            self::commit_transaction_or_throw($in_tx);
            self::invalidate_vendor_truth_cache($vendor_id);

            return [
                'success' => true,
                'financial_txn_ref' => implode(',', array_filter([$reversal_key, $debit_ref, $target_unwind_ref, 'refund-rollback:' . $case_id])),
                'reversal_restored_amount' => self::money($reversal_restored),
                'debit_rolled_back_amount' => self::money($debit_rolled_back),
                'restored_target_rows' => $restored_target_rows,
                'reversal_rows' => $reversal_rows,
                'restored_refund_targets' => $restored_refund_targets,
                'reclosed_sources' => $reclosed_sources,
            ];
        } catch (\Throwable $e) {
            self::rollback_transaction($in_tx);
            return [
                'success' => false,
                'error' => $e->getMessage(),
            ];
        } finally {
            self::release_payout_lock($vendor_id);
        }
    }



    public static function mark_paid_for_vendor(int $vendor_id, float $cash_target = 0.0): float
    {
        $result = self::mark_paid_for_vendor_detailed($vendor_id, $cash_target);
        return round((float) ($result['paid'] ?? 0.0), 2);
    }
    public static function mark_paid_for_vendor_detailed(int $vendor_id, float $cash_target = 0.0, array $context = []): array
    {
        global $wpdb;

        $vendor_id = max(0, $vendor_id);
        if ($vendor_id <= 0) {
            return ['paid' => 0.0, 'offset_applied' => 0.0, 'cash_sources' => [], 'offset_events' => []];
        }

        if (!self::acquire_payout_lock($vendor_id)) {
            return ['paid' => 0.0, 'offset_applied' => 0.0, 'cash_sources' => [], 'offset_events' => [], 'error' => 'lock_unavailable'];
        }

        $in_tx = false;

        try {
            $in_tx = ($wpdb->query('START TRANSACTION') !== false);

            $now = self::now();
            $context['vendor_id'] = $vendor_id;
            $offset_events = [];
            $payout_events = [];
            $offset_applied_total = 0.0;

            $available_rows = self::fetch_available_rows_for_update($vendor_id);
            if (!$available_rows) {
                self::commit_transaction_or_throw($in_tx);
                return ['paid' => 0.0, 'offset_applied' => 0.0, 'cash_sources' => [], 'offset_events' => []];
            }

            $available_sum = 0.0;
            foreach ($available_rows as $row) {
                $available_sum += (float) ($row['net'] ?? 0);
            }
            $available_sum = round($available_sum, 2);
            if ($available_sum <= 0) {
                self::commit_transaction_or_throw($in_tx);
                return ['paid' => 0.0, 'offset_applied' => 0.0, 'cash_sources' => [], 'offset_events' => []];
            }

            $debit_rows = self::fetch_debit_rows_for_update($vendor_id);
            $debit_exposure = 0.0;
            $debit_states = [];
            foreach ($debit_rows as $row) {
                $abs_debit = round(abs((float) ($row['net'] ?? 0)), 2);
                if ($abs_debit <= 0) {
                    continue;
                }
                $debit_exposure = round($debit_exposure + $abs_debit, 2);
                $debit_states[] = [
                    'row' => $row,
                    'id' => (int) ($row['id'] ?? 0),
                    'remaining' => $abs_debit,
                    'applied' => 0.0,
                    'targets' => [],
                    'source_slices' => self::row_financial_slices($row),
                ];
            }

            $offset_amount = min($available_sum, $debit_exposure);
            $remaining_offset = round($offset_amount, 2);

            if ($remaining_offset > 0) {
                foreach ($available_rows as $row) {
                    if ($remaining_offset <= 0) {
                        break;
                    }

                    $id  = (int) ($row['id'] ?? 0);
                    $net = round((float) ($row['net'] ?? 0), 2);
                    if ($id <= 0 || $net <= 0) {
                        continue;
                    }

                    $row_offset_sources = [];
                    $row_offset_total = 0.0;
                    $row_slices = self::row_financial_slices($row);
                    $row_slice_allocations = [];

                    foreach ($row_slices as $contributor_slice) {
                        if ($remaining_offset <= 0) {
                            break;
                        }
                        $contributor_slice_amount = self::money((float) ($contributor_slice['amount'] ?? 0));
                        if ($contributor_slice_amount <= 0) {
                            continue;
                        }

                        $slice_room = $contributor_slice_amount;
                        foreach ($debit_states as $idx => $debit_state) {
                            if ($remaining_offset <= 0 || $slice_room <= 0) {
                                break;
                            }
                            $debit_remaining = round((float) ($debit_states[$idx]['remaining'] ?? 0), 2);
                            if ($debit_remaining <= 0) {
                                continue;
                            }

                            foreach ((array) ($debit_states[$idx]['source_slices'] ?? []) as $source_slice_idx => $source_slice) {
                                if ($remaining_offset <= 0 || $slice_room <= 0) {
                                    break;
                                }
                                $source_slice_remaining = self::money((float) ($source_slice['amount'] ?? 0));
                                if ($source_slice_remaining <= 0) {
                                    continue;
                                }

                                $apply_here = round(min($slice_room, $source_slice_remaining, $debit_remaining, $remaining_offset), 2);
                                if ($apply_here <= 0) {
                                    continue;
                                }

                                $source_row = $debit_states[$idx]['row'];
                                $source_meta = self::decode_meta($source_row['meta'] ?? '');
                                $row_offset_sources[] = [
                                    'debit_row_id' => (int) ($source_row['id'] ?? 0),
                                    'source_shipment_id' => (int) ($source_row['shipment_id'] ?? 0),
                                    'source_order_id' => (int) ($source_row['order_id'] ?? 0),
                                    'source_slice_id' => (string) ($source_slice['slice_id'] ?? ''),
'source_order_item_id' => (int) ($source_slice['order_item_id'] ?? 0),
'target_row_id' => 0, // filled after final target row is known
'target_slice_id' => (string) ($contributor_slice['slice_id'] ?? ''),                                    'target_order_item_id' => (int) ($contributor_slice['order_item_id'] ?? 0),
                                    'case_id' => (string) ($source_meta['case_id'] ?? ''),
                                    'reference' => (string) ($source_row['unique_key'] ?? ''),
'amount' => $apply_here,
'allocation_status' => 'consumed',
'allocated_at' => $now,
'finalized_at' => $now,                                ];

                                $row_slice_allocations[(string) ($contributor_slice['slice_id'] ?? '')] = self::money((float) ($row_slice_allocations[(string) ($contributor_slice['slice_id'] ?? '')] ?? 0) + $apply_here);
                                $debit_states[$idx]['source_slices'][$source_slice_idx]['amount'] = self::money($source_slice_remaining - $apply_here);
                                $debit_remaining = round($debit_remaining - $apply_here, 2);
                                $debit_states[$idx]['remaining'] = $debit_remaining;
                                $debit_states[$idx]['applied'] = round((float) ($debit_states[$idx]['applied'] ?? 0) + $apply_here, 2);
                                $slice_room = round($slice_room - $apply_here, 2);
                                $row_offset_total = round($row_offset_total + $apply_here, 2);
                                $remaining_offset = round($remaining_offset - $apply_here, 2);
                            }
                        }
                    }

                    if ($row_offset_total <= 0) {
                        continue;
                    }

                    $row_meta = self::decode_meta($row['meta'] ?? '');
                    $split_result = self::split_row_financial_slices($row, $row_offset_total, $row_slice_allocations);
                    $taken_slices = (array) ($split_result['taken_slices'] ?? []);
                    $remaining_slices = (array) ($split_result['remaining_slices'] ?? []);

                    $grouped_offset_sources = [];
                    $grouped_slice_allocations = [];
                    foreach ($row_offset_sources as $entry) {
                        $group_key = implode('|', [
                            (int) ($entry['debit_row_id'] ?? 0),
                            (string) ($entry['source_slice_id'] ?? ''),
                            (int) ($entry['source_order_item_id'] ?? 0),
                        ]);
                        if (!isset($grouped_offset_sources[$group_key])) {
                            $grouped_offset_sources[$group_key] = [];
                            $grouped_slice_allocations[$group_key] = [];
                        }
                        $grouped_offset_sources[$group_key][] = $entry;
                        $tsid = (string) ($entry['target_slice_id'] ?? '');
                        $grouped_slice_allocations[$group_key][$tsid] = self::money((float) ($grouped_slice_allocations[$group_key][$tsid] ?? 0) + (float) ($entry['amount'] ?? 0));
                    }

                    $target_row_map = [];
                    $slice_pool = $taken_slices ?: self::row_financial_slices($row);
                    $multiple_source_groups = count($grouped_offset_sources) > 1;

                   if (!$multiple_source_groups && $row_offset_total + 0.009 >= $net) {
    $target_row_id = $id;

    foreach ($row_offset_sources as $source_idx => $source_edge) {
        $row_offset_sources[$source_idx]['target_row_id'] = $target_row_id;
        $row_offset_sources[$source_idx]['allocation_status'] = 'consumed';
        $row_offset_sources[$source_idx]['allocated_at'] = (string) (($source_edge['allocated_at'] ?? '') ?: $now);
        $row_offset_sources[$source_idx]['finalized_at'] = $now;
    }

    $row_meta['offset_sources'] = $row_offset_sources;
    
    

                        $row_meta['linked_source_shipments'] = array_values(array_unique(array_map(static function ($entry) {
                            return (int) ($entry['source_shipment_id'] ?? 0);
                        }, $row_offset_sources)));
                        $row_meta = self::set_row_financial_slices($row_meta, $slice_pool);
                        $row_meta['settlement_stage']  = 'recovery';
                        $row_meta['settlement_state']  = 'paid';
                        $row_meta['settlement_reason'] = 'Available seller earnings used to offset debit exposure';
                        $row_meta['state_timestamp']   = $now;
                        $row_meta['payout_mode']       = 'offset';
                        $row_meta = self::with_trace_meta($row_meta, $context, 'mark_paid_offset_consumed');
                        $row_meta = self::sync_chain_snapshot($row_meta, [
                            'state' => 'paid',
                            'net' => $row_offset_total,
                            'payout_mode' => 'offset',
                        ]);

                        $result = $wpdb->query(
                            $wpdb->prepare(
                                "UPDATE " . self::table() . "
                                 SET state='paid',
                                     event_type='seller_offset_consumed',
                                     note='Available seller earnings used to offset debit exposure',
                                     updated_at=%s,
                                     meta=%s
                                 WHERE id=%d
                                   AND state='available'",
                                $now,
                                self::encode_meta($row_meta),
                                $id
                            )
                        );

                        if ($result === false) {
                            throw new \RuntimeException('Failed updating available row to paid offset.');
                        }
                        foreach ($row_offset_sources as $entry) {
                            $entry_key = implode('|', [
                                (int) ($entry['debit_row_id'] ?? 0),
                                (string) ($entry['source_slice_id'] ?? ''),
                                (int) ($entry['source_order_item_id'] ?? 0),
                            ]);
                            $target_row_map[$entry_key] = $target_row_id = $id;
                        }
                    } else {
                        foreach ($grouped_offset_sources as $group_key => $group_entries) {
                            $group_total = self::money(array_sum(array_map(static function ($entry) {
                                return (float) ($entry['amount'] ?? 0);
                            }, $group_entries)));
                            if ($group_total <= 0) {
                                continue;
                            }
                            $group_split = self::consume_financial_slices_by_request($slice_pool, (array) ($grouped_slice_allocations[$group_key] ?? []), (int) ($row['shipment_id'] ?? 0));
                            $group_taken_slices = (array) ($group_split['taken_slices'] ?? []);
                            $slice_pool = (array) ($group_split['remaining_slices'] ?? $slice_pool);
                            $slice_id = self::clone_row_as_paid_slice(
                                $row,
                                $group_total,
                                'Available seller earnings used to offset debit exposure',
                                [
                                    'offset_from_row_id' => $id,
                                    'payout_mode'        => 'offset',
                                    'financial_slices'   => $group_taken_slices,
                                    'offset_sources'     => array_values($group_entries),
                                    'linked_source_shipments' => array_values(array_unique(array_map(static function ($entry) {
                                        return (int) ($entry['source_shipment_id'] ?? 0);
                                    }, $group_entries))),
                                    'trace_context' => self::build_trace_context($context),
                                    'correlation_id' => (string) ($context['correlation_id'] ?? ''),
                                ]
                            );
                           if ($slice_id <= 0) {
    throw new \RuntimeException('Failed creating paid offset slice.');
}

foreach ($group_entries as $entry_idx => $entry) {
    $group_entries[$entry_idx]['target_row_id'] = $slice_id;
    $group_entries[$entry_idx]['allocation_status'] = 'consumed';
    $group_entries[$entry_idx]['allocated_at'] = (string) (($entry['allocated_at'] ?? '') ?: $now);
    $group_entries[$entry_idx]['finalized_at'] = $now;
}

$target_slice_row = $wpdb->get_row(
    $wpdb->prepare("SELECT * FROM " . self::table() . " WHERE id=%d LIMIT 1", $slice_id),
    ARRAY_A
);

if ($target_slice_row) {
    $target_slice_meta = self::decode_meta($target_slice_row['meta'] ?? '');
    $target_slice_meta['offset_sources'] = self::normalize_source_edges($group_entries);
    $target_slice_meta['target_assignment_status'] = 'allocated';
    $target_slice_meta['target_assignment_reason'] = 'Open vendor debit exposure existed when shipment became available';
    $target_slice_meta['state_timestamp'] = $now;

    $wpdb->update(
        self::table(),
        [
            'meta'       => self::encode_meta($target_slice_meta),
            'updated_at' => $now,
        ],
        ['id' => $slice_id],
        ['%s', '%s'],
        ['%d']
    );
}

$target_row_map[$group_key] = $slice_id;
                        }

                        $remaining_net = round($net - $row_offset_total, 2);
                        $row_meta['offset_slice_created'] = true;
                        $row_meta['offset_slice_amount']  = $row_offset_total;
                        $row_meta['state_timestamp']      = $now;
                        $row_meta = self::set_row_financial_slices($row_meta, $slice_pool ?: $remaining_slices);
                        self::reduce_available_row($id, $remaining_net, $row_meta);

                        if (!empty($wpdb->last_error)) {
                            throw new \RuntimeException('Failed reducing available row after offset slice.');
                        }
                    }

                    foreach ($row_offset_sources as $entry) {
                        $debit_row_id = (int) ($entry['debit_row_id'] ?? 0);
                        $entry_key = implode('|', [
                            (int) ($entry['debit_row_id'] ?? 0),
                            (string) ($entry['source_slice_id'] ?? ''),
                            (int) ($entry['source_order_item_id'] ?? 0),
                        ]);
                        $target_row_id = (int) ($target_row_map[$entry_key] ?? 0);
                        foreach ($debit_states as $idx => $debit_state) {
                            if ((int) ($debit_state['id'] ?? 0) !== $debit_row_id) {
                                continue;
                            }
                            $debit_states[$idx]['targets'][] = [
                                'target_row_id' => $target_row_id,
                                'target_shipment_id' => (int) ($row['shipment_id'] ?? 0),
                                'target_order_id' => (int) ($row['order_id'] ?? 0),
                                'target_slice_id' => (string) ($entry['target_slice_id'] ?? ''),
                                'target_order_item_id' => (int) ($entry['target_order_item_id'] ?? 0),
                                'source_slice_id' => (string) ($entry['source_slice_id'] ?? ''),
                                'source_order_item_id' => (int) ($entry['source_order_item_id'] ?? 0),
                                'amount' => round((float) ($entry['amount'] ?? 0), 2),
                            ];
                            break;
                        }
                    }
                }

                $offset_applied_total = round($offset_amount - max(0.0, $remaining_offset), 2);

                foreach ($debit_states as $debit_state) {
                    $apply_total = round((float) ($debit_state['applied'] ?? 0), 2);
                    if ($apply_total <= 0) {
                        continue;
                    }

                    $source_row = $debit_state['row'];
                    $source_id = (int) ($source_row['id'] ?? 0);
                    $source_abs = round(abs((float) ($source_row['net'] ?? 0)), 2);
                    $new_abs = round(max(0.0, $source_abs - $apply_total), 2);
                    $source_meta = self::decode_meta($source_row['meta'] ?? '');
                    $existing_targets = isset($source_meta['offset_targets']) && is_array($source_meta['offset_targets']) ? array_values($source_meta['offset_targets']) : [];
                    $source_meta['offset_targets'] = array_merge($existing_targets, array_values($debit_state['targets'] ?? []));
                    $source_meta['debit_offset_applied'] = round((float) ($source_meta['debit_offset_applied'] ?? 0) + $apply_total, 2);
                    $source_meta['settlement_stage'] = 'recovery';
                    $source_meta['state_timestamp'] = $now;

                    if ($new_abs <= 0) {
                        $source_meta['settlement_state'] = 'reversed';
                        $source_meta['settlement_reason'] = 'Vendor debit fully offset by available earnings';
                        $source_meta = self::set_row_financial_slices($source_meta, []);
                        $source_meta = self::sync_chain_snapshot($source_meta, [
                            'state' => 'reversed',
                            'net' => 0.0,
                        ]);
                        $updated = $wpdb->query(
                            $wpdb->prepare(
                                "UPDATE " . self::table() . "
                                 SET state='reversed',
                                     event_type='seller_deduction_fully_offset',
                                     note='Vendor debit fully offset by available earnings',
                                     net=0,
                                     updated_at=%s,
                                     meta=%s
                                 WHERE id=%d",
                                $now,
                                self::encode_meta($source_meta),
                                $source_id
                            )
                        );
                    } else {
                        $source_meta['settlement_state'] = 'debit';
                        $source_meta['settlement_reason'] = 'Vendor debit partially offset by available earnings';
                        $source_meta = self::sync_debit_open_slices_to_net($source_row, $source_meta, $new_abs);
                        $source_meta = self::sync_chain_snapshot($source_meta, [
                            'state' => 'debit',
                            'net' => -1 * $new_abs,
                        ]);
                        $updated = $wpdb->query(
                            $wpdb->prepare(
                                "UPDATE " . self::table() . "
                                 SET event_type='seller_deduction_partial_offset',
                                     note='Vendor debit partially offset by available earnings',
                                     net=%s,
                                     updated_at=%s,
                                     meta=%s
                                 WHERE id=%d",
                                number_format(-1 * $new_abs, 2, '.', ''),
                                $now,
                                self::encode_meta($source_meta),
                                $source_id
                            )
                        );
                    }

                    if ($updated === false) {
                        throw new \RuntimeException('Failed updating debit row during offset processing.');
                    }
                }

                if ($offset_applied_total > 0) {
                    $offset_events[] = [
                        'vendor_id' => $vendor_id,
                        'currency'  => self::currency(),
                        'amount'    => $offset_applied_total,
                        'reference' => 'debit_offset:' . $vendor_id . ':' . $now,
                    ];
                }
            }

            $remaining_rows = self::fetch_available_rows_for_update($vendor_id);
            if (!$remaining_rows) {
                self::commit_transaction_or_throw($in_tx);
                self::invalidate_vendor_truth_cache($vendor_id);
                self::dispatch_deferred_events($offset_events, $payout_events);
                return [
                    'paid' => 0.0,
                    'offset_applied' => $offset_applied_total,
                    'cash_sources' => $payout_events,
                    'offset_events' => $offset_events,
                ];
            }

            $available_cash_sum = 0.0;
            foreach ($remaining_rows as $row) {
                $available_cash_sum += (float) ($row['net'] ?? 0);
            }
            $available_cash_sum = round($available_cash_sum, 2);
            if ($available_cash_sum <= 0) {
                self::commit_transaction_or_throw($in_tx);
                self::invalidate_vendor_truth_cache($vendor_id);
                self::dispatch_deferred_events($offset_events, $payout_events);
                return [
                    'paid' => 0.0,
                    'offset_applied' => $offset_applied_total,
                    'cash_sources' => $payout_events,
                    'offset_events' => $offset_events,
                ];
            }

            $cash_target = round(max(0.0, $cash_target), 2);
            $payout_target = $cash_target > 0 ? min($available_cash_sum, $cash_target) : $available_cash_sum;
            if ($payout_target <= 0) {
                self::commit_transaction_or_throw($in_tx);
                self::invalidate_vendor_truth_cache($vendor_id);
                self::dispatch_deferred_events($offset_events, $payout_events);
                return [
                    'paid' => 0.0,
                    'offset_applied' => $offset_applied_total,
                    'cash_sources' => $payout_events,
                    'offset_events' => $offset_events,
                ];
            }

            $payout_sum = 0.0;
            $remaining_payout = $payout_target;

            foreach ($remaining_rows as $row) {
                if ($remaining_payout <= 0) {
                    break;
                }

                $id  = (int) ($row['id'] ?? 0);
                $net = round((float) ($row['net'] ?? 0), 2);
                if ($id <= 0 || $net <= 0) {
                    continue;
                }

                $meta = self::decode_meta($row['meta'] ?? '');
                $canonical_pending_until = (string) ($meta['pending_until'] ?? ($row['pending_until'] ?? ''));

                if ($net <= $remaining_payout + 0.009) {
                    $meta['settlement_stage']  = 'payout_complete';
                    $meta['settlement_state']  = 'paid';
                    $meta['settlement_reason'] = 'Seller payout completed';
                    $meta['state_timestamp']   = $now;
                    $meta['payout_mode']       = 'cash';
                    $meta = self::sync_chain_snapshot($meta, [
                        'state' => 'paid',
                        'net' => $net,
                        'payout_mode' => 'cash',
                    ]);

                    $result = $wpdb->query(
                        $wpdb->prepare(
                            "UPDATE " . self::table() . "
                             SET state='paid',
                                 event_type='vendor_withdrawal_paid',
                                 note='Seller payout completed',
                                 pending_until=%s,
                                 updated_at=%s,
                                 meta=%s
                             WHERE id=%d
                               AND state='available'",
                            $canonical_pending_until !== '' ? $canonical_pending_until : null,
                            $now,
                            self::encode_meta($meta),
                            $id
                        )
                    );

                    if ($result === false) {
                        throw new \RuntimeException('Failed updating available row to paid cash.');
                    }

                    if ((int) $wpdb->rows_affected > 0) {
                        $payout_sum += (float) $net;
                        $remaining_payout = round($remaining_payout - $net, 2);
                        $payout_events[] = [
                            'ledger_row_id' => $id,
                            'shipment_id'   => (int) ($meta['shipment_id'] ?? ($row['shipment_id'] ?? 0)),
                            'order_id'      => (int) ($meta['order_id'] ?? ($row['order_id'] ?? 0)),
                            'vendor_id'     => $vendor_id,
                            'currency'      => self::currency(),
                            'amount'        => (float) $net,
                            'source_ref'    => 'ledger_paid:' . $id,
                        ];
                    }
                } else {
                    $slice = $remaining_payout;
                    $remaining_net = round($net - $slice, 2);
                    $split_result = self::split_row_financial_slices($row, $slice);
                    $taken_slices = (array) ($split_result['taken_slices'] ?? []);
                    $remaining_slices = (array) ($split_result['remaining_slices'] ?? []);

                    $slice_id = self::clone_row_as_paid_slice(
                        $row,
                        $slice,
                        'Seller payout completed',
                        [
                            'cash_from_row_id' => $id,
                            'payout_mode'      => 'cash',
                            'financial_slices' => $taken_slices,
                        ]
                    );

                    if ($slice_id <= 0) {
                        throw new \RuntimeException('Failed creating paid cash slice.');
                    }

                    $meta['cash_slice_created'] = true;
                    $meta['cash_slice_amount']  = $slice;
                    $meta['state_timestamp']    = $now;
                    $meta = self::set_row_financial_slices($meta, $remaining_slices);
                    self::reduce_available_row($id, $remaining_net, $meta);
                    if (!empty($wpdb->last_error)) {
                        throw new \RuntimeException('Failed reducing available row after cash slice.');
                    }

                    $payout_sum += (float) $slice;
                    $remaining_payout = 0.0;
                    $payout_events[] = [
                        'ledger_row_id' => $slice_id,
                        'shipment_id'   => (int) ($row['shipment_id'] ?? 0),
                        'order_id'      => (int) ($row['order_id'] ?? 0),
                        'vendor_id'     => $vendor_id,
                        'currency'      => self::currency(),
                        'amount'        => (float) $slice,
                        'source_ref'    => 'ledger_paid:' . $slice_id,
                    ];
                }
            }

            $payout_sum = round($payout_sum, 2);
            if (abs($payout_sum - $payout_target) > 0.009) {
                throw new \RuntimeException(
                    'Payout reconciliation mismatch for vendor ' . $vendor_id .
                    '. Expected ' . $payout_target . ', got ' . $payout_sum . '.'
                );
            }

            self::commit_transaction_or_throw($in_tx);
            self::invalidate_vendor_truth_cache($vendor_id);
            self::dispatch_deferred_events($offset_events, $payout_events);

            return [
                'paid' => $payout_sum,
                'offset_applied' => $offset_applied_total,
                'cash_sources' => $payout_events,
                'offset_events' => $offset_events,
            ];
        } catch (\Throwable $e) {
            self::rollback_transaction($in_tx);
            error_log('[Caricove Bank][Ledger::mark_paid_for_vendor_detailed] vendor_id=' . $vendor_id . ' error=' . $e->getMessage());
            return [
                'paid' => 0.0,
                'offset_applied' => 0.0,
                'cash_sources' => [],
                'offset_events' => [],
                'error' => $e->getMessage(),
            ];
        } finally {
            self::release_payout_lock($vendor_id);
        }
    }



}
