<?php
namespace Caricove\Bank;

if ( ! defined('ABSPATH') ) { exit; }

final class BankCourierInstantPayoutRequestsTab {
    public static function render(): void {
        if ( ! class_exists(__NAMESPACE__ . '\\BankCourierPayoutRequestsTab') ) {
            echo '<div class="cbank-card" style="margin-top:16px;border:1px solid #000;background:#fff;color:#000;"><p style="margin:0;">Payout tab dependency missing.</p></div>';
            return;
        }

        BankCourierPayoutRequestsTab::render();
    }
}
