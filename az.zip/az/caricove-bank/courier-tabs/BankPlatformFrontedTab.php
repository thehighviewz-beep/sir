<?php
namespace Caricove\Bank;

if (!defined('ABSPATH')) { exit; }

final class BankPlatformFrontedTab {
    private const FRONTED_OPTION = 'caricove_bank_platform_fronted_v1';
    private const RECOVERY_OPTION = 'caricove_bank_courier_recovery_v1';

    public static function boot(): void {
        add_action('admin_post_cc_bank_platform_fronted_refund', [__CLASS__, 'post_customer_only_refund']);
    }

   public static function render(): void {
        if (!class_exists(__NAMESPACE__ . '\\BankRefundCases')) {
            self::render_missing();
            return;
        }

        self::render_notices();

        $search        = sanitize_text_field((string) ($_GET['pf_q'] ?? ''));
        $case_id_focus = sanitize_text_field((string) ($_GET['case_id'] ?? ''));
        $rows          = self::candidate_rows($search, $case_id_focus);
        $kpis          = self::kpis();
        $modals_html   = '';

        echo self::styles();
        echo '<div class="cbank-card pf-card">';
        echo '<div class="pf-head"><div><h1 class="pf-title">Courier CX Refunds</h1><p class="pf-sub">Carrier-liable cases where shipping must post into platform fronted + courier recovery.</p></div><div class="pf-pill">' . esc_html((string) count($rows)) . ' visible</div></div>';
        echo '<div class="pf-kpis">';
        echo self::kpi('Customer Refund', self::money($kpis['customer_refund']));
        echo self::kpi('Total Platform Fronted', self::money($kpis['total_fronted']));
        echo self::kpi('Courier Debt', self::money($kpis['courier_debt']));
        echo '</div>';
        echo '<form method="get" class="pf-filters">';
        echo '<input type="hidden" name="page" value="caricove-bank">';
        echo '<input type="hidden" name="tab" value="platform_fronted">';
        echo '<input type="text" name="pf_q" value="' . esc_attr($search) . '" placeholder="Case / customer / courier / shipment / product">';
        echo '<button type="submit" class="button button-primary">Filter</button>';
        echo '</form>';

        if (empty($rows)) {
            echo '<div class="pf-empty">No carrier-liable refund cases are visible right now.</div>';
            echo '</div>';
            return;
        }

        echo '<div class="pf-tablewrap"><table class="widefat striped pf-table">';
        echo '<thead><tr><th>Created</th><th>Case</th><th>Customer</th><th>Seller</th><th>Courier</th><th>Order</th><th>Shipment</th><th>Product</th><th>Mode</th><th>Item Refund</th><th>Shipping Refund</th><th>Total Fronted</th><th>Courier Debt</th><th>Status</th><th>Recovery Link</th></tr></thead><tbody>';

        foreach ($rows as $row) {
            $status_badge = self::status_badge((string) ($row['status'] ?? 'open'));
            $recovery_url = $row['recovery_case_id'] !== '' ? admin_url('admin.php?page=caricove-bank&tab=courier_recovery&case_id=' . rawurlencode($row['recovery_case_id'])) : '';
            $modal_id     = 'pf-refund-modal-' . sanitize_html_class((string) $row['case_id']);

            echo '<tr' . ($case_id_focus !== '' && $case_id_focus === (string) $row['case_id'] ? ' class="pf-focus-row"' : '') . '>';
            echo '<td>' . esc_html($row['created']) . '</td>';
            echo '<td><code>' . esc_html($row['case_id']) . '</code></td>';
            echo '<td>' . esc_html($row['customer']) . '</td>';
            echo '<td>' . esc_html($row['seller']) . '</td>';
            echo '<td>' . esc_html($row['courier']) . '</td>';
            echo '<td><code>#' . esc_html((string) $row['order_id']) . '</code></td>';
            echo '<td><code>#' . esc_html((string) $row['shipment_id']) . '</code></td>';
            echo '<td>' . esc_html($row['product']) . '</td>';
            echo '<td>' . esc_html(ucwords(str_replace('_', ' ', (string) $row['refund_execution_mode']))) . '</td>';
            echo '<td class="pf-money">' . esc_html(self::money((float) $row['item_refund'])) . '</td>';
            echo '<td class="pf-money">' . esc_html(self::money((float) $row['shipping_refund'])) . '</td>';
            echo '<td class="pf-money pf-money-strong">' . esc_html(self::money((float) $row['total_fronted'])) . '</td>';
            echo '<td class="pf-money pf-money-debt">' . esc_html(self::money((float) $row['courier_debt'])) . '</td>';
            echo '<td>' . $status_badge . '</td>';
            echo '<td class="pf-actions">';
            if (!empty($row['actionable'])) {
               echo '<button type="button" class="pf-row-btn pf-open-modal" data-target="' . esc_attr($modal_id) . '">Refund Now</button> ';
            }
            if ($recovery_url !== '') {
                echo '<a class="pf-row-link pf-recovery-link" href="' . esc_url($recovery_url) . '" onclick="window.location.href=this.href; return false;">Open Recovery</a>';
            }
            echo '</td>';
            echo '</tr>';

            if (!empty($row['actionable'])) {
                $modals_html .= '<div class="pf-modal-backdrop" id="' . esc_attr($modal_id) . '">';
                $modals_html .= '<div class="pf-modal">';
                $modals_html .= '<button type="button" class="pf-modal-close" data-close="' . esc_attr($modal_id) . '">×</button>';
                $modals_html .= '<div class="pf-modal-title">Commit Courier CX Refund</div>';
                $modals_html .= '<div class="pf-modal-case">Case ' . esc_html($row['case_id']) . ' · Shipping will route to courier recovery automatically.</div>';
                $modals_html .= '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="pf-modal-form">';
                $modals_html .= wp_nonce_field('cc_bank_platform_fronted_refund', '_wpnonce', true, false);
                $modals_html .= '<input type="hidden" name="action" value="cc_bank_platform_fronted_refund">';
                $modals_html .= '<input type="hidden" name="case_id" value="' . esc_attr((string) $row['case_id']) . '">';
                $modals_html .= '<input type="hidden" name="shipping_liability_party" value="carrier">';
                $modals_html .= '<input type="hidden" name="refund_execution_mode" value="' . esc_attr((string) $row['refund_execution_mode']) . '">';
                $modals_html .= '<label class="pf-field-label">Item refund</label>';
                $modals_html .= '<input class="pf-field" type="number" step="0.01" min="0" name="item_refund_amount_customer" value="' . esc_attr(number_format((float) $row['item_refund'], 2, '.', '')) . '">';
                $modals_html .= '<label class="pf-field-label">Outbound shipping refund</label>';
                $modals_html .= '<input class="pf-field" type="number" step="0.01" min="0" name="outbound_shipping_refund_amount_customer" value="' . esc_attr(number_format((float) $row['shipping_refund'], 2, '.', '')) . '">';
                $modals_html .= '<label class="pf-field-label">Admin note</label>';
                $modals_html .= '<textarea class="pf-field" name="admin_note" rows="4" placeholder="Briefly note why courier absorbs the shipping fee."></textarea>';
                $modals_html .= '<div class="pf-modal-actions">';
                $modals_html .= '<button type="submit" class="pf-blue-btn">Refund Customer</button>';
                $modals_html .= '<button type="button" class="pf-cancel-btn" data-close="' . esc_attr($modal_id) . '">Cancel</button>';
                $modals_html .= '</div>';
                $modals_html .= '</form>';
                $modals_html .= '</div>';
                $modals_html .= '</div>';
            }
        }

        echo '</tbody></table></div>';
        echo $modals_html;
        echo '</div>';
        echo self::modal_script();
    }

    public static function post_customer_only_refund(): void {
        if (!current_user_can('manage_woocommerce') && !current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }
        check_admin_referer('cc_bank_platform_fronted_refund');

        $case_id = sanitize_text_field((string) ($_POST['case_id'] ?? ''));
        if ($case_id === '') {
            self::redirect_notice('refund_failed');
        }

        $case = BankRefundCases::get_case($case_id);
        if (!is_array($case) || empty($case)) {
            self::redirect_notice('refund_failed');
        }

        $status = sanitize_key((string) ($case['status'] ?? ''));
        if (in_array($status, ['declined', 'closed', 'cancelled', 'completed', 'refunded'], true)) {
            self::redirect_notice('refund_exists');
        }

        $previous_fronted_row = self::fronted_row_for_case($case_id);

        $overrides = [
            'item_refund_amount_customer' => round((float) ($_POST['item_refund_amount_customer'] ?? 0), 2),
            'outbound_shipping_refund_amount_customer' => round((float) ($_POST['outbound_shipping_refund_amount_customer'] ?? 0), 2),
            'shipping_liability_party' => 'carrier',
            'shipping_refund_selected' => !empty($_POST['outbound_shipping_refund_amount_customer']) ? 1 : 0,
            'refund_execution_mode' => sanitize_key((string) ($_POST['refund_execution_mode'] ?? ($case['refund_execution_mode'] ?? ''))),
        ];

        $item_received = !empty($case['item_received_flag']) || (int) ($case['qty_received'] ?? 0) > 0;
        $return_required = !empty($case['return_required']) && sanitize_key((string) ($overrides['refund_execution_mode'] ?? '')) !== 'never_received';
        if ($return_required && !$item_received) {
            $overrides['item_refund_amount_customer'] = 0.0;
            $overrides['refund_amount_requested'] = 0.0;
            $overrides['refund_amount_approved'] = 0.0;
        }

        if (method_exists(BankRefunds::class, 'commit_refund_universe')) {
            $result = BankRefunds::commit_refund_universe($case, $overrides);
        } else {
            $result = BankRefunds::commit_refund($case, [
                'refund_amount_requested' => $overrides['item_refund_amount_customer'],
                'refund_amount_approved'  => $overrides['item_refund_amount_customer'],
            ]);
        }

        if (empty($result['success'])) {
            self::redirect_notice('refund_failed');
        }

        self::sync_courier_debt_to_customer_total($case, $result, $overrides, $previous_fronted_row);

        $fresh_case = BankRefundCases::get_case($case_id);
        $fresh_preview = is_array($fresh_case) ? BankRefunds::preview_refund($fresh_case) : [];
        $fronted_row = self::fronted_row_for_case($case_id);
        $remaining = self::remaining_components(is_array($fresh_case) ? $fresh_case : $case, $fresh_preview, $fronted_row);
        $admin_note = sanitize_textarea_field((string) ($_POST['admin_note'] ?? 'Refunded through Courier CX Refund'));

        if (($remaining['remaining_total'] ?? 0.0) > 0) {
            $next_status = !empty($remaining['return_required'])
                ? (!empty($remaining['item_received']) ? 'received' : 'awaiting_return')
                : 'approved';

            BankRefundCases::set_status($case_id, $next_status, [
                'admin_user_id' => get_current_user_id(),
                'admin_note'    => $admin_note !== '' ? $admin_note : 'Partial courier CX refund posted; case remains open for remaining component.',
            ]);

            $financial_state = ( ! empty( $remaining['return_required'] ) && empty( $remaining['item_received'] ) )
                ? 'shipping_posted'
                : 'refund_posted';

            BankRefundCases::mark_financial_state($case_id, $financial_state, [
                'financial_txn_ref' => (string) ($result['shipping_posting_key'] ?? $result['shipping_liability_posting_key'] ?? $result['shipping_refund_posting_key'] ?? ''),
            ]);
        } else {
          BankRefundCases::update_case($case_id, [
                'status'            => 'refunded',
                'admin_user_id'     => get_current_user_id(),
                'admin_note'        => $admin_note !== '' ? $admin_note : 'Refunded through Courier CX Refund',
                'admin_reviewed_at' => time(),
            ]);
            BankRefundCases::mark_financial_state($case_id, 'completed', [
                'financial_txn_ref' => (string) ($result['shipping_posting_key'] ?? $result['shipping_liability_posting_key'] ?? $result['shipping_refund_posting_key'] ?? ''),
            ]);
        }

        self::redirect_notice('refunded');
    }

    private static function candidate_rows(string $search = '', string $case_id_focus = ''): array {
        $fronted_store   = self::get_fronted_store();
        $recovery_store  = self::get_recovery_store();
        $fronted_by_case = [];
        $recovery_by_case = [];

        foreach ((array) $fronted_store as $rec) {
            if (!empty($rec['source_case_id'])) {
                $fronted_by_case[(string) $rec['source_case_id']] = $rec;
            }
        }
        foreach ((array) $recovery_store as $rec) {
            if (!empty($rec['source_case_id'])) {
                $recovery_by_case[(string) $rec['source_case_id']] = $rec;
            }
        }

        $rows = [];
        foreach ((array) BankRefundCases::list_cases() as $case) {
            if (!is_array($case) || empty($case['case_id'])) {
                continue;
            }

            $preview      = BankRefunds::preview_refund($case);
            $case_id      = (string) ($case['case_id'] ?? '');
            $fronted_row  = $fronted_by_case[$case_id] ?? null;
            $recovery_row = $recovery_by_case[$case_id] ?? null;
            $party        = (string) ($preview['shipping_liability_party'] ?? $case['shipping_liability_party'] ?? $case['resolved_fault_party'] ?? '');

            if ($party === 'carrier' && (float) ($preview['outbound_shipping_refund_amount_customer'] ?? 0) <= 0) {
                $order_shipping = self::order_shipping_amount((int) ($case['order_id'] ?? 0));
                if ($order_shipping > 0) {
                    $preview = BankRefunds::preview_refund($case, [
                        'shipping_liability_party' => 'carrier',
                        'shipping_refund_selected' => 1,
                        'outbound_shipping_refund_amount_customer' => $order_shipping,
                    ]);
                }
            }

            if ($party !== 'carrier' && !$fronted_row && !$recovery_row) {
                continue;
            }

            if ($case_id_focus !== '' && $case_id !== $case_id_focus) {
                continue;
            }

            $remaining = self::remaining_components($case, $preview, $fronted_row);
            $status = self::display_status_for_case($case, $fronted_row, $remaining);
            $row = [
                'created'          => self::date_human((int) ($case['created_at'] ?? 0)),
                'created_ts'       => (int) ($case['created_at'] ?? 0),
                'case_id'          => $case_id,
                'customer'         => self::customer_name((int) ($case['customer_id'] ?? 0)),
                'seller'           => self::seller_name($case),
                'courier'          => self::courier_name((int) ($case['shipment_id'] ?? 0), $case),
                'order_id'         => (int) ($case['order_id'] ?? 0),
                'shipment_id'      => (int) ($case['shipment_id'] ?? 0),
                'product'          => self::product_name($case),
                'refund_execution_mode' => (string) ($preview['refund_execution_mode'] ?? $case['refund_execution_mode'] ?? ''),
                'item_refund'      => (float) ($remaining['remaining_item'] ?? 0),
                'shipping_refund'  => (float) ($remaining['remaining_shipping'] ?? 0),
                'total_fronted'    => $fronted_row ? (float) ($fronted_row['total_fronted_amount'] ?? 0) : (float) ($remaining['already_total'] ?? 0),
                'courier_debt'     => $recovery_row ? (float) ($recovery_row['remaining_amount_total'] ?? 0) : (float) ($remaining['already_total'] ?? 0),
                'status'           => $status,
                'recovery_case_id' => $recovery_row ? (string) ($recovery_row['recovery_case_id'] ?? '') : '',
                'actionable'       => !self::is_terminal_status((string) ($case['status'] ?? '')) && (($remaining['refund_now_total'] ?? 0.0) > 0 ? 1 : 0),
            ];

            if ($search !== '' && !self::matches_search($row, $search)) {
                continue;
            }
            $rows[] = $row;
        }

        usort($rows, static function (array $a, array $b): int {
            return ($b['created_ts'] ?? 0) <=> ($a['created_ts'] ?? 0);
        });

        return $rows;
    }


    private static function fronted_row_for_case(string $case_id): ?array {
        foreach (self::get_fronted_store() as $row) {
            if ((string) ($row['source_case_id'] ?? '') === $case_id) {
                return is_array($row) ? $row : null;
            }
        }
        return null;
    }


    private static function live_shipping_bucket(array $case): array {
        $current = isset($case['order_shipping_refund_bucket']) && is_array($case['order_shipping_refund_bucket']) ? $case['order_shipping_refund_bucket'] : [];
        $order_id = max(0, (int) ($case['order_id'] ?? 0));
        $bucket = $current;

        if ($order_id > 0) {
            $raw = get_post_meta($order_id, '_caricove_bank_shipping_refund_bucket', true);
            if (is_array($raw)) {
                $bucket = array_merge($bucket, $raw);
            }
        }

        return [
            'order_id' => max(0, (int) ($bucket['order_id'] ?? $order_id)),
            'owner_case_id' => sanitize_text_field((string) ($bucket['owner_case_id'] ?? '')),
            'already_allocated_shipping' => round(max(0.0, (float) ($bucket['already_allocated_shipping'] ?? 0)), 2),
            'posting_key' => sanitize_text_field((string) ($bucket['posting_key'] ?? '')),
        ];
    }

    private static function case_matches_shipping_bucket(array $case, ?array $bucket = null): bool {
        $bucket = is_array($bucket) ? $bucket : self::live_shipping_bucket($case);
        $case_id = trim((string) ($case['case_id'] ?? ''));
        $owner_case_id = trim((string) ($bucket['owner_case_id'] ?? ''));
        if ($case_id !== '' && $owner_case_id !== '' && $owner_case_id === $case_id) {
            return true;
        }

        $bucket_posting_key = trim((string) ($bucket['posting_key'] ?? ''));
        if ($bucket_posting_key !== '') {
            foreach (['shipping_refund_posting_key', 'shipping_liability_posting_key', 'shipping_posting_key'] as $key) {
                $case_posting_key = trim((string) ($case[$key] ?? ''));
                if ($case_posting_key !== '' && $case_posting_key === $bucket_posting_key) {
                    return true;
                }
            }
        }

        return false;
    }

    private static function effective_posted_shipping_component(array $case): float {
        $bucket = self::live_shipping_bucket($case);
        $raw = round(max(
            (float) ($case['outbound_shipping_refund_amount_customer'] ?? 0),
            (float) ($case['shipping_refund_amount'] ?? 0)
        ), 2);
        $allocated = round(max(0.0, (float) ($bucket['already_allocated_shipping'] ?? 0)), 2);

        if ($allocated > 0) {
            if (!self::case_matches_shipping_bucket($case, $bucket)) {
                return 0.0;
            }
            return $raw > 0 ? min($raw, $allocated) : $allocated;
        }

        $shipping_posting_key = trim((string) ($case['shipping_refund_posting_key'] ?? $case['shipping_liability_posting_key'] ?? $case['shipping_posting_key'] ?? ''));
        $shipping_posting_status = sanitize_key((string) ($case['shipping_posting_status'] ?? ''));
        $shipping_visibility_status = sanitize_key((string) ($case['shipping_visibility_status'] ?? ''));
        $financial_status = sanitize_key((string) ($case['financial_status'] ?? ''));
        $posted = (
            $shipping_posting_key !== ''
            || in_array($shipping_posting_status, ['posted', 'visible'], true)
            || in_array($shipping_visibility_status, ['posted', 'visible'], true)
            || in_array($financial_status, ['shipping_posted', 'completed', 'debit_posted', 'reversal_posted', 'refund_posted'], true)
        );

        return $posted ? $raw : 0.0;
    }

    private static function is_terminal_status(string $status): bool {
        return in_array(sanitize_key($status), ['declined', 'closed', 'cancelled', 'completed', 'refunded'], true);
    }

    private static function case_shipping_component_posted(array $case): bool {
        $shipping_amount  = round((float) ($case['outbound_shipping_refund_amount_customer'] ?? 0), 2);
        $financial_status = sanitize_key((string) ($case['financial_status'] ?? ''));
        $posted_status    = sanitize_key((string) ($case['shipping_posting_status'] ?? ''));
        $visible_status   = sanitize_key((string) ($case['shipping_visibility_status'] ?? ''));
        $posted_key       = trim((string) ($case['shipping_refund_posting_key'] ?? $case['shipping_liability_posting_key'] ?? $case['shipping_posting_key'] ?? ''));

        if ($shipping_amount <= 0) {
            return false;
        }

        return (
            $posted_key !== ''
            || in_array($posted_status, ['posted', 'visible'], true)
            || in_array($visible_status, ['posted', 'visible'], true)
            || in_array($financial_status, ['shipping_posted', 'refund_posted', 'completed', 'debit_posted', 'reversal_posted'], true)
        );
    }

    private static function case_item_component_posted(array $case): bool {
        $item_amount      = round((float) ($case['item_refund_amount_customer'] ?? 0), 2);
        $financial_status = sanitize_key((string) ($case['financial_status'] ?? ''));
        $status           = sanitize_key((string) ($case['status'] ?? ''));
        $item_key         = trim((string) ($case['item_refund_posting_key'] ?? ''));

        if ($item_amount <= 0) {
            return false;
        }

        if ($item_key !== '') {
            return true;
        }

        if (in_array($financial_status, ['refund_posted', 'completed', 'debit_posted', 'reversal_posted'], true)) {
            return true;
        }

        return $status === 'refunded';
    }

    private static function remaining_components(array $case, array $preview, ?array $fronted_row): array {
        $already_item = round((float) ($fronted_row['customer_item_refund_amount'] ?? 0), 2);
        $already_shipping = round((float) ($fronted_row['customer_shipping_refund_amount'] ?? 0), 2);
        $eligible_item_now = round((float) ($preview['item_refund_amount_customer'] ?? 0), 2);
        $eligible_shipping_now = round((float) ($preview['outbound_shipping_refund_amount_customer'] ?? 0), 2);
        $already_total = round($already_item + $already_shipping, 2);

        $item_received = !empty($case['item_received_flag']) || (int) ($case['qty_received'] ?? 0) > 0;
        $return_required = !empty($case['return_required']);
        $item_refundable_now = !$return_required || $item_received;

        $latent_item = round(max(
            (float) ($case['item_refund_amount_customer_pending'] ?? 0),
            (float) ($case['refund_amount_requested_pending'] ?? 0),
            (float) ($case['refund_amount_approved_pending'] ?? 0),
            (!$item_refundable_now ? (float) ($preview['item_refund_amount_customer'] ?? 0) : 0.0)
        ), 2);

        $remaining_item_candidate = round(max(0.0, $eligible_item_now - $already_item), 2);
        $remaining_item_now = $item_refundable_now ? $remaining_item_candidate : 0.0;
        $remaining_shipping_now = round(max(0.0, $eligible_shipping_now - $already_shipping), 2);
        $future_item_pending = (!$item_refundable_now && $return_required)
            ? round(max(0.0, $latent_item - $already_item), 2)
            : 0.0;

        $refund_now_total = round($remaining_shipping_now + $remaining_item_now, 2);
        $remaining_total = round($refund_now_total + $future_item_pending, 2);

        return [
            'already_item' => $already_item,
            'already_shipping' => $already_shipping,
            'already_total' => $already_total,
            'remaining_item' => $remaining_item_now,
            'remaining_shipping' => $remaining_shipping_now,
            'future_item_pending' => $future_item_pending,
            'refund_now_total' => $refund_now_total,
            'remaining_total' => $remaining_total,
            'item_received' => $item_received,
            'return_required' => $return_required,
        ];
    }

    private static function display_status_for_case(array $case, ?array $fronted_row, array $remaining): string {
        if (($remaining['remaining_total'] ?? 0.0) <= 0) {
            return 'refunded';
        }

        if (($remaining['already_total'] ?? 0.0) <= 0) {
            return 'open';
        }

        if (!empty($remaining['return_required']) && empty($remaining['item_received']) && ($remaining['future_item_pending'] ?? 0.0) > 0) {
            return 'awaiting_return';
        }

        if (($remaining['remaining_item'] ?? 0.0) > 0 && !empty($remaining['item_received'])) {
            return 'partial_refund';
        }

        if (($remaining['remaining_shipping'] ?? 0.0) > 0) {
            return 'shipping_pending';
        }

        return (string) ($fronted_row['status'] ?? 'open');
    }


   private static function sync_courier_debt_to_customer_total(array $case, array $result, array $overrides, ?array $previous_fronted_row = null): void {
        $case_id = (string) ($case['case_id'] ?? '');
        if ($case_id === '') {
            return;
        }

        $current_case = BankRefundCases::get_case($case_id);
        if (!is_array($current_case) || empty($current_case)) {
            $current_case = $case;
        }

        $canonical_item = self::case_item_component_posted($current_case)
            ? round((float) ($current_case['item_refund_amount_customer'] ?? 0), 2)
            : 0.0;
        $canonical_shipping = self::case_shipping_component_posted($current_case)
            ? self::effective_posted_shipping_component($current_case)
            : 0.0;

        $existing_item_seed = round((float) ($previous_fronted_row['customer_item_refund_amount'] ?? 0), 2);
        $existing_shipping_seed = round((float) ($previous_fronted_row['customer_shipping_refund_amount'] ?? 0), 2);
        $cumulative_item = round(max($existing_item_seed, $canonical_item), 2);
        $cumulative_shipping = round(max($existing_shipping_seed, $canonical_shipping), 2);
        $cumulative_total = round($cumulative_item + $cumulative_shipping, 2);
        if ($cumulative_total <= 0) {
            return;
        }

        $fronted = self::get_fronted_store();
        foreach ($fronted as &$row) {
            if ((string) ($row['source_case_id'] ?? '') !== $case_id) {
                continue;
            }

            $recovered = round((float) ($row['recovered_amount_total'] ?? 0), 2);
            $remaining = round(max(0.0, $cumulative_total - $recovered), 2);

            $row['customer_item_refund_amount'] = $cumulative_item;
            $row['customer_shipping_refund_amount'] = $cumulative_shipping;
            $row['customer_refund_amount'] = $cumulative_total;
            $row['total_fronted_amount'] = $cumulative_total;
            $row['shipping_liability_party'] = 'carrier';
            $row['shipping_liability_amount'] = $cumulative_shipping;
            $row['courier_liability_item_amount'] = $cumulative_item;
            $row['courier_liability_shipping_amount'] = $cumulative_shipping;
            $row['courier_liability_total_amount'] = $cumulative_total;
            $row['remaining_amount_total'] = $remaining;
            $row['status'] = $remaining > 0 ? 'open' : 'recovered';
            $row['updated_at'] = time();
        }
        unset($row);
        update_option(self::FRONTED_OPTION, array_values($fronted), false);

        $recovery = self::get_recovery_store();
        foreach ($recovery as &$row) {
            if ((string) ($row['source_case_id'] ?? '') !== $case_id) {
                continue;
            }

            $recovered = round((float) ($row['recovered_amount_total'] ?? 0), 2);
            $remaining = round(max(0.0, $cumulative_total - $recovered), 2);

            $row['status'] = $remaining > 0 ? 'open' : 'recovered';
            $row['recoverable_amount_total'] = $cumulative_total;
            $row['remaining_amount_total'] = $remaining;
            $row['shipping_liability_amount'] = $cumulative_shipping;
            $row['courier_liability_item_amount'] = $cumulative_item;
            $row['courier_liability_shipping_amount'] = $cumulative_shipping;
            $row['courier_liability_total_amount'] = $cumulative_total;
            $row['customer_item_refund_amount'] = $cumulative_item;
            $row['customer_shipping_refund_amount'] = $cumulative_shipping;
            $row['customer_refund_amount'] = $cumulative_total;
            $row['updated_at'] = time();
        }
        unset($row);
        update_option(self::RECOVERY_OPTION, array_values($recovery), false);
    }

    private static function order_shipping_amount(int $order_id): float {
        if ($order_id <= 0 || !function_exists('wc_get_order')) {
            return 0.0;
        }
        $order = wc_get_order($order_id);
        if (!$order) {
            return 0.0;
        }
        return round(max(0.0, (float) $order->get_shipping_total() + (float) $order->get_shipping_tax()), 2);
    }

   private static function dedupe_store_rows(array $store, string $fallback_id_key): array {
        $deduped = [];
        foreach ($store as $row) {
            if (!is_array($row)) {
                continue;
            }

            $key = (string) ($row['source_case_id'] ?? '');
            if ($key === '') {
                $key = (string) ($row[$fallback_id_key] ?? '');
            }

            if ($key === '') {
                $deduped[] = $row;
                continue;
            }

            $current_ts = max((int) ($row['updated_at'] ?? 0), (int) ($row['created_at'] ?? 0));
            $prior = $deduped[$key] ?? null;
            $prior_ts = is_array($prior) ? max((int) ($prior['updated_at'] ?? 0), (int) ($prior['created_at'] ?? 0)) : -1;

            if (!is_array($prior) || $current_ts >= $prior_ts) {
                $deduped[$key] = $row;
            }
        }

        return array_values($deduped);
    }

    private static function get_fronted_store(): array {
        $store = get_option(self::FRONTED_OPTION, []);
        $store = is_array($store) ? $store : [];
        return self::dedupe_store_rows($store, 'fronted_case_id');
    }

    private static function get_recovery_store(): array {
        $store = get_option(self::RECOVERY_OPTION, []);
        $store = is_array($store) ? $store : [];
        return self::dedupe_store_rows($store, 'recovery_case_id');
    }

    private static function kpis(): array {
        $fronted = self::get_fronted_store();
        $recovery = self::get_recovery_store();
        $customer = 0.0;
        $fronted_total = 0.0;
        $debt = 0.0;

        foreach ((array) $fronted as $row) {
            $customer += (float) ($row['customer_refund_amount'] ?? 0);
            $fronted_total += (float) ($row['total_fronted_amount'] ?? 0);
        }
        foreach ((array) $recovery as $row) {
            $debt += (float) ($row['remaining_amount_total'] ?? 0);
        }

        return [
            'customer_refund' => round($customer, 2),
            'total_fronted'   => round($fronted_total, 2),
            'courier_debt'    => round($debt, 2),
        ];
    }

    private static function render_notices(): void {
        $map = [
            'refunded'      => 'Customer refund recorded and courier recovery row created.',
            'refund_exists' => 'That case is already refunded.',
            'refund_failed' => 'Refund could not be completed.',
        ];
        foreach ($map as $key => $label) {
            if (!isset($_GET[$key])) continue;
            $tone = $key === 'refunded' ? 'success' : 'error';
            echo '<div class="notice notice-' . esc_attr($tone) . ' inline"><p>' . esc_html($label) . '</p></div>';
        }
    }

    private static function customer_name(int $customer_id): string {
        if ($customer_id <= 0) return '—';
        $user = get_user_by('id', $customer_id);
        return $user ? (string) $user->display_name : ('#' . $customer_id);
    }

    private static function seller_name(array $case): string {
        $vendor_id = (int) ($case['vendor_id'] ?? 0);
        if ($vendor_id <= 0) return '—';
        $user = get_user_by('id', $vendor_id);
        return $user ? (string) $user->display_name : ('#' . $vendor_id);
    }

    private static function courier_id(int $shipment_id, array $case = []): int {
        if ($shipment_id > 0) {
            if (class_exists('\\Caricove\\Logistics\\Core\\ShipmentManager') && method_exists('\\Caricove\\Logistics\\Core\\ShipmentManager', 'get_shipment_summary')) {
                $summary = \Caricove\Logistics\Core\ShipmentManager::get_shipment_summary($shipment_id);
                $cid = (int) ($summary['courier_id'] ?? 0);
                if ($cid > 0) return $cid;
            }
            $meta_key = '_cc_shipment_courier_id';
            if (class_exists('\\Caricove\\Logistics\\Core\\Schema')) {
                $meta_key = \Caricove\Logistics\Core\Schema::META_SHIPMENT_COURIER_ID;
            }
            $cid = (int) get_post_meta($shipment_id, $meta_key, true);
            if ($cid > 0) return $cid;
        }
        return (int) ($case['courier_id'] ?? 0);
    }

    private static function courier_name(int $shipment_id, array $case = []): string {
        $cid = self::courier_id($shipment_id, $case);
        if ($cid <= 0) return '—';
        $user = get_user_by('id', $cid);
        return $user ? (string) $user->display_name : ('#' . $cid);
    }

    private static function product_name(array $case): string {
        $name = trim((string) ($case['product_name'] ?? ''));
        if ($name !== '') return $name;
        $product_id = (int) ($case['product_id'] ?? 0);
        if ($product_id > 0) {
            $title = get_the_title($product_id);
            return $title ? (string) $title : ('#' . $product_id);
        }
        return '—';
    }

    private static function status_badge(string $status): string {
        $status = sanitize_key($status !== '' ? $status : 'open');
        $label = ucwords(str_replace('_', ' ', $status));
        return '<span class="pf-badge pf-' . esc_attr(sanitize_html_class($status)) . '">' . esc_html($label) . '</span>';
    }

    private static function kpi(string $label, string $value): string {
        return '<div class="pf-kpi"><div class="pf-kpi-label">' . esc_html($label) . '</div><div class="pf-kpi-value">' . esc_html($value) . '</div></div>';
    }

    private static function matches_search(array $row, string $search): bool {
        $hay = strtolower(implode(' ', [
            (string) ($row['case_id'] ?? ''),
            (string) ($row['customer'] ?? ''),
            (string) ($row['seller'] ?? ''),
            (string) ($row['courier'] ?? ''),
            (string) ($row['product'] ?? ''),
            (string) ($row['order_id'] ?? ''),
            (string) ($row['shipment_id'] ?? ''),
        ]));
        return strpos($hay, strtolower(trim($search))) !== false;
    }

    private static function money(float $amount): string {
        return 'GYD ' . number_format($amount, 2);
    }

    private static function date_human(int $ts): string {
        return $ts > 0 ? gmdate('Y-m-d H:i', $ts) . ' UTC' : '—';
    }

    private static function render_missing(): void {
        echo '<div class="notice notice-error inline"><p>Platform Fronted dependencies are missing.</p></div>';
    }

    private static function redirect_notice(string $flag): void {
        wp_safe_redirect(add_query_arg([
            'page' => 'caricove-bank',
            'tab'  => 'platform_fronted',
            $flag  => 1,
        ], admin_url('admin.php')));
        exit;
    }

   private static function modal_script(): string {
    return '<script>
    document.addEventListener("DOMContentLoaded", function () {
        function openModalById(id) {
            var target = document.getElementById(id);
            if (target) target.classList.add("is-open");
        }

        function closeModalById(id) {
            var target = document.getElementById(id);
            if (target) target.classList.remove("is-open");
        }

        document.querySelectorAll(".pf-open-modal").forEach(function (btn) {
            btn.addEventListener("click", function (e) {
                e.preventDefault();
                e.stopPropagation();
                var id = btn.getAttribute("data-target");
                if (id) openModalById(id);
            });
        });

        document.querySelectorAll(".pf-recovery-link").forEach(function (link) {
            link.addEventListener("click", function (e) {
                e.stopPropagation();
            });
        });

        document.querySelectorAll(".pf-modal-close, .pf-cancel-btn").forEach(function (btn) {
            btn.addEventListener("click", function (e) {
                e.preventDefault();
                e.stopPropagation();
                var id = btn.getAttribute("data-close");
                if (id) closeModalById(id);
            });
        });

        document.querySelectorAll(".pf-modal-backdrop").forEach(function (backdrop) {
            backdrop.addEventListener("click", function (e) {
                if (e.target === backdrop) {
                    backdrop.classList.remove("is-open");
                }
            });
        });

        document.addEventListener("keydown", function (e) {
            if (e.key === "Escape") {
                document.querySelectorAll(".pf-modal-backdrop.is-open").forEach(function (el) {
                    el.classList.remove("is-open");
                });
            }
        });
    });
    </script>';
}

    private static function styles(): string {
        return '<style>
        .pf-card{margin-top:16px;border:1px solid rgba(120,185,255,.18);background:linear-gradient(180deg,#070B14,#04060C);color:#f5f7ff}
        .pf-head{display:flex;justify-content:space-between;align-items:flex-start;gap:16px;margin-bottom:14px}
        .pf-title{margin:0;color:#7bd7ff;font-size:20px;font-weight:900;letter-spacing:.08em;text-transform:uppercase}
        .pf-sub{margin:4px 0 0;color:#b7c9ea}
        .pf-pill{background:#000;color:#fff;padding:8px 12px;border-radius:999px;font-weight:700}
        .pf-kpis{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;margin-bottom:16px}
        .pf-kpi{padding:12px 14px;border-radius:16px;border:1px solid rgba(255,255,255,.08);background:rgba(255,255,255,.04)}
        .pf-kpi-label{font-size:11px;letter-spacing:.12em;text-transform:uppercase;color:#9fb7dc}
        .pf-kpi-value{margin-top:6px;font-size:18px;font-weight:900;color:#fff}
        .pf-filters{display:flex;gap:10px;flex-wrap:wrap;margin:0 0 16px}
        .pf-filters input{min-width:260px;padding:9px 10px;border-radius:999px;border:1px solid rgba(120,185,255,.35);background:#08111f;color:#f5f7ff}
        .pf-tablewrap{overflow:auto;border-radius:16px;border:1px solid rgba(255,255,255,.07)}
        .pf-table{min-width:1560px}
        .pf-money{text-align:right;white-space:nowrap}
        .pf-money-strong{font-weight:900}
        .pf-money-debt{color:#ffd38a;font-weight:900}
        .pf-actions{white-space:nowrap}
        .pf-link{border-color:rgba(120,185,255,.35)!important}
        .pf-badge{display:inline-block;padding:5px 10px;border-radius:999px;font-size:11px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;background:#eff4ff;color:#1f3c7a}
        .pf-open{background:#eff4ff;color:#1f3c7a}
        .pf-refunded{background:#e8fff4;color:#16623f}
        .pf-focus-row{box-shadow:inset 0 0 0 9999px rgba(0,115,170,.10)}
        .pf-empty{padding:20px;border-radius:14px;border:1px dashed rgba(255,255,255,.14);color:#b7c9ea}
        .pf-done{font-size:12px;color:#b7c9ea}
        .pf-modal-backdrop{display:none;position:fixed;inset:0;background:rgba(0,0,0,.35);z-index:99999;align-items:center;justify-content:center;padding:16px}
        .pf-modal-backdrop.is-open{display:flex}
        .pf-modal{position:relative;width:100%;max-width:420px;background:#fff;color:#111;border-radius:16px;padding:20px;box-shadow:0 24px 70px rgba(0,0,0,.28)}
        .pf-modal-close{position:absolute;top:8px;right:10px;border:0;background:transparent;color:#666;font-size:22px;line-height:1;cursor:pointer}
        .pf-modal-title{font-size:18px;font-weight:800;color:#111}
        .pf-modal-case{margin-top:4px;font-size:12px;color:#667085}
        .pf-modal-form{margin-top:16px}
        .pf-field-label{display:block;margin-bottom:6px;font-size:12px;font-weight:700;color:#334155}
        .pf-field{width:100%;padding:11px 12px;border:1px solid #dbe3ef;border-radius:12px;background:#fff;color:#111}
        .pf-modal-actions{display:flex;gap:10px;justify-content:flex-end;margin-top:16px}
        .pf-blue-btn{border:0;background:#1d4ed8;color:#fff;padding:10px 14px;border-radius:12px;font-weight:700;cursor:pointer}
        .pf-cancel-btn{border:1px solid #d6dde8;background:#fff;color:#334155;padding:10px 14px;border-radius:12px;font-weight:700;cursor:pointer}
        
        
        
        .pf-row-btn,
.pf-row-link{
    display:inline-flex;
    align-items:center;
    justify-content:center;
    min-height:36px;
    padding:0 14px;
    border-radius:10px;
    font-weight:700;
    text-decoration:none;
    cursor:pointer;
    box-sizing:border-box;
}
.pf-row-btn{
    border:1px solid rgba(120,185,255,.35);
    background:#eff4ff;
    color:#1f3c7a;
}
.pf-row-link{
    border:1px solid rgba(120,185,255,.35);
    background:transparent;
    color:#7bd7ff;
}
.pf-row-link:hover{
    color:#fff;
    border-color:rgba(120,185,255,.6);
}


        </style>';
    }
}
