<?php
namespace Caricove\Bank;

if ( ! defined('ABSPATH') ) { exit; }

final class BankCourierForfeitedTab {
    public static function render(): void {
        if ( ! class_exists(__NAMESPACE__ . '\\BankCourierHeldQueueTab') ) {
            echo '<div class="cbank-card" style="margin-top:16px;border:1px solid #000;background:#fff;color:#000;"><p style="margin:0;">Held queue dependency missing.</p></div>';
            return;
        }
        $rows = BankCourierHeldQueueTab::filtered_rows('forfeited');
        echo '<div class="cbank-card" style="margin-top:16px;border:1px solid #000;background:#fff;color:#000;">';
        echo '<div style="display:flex;justify-content:space-between;gap:16px;align-items:flex-start;margin-bottom:16px;">';
        echo '<div><h1 style="margin:0;color:#000;">Forfeited</h1><p class="description" style="margin:6px 0 0;">True forfeited courier rows only. These no longer live inside Paid.</p></div>';
        echo '<div style="background:#000;color:#fff;padding:8px 12px;border-radius:999px;font-weight:600;">' . esc_html((string) count($rows)) . ' visible</div></div>';
        echo '<form method="get" style="display:flex;flex-wrap:wrap;gap:10px;margin:0 0 16px;">';
        echo '<input type="hidden" name="page" value="caricove-bank"><input type="hidden" name="tab" value="forfeited">';
        echo '<input type="text" name="cq" value="' . esc_attr((string) ($_GET['cq'] ?? '')) . '" placeholder="Courier / earning / shipment" style="padding:8px 10px;min-width:220px;">';
        echo '<input type="date" name="from" value="' . esc_attr((string) ($_GET['from'] ?? '')) . '" style="padding:8px 10px;">';
        echo '<input type="date" name="to" value="' . esc_attr((string) ($_GET['to'] ?? '')) . '" style="padding:8px 10px;">';
        echo '<button type="submit" class="button button-primary">Filter</button></form>';
        if (empty($rows)) { echo '<p style="margin:0;">No forfeited rows.</p></div>'; return; }
        echo '<div style="overflow:auto;"><table class="widefat striped"><thead><tr><th>Earning</th><th>Shipment</th><th>Courier</th><th>Net</th><th>Reason</th><th>Note</th><th>Forfeited At</th></tr></thead><tbody>';
        foreach ($rows as $row) {
            echo '<tr><td><code>#' . esc_html((string)$row['earning_id']) . '</code></td><td><code>#' . esc_html((string)$row['shipment_id']) . '</code></td><td>' . esc_html($row['courier_name']) . '</td><td>' . esc_html('GYD ' . number_format((float)$row['amount'],2)) . '</td><td>' . esc_html($row['reason']) . '</td><td>' . esc_html($row['note']) . '</td><td>' . esc_html(((int)$row['resolved_at'] > 0) ? gmdate('Y-m-d H:i', (int)$row['resolved_at']) . ' UTC' : '—') . '</td></tr>';
        }
        echo '</tbody></table></div></div>';
    }
}
