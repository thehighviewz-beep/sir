<?php
namespace Caricove\Bank;

if ( ! defined('ABSPATH') ) { exit; }

final class BankCourierPayoutRequestsTab {

    public static function boot(): void {
        add_action('admin_post_cc_bank_courier_payout_approve', [__CLASS__, 'post_approve']);
        add_action('admin_post_cc_bank_courier_payout_hold',    [__CLASS__, 'post_hold']);
        add_action('admin_post_cc_bank_courier_payout_reject',  [__CLASS__, 'post_reject']);
    }

    public static function render(): void {
        if ( ! self::deps_ok() ) { self::render_missing(); return; }
        $rows = self::filtered_rows('all');
        echo self::styles();
        echo '<div class="cbank-card" style="margin-top:16px;border:1px solid #000;background:#fff;color:#000;">';
        echo '<div style="display:flex;justify-content:space-between;gap:16px;align-items:flex-start;margin-bottom:16px;">';
        echo '<div><h1 style="margin:0;color:#000;">Courier Payout Requests</h1><p class="description" style="margin:6px 0 0;">Approve marks courier earnings paid. Hold moves the selected request amount into Held Queue. Standard payout requests are the canonical courier cash-out flow.</p></div>';
        echo '<div style="background:#000;color:#fff;padding:8px 12px;border-radius:999px;font-weight:600;">' . esc_html((string) count($rows)) . ' visible</div>';
        echo '</div>';
        self::render_filter('payout_requests');
        self::render_notices();

        if (empty($rows)) { echo '<p style="margin:0;">No matching payout requests.</p></div>'; return; }

        echo '<div style="overflow:auto;"><table class="widefat striped"><thead><tr>';
        echo '<th>ID</th><th>Courier</th><th>Type</th><th>Destination</th><th>Amount</th><th>Status</th><th>Requested</th><th>Actions</th>';
        echo '</tr></thead><tbody>';
        foreach ($rows as $r) {
            $cid = (int) ($r['courier_id'] ?? 0);
            $u   = $cid ? get_user_by('id', $cid) : false;
            $name = $u ? ($u->display_name . ' (#' . $cid . ')') : ('#' . $cid);
            $status = (string) ($r['status'] ?? 'requested');
            echo '<tr>';
            echo '<td><code>' . esc_html((string) ($r['id'] ?? '')) . '</code></td>';
            echo '<td>' . esc_html($name) . '</td>';
            echo '<td>' . self::type_badge((string) ($r['type'] ?? 'scheduled')) . '</td>';
            echo '<td>' . self::destination_badge($r) . '</td>';
            echo '<td>' . esc_html(self::money((float) ($r['amount_gyd'] ?? 0))) . '</td>';
            echo '<td>' . self::badge($status) . '</td>';
            echo '<td>' . esc_html(self::ts((int) ($r['ts'] ?? 0))) . '</td>';
            echo '<td>';
            if ($status === 'requested') {
                echo self::action_link('Approve', 'cc_bank_courier_payout_approve', (string) ($r['id'] ?? ''), 'green');
                echo ' ' . self::action_link('Hold', 'cc_bank_courier_payout_hold', (string) ($r['id'] ?? ''), 'amber');
                echo ' ' . self::action_link('Reject', 'cc_bank_courier_payout_reject', (string) ($r['id'] ?? ''), 'ghost');
            } else {
                echo '<span style="color:#666;">Finalized</span>';
            }
            echo '</td></tr>';
        }
        echo '</tbody></table></div></div>';
    }

    public static function filtered_rows(string $type): array {
        $all       = \Caricove_Courier_Earnings_Payouts::get_requests();
        $q         = sanitize_text_field((string) ($_GET['cq'] ?? ''));
        $date_from = sanitize_text_field((string) ($_GET['from'] ?? ''));
        $date_to   = sanitize_text_field((string) ($_GET['to'] ?? ''));
        $rows = array_values(array_filter((array) $all, static function ($r) use ($type, $q, $date_from, $date_to) {
            $row_type = (string) ($r['type'] ?? 'scheduled');
            if ($type !== 'all' && $row_type !== $type) return false;
            $cid    = (int) ($r['courier_id'] ?? 0);
            $u      = $cid ? get_user_by('id', $cid) : false;
            $method_label = self::destination_text($r);
            $hay    = strtolower(trim(($u ? ($u->display_name . ' ' . $u->user_email) : '') . ' #' . $cid . ' ' . ($r['id'] ?? '') . ' ' . $method_label));
            $needle = strtolower(trim($q));
            $ts     = (int) ($r['ts'] ?? 0);
            if ($needle !== '' && strpos($hay, $needle) === false) return false;
            if ($date_from !== '' && $ts < strtotime($date_from . ' 00:00:00 UTC')) return false;
            if ($date_to   !== '' && $ts > strtotime($date_to   . ' 23:59:59 UTC')) return false;
            return true;
        }));
        usort($rows, static function ($a, $b) { return (int) ($b['ts'] ?? 0) <=> (int) ($a['ts'] ?? 0); });
        return $rows;
    }

    public static function post_approve(): void {
        self::guard();
        $id = sanitize_text_field((string) ($_GET['id'] ?? ''));
        $ok = \Caricove_Courier_Earnings_Payouts::process_request($id, 'approve');
        self::redirect(self::request_tab($id), $ok ? 'approved' : 'insufficient');
    }

    public static function post_hold(): void {
        self::guard();
        $id = sanitize_text_field((string) ($_GET['id'] ?? ''));
        $ok = \Caricove_Courier_Earnings_Payouts::process_request($id, 'hold');
        self::redirect(self::request_tab($id), $ok ? 'held' : 'insufficient');
    }

    public static function post_reject(): void {
        self::guard();
        $id = sanitize_text_field((string) ($_GET['id'] ?? ''));
        $req = \Caricove_Courier_Earnings_Payouts::get_requests();
        foreach ($req as &$r) {
            if (($r['id'] ?? '') === $id && ($r['status'] ?? '') === 'requested') {
                $r['status'] = 'rejected';
                $r['rejected_at'] = time();
                break;
            }
        }
        unset($r);
        \Caricove_Courier_Earnings_Payouts::save_requests($req);
        self::redirect(self::request_tab($id), 'rejected');
    }

    public static function request_tab(string $id): string {
        return 'payout_requests';
    }

    private static function render_filter(string $tab): void {
        echo '<form method="get" style="display:flex;flex-wrap:wrap;gap:10px;margin:0 0 16px;">';
        echo '<input type="hidden" name="page" value="caricove-bank">';
        echo '<input type="hidden" name="tab" value="' . esc_attr($tab) . '">';
        echo '<input type="text" name="cq" value="' . esc_attr((string) ($_GET['cq'] ?? '')) . '" placeholder="Courier / email / request id" style="padding:8px 10px;min-width:220px;">';
        echo '<input type="date" name="from" value="' . esc_attr((string) ($_GET['from'] ?? '')) . '" style="padding:8px 10px;">';
        echo '<input type="date" name="to" value="' . esc_attr((string) ($_GET['to'] ?? '')) . '" style="padding:8px 10px;">';
        echo '<button type="submit" class="button button-primary">Filter</button></form>';
    }

    public static function render_notices(): void {
        $map = ['approved'=>'Courier payout approved and marked paid.','held'=>'Courier payout request moved into Held Queue.','rejected'=>'Payout request rejected.','insufficient'=>'Not enough available courier funds to process that request.'];
        foreach ($map as $key => $label) {
            if (!isset($_GET[$key])) continue;
            $tone = ($key === 'insufficient') ? 'error' : 'success';
            echo '<div class="notice notice-' . esc_attr($tone) . ' inline"><p>' . esc_html($label) . '</p></div>';
        }
    }

    private static function action_link(string $label, string $action, string $id, string $tone): string {
        $url = wp_nonce_url(admin_url('admin-post.php?action=' . rawurlencode($action) . '&id=' . rawurlencode($id)), 'cc_bank_courier_payout_admin');
        $styles = [
            'green' => 'background:#0f7b3b;border-color:#0f7b3b;color:#fff;',
            'amber' => 'background:#7a5200;border-color:#7a5200;color:#fff;',
            'ghost' => 'background:#fff;border-color:#000;color:#000;',
        ];
        return '<a class="button" style="margin:0 6px 6px 0;' . esc_attr($styles[$tone] ?? '') . '" href="' . esc_url($url) . '">' . esc_html($label) . '</a>';
    }


    private static function destination_text(array $row): string {
        $snap = isset($row['payout_method']) && is_array($row['payout_method']) ? $row['payout_method'] : [];
        $label = trim((string) ($row['payout_destination_label'] ?? $snap['destination_label'] ?? ''));
        if ($label !== '') {
            return $label;
        }

        $cid = (int) ($row['courier_id'] ?? 0);
        if ($cid > 0) {
            $profile = get_user_meta($cid, '_ccv_courier_payout_method_v1', true);
            if (is_array($profile)) {
                $type = sanitize_key((string) ($profile['type'] ?? ''));
                if ($type === 'mmg') {
                    $last4 = self::last4((string) ($profile['phone_last4'] ?? $profile['phone'] ?? ''));
                    return $last4 !== '' ? 'MMG • ••••' . $last4 : 'MMG profile saved';
                }
                if ($type === 'bank') {
                    $last4 = self::last4((string) ($profile['bank_account_last4'] ?? ''));
                    $bank  = trim((string) ($profile['bank_name'] ?? 'Bank'));
                    return 'Bank transfer • ' . $bank . ($last4 !== '' ? ' • ••••' . $last4 : '');
                }
                if ($type === 'card') {
                    $last4 = self::last4((string) ($profile['card_last4'] ?? ''));
                    $brand = trim((string) ($profile['card_brand'] ?? 'Card'));
                    return 'Card payout • ' . $brand . ($last4 !== '' ? ' • ••••' . $last4 : '');
                }
            }
        }

        return 'No payout method snapshot';
    }

    private static function destination_badge(array $row): string {
        $text = self::destination_text($row);
        $snap = isset($row['payout_method']) && is_array($row['payout_method']) ? $row['payout_method'] : [];
        $processor = trim((string) ($row['processor_status'] ?? $snap['processor_status'] ?? 'standby'));
        $processor_label = $processor !== '' ? ucwords(str_replace('_', ' ', $processor)) : 'Standby';

        $is_missing = ($text === 'No payout method snapshot');
        $bg = $is_missing ? '#fff3cd' : '#e7f1ff';
        $fg = $is_missing ? '#664d03' : '#084298';

        return '<div style="display:grid;gap:4px;min-width:180px;">'
            . '<span style="display:inline-block;padding:4px 10px;border-radius:999px;font-size:12px;font-weight:700;background:' . esc_attr($bg) . ';color:' . esc_attr($fg) . ';">' . esc_html($text) . '</span>'
            . '<small style="color:#444;">' . esc_html($processor_label) . '</small>'
            . '</div>';
    }

    private static function last4(string $value): string {
        $digits = preg_replace('/\D+/', '', $value);
        if (strlen($digits) < 4) {
            return '';
        }
        return substr($digits, -4);
    }

    private static function type_badge(string $type): string {
        $type = strtolower(trim($type));
        if ($type === 'instant') {
            return '<span style="display:inline-block;padding:4px 10px;border-radius:999px;font-size:12px;font-weight:700;background:#e7f1ff;color:#084298;">Legacy standardized</span>';
        }
        return '<span style="display:inline-block;padding:4px 10px;border-radius:999px;font-size:12px;font-weight:700;background:#e8f5e9;color:#0f5132;">Standard</span>';
    }

    private static function badge(string $status): string {
        $styles = [
            'requested' => 'background:#fff3cd;color:#664d03;',
            'approved'  => 'background:#d1e7dd;color:#0f5132;',
            'held'      => 'background:#e2d9f3;color:#4b2e83;',
            'rejected'  => 'background:#f8d7da;color:#842029;',
        ];
        return '<span style="display:inline-block;padding:4px 10px;border-radius:999px;font-size:12px;font-weight:700;text-transform:capitalize;' . esc_attr($styles[$status] ?? 'background:#eee;color:#111;') . '">' . esc_html($status) . '</span>';
    }

    private static function guard(): void {
        if (! current_user_can('manage_options')) wp_die('Unauthorized');
        check_admin_referer('cc_bank_courier_payout_admin');
        if (! self::deps_ok()) wp_die('Courier earnings dependencies are missing.');
    }

    private static function redirect(string $tab, string $flag): void {
        wp_safe_redirect(add_query_arg(['page'=>'caricove-bank','tab'=>$tab,$flag=>1], admin_url('admin.php')));
        exit;
    }

    private static function deps_ok(): bool {
        return class_exists('\\Caricove_Courier_Earnings_Payouts') && class_exists('\\Caricove_Courier_Earnings_Engine');
    }

    private static function render_missing(): void {
        echo '<div class="cbank-card" style="margin-top:16px;border:1px solid #000;background:#fff;color:#000;">';
        echo '<h1 style="margin-top:0;color:#000;">Courier Earnings dependency missing</h1>';
        echo '<p style="margin:0;">The courier earnings engine or payout request module is not loaded, so this tab cannot render truthfully.</p></div>';
    }

    private static function money(float $amount): string { return 'GYD ' . number_format($amount, 2); }
    private static function ts(int $ts): string { return $ts > 0 ? gmdate('Y-m-d H:i', $ts) . ' UTC' : '—'; }
    private static function styles(): string { return ''; }
}
