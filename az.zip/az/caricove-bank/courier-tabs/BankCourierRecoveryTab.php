<?php
namespace Caricove\Bank;

if ( ! defined( 'ABSPATH' ) ) { exit; }

final class BankCourierRecoveryTab {

    private const RECOVERY_OPTION       = 'caricove_bank_courier_recovery_v1';
    private const FRONTED_OPTION        = 'caricove_bank_platform_fronted_v1';
    private const RECOVERED_LEDGER_MARK = 'recovered';

    public static function boot(): void {
        add_action( 'admin_post_cc_bank_recovery_begin', [ __CLASS__, 'post_begin_recovery' ] );
        add_action( 'admin_post_cc_bank_recovery_manual_payment', [ __CLASS__, 'post_manual_payment' ] );
        add_action( 'admin_post_cc_bank_recovery_waive_amount', [ __CLASS__, 'post_waive_amount' ] );

       add_action( 'cc_earnings_ledger_created', [ __CLASS__, 'hook_earning_created' ], 20, 4 );
        add_action( 'cc_earnings_held', [ __CLASS__, 'hook_earning_held' ], 20, 3 );
        add_action( 'cc_earnings_hold_forfeited', [ __CLASS__, 'hook_earning_forfeited' ], 20, 2 );
        add_action( 'cc_earning_became_available', [ __CLASS__, 'hook_earning_available' ], 20, 1 );

        add_action( 'cc_bank_courier_recovery_cron', [ __CLASS__, 'run_cron_sweep' ] );
    }

public static function render(): void {
    if ( ! class_exists( '\\Caricove_Courier_Earnings_Engine' ) ) {
        self::render_missing( 'Courier earnings engine is not loaded.' );
        return;
    }

    self::render_notices();

    $case_id_filter = sanitize_text_field( (string) ( $_GET['case_id'] ?? '' ) );
    $status_filter  = sanitize_key( (string) ( $_GET['recovery_status'] ?? '' ) );
    $q              = sanitize_text_field( (string) ( $_GET['rq'] ?? '' ) );

    $cases    = self::filtered_cases( $case_id_filter, $status_filter, $q );
    $selected = null;

    if ( $case_id_filter !== '' ) {
        foreach ( $cases as $case ) {
            if ( (string) ( $case['recovery_case_id'] ?? '' ) === $case_id_filter ) {
                $selected = $case;
                break;
            }
        }
    }

    if ( ! $selected && ! empty( $cases ) ) {
        $selected = $cases[0];
    }

    echo self::styles();

    echo '<div class="ccrc-wrap">';
    echo '<div class="ccrc-shell">';

    echo '<div class="ccrc-head">';
    echo '<div>';
    echo '<h1 class="ccrc-title">Courier Recovery</h1>';
    echo '<p class="ccrc-sub">Recovery sweeps only collect from held, forfeited, and available courier earnings — in that exact order. Clearing stays visible for awareness but is never collectible here.</p>';
    echo '</div>';
    echo '<div class="ccrc-chip">' . esc_html( (string) count( $cases ) ) . ' cases</div>';
    echo '</div>';

    echo '<form method="get" class="ccrc-filters">';
    echo '<input type="hidden" name="page" value="caricove-bank">';
    echo '<input type="hidden" name="tab" value="courier_recovery">';
    echo '<input class="ccrc-input" type="text" name="rq" value="' . esc_attr( $q ) . '" placeholder="Recovery case / fronted case / courier / order / shipment">';
    echo '<select class="ccrc-select" name="recovery_status">';
    $statuses = [
        ''                    => 'All statuses',
        'open'                => 'Open',
        'recovering'          => 'Recovering',
        'partially_recovered' => 'Partially Recovered',
        'recovered'           => 'Recovered',
        'waived'              => 'Waived',
    ];
    foreach ( $statuses as $value => $label ) {
        echo '<option value="' . esc_attr( $value ) . '"' . selected( $status_filter, $value, false ) . '>' . esc_html( $label ) . '</option>';
    }
    echo '</select>';
    echo '<button type="submit" class="button button-primary ccrc-filter-btn">Filter</button>';
    echo '</form>';

    echo '<section class="ccrc-panel">';
    echo '<div class="ccrc-panel-head">';
    echo '<div class="ccrc-panel-title">Recovery Cases</div>';
    echo '<div class="ccrc-panel-note">Snapshot</div>';
    echo '</div>';

    if ( empty( $cases ) ) {
        echo '<div class="ccrc-empty">No recovery cases found.</div>';
    } else {
        echo '<div class="ccrc-tablewrap ccrc-snapshot-wrap">';
        echo '<table class="widefat striped ccrc-table ccrc-snapshot-table">';
        echo '<thead><tr>';
        echo '<th>Recovery Case</th>';
        echo '<th>Fronted Case</th>';
        echo '<th>Courier</th>';
        echo '<th>Order</th>';
        echo '<th>Shipment</th>';
        echo '<th class="ccrc-money">Recoverable</th>';
        echo '<th class="ccrc-money">Recovered</th>';
        echo '<th class="ccrc-money">Remaining</th>';
        echo '<th>Status</th>';
        echo '<th>Open</th>';
        echo '</tr></thead><tbody>';

        foreach ( $cases as $case ) {
            $open_url = add_query_arg(
                [
                    'page'            => 'caricove-bank',
                    'tab'             => 'courier_recovery',
                    'case_id'         => (string) ( $case['recovery_case_id'] ?? '' ),
                    'recovery_status' => $status_filter,
                    'rq'              => $q,
                ],
                admin_url( 'admin.php' )
            );

            $is_active = $selected && (string) ( $selected['recovery_case_id'] ?? '' ) === (string) ( $case['recovery_case_id'] ?? '' );

            echo '<tr' . ( $is_active ? ' class="ccrc-active-row"' : '' ) . '>';
            echo '<td><code>' . esc_html( (string) ( $case['recovery_case_id'] ?? '' ) ) . '</code></td>';
            echo '<td><code>' . esc_html( (string) ( $case['platform_fronted_case_id'] ?? '—' ) ) . '</code></td>';
            echo '<td>' . esc_html( (string) ( $case['courier_name'] ?? '—' ) ) . '</td>';
            echo '<td><code>#' . esc_html( (string) ( $case['order_id'] ?? 0 ) ) . '</code></td>';
            echo '<td><code>#' . esc_html( (string) ( $case['shipment_id'] ?? 0 ) ) . '</code></td>';
            echo '<td class="ccrc-money">' . esc_html( self::money( (float) ( $case['recoverable_amount_total'] ?? 0 ) ) ) . '</td>';
            echo '<td class="ccrc-money">' . esc_html( self::money( (float) ( $case['recovered_amount_total'] ?? 0 ) ) ) . '</td>';
            echo '<td class="ccrc-money ccrc-money-strong">' . esc_html( self::money( (float) ( $case['remaining_amount_total'] ?? 0 ) ) ) . '</td>';
            echo '<td>' . self::badge( (string) ( $case['status'] ?? 'open' ) ) . '</td>';
            echo '<td><a class="button" href="' . esc_url( $open_url ) . '">Open</a></td>';
            echo '</tr>';
        }

        echo '</tbody></table>';
        echo '</div>';
    }

    echo '</section>';

   echo '<section class="ccrc-panel">';
    echo '<div class="ccrc-panel-head">';
    echo '<div class="ccrc-panel-note">Selected case</div>';
    echo '</div>';

    if ( ! $selected ) {
        echo '<div class="ccrc-empty">Select a recovery case to view the operational detail.</div>';
        echo '</section></div></div>';
        return;
    }

    $pools      = self::courier_pools( (int) ( $selected['courier_id'] ?? 0 ) );
    $percent = self::recovery_percent(
    (float) ( ($selected['recovered_amount_total'] ?? 0) + ($selected['waived_amount_total'] ?? 0) ),
    (float) ( $selected['recoverable_amount_total'] ?? 0 )
);
    $bar_tone   = self::battery_tone( $percent );
    $actions    = is_array( $selected['actions'] ?? null ) ? $selected['actions'] : [];

    echo '<div class="ccrc-detail-stage">';
    echo '<div class="ccrc-stage-topline">';
    echo '<div class="ccrc-stage-pillbox"><span class="ccrc-stage-pill-label">Status</span>' . self::badge( (string) ( $selected['status'] ?? 'open' ) ) . '</div>';
  echo '<div class="ccrc-stage-pillbox ccrc-stage-pillbox-right"><span class="ccrc-stage-pill-label">Courier</span><span class="ccrc-stage-pill">' . esc_html( (string) ( $selected['courier_name'] ?? '—' ) ) . '</span></div>';
    echo '<div class="ccrc-stage-pillbox"><span class="ccrc-stage-pill-label">Auto</span><span class="ccrc-stage-pill">' . ( ! empty( $selected['auto_enabled'] ) ? 'ON' : 'OFF' ) . '</span></div>';
    echo '</div>';

   

    echo '<div class="ccrc-pool-grid">';
    echo self::pool_box( 'Available', (float) ( $pools['available'] ?? 0 ) );
    echo self::pool_box( 'Clearing', (float) ( $pools['clearing'] ?? 0 ) );
    echo self::pool_box( 'Held', (float) ( $pools['held'] ?? 0 ) );
    echo self::pool_box( 'Forfeited', (float) ( $pools['forfeited'] ?? 0 ) );
    echo '</div>';
    echo '</div>';

    echo '<div class="ccrc-battery-block">';
    echo '<div class="ccrc-battery-top">';
    echo '<div class="ccrc-battery-title">Recovery Battery</div>';
    echo '<div class="ccrc-battery-percent">' . esc_html( number_format( $percent, 2 ) ) . '%</div>';
    echo '</div>';
    echo '<div class="ccrc-battery-wrap">';
    echo '<div class="ccrc-battery ccrc-battery-' . esc_attr( $bar_tone ) . '">';
    echo '<div class="ccrc-battery-fill" style="width:' . esc_attr( number_format( $percent, 2, '.', '' ) ) . '%"></div>';
    echo '<div class="ccrc-battery-glow"></div>';
    echo '</div>';
    echo '<div class="ccrc-battery-cap"></div>';
    echo '</div>';
    echo '<div class="ccrc-battery-legend">';
    echo '<span>Recovered ' . esc_html( self::money( (float) ( $selected['recovered_amount_total'] ?? 0 ) ) ) . '</span>';
    echo '<span>Recoverable ' . esc_html( self::money( (float) ( $selected['recoverable_amount_total'] ?? 0 ) ) ) . '</span>';
    echo '</div>';
    echo '</div>';

    echo '<div class="ccrc-action-stack">';
    echo '<div class="ccrc-action-card ccrc-action-primary">';
    echo '<div class="ccrc-action-title">Begin Recovery</div>';
    echo '<div class="ccrc-action-help">One click full sweep. It checks collectible pools in strict order — held, forfeited, then available — and stops only when the debt is cleared or no collectible money remains. Clearing is never touched.</div>';
    echo self::simple_action_form(
        'cc_bank_recovery_begin',
        (string) ( $selected['recovery_case_id'] ?? '' ),
        'Begin Recovery',
        'button button-primary ccrc-btn ccrc-btn-begin'
    );
    echo '</div>';

    echo '<div class="ccrc-manual-grid">';
    echo '<div class="ccrc-action-card">';
    echo '<div class="ccrc-action-title">Record Manual Payment</div>';
    echo '<div class="ccrc-action-help">Use this only when money was repaid outside the courier earnings pools.</div>';
    echo self::amount_action_form(
        'cc_bank_recovery_manual_payment',
        (string) ( $selected['recovery_case_id'] ?? '' ),
        'amount',
        'Payment amount',
        'Record Manual Payment',
        'button ccrc-btn'
    );
    echo '</div>';

    echo '<div class="ccrc-action-card">';
    echo '<div class="ccrc-action-title">Waive Amount</div>';
    echo '<div class="ccrc-action-help">Administrative debt reduction. This lowers the remaining balance without touching courier earnings pools.</div>';
    echo self::amount_action_form(
        'cc_bank_recovery_waive_amount',
        (string) ( $selected['recovery_case_id'] ?? '' ),
        'amount',
        'Waive amount',
        'Waive Amount',
        'button ccrc-btn ccrc-btn-alt'
    );
    echo '</div>';
    echo '</div>';
    echo '</div>';

    echo '<div class="ccrc-history-block">';
    echo '<div class="ccrc-history-head">';
    echo '<div class="ccrc-panel-title">Recovery History</div>';
    echo '<div class="ccrc-panel-note">' . esc_html( (string) count( $actions ) ) . ' rows</div>';
    echo '</div>';

    if ( empty( $actions ) ) {
        echo '<div class="ccrc-empty ccrc-empty-slim">No recovery history has been logged for this case yet.</div>';
    } else {
        echo '<div class="ccrc-tablewrap">';
        echo '<table class="widefat striped ccrc-table">';
        echo '<thead><tr><th>When</th><th>Action</th><th>Source</th><th class="ccrc-money">Amount</th><th>Note</th></tr></thead><tbody>';
        foreach ( array_reverse( $actions ) as $action ) {
            echo '<tr>';
            echo '<td>' . esc_html( self::date_human( (int) ( $action['created_at'] ?? 0 ) ) ) . '</td>';
            echo '<td>' . esc_html( self::human_action( (string) ( $action['action_type'] ?? '' ) ) ) . '</td>';
            echo '<td>' . esc_html( self::human_action( (string) ( $action['source'] ?? '' ) ) ) . '</td>';
            echo '<td class="ccrc-money">' . esc_html( self::money( (float) ( $action['amount'] ?? 0 ) ) ) . '</td>';
            echo '<td>' . esc_html( (string) ( $action['note'] ?? '—' ) ) . '</td>';
            echo '</tr>';
        }
        echo '</tbody></table>';
        echo '</div>';
    }

    echo '</div>';
    echo '</section>';

    echo '</div>';
    echo '</div>';
}

public static function hook_earning_created( $earning_id, $shipment_id, $courier_id, $context = [] ): void {
    $courier_id = (int) $courier_id;
    if ( $courier_id > 0 ) {
        self::auto_recover_for_courier( $courier_id, 'ledger_created' );
    }
}

public static function hook_earning_held( $earning_id, $reason = '', $note = '' ): void {
    self::auto_recover_from_earning( (int) $earning_id, 'held' );
}

public static function hook_earning_forfeited( $earning_id, $admin_user_id = 0 ): void {
    self::auto_recover_from_earning( (int) $earning_id, 'forfeited' );
}

public static function hook_earning_available( $earning_id ): void {
    self::auto_recover_from_earning( (int) $earning_id, 'available' );
}

public static function run_cron_sweep(): void {
    $store         = self::get_recovery_store();
    $courier_ids   = [];
    $cases_checked = 0;
    $cases_changed = 0;
    $total_applied = 0.0;

    foreach ( (array) $store as $case ) {
        if ( ! is_array( $case ) ) {
            continue;
        }

        $case = self::hydrate_case( $case );
        $status = sanitize_key( (string) ( $case['status'] ?? 'open' ) );
        $remaining = round( (float) ( $case['remaining_amount_total'] ?? 0 ), 2 );

       if ( $remaining <= 0 || ! in_array( $status, [ 'open', 'recovering', 'partially_recovered' ], true ) ) {
            continue;
        }

        if ( empty( $case['auto_enabled'] ) ) {
            continue;
        }

        $courier_id = (int) ( $case['courier_id'] ?? 0 );
        if ( $courier_id <= 0 ) {
            continue;
        }

        $courier_ids[ $courier_id ] = true;
    }

    foreach ( array_keys( $courier_ids ) as $courier_id ) {
        $result = self::auto_recover_for_courier( (int) $courier_id, 'cron' );
        $cases_checked += (int) ( $result['cases_checked'] ?? 0 );
        $cases_changed += (int) ( $result['cases_changed'] ?? 0 );
        $total_applied += (float) ( $result['applied_total'] ?? 0 );
    }

    update_option(
        '_cc_bank_recovery_last_cron_sweep',
        [
            'ran_at'         => time(),
            'cases_checked'  => (int) $cases_checked,
            'cases_changed'  => (int) $cases_changed,
            'applied_total'  => round( (float) $total_applied, 2 ),
            'couriers_count' => count( $courier_ids ),
        ],
        false
    );
}

public static function auto_recover_for_courier( int $courier_id, string $trigger = 'hook' ): array {
    $courier_id = (int) $courier_id;
    if ( $courier_id <= 0 ) {
        return [ 'cases_checked' => 0, 'cases_changed' => 0, 'applied_total' => 0.0 ];
    }

    static $request_guard = [];
    $guard_key = $trigger . '|' . $courier_id;
    if ( isset( $request_guard[ $guard_key ] ) ) {
        return [ 'cases_checked' => 0, 'cases_changed' => 0, 'applied_total' => 0.0 ];
    }
    $request_guard[ $guard_key ] = true;

    $store         = self::get_recovery_store();
    $case_ids      = [];
    $cases_changed = 0;
    $applied_total = 0.0;

    foreach ( (array) $store as $case ) {
        if ( ! is_array( $case ) ) {
            continue;
        }

        $case = self::hydrate_case( $case );
        $status = sanitize_key( (string) ( $case['status'] ?? 'open' ) );
        $remaining = round( (float) ( $case['remaining_amount_total'] ?? 0 ), 2 );

       if ( $remaining <= 0 || ! in_array( $status, [ 'open', 'recovering', 'partially_recovered' ], true ) ) {
            continue;
        }

        if ( empty( $case['auto_enabled'] ) ) {
            continue;
        }

        if ( (int) ( $case['courier_id'] ?? 0 ) !== $courier_id ) {
            continue;
        }

        $case_ids[] = (string) ( $case['recovery_case_id'] ?? '' );
    }

    foreach ( array_unique( array_filter( $case_ids ) ) as $case_id ) {
        $result = self::begin_recovery_sweep( (string) $case_id, $trigger );
        if ( (float) ( $result['applied'] ?? 0 ) > 0 ) {
            $cases_changed++;
            $applied_total += (float) ( $result['applied'] ?? 0 );
        }
    }

    return [
        'cases_checked' => count( array_unique( array_filter( $case_ids ) ) ),
        'cases_changed' => (int) $cases_changed,
        'applied_total' => round( (float) $applied_total, 2 ),
    ];
}

private static function auto_recover_from_earning( int $earning_id, string $trigger ): void {
    if ( $earning_id <= 0 || ! class_exists( '\\Caricove_Courier_Earnings_Engine' ) ) {
        return;
    }

    $courier_id = (int) get_post_meta( $earning_id, \Caricove_Courier_Earnings_Engine::META_COURIER_ID, true );
    if ( $courier_id > 0 ) {
        self::auto_recover_for_courier( $courier_id, $trigger );
    }
}

   public static function post_begin_recovery(): void {
        self::guard();
        $case_id = sanitize_text_field( (string) ( $_POST['recovery_case_id'] ?? '' ) );

        if ( $case_id !== '' ) {
            $store = self::get_recovery_store();
            foreach ( (array) $store as $idx => $case ) {
                if ( ! is_array( $case ) ) {
                    continue;
                }
                if ( (string) ( $case['recovery_case_id'] ?? '' ) !== $case_id ) {
                    continue;
                }

                $case = self::hydrate_case( $case );
                $case['auto_enabled'] = 1;
                $store[ $idx ] = $case;
update_option( 'caricove_bank_courier_recovery_v1', $store );                break;
            }
        }

        $result  = self::begin_recovery_sweep( $case_id, 'manual_button' );
        self::redirect_case( $case_id, ( (float) ( $result['applied'] ?? 0 ) > 0 ) ? 'applied' : 'failed' );
    }

    public static function post_manual_payment(): void {
        self::guard();
        $case_id = sanitize_text_field( (string) ( $_POST['recovery_case_id'] ?? '' ) );
        $amount  = round( (float) ( $_POST['amount'] ?? 0 ), 2 );

        if ( $amount <= 0 ) {
            self::redirect_case( $case_id, 'failed' );
        }

        $ok = self::apply_manual( $case_id, $amount );
        self::redirect_case( $case_id, $ok ? 'applied' : 'failed' );
    }

    public static function post_waive_amount(): void {
        self::guard();
        $case_id = sanitize_text_field( (string) ( $_POST['recovery_case_id'] ?? '' ) );
        $amount  = round( (float) ( $_POST['amount'] ?? 0 ), 2 );

        if ( $amount <= 0 ) {
            self::redirect_case( $case_id, 'failed' );
        }

        $ok = self::waive_amount( $case_id, $amount );
        self::redirect_case( $case_id, $ok ? 'applied' : 'failed' );
    }

    private static function guard(): void {
        if ( ! current_user_can( 'manage_options' ) && ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( 'Unauthorized' );
        }

        check_admin_referer( 'cc_bank_recovery_action' );
    }

    private static function filtered_cases( string $case_id_filter, string $status_filter, string $q ): array {
        $cases = self::get_recovery_store();
        $out   = [];

        foreach ( (array) $cases as $case ) {
            if ( ! is_array( $case ) || empty( $case['recovery_case_id'] ) ) {
                continue;
            }

            $case = self::hydrate_case( $case );

            if ( $case_id_filter !== '' && (string) ( $case['recovery_case_id'] ?? '' ) !== $case_id_filter ) {
                continue;
            }

            $case_status = sanitize_key( (string) ( $case['status'] ?? 'open' ) );
            if ( $status_filter !== '' && $case_status !== $status_filter ) {
                continue;
            }

            if ( $q !== '' ) {
                $haystack = strtolower( implode( ' ', [
                    (string) ( $case['recovery_case_id'] ?? '' ),
                    (string) ( $case['platform_fronted_case_id'] ?? '' ),
                    (string) ( $case['courier_name'] ?? '' ),
                    (string) ( $case['order_id'] ?? '' ),
                    (string) ( $case['shipment_id'] ?? '' ),
                    (string) ( $case['status'] ?? '' ),
                ] ) );

                if ( strpos( $haystack, strtolower( trim( $q ) ) ) === false ) {
                    continue;
                }
            }

            $out[] = $case;
        }

        usort(
            $out,
            static function ( array $a, array $b ): int {
                return (int) ( $b['created_at'] ?? 0 ) <=> (int) ( $a['created_at'] ?? 0 );
            }
        );

        return $out;
    }

    private static function hydrate_case( array $case ): array {
        $shipment_id            = (int) ( $case['shipment_id'] ?? 0 );
        $canonical_courier_id   = self::canonical_courier_id( $shipment_id, $case );
        $case['courier_id']     = $canonical_courier_id;
        $case['courier_name']   = self::courier_name( $canonical_courier_id );
        $case['status']         = self::status_from_totals( $case, (string) ( $case['status'] ?? '' ) );
        $case['actions']        = is_array( $case['actions'] ?? null ) ? $case['actions'] : [];
        $case['created_at']     = (int) ( $case['created_at'] ?? 0 );
        $case['updated_at']     = (int) ( $case['updated_at'] ?? 0 );
        $case['order_id']       = (int) ( $case['order_id'] ?? 0 );
        $case['shipment_id']    = $shipment_id;
        return $case;
    }

    private static function canonical_courier_id( int $shipment_id, array $case = [] ): int {
        if ( $shipment_id > 0 ) {
            if ( class_exists( '\\Caricove\\Logistics\\Core\\ShipmentManager' ) && method_exists( '\\Caricove\\Logistics\\Core\\ShipmentManager', 'get_shipment_summary' ) ) {
                $summary = \Caricove\Logistics\Core\ShipmentManager::get_shipment_summary( $shipment_id );
                $cid     = (int) ( $summary['courier_id'] ?? 0 );
                if ( $cid > 0 ) {
                    return $cid;
                }
            }

            $cid = (int) get_post_meta( $shipment_id, self::shipment_courier_meta_key(), true );
            if ( $cid > 0 ) {
                return $cid;
            }
        }

        return (int) ( $case['courier_id'] ?? 0 );
    }

    private static function shipment_courier_meta_key(): string {
        if ( class_exists( '\\Caricove\\Logistics\\Core\\Schema' ) && defined( '\\Caricove\\Logistics\\Core\\Schema::META_SHIPMENT_COURIER_ID' ) ) {
            return \Caricove\Logistics\Core\Schema::META_SHIPMENT_COURIER_ID;
        }

        return '_cc_shipment_courier_id';
    }

    private static function courier_pools( int $courier_id ): array {
        if ( $courier_id <= 0 || ! class_exists( '\\Caricove_Courier_Earnings_Engine' ) ) {
            return [
                'available' => 0.0,
                'clearing'  => 0.0,
                'held'      => 0.0,
                'forfeited' => 0.0,
            ];
        }

        $balances = \Caricove_Courier_Earnings_Engine::get_balances_for_courier( $courier_id );

        return [
            'available' => round( (float) ( $balances['available'] ?? 0 ), 2 ),
            'clearing'  => round( (float) ( $balances['clearing'] ?? 0 ), 2 ),
            'held'      => round( (float) ( $balances['held'] ?? 0 ), 2 ),
            'forfeited' => self::sum_earnings_by_status( $courier_id, 'forfeited' ),
        ];
    }


private static function meta_chip( string $label, string $value, string $extra_class = '' ): string {
    $class = trim( 'ccrc-meta-chip ' . $extra_class );
    return '<div class="' . esc_attr( $class ) . '"><span>' . esc_html( $label ) . '</span><b>' . esc_html( $value ) . '</b></div>';
}

private static function pool_box( string $label, float $amount ): string {
    return '<div class="ccrc-pool-box"><span>' . esc_html( $label ) . '</span><strong>' . esc_html( self::money( $amount ) ) . '</strong></div>';
}

    private static function detail_line( string $label, string $value_html ): string {
        return '<div class="ccrc-detail-line"><span>' . esc_html( $label ) . '</span><b>' . $value_html . '</b></div>';
    }

    private static function simple_action_form( string $action, string $case_id, string $label, string $button_class ): string {
        $html  = '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
        $html .= wp_nonce_field( 'cc_bank_recovery_action', '_wpnonce', true, false );
        $html .= '<input type="hidden" name="action" value="' . esc_attr( $action ) . '">';
        $html .= '<input type="hidden" name="recovery_case_id" value="' . esc_attr( $case_id ) . '">';
        $html .= '<button type="submit" class="' . esc_attr( $button_class ) . '">' . esc_html( $label ) . '</button>';
        $html .= '</form>';
        return $html;
    }

    private static function amount_action_form( string $action, string $case_id, string $field_name, string $placeholder, string $label, string $button_class ): string {
        $html  = '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
        $html .= wp_nonce_field( 'cc_bank_recovery_action', '_wpnonce', true, false );
        $html .= '<input type="hidden" name="action" value="' . esc_attr( $action ) . '">';
        $html .= '<input type="hidden" name="recovery_case_id" value="' . esc_attr( $case_id ) . '">';
        $html .= '<input class="ccrc-input" type="number" min="0" step="0.01" name="' . esc_attr( $field_name ) . '" placeholder="' . esc_attr( $placeholder ) . '" required>';
        $html .= '<button type="submit" class="' . esc_attr( $button_class ) . '">' . esc_html( $label ) . '</button>';
        $html .= '</form>';
        return $html;
    }

private static function begin_recovery_sweep( string $case_id, string $trigger = 'manual_button' ): array {
    if ( $case_id === '' ) {
        return [ 'applied' => 0.0, 'changed' => false ];
    }

    $store   = self::get_recovery_store();
    $changed = false;
    $applied = 0.0;

    foreach ( $store as &$case ) {
        if ( (string) ( $case['recovery_case_id'] ?? '' ) !== $case_id ) {
            continue;
        }

        $case       = self::hydrate_case( $case );
        $remaining  = round( (float) ( $case['remaining_amount_total'] ?? 0 ), 2 );
        $courier_id = (int) ( $case['courier_id'] ?? 0 );

        if ( $remaining <= 0 || $courier_id <= 0 ) {
            break;
        }

        foreach ( [ 'held', 'forfeited', 'available' ] as $source_status ) {
            if ( $remaining <= 0 ) {
                break;
            }

            $result = self::consume_earnings_by_status( $courier_id, $source_status, $remaining, $case_id );
            $taken  = round( (float) ( $result['taken'] ?? 0 ), 2 );

            if ( $taken <= 0 ) {
                continue;
            }

            self::record_action(
                $case,
                [
                    'action_type' => $trigger === 'manual_button' ? 'begin_recovery' : 'auto_recovery',
                    'source'      => $source_status,
                    'amount'      => $taken,
                    'note'        => $trigger === 'manual_button'
                        ? 'Manual Begin Recovery sweep from ' . $source_status
                        : 'Background sweep (' . self::human_action( $trigger ) . ') from ' . $source_status,
                ]
            );

            $remaining = round( max( 0.0, $remaining - $taken ), 2 );
            $applied   = round( $applied + $taken, 2 );

            $case['recovered_amount_total'] = round( (float) ( $case['recovered_amount_total'] ?? 0 ) + $taken, 2 );
            $case['remaining_amount_total'] = $remaining;
            $case['updated_at']             = time();

            if ( $source_status === 'held' ) {
                $case['recovered_from_held'] = round( (float) ( $case['recovered_from_held'] ?? 0 ) + $taken, 2 );
            } elseif ( $source_status === 'forfeited' ) {
                $case['recovered_from_forfeited'] = round( (float) ( $case['recovered_from_forfeited'] ?? 0 ) + $taken, 2 );
            } else {
                $case['recovered_from_available'] = round( (float) ( $case['recovered_from_available'] ?? 0 ) + $taken, 2 );
            }

            $changed = true;
        }

        $case['status'] = self::status_from_totals( $case );
        self::sync_fronted_remaining( (string) ( $case['platform_fronted_case_id'] ?? '' ), (float) ( $case['remaining_amount_total'] ?? 0 ) );
        break;
    }
    unset( $case );

    if ( $changed ) {
        update_option( self::RECOVERY_OPTION, $store, false );
    }

    return [
        'applied' => round( (float) $applied, 2 ),
        'changed' => (bool) $changed,
    ];
}

    private static function consume_earnings_by_status( int $courier_id, string $source_status, float $target_amount, string $case_id ): array {
        $courier_id   = (int) $courier_id;
        $target_amount = round( (float) $target_amount, 2 );

        if ( $courier_id <= 0 || $target_amount <= 0 || ! class_exists( '\\Caricove_Courier_Earnings_Engine' ) ) {
            return [ 'taken' => 0.0, 'allocations' => [] ];
        }

        $entries = get_posts(
            [
                'post_type'      => \Caricove_Courier_Earnings_Engine::CPT_EARNING,
                'post_status'    => 'any',
                'posts_per_page' => 500,
                'orderby'        => 'date',
                'order'          => 'ASC',
                'fields'         => 'ids',
                'meta_query'     => [
                    [
                        'key'   => \Caricove_Courier_Earnings_Engine::META_COURIER_ID,
                        'value' => $courier_id,
                    ],
                    [
                        'key'   => \Caricove_Courier_Earnings_Engine::META_STATUS,
                        'value' => $source_status,
                    ],
                ],
            ]
        );

        $remaining   = $target_amount;
        $taken       = 0.0;
        $allocations = [];

        foreach ( (array) $entries as $eid ) {
            if ( $remaining <= 0 ) {
                break;
            }

            $eid        = (int) $eid;
            $row_amount = round( (float) get_post_meta( $eid, \Caricove_Courier_Earnings_Engine::META_AMOUNT_GYD, true ), 2 );

            if ( $row_amount <= 0 ) {
                continue;
            }

            if ( $row_amount <= $remaining ) {
                self::mark_earning_recovered( $eid, $source_status, $case_id, $row_amount );

                $allocations[] = [
                    'eid'    => $eid,
                    'amount' => $row_amount,
                ];

                $taken     = round( $taken + $row_amount, 2 );
                $remaining = round( $remaining - $row_amount, 2 );
                continue;
            }

            $move_amount     = $remaining;
            $leftover_amount = round( $row_amount - $move_amount, 2 );

            $new_id = wp_insert_post(
                [
                    'post_type'   => \Caricove_Courier_Earnings_Engine::CPT_EARNING,
                    'post_status' => 'publish',
                    'post_title'  => get_the_title( $eid ) . ' — Recovery Split',
                ]
            );

            if ( ! $new_id || is_wp_error( $new_id ) ) {
                break;
            }

            self::clone_earning_meta( $eid, (int) $new_id );
            update_post_meta( $new_id, \Caricove_Courier_Earnings_Engine::META_AMOUNT_GYD, $move_amount );
            update_post_meta( $new_id, \Caricove_Courier_Earnings_Engine::META_STATUS, $source_status );
            self::mark_earning_recovered( (int) $new_id, $source_status, $case_id, $move_amount );

            update_post_meta( $eid, \Caricove_Courier_Earnings_Engine::META_AMOUNT_GYD, max( 0, $leftover_amount ) );

            $allocations[] = [
                'eid'    => (int) $new_id,
                'amount' => $move_amount,
            ];

            $taken     = round( $taken + $move_amount, 2 );
            $remaining = 0.0;
            break;
        }

        return [
            'taken'       => round( $taken, 2 ),
            'allocations' => $allocations,
        ];
    }

    private static function mark_earning_recovered( int $earning_id, string $source_status, string $case_id, float $amount ): void {
        $earning_id = (int) $earning_id;
        if ( $earning_id <= 0 || ! class_exists( '\\Caricove_Courier_Earnings_Engine' ) ) {
            return;
        }

        $note = 'Recovered by Courier Recovery case ' . $case_id . ' from ' . $source_status . ' (' . number_format( (float) $amount, 2, '.', '' ) . ' GYD)';

        update_post_meta( $earning_id, \Caricove_Courier_Earnings_Engine::META_STATUS, self::RECOVERED_LEDGER_MARK );
        update_post_meta( $earning_id, \Caricove_Courier_Earnings_Engine::META_HELD_RESOLUTION, self::RECOVERED_LEDGER_MARK );
        update_post_meta( $earning_id, \Caricove_Courier_Earnings_Engine::META_HELD_RESOLVED_AT, current_time( 'timestamp', true ) );
        update_post_meta( $earning_id, \Caricove_Courier_Earnings_Engine::META_HELD_BY, get_current_user_id() );

        $existing_note = trim( (string) get_post_meta( $earning_id, \Caricove_Courier_Earnings_Engine::META_HELD_NOTE, true ) );
        update_post_meta(
            $earning_id,
            \Caricove_Courier_Earnings_Engine::META_HELD_NOTE,
            $existing_note !== '' ? ( $existing_note . ' | ' . $note ) : $note
        );
    }

    private static function clone_earning_meta( int $from_id, int $to_id ): void {
        if ( $from_id <= 0 || $to_id <= 0 ) {
            return;
        }

        $all_meta = get_post_meta( $from_id );
        foreach ( (array) $all_meta as $meta_key => $values ) {
            foreach ( (array) $values as $value ) {
                add_post_meta( $to_id, $meta_key, maybe_unserialize( $value ) );
            }
        }
    }

    private static function apply_manual( string $case_id, float $amount ): bool {
        if ( $case_id === '' || $amount <= 0 ) {
            return false;
        }

        $store   = self::get_recovery_store();
        $changed = false;
        $applied = 0.0;

        foreach ( $store as &$case ) {
            if ( (string) ( $case['recovery_case_id'] ?? '' ) !== $case_id ) {
                continue;
            }

            $case      = self::hydrate_case( $case );
            $remaining = round( (float) ( $case['remaining_amount_total'] ?? 0 ), 2 );
            $take      = round( min( $amount, $remaining ), 2 );

            if ( $take <= 0 ) {
                break;
            }

            self::record_action(
                $case,
                [
                    'action_type' => 'record_manual_payment',
                    'source'      => 'manual_payment',
                    'amount'      => $take,
                    'note'        => 'Manual repayment recorded',
                ]
            );

            $case['recovered_amount_total']        = round( (float) ( $case['recovered_amount_total'] ?? 0 ) + $take, 2 );
            $case['recovered_from_manual_payment'] = round( (float) ( $case['recovered_from_manual_payment'] ?? 0 ) + $take, 2 );
            $case['remaining_amount_total']        = round( max( 0.0, $remaining - $take ), 2 );
            $case['updated_at']                    = time();
            $case['status']                        = self::status_from_totals( $case );

            self::sync_fronted_remaining( (string) ( $case['platform_fronted_case_id'] ?? '' ), (float) ( $case['remaining_amount_total'] ?? 0 ) );

            $changed = true;
            $applied = $take;
            break;
        }
        unset( $case );

        if ( $changed ) {
            update_option( self::RECOVERY_OPTION, $store, false );
        }

        return $applied > 0;
    }

    private static function waive_amount( string $case_id, float $amount ): bool {
        if ( $case_id === '' || $amount <= 0 ) {
            return false;
        }

        $store   = self::get_recovery_store();
        $changed = false;
        $waived  = 0.0;

        foreach ( $store as &$case ) {
            if ( (string) ( $case['recovery_case_id'] ?? '' ) !== $case_id ) {
                continue;
            }

            $case      = self::hydrate_case( $case );
            $remaining = round( (float) ( $case['remaining_amount_total'] ?? 0 ), 2 );
            $take      = round( min( $amount, $remaining ), 2 );

            if ( $take <= 0 ) {
                break;
            }

            self::record_action(
                $case,
                [
                    'action_type' => 'waive_amount',
                    'source'      => 'waive',
                    'amount'      => $take,
                    'note'        => 'Amount waived by admin',
                ]
            );

            $case['waived_amount_total']    = round( (float) ( $case['waived_amount_total'] ?? 0 ) + $take, 2 );
            $case['remaining_amount_total'] = round( max( 0.0, $remaining - $take ), 2 );
            $case['updated_at']             = time();
            $case['status']                 = self::status_from_totals( $case );

            self::sync_fronted_remaining( (string) ( $case['platform_fronted_case_id'] ?? '' ), (float) ( $case['remaining_amount_total'] ?? 0 ) );

            $changed = true;
            $waived  = $take;
            break;
        }
        unset( $case );

        if ( $changed ) {
            update_option( self::RECOVERY_OPTION, $store, false );
        }

        return $waived > 0;
    }

    private static function record_action( array &$case, array $action ): void {
        if ( ! isset( $case['actions'] ) || ! is_array( $case['actions'] ) ) {
            $case['actions'] = [];
        }

        $action['created_at']           = time();
        $action['created_by_admin_id']  = get_current_user_id();
        $case['actions'][] = $action;
    }

    private static function sync_fronted_remaining( string $fronted_case_id, float $remaining ): void {
        if ( $fronted_case_id === '' ) {
            return;
        }

        $store = self::get_fronted_store();

        foreach ( $store as &$row ) {
            if ( (string) ( $row['fronted_case_id'] ?? '' ) !== $fronted_case_id ) {
                continue;
            }

            $row['remaining_amount_total'] = round( $remaining, 2 );
            $row['updated_at']             = time();
            $row['status']                 = $remaining <= 0 ? 'recovered' : 'recovering';
            break;
        }
        unset( $row );

        update_option( self::FRONTED_OPTION, $store, false );
    }

    private static function status_from_totals( array $case, string $fallback = 'open' ): string {
        $recoverable = round( (float) ( $case['recoverable_amount_total'] ?? 0 ), 2 );
        $recovered   = round( (float) ( $case['recovered_amount_total'] ?? 0 ), 2 );
        $remaining   = round( (float) ( $case['remaining_amount_total'] ?? 0 ), 2 );
        $waived      = round( (float) ( $case['waived_amount_total'] ?? 0 ), 2 );

        if ( $recoverable <= 0 && $remaining <= 0 ) {
            return $fallback !== '' ? sanitize_key( $fallback ) : 'open';
        }

        if ( $remaining <= 0 ) {
            return $recovered > 0 ? 'recovered' : 'waived';
        }

        if ( $recovered > 0 || $waived > 0 ) {
            return 'recovering';
        }

        $fallback = sanitize_key( $fallback );
        if ( in_array( $fallback, [ 'open', 'recovering', 'partially_recovered', 'recovered', 'waived' ], true ) ) {
            return $fallback;
        }

        return 'open';
    }

    private static function sum_earnings_by_status( int $courier_id, string $status ): float {
        if ( $courier_id <= 0 || ! class_exists( '\\Caricove_Courier_Earnings_Engine' ) ) {
            return 0.0;
        }

        $ids = get_posts(
            [
                'post_type'      => \Caricove_Courier_Earnings_Engine::CPT_EARNING,
                'post_status'    => 'any',
                'posts_per_page' => 500,
                'fields'         => 'ids',
                'meta_query'     => [
                    [
                        'key'   => \Caricove_Courier_Earnings_Engine::META_COURIER_ID,
                        'value' => $courier_id,
                    ],
                    [
                        'key'   => \Caricove_Courier_Earnings_Engine::META_STATUS,
                        'value' => $status,
                    ],
                ],
            ]
        );

        $sum = 0.0;
        foreach ( (array) $ids as $id ) {
            $sum += (float) get_post_meta( $id, \Caricove_Courier_Earnings_Engine::META_AMOUNT_GYD, true );
        }

        return round( $sum, 2 );
    }

    private static function courier_name( int $courier_id ): string {
        if ( $courier_id <= 0 ) {
            return '—';
        }

        $user = get_user_by( 'id', $courier_id );
        return $user ? (string) $user->display_name . ' (#' . $courier_id . ')' : '#' . $courier_id;
    }

    private static function recovery_percent( float $recovered, float $recoverable ): float {
        $recovered   = max( 0.0, $recovered );
        $recoverable = max( 0.0, $recoverable );

        if ( $recoverable <= 0 ) {
            return 0.0;
        }

        return round( min( 100, ( $recovered / $recoverable ) * 100 ), 2 );
    }

    private static function battery_tone( float $percent ): string {
        if ( $percent <= 30 ) {
            return 'red';
        }

        if ( $percent <= 70 ) {
            return 'yellow';
        }

        return 'green';
    }

    private static function badge( string $status ): string {
        $status = sanitize_key( $status !== '' ? $status : 'open' );

        $map = [
            'open'                => 'Open',
            'recovering'          => 'Recovering',
            'partially_recovered' => 'Partially Recovered',
            'recovered'           => 'Recovered',
            'waived'              => 'Waived',
        ];

        $label = $map[ $status ] ?? ucwords( str_replace( '_', ' ', $status ) );

        return '<span class="ccrc-badge ccrc-' . esc_attr( $status ) . '">' . esc_html( $label ) . '</span>';
    }

    private static function money( float $amount ): string {
        return 'GYD ' . number_format( (float) $amount, 2 );
    }

    private static function date_human( int $ts ): string {
        return $ts > 0 ? gmdate( 'Y-m-d H:i', $ts ) . ' UTC' : '—';
    }

    private static function human_action( string $value ): string {
        $value = trim( $value );
        if ( $value === '' ) {
            return '—';
        }

        return ucwords( str_replace( '_', ' ', $value ) );
    }

    private static function redirect_case( string $case_id, string $flag ): void {
        wp_safe_redirect(
            add_query_arg(
                [
                    'page'    => 'caricove-bank',
                    'tab'     => 'courier_recovery',
                    'case_id' => $case_id,
                    $flag     => 1,
                ],
                admin_url( 'admin.php' )
            )
        );
        exit;
    }

    private static function render_notices(): void {
        $map = [
            'applied' => 'Recovery action applied successfully.',
            'failed'  => 'Recovery action could not be completed.',
        ];

        foreach ( $map as $key => $label ) {
            if ( ! isset( $_GET[ $key ] ) ) {
                continue;
            }

            $tone = $key === 'applied' ? 'success' : 'error';
            echo '<div class="notice notice-' . esc_attr( $tone ) . ' inline"><p>' . esc_html( $label ) . '</p></div>';
        }
    }

    private static function render_missing( string $message ): void {
        echo '<div class="notice notice-error inline"><p>' . esc_html( $message ) . '</p></div>';
    }

    private static function get_recovery_store(): array {
        $store = get_option( self::RECOVERY_OPTION, [] );
        return is_array( $store ) ? $store : [];
    }

    private static function get_fronted_store(): array {
        $store = get_option( self::FRONTED_OPTION, [] );
        return is_array( $store ) ? $store : [];
    }

private static function styles(): string {
    return '<style>
    .ccrc-wrap{margin-top:16px}
    .ccrc-shell{background:linear-gradient(180deg,#081122 0%,#06101d 42%,#050c16 100%);border:1px solid rgba(114,176,255,.18);border-radius:26px;padding:22px;box-shadow:0 18px 50px rgba(0,0,0,.35);color:#f6f9ff}
    .ccrc-head{display:flex;justify-content:space-between;align-items:flex-start;gap:18px;margin-bottom:16px}
    .ccrc-title{margin:0;font-size:24px;line-height:1.1;font-weight:900;letter-spacing:.08em;text-transform:uppercase;color:#8ed8ff}
    .ccrc-sub{margin:8px 0 0;max-width:980px;color:#c1d3ef;font-size:13px;line-height:1.6}
    .ccrc-chip{padding:10px 14px;border-radius:999px;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.12);font-weight:800;white-space:nowrap}
    .ccrc-filters{display:flex;gap:12px;flex-wrap:wrap;margin:0 0 18px}
    .ccrc-input,.ccrc-select{min-width:220px;padding:12px 14px;border-radius:14px;border:1px solid rgba(128,184,255,.25);background:#0b1629;color:#fff;box-shadow:inset 0 1px 0 rgba(255,255,255,.04)}
    .ccrc-input::placeholder{color:#93abc9}
    .ccrc-filter-btn{border-radius:14px!important;padding:0 18px!important}
    .ccrc-panel{margin-top:18px;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.09);border-radius:22px;padding:18px}
    .ccrc-panel-head,.ccrc-history-head{display:flex;justify-content:space-between;align-items:center;gap:10px;margin-bottom:12px}
    .ccrc-panel-title{font-size:14px;font-weight:900;letter-spacing:.12em;text-transform:uppercase;color:#9fdefe}
    .ccrc-panel-note{color:#9db5d4;font-size:12px}
    .ccrc-tablewrap{overflow:auto;border:1px solid rgba(255,255,255,.08);border-radius:16px;background:#081220}
    .ccrc-table{min-width:1060px}
    .ccrc-table th{background:#0d1a2c;color:#d9ebff;border-bottom:1px solid rgba(255,255,255,.08)}
    .ccrc-table td{background:transparent;color:#f4f8ff;border-bottom:1px solid rgba(255,255,255,.05)}
    .ccrc-table code{background:rgba(255,255,255,.07);padding:4px 7px;border-radius:8px;color:#fff}
    .ccrc-active-row td{background:rgba(58,142,255,.12)!important}
    .ccrc-snapshot-wrap{background:#ffffff;border-color:#d9e1ee}
    .ccrc-snapshot-table{min-width:1060px;background:#fff}
    .ccrc-snapshot-table th{background:#f6f8fc;color:#0f1726;border-bottom:1px solid #dde5f1}
    .ccrc-snapshot-table td{background:#fff;color:#111827;border-bottom:1px solid #e8edf5}
    
    
    .ccrc-history-block .ccrc-tablewrap,
.ccrc-history-block .ccrc-tablewrap table,
.ccrc-history-block .ccrc-tablewrap td,
.ccrc-history-block .ccrc-tablewrap th{
    color:#111827 !important;
}
    
    
    
    
    
    
    
    
  /* Make recovery history table WHITE */
.ccrc-history-block .ccrc-tablewrap{
    background:#ffffff !important;
    border-radius:12px;
}

/* Table base */
.ccrc-history-block .ccrc-table{
    background:#ffffff !important;
    color:#111827 !important;
}

/* Headers */
.ccrc-history-block .ccrc-table th{
    background:#f3f6fb !important;
    color:#111827 !important;
    border-bottom:1px solid #dbe3f0;
}

/* Rows */
.ccrc-history-block .ccrc-table td{
    background:#ffffff !important;
    color:#111827 !important;
    border-bottom:1px solid #eef2f7;
}

/* Zebra striping fix */
.ccrc-history-block .ccrc-table.striped tbody tr:nth-child(odd){
    background:#f9fbff !important;
}

/* Amount column */
.ccrc-history-block .ccrc-money{
    color:#111827 !important;
}

/* Remove dark inheritance completely */
.ccrc-history-block .ccrc-table *{
    color:#111827 !important;
}  
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    .ccrc-snapshot-table code{background:#eef3fb;color:#16233a}
   .ccrc-snapshot-table .button{border-color:#c9d4e6;background:#fff;color:#16233a}
.ccrc-snapshot-table .ccrc-badge.ccrc-open{background:#eef3fb;color:#314560}
.ccrc-snapshot-table .ccrc-badge.ccrc-recovering,.ccrc-snapshot-table .ccrc-badge.ccrc-partially_recovered{background:#dff1ff;color:#15507a}
.ccrc-snapshot-table .ccrc-badge.ccrc-recovered{background:#def7ea;color:#0f6a43}
.ccrc-snapshot-table .ccrc-badge.ccrc-waived{background:#fff2d8;color:#8a5b00}
.ccrc-snapshot-table .ccrc-money-strong{color:#0f1726}
.ccrc-snapshot-table .ccrc-active-row td{background:#eef5ff!important}
.ccrc-snapshot-table input,
.ccrc-snapshot-table select,
.ccrc-snapshot-table textarea{background:#fff!important;color:#111827!important;border:1px solid #cfd9e8!important;box-shadow:none!important}
.ccrc-snapshot-table input::placeholder,
.ccrc-snapshot-table textarea::placeholder{color:#6b7280!important}
    .ccrc-money{text-align:right;white-space:nowrap}
    .ccrc-money-strong{font-weight:900;color:#ffd788}
    .ccrc-badge{display:inline-flex;align-items:center;justify-content:center;padding:6px 10px;border-radius:999px;font-size:11px;font-weight:900;letter-spacing:.08em;text-transform:uppercase}
    .ccrc-open{background:rgba(255,255,255,.08);color:#d8e7fa}
    .ccrc-recovering,.ccrc-partially_recovered{background:rgba(78,171,255,.17);color:#97dbff}
    .ccrc-recovered{background:rgba(64,212,149,.17);color:#9ef2c9}
    .ccrc-waived{background:rgba(255,190,92,.17);color:#ffd58f}
    .ccrc-empty{padding:22px;border-radius:16px;border:1px dashed rgba(255,255,255,.14);background:rgba(255,255,255,.02);color:#b8cceb}
    .ccrc-empty-slim{padding:14px}
    .ccrc-detail-stage{margin-top:4px;border:1px solid rgba(255,255,255,.10);border-radius:24px;background:linear-gradient(180deg,rgba(7,15,28,.98),rgba(8,18,34,.94));padding:18px 18px 20px;box-shadow:inset 0 1px 0 rgba(255,255,255,.04)}
  .ccrc-stage-topline{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:16px;align-items:center}
.ccrc-stage-pillbox{display:inline-flex;align-items:center;gap:10px;font-size:12px;letter-spacing:.12em;text-transform:uppercase;color:#9eb4d3}
.ccrc-stage-pillbox-right{justify-self:end}
.ccrc-stage-pill{display:inline-flex;align-items:center;justify-content:center;min-width:74px;padding:7px 14px;border-radius:999px;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.16);font-weight:800;font-size:12px;letter-spacing:.12em;color:#ffffff}
.ccrc-stage-main{margin-top:16px;padding:18px 18px 14px;border-radius:20px;background:linear-gradient(180deg,rgba(255,255,255,.03),rgba(255,255,255,.015));border:1px solid rgba(255,255,255,.07)}
    .ccrc-meta-chip{min-width:150px;flex:1 1 160px;padding:10px 12px;border-radius:14px;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.08)}
    .ccrc-meta-chip span{display:block;color:#9db5d4;font-size:10px;letter-spacing:.12em;text-transform:uppercase;margin-bottom:5px}
    .ccrc-meta-chip b{display:block;color:#f6f9ff;font-size:14px;line-height:1.25;word-break:break-word}
    .ccrc-meta-chip-remaining b{color:#ffd788}
    .ccrc-pool-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px;margin-top:16px}
    .ccrc-pool-box{padding:16px 14px;border-radius:18px;background:linear-gradient(180deg,rgba(255,255,255,.06),rgba(255,255,255,.025));border:1px solid rgba(255,255,255,.10);min-height:88px;display:flex;flex-direction:column;justify-content:center;box-shadow:inset 0 1px 0 rgba(255,255,255,.03)}
    .ccrc-pool-box span{display:block;color:#b3c9e8;font-size:12px;letter-spacing:.12em;text-transform:uppercase}
    .ccrc-pool-box strong{display:block;margin-top:8px;font-size:24px;line-height:1.15;color:#ffffff}
   @media (max-width:980px){.ccrc-stage-topline{grid-template-columns:1fr}.ccrc-stage-pillbox-right{justify-content:flex-start}.ccrc-pool-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}
    @media (max-width:620px){.ccrc-head{flex-direction:column}.ccrc-pool-grid{grid-template-columns:1fr}}
    .ccrc-battery-block{margin-top:18px;padding:18px;border-radius:20px;background:linear-gradient(180deg,rgba(10,20,35,.9),rgba(7,15,28,.96));border:1px solid rgba(255,255,255,.08)}
    .ccrc-battery-top{display:flex;justify-content:space-between;gap:12px;align-items:center;margin-bottom:12px}
    .ccrc-battery-title{font-size:14px;font-weight:900;letter-spacing:.12em;text-transform:uppercase;color:#9fdefe}
    .ccrc-battery-percent{font-size:18px;font-weight:900;color:#fff}
    .ccrc-battery-wrap{display:flex;align-items:center;gap:8px}
    .ccrc-battery{position:relative;flex:1;height:46px;border-radius:14px;border:2px solid rgba(255,255,255,.16);background:#0b1220;overflow:hidden;box-shadow:inset 0 0 24px rgba(0,0,0,.45)}
    .ccrc-battery-fill{position:absolute;left:0;top:0;bottom:0;border-radius:12px;transition:width .2s ease}
    .ccrc-battery-glow{position:absolute;inset:0;background:linear-gradient(90deg,rgba(255,255,255,.06),rgba(255,255,255,0) 45%,rgba(255,255,255,.08));mix-blend-mode:screen;pointer-events:none}
    .ccrc-battery-cap{width:12px;height:22px;border-radius:0 6px 6px 0;background:rgba(255,255,255,.18);box-shadow:inset 0 0 8px rgba(255,255,255,.1)}
    .ccrc-battery-red .ccrc-battery-fill{background:linear-gradient(90deg,#7b1111,#c62828,#ef5350)}
    .ccrc-battery-yellow .ccrc-battery-fill{background:linear-gradient(90deg,#8a5b00,#d9a402,#ffd54f)}
    .ccrc-battery-green .ccrc-battery-fill{background:linear-gradient(90deg,#0f6b39,#18a05c,#49d88d)}
    .ccrc-battery-legend{display:flex;justify-content:space-between;gap:12px;margin-top:10px;color:#c6d7ee;font-size:12px}
    .ccrc-action-stack{margin-top:18px}
    .ccrc-action-primary{margin-bottom:14px}
    .ccrc-manual-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}
    @media (max-width:760px){.ccrc-manual-grid{grid-template-columns:1fr}}
    .ccrc-action-card{padding:16px;border-radius:18px;background:linear-gradient(180deg,rgba(255,255,255,.05),rgba(255,255,255,.03));border:1px solid rgba(255,255,255,.08)}
    .ccrc-action-title{font-size:14px;font-weight:900;color:#fff;letter-spacing:.08em;text-transform:uppercase}
    .ccrc-action-help{margin:8px 0 14px;color:#bcd0ed;font-size:12px;line-height:1.55}
    .ccrc-btn{width:100%;display:inline-flex!important;justify-content:center;align-items:center;border-radius:14px!important;padding:11px 16px!important;background:#0e6eff!important;border:1px solid rgba(255,255,255,.12)!important;color:#fff!important;font-weight:800!important;text-decoration:none!important}
    .ccrc-btn:hover{background:#2080ff!important}
    .ccrc-btn-begin{background:linear-gradient(90deg,#0c6dff,#1f86ff)!important;box-shadow:0 10px 24px rgba(17,102,255,.28)}
    .ccrc-btn-alt{background:#16263d!important}
    .ccrc-history-block{margin-top:18px}
    </style>';
}

}