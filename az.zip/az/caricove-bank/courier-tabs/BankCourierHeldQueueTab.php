<?php
namespace Caricove\Bank;

if ( ! defined('ABSPATH') ) { exit; }

final class BankCourierHeldQueueTab {
    public static function boot(): void {
        add_action('admin_post_cc_bank_courier_hold_release', [__CLASS__, 'post_release']);
        add_action('admin_post_cc_bank_courier_hold_forfeit', [__CLASS__, 'post_forfeit']);
    }

    public static function render(): void {
        if ( ! class_exists('\\Caricove_Courier_Earnings_Engine') ) { self::render_missing(); return; }
        $rows = self::filtered_rows('held');
        echo '<div class="cbank-card" style="margin-top:16px;border:1px solid #000;background:#fff;color:#000;">';
        echo '<div style="display:flex;justify-content:space-between;gap:16px;align-items:flex-start;margin-bottom:16px;">';
        echo '<div><h1 style="margin:0;color:#000;">Held Queue</h1><p class="description" style="margin:6px 0 0;">Release marks held earnings paid. Forfeit moves held earnings into true forfeited status.</p></div>';
        echo '<div style="background:#000;color:#fff;padding:8px 12px;border-radius:999px;font-weight:600;">' . esc_html((string) count($rows)) . ' visible</div></div>';
        self::render_filter(); self::render_notices();
        if (empty($rows)) { echo '<p style="margin:0;">No held rows.</p></div>'; return; }
        echo '<div style="overflow:auto;"><table class="widefat striped"><thead><tr><th>Earning</th><th>Shipment</th><th>Courier</th><th>Net</th><th>Reason</th><th>Note</th><th>Held At</th><th>Actions</th></tr></thead><tbody>';
        foreach ($rows as $row) {
            $r = wp_nonce_url(admin_url('admin-post.php?action=cc_bank_courier_hold_release&earning_id=' . (int)$row['earning_id']), 'cc_bank_courier_hold_admin');
            $f = wp_nonce_url(admin_url('admin-post.php?action=cc_bank_courier_hold_forfeit&earning_id=' . (int)$row['earning_id']), 'cc_bank_courier_hold_admin');
            echo '<tr><td><code>#' . esc_html((string)$row['earning_id']) . '</code></td><td><code>#' . esc_html((string)$row['shipment_id']) . '</code></td><td>' . esc_html($row['courier_name']) . '</td><td>' . esc_html('GYD ' . number_format((float)$row['amount'],2)) . '</td><td>' . esc_html($row['reason']) . '</td><td>' . esc_html($row['note']) . '</td><td>' . esc_html(self::ts((int)$row['held_at'])) . '</td><td><a class="button" style="margin:0 6px 6px 0;background:#0f7b3b;border-color:#0f7b3b;color:#fff;" href="' . esc_url($r) . '">Release</a> <a class="button" style="margin:0 6px 6px 0;background:#7a5200;border-color:#7a5200;color:#fff;" href="' . esc_url($f) . '">Forfeit</a></td></tr>';
        }
        echo '</tbody></table></div></div>';
    }

   public static function filtered_rows(string $status): array {
    $q         = sanitize_text_field((string) ($_GET['cq'] ?? ''));
    $date_from = sanitize_text_field((string) ($_GET['from'] ?? ''));
    $date_to   = sanitize_text_field((string) ($_GET['to'] ?? ''));

    $ids = get_posts(array(
        'post_type'      => \Caricove_Courier_Earnings_Engine::CPT_EARNING,
        'post_status'    => 'any',
        'posts_per_page' => 80,
        'orderby'        => 'date',
        'order'          => 'DESC',
        'fields'         => 'ids',
        'meta_query'     => array(
            array(
                'key'   => \Caricove_Courier_Earnings_Engine::META_STATUS,
                'value' => $status,
            ),
        ),
    ));

    $rows = array();

    foreach ( (array) $ids as $eid ) {
        $cid         = (int) get_post_meta($eid, \Caricove_Courier_Earnings_Engine::META_COURIER_ID, true);
        $u           = $cid ? get_user_by('id', $cid) : false;
        $courier_name= $u ? ($u->display_name . ' (#' . $cid . ')') : ('#' . $cid);
        $held_at     = (int) get_post_meta($eid, \Caricove_Courier_Earnings_Engine::META_HELD_AT_TS, true);
        $resolved_at = (int) get_post_meta($eid, \Caricove_Courier_Earnings_Engine::META_HELD_RESOLVED_AT, true);
        $shipment_id = (int) get_post_meta($eid, \Caricove_Courier_Earnings_Engine::META_SHIPMENT_ID, true);

        $ts = ($status === 'forfeited') ? $resolved_at : $held_at;

        if ( $date_from !== '' && $ts > 0 && $ts < strtotime($date_from . ' 00:00:00 UTC') ) {
            continue;
        }
        if ( $date_to !== '' && $ts > 0 && $ts > strtotime($date_to . ' 23:59:59 UTC') ) {
            continue;
        }

        $hay = strtolower(trim($courier_name . ' #' . $eid . ' #' . $shipment_id));
        if ( $q !== '' && strpos($hay, strtolower($q)) === false ) {
            continue;
        }

        $rows[] = array(
            'earning_id'   => (int) $eid,
            'shipment_id'  => $shipment_id,
            'courier_name' => $courier_name,
            'amount'       => (float) get_post_meta($eid, \Caricove_Courier_Earnings_Engine::META_AMOUNT_GYD, true),
            'reason'       => (string) get_post_meta($eid, \Caricove_Courier_Earnings_Engine::META_HELD_REASON, true),
            'note'         => (string) get_post_meta($eid, \Caricove_Courier_Earnings_Engine::META_HELD_NOTE, true),
            'held_at'      => $held_at,
            'resolved_at'  => $resolved_at,
        );
    }

    return $rows;
}

    public static function post_release(): void {
        self::guard();
        $eid = (int) ($_GET['earning_id'] ?? 0);
        $ok = \Caricove_Courier_Earnings_Engine::release_hold($eid, get_current_user_id());
        self::redirect($ok ? 'paid' : 'failed');
    }
    public static function post_forfeit(): void {
        self::guard();
        $eid = (int) ($_GET['earning_id'] ?? 0);
        $ok = \Caricove_Courier_Earnings_Engine::forfeit_hold($eid, get_current_user_id());
        self::redirect($ok ? 'forfeited' : 'failed');
    }

    private static function render_filter(): void {
        echo '<form method="get" style="display:flex;flex-wrap:wrap;gap:10px;margin:0 0 16px;">';
      echo '<input type="hidden" name="page" value="caricove-bank"><input type="hidden" name="tab" value="hold">';
        echo '<input type="text" name="cq" value="' . esc_attr((string) ($_GET['cq'] ?? '')) . '" placeholder="Courier / earning / shipment" style="padding:8px 10px;min-width:220px;">';
        echo '<input type="date" name="from" value="' . esc_attr((string) ($_GET['from'] ?? '')) . '" style="padding:8px 10px;">';
        echo '<input type="date" name="to" value="' . esc_attr((string) ($_GET['to'] ?? '')) . '" style="padding:8px 10px;">';
        echo '<button type="submit" class="button button-primary">Filter</button></form>';
    }
    private static function render_notices(): void {
        $map = ['paid'=>'Held ledger released and marked paid.','forfeited'=>'Held ledger moved to true forfeited status.','failed'=>'That action could not be completed.'];
        foreach ($map as $key=>$label) { if (!isset($_GET[$key])) continue; $tone = ($key === 'failed') ? 'error' : 'success'; echo '<div class="notice notice-' . esc_attr($tone) . ' inline"><p>' . esc_html($label) . '</p></div>'; }
    }
    private static function guard(): void { if (! current_user_can('manage_options')) wp_die('Unauthorized'); check_admin_referer('cc_bank_courier_hold_admin'); if (! class_exists('\\Caricove_Courier_Earnings_Engine')) wp_die('Courier earnings dependency missing.'); }
   private static function redirect(string $flag): void {
    wp_safe_redirect(add_query_arg(['page' => 'caricove-bank', 'tab' => 'hold', $flag => 1], admin_url('admin.php')));
    exit;
}
    private static function render_missing(): void { echo '<div class="cbank-card" style="margin-top:16px;border:1px solid #000;background:#fff;color:#000;"><p style="margin:0;">Courier earnings engine is not loaded.</p></div>'; }
    private static function ts(int $ts): string { return $ts > 0 ? gmdate('Y-m-d H:i', $ts) . ' UTC' : '—'; }
}
