<?php
/**
 * Plugin Name: Caricove Ledger Inspector Auditor
 * Description: Read-only forensic auditor for seller ledger rows and bank events with enterprise rule checks.
 */

if (!defined('ABSPATH')) exit;

final class Caricove_Ledger_Inspector_Auditor {
    private static array $request = [];

    public static function boot(): void {
        add_action('admin_menu', [__CLASS__, 'menu']);
        add_action('admin_init', [__CLASS__, 'maybe_force_promote'], 0);
        add_action('admin_init', [__CLASS__, 'maybe_export_json'], 1);
    }

    public static function menu(): void {
        add_menu_page(
            'Ledger Inspector',
            'Ledger Inspector',
            'manage_options',
            'caricove-ledger-inspector',
            [__CLASS__, 'render'],
            'dashicons-table-col-after',
            58
        );
    }

    private static function req(): array {
        if (self::$request) return self::$request;
        self::$request = [
            'tab'            => sanitize_text_field((string) ($_GET['tab'] ?? 'ledger')),
            'vendor_id'      => absint($_GET['vendor_id'] ?? 0),
            'order_id'       => absint($_GET['order_id'] ?? 0),
            'shipment_id'    => absint($_GET['shipment_id'] ?? 0),
            'state'          => sanitize_text_field((string) ($_GET['state'] ?? '')),
            'event_type'     => sanitize_text_field((string) ($_GET['event_type'] ?? '')),
            'search'         => sanitize_text_field((string) ($_GET['search'] ?? '')),
            'limit'          => max(1, min(1500, absint($_GET['limit'] ?? 100))),
            'issues_only'    => !empty($_GET['issues_only']) ? 1 : 0,
            'print_mode'     => !empty($_GET['print_mode']) ? 1 : 0,
            'show_full_json' => !empty($_GET['show_full_json']) ? 1 : 0,
            'export_json'    => !empty($_GET['export_json']) ? 1 : 0,
        ];
        return self::$request;
    }

    private static function decode_json($value): array {
        if (!is_string($value) || $value === '') return [];
        $decoded = json_decode($value, true);
        return is_array($decoded) ? $decoded : [];
    }

    private static function encode_json($value): string {
        return wp_json_encode($value, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    }

    private static function ensure_doctrine_loaded(): bool {
        if (class_exists('\\Caricove\\Bank\\LedgerDoctrine')) {
            return true;
        }

        $paths = [
            WP_CONTENT_DIR . '/mu-plugins/caricove-bank/LedgerDoctrine.php',
            __DIR__ . '/caricove-bank/LedgerDoctrine.php',
            dirname(__DIR__) . '/caricove-bank/LedgerDoctrine.php',
        ];

        foreach ($paths as $path) {
            if (is_string($path) && $path !== '' && file_exists($path)) {
                require_once $path;
                if (class_exists('\\Caricove\\Bank\\LedgerDoctrine')) {
                    return true;
                }
            }
        }

        return false;
    }

    private static function doctrine_report(array $row): array {
        if (!self::ensure_doctrine_loaded()) {
            return [
                'doctrine_version' => 'missing',
                'status' => 'FAIL',
                'role' => 'UNKNOWN',
                'violations' => [[
                    'severity' => 'critical',
                    'code' => 'D000_DOCTRINE_NOT_LOADED',
                    'message' => 'LedgerDoctrine.php could not be loaded.',
                    'context' => [],
                ]],
            ];
        }

        return \Caricove\Bank\LedgerDoctrine::validate_row($row);
    }

    private static function path($array, string $path, $default = '') {
        if (!is_array($array)) return $default;
        $cur = $array;
        foreach (explode('.', $path) as $segment) {
            if (!is_array($cur) || !array_key_exists($segment, $cur)) return $default;
            $cur = $cur[$segment];
        }
        return $cur;
    }

    private static function first_non_empty(...$values) {
        foreach ($values as $v) {
            if (is_array($v)) {
                if (!empty($v)) return $v;
                continue;
            }
            if ($v !== null && $v !== '') return $v;
        }
        return '';
    }

    private static function tables(): array {
        global $wpdb;
        $prefix = $wpdb->prefix;
        $candidates = [
            'ledger' => [$prefix . 'cc_sp_ledger'],
            'bank_events' => [$prefix . 'caricove_bank_events', $prefix . 'bank_events'],
        ];
        $out = ['ledger' => '', 'bank_events' => ''];
        foreach ($candidates as $key => $tables) {
            foreach ($tables as $table) {
                $found = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table));
                if ($found === $table) { $out[$key] = $table; break; }
            }
        }
        return $out;
    }

    private static function extract_ledger_trace(array $row): array {
        $meta = self::decode_json((string) ($row['meta'] ?? ''));
        $trace_context = self::first_non_empty(
            self::path($meta, 'trace_context', []),
            self::path($meta, 'return_bridge.trace_context', [])
        );
        if (!is_array($trace_context)) $trace_context = [];
        return [
            'meta'            => $meta,
            'trace_context'   => $trace_context,
            'correlation_id'  => (string) self::first_non_empty(self::path($meta, 'correlation_id', ''), self::path($trace_context, 'correlation_id', ''), self::path($meta, 'return_bridge.correlation_id', ''), self::path($meta, 'return_bridge.trace_context.correlation_id', '')),
            'trace_operation' => (string) self::first_non_empty(self::path($meta, 'trace_operation', ''), self::path($meta, 'return_bridge.trace_operation', '')),
            'refund_case_id'  => (string) self::first_non_empty(self::path($meta, 'refund_case_id', ''), self::path($meta, 'case_id', ''), self::path($meta, 'return_bridge.case_id', ''), self::path($trace_context, 'refund_case_id', ''), self::path($trace_context, 'case_id', '')),
        ];
    }

    private static function extract_bank_trace(array $row): array {
        $meta = self::decode_json((string) ($row['meta_json'] ?? ''));
        $trace_context = self::first_non_empty(self::path($meta, 'trace_context', []), self::path($meta, 'return_bridge.trace_context', []));
        if (!is_array($trace_context)) $trace_context = [];
        return [
            'meta'            => $meta,
            'trace_context'   => $trace_context,
            'correlation_id'  => (string) self::first_non_empty(self::path($meta, 'correlation_id', ''), self::path($trace_context, 'correlation_id', ''), self::path($meta, 'return_bridge.correlation_id', ''), self::path($meta, 'return_bridge.trace_context.correlation_id', '')),
            'trace_operation' => (string) self::first_non_empty(self::path($meta, 'trace_operation', ''), self::path($meta, 'return_bridge.trace_operation', '')),
            'refund_case_id'  => (string) self::first_non_empty((string) ($row['return_case_id'] ?? ''), self::path($meta, 'refund_case_id', ''), self::path($meta, 'case_id', ''), self::path($meta, 'return_bridge.case_id', ''), self::path($trace_context, 'refund_case_id', ''), self::path($trace_context, 'case_id', '')),
        ];
    }

    private static function audit_ledger_row(array $row): array {
        $t = self::extract_ledger_trace($row);
        $meta = $t['meta'];
        $issues = [];

        $state = (string) ($row['state'] ?? '');
        $event = (string) ($row['event_type'] ?? '');
        $pending_until = (string) ($row['pending_until'] ?? '');
        $row_net = (float) ($row['net'] ?? 0);
        $meta_state = (string) self::path($meta, 'settlement_state', '');
        $meta_stage = (string) self::path($meta, 'settlement_stage', '');
        $meta_pending_until = (string) self::path($meta, 'pending_until', '');
        $slices = self::path($meta, 'financial_slices', []);
        $slice_total = 0.0;
        if (is_array($slices)) {
            foreach ($slices as $slice) {
                if (is_array($slice)) $slice_total += (float) ($slice['amount'] ?? 0);
            }
        }
        $slice_total = round($slice_total, 2);
        $net_round = round($row_net, 2);

        $is_refund_debit = strpos((string) ($row['unique_key'] ?? ''), 'refund-debit:') === 0 || !empty(self::path($meta, 'seller_debit_exposure', 0));
        $is_shipping = strpos((string) ($row['unique_key'] ?? ''), 'shipping:') === 0 || !empty(self::path($meta, 'shipping_liability', 0)) || in_array((string) self::path($meta, 'debit_component', ''), ['shipping_liability', 'shipping'], true);

        $expected_event_by_state = [
            'pending'   => ['shipment_earnings_created', 'seller_hold_released_pending'],
            'hold'      => ['shipment_earnings_created', 'seller_earnings_held'],
            'available' => ['funds_became_available', 'funds_force_cleared_available', 'seller_hold_released_available', 'shipment_earnings_created'],
            'paid'      => ['vendor_withdrawal_paid', 'seller_offset_consumed'],
            'debit'     => ['seller_deduction_created', 'seller_deduction_reopened_by_refund', 'seller_deduction_partially_reopened', 'seller_offset_reopened_by_refund'],
            'reversed'  => ['seller_earnings_reversed_unpaid', 'available_row_fully_consumed', 'seller_offset_reversed_by_refund', 'seller_deduction_fully_offset'],
        ];

        if ($meta_state !== '' && $state !== '' && $meta_state !== $state) {
            $issues[] = ['severity' => 'critical', 'code' => 'STATE_META_MISMATCH', 'message' => 'Row state does not match meta settlement_state.'];
        }
        if ($pending_until !== '' && $meta_pending_until !== '' && $pending_until !== $meta_pending_until) {
            $issues[] = ['severity' => 'critical', 'code' => 'PENDING_UNTIL_MISMATCH', 'message' => 'Row pending_until does not match meta pending_until.'];
        }
        if ($state === 'available' && $meta_stage === 'clearing') {
            $issues[] = ['severity' => 'critical', 'code' => 'AVAILABLE_STILL_CLEARING', 'message' => 'Available row still marked as clearing in meta.'];
        }
        if ($state === 'available' && $meta_state === 'pending') {
            $issues[] = ['severity' => 'critical', 'code' => 'AVAILABLE_STILL_PENDING', 'message' => 'Available row still marked as pending in meta.'];
        }
        if (isset($expected_event_by_state[$state]) && !in_array($event, $expected_event_by_state[$state], true)) {
            $issues[] = ['severity' => 'warning', 'code' => 'EVENT_STATE_ODD', 'message' => 'Event type is unusual for the current row state.'];
        }
        if ($state === 'available' && $event === 'shipment_earnings_created') {
            $issues[] = ['severity' => 'critical', 'code' => 'AVAILABLE_WITH_CREATION_EVENT', 'message' => 'Available row still carries shipment_earnings_created.'];
        }
        if ($state === 'pending' && $row_net > 0 && is_array($slices) && $slice_total > 0 && abs($slice_total - $net_round) > 0.02) {
            $issues[] = ['severity' => 'warning', 'code' => 'SLICE_NET_MISMATCH', 'message' => 'Financial slice total does not match row net.'];
        }
        if (($state === 'available' || $state === 'paid') && is_array($slices) && $slice_total > 0 && abs($slice_total - $net_round) > 0.02 && !$is_refund_debit && !$is_shipping) {
            $issues[] = ['severity' => 'warning', 'code' => 'SLICE_NET_MISMATCH', 'message' => 'Financial slice total does not match row net.'];
        }
        if (($is_refund_debit || $is_shipping || $state === 'paid' || $state === 'debit') && $t['correlation_id'] === '') {
            $issues[] = ['severity' => 'warning', 'code' => 'TRACE_CORRELATION_MISSING', 'message' => 'Missing normalized correlation_id.'];
        }
        if (($is_refund_debit || $is_shipping || $state === 'paid' || $state === 'debit') && $t['trace_operation'] === '') {
            $issues[] = ['severity' => 'warning', 'code' => 'TRACE_OPERATION_MISSING', 'message' => 'Missing normalized trace_operation.'];
        }
        if (($is_refund_debit || $is_shipping) && $t['refund_case_id'] === '') {
            $issues[] = ['severity' => 'critical', 'code' => 'CASE_LINK_MISSING', 'message' => 'Refund-related row is missing normalized refund case linkage.'];
        }
        if ($is_shipping) {
            $party = (string) self::first_non_empty(self::path($meta, 'shipping_liability_party', ''), self::path($meta, 'return_bridge.shipping_liability_party', ''));
            if ($party === '') {
                $issues[] = ['severity' => 'warning', 'code' => 'SHIPPING_PARTY_MISSING', 'message' => 'Shipping liability row is missing shipping_liability_party.'];
            }
        }
        if ($state === 'paid') {
            $mode = (string) self::path($meta, 'payout_mode', '');
            if ($mode === 'offset' && $event !== 'seller_offset_consumed') {
                $issues[] = ['severity' => 'warning', 'code' => 'PAID_OFFSET_EVENT_MISMATCH', 'message' => 'Paid offset row should usually be seller_offset_consumed.'];
            }
            if ($mode === 'cash' && $event !== 'vendor_withdrawal_paid') {
                $issues[] = ['severity' => 'warning', 'code' => 'PAID_CASH_EVENT_MISMATCH', 'message' => 'Paid cash row should usually be vendor_withdrawal_paid.'];
            }
        }
        if ($state === 'debit') {
            $amount = abs((float) ($row['net'] ?? 0));
            if ($amount <= 0.0) {
                $issues[] = ['severity' => 'warning', 'code' => 'DEBIT_ZERO_NET', 'message' => 'Debit row has zero net.'];
            }
        }
        $offset_sources = self::path($meta, 'offset_sources', []);
        $offset_targets = self::path($meta, 'offset_targets', []);
        if (!is_array($offset_sources)) $offset_sources = [];
        if (!is_array($offset_targets)) $offset_targets = [];
        $role_state = (string) self::path($meta, 'chain_role_state', '');
        if ($state === 'paid' && (string) self::path($meta, 'payout_mode', '') === 'offset' && empty($offset_sources)) {
            $issues[] = ['severity' => 'warning', 'code' => 'OFFSET_ROW_NO_SOURCES', 'message' => 'Offset-paid row has no offset_sources trace.'];
        }
        if ($state === 'debit' && $role_state === 'TARGET' && empty($offset_targets)) {
            $issues[] = ['severity' => 'warning', 'code' => 'TARGET_NO_OFFSET_TARGETS', 'message' => 'Target-like debit row has no offset_targets trace.'];
        }
        if ($state === 'debit' && $role_state === 'SOURCE' && empty($offset_sources) && !$is_refund_debit && !$is_shipping) {
            $issues[] = ['severity' => 'warning', 'code' => 'SOURCE_NO_OFFSET_SOURCES', 'message' => 'Source-like debit row has no offset_sources trace.'];
        }

        $doctrine = self::doctrine_report($row);
        $doctrine_issues = [];
        foreach ((array)($doctrine['violations'] ?? []) as $violation) {
            if (!is_array($violation)) {
                continue;
            }
            $doctrine_issues[] = [
                'severity' => (string)($violation['severity'] ?? 'critical'),
                'code' => (string)($violation['code'] ?? 'DOCTRINE_VIOLATION'),
                'message' => (string)($violation['message'] ?? 'Ledger doctrine violation.'),
                'context' => (array)($violation['context'] ?? []),
            ];
        }

        $issues = $doctrine_issues;

        return [
            'issues' => $issues,
            'severity_score' => self::severity_score($issues),
            'trace' => $t,
            'doctrine' => $doctrine,
            'is_shipping' => $is_shipping,
            'is_refund_debit' => $is_refund_debit,
            'slice_total' => $slice_total,
        ];
    }

    private static function audit_bank_event(array $row, array $all_bank_events = []): array {
        $t = self::extract_bank_trace($row);
        $issues = [];
        if (((string) ($row['event_type'] ?? '')) !== '' || ((string) ($row['return_case_id'] ?? '')) !== '') {
            if ($t['correlation_id'] === '') $issues[] = ['severity' => 'warning', 'code' => 'TRACE_CORRELATION_MISSING', 'message' => 'Missing normalized correlation_id.'];
            if ($t['trace_operation'] === '') $issues[] = ['severity' => 'warning', 'code' => 'TRACE_OPERATION_MISSING', 'message' => 'Missing normalized trace_operation.'];
        }
        if ((string) ($row['return_case_id'] ?? '') === '' && in_array((string) ($row['event_type'] ?? ''), ['customer_refund_issued', 'return_shipping_charge', 'seller_deduction_created', 'seller_offset_reopened_by_refund', 'refund_financial_rollback'], true)) {
            $issues[] = ['severity' => 'warning', 'code' => 'RETURN_CASE_MISSING', 'message' => 'Refund-related bank event missing return_case_id.'];
        }
        // duplicate payout noise detection
        if ((string) ($row['event_type'] ?? '') === 'seller_payout_completed' && !empty($all_bank_events)) {
            $same = array_filter($all_bank_events, function($r) use ($row) {
                return (string) ($r['event_type'] ?? '') === 'seller_payout_completed'
                    && (int) ($r['shipment_id'] ?? 0) === (int) ($row['shipment_id'] ?? 0)
                    && (int) ($r['vendor_id'] ?? 0) === (int) ($row['vendor_id'] ?? 0);
            });
            if (count($same) > 1) {
                $zero_and_nonzero = false;
                $has_zero = false; $has_nonzero = false;
                foreach ($same as $r) { if ((float)($r['amount']??0) == 0.0) $has_zero=true; else $has_nonzero=true; }
                $zero_and_nonzero = $has_zero && $has_nonzero;
                if ($zero_and_nonzero) $issues[] = ['severity' => 'warning', 'code' => 'PAYOUT_EVENT_DUPLICATION', 'message' => 'Shipment has both zero and non-zero seller_payout_completed events.'];
            }
        }
        return [
            'issues' => $issues,
            'severity_score' => self::severity_score($issues),
            'trace' => $t,
        ];
    }

    private static function severity_score(array $issues): int {
        $score = 0;
        foreach ($issues as $issue) {
            $score += ($issue['severity'] ?? '') === 'critical' ? 3 : 1;
        }
        return $score;
    }

    private static function ledger_rows(array $filters): array {
        global $wpdb;
        $table = self::tables()['ledger'];
        if (!$table) return [];
        $where = ['1=1']; $params = [];
        foreach (['vendor_id','order_id','shipment_id'] as $f) {
            if (!empty($filters[$f])) { $where[] = "$f=%d"; $params[] = (int) $filters[$f]; }
        }
        if (!empty($filters['state'])) { $where[] = 'state=%s'; $params[] = $filters['state']; }
        if (!empty($filters['event_type'])) { $where[] = 'event_type=%s'; $params[] = $filters['event_type']; }
        if (!empty($filters['search'])) {
            $like = '%' . $wpdb->esc_like($filters['search']) . '%';
            $where[] = '(unique_key LIKE %s OR note LIKE %s OR meta LIKE %s OR event_type LIKE %s)';
            array_push($params, $like, $like, $like, $like);
        }
        $sql = "SELECT id,unique_key,shipment_id,order_id,vendor_id,currency,state,created_at,updated_at,delivered_at,pending_until,gross,commission,courier_fees,reserve,net,meta,event_type,note,hold_reason,hold_set_at FROM {$table} WHERE " . implode(' AND ', $where) . " ORDER BY id DESC LIMIT %d";
        $params[] = (int)$filters['limit'];
        $rows = $wpdb->get_results($wpdb->prepare($sql, ...$params), ARRAY_A);
        foreach ($rows as &$row) {
            $row['_audit'] = self::audit_ledger_row($row);
        }
        unset($row);
        if (!empty($filters['issues_only'])) {
            $rows = array_values(array_filter($rows, fn($r) => !empty($r['_audit']['issues'])));
        }
        return $rows;
    }

    private static function bank_events(array $filters): array {
        global $wpdb;
        $table = self::tables()['bank_events'];
        if (!$table) return [];
        $where = ['1=1']; $params = [];
        foreach (['vendor_id','order_id','shipment_id'] as $f) {
            if (!empty($filters[$f])) { $where[] = "$f=%d"; $params[] = (int) $filters[$f]; }
        }
        if (!empty($filters['state'])) { $where[] = 'event_status=%s'; $params[] = $filters['state']; }
        if (!empty($filters['event_type'])) { $where[] = 'event_type=%s'; $params[] = $filters['event_type']; }
        if (!empty($filters['search'])) {
            $like = '%' . $wpdb->esc_like($filters['search']) . '%';
            $where[] = '(event_uuid LIKE %s OR event_type LIKE %s OR meta_json LIKE %s OR notes LIKE %s OR return_case_id LIKE %s OR source_ref LIKE %s)';
            array_push($params, $like, $like, $like, $like, $like, $like);
        }
        $sql = "SELECT id,event_uuid,event_type,event_status,order_id,shipment_id,return_case_id,vendor_id,courier_id,customer_id,woo_refund_id,currency,amount,direction,payer_type,payer_id,payee_type,payee_id,reason_code,reason_label,source_system,source_ref,notes,meta_json,created_at,effective_at,created_by FROM {$table} WHERE " . implode(' AND ', $where) . " ORDER BY id DESC LIMIT %d";
        $params[] = (int)$filters['limit'];
        $rows = $wpdb->get_results($wpdb->prepare($sql, ...$params), ARRAY_A);
        foreach ($rows as &$row) {
            $row['_audit'] = self::audit_bank_event($row, $rows);
        }
        unset($row);
        if (!empty($filters['issues_only'])) {
            $rows = array_values(array_filter($rows, fn($r) => !empty($r['_audit']['issues'])));
        }
        return $rows;
    }

    private static function group_key_from_ledger(array $row): string {
        $t = $row['_audit']['trace'] ?? self::extract_ledger_trace($row);
        if (!empty($t['refund_case_id'])) return 'refund_case:' . $t['refund_case_id'];
        if (!empty($t['correlation_id'])) return 'correlation:' . $t['correlation_id'];
        if (!empty($row['shipment_id'])) return 'shipment:' . (int)$row['shipment_id'];
        if (!empty($row['order_id'])) return 'order:' . (int)$row['order_id'];
        return 'ledger:' . (int)$row['id'];
    }
    private static function group_key_from_bank(array $row): string {
        $t = $row['_audit']['trace'] ?? self::extract_bank_trace($row);
        if (!empty($t['refund_case_id'])) return 'refund_case:' . $t['refund_case_id'];
        if (!empty($t['correlation_id'])) return 'correlation:' . $t['correlation_id'];
        if (!empty($row['shipment_id'])) return 'shipment:' . (int)$row['shipment_id'];
        if (!empty($row['order_id'])) return 'order:' . (int)$row['order_id'];
        return 'bank:' . (int)$row['id'];
    }

    private static function linked(array $ledger_rows, array $bank_events): array {
        $groups=[];
        foreach ($ledger_rows as $r) { $k=self::group_key_from_ledger($r); $groups[$k]['group_key']=$k; $groups[$k]['ledger_rows'][]=$r; $groups[$k]['bank_events']=$groups[$k]['bank_events']??[]; }
        foreach ($bank_events as $r) { $k=self::group_key_from_bank($r); $groups[$k]['group_key']=$k; $groups[$k]['bank_events'][]=$r; $groups[$k]['ledger_rows']=$groups[$k]['ledger_rows']??[]; }
        foreach ($groups as &$g) {
            $g['severity_score']=0; $g['issue_count']=0;
            foreach (($g['ledger_rows']??[]) as $r) { $g['severity_score'] += (int) ($r['_audit']['severity_score'] ?? 0); $g['issue_count'] += count($r['_audit']['issues'] ?? []); }
            foreach (($g['bank_events']??[]) as $r) { $g['severity_score'] += (int) ($r['_audit']['severity_score'] ?? 0); $g['issue_count'] += count($r['_audit']['issues'] ?? []); }
        }
        unset($g);
        uasort($groups, fn($a,$b) => [$b['severity_score'],$b['issue_count'],$a['group_key']] <=> [$a['severity_score'],$a['issue_count'],$b['group_key']]);
        return $groups;
    }


    /**
     * Best-effort loader for the canonical bank ledger engine.
     * The Inspector must not implement allocation itself; it only loads and calls
     * \Caricove\Bank\Ledger::inspector_allocate_available_row() after safe promotion.
     */
    private static function ensure_bank_ledger_loaded(): bool {
        if (class_exists('\\Caricove\\Bank\\Ledger')) {
            return true;
        }

        $candidates = [];

        if (defined('WPMU_PLUGIN_DIR')) {
            $candidates[] = trailingslashit(WPMU_PLUGIN_DIR) . 'caricove-bank/BankSellerLedger.php';
            $candidates[] = trailingslashit(WPMU_PLUGIN_DIR) . 'BankSellerLedger.php';
        }
        if (defined('WP_PLUGIN_DIR')) {
            $candidates[] = trailingslashit(WP_PLUGIN_DIR) . 'caricove-bank/BankSellerLedger.php';
            $candidates[] = trailingslashit(WP_PLUGIN_DIR) . 'BankSellerLedger.php';
        }

        $here = __DIR__;
        $candidates[] = $here . '/BankSellerLedger.php';
        $candidates[] = $here . '/caricove-bank/BankSellerLedger.php';
        $candidates[] = dirname($here) . '/caricove-bank/BankSellerLedger.php';
        $candidates[] = dirname($here) . '/BankSellerLedger.php';

        foreach (array_unique(array_filter($candidates)) as $file) {
            if (is_string($file) && $file !== '' && file_exists($file) && is_readable($file)) {
                require_once $file;
                if (class_exists('\\Caricove\\Bank\\Ledger')) {
                    return true;
                }
            }
        }

        return class_exists('\\Caricove\\Bank\\Ledger');
    }

    private static function mark_promote_allocator_status(int $row_id, string $status, array $details = []): void {
        // Doctrine mode: Force Promote remains available for deliberate testing,
        // but the Inspector must not write allocator-status scars into ledger meta.
        return;
    }


    public static function maybe_force_promote(): void {
        if (!is_admin() || !current_user_can('manage_options')) return;
        if (($_POST['page'] ?? '') !== 'caricove-ledger-inspector') return;
        if (empty($_POST['ccv_safe_force_promote'])) return;
        check_admin_referer('ccv_safe_force_promote');

        global $wpdb;
        $tables = self::tables();
        $table = $tables['ledger'] ?? '';
        $row_id = absint($_POST['row_id'] ?? 0);
        $shipment_id = absint($_POST['promote_shipment_id'] ?? ($_POST['return_shipment_id'] ?? 0));
        $redirect_args = [
            'page' => 'caricove-ledger-inspector',
            'tab' => sanitize_text_field((string)($_POST['return_tab'] ?? 'ledger')),
            'shipment_id' => $shipment_id,
            'show_full_json' => 1,
        ];

        if (!$table) {
            wp_safe_redirect(add_query_arg($redirect_args + ['ccv_promote_error' => 'missing_ledger_table'], admin_url('admin.php')));
            exit;
        }

        if ($row_id > 0) {
            $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $row_id), ARRAY_A);
        } elseif ($shipment_id > 0) {
            $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE shipment_id = %d AND unique_key LIKE %s ORDER BY id DESC LIMIT 1", $shipment_id, 'ship:%'), ARRAY_A);
        } else {
            $row = null;
        }

        if (!$row) {
            wp_safe_redirect(add_query_arg($redirect_args + ['ccv_promote_error' => 'row_not_found'], admin_url('admin.php')));
            exit;
        }

        $row_id = (int)($row['id'] ?? 0);
        $shipment_id = (int)($row['shipment_id'] ?? $shipment_id);
        $state = (string)($row['state'] ?? '');
        $event_type = (string)($row['event_type'] ?? '');
        $meta = self::decode_json((string)($row['meta'] ?? ''));
        $meta_state = (string)($meta['settlement_state'] ?? '');
        $meta_stage = (string)($meta['settlement_stage'] ?? '');

        $is_pending = ($state === 'pending');
        $is_malformed_available = ($state === 'available' && ($event_type === 'shipment_earnings_created' || $meta_state === 'pending' || $meta_stage === 'clearing'));

        if (!$is_pending && !$is_malformed_available) {
            wp_safe_redirect(add_query_arg($redirect_args + ['ccv_promote_error' => 'row_is_not_pending_or_malformed_available'], admin_url('admin.php')));
            exit;
        }

        // Clean legacy pending-reserve scars before the inspector changes state.
        // Force Promote must never preserve UI/old-engine reservations as real allocation truth.
        $legacy_pending_edges = [];
        $meta_offset_sources = isset($meta['offset_sources']) && is_array($meta['offset_sources']) ? $meta['offset_sources'] : [];
        $had_legacy_pending_reservation = false;
        foreach ($meta_offset_sources as $edge) {
            if (!is_array($edge)) continue;
            $status = (string)($edge['allocation_status'] ?? '');
            $ref = (string)($edge['reference'] ?? '');
            $target_slice = (string)($edge['target_slice_id'] ?? '');
            if ($status === 'reserved_pending' || strpos($ref, 'pending-auto-allocation:') === 0 || strpos($target_slice, 'pending-target-') === 0) {
                $legacy_pending_edges[] = $edge;
                $had_legacy_pending_reservation = true;
            }
        }
        if ((string)($meta['target_assignment_status'] ?? '') === 'reserved_pending' || isset($meta['pending_offset_reserved_total'])) {
            $had_legacy_pending_reservation = true;
        }

        if ($had_legacy_pending_reservation) {
            foreach ($legacy_pending_edges as $edge) {
                $source_row_id = absint($edge['debit_row_id'] ?? 0);
                if ($source_row_id <= 0) continue;

                $source_row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $source_row_id), ARRAY_A);
                if (!$source_row) continue;

                $source_meta = self::decode_json((string)($source_row['meta'] ?? ''));
                $source_targets = isset($source_meta['offset_targets']) && is_array($source_meta['offset_targets']) ? $source_meta['offset_targets'] : [];
                $clean_targets = [];
                foreach ($source_targets as $target_edge) {
                    if (!is_array($target_edge)) continue;
                    $status = (string)($target_edge['allocation_status'] ?? '');
                    $ref = (string)($target_edge['reference'] ?? '');
                    $target_slice = (string)($target_edge['target_slice_id'] ?? '');
                    $target_row_id = absint($target_edge['target_row_id'] ?? 0);
                    $is_pending_edge = ($status === 'reserved_pending' || strpos($ref, 'pending-auto-allocation:') === 0 || strpos($target_slice, 'pending-target-') === 0);
                    if ($is_pending_edge && ($target_row_id === $row_id || $target_row_id <= 0)) {
                        continue;
                    }
                    $clean_targets[] = $target_edge;
                }

                $source_meta['offset_targets'] = array_values($clean_targets);
                unset($source_meta['pending_debit_reserved_total'], $source_meta['pending_debit_reserved_at']);
                if ((string)($source_meta['trace_operation'] ?? '') === 'reserve_open_debits_to_pending_source') {
                    unset($source_meta['trace_operation'], $source_meta['correlation_id'], $source_meta['trace_context']);
                }

                if ((string)($source_row['state'] ?? '') === 'debit') {
                    $source_abs = abs((float)($source_row['net'] ?? 0));
                    $source_meta['settlement_stage'] = 'recovery';
                    $source_meta['settlement_state'] = 'debit';
                    $source_meta['settlement_reason'] = 'Seller payout recovered due to refund or adjustment';
                    $source_meta['chain_role_state'] = 'SOURCE';
                    $source_meta['chain_source_slice'] = round($source_abs, 2);
                    $source_meta['chain_source_remaining'] = round($source_abs, 2);
                    $source_meta['chain_target_allocated_slice'] = 0;
                }

                $wpdb->update(
                    $table,
                    ['meta' => wp_json_encode($source_meta), 'updated_at' => current_time('mysql')],
                    ['id' => $source_row_id],
                    ['%s','%s'],
                    ['%d']
                );
            }

            unset(
                $meta['pending_offset_reserved_total'],
                $meta['pending_offset_reserved_at'],
                $meta['reserved_offset_sources']
            );
            $meta['offset_sources'] = [];
            $meta['offset_targets'] = isset($meta['offset_targets']) && is_array($meta['offset_targets']) ? array_values($meta['offset_targets']) : [];
            $meta['auto_target_candidate'] = true;
            $meta['target_assignment_status'] = 'available_for_recovery';
            $meta['target_assignment_reason'] = 'Legacy pending reservation cleared by Ledger Inspector safe promotion';
            $meta['chain_target_allocated_slice'] = 0;
            $meta['chain_target_capacity_original'] = round((float)($meta['chain_target_capacity_original'] ?? $row['net'] ?? 0), 2);
            $meta['chain_target_capacity'] = $meta['chain_target_capacity_original'];
            $meta['chain_target_remaining_capacity'] = $meta['chain_target_capacity_original'];
            $meta['inspector_cleared_legacy_pending_reservation'] = 1;
        }

        $now = current_time('mysql');
        $trace_id = 'inspector-force-promote-' . $row_id . '-' . wp_generate_password(8, false, false);

        $meta['settlement_state']  = 'available';
        $meta['settlement_stage']  = 'payout_ready';
        $meta['settlement_reason'] = $is_malformed_available ? 'Malformed available row repaired by Ledger Inspector safe promotion tool' : 'Force cleared by Ledger Inspector safe promotion test';
        $meta['state_timestamp']   = $now;
        $meta['pending_until']     = $now;
        $meta['force_promoted_by'] = get_current_user_id();
        $meta['force_promoted_at'] = $now;
        $meta['trace_operation']   = $is_malformed_available ? 'inspector_repair_malformed_available' : 'inspector_force_promote';
        $meta['correlation_id']    = $trace_id;
        $meta['trace_context']     = [
            'correlation_id' => $trace_id,
            'command_source' => 'ledger_inspector_auditor',
            'trace_operation' => $meta['trace_operation'],
            'ledger_row_id' => $row_id,
            'shipment_id' => $shipment_id,
            'order_id' => (int)($row['order_id'] ?? 0),
            'vendor_id' => (int)($row['vendor_id'] ?? 0),
            'actor_user_id' => get_current_user_id(),
            'captured_at' => $now,
            'previous_state' => $state,
            'previous_event_type' => $event_type,
            'previous_meta_state' => $meta_state,
            'previous_meta_stage' => $meta_stage,
        ];

        $updated = $wpdb->update(
            $table,
            [
                'state' => 'available',
                'event_type' => 'funds_force_cleared_available',
                'note' => $is_malformed_available ? 'Malformed available row repaired by Ledger Inspector safe promotion tool' : 'Funds force-cleared by Ledger Inspector safe promotion test',
                'updated_at' => $now,
                'pending_until' => $now,
                'meta' => wp_json_encode($meta),
            ],
            ['id' => $row_id],
            ['%s','%s','%s','%s','%s','%s'],
            ['%d']
        );

        // After the inspector promotes a row, delegate real recovery to BankSellerLedger.
        // The Inspector must never allocate on its own. It loads the canonical ledger engine
        // and asks it to run the same available-stage recovery that normal settlement uses.
        $allocator_status = 'not_attempted';
        $allocator_result = [];
        if ($updated !== false) {
            try {
                if (!self::ensure_bank_ledger_loaded()) {
                    $allocator_status = 'bank_ledger_class_not_loaded';
                } elseif (method_exists('\\Caricove\\Bank\\Ledger', 'inspector_allocate_available_row')) {
                    $allocator_result = (array) \Caricove\Bank\Ledger::inspector_allocate_available_row($row_id, [
                        'operation' => 'ledger_inspector_safe_promote',
                        'command_source' => 'ledger_inspector_auditor',
                        'correlation_id' => $trace_id,
                        'actor_user_id' => get_current_user_id(),
                    ]);
                    $allocator_status = ((float)($allocator_result['applied'] ?? 0) > 0) ? 'applied' : 'ran_no_allocation';
                } elseif (method_exists('\\Caricove\\Bank\\Ledger', 'auto_allocate_open_debits_to_available_row')) {
                    $rm = new \ReflectionMethod('\\Caricove\\Bank\\Ledger', 'auto_allocate_open_debits_to_available_row');
                    $rm->setAccessible(true);
                    $allocator_result = (array) $rm->invoke(null, $row_id, [
                        'operation' => 'ledger_inspector_safe_promote',
                        'command_source' => 'ledger_inspector_auditor',
                        'correlation_id' => $trace_id,
                        'actor_user_id' => get_current_user_id(),
                    ]);
                    $allocator_status = ((float)($allocator_result['applied'] ?? 0) > 0) ? 'applied' : 'ran_no_allocation';
                } else {
                    $allocator_status = 'allocator_method_missing';
                }
            } catch (\Throwable $e) {
                $allocator_status = 'allocator_exception';
                $allocator_result = [
                    'message' => $e->getMessage(),
                    'file' => basename($e->getFile()),
                    'line' => (int)$e->getLine(),
                ];
                // Export will still show the promoted row; allocator failure must not white-screen admin.
            }

            self::mark_promote_allocator_status($row_id, $allocator_status, $allocator_result);
        }


        wp_safe_redirect(add_query_arg($redirect_args + [($updated === false ? 'ccv_promote_error' : 'ccv_promoted') => ($updated === false ? 'db_update_failed' : $row_id)], admin_url('admin.php')));
        exit;
    }

    private static function top_safe_promote_panel(array $req): string {
        $shipment_id = (int)($req['shipment_id'] ?? 0);
        ob_start();
        ?>
        <div class="notice notice-warning" style="padding:12px 14px;margin:12px 0 16px 0;border-left-color:#d63638">
            <p style="margin:0 0 8px 0"><strong>Temporary test tool:</strong> Safe Promote / Repair updates state, event_type, pending_until, and meta together. Use only for one test shipment.</p>
            <form method="post" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:0">
                <?php wp_nonce_field('ccv_safe_force_promote'); ?>
                <input type="hidden" name="page" value="caricove-ledger-inspector">
                <input type="hidden" name="return_tab" value="<?php echo esc_attr((string)($req['tab'] ?? 'ledger')); ?>">
                <label><strong>Shipment ID</strong></label>
                <input type="number" name="promote_shipment_id" value="<?php echo esc_attr((string)$shipment_id); ?>" min="1" style="width:140px">
                <button type="submit" name="ccv_safe_force_promote" value="1" class="button button-primary" onclick="return confirm('Safe promote or repair this one shipment row?');">Force Promote / Repair (SAFE)</button>
                <span style="color:#646970">Visible here even when the row-level button is hidden.</span>
            </form>
        </div>
        <?php
        return (string)ob_get_clean();
    }

    public static function maybe_export_json(): void {
        if (!is_admin() || !current_user_can('manage_options')) return;
        if (($_GET['page'] ?? '') !== 'caricove-ledger-inspector') return;
        $req = self::req();
        if (empty($req['export_json'])) return;

        $ledger = self::ledger_rows($req);
        $bank = self::bank_events($req);
        $linked = self::linked($ledger, $bank);
        nocache_headers();
        header('Content-Type: application/json; charset=utf-8');
        header('Content-Disposition: attachment; filename=ledger-inspector-audit-' . gmdate('Ymd-His') . '.json');
        echo wp_json_encode([
            'filters' => $req,
            'tables' => self::tables(),
            'summary' => [
                'ledger_rows' => count($ledger),
                'bank_events' => count($bank),
                'linked_groups' => count($linked),
                'ledger_issue_rows' => count(array_filter($ledger, fn($r)=>!empty($r['_audit']['issues']))),
                'bank_issue_rows' => count(array_filter($bank, fn($r)=>!empty($r['_audit']['issues']))),
            ],
            'ledger_rows' => $ledger,
            'bank_events' => $bank,
            'linked_groups' => $linked,
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        exit;
    }


    private static function safe_promote_button(array $row, string $return_tab = 'ledger'): string {
        if ((string)($row['state'] ?? '') !== 'pending') return '';
        $row_id = (int)($row['id'] ?? 0);
        if ($row_id <= 0) return '';
        ob_start();
        ?>
        <form method="post" style="margin-top:8px;display:inline-block">
            <?php wp_nonce_field('ccv_safe_force_promote'); ?>
            <input type="hidden" name="page" value="caricove-ledger-inspector">
            <input type="hidden" name="row_id" value="<?php echo esc_attr((string)$row_id); ?>">
            <input type="hidden" name="return_tab" value="<?php echo esc_attr($return_tab); ?>">
            <input type="hidden" name="return_shipment_id" value="<?php echo esc_attr((string)(int)($row['shipment_id'] ?? 0)); ?>">
            <button type="submit" name="ccv_safe_force_promote" value="1" class="button button-small" onclick="return confirm('Force promote this one pending ledger row using the safe inspector transition?');">Force Promote (SAFE)</button>
        </form>
        <?php
        return (string)ob_get_clean();
    }

    private static function issue_badges(array $issues): string {
        if (empty($issues)) return '<span class="good">No immediate issues flagged</span>';
        $html='';
        foreach ($issues as $i) {
            $sev = esc_attr((string)$i['severity']);
            $msg = esc_html((string)$i['message']);
            $code= esc_html((string)$i['code']);
            $html .= "<span class='flag {$sev}' title='{$code}'>{$msg}</span> ";
        }
        return $html;
    }

    public static function render(): void {
        if (!current_user_can('manage_options')) wp_die('Access denied.');
        $req = self::req();
        $ledger = self::ledger_rows($req);
        $bank = self::bank_events($req);
        $linked = self::linked($ledger, $bank);
        $tables = self::tables();
        $active = in_array($req['tab'], ['ledger','bank','linked'], true) ? $req['tab'] : 'ledger';
        $base = admin_url('admin.php');
        ?>
        <div class="wrap">
            <h1>Ledger Inspector Auditor</h1>
            <?php if (!empty($_GET['ccv_promoted'])): ?><div class="notice notice-success"><p>Safe force promotion applied to ledger row #<?php echo esc_html((string)absint($_GET['ccv_promoted'])); ?>.</p></div><?php endif; ?>
            <?php if (!empty($_GET['ccv_promote_error'])): ?><div class="notice notice-error"><p>Safe force promotion failed: <?php echo esc_html(sanitize_text_field((string)$_GET['ccv_promote_error'])); ?>.</p></div><?php endif; ?>
            <p>Read-only financial auditor for ledger rows, bank events, linked chains, and business-rule contradictions. The temporary Force Promote / Repair tool performs a full synced test transition.</p>
            <?php echo self::top_safe_promote_panel($req); ?>
            <style>
            .tabs{display:flex;gap:8px;margin:0 0 14px 0}.tab{display:inline-block;padding:8px 14px;text-decoration:none;border:1px solid #ccd0d4;background:#fff;border-radius:6px 6px 0 0;color:#1d2327}.tab.active{background:#eef4ff;font-weight:600}
            .formgrid{margin-bottom:16px;display:grid;grid-template-columns:repeat(6,minmax(120px,1fr));gap:10px;max-width:1500px}
            .meta{color:#555;font-size:12px;margin:6px 0 14px 0;display:flex;flex-wrap:wrap;gap:20px}
            .wraptable{overflow:auto;max-width:100%;border:1px solid #ccd0d4;background:#fff}.tbl{border-collapse:collapse;width:100%;min-width:2000px}.tbl th,.tbl td{border:1px solid #e2e4e7;padding:8px;vertical-align:top;text-align:left;font-size:12px;line-height:1.4}.tbl th{position:sticky;top:0;background:#f6f7f7;z-index:2}
            .pre{max-width:800px;max-height:280px;overflow:auto;white-space:pre-wrap;word-break:break-word;background:#0f172a;color:#e2e8f0;padding:10px;border-radius:6px;margin:0;font-size:11px}
            .pill{display:inline-block;padding:2px 8px;border-radius:999px;font-size:11px;font-weight:600;background:#eef2ff}.state-paid{background:#dcfce7}.state-debit{background:#fee2e2}.state-available{background:#dbeafe}.state-pending{background:#fef3c7}.state-reversed{background:#f3f4f6}.state-hold{background:#ede9fe}
            .flag{display:inline-block;border-radius:999px;padding:2px 8px;margin:0 6px 6px 0;font-size:11px;font-weight:600}.flag.critical{background:#fee2e2;color:#991b1b;border:1px solid #fca5a5}.flag.warning{background:#fff7ed;color:#9a3412;border:1px solid #fdba74}.good{color:#166534;font-weight:600}.bad{color:#991b1b;font-weight:600}
            .group{border:1px solid #dcdcde;border-radius:8px;margin:0 0 18px 0;background:#fff}.grouphead{padding:12px 14px;background:#f8fafc;border-bottom:1px solid #e5e7eb;font-weight:600}.groupbody{padding:14px}
            .subhead{font-size:14px;font-weight:700;margin:0 0 10px 0}.printbar{margin:0 0 16px 0;display:flex;gap:10px;align-items:center;flex-wrap:wrap}
            @media print{.tabs,.formgrid,.meta,.button{display:none !important}.wrap h1,.wrap>p{display:none !important}.pre{background:#fff !important;color:#000 !important;border:1px solid #ccc}}
            </style>
            <div class="tabs">
            <?php foreach (['ledger'=>'Ledger Rows','bank'=>'Bank Events','linked'=>'Linked View'] as $tab=>$label): ?>
                <?php $args = array_merge($req, ['page'=>'caricove-ledger-inspector','tab'=>$tab,'print_mode'=>0,'export_json'=>0]); ?>
                <a class="tab <?php echo $active===$tab?'active':''; ?>" href="<?php echo esc_url(add_query_arg($args, $base)); ?>"><?php echo esc_html($label); ?></a>
            <?php endforeach; ?>
            </div>
            <form method="get" class="formgrid">
                <input type="hidden" name="page" value="caricove-ledger-inspector">
                <input type="hidden" name="tab" value="<?php echo esc_attr($active); ?>">
                <div><label><strong>Vendor ID</strong></label><br><input type="number" name="vendor_id" value="<?php echo esc_attr((string)$req['vendor_id']); ?>" style="width:100%"></div>
                <div><label><strong>Order ID</strong></label><br><input type="number" name="order_id" value="<?php echo esc_attr((string)$req['order_id']); ?>" style="width:100%"></div>
                <div><label><strong>Shipment ID</strong></label><br><input type="number" name="shipment_id" value="<?php echo esc_attr((string)$req['shipment_id']); ?>" style="width:100%"></div>
                <div><label><strong>State</strong></label><br><input type="text" name="state" value="<?php echo esc_attr((string)$req['state']); ?>" style="width:100%"></div>
                <div><label><strong>Event Type</strong></label><br><input type="text" name="event_type" value="<?php echo esc_attr((string)$req['event_type']); ?>" style="width:100%"></div>
                <div><label><strong>Limit</strong></label><br><input type="number" name="limit" min="1" max="1500" value="<?php echo esc_attr((string)$req['limit']); ?>" style="width:100%"></div>
                <div style="grid-column:1 / span 5"><label><strong>Search</strong></label><br><input type="text" name="search" value="<?php echo esc_attr((string)$req['search']); ?>" style="width:100%" placeholder="unique_key / note / meta / event_uuid / return_case_id / notes"></div>
                <div style="display:flex;align-items:end;gap:8px;flex-wrap:wrap"><button class="button button-primary" type="submit">Filter</button><button class="button" type="submit" name="print_mode" value="1">Print Mode</button><button class="button" type="submit" name="export_json" value="1">Export JSON</button></div>
                <div style="grid-column:1/span 6;display:flex;gap:18px;flex-wrap:wrap;align-items:center">
                    <label><input type="checkbox" name="issues_only" value="1" <?php checked($req['issues_only'],1); ?>> Only show rows with issues</label>
                    <label><input type="checkbox" name="show_full_json" value="1" <?php checked($req['show_full_json'],1); ?>> Show full raw JSON</label>
                    <span>Ledger table: <?php echo $tables['ledger'] ? '<span class="good">found</span>' : '<span class="bad">missing</span>'; ?></span>
                    <span>Bank events table: <?php echo $tables['bank_events'] ? '<span class="good">found</span>' : '<span class="bad">missing</span>'; ?></span>
                </div>
            </form>
            <div class="meta"><span>Ledger rows: <?php echo esc_html((string)count($ledger)); ?></span><span>Bank events: <?php echo esc_html((string)count($bank)); ?></span><span>Linked groups: <?php echo esc_html((string)count($linked)); ?></span><span>Issue-only filter: <?php echo $req['issues_only']?'on':'off'; ?></span></div>
            <?php if ($req['print_mode']): ?><div class="printbar"><button type="button" class="button button-primary" onclick="window.print()">Print These Filtered Results</button></div><?php endif; ?>
            <?php if ($active === 'ledger'): ?>
                <div class="wraptable"><table class="tbl"><thead><tr><th>ID</th><th>Unique Key</th><th>Shipment / Order / Vendor</th><th>State / Event</th><th>Amounts</th><th>Dates</th><th>Audit Issues</th><th>Rule Trace</th><th><?php echo $req['show_full_json'] ? 'Full Meta' : 'Meta Summary'; ?></th></tr></thead><tbody>
                <?php if (!$ledger): ?><tr><td colspan="9">No ledger rows found.</td></tr><?php else: foreach ($ledger as $row): $audit=$row['_audit']; $meta=$audit['trace']['meta']; $state_class='state-' . sanitize_html_class((string)$row['state']); ?>
                <tr>
                    <td><?php echo (int)$row['id']; ?></td>
                    <td><strong><?php echo esc_html((string)$row['unique_key']); ?></strong><br><small>Doctrine: <strong class="<?php echo (($audit['doctrine']['status'] ?? '') === 'PASS') ? 'good' : 'bad'; ?>"><?php echo esc_html((string)($audit['doctrine']['status'] ?? 'FAIL')); ?></strong> / <?php echo esc_html((string)($audit['doctrine']['role'] ?? 'UNKNOWN')); ?></small><br><small>Severity score: <?php echo (int)$audit['severity_score']; ?></small></td>
                    <td><div><strong>Shipment:</strong> <?php echo (int)$row['shipment_id']; ?></div><div><strong>Order:</strong> <?php echo (int)$row['order_id']; ?></div><div><strong>Vendor:</strong> <?php echo (int)$row['vendor_id']; ?></div><div><strong>Currency:</strong> <?php echo esc_html((string)$row['currency']); ?></div></td>
                    <td><div><span class="pill <?php echo esc_attr($state_class); ?>"><?php echo esc_html((string)$row['state']); ?></span></div><div style="margin-top:6px"><strong><?php echo esc_html((string)$row['event_type']); ?></strong></div><div style="margin-top:6px"><strong>row note:</strong> <?php echo esc_html((string)$row['note']); ?></div><?php echo self::safe_promote_button($row, 'ledger'); ?></td>
                    <td><div><strong>gross:</strong> <?php echo esc_html((string)$row['gross']); ?></div><div><strong>commission:</strong> <?php echo esc_html((string)$row['commission']); ?></div><div><strong>courier_fees:</strong> <?php echo esc_html((string)$row['courier_fees']); ?></div><div><strong>reserve:</strong> <?php echo esc_html((string)$row['reserve']); ?></div><div><strong>net:</strong> <strong><?php echo esc_html((string)$row['net']); ?></strong></div><div><strong>slice total:</strong> <?php echo esc_html(number_format((float)$audit['slice_total'],2,'.','')); ?></div></td>
                    <td><div><strong>created:</strong><br><?php echo esc_html((string)$row['created_at']); ?></div><div><strong>updated:</strong><br><?php echo esc_html((string)$row['updated_at']); ?></div><div><strong>delivered:</strong><br><?php echo esc_html((string)$row['delivered_at']); ?></div><div><strong>pending_until:</strong><br><?php echo esc_html((string)$row['pending_until']); ?></div></td>
                    <td><?php echo self::issue_badges($audit['issues']); ?></td>
                    <td><div><strong>refund_case_id:</strong> <?php echo esc_html((string)$audit['trace']['refund_case_id']); ?></div><div><strong>correlation_id:</strong> <?php echo esc_html((string)$audit['trace']['correlation_id']); ?></div><div><strong>trace_operation:</strong> <?php echo esc_html((string)$audit['trace']['trace_operation']); ?></div><div><strong>shipping row:</strong> <?php echo $audit['is_shipping'] ? 'yes' : 'no'; ?></div><div><strong>refund debit:</strong> <?php echo $audit['is_refund_debit'] ? 'yes' : 'no'; ?></div></td>
                    <td><?php if ($req['show_full_json']): ?><pre class="pre"><?php echo esc_html(self::encode_json($meta)); ?></pre><?php else: ?><div><strong>settlement_stage:</strong> <?php echo esc_html((string)self::path($meta,'settlement_stage','')); ?></div><div><strong>settlement_state:</strong> <?php echo esc_html((string)self::path($meta,'settlement_state','')); ?></div><div><strong>meta.pending_until:</strong> <?php echo esc_html((string)self::path($meta,'pending_until','')); ?></div><div><strong>payout_mode:</strong> <?php echo esc_html((string)self::path($meta,'payout_mode','')); ?></div><div><strong>debit_component:</strong> <?php echo esc_html((string)self::path($meta,'debit_component','')); ?></div><div><strong>shipping_liability_party:</strong> <?php echo esc_html((string)self::first_non_empty(self::path($meta,'shipping_liability_party',''), self::path($meta,'return_bridge.shipping_liability_party',''))); ?></div></td><?php endif; ?>
                </tr>
                <?php endforeach; endif; ?></tbody></table></div>
            <?php elseif ($active === 'bank'): ?>
                <div class="wraptable"><table class="tbl"><thead><tr><th>ID</th><th>Event UUID</th><th>Type / Status</th><th>Order / Shipment / Return Case</th><th>Parties</th><th>Amount</th><th>Audit Issues</th><th>Rule Trace</th><th><?php echo $req['show_full_json'] ? 'Full Meta JSON' : 'Meta Summary'; ?></th></tr></thead><tbody>
                <?php if (!$bank): ?><tr><td colspan="9">No bank events found.</td></tr><?php else: foreach ($bank as $row): $audit=$row['_audit']; $meta=$audit['trace']['meta']; ?>
                <tr>
                    <td><?php echo (int)$row['id']; ?></td>
                    <td><strong><?php echo esc_html((string)$row['event_uuid']); ?></strong><br><small>Severity score: <?php echo (int)$audit['severity_score']; ?></small></td>
                    <td><div><strong><?php echo esc_html((string)$row['event_type']); ?></strong></div><div><?php echo esc_html((string)$row['event_status']); ?></div></td>
                    <td><div><strong>Order:</strong> <?php echo (int)$row['order_id']; ?></div><div><strong>Shipment:</strong> <?php echo (int)$row['shipment_id']; ?></div><div><strong>Return case:</strong> <?php echo esc_html((string)$row['return_case_id']); ?></div></td>
                    <td><div><strong>Vendor:</strong> <?php echo (int)$row['vendor_id']; ?></div><div><strong>Customer:</strong> <?php echo (int)$row['customer_id']; ?></div><div><strong>Courier:</strong> <?php echo (int)$row['courier_id']; ?></div><div><strong>Payer:</strong> <?php echo esc_html((string)$row['payer_type']); ?> #<?php echo esc_html((string)$row['payer_id']); ?></div><div><strong>Payee:</strong> <?php echo esc_html((string)$row['payee_type']); ?> #<?php echo esc_html((string)$row['payee_id']); ?></div></td>
                    <td><div><strong>Amount:</strong> <?php echo esc_html((string)$row['amount']); ?></div><div><strong>Direction:</strong> <?php echo esc_html((string)$row['direction']); ?></div><div><strong>Currency:</strong> <?php echo esc_html((string)$row['currency']); ?></div></td>
                    <td><?php echo self::issue_badges($audit['issues']); ?></td>
                    <td><div><strong>refund_case_id:</strong> <?php echo esc_html((string)$audit['trace']['refund_case_id']); ?></div><div><strong>correlation_id:</strong> <?php echo esc_html((string)$audit['trace']['correlation_id']); ?></div><div><strong>trace_operation:</strong> <?php echo esc_html((string)$audit['trace']['trace_operation']); ?></div></td>
                    <td><?php if ($req['show_full_json']): ?><pre class="pre"><?php echo esc_html(self::encode_json($meta)); ?></pre><?php else: ?><div><strong>reason_code:</strong> <?php echo esc_html((string)$row['reason_code']); ?></div><div><strong>reason_label:</strong> <?php echo esc_html((string)$row['reason_label']); ?></div><div><strong>source_system:</strong> <?php echo esc_html((string)$row['source_system']); ?></div><div><strong>source_ref:</strong> <?php echo esc_html((string)$row['source_ref']); ?></div><div><strong>notes:</strong> <?php echo esc_html((string)$row['notes']); ?></div><?php endif; ?></td>
                </tr>
                <?php endforeach; endif; ?></tbody></table></div>
            <?php else: ?>
                <?php if (!$linked): ?><p>No linked groups found.</p><?php else: foreach ($linked as $group): ?>
                    <div class="group"><div class="grouphead"><?php echo esc_html((string)$group['group_key']); ?> — severity <?php echo (int)$group['severity_score']; ?> / issues <?php echo (int)$group['issue_count']; ?></div><div class="groupbody">
                        <div class="subhead">Ledger Rows (<?php echo count($group['ledger_rows'] ?? []); ?>)</div>
                        <div class="wraptable" style="margin-bottom:14px"><table class="tbl" style="min-width:1200px"><thead><tr><th>ID</th><th>Unique Key</th><th>State / Event</th><th>Net</th><th>Audit Issues</th><th>Actions</th></tr></thead><tbody>
                        <?php if (empty($group['ledger_rows'])): ?><tr><td colspan="6">No ledger rows in this group.</td></tr><?php else: foreach (($group['ledger_rows'] ?? []) as $row): ?>
                            <tr><td><?php echo (int)$row['id']; ?></td><td><?php echo esc_html((string)$row['unique_key']); ?><br><small>Doctrine: <strong class="<?php echo (($row['_audit']['doctrine']['status'] ?? '') === 'PASS') ? 'good' : 'bad'; ?>"><?php echo esc_html((string)($row['_audit']['doctrine']['status'] ?? 'FAIL')); ?></strong></small></td><td><?php echo esc_html((string)$row['state']); ?> / <?php echo esc_html((string)$row['event_type']); ?></td><td><?php echo esc_html((string)$row['net']); ?></td><td><?php echo self::issue_badges($row['_audit']['issues'] ?? []); ?></td><td><?php echo self::safe_promote_button($row, 'linked'); ?></td></tr>
                            <?php if ($req['show_full_json']): ?><tr><td colspan="6"><pre class="pre"><?php echo esc_html(self::encode_json(self::extract_ledger_trace($row)['meta'])); ?></pre></td></tr><?php endif; ?>
                        <?php endforeach; endif; ?></tbody></table></div>
                        <div class="subhead">Bank Events (<?php echo count($group['bank_events'] ?? []); ?>)</div>
                        <div class="wraptable"><table class="tbl" style="min-width:1200px"><thead><tr><th>ID</th><th>Event UUID</th><th>Type / Status</th><th>Amount</th><th>Audit Issues</th></tr></thead><tbody>
                        <?php if (empty($group['bank_events'])): ?><tr><td colspan="5">No bank events in this group.</td></tr><?php else: foreach (($group['bank_events'] ?? []) as $row): ?>
                            <tr><td><?php echo (int)$row['id']; ?></td><td><?php echo esc_html((string)$row['event_uuid']); ?></td><td><?php echo esc_html((string)$row['event_type']); ?> / <?php echo esc_html((string)$row['event_status']); ?></td><td><?php echo esc_html((string)$row['amount']); ?> <?php echo esc_html((string)$row['currency']); ?></td><td><?php echo self::issue_badges($row['_audit']['issues'] ?? []); ?></td></tr>
                            <?php if ($req['show_full_json']): ?><tr><td colspan="5"><pre class="pre"><?php echo esc_html(self::encode_json(self::extract_bank_trace($row)['meta'])); ?></pre></td></tr><?php endif; ?>
                        <?php endforeach; endif; ?></tbody></table></div>
                    </div></div>
                <?php endforeach; endif; ?>
            <?php endif; ?>
        </div>
        <?php
    }
}

Caricove_Ledger_Inspector_Auditor::boot();
