document.addEventListener('DOMContentLoaded', function () {
const ledgerRows = document.querySelectorAll('.cbank-ledger-row[data-shipment]');
    ledgerRows.forEach(function (row) {
        row.addEventListener('click', function () {
            const shipmentId = this.dataset.shipment;
            const vendorId = this.dataset.vendor || '';
            if (!shipmentId) return;

            let url = CaricoveBank.restUrl + '/ledger?shipment_id=' + encodeURIComponent(shipmentId);
            if (vendorId) {
                url += '&vendor_id=' + encodeURIComponent(vendorId);
            }

            fetch(url, {
                headers: {
                    'X-WP-Nonce': CaricoveBank.nonce
                }
            })
           .then(function (r) {
    if (!r.ok) {
        throw new Error('Ledger endpoint failed: ' + r.status);
    }
    return r.json();
})
            
            
            .then(function (data) {
                let panel = document.getElementById('cbank-ledger-panel');

                if (!panel) {
                    panel = document.createElement('div');
                    panel.id = 'cbank-ledger-panel';
                    panel.style.marginTop = '20px';
                    panel.style.background = '#fff';
                    panel.style.padding = '15px';
                    panel.style.border = '1px solid #ccc';

                    const wrap = document.querySelector('.caricove-bank-wrap');
                    if (wrap) {
                        wrap.appendChild(panel);
                    } else {
                        document.body.appendChild(panel);
                    }
                }

                const bankRows = Array.isArray(data.rows) ? data.rows : [];
                const sellerRows = Array.isArray(data.seller_rows) ? data.seller_rows : [];
                const snapshot = (data && typeof data.shipment_snapshot === 'object' && data.shipment_snapshot) ? data.shipment_snapshot : {};

                if (!bankRows.length && !sellerRows.length) {
                    panel.innerHTML = '<h3>No ledger truth found for shipment ' + shipmentId + '</h3>';
                    return;
                }

                function money(v) {
                    if (v === null || v === undefined || v === '') return '—';
                    const n = Number(v);
                    if (Number.isNaN(n)) return String(v);
                    return 'GYD ' + n.toFixed(2);
                }

                function niceWhen(ts) {
                    if (!ts) return '—';
                    const d = new Date(String(ts).replace(' ', 'T'));
                    if (isNaN(d.getTime())) return ts;
                    return d.toLocaleString();
                }

                function safeMeta(raw) {
                    if (!raw) return {};
                    if (typeof raw === 'object') return raw;
                    try {
                        return JSON.parse(raw);
                    } catch (e) {
                        return {};
                    }
                }

              function eventTitle(type) {
    const map = {
        reversal: 'Seller Earnings Reversed Before Payout',
        seller_deduction_created: 'Seller Owes Caricove',
        customer_refund_issued: 'Customer Refund Sent',
        shipment_earnings_created: 'Shipment Earnings Created',
        vendor_liability_recovered: 'Vendor Liability Cleared From Payout',
        seller_payout_sent: 'Seller Payout Sent',
        seller_offset_consumed: 'Seller Earnings Applied To Debt'
    };

    return map[String(type || '').toLowerCase()] || (type || 'Event');
}

                function sellerStateLabel(state) {
                    const map = {
                        pending: 'Clearing',
                        available: 'Available',
                        paid: 'Paid',
                        debit: 'Debt / Recovery',
                        reversed: 'Reversed',
                        hold: 'On Hold'
                    };
                    return map[String(state || '').toLowerCase()] || (state || '—');
                }

                function settlementPackBank(r, meta) {
                    const rawState = String(meta.settlement_state ?? meta.state ?? r.event_status ?? '').toLowerCase();
                    const recordedAt = r.created_at ?? '';
                    const effectiveAt = r.effective_at ?? recordedAt;
                    const pendingUntil = meta.pending_until ?? null;
                    const updatedAt = r.updated_at ?? null;

                    let settlementState = String(meta.settlement_state || 'recorded').toLowerCase();
                    let stateReason = String(meta.settlement_reason || 'Recorded event');
                    let maturityAt = '—';
                    const settlementStage = String(meta.settlement_stage || '');

                    if (r.event_type === 'shipment_earnings_created') {
                        if (rawState === 'pending') {
                            settlementState = 'pending';
                            stateReason = stateReason || 'Seller earnings are in clearing window';
                            maturityAt = niceWhen(pendingUntil);
                        } else if (rawState === 'available') {
                            settlementState = 'available';
                            stateReason = stateReason || 'Clearing window completed; seller can be paid';
                            maturityAt = updatedAt ? niceWhen(updatedAt) : 'Available now';
                        } else if (rawState === 'hold') {
                            settlementState = 'held';
                            stateReason = stateReason || 'Finance hold is preventing release';
                            maturityAt = 'Held until manual release';
                        } else if (rawState === 'paid') {
                            settlementState = 'paid';
                            stateReason = stateReason || 'Seller payout completed';
                            maturityAt = updatedAt ? niceWhen(updatedAt) : 'Settled';
                        } else if (rawState === 'reversed') {
                            settlementState = 'reversed';
                            stateReason = stateReason || 'Original seller earnings were neutralized before payout';
                            maturityAt = updatedAt ? niceWhen(updatedAt) : 'No release';
                        } else {
                            settlementState = rawState || 'recorded';
                            stateReason = stateReason || 'Seller event recorded';
                            maturityAt = pendingUntil ? niceWhen(pendingUntil) : '—';
                        }
                    } else if (r.event_type === 'seller_deduction_created') {
                        settlementState = settlementState || 'posted';
                        stateReason = stateReason || 'Seller liability posted immediately';
                        maturityAt = 'Immediate';
                    } else if (r.event_type === 'customer_refund_issued') {
                        settlementState = settlementState || 'posted';
                        stateReason = stateReason || 'Customer refund posted immediately';
                        maturityAt = 'Immediate';
                    }

                    let countdownText = '—';
                    if (pendingUntil) {
                        const now = new Date();
                        const target = new Date(String(pendingUntil).replace(' ', 'T'));

                        if (!isNaN(target.getTime())) {
                            const diffMs = target.getTime() - now.getTime();

                            if (diffMs <= 0) {
                                countdownText = 'Ready now';
                            } else {
                                const totalMinutes = Math.floor(diffMs / 60000);
                                const days = Math.floor(totalMinutes / 1440);
                                const hours = Math.floor((totalMinutes % 1440) / 60);
                                const minutes = totalMinutes % 60;

                                if (days > 0) {
                                    countdownText = days + 'd ' + hours + 'h ' + minutes + 'm';
                                } else if (hours > 0) {
                                    countdownText = hours + 'h ' + minutes + 'm';
                                } else {
                                    countdownText = minutes + 'm';
                                }
                            }
                        }
                    }

                    return {
                        settlementStage: settlementStage,
                        settlementState: settlementState,
                        stateReason: stateReason,
                        recordedAt: niceWhen(recordedAt),
                        effectiveAt: niceWhen(effectiveAt),
                        maturityAt: maturityAt,
                        countdownText: countdownText
                    };
                }

                const sellerByState = {};
                sellerRows.forEach(function (r) {
                    sellerByState[String(r.state || '').toLowerCase()] = r;
                });

                const pendingRow = sellerByState.pending || null;
                const availableRow = sellerByState.available || null;
                const paidRow = sellerByState.paid || null;
                const reversedRow = sellerByState.reversed || null;
                const debitRow = sellerByState.debit || null;

                const baselineRow = pendingRow || availableRow || paidRow || reversedRow || null;
                const baselineMeta = baselineRow ? safeMeta(baselineRow.meta) : {};

                const grossDeclared = snapshot.shipment_declared_value !== undefined ? Number(snapshot.shipment_declared_value) : null;

                const saleGross =
                    snapshot.sale_gross !== undefined && snapshot.sale_gross !== null
                        ? Number(snapshot.sale_gross)
                        : (baselineRow ? Number(baselineRow.gross || 0) : (grossDeclared !== null ? grossDeclared : null));

                const saleCommission =
                    snapshot.sale_commission !== undefined && snapshot.sale_commission !== null
                        ? Number(snapshot.sale_commission)
                        : (baselineRow ? Number(baselineRow.commission || 0) : null);

                const saleVendorNetOriginal =
                    snapshot.sale_vendor_net_original !== undefined && snapshot.sale_vendor_net_original !== null
                        ? Number(snapshot.sale_vendor_net_original)
                        : (saleGross !== null && saleCommission !== null ? Number(saleGross) - Number(saleCommission) : null);

                const currentSellerClearing = pendingRow ? Number(pendingRow.net || 0) : 0;
                const currentSellerAvailable = availableRow ? Number(availableRow.net || 0) : 0;
              const bankPaidAmount = bankRows
    .filter(function (r) {
        return String(r.event_type || '').toLowerCase() === 'seller_payout_sent';
    })
    .reduce(function (sum, r) {
        return sum + Math.abs(Number(r.amount || 0));
    }, 0);

const sellerLedgerPaidAmount = sellerRows
    .filter(function (r) {
        return String(r.state || '').toLowerCase() === 'paid';
    })
    .reduce(function (sum, r) {
        return sum + Math.abs(Number(r.net || 0));
    }, 0);

const currentSellerPaid = bankPaidAmount > 0 ? bankPaidAmount : sellerLedgerPaidAmount;

                const sellerFundsReversed =
                    snapshot.seller_funds_reversed !== undefined && snapshot.seller_funds_reversed !== null
                        ? Math.abs(Number(snapshot.seller_funds_reversed))
                        : (reversedRow ? Math.abs(Number(saleVendorNetOriginal || 0)) : 0);

                const sellerFundsDebitedRaw =
                    snapshot.seller_funds_debited !== undefined && snapshot.seller_funds_debited !== null
                        ? Math.abs(Number(snapshot.seller_funds_debited))
                        : (debitRow ? Math.abs(Number(debitRow.net || 0)) : 0);

/*
If seller earnings were fully reversed before payout,
do NOT present the debit as live seller liability in the Seller Outcome summary.
*/
const sellerDebtToCaricove = reversedRow ? 0 : sellerFundsDebitedRaw;
const sellerFundsDebited = reversedRow ? 0 : sellerFundsDebitedRaw;

              let customerRefundAmount = 0;
let totalCommissionReversed =
    snapshot.commission_reversed !== undefined && snapshot.commission_reversed !== null
        ? Math.abs(Number(snapshot.commission_reversed))
        : 0;

const refundEvent = bankRows.find(function (r) {
    return r.event_type === 'customer_refund_issued';
}) || null;

if (refundEvent) {
    const refundMeta = safeMeta(refundEvent.meta_json);
    customerRefundAmount = Math.abs(Number(refundEvent.amount || 0));

    if (!totalCommissionReversed && refundMeta.commission_reversal !== undefined) {
        totalCommissionReversed = Math.abs(Number(refundMeta.commission_reversal || 0));
    } else if (!totalCommissionReversed && reversedRow && saleCommission !== null) {
        totalCommissionReversed = Math.abs(Number(saleCommission || 0));
    }
}

                const customerPaid = snapshot.order_total !== undefined ? Number(snapshot.order_total || 0) : (saleGross !== null ? saleGross : null);
                const orderShipping = snapshot.order_shipping_total !== undefined ? Number(snapshot.order_shipping_total || 0) : 0;
                const customerLossOnOrder = customerPaid !== null ? Math.max(0, Number(customerPaid) - Number(customerRefundAmount || 0)) : null;
                const returnShippingFeeCollected = customerLossOnOrder !== null ? Math.max(0, customerLossOnOrder) : null;

                let whatHappenedToSellerFunds = 'No seller ledger baseline found.';
                if (reversedRow) {
                    whatHappenedToSellerFunds = 'Seller earnings were reversed before payout.';
                } else if (paidRow && debitRow) {
                    whatHappenedToSellerFunds = 'Seller was already paid, then Caricove posted a recovery debt.';
                } else if (pendingRow) {
                    whatHappenedToSellerFunds = 'Seller funds are still clearing.';
                } else if (availableRow) {
                    whatHappenedToSellerFunds = 'Seller funds are available for payout.';
                }

            const platformNetEffect =
                   snapshot.platform_net_effect !== undefined && snapshot.platform_net_effect !== null
                       ? Number(snapshot.platform_net_effect)
                       : ((saleCommission !== null ? Number(saleCommission) : 0) - (totalCommissionReversed || 0));
               

                const bankTimeline = bankRows.slice().sort(function (a, b) {
                    const timeDiff = new Date(a.created_at) - new Date(b.created_at);
                    if (timeDiff !== 0) return timeDiff;
                    return Number(a.id || 0) - Number(b.id || 0);
                });

                let timelineHtml = '';
let runningImpact = 0;
                bankTimeline.forEach(function (r) {
                    const meta = safeMeta(r.meta_json);
                    const settlement = settlementPackBank(r, meta);
const amount = Math.abs(Number(r.amount || 0));                    const signedImpact = r.direction === 'debit' ? -amount : amount;
                    runningImpact += signedImpact;

                 let businessMeaning = 'Recorded bank movement.';
                    if (r.event_type === 'reversal') {
                        businessMeaning = 'This removed uncleared seller earnings before payout.';
                    } else if (r.event_type === 'seller_deduction_created') {
                        businessMeaning = 'This created recoverable seller debt owed back to Caricove.';
                    } else if (r.event_type === 'customer_refund_issued') {
                        businessMeaning = 'This sent money back to the customer.';
                    } else if (r.event_type === 'vendor_liability_recovered') {
                        businessMeaning = 'This cleared seller liability using payout value before cash left the platform.';
                    } else if (r.event_type === 'seller_payout_sent') {
                        businessMeaning = 'This was the actual cash sent to the seller after any liability offset.';
                    }

                    timelineHtml += `
<div class="cbank-event" data-dir="${r.direction}">
    <div class="cbank-event-header">
        <div class="cbank-event-title">${eventTitle(r.event_type)}</div>
        <div class="cbank-event-time">${niceWhen(r.created_at)}</div>
    </div>

    <div class="cbank-inspector-grid">
        <div><strong>Amount</strong><br>${money(amount)}</div>
        <div><strong>Direction</strong><br>${r.direction || '—'}</div>
        <div><strong>Recorded At</strong><br>${settlement.recordedAt}</div>
        <div><strong>Effective At</strong><br>${settlement.effectiveAt}</div>
        <div><strong>Settlement State</strong><br>${settlement.settlementState}</div>

        <div><strong>Business Meaning</strong><br>${businessMeaning}</div>
        <div><strong>Reason</strong><br>${r.reason_label || '—'}</div>
        <div><strong>Vendor</strong><br>${r.store_name || snapshot.store_name || r.vendor_id || '—'}</div>
        <div><strong>Order</strong><br>${r.order_id || snapshot.order_id || '—'}</div>

        <div><strong>Source Ref</strong><br>${r.source_ref || '—'}</div>
        <div><strong>Event UUID</strong><br>${r.event_uuid || '—'}</div>
    </div>

    <details class="cbank-raw">
        <summary>Raw Event</summary>
        <pre>${JSON.stringify(r, null, 2)}</pre>
    </details>
</div>`;
                });

                let sellerLedgerHtml = '';
                if (sellerRows.length) {
                    sellerRows.slice().sort(function (a, b) {
                        const timeDiff = new Date(a.created_at) - new Date(b.created_at);
                        if (timeDiff !== 0) return timeDiff;
                        return Number(a.id || 0) - Number(b.id || 0);
                    }).forEach(function (r) {
                      const meta = safeMeta(r.meta);

const rowState = String(r.state || '').toLowerCase();
const rowEvent = String(r.event_type || '').toLowerCase();

let sellerLedgerNet = Number(r.net || 0);
if (rowState === 'reversed') {
    sellerLedgerNet = Math.max(0, Number(r.gross || 0) - Number(r.commission || 0));
}

const grossNum = Number(r.gross || 0);
const commissionNum = Number(r.commission || 0);
const sellerEarningsBeforeOffset = Math.max(0, grossNum - commissionNum);

let debtOffsetApplied = 0;
if (rowEvent === 'seller_offset_consumed') {
    debtOffsetApplied = Math.abs(sellerLedgerNet);
} else if (rowEvent === 'vendor_withdrawal_paid' && sellerEarningsBeforeOffset > Math.abs(sellerLedgerNet)) {
    debtOffsetApplied = Math.max(0, sellerEarningsBeforeOffset - Math.abs(sellerLedgerNet));
}

const payoutExplainHtml = (
    rowEvent === 'vendor_withdrawal_paid' &&
    grossNum > 0 &&
    commissionNum > 0 &&
    debtOffsetApplied > 0
) ? `
    <div class="cbank-ledger-explain" style="margin-top:12px;padding:14px;border:1px solid #d9e3f0;border-radius:12px;background:#f8fbff;">
        <div style="font-weight:700;margin-bottom:10px;">How this net was calculated</div>
        <div class="cbank-inspector-grid">
            <div><strong>Gross Sale</strong><br>${money(grossNum)}</div>
            <div><strong>Platform Commission</strong><br>-${money(commissionNum)}</div>
            <div><strong>Seller Earnings Before Offset</strong><br>${money(sellerEarningsBeforeOffset)}</div>
            <div><strong>Debt Offset Applied</strong><br>-${money(debtOffsetApplied)}</div>
            <div><strong>Withdrawable Before Payout Fee</strong><br>${money(sellerLedgerNet)}</div>
        </div>
    </div>
` : '';

sellerLedgerHtml += `
<div class="cbank-event" data-dir="${sellerLedgerNet < 0 ? 'debit' : 'credit'}">
    <div class="cbank-event-header">
        <div class="cbank-event-title">Seller Ledger — ${sellerStateLabel(r.state)}</div>
        <div class="cbank-event-time">${niceWhen(r.updated_at || r.created_at)}</div>
    </div>

    <div class="cbank-inspector-grid">
        <div><strong>Gross</strong><br>${money(r.gross)}</div>
        <div><strong>Commission</strong><br>${money(r.commission)}</div>
        <div><strong>Net</strong><br>${money(sellerLedgerNet)}</div>
        <div><strong>State</strong><br>${sellerStateLabel(r.state)}</div>
        <div><strong>Delivered At</strong><br>${niceWhen(r.delivered_at)}</div>
        <div><strong>Pending Until</strong><br>${niceWhen(r.pending_until)}</div>
        <div><strong>Event Type</strong><br>${r.event_type || '—'}</div>
        <div><strong>Note</strong><br>${r.note || '—'}</div>
        <div><strong>Settlement Stage</strong><br>${meta.settlement_stage || '—'}</div>
        <div><strong>Settlement Reason</strong><br>${meta.settlement_reason || '—'}</div>
    </div>

    ${payoutExplainHtml}

    <details class="cbank-raw">
        <summary>Raw Seller Ledger Row</summary>
        <pre>${JSON.stringify(r, null, 2)}</pre>
    </details>
</div>`;
                    });
                }

                const productLines = Array.isArray(snapshot.product_lines) ? snapshot.product_lines : [];
                const productLinesHtml = productLines.length
                    ? productLines.map(function (line) {
                        return `<div><strong>${line.name || 'Item'}</strong><br>Qty ${line.qty || 0} • ${money(line.total)}</div>`;
                    }).join('')
                    : '<div>—</div>';

                let html = `
<div class="cbank-inspector">
    <h3>Shipment ${shipmentId} Ledger Story</h3>
    <div class="cbank-timeline-count">${bankRows.length} bank event(s) • ${sellerRows.length} seller ledger row(s)</div>

    <div class="cbank-summary">
        <h4>Shipment Financial Story</h4>

        <div class="cbank-summary-section">
            <h5>Shipment Snapshot</h5>
            <div class="cbank-summary-grid">
                <div><strong>Shipment ID</strong><br>${shipmentId}</div>
                <div><strong>Order ID</strong><br>${snapshot.order_id || '—'}</div>
                <div><strong>Shipment Status</strong><br>${snapshot.shipment_status || '—'}</div>
                <div><strong>Store</strong><br>${snapshot.store_name || snapshot.pickup_name || '—'}</div>
                <div><strong>Customer</strong><br>${snapshot.customer_name || snapshot.dropoff_name || '—'}</div>
                <div><strong>Items In Shipment</strong><br>${snapshot.item_count || 0}</div>
                <div><strong>Pickup</strong><br>${snapshot.pickup_address || '—'}</div>
                <div><strong>Dropoff</strong><br>${snapshot.dropoff_address || '—'}</div>
            </div>
        </div>

        <div class="cbank-summary-section">
            <h5>Sale Baseline</h5>
            <div class="cbank-summary-grid">
                <div><strong>Product Value</strong><br>${money(saleGross)}</div>
                <div><strong>Order Shipping Charged</strong><br>${money(orderShipping)}</div>
                <div><strong>Customer Paid Total</strong><br>${money(customerPaid)}</div>
                <div><strong>Platform Commission</strong><br>${money(saleCommission)}</div>
                <div><strong>Original Seller Net</strong><br>${money(saleVendorNetOriginal)}</div>
                <div><strong>Products</strong><br>${productLinesHtml}</div>
            </div>
        </div>

        <div class="cbank-summary-section">
            <h5>Customer Outcome</h5>
            <div class="cbank-summary-grid">
                <div><strong>Customer Paid</strong><br>${money(customerPaid)}</div>
                <div><strong>Customer Refunded</strong><br>${money(customerRefundAmount)}</div>
                <div><strong>Customer Still Out Of Pocket</strong><br>${money(customerLossOnOrder)}</div>
                <div><strong>Implied Shipping / Non-Refunded Portion</strong><br>${money(returnShippingFeeCollected)}</div>
            </div>
        </div>

       <div class="cbank-summary-section">
    <h5>Seller Outcome</h5>
    <div class="cbank-summary-grid">
        <div><strong>Original Seller Net</strong><br>${money(saleVendorNetOriginal)}</div>
        <div><strong>Seller Funds Reversed</strong><br>${money(sellerFundsReversed)}</div>
        <div><strong>Seller Funds Debited</strong><br>${money(sellerFundsDebited)}</div>
        <div><strong>Seller Funds Still Clearing</strong><br>${money(currentSellerClearing)}</div>
        <div><strong>Seller Funds Available</strong><br>${money(currentSellerAvailable)}</div>
        <div><strong>Seller Funds Already Paid</strong><br>${money(currentSellerPaid)}</div>
        <div><strong>Seller Balance Owed To Caricove</strong><br>${money(sellerDebtToCaricove)}</div>
        <div><strong>What Happened To Seller Funds</strong><br>${whatHappenedToSellerFunds}</div>
    </div>
</div>

        <div class="cbank-summary-section">
            <h5>Platform Outcome</h5>
            <div class="cbank-summary-grid">
                <div><strong>Original Commission</strong><br>${money(saleCommission)}</div>
                <div><strong>Commission Reversed / Recovered</strong><br>${money(totalCommissionReversed)}</div>
                <div><strong>Customer Refund Paid</strong><br>${money(customerRefundAmount)}</div>
                <div><strong>Platform Net Profit On This Shipment</strong><br>${money(platformNetEffect)}</div>
            </div>
        </div>
    </div>

    <div class="cbank-summary-section">
        <h5>Bank Event Timeline</h5>
        ${timelineHtml || '<div>No bank event rows found.</div>'}
    </div>

    <div class="cbank-summary-section">
        <h5>Canonical Seller Ledger Rows</h5>
        ${sellerLedgerHtml || '<div>No seller ledger rows found.</div>'}
    </div>
</div>`;

                panel.innerHTML = html;
            })
            .catch(function (err) {
                console.error(err);
                let panel = document.getElementById('cbank-ledger-panel');
                if (!panel) {
                    panel = document.createElement('div');
                    panel.id = 'cbank-ledger-panel';
                    document.body.appendChild(panel);
                }
                panel.innerHTML = '<h3>Could not load shipment ledger.</h3><pre>' + String(err) + '</pre>';
            });
        });
    });

    document.addEventListener('click', function (e) {
        const btn = e.target.closest('.cbank-pay-btn');
        if (!btn) return;

        const canPay = btn.getAttribute('data-can-pay') === '1';
        if (!canPay) return;

        const payoutId = parseInt(btn.getAttribute('data-payout-id') || '0', 10);
        if (!payoutId) return;

        if (btn.dataset.busy === '1') return;

        const originalText = btn.textContent;

        btn.dataset.busy = '1';
        btn.disabled = true;
        btn.textContent = 'Processing...';
        btn.style.opacity = '0.75';
        btn.style.cursor = 'wait';

        fetch(CaricoveBank.restUrl + '/payouts/' + encodeURIComponent(payoutId) + '/execute', {
            method: 'POST',
            headers: {
                'X-WP-Nonce': CaricoveBank.nonce,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                note: 'Executed from Caricove Bank payouts tab'
            })
        })
        .then(async function (r) {
            let data = {};
            try {
                data = await r.json();
            } catch (err) {}

            if (!r.ok || !data.ok) {
                throw new Error((data && (data.message || data.error)) ? (data.message || data.error) : 'Payout execution failed.');
            }

            btn.textContent = 'Paid';
            btn.style.background = '#16a34a';
            btn.style.borderColor = '#166534';
            btn.style.color = '#fff';
            btn.style.cursor = 'default';

            setTimeout(function () {
                window.location.reload();
            }, 700);
        })
        .catch(function (err) {
            console.error(err);
            btn.dataset.busy = '0';
            btn.disabled = false;
            btn.textContent = originalText;
            btn.style.opacity = '1';
            btn.style.cursor = 'pointer';
            alert(err && err.message ? err.message : 'Could not execute payout.');
        });
    });
});
