<?php
namespace Caricove\Bank;

if ( ! defined('ABSPATH') ) { exit; }

/**
 * Caricove Ledger Doctrine — ULTRA STRICT v2.0.0
 *
 * This is the canonical ledger rulebook. It validates only. It never repairs,
 * allocates, promotes, mutates, rewrites, or infers missing ledger truth.
 *
 * Doctrine roles:
 * - EARNING_PENDING / EARNING_AVAILABLE / EARNING_HOLD
 * - PAYOUT_CASH
 * - OFFSET_TARGET
 * - DEBIT_OPEN
 * - DEBIT_RESOLVED
 * - EARNING_REVERSAL
 * - UNKNOWN
 */
final class LedgerDoctrine {
    public const VERSION = 'ultra-strict-v3.0.0';
    public const EPSILON = 0.01;
    public const STATUS_PASS = 'PASS';
    public const STATUS_FAIL = 'FAIL';

    public static function validate_row($row, array $options = []): array {
        $ctx = self::normalize_row($row);
        $meta = self::decode_meta((string) $ctx['meta_raw']);
        $ctx['meta'] = $meta;
        $ctx['role'] = self::classify($ctx, $meta);

        $violations = [];
        self::rule_required_columns($ctx, $meta, $violations, $options);
        self::rule_json($ctx, $meta, $violations);
        self::rule_state_event_matrix($ctx, $meta, $violations);
        self::rule_settlement_state($ctx, $meta, $violations);
        self::rule_trace($ctx, $meta, $violations);
        self::rule_money_and_slices($ctx, $meta, $violations);
        self::rule_source_capacity($ctx, $meta, $violations);
        self::rule_target_capacity($ctx, $meta, $violations);
        self::rule_allocation_edges($ctx, $meta, $violations);
        self::rule_reopen_unwind($ctx, $meta, $violations);
        self::rule_identity($ctx, $meta, $violations);
        self::rule_shipping_vs_item($ctx, $meta, $violations);
        self::rule_forbidden_legacy_pollution($ctx, $meta, $violations);

        return [
            'doctrine_version' => self::VERSION,
            'status' => empty($violations) ? self::STATUS_PASS : self::STATUS_FAIL,
            'row_id' => (int) $ctx['id'],
            'unique_key' => (string) $ctx['unique_key'],
            'role' => (string) $ctx['role'],
            'state' => (string) $ctx['state'],
            'event_type' => (string) $ctx['event_type'],
            'violations' => array_values($violations),
        ];
    }

    public static function validate_rows(array $rows, array $options = []): array {
        $reports = [];
        $failed = 0;
        foreach ($rows as $row) {
            $report = self::validate_row($row, $options);
            if (($report['status'] ?? '') !== self::STATUS_PASS) {
                $failed++;
            }
            $reports[] = $report;
        }
        return [
            'doctrine_version' => self::VERSION,
            'status' => $failed === 0 ? self::STATUS_PASS : self::STATUS_FAIL,
            'total_rows' => count($reports),
            'passed_rows' => count($reports) - $failed,
            'failed_rows' => $failed,
            'reports' => $reports,
        ];
    }

    public static function row_passes($row, array $options = []): bool {
        return (self::validate_row($row, $options)['status'] ?? '') === self::STATUS_PASS;
    }

    public static function assert_row_passes($row, string $context = '', array $options = []): void {
        $report = self::validate_row($row, $options);
        if (($report['status'] ?? '') !== self::STATUS_PASS) {
            $message = 'LedgerDoctrine violation';
            if ($context !== '') {
                $message .= ' [' . $context . ']';
            }
            $message .= ': ' . self::json($report);
            throw new \RuntimeException($message);
        }
    }

    public static function compact_codes(array $report): array {
        $out = [];
        foreach ((array) ($report['violations'] ?? []) as $v) {
            if (is_array($v) && !empty($v['code'])) {
                $out[] = (string) $v['code'];
            }
        }
        return array_values(array_unique($out));
    }

    private static function normalize_row($row): array {
        $get = static function (string $key, $default = null) use ($row) {
            if (is_array($row)) {
                return array_key_exists($key, $row) ? $row[$key] : $default;
            }
            if (is_object($row)) {
                return isset($row->{$key}) ? $row->{$key} : $default;
            }
            return $default;
        };

        return [
            'id' => (int) $get('id', 0),
            'unique_key' => trim((string) $get('unique_key', '')),
            'shipment_id' => (int) $get('shipment_id', 0),
            'order_id' => (int) $get('order_id', 0),
            'vendor_id' => (int) $get('vendor_id', 0),
            'currency' => strtoupper(trim((string) $get('currency', ''))),
            'state' => strtolower(trim((string) $get('state', ''))),
            'event_type' => strtolower(trim((string) $get('event_type', ''))),
            'gross' => self::money($get('gross', 0)),
            'commission' => self::money($get('commission', 0)),
            'courier_fees' => self::money($get('courier_fees', 0)),
            'reserve' => self::money($get('reserve', 0)),
            'net' => self::money($get('net', 0)),
            'created_at' => (string) $get('created_at', ''),
            'updated_at' => (string) $get('updated_at', ''),
            'delivered_at' => (string) $get('delivered_at', ''),
            'pending_until' => (string) $get('pending_until', ''),
            'note' => (string) $get('note', ''),
            'meta_raw' => (string) $get('meta', ''),
        ];
    }

    private static function decode_meta(string $raw): array {
        if (trim($raw) === '') {
            return ['__decode_ok' => false, '__decode_error' => 'empty_meta'];
        }
        $decoded = json_decode($raw, true);
        if (!is_array($decoded)) {
            return ['__decode_ok' => false, '__decode_error' => json_last_error_msg()];
        }
        $decoded['__decode_ok'] = true;
        return $decoded;
    }

    private static function classify(array $ctx, array $meta): string {
        $state = $ctx['state'];
        $event = $ctx['event_type'];
        $key = $ctx['unique_key'];
        $type = strtolower((string) ($meta['type'] ?? ''));
        $mode = strtolower((string) ($meta['payout_mode'] ?? ''));
        $stage = strtolower((string) ($meta['settlement_stage'] ?? ''));

        $is_debit_key = str_starts_with($key, 'refund-debit:') || str_starts_with($key, 'shipping:');
        $is_debit_meta = $type === 'debit' || !empty($meta['seller_debit_exposure']) || !empty($meta['shipping_liability']);

        if ($is_debit_key || $is_debit_meta) {
            return $state === 'reversed' ? 'DEBIT_RESOLVED' : 'DEBIT_OPEN';
        }
        if ($state === 'paid' && ($mode === 'offset' || $event === 'seller_offset_consumed' || str_contains($event, 'offset'))) {
            return 'OFFSET_TARGET';
        }
        if ($state === 'paid') {
            return 'PAYOUT_CASH';
        }
        if ($state === 'pending') {
            return 'EARNING_PENDING';
        }
        if ($state === 'available') {
            return 'EARNING_AVAILABLE';
        }
        if ($state === 'hold') {
            return 'EARNING_HOLD';
        }
        if ($state === 'reversed') {
            return 'EARNING_REVERSAL';
        }
        if ($stage === 'payout_complete') {
            return 'PAYOUT_CASH';
        }
        return 'UNKNOWN';
    }

    private static function rule_required_columns(array $ctx, array $meta, array &$v, array $options): void {
        $precommit = !empty($options['precommit']);
        if (!$precommit && $ctx['id'] <= 0) {
            self::fail($v, 'D001_ROW_ID_REQUIRED', 'Persisted ledger rows require a positive id.');
        }
        foreach (['unique_key','state','event_type','currency','created_at','updated_at'] as $field) {
            if ((string) $ctx[$field] === '') {
                self::fail($v, 'D002_REQUIRED_COLUMN_EMPTY', 'Required ledger column is empty.', ['field' => $field]);
            }
        }
        foreach (['shipment_id','order_id','vendor_id'] as $field) {
            if ((int) $ctx[$field] <= 0) {
                self::fail($v, 'D003_REQUIRED_ID_INVALID', 'Required ledger id column must be positive.', ['field' => $field]);
            }
        }
        if ($ctx['role'] === 'UNKNOWN') {
            self::fail($v, 'D004_ROW_ROLE_UNKNOWN', 'Ledger row cannot be classified by doctrine.');
        }
    }

    private static function rule_json(array $ctx, array $meta, array &$v): void {
        if (($meta['__decode_ok'] ?? false) !== true) {
            self::fail($v, 'D010_META_JSON_INVALID', 'Ledger meta must be valid non-empty JSON.', ['error' => $meta['__decode_error'] ?? 'unknown']);
        }
    }

    private static function rule_state_event_matrix(array $ctx, array $meta, array &$v): void {
        $state = $ctx['state'];
        $event = $ctx['event_type'];
        $matrix = [
            'pending' => ['shipment_earnings_created', 'seller_hold_released_pending', 'seller_earnings_partially_revers', 'seller_earnings_partially_reversed_unpaid'],
            'hold' => ['shipment_earnings_created', 'seller_earnings_held', 'seller_earnings_hold_set', 'seller_earnings_partially_reversed_unpaid'],
            'available' => ['funds_became_available', 'funds_force_cleared_available', 'seller_hold_released_available', 'shipment_earnings_available', 'available_row_partially_consumed', 'seller_earnings_restored_after_refund_rollback'],
            'paid' => ['vendor_withdrawal_paid', 'seller_offset_consumed', 'seller_offset_partially_reversed', 'seller_offset_partially_released', 'seller_offset_partially_reversed_by_refund', 'seller_offset_restored_after_refund_rollback', 'seller_offset_partially_restored_after_refund_rollback'],
            'debit' => ['seller_deduction_created', 'seller_deduction_partial_offset', 'seller_deduction_reopened_by_ref', 'seller_deduction_reopened_by_refund', 'seller_deduction_partially_reopened', 'seller_offset_reopened_by_refund', 'seller_deduction_reopened_by_refunded_target', 'seller_deduction_partially_reopened_by_refunded_target', 'seller_deduction_partially_reclosed_after_refund_rollback'],
            'reversed' => ['available_row_fully_consumed', 'seller_deduction_fully_offset', 'seller_offset_reversed_by_refund', 'seller_offset_released', 'seller_earnings_reversed_unpaid', 'seller_earnings_restored_reversed', 'seller_deduction_reclosed_after_refund_rollback', 'seller_deduction_rolled_back'],
        ];
        if (!isset($matrix[$state])) {
            self::fail($v, 'D020_STATE_UNKNOWN', 'Unknown ledger state.', ['state' => $state]);
            return;
        }
        if (!in_array($event, $matrix[$state], true)) {
            self::fail($v, 'D021_STATE_EVENT_FORBIDDEN', 'Event type is forbidden for row state.', ['state' => $state, 'event_type' => $event, 'allowed' => $matrix[$state]]);
        }
    }

    private static function rule_settlement_state(array $ctx, array $meta, array &$v): void {
        if (($meta['__decode_ok'] ?? false) !== true) { return; }
        $meta_state = strtolower((string) ($meta['settlement_state'] ?? ''));
        if ($meta_state === '') {
            self::fail($v, 'D030_SETTLEMENT_STATE_REQUIRED', 'meta.settlement_state is required.');
        } elseif ($meta_state !== $ctx['state']) {
            self::fail($v, 'D031_SETTLEMENT_STATE_MISMATCH', 'meta.settlement_state must exactly mirror row.state.', ['row_state' => $ctx['state'], 'settlement_state' => $meta_state]);
        }
        foreach (['settlement_stage','settlement_reason','state_timestamp'] as $key) {
            if (empty($meta[$key])) {
                self::fail($v, 'D032_SETTLEMENT_FIELD_REQUIRED', 'Required settlement meta field is missing.', ['field' => $key]);
            }
        }
    }

    private static function rule_trace(array $ctx, array $meta, array &$v): void {
        if (($meta['__decode_ok'] ?? false) !== true) { return; }
        $trace = isset($meta['trace_context']) && is_array($meta['trace_context']) ? $meta['trace_context'] : [];
        $correlation = (string) ($meta['correlation_id'] ?? ($trace['correlation_id'] ?? ''));
        $operation = (string) ($meta['trace_operation'] ?? ($trace['trace_operation'] ?? ($trace['operation'] ?? '')));
        if ($correlation === '') {
            self::fail($v, 'D040_CORRELATION_ID_REQUIRED', 'correlation_id is required.');
        }
        if ($operation === '') {
            self::fail($v, 'D041_TRACE_OPERATION_REQUIRED', 'trace_operation is required.');
        }
        if (isset($trace['vendor_id']) && (int) $trace['vendor_id'] > 0 && (int) $trace['vendor_id'] !== (int) $ctx['vendor_id']) {
            self::fail($v, 'D042_TRACE_VENDOR_MISMATCH', 'trace_context.vendor_id must match row.vendor_id.', ['row_vendor_id' => $ctx['vendor_id'], 'trace_vendor_id' => (int) $trace['vendor_id']]);
        }
        if (isset($trace['shipment_id']) && (int) $trace['shipment_id'] > 0 && (int) $trace['shipment_id'] !== (int) $ctx['shipment_id'] && $ctx['role'] !== 'DEBIT_OPEN' && $ctx['role'] !== 'DEBIT_RESOLVED') {
            self::fail($v, 'D043_TRACE_SHIPMENT_MISMATCH', 'trace_context.shipment_id must match row.shipment_id for non-source rows.', ['row_shipment_id' => $ctx['shipment_id'], 'trace_shipment_id' => (int) $trace['shipment_id']]);
        }
    }

    private static function rule_money_and_slices(array $ctx, array $meta, array &$v): void {
        if (($meta['__decode_ok'] ?? false) !== true) { return; }
        $role = $ctx['role'];
        $net = self::money($ctx['net']);
        $slices = self::slices($meta);
        $slice_total = self::slice_sum($slices);

        if (in_array($role, ['EARNING_PENDING','EARNING_AVAILABLE','EARNING_HOLD','PAYOUT_CASH','OFFSET_TARGET','DEBIT_OPEN'], true) && empty($slices)) {
            self::fail($v, 'D050_SLICES_REQUIRED', 'financial_slices are required for this row role.', ['role' => $role]);
        }

        foreach ($slices as $i => $slice) {
            if (!is_array($slice)) {
                self::fail($v, 'D051_SLICE_OBJECT_REQUIRED', 'Each financial slice must be an object.', ['index' => $i]);
                continue;
            }
            $slice_id = trim((string) ($slice['slice_id'] ?? ''));
            $amount = self::money($slice['amount'] ?? 0);
            $qty = (float) ($slice['qty'] ?? 0);
            $unit = self::money($slice['unit_amount'] ?? 0);
            if ($slice_id === '') {
                self::fail($v, 'D052_SLICE_ID_REQUIRED', 'Every financial slice requires slice_id.', ['index' => $i]);
            }
            if ($slice_id !== '' && str_starts_with($slice_id, 'auto-target-')) {
                self::fail($v, 'D053_SYNTHETIC_SLICE_FORBIDDEN', 'Synthetic auto-target slice ids are forbidden.', ['slice_id' => $slice_id]);
            }
            if ($slice_id !== '' && str_contains($slice_id, ':fallback')) {
                self::fail($v, 'D054_FALLBACK_SLICE_FORBIDDEN', 'Fallback slice ids are forbidden for doctrine-valid rows.', ['slice_id' => $slice_id]);
            }
            if (!empty($slice['legacy_fallback'])) {
                self::fail($v, 'D055_LEGACY_FALLBACK_SLICE_FORBIDDEN', 'legacy_fallback slices are forbidden for doctrine-valid rows.', ['slice_id' => $slice_id]);
            }
            if ($amount < -self::EPSILON) {
                self::fail($v, 'D056_SLICE_AMOUNT_NEGATIVE', 'Slice amount cannot be negative.', ['slice_id' => $slice_id, 'amount' => $amount]);
            }
            if ($amount > self::EPSILON && $qty <= 0) {
                self::fail($v, 'D057_SLICE_QTY_INVALID', 'Positive slice amount requires positive qty.', ['slice_id' => $slice_id, 'qty' => $qty]);
            }
            if ($amount > self::EPSILON && $unit <= 0) {
                self::fail($v, 'D058_SLICE_UNIT_INVALID', 'Positive slice amount requires positive unit_amount.', ['slice_id' => $slice_id, 'unit_amount' => $unit]);
            }
        }

        if (in_array($role, ['EARNING_PENDING','EARNING_AVAILABLE','EARNING_HOLD','PAYOUT_CASH','OFFSET_TARGET'], true)) {
            if ($net < -self::EPSILON) {
                self::fail($v, 'D060_POSITIVE_ROLE_NET_NEGATIVE', 'Positive ledger roles cannot have negative net.', ['role' => $role, 'net' => $net]);
            }
            if (!self::same($slice_total, $net)) {
                self::fail($v, 'D061_POSITIVE_ROLE_SLICE_NET_MISMATCH', 'Slice total must equal row net for positive ledger roles.', ['role' => $role, 'slice_total' => $slice_total, 'net' => $net]);
            }
        }

        if ($role === 'DEBIT_OPEN') {
            if ($net >= -self::EPSILON) {
                self::fail($v, 'D062_DEBIT_OPEN_NET_NOT_NEGATIVE', 'Open debit rows must have negative net.', ['net' => $net]);
            }
            if (!self::same($slice_total, abs($net))) {
                self::fail($v, 'D063_DEBIT_OPEN_SLICE_NET_MISMATCH', 'Open debit slice total must equal abs(row.net).', ['slice_total' => $slice_total, 'abs_net' => abs($net)]);
            }
        }

        if (in_array($role, ['DEBIT_RESOLVED','EARNING_REVERSAL'], true)) {
            if (!self::same($net, 0.0)) {
                self::fail($v, 'D064_REVERSED_NET_NOT_ZERO', 'Resolved/reversal rows must have net = 0.', ['net' => $net]);
            }
        }

        if ($ctx['gross'] > 0 && in_array($role, ['EARNING_PENDING','EARNING_AVAILABLE','EARNING_HOLD'], true)) {
            $expected = self::money($ctx['gross'] - $ctx['commission'] - $ctx['courier_fees'] - $ctx['reserve']);
            if (!self::same($expected, $net)) {
                self::fail($v, 'D065_EARNING_FORMULA_MISMATCH', 'Earning net must equal gross - commission - courier_fees - reserve.', ['expected' => $expected, 'net' => $net]);
            }
        }
    }

    private static function rule_source_capacity(array $ctx, array $meta, array &$v): void {
        if (($meta['__decode_ok'] ?? false) !== true) { return; }
        if (!in_array($ctx['role'], ['DEBIT_OPEN','DEBIT_RESOLVED'], true)) { return; }

        $net_abs = abs(self::money($ctx['net']));
        $source_original = self::money($meta['source_amount_original'] ?? ($meta['chain_source_slice'] ?? self::slice_sum(self::slices($meta))));
        $still_recovered = self::money($meta['source_amount_still_recovered'] ?? ($meta['debit_offset_applied'] ?? 0));
        $currently_open = self::money($meta['source_amount_currently_open'] ?? ($ctx['role'] === 'DEBIT_OPEN' ? $net_abs : 0));
        $reopened_total = self::money($meta['source_amount_reopened_total'] ?? 0);
        $targets_total = self::edge_sum((array) ($meta['offset_targets'] ?? []));

        if ($source_original <= 0) {
            self::fail($v, 'D070_SOURCE_ORIGINAL_REQUIRED', 'Debit rows require source_amount_original > 0.');
            return;
        }
        if ($currently_open - $source_original > self::EPSILON) {
            self::fail($v, 'D071_SOURCE_OPEN_EXCEEDS_ORIGINAL', 'source_amount_currently_open cannot exceed original exposure.', ['open' => $currently_open, 'original' => $source_original]);
        }
        if ($still_recovered - $source_original > self::EPSILON) {
            self::fail($v, 'D072_SOURCE_RECOVERED_EXCEEDS_ORIGINAL', 'source_amount_still_recovered cannot exceed original exposure.', ['recovered' => $still_recovered, 'original' => $source_original]);
        }
        if (($currently_open + $still_recovered) - $source_original > self::EPSILON) {
            self::fail($v, 'D073_SOURCE_OPEN_PLUS_RECOVERED_EXCEEDS_ORIGINAL', 'open + recovered cannot exceed original exposure.', ['open' => $currently_open, 'recovered' => $still_recovered, 'original' => $source_original]);
        }
        if ($reopened_total - $source_original > self::EPSILON) {
            self::fail($v, 'D074_SOURCE_REOPEN_TOTAL_EXCEEDS_ORIGINAL', 'source_amount_reopened_total cannot exceed original exposure.', ['reopened_total' => $reopened_total, 'original' => $source_original]);
        }
        if ($ctx['role'] === 'DEBIT_OPEN' && !self::same($currently_open, $net_abs)) {
            self::fail($v, 'D075_OPEN_SOURCE_NET_MISMATCH', 'Open debit current exposure must equal abs(row.net).', ['current_open' => $currently_open, 'abs_net' => $net_abs]);
        }
        if ($ctx['role'] === 'DEBIT_RESOLVED' && !self::same($currently_open, 0.0)) {
            self::fail($v, 'D076_RESOLVED_SOURCE_OPEN_NOT_ZERO', 'Resolved debit rows must have zero current open exposure.', ['current_open' => $currently_open]);
        }
        if ($targets_total > 0 && !self::same($targets_total, $still_recovered)) {
            self::fail($v, 'D077_SOURCE_TARGET_EDGE_TOTAL_MISMATCH', 'offset_targets total must equal source_amount_still_recovered.', ['offset_targets_total' => $targets_total, 'still_recovered' => $still_recovered]);
        }
    }

    private static function rule_target_capacity(array $ctx, array $meta, array &$v): void {
        if (($meta['__decode_ok'] ?? false) !== true) { return; }
        if (!in_array($ctx['role'], ['OFFSET_TARGET','EARNING_AVAILABLE','EARNING_PENDING','EARNING_HOLD','PAYOUT_CASH'], true)) { return; }

        $target_capacity = self::money($meta['chain_target_capacity'] ?? $meta['chain_target_capacity_original'] ?? $ctx['net']);
        $target_allocated = self::edge_sum((array) ($meta['offset_sources'] ?? []));
        if ($target_capacity > 0 && $target_allocated - $target_capacity > self::EPSILON) {
            self::fail($v, 'D080_TARGET_ALLOCATED_EXCEEDS_CAPACITY', 'Target allocated amount cannot exceed target capacity.', ['allocated' => $target_allocated, 'capacity' => $target_capacity]);
        }
        if ($ctx['role'] === 'OFFSET_TARGET' && $target_allocated > 0 && !self::same($target_allocated, $ctx['net'])) {
            self::fail($v, 'D081_OFFSET_TARGET_NET_MISMATCH', 'Offset target net must equal sum(offset_sources).', ['offset_sources_total' => $target_allocated, 'net' => $ctx['net']]);
        }
    }

    private static function rule_allocation_edges(array $ctx, array $meta, array &$v): void {
        if (($meta['__decode_ok'] ?? false) !== true) { return; }

        foreach (['offset_sources','offset_targets'] as $collection) {
            $edges = $meta[$collection] ?? [];
            if ($edges === null || $edges === '') { $edges = []; }
            if (!is_array($edges)) {
                self::fail($v, 'D090_EDGE_COLLECTION_INVALID', $collection . ' must be an array.', ['collection' => $collection]);
                continue;
            }
            foreach ($edges as $i => $edge) {
                if (!is_array($edge)) {
                    self::fail($v, 'D091_EDGE_OBJECT_REQUIRED', 'Allocation edge must be an object.', ['collection' => $collection, 'index' => $i]);
                    continue;
                }
                $amount = self::money($edge['amount'] ?? 0);
                $status = (string) ($edge['allocation_status'] ?? '');
                $reference = (string) ($edge['reference'] ?? '');
                $source_slice = (string) ($edge['source_slice_id'] ?? '');
                $target_slice = (string) ($edge['target_slice_id'] ?? '');
                $target_row_id = (int) ($edge['target_row_id'] ?? 0);
                $debit_row_id = (int) ($edge['debit_row_id'] ?? $edge['source_row_id'] ?? 0);

                if ($amount <= 0) {
                    self::fail($v, 'D092_EDGE_AMOUNT_INVALID', 'Allocation edge amount must be positive.', ['collection' => $collection, 'index' => $i, 'amount' => $amount]);
                }
                if ($target_row_id <= 0) {
                    self::fail($v, 'D093_EDGE_TARGET_ROW_ID_REQUIRED', 'Allocation edge requires a real target_row_id.', ['collection' => $collection, 'index' => $i]);
                }
                if ($collection === 'offset_sources' && $debit_row_id <= 0) {
                    self::fail($v, 'D094_EDGE_SOURCE_ROW_ID_REQUIRED', 'Target-side offset_sources require a real debit_row_id.', ['index' => $i]);
                }
                if ($source_slice === '' || $target_slice === '') {
                    self::fail($v, 'D095_EDGE_SLICE_IDS_REQUIRED', 'Allocation edges require source_slice_id and target_slice_id.', ['collection' => $collection, 'index' => $i, 'source_slice_id' => $source_slice, 'target_slice_id' => $target_slice]);
                }
                if (str_starts_with($source_slice, 'auto-target-') || str_starts_with($target_slice, 'auto-target-')) {
                    self::fail($v, 'D096_SYNTHETIC_EDGE_FORBIDDEN', 'Synthetic auto-target allocation edges are forbidden.', ['collection' => $collection, 'index' => $i]);
                }
                if (str_starts_with($reference, 'pending-auto-allocation:') || $status === 'reserved_pending' || str_starts_with($target_slice, 'pending-target-')) {
                    self::fail($v, 'D097_PENDING_RESERVATION_EDGE_FORBIDDEN', 'Pending reservation edges are forbidden in doctrine-valid ledger rows.', ['collection' => $collection, 'index' => $i]);
                }
                if ($status !== '' && $status !== 'consumed') {
                    self::fail($v, 'D098_EDGE_STATUS_INVALID', 'Allocation edge status must be consumed when present.', ['collection' => $collection, 'index' => $i, 'status' => $status]);
                }
                if (empty($edge['allocated_at']) && empty($edge['finalized_at'])) {
                    self::fail($v, 'D099_EDGE_TIMESTAMP_REQUIRED', 'Allocation edge requires allocated_at or finalized_at.', ['collection' => $collection, 'index' => $i]);
                }
                if ($ctx['role'] === 'OFFSET_TARGET' && $collection === 'offset_sources' && $ctx['id'] > 0 && $target_row_id !== $ctx['id']) {
                    self::fail($v, 'D100_TARGET_EDGE_ROW_ID_MISMATCH', 'Target-side offset_sources.target_row_id must equal this row id.', ['row_id' => $ctx['id'], 'edge_target_row_id' => $target_row_id]);
                }
            }
        }
    }

    private static function rule_reopen_unwind(array $ctx, array $meta, array &$v): void {
        if (($meta['__decode_ok'] ?? false) !== true) { return; }
        if (!empty($meta['refund_target_unwind_match_mode']) && (string) $meta['refund_target_unwind_match_mode'] !== 'strict_target_slice') {
            self::fail($v, 'D110_UNWIND_MUST_BE_STRICT_SLICE', 'Refund target unwind must use strict_target_slice only.', ['match_mode' => $meta['refund_target_unwind_match_mode']]);
        }
        if (!empty($meta['refund_target_unwind_fallback_reason'])) {
            self::fail($v, 'D111_UNWIND_FALLBACK_REASON_FORBIDDEN', 'Fallback unwind reasons are forbidden.');
        }
        if (!empty($meta['source_reopen_events']) && empty($meta['refund_target_reopen_case_id']) && empty($meta['reopen_trigger_context'])) {
            self::fail($v, 'D112_REOPEN_TRIGGER_REQUIRED', 'Source reopen events require an explicit trigger context.');
        }
    }

    private static function rule_identity(array $ctx, array $meta, array &$v): void {
        if (($meta['__decode_ok'] ?? false) !== true) { return; }
        if (in_array($ctx['role'], ['DEBIT_OPEN','DEBIT_RESOLVED'], true)) {
            $case_id = (string) ($meta['case_id'] ?? '');
            if ($case_id === '') {
                self::fail($v, 'D120_SOURCE_CASE_ID_REQUIRED', 'Debit source rows require original case_id.');
            }
            $bridge_case = (string) ($meta['return_bridge']['case_id'] ?? '');
            if ($bridge_case !== '' && $case_id !== '' && $bridge_case !== $case_id && empty($meta['reopen_trigger_return_bridge'])) {
                self::fail($v, 'D121_SOURCE_BRIDGE_CASE_MISMATCH', 'return_bridge.case_id must match source case_id unless stored as reopen trigger bridge.', ['case_id' => $case_id, 'bridge_case_id' => $bridge_case]);
            }
            $reopen_case = (string) ($meta['refund_target_reopen_case_id'] ?? '');
            if ($reopen_case !== '' && $case_id !== '' && $reopen_case === $case_id && !empty($meta['source_reopen_events'])) {
                self::fail($v, 'D122_REOPEN_TRIGGER_OVERWROTE_SOURCE_CASE', 'Reopen trigger case must not overwrite the original source case identity.');
            }
        }
    }

    private static function rule_shipping_vs_item(array $ctx, array $meta, array &$v): void {
        if (($meta['__decode_ok'] ?? false) !== true) { return; }
        $kind = strtolower((string) ($meta['return_bridge']['kind'] ?? $meta['debit_component'] ?? ''));
        $is_shipping = !empty($meta['shipping_liability']) || str_starts_with($ctx['unique_key'], 'shipping:') || in_array($kind, ['shipping','shipping_liability'], true);
        if ($is_shipping) {
            if (($meta['return_bridge']['kind'] ?? '') !== 'shipping') {
                self::fail($v, 'D130_SHIPPING_KIND_REQUIRED', 'Shipping debit rows must have return_bridge.kind = shipping.');
            }
            if ((int) ($meta['return_bridge']['item_id'] ?? 0) !== 0) {
                self::fail($v, 'D131_SHIPPING_ITEM_ID_FORBIDDEN', 'Shipping debit rows must use item_id = 0.');
            }
            if (empty($meta['shipping_posting_key']) && empty($meta['shipping_liability_posting_key'])) {
                self::fail($v, 'D132_SHIPPING_POSTING_KEY_REQUIRED', 'Shipping debit rows require a posting key to prevent double posting.');
            }
        } elseif (!empty($meta['shipping_liability_amount'])) {
            self::fail($v, 'D133_ITEM_ROW_CARRIES_SHIPPING_AMOUNT', 'Item rows must not carry shipping_liability_amount.');
        }
    }

    private static function rule_forbidden_legacy_pollution(array $ctx, array $meta, array &$v): void {
        if (($meta['__decode_ok'] ?? false) !== true) { return; }
        $raw = self::json($meta);
        $forbidden_needles = [
            'edge_fallback_offset_sources' => 'D140_EDGE_FALLBACK_FORBIDDEN',
            'pending-auto-allocation:' => 'D144_PENDING_AUTO_ALLOCATION_FORBIDDEN',
            'auto-target-' => 'D145_AUTO_TARGET_FORBIDDEN',
        ];
        foreach ($forbidden_needles as $needle => $code) {
            if (str_contains($raw, $needle)) {
                self::fail($v, $code, 'Legacy/polluting field or value is forbidden.', ['needle' => $needle]);
            }
        }
        foreach (['reset_before_rebuild','inspector_allocator_status','inspector_allocator_details','reserved_offset_sources','pending_offset_reserved_total','pending_offset_reserved_at','offset_source_shipments'] as $key) {
            if (array_key_exists($key, $meta)) {
                self::fail($v, 'D146_FORBIDDEN_REPAIR_OR_RESERVATION_META', 'Repair/reservation-era meta field is forbidden in doctrine-valid rows.', ['field' => $key]);
            }
        }
        foreach (['chain_available_slice','chain_withdrawn_slice','chain_target_allocated_slice','chain_source_slice','chain_repair_slice','chain_source_remaining','chain_target_capacity','chain_target_remaining_capacity','chain_historical_target_reopen_total'] as $key) {
            if (array_key_exists($key, $meta) && self::money($meta[$key]) < -self::EPSILON) {
                self::fail($v, 'D147_CHAIN_VALUE_NEGATIVE', 'chain_* values cannot be negative.', ['field' => $key, 'value' => self::money($meta[$key])]);
            }
        }
    }

    private static function slices(array $meta): array {
        return isset($meta['financial_slices']) && is_array($meta['financial_slices']) ? $meta['financial_slices'] : [];
    }

    private static function slice_sum(array $slices): float {
        $sum = 0.0;
        foreach ($slices as $slice) {
            if (is_array($slice)) {
                $sum += self::money($slice['amount'] ?? 0);
            }
        }
        return self::money($sum);
    }

    private static function edge_sum(array $edges): float {
        $sum = 0.0;
        foreach ($edges as $edge) {
            if (is_array($edge)) {
                $sum += self::money($edge['amount'] ?? 0);
            }
        }
        return self::money($sum);
    }

    private static function money($value): float {
        if (is_string($value)) {
            $value = str_replace([',',' '], '', $value);
        }
        return round((float) $value, 2);
    }

    private static function same(float $a, float $b): bool {
        return abs(self::money($a) - self::money($b)) <= self::EPSILON;
    }

    private static function fail(array &$v, string $code, string $message, array $context = []): void {
        $v[] = [
            'severity' => 'critical',
            'code' => $code,
            'message' => $message,
            'context' => $context,
        ];
    }

    private static function json($value): string {
        if (function_exists('wp_json_encode')) {
            return (string) wp_json_encode($value);
        }
        return (string) json_encode($value);
    }
}
