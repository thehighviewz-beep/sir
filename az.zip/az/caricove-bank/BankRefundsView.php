<?php
namespace Caricove\Bank;

if (!defined('ABSPATH')) exit;

final class BankRefundsView
{
    public static function render(): void
    {
        $rows      = BankRefundsTable::get_rows();
        $nonce     = wp_create_nonce('caricove_bank_refunds');
        $caseFocus = sanitize_text_field((string) ($_GET['case_id'] ?? ''));

        if ($caseFocus !== '') {
            $rows = array_values(array_filter($rows, static function ($row) use ($caseFocus) {
                return (string) ($row['case_id'] ?? '') === $caseFocus;
            }));
        }

        echo '<div class="cbank-refunds">';
        echo '<h2>CX Refund Requests</h2>';
        echo '<p class="description" style="max-width:980px">This is the execution layer. Fault resolution belongs in tickets; this drawer commits the customer refund.</p>';

        echo '<table class="widefat striped">';
        echo '<thead><tr>';
        echo '<th>Created</th><th>Case</th><th>Customer</th><th>Seller</th><th>Order</th><th>Shipment</th><th>Product</th><th>Case Mode</th><th>Fault</th><th>Item Refund</th><th>Shipping Refund</th><th>Total Customer</th><th>Internal Shipping</th><th>Status</th><th>Action</th>';
        echo '</tr></thead><tbody>';

        if (!$rows) {
            echo '<tr><td colspan="15">No refund requests.</td></tr>';
        }

        foreach ($rows as $row) {
            $case    = is_array($row['case'] ?? null) ? $row['case'] : [];
            $preview = \Caricove\Bank\BankRefunds::preview_refund($case);

            $created_at = !empty($row['created_at']) ? date('Y-m-d', (int) $row['created_at']) : '';
            $faultParty = (string) ($preview['shipping_liability_party'] ?? $case['shipping_liability_party'] ?? $case['resolved_fault_party'] ?? '');
            $faultLabel = $faultParty !== '' ? ucfirst($faultParty) : 'Unassigned';
            $executionMode = (string) ($preview['refund_execution_mode'] ?? $row['refund_execution_mode'] ?? '');
            $executionLabel = $executionMode !== '' ? str_replace('_', ' ', $executionMode) : 'return_required';
            $isActionable = !empty($row['actionable']);
            $preReturnShippingOnly = !empty($row['pre_return_shipping_only']);

            echo '<tr' . ($caseFocus !== '' ? ' class="cbank-row-focus"' : '') . '>';
            echo '<td>' . esc_html($created_at) . '</td>';
            echo '<td><code>' . esc_html((string) ($row['case_id'] ?? '')) . '</code></td>';
            echo '<td>' . esc_html((string) ($row['customer'] ?? '')) . '</td>';
            echo '<td>' . esc_html((string) ($row['seller'] ?? '')) . '</td>';
            echo '<td>#' . esc_html((string) ($row['order_id'] ?? '')) . '</td>';
            echo '<td>' . esc_html((string) ($row['shipment_id'] ?? '')) . '</td>';
            echo '<td>' . esc_html((string) ($row['product'] ?? '')) . '</td>';
            echo '<td>' . esc_html(ucwords($executionLabel)) . '</td>';
            echo '<td>' . esc_html($faultLabel) . '</td>';
            echo '<td>' . esc_html(number_format((float) ($preview['item_refund_amount_customer'] ?? 0), 2)) . '</td>';
            echo '<td>' . esc_html(number_format((float) ($preview['outbound_shipping_refund_amount_customer'] ?? 0), 2)) . '</td>';
            echo '<td><strong>' . esc_html(number_format((float) ($preview['customer_total_refund'] ?? 0), 2)) . '</strong></td>';
            echo '<td>' . esc_html($faultLabel . ' · ' . number_format((float) ($preview['shipping_liability_amount_internal'] ?? 0), 2)) . '</td>';
            echo '<td>' . esc_html((string) ($row['status'] ?? '')) . '</td>';
            echo '<td>';
            if ($isActionable) {
                echo '<button type="button" class="button button-primary refund-preview-btn"'
                    . ' data-case="' . esc_attr((string) ($row['case_id'] ?? '')) . '"'
                    . ' data-nonce="' . esc_attr($nonce) . '"'
                    . ' data-item-refund="' . esc_attr(number_format($preReturnShippingOnly ? 0.0 : (float) ($preview['item_refund_amount_customer'] ?? 0), 2, '.', '')) . '"'
                    . ' data-shipping-refund="' . esc_attr(number_format((float) ($preview['outbound_shipping_refund_amount_customer'] ?? 0), 2, '.', '')) . '"'
                    . ' data-liability-party="' . esc_attr($faultParty) . '"'
                    . ' data-refund-execution-mode="' . esc_attr($executionMode) . '"'
                    . ' data-return-required="' . esc_attr(!empty($case['return_required']) ? '1' : '0') . '"'
                   . ' data-item-received-flag="' . esc_attr(((int) ($case['qty_received'] ?? 0) > 0) ? '1' : '0') . '"'
                    . ' data-pre-return-shipping-only="' . esc_attr($preReturnShippingOnly ? '1' : '0') . '">' . esc_html($preReturnShippingOnly ? 'Refund Shipping' : 'Refund') . '</button>';
                echo ' <button type="button" class="button decline-btn" data-case="' . esc_attr((string) ($row['case_id'] ?? '')) . '" data-nonce="' . esc_attr($nonce) . '">Decline</button>';
            } else {
                echo '&mdash;';
            }
            echo '</td>';
            echo '</tr>';
        }

        echo '</tbody></table>';

        echo '<div id="cbank-refund-backdrop" class="cbank-refund-backdrop" hidden></div>';
        echo '<div id="cbank-refund-drawer" class="cbank-refund-drawer" hidden>';
        echo '<div class="cbank-refund-head"><h3>Execute Refund</h3><button type="button" class="button-link" id="cbank-refund-close">×</button></div>';
        echo '<div class="cbank-refund-grid">';
        echo '<input type="hidden" id="cbank-case-id" value="">';
        echo '<input type="hidden" id="cbank-case-nonce" value="">';
        echo '<input type="hidden" id="cbank-refund-mode" value="">';
echo '<input type="hidden" id="cbank-item-received-flag" value="0">';        echo '<input type="hidden" id="cbank-return-required" value="0">';
        echo '<input type="hidden" id="cbank-liability-party" value="">';
        echo '<input type="hidden" id="cbank-pre-return-shipping-only" value="0">';

        echo '<label>Item refund to customer<input type="number" step="0.01" min="0" id="cbank-item-refund" value="0"></label>';
        echo '<label>Outbound shipping refund to customer<input type="number" step="0.01" min="0" id="cbank-shipping-refund" value="0"></label>';
        echo '<div id="cbank-pre-return-note" class="cbank-pre-return-note" hidden>Item refund stays blocked until the return checkpoint is reached. This action will refund outbound shipping only.</div>';

        echo '</div>';
        echo '<div id="cbank-refund-summary" class="cbank-refund-summary"></div>';
        echo '<div class="cbank-refund-actions">';
        echo '<button type="button" class="button" id="cbank-refund-cancel">Cancel</button>';
        echo '<button type="button" class="button button-primary" id="cbank-refund-confirm">Commit refund</button>';
        echo '</div>';
        echo '</div>';

        self::script();

        echo '<style>
        .cbank-refunds{position:relative}
        .cbank-row-focus{box-shadow:inset 0 0 0 9999px rgba(0,115,170,.08)}
        .cbank-refund-backdrop{position:fixed;inset:0;background:rgba(0,0,0,.3);z-index:9998}
        .cbank-refund-drawer{position:fixed;top:4vh;right:24px;width:min(620px,calc(100vw - 48px));max-height:92vh;overflow:auto;background:#fff;border:1px solid #d6dbe6;border-radius:16px;padding:18px;z-index:9999;box-shadow:0 25px 80px rgba(0,0,0,.22)}
        .cbank-refund-head{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:14px}
        .cbank-refund-head h3{margin:0}
        .cbank-refund-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}
        .cbank-refund-grid label{display:flex;flex-direction:column;gap:6px;font-weight:600}
        .cbank-refund-grid input,.cbank-refund-grid select,.cbank-refund-grid textarea{width:100%}
        .cbank-refund-summary{margin-top:14px;padding:12px;border-radius:12px;background:#f6f8fb;border:1px solid #dce3ef}
        .cbank-refund-summary .row{display:flex;justify-content:space-between;gap:16px;padding:6px 0;border-bottom:1px solid #e8edf5}
        .cbank-refund-summary .row:last-child{border-bottom:none}
        .cbank-refund-actions{display:flex;justify-content:flex-end;gap:10px;margin-top:14px}
        .cbank-pre-return-note{grid-column:1/-1;padding:10px 12px;border-radius:10px;background:#fff7da;border:1px solid #f0d98a;color:#6b5600;font-weight:600}
        </style>';
        echo '</div>';
    }

    private static function script(): void
    {
?>
<script>
document.addEventListener("DOMContentLoaded", function () {
    const ajax = window.ajaxurl || "<?php echo esc_js(admin_url('admin-ajax.php')); ?>";
    const drawer = document.getElementById('cbank-refund-drawer');
    const backdrop = document.getElementById('cbank-refund-backdrop');
    const closeBtn = document.getElementById('cbank-refund-close');
    const cancelBtn = document.getElementById('cbank-refund-cancel');
    const confirmBtn = document.getElementById('cbank-refund-confirm');
    const caseIdEl = document.getElementById('cbank-case-id');
    const nonceEl = document.getElementById('cbank-case-nonce');
    const itemRefundEl = document.getElementById('cbank-item-refund');
    const shippingRefundEl = document.getElementById('cbank-shipping-refund');
    const liabilityEl = document.getElementById('cbank-liability-party');
    const summaryEl = document.getElementById('cbank-refund-summary');
    const modeEl = document.getElementById('cbank-refund-mode');
    const itemReceivedEl = document.getElementById('cbank-item-received-flag');
    const returnRequiredEl = document.getElementById('cbank-return-required');
    const preReturnShippingOnlyEl = document.getElementById('cbank-pre-return-shipping-only');
    const preReturnNoteEl = document.getElementById('cbank-pre-return-note');

    function openDrawer() {
        drawer.hidden = false;
        backdrop.hidden = false;
    }

    function closeDrawer() {
        drawer.hidden = true;
        backdrop.hidden = true;
    }

    function money(v) {
        const n = Number(v || 0);
        return n.toFixed(2);
    }

    function applyPreReturnShippingOnlyMode(enabled) {
        preReturnShippingOnlyEl.value = enabled ? '1' : '0';
        itemRefundEl.disabled = !!enabled;
        if (enabled) {
            itemRefundEl.value = '0.00';
            confirmBtn.textContent = 'Commit shipping refund';
            if (preReturnNoteEl) preReturnNoteEl.hidden = false;
        } else {
            confirmBtn.textContent = 'Commit refund';
            if (preReturnNoteEl) preReturnNoteEl.hidden = true;
        }
    }

    function renderSummary(d) {
        summaryEl.innerHTML = [
            ['Case mode', String(d.refund_execution_mode || '').replaceAll('_', ' ') || 'return_required'],
            ['Physical return', Number(d.return_required || 0) ? 'Required' : 'No physical return'],
            ['Item received', Number(d.item_received_flag || 0) ? 'Yes' : 'No'],
            ['Item refund', money(d.item_refund_amount_customer || 0)],
            ['Shipping refund', money(d.outbound_shipping_refund_amount_customer || 0)],
            ['Customer total back', money(d.customer_total_refund || 0)],
            ['Shipping liability', (d.shipping_liability_party || 'none') + ' · ' + money(d.shipping_liability_amount_internal || 0)],
            ['Seller outcome', (d.seller_outcome_label || 'Seller impact') + ' · ' + money(d.seller_outcome_amount || 0)],
            ['Seller Debit Exposure', money(d.seller_debit_exposure_amount || 0)],
            ['Courier shipping impact', money(d.courier_shipping_impact || 0)],
            ['Platform margin removed', money(d.caricove_pays_now || 0)]
        ].map(function (row) {
            return '<div class="row"><span>' + row[0] + '</span><strong>' + row[1] + '</strong></div>';
        }).join('');
    }

    async function refreshPreview() {
        if (!caseIdEl.value || !nonceEl.value) return;

        const body = new URLSearchParams({
            action: 'caricove_bank_refund_preview',
            nonce: nonceEl.value,
            case_id: caseIdEl.value,
            item_refund_amount_customer: money(preReturnShippingOnlyEl.value === '1' ? 0 : itemRefundEl.value),
            outbound_shipping_refund_amount_customer: money(shippingRefundEl.value),
            shipping_liability_party: liabilityEl.value,
            refund_execution_mode: modeEl.value,
            item_received_flag: itemReceivedEl.value,
            shipping_refund_selected: Number(shippingRefundEl.value || 0) > 0 ? '1' : '0'
        });

        const res = await fetch(ajax, {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'},
            body
        });

        const raw = await res.text();
        let payload;
        try { payload = JSON.parse(raw); } catch (e) { throw new Error(raw.substring(0, 500)); }

        if (!payload.success) {
            throw new Error((payload.data && payload.data.message) ? payload.data.message : 'Preview failed');
        }

        if (payload.data && Number(payload.data.pre_return_shipping_only || 0)) {
            applyPreReturnShippingOnlyMode(true);
            itemRefundEl.value = '0.00';
        }
        renderSummary(payload.data || {});
    }

    document.addEventListener('click', function (e) {
        const openBtn = e.target.closest('.refund-preview-btn');
        if (openBtn) {
            caseIdEl.value = openBtn.dataset.case || '';
            nonceEl.value = openBtn.dataset.nonce || '';
            itemRefundEl.value = openBtn.dataset.itemRefund || '0.00';
            shippingRefundEl.value = openBtn.dataset.shippingRefund || '0.00';
            liabilityEl.value = openBtn.dataset.liabilityParty || '';
            modeEl.value = openBtn.dataset.refundExecutionMode || '';
            itemReceivedEl.value = openBtn.dataset.itemReceivedFlag || '1';
            returnRequiredEl.value = openBtn.dataset.returnRequired || '0';
            applyPreReturnShippingOnlyMode((openBtn.dataset.preReturnShippingOnly || '0') === '1');

            renderSummary({
                item_refund_amount_customer: itemRefundEl.value,
                outbound_shipping_refund_amount_customer: shippingRefundEl.value,
                customer_total_refund: Number((preReturnShippingOnlyEl.value === '1' ? 0 : itemRefundEl.value) || 0) + Number(shippingRefundEl.value || 0),
                shipping_liability_party: liabilityEl.value,
                shipping_liability_amount_internal: shippingRefundEl.value,
                refund_execution_mode: modeEl.value,
                item_received_flag: itemReceivedEl.value,
                return_required: returnRequiredEl.value,
                seller_outcome_label: 'Preview loading…',
                seller_outcome_amount: 0,
                seller_debit_exposure_amount: 0,
                courier_shipping_impact: liabilityEl.value === 'carrier' ? shippingRefundEl.value : 0,
                caricove_pays_now: 0
            });

            openDrawer();

            refreshPreview().catch(function (err) {
                summaryEl.innerHTML = '<div class="row"><span>Preview error</span><strong>' + String(err.message || err) + '</strong></div>';
            });
            return;
        }

        const declineBtn = e.target.closest('.decline-btn');
        if (declineBtn) {
            if (!window.confirm('Decline this refund request?')) return;

            fetch(ajax, {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'},
                body: new URLSearchParams({
                    action: 'caricove_bank_refund_decline',
                    case_id: declineBtn.dataset.case || '',
                    nonce: declineBtn.dataset.nonce || ''
                })
            }).then(function (r) {
                return r.text();
            }).then(function (raw) {
                let payload;
                try { payload = JSON.parse(raw); } catch (e) { throw new Error(raw.substring(0, 500)); }
                if (!payload.success) {
                    throw new Error((payload.data && payload.data.message) ? payload.data.message : 'Decline failed');
                }
                window.location.reload();
            }).catch(function (err) {
                alert(String(err.message || err));
            });
        }
    });

    [itemRefundEl, shippingRefundEl].forEach(function (el) {
        el.addEventListener('input', function () {
            refreshPreview().catch(function (err) {
                summaryEl.innerHTML = '<div class="row"><span>Preview error</span><strong>' + String(err.message || err) + '</strong></div>';
            });
        });
        el.addEventListener('change', function () {
            refreshPreview().catch(function (err) {
                summaryEl.innerHTML = '<div class="row"><span>Preview error</span><strong>' + String(err.message || err) + '</strong></div>';
            });
        });
    });

    [closeBtn, cancelBtn, backdrop].forEach(function (el) {
        el.addEventListener('click', function () {
            closeDrawer();
        });
    });

    confirmBtn.addEventListener('click', async function () {
        if (!caseIdEl.value || !nonceEl.value) {
            alert('Missing refund case context.');
            return;
        }

        const body = new URLSearchParams({
            action: 'caricove_bank_refund_commit',
            nonce: nonceEl.value,
            case_id: caseIdEl.value,
            item_refund_amount_customer: money(preReturnShippingOnlyEl.value === '1' ? 0 : itemRefundEl.value),
            outbound_shipping_refund_amount_customer: money(shippingRefundEl.value),
            shipping_liability_party: liabilityEl.value,
            refund_execution_mode: modeEl.value,
            item_received_flag: itemReceivedEl.value,
            shipping_refund_selected: Number(shippingRefundEl.value || 0) > 0 ? '1' : '0'
        });

        try {
            const res = await fetch(ajax, {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'},
                body
            });

            const raw = await res.text();
            let payload;
            try { payload = JSON.parse(raw); } catch (e) { throw new Error(raw.substring(0, 500)); }

            if (!payload.success) {
                throw new Error((payload.data && payload.data.message) ? payload.data.message : 'Refund failed');
            }

            closeDrawer();
            window.location.reload();
        } catch (err) {
            alert(String(err.message || err));
        }
    });

    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') closeDrawer();
    });
});
</script>
<?php
    }
}


