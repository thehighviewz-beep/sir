<?php
namespace Caricove\Bank;
if (!defined('ABSPATH')) exit;

final class BankEvents {
    public const TYPES = [
        'order_payment_captured',
        'shipment_earnings_created',
        'shipment_funds_cleared',
        'customer_refund_issued',
        'seller_deduction_created',
        'courier_payout_created',
        'return_shipping_charge',
        'vendor_withdrawal_requested',
        'vendor_withdrawal_paid',
        'manual_adjustment',
        'platform_loss_booked',
        'reversal',
        'refund_financial_rollback',
        'seller_offset_reopened_by_refund',
        'seller_funds_available',
        'seller_payout_requested',
        'seller_payout_approved',
        'seller_payout_queued',
        'seller_payout_completed',
        'seller_debit_offset_applied',
        'seller_payout_sent',
        'vendor_liability_recovered',
    ];

    public const STATUSES = ['pending', 'posted', 'reversed', 'failed'];
    public const DIRECTIONS = ['credit', 'debit'];
    public const ENTITY_TYPES = ['platform', 'vendor', 'courier', 'customer', 'bank'];

    public static function is_valid_type(string $type): bool {
        return in_array($type, self::TYPES, true);
    }
}
