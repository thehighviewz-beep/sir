<?php
namespace Caricove\Bank;

if (!defined('ABSPATH')) exit;

/**
 * Caricove Bank Payment Rails — Phase 2C-GY
 *
 * Guyana-first payment rail decision layer.
 * This class stores/readiness-checks rails only. It never charges, refunds,
 * transfers, pays out, withdraws, or marks money as provider-confirmed.
 */
final class BankPaymentRails
{
    public const OPTION = 'caricove_bank_payment_rails_v1';
    public const ACTION_SAVE = 'caricove_bank_payment_rails_save';
    public const NONCE_SAVE = 'caricove_bank_payment_rails_save';

    public static function boot(): void
    {
        add_action('admin_post_' . self::ACTION_SAVE, [__CLASS__, 'handle_save']);
    }

    public static function can_manage(): bool
    {
        return current_user_can('manage_woocommerce') || current_user_can('manage_options');
    }

    public static function settings(): array
    {
        $saved = get_option(self::OPTION, []);
        if (!is_array($saved)) {
            $saved = [];
        }

        $settings = wp_parse_args($saved, self::defaults());
        $choices = self::choices();

        foreach ($choices as $key => $allowed) {
            $value = sanitize_key((string) ($settings[$key] ?? self::defaults()[$key] ?? ''));
            if (!array_key_exists($value, $allowed)) {
                $value = (string) (self::defaults()[$key] ?? array_key_first($allowed));
            }
            $settings[$key] = $value;
        }

        $settings['notes'] = sanitize_textarea_field((string) ($settings['notes'] ?? ''));
        $settings['updated_at'] = sanitize_text_field((string) ($settings['updated_at'] ?? 'Never'));
        $settings['updated_by'] = max(0, (int) ($settings['updated_by'] ?? 0));
        $settings['schema'] = '2C-GY.1';
        $settings['money_movement_enabled'] = false;
        $settings['cod_enabled'] = false;

        return $settings;
    }

    public static function defaults(): array
    {
        return [
            'primary_checkout_rail' => 'mmg',
            'secondary_checkout_rail' => 'card_gateway',
            'card_gateway_candidate' => 'not_selected',
            'mmg_status' => 'not_contacted',
            'card_gateway_status' => 'not_contacted',
            'manual_bank_status' => 'hidden_fallback',
            'customer_trust_badge' => 'protected_checkout',
            'seller_payout_identity' => 'later',
            'courier_payout_identity' => 'later',
            'owner_takeout_identity' => 'later',
            'provider_proof_mode' => 'webhook_or_api_required',
            'manual_bank_visibility' => 'hidden_admin_fallback',
            'notes' => '',
            'updated_at' => 'Never',
            'updated_by' => 0,
        ];
    }

    public static function choices(): array
    {
        return [
            'primary_checkout_rail' => [
                'mmg' => 'MMG Checkout',
                'card_gateway' => 'Card Gateway',
                'manual_bank' => 'Manual bank fallback',
                'not_selected' => 'Not selected',
            ],
            'secondary_checkout_rail' => [
                'card_gateway' => 'Card Gateway',
                'mmg' => 'MMG Checkout',
                'manual_bank' => 'Manual bank fallback',
                'not_selected' => 'Not selected',
            ],
            'card_gateway_candidate' => [
                'not_selected' => 'Not selected yet',
                'wipay' => 'WiPay',
                'republic_epay' => 'Republic EPay / local bank e-commerce',
                'scotia_ecom' => 'Scotia eCom+ / local bank e-commerce',
                'mpgs' => 'MPGS / Mastercard Payment Gateway Services',
                'nmi' => 'NMI-backed gateway',
                'cybersource' => 'CyberSource-backed gateway',
                'knitpay_supported_gateway' => 'KnitPay-supported gateway',
                'custom_api' => 'Custom API adapter',
            ],
            'mmg_status' => self::provider_status_choices(),
            'card_gateway_status' => self::provider_status_choices(),
            'manual_bank_status' => [
                'hidden_fallback' => 'Hidden fallback only',
                'admin_only' => 'Admin-only special case',
                'off' => 'Off',
            ],
            'customer_trust_badge' => [
                'protected_checkout' => 'Caricove Protected Checkout',
                'local_fast_pay' => 'Local Fast Pay',
                'none' => 'No badge yet',
            ],
            'seller_payout_identity' => [
                'later' => 'Later phase',
                'mmg_or_bank' => 'MMG or bank profile later',
                'bank_only' => 'Bank payout profile later',
                'manual_only' => 'Manual payout profile later',
            ],
            'courier_payout_identity' => [
                'later' => 'Later phase',
                'mmg_or_bank' => 'MMG or bank profile later',
                'bank_only' => 'Bank payout profile later',
                'manual_only' => 'Manual payout profile later',
            ],
            'owner_takeout_identity' => [
                'later' => 'Later phase',
                'bank_owner_profile' => 'Owner bank profile later',
                'manual_owner_profile' => 'Manual owner profile later',
            ],
            'provider_proof_mode' => [
                'webhook_or_api_required' => 'Webhook/API confirmation required',
                'manual_admin_proof_only' => 'Manual admin proof only',
            ],
            'manual_bank_visibility' => [
                'hidden_admin_fallback' => 'Hidden/admin fallback only',
                'business_orders_only' => 'Business/high-value orders only',
                'off' => 'Off',
            ],
        ];
    }

    public static function provider_status_choices(): array
    {
        return [
            'not_contacted' => 'Not contacted',
            'pricing_requested' => 'Pricing requested',
            'applied' => 'Applied',
            'waiting_credentials' => 'Waiting credentials',
            'sandbox_credentials' => 'Sandbox/test credentials received',
            'live_credentials' => 'Live credentials received',
            'blocked' => 'Blocked / not viable',
        ];
    }

    public static function handle_save(): void
    {
        if (!self::can_manage()) {
            wp_die(esc_html__('You do not have permission to update payment rails.', 'caricove'));
        }

        check_admin_referer(self::NONCE_SAVE);

        $choices = self::choices();
        $next = self::defaults();
        foreach ($choices as $key => $allowed) {
            $raw = isset($_POST[$key]) ? sanitize_key((string) wp_unslash($_POST[$key])) : (string) ($next[$key] ?? '');
            $next[$key] = array_key_exists($raw, $allowed) ? $raw : (string) ($next[$key] ?? array_key_first($allowed));
        }

        $next['notes'] = isset($_POST['notes']) ? sanitize_textarea_field(wp_unslash((string) $_POST['notes'])) : '';
        $next['updated_at'] = current_time('mysql');
        $next['updated_by'] = get_current_user_id();
        $next['schema'] = '2C-GY.1';
        $next['money_movement_enabled'] = false;
        $next['cod_enabled'] = false;

        update_option(self::OPTION, $next, false);

        wp_safe_redirect(add_query_arg([
            'page' => 'caricove-bank',
            'tab' => 'guyana_rails',
            'rails_saved' => '1',
        ], admin_url('admin.php')));
        exit;
    }

    public static function checkout_order(): array
    {
        $settings = self::settings();
        $choices = self::choices();
        $candidate = (string) ($settings['card_gateway_candidate'] ?? 'not_selected');
        $candidate_label = (string) ($choices['card_gateway_candidate'][$candidate] ?? 'Card Gateway');

        return [
            [
                'rank' => 'Recommended first',
                'rail' => 'MMG Checkout',
                'status' => self::status_label((string) $settings['mmg_status']),
                'customer_label' => 'Pay with MMG',
                'why' => 'Local, familiar, fast, and better aligned to Guyana customer trust than a strange card-only checkout.',
                'money_rule' => 'Order may proceed only after MMG callback/API proof is verified.',
            ],
            [
                'rank' => 'Second / card convenience',
                'rail' => $candidate_label,
                'status' => self::status_label((string) $settings['card_gateway_status']),
                'customer_label' => 'Pay by Card',
                'why' => 'Keeps checkout friction low for customers who expect Visa/Mastercard or online card payment.',
                'money_rule' => 'Order may proceed only after gateway confirmation/webhook/API proof is verified.',
            ],
            [
                'rank' => 'Hidden fallback',
                'rail' => 'Manual bank transfer',
                'status' => self::label_for('manual_bank_status', (string) $settings['manual_bank_status']),
                'customer_label' => 'Manual payment',
                'why' => 'Not main checkout. Keep it hidden for business/high-value/special support cases so normal checkout stays fast.',
                'money_rule' => 'Admin proof required before any ledger split unlocks.',
            ],
            [
                'rank' => 'Removed',
                'rail' => 'Cash on Delivery',
                'status' => 'Disabled',
                'customer_label' => 'Not shown',
                'why' => 'COD is out of doctrine for this build.',
                'money_rule' => 'No COD order-confirmation path.',
            ],
        ];
    }

    public static function payout_identity_plan(): array
    {
        $settings = self::settings();
        return [
            [
                'party' => 'Customer / CX',
                'profile' => 'No Caricove wallet. Store provider payment IDs only.',
                'current_phase' => 'Later: checkout provider adapter stores payment/refund IDs on the order.',
                'hard_rule' => 'Do not store raw card/bank data in WordPress.',
            ],
            [
                'party' => 'Seller',
                'profile' => self::label_for('seller_payout_identity', (string) $settings['seller_payout_identity']),
                'current_phase' => 'Later: seller payout identity/profile only, then provider payout proof.',
                'hard_rule' => 'Seller funds are never platform spendable.',
            ],
            [
                'party' => 'Courier',
                'profile' => self::label_for('courier_payout_identity', (string) $settings['courier_payout_identity']),
                'current_phase' => 'Later: courier payout identity/profile only, with same-courier debt offset first.',
                'hard_rule' => 'Courier #35 debt can only offset courier #35 funds.',
            ],
            [
                'party' => 'Platform Owner',
                'profile' => self::label_for('owner_takeout_identity', (string) $settings['owner_takeout_identity']),
                'current_phase' => 'Later: owner takeout profile after provider balance mirror and proof inbox are stable.',
                'hard_rule' => 'Owner takeout is the lower of internal safe revenue and provider available cash, after reserves.',
            ],
        ];
    }

    public static function readiness_rows(): array
    {
        $settings = self::settings();
        $mmg_ready = in_array((string) $settings['mmg_status'], ['sandbox_credentials', 'live_credentials'], true);
        $card_ready = in_array((string) $settings['card_gateway_status'], ['sandbox_credentials', 'live_credentials'], true)
            && (string) $settings['card_gateway_candidate'] !== 'not_selected';
        $manual_hidden = in_array((string) $settings['manual_bank_visibility'], ['hidden_admin_fallback', 'business_orders_only', 'off'], true)
            && (string) $settings['manual_bank_status'] !== 'admin_only';

        return [
            [
                'gate' => 'Primary Guyana checkout rail',
                'status' => $mmg_ready ? 'Ready for adapter build' : 'Not ready',
                'class' => $mmg_ready ? 'good' : 'warn',
                'meaning' => $mmg_ready ? 'MMG credentials/status look ready for adapter work.' : 'MMG is still a business/provider setup task before checkout wiring.',
            ],
            [
                'gate' => 'Card gateway candidate',
                'status' => $card_ready ? 'Ready for adapter build' : 'Pending decision',
                'class' => $card_ready ? 'good' : 'warn',
                'meaning' => $card_ready ? 'A card gateway candidate and credential status are selected.' : 'Choose/pricing-check WiPay, Republic/Scotia, MPGS/NMI/CyberSource, KnitPay-supported gateway, or custom API.',
            ],
            [
                'gate' => 'Manual bank friction',
                'status' => $manual_hidden ? 'Controlled' : 'Review',
                'class' => $manual_hidden ? 'good' : 'warn',
                'meaning' => 'Manual bank must not become the main checkout rail. It stays hidden/fallback/business-only.',
            ],
            [
                'gate' => 'COD doctrine',
                'status' => 'Disabled',
                'class' => 'good',
                'meaning' => 'Cash on delivery is removed from the payment roadmap.',
            ],
            [
                'gate' => 'Provider proof',
                'status' => self::label_for('provider_proof_mode', (string) $settings['provider_proof_mode']),
                'class' => 'warn',
                'meaning' => 'No order/payment split should unlock until provider callback/webhook/API or admin proof is recorded.',
            ],
            [
                'gate' => 'Money movement',
                'status' => 'Locked',
                'class' => 'bad',
                'meaning' => 'This phase does not charge, refund, pay sellers/couriers, or allow owner withdrawals.',
            ],
        ];
    }

    public static function callback_reference(): array
    {
        return [
            [
                'provider' => 'MMG Checkout',
                'url' => rest_url('caricove-bank/v1/mmg/callback'),
                'status' => 'Reserved / adapter not active',
                'rule' => 'Only enable after MMG gives official callback/signature/API requirements.',
            ],
            [
                'provider' => 'Card Gateway / WiPay / Bank Gateway',
                'url' => rest_url('caricove-bank/v1/card-gateway/webhook'),
                'status' => 'Reserved / adapter not active',
                'rule' => 'Only enable after chosen gateway proof/signature requirements are known.',
            ],
            [
                'provider' => 'Manual bank fallback',
                'url' => admin_url('admin.php?page=caricove-bank&tab=provider_events'),
                'status' => 'Admin proof only',
                'rule' => 'Manual proof should be rare and never the main checkout path.',
            ],
            [
                'provider' => 'Stripe dev/test rail',
                'url' => class_exists(__NAMESPACE__ . '\BankProviderEvents') ? BankProviderEvents::webhook_url('stripe') : rest_url('caricove-bank/v1/stripe/webhook'),
                'status' => 'Existing test/dev inbox',
                'rule' => 'Keep for testing/future compliant entities, not Guyana-live assumption.',
            ],
        ];
    }

    public static function provider_questions(): array
    {
        return [
            'Exact online merchant fee, including setup, monthly, settlement, chargeback, refund, and withdrawal fees.',
            'Whether WooCommerce is supported directly or through MPGS, NMI, CyberSource, KnitPay, hosted checkout, or custom API.',
            'Whether sandbox/test credentials are available before live approval.',
            'Whether provider sends callbacks/webhooks and how signatures are verified.',
            'Whether Caricove can verify payment status by API using order/reference IDs.',
            'Whether refunds are possible by API and how refund status is confirmed.',
            'Settlement timing, currency, bank deposit rules, and whether held/withheld funds are reported.',
        ];
    }

    public static function label_for(string $field, string $value): string
    {
        $choices = self::choices();
        return (string) ($choices[$field][$value] ?? $value);
    }

    public static function status_label(string $value): string
    {
        return (string) (self::provider_status_choices()[$value] ?? $value);
    }

    public static function status_class(string $value): string
    {
        if (in_array($value, ['sandbox_credentials', 'live_credentials'], true)) {
            return 'good';
        }
        if ($value === 'blocked') {
            return 'bad';
        }
        return 'warn';
    }
}
