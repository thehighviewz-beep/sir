<?php
namespace Caricove\Bank;

if (!defined('ABSPATH')) exit;

final class BankRefundsTable
{
    private static function has_explicit_fault_verdict(array $case, array $preview = []): bool
    {
        $resolved_party = sanitize_key((string) ($preview['resolved_fault_party'] ?? $case['resolved_fault_party'] ?? ''));
        if (in_array($resolved_party, ['seller', 'carrier'], true)) {
            return true;
        }

        $resolution_status = sanitize_key((string) ($preview['fault_resolution_status'] ?? $case['fault_resolution_status'] ?? ''));
        if ($resolution_status === 'resolved') {
            $shipping_party = sanitize_key((string) ($preview['shipping_liability_party'] ?? $case['shipping_liability_party'] ?? ''));
            return in_array($shipping_party, ['seller', 'carrier'], true);
        }

        return false;
    }

    public static function get_rows(array $filters = []): array
    {
        $cases = BankRefundCases::list_cases($filters);
        $rows  = [];

        foreach ((array) $cases as $case) {
            if (!is_array($case) || empty($case['case_id'])) {
                continue;
            }

            $status    = sanitize_key((string) ($case['status'] ?? 'requested'));
            $case_type = sanitize_key((string) ($case['case_type'] ?? 'return'));
            if (in_array($status, ['refunded', 'declined', 'closed', 'cancelled', 'cancelled_partial', 'completed'], true)) {
                continue;
            }
            if ($case_type === 'cancellation') {
                continue;
            }

           $preview = BankRefunds::preview_refund($case);
            $fault_party = self::resolve_fault_party_for_row($case, $preview);

            // Carrier-liable cases belong only in Platform Fronted / Courier Recovery,
            // not in the normal CX Refund Requests execution table.
            if ($fault_party === 'carrier') {
                continue;
            }

            $rows[]  = self::build_row($case, $preview);
        }

        return self::sort_rows_fifo($rows);
    }

    private static function build_row(array $case, array $preview): array
    {
        $mode            = (string) ($preview['refund_execution_mode'] ?? ($case['refund_execution_mode'] ?? ''));
$return_required = !empty($case['return_required']);
$qty_received    = (int) ($case['qty_received'] ?? 0);

/*
 * For shipping-first pre-return flow, do NOT let preview drift mark the case
 * as item-received. Only stored receipt truth / qty_received should count here.
 */
$item_received   = ($qty_received > 0) || !empty($case['item_received_flag']);

$financial_done  = (string) ($case['financial_status'] ?? '') === 'completed'
    && (float) ($case['refund_amount_approved'] ?? 0) > 0;

$shipping_preview_amount = (float) ($preview['outbound_shipping_refund_amount_customer'] ?? 0);
$shipping_posted         = trim((string) ($case['shipping_refund_posting_key'] ?? '')) !== '';

$pre_return_shipping_only = (
    $return_required
    && $mode !== 'never_received'
    && !$item_received
    && $qty_received <= 0
    && !$shipping_posted
    && $shipping_preview_amount > 0
);

$actionable = !$financial_done;
if ($return_required && $mode !== 'never_received' && !$item_received && $qty_received <= 0) {
    $actionable = $pre_return_shipping_only;
}

$has_fault_verdict = self::has_explicit_fault_verdict($case, $preview);
if ($mode === 'never_received' && !$has_fault_verdict) {
    $actionable = false;
}

        $fault_party = self::resolve_fault_party_for_row($case, $preview);
        $fault_label = self::resolve_fault_label_for_row($fault_party);

        if ($fault_party !== 'seller') {
            $pre_return_shipping_only = false;
            if ($return_required && $mode !== 'never_received' && !$item_received && $qty_received <= 0) {
                $actionable = false;
            }
        }

        $status_label = (string) ($case['status'] ?? 'requested');
        if ($mode === 'never_received') {
            $status_label = $has_fault_verdict ? 'investigated / no return' : 'awaiting fault verdict / no return';
        } elseif (!$return_required) {
            $status_label = 'returnless / admin refund';
        } elseif ($qty_received > 0) {
            $status_label = 'received';
        } elseif ($return_required) {
            $status_label = 'awaiting return';
        }

        $order_id    = (int) ($case['order_id'] ?? 0);
        $shipment_id = (int) ($case['shipment_id'] ?? 0);
        $customer_id = (int) ($case['customer_id'] ?? 0);

        $customer_name = '';
        if ($customer_id > 0) {
            $user = get_user_by('id', $customer_id);
            if ($user) {
                $customer_name = (string) $user->display_name;
            }
        }

        return [
            'case_id'        => (string) ($case['case_id'] ?? ''),
            'created_at'     => (int) ($case['created_at'] ?? 0),
            'customer'       => $customer_name,
            'seller'         => self::resolve_storefront_name($case),
            'order_id'       => $order_id,
            'shipment_id'    => self::resolve_shipment_number($case),
            'product'        => self::resolve_product_name($case),
            'reason'         => (string) ($case['reason_text'] ?: $case['reason_code']),
            'qty_requested'  => (int) ($case['qty_requested'] ?? 0),
            'qty_received'   => $qty_received,
            'item_refund_amount_customer' => (float) ($preview['item_refund_amount_customer'] ?? $preview['refund_amount'] ?? 0),
            'outbound_shipping_refund_amount_customer' => (float) ($preview['outbound_shipping_refund_amount_customer'] ?? 0),
            'customer_total_refund' => (float) ($preview['customer_total_refund'] ?? $preview['customer_gets_back'] ?? 0),
            'seller_impact'  => (float) ($preview['seller_outcome_amount'] ?? 0),
            'shipping_liability_party' => (string) ($preview['shipping_liability_party'] ?? ''),
            'shipping_liability_amount_internal' => (float) ($preview['shipping_liability_amount_internal'] ?? 0),
            'refund_execution_mode' => $mode,
            'return_required' => $return_required ? 1 : 0,
            'item_received_flag' => $item_received ? 1 : 0,
            'mode'           => (string) ($preview['mode'] ?? 'debit'),
            'fault_party'    => $fault_party,
            'fault_label'    => $fault_label,
            'status'         => $status_label,
            'actionable'     => $actionable ? 1 : 0,
            'pre_return_shipping_only' => $pre_return_shipping_only ? 1 : 0,
            'case'           => $case,
        ];
    }


    private static function resolve_fault_party_for_row(array $case, array $preview): string
    {
        $mode = (string) ($preview['refund_execution_mode'] ?? $case['refund_execution_mode'] ?? '');
        if ($mode === 'never_received' && !self::has_explicit_fault_verdict($case, $preview)) {
            return '';
        }

        foreach (['resolved_fault_party', 'shipping_liability_party', 'initial_fault', 'fault', 'shipping_payer'] as $key) {
            $party = sanitize_key((string) ($preview[$key] ?? $case[$key] ?? ''));
            if (in_array($party, ['seller', 'carrier', 'customer'], true)) {
                return $party;
            }
            if (in_array($party, ['vendor', 'merchant'], true)) {
                return 'seller';
            }
            if (in_array($party, ['courier', 'shipping', 'logistics'], true)) {
                return 'carrier';
            }
            if (in_array($party, ['buyer', 'user', 'cx', 'none', 'clear'], true)) {
                return 'customer';
            }
        }
        return 'customer';
    }

    private static function resolve_fault_label_for_row(string $party): string
    {
        if ($party === 'seller') {
            return 'Seller';
        }
        if ($party === 'carrier') {
            return 'Carrier';
        }
        if ($party === '') {
            return 'Awaiting verdict';
        }
        return 'CX fault';
    }

    private static function sort_rows_fifo(array $rows): array
    {
        usort($rows, static function ($a, $b) {
            return ($a['created_at'] ?? 0) <=> ($b['created_at'] ?? 0);
        });

        return $rows;
    }

    public static function search(array $rows, string $term): array
    {
        $term = strtolower(trim($term));
        if ($term === '') return $rows;

        return array_values(array_filter($rows, static function ($row) use ($term) {
            $hay = strtolower(implode(' ', [
                (string) ($row['case_id'] ?? ''),
                (string) ($row['customer'] ?? ''),
                (string) ($row['seller'] ?? ''),
                (string) ($row['product'] ?? ''),
                (string) ($row['reason'] ?? ''),
                (string) ($row['shipment_id'] ?? ''),
                (string) ($row['order_id'] ?? ''),
            ]));
            return strpos($hay, $term) !== false;
        }));
    }

    private static function resolve_storefront_name(array $case): string
    {
        $vendor_id = (int) ($case['vendor_id'] ?? 0);

        if ($vendor_id > 0) {
            $store_name = '';
            if (function_exists('dokan_get_store_info')) {
                $store = dokan_get_store_info($vendor_id);
                if (is_array($store)) {
                    $store_name = trim((string) ($store['store_name'] ?? ''));
                }
            }
            if ($store_name !== '') {
                return $store_name;
            }
            $user = get_user_by('id', $vendor_id);
            if ($user) {
                return (string) $user->display_name;
            }
        }

        return '';
    }

    private static function resolve_product_name(array $case): string
    {
        $product_id    = (int) ($case['product_id'] ?? 0);
        $order_id      = (int) ($case['order_id'] ?? 0);
        $order_item_id = (int) ($case['order_item_id'] ?? 0);

        if ($product_id > 0 && function_exists('wc_get_product')) {
            $product = wc_get_product($product_id);
            if ($product) {
                $name = trim((string) $product->get_name());
                if ($name !== '') {
                    return $name;
                }
            }
        }

        if ($order_id > 0 && $order_item_id > 0 && function_exists('wc_get_order')) {
            $order = wc_get_order($order_id);
            if ($order) {
                $item = $order->get_item($order_item_id);
                if ($item && method_exists($item, 'get_name')) {
                    $name = trim((string) $item->get_name());
                    if ($name !== '') {
                        return $name;
                    }
                }
            }
        }

        return '';
    }

    private static function resolve_shipment_number(array $case): string
    {
        $shipment_id = (int) ($case['shipment_id'] ?? 0);
        if ($shipment_id > 0) {
            return (string) $shipment_id;
        }

        $order_id      = (int) ($case['order_id'] ?? 0);
        $order_item_id = (int) ($case['order_item_id'] ?? 0);
        $product_id    = (int) ($case['product_id'] ?? 0);

        if ($order_id > 0 && $order_item_id > 0) {
            $sid = (int) wc_get_order_item_meta($order_item_id, '_cc_item_shipment_id', true);
            if ($sid > 0) {
                return (string) $sid;
            }
        }

        if ($order_id > 0 && function_exists('wc_get_order')) {
            $order = wc_get_order($order_id);
            if ($order) {
                foreach ($order->get_items() as $item_id => $item) {
                    if ($order_item_id > 0 && (int) $item_id !== $order_item_id) {
                        continue;
                    }
                    if ($product_id > 0 && (int) $item->get_product_id() !== $product_id) {
                        continue;
                    }
                    $sid = (int) wc_get_order_item_meta($item_id, '_cc_item_shipment_id', true);
                    if ($sid > 0) {
                        return (string) $sid;
                    }
                }
            }
        }

        return '';
    }

    public static function filter_by_status(array $rows, string $status): array
    {
        if ($status === '') return $rows;

        return array_values(array_filter($rows, static function ($row) use ($status) {
            return (string) ($row['status'] ?? '') === $status;
        }));
    }
}
