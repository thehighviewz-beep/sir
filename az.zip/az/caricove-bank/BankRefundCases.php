<?php
namespace Caricove\Bank;

if (!defined('ABSPATH')) exit;

final class BankRefundCases {

    private static function received_item_refund_amount(array $case, float $base_amount, int $qty_received): float {
        $qty_requested = max(1, (int) ($case['qty_requested'] ?? 0));
        $qty_received = max(0, min($qty_received, $qty_requested));
        if ($qty_received <= 0 || $base_amount <= 0) {
            return 0.0;
        }

        $per_unit = 0.0;
        $order_id = (int) ($case['order_id'] ?? 0);
        $order_item_id = (int) ($case['order_item_id'] ?? 0);
        if ($order_id > 0 && $order_item_id > 0 && function_exists('wc_get_order')) {
            $order = wc_get_order($order_id);
            if ($order) {
                $item = $order->get_item($order_item_id);
                if ($item) {
                    $item_total = (float) $item->get_total();
                    $item_qty = max(1, (int) $item->get_quantity());
                    $per_unit = $item_total / $item_qty;
                }
            }
        }

        if ($per_unit <= 0.0) {
            $unit_price = (float) ($case['unit_price'] ?? 0);
            if ($unit_price > 0.0) {
                $per_unit = $unit_price;
            }
        }

        if ($per_unit > 0.0) {
            return round(max(0.0, $per_unit * $qty_received), 2);
        }

        return round(max(0.0, ($base_amount / $qty_requested) * $qty_received), 2);
    }

    const STORE_OPTION      = 'caricove_bank_refund_cases_v1';
    const LEGACY_ORDER_META = '_caricove_return_cases';

    public static function canonical_statuses(): array {
        return [
            'requested',
            'seller_review',
            'awaiting_return',
            'awaiting_pickup',
            'awaiting_dropoff',
            'approved_return_pickup',
            'return_in_progress',
            'in_transit',
            'pickup_complete',
            'hub_received',
            'received',
            'admin_review',
            'approved',
            'pending_review',
            'info_requested',
            'under_review',
            'escalated',
            'declined',
            'refunded',
            'closed',
            'resolved',
            'completed',
            'cancelled',
            'cancelled_partial',
        ];
    }

   public static function canonical_financial_statuses(): array {
    return [
        'none',
        'previewed',
        'shipping_posted',
        'refund_posted',
        'reversal_posted',
        'debit_posted',
        'completed',
        'rolled_back',
        'rollback_blocked',
        'failed',
    ];
}

    private static function shipping_bucket_meta_key(): string {
        return '_caricove_bank_shipping_refund_bucket';
    }

    private static function live_order_shipping_bucket(array $case): array {
        $current = isset($case['order_shipping_refund_bucket']) && is_array($case['order_shipping_refund_bucket']) ? $case['order_shipping_refund_bucket'] : [];
        $order_id = max(0, (int) ($case['order_id'] ?? 0));
        $bucket = $current;

        if ($order_id > 0) {
            $raw = get_post_meta($order_id, self::shipping_bucket_meta_key(), true);
            if (is_array($raw)) {
                $bucket = array_merge($bucket, $raw);
            }
        }

        return [
            'order_id' => max(0, (int) ($bucket['order_id'] ?? $order_id)),
            'owner_case_id' => sanitize_text_field((string) ($bucket['owner_case_id'] ?? '')),
            'total_shipping_refundable' => round(max(0.0, (float) ($bucket['total_shipping_refundable'] ?? 0)), 2),
            'already_allocated_shipping' => round(max(0.0, (float) ($bucket['already_allocated_shipping'] ?? 0)), 2),
            'posting_key' => sanitize_text_field((string) ($bucket['posting_key'] ?? '')),
            'status' => sanitize_key((string) ($bucket['status'] ?? 'open')),
            'updated_at' => max(0, (int) ($bucket['updated_at'] ?? 0)),
        ];
    }

    private static function case_matches_shipping_bucket(array $case, ?array $bucket = null): bool {
        $bucket = is_array($bucket) ? $bucket : self::live_order_shipping_bucket($case);
        $case_id = trim((string) ($case['case_id'] ?? ''));
        $owner_case_id = trim((string) ($bucket['owner_case_id'] ?? ''));

        if ($case_id !== '' && $owner_case_id !== '' && $owner_case_id === $case_id) {
            return true;
        }

        $bucket_posting_key = trim((string) ($bucket['posting_key'] ?? ''));
        if ($bucket_posting_key !== '') {
            foreach (['shipping_refund_posting_key', 'shipping_liability_posting_key', 'shipping_posting_key'] as $key) {
                $case_posting_key = trim((string) ($case[$key] ?? ''));
                if ($case_posting_key !== '' && $case_posting_key === $bucket_posting_key) {
                    return true;
                }
            }
        }

        return false;
    }

    private static function effective_case_shipping_refund_amount(array $case, ?array $bucket = null): float {
        $bucket = is_array($bucket) ? $bucket : self::live_order_shipping_bucket($case);
        $raw = round(max(
            (float) ($case['outbound_shipping_refund_amount_customer'] ?? 0),
            (float) ($case['shipping_refund_amount'] ?? 0)
        ), 2);
        $allocated = round(max(0.0, (float) ($bucket['already_allocated_shipping'] ?? 0)), 2);

        if ($allocated > 0) {
            if (!self::case_matches_shipping_bucket($case, $bucket)) {
                return 0.0;
            }
            return $raw > 0 ? min($raw, $allocated) : $allocated;
        }

        return $raw;
    }

    public static function default_case(): array {
        return [
            'case_id'                 => '',
            'status'                  => 'requested',
            'case_type'               => 'return',

            'order_id'                => 0,
            'order_number'            => '',
            'parent_order_id'         => 0,
            'shipment_id'             => 0,
            'shipment_resolution_status' => 'resolved',
            'vendor_id'               => 0,
            'vendor_name'             => '',
            'customer_id'             => 0,

            'order_item_id'           => 0,
            'product_id'              => 0,
            'product_name'            => '',

            'qty_requested'           => 1,
            'qty_received'            => 0,
            'qty_refundable'          => 0,
            'cancel_qty_delta'        => 0,
            'cancel_qty_total'        => 0,

            'reason_code'             => '',
            'reason_text'             => '',
            'decision_code'           => '',

            'currency'                => '',
            'refund_amount_requested' => 0.0,
            'refund_amount_approved'  => 0.0,
            'declined_amount'         => 0.0,
            'unit_price'              => 0.0,
            'gross_refund_base'       => 0.0,
            'restocking_fee_rate'     => 0.0,
            'restocking_fee_amount'   => 0.0,
            'refund_suggested'        => 0.0,
            'item_refund_amount_customer' => 0.0,
            'item_refund_amount_customer_pending' => 0.0,
            'refund_amount_requested_pending' => 0.0,
            'refund_amount_approved_pending' => 0.0,
            'outbound_shipping_refund_amount_customer' => 0.0,
            'return_shipping_cost_internal' => 0.0,
            'shipping_liability_amount_internal' => 0.0,

            'refund_timing'           => '',
            'shipping_liability_party'=> '',
            'item_received_flag'      => 0,
            'refund_execution_mode'   => '',
            'shipping_refund_selected'=> 0,
            'shipping_posting_status' => '',
            'shipping_visibility_status' => '',
            'shipping_posting_key'    => '',
            'shipping_reversal_parent_key' => '',
            'item_refund_posting_key' => '',
            'shipping_refund_posting_key' => '',
            'shipping_liability_posting_key' => '',
            'customer_total_refund'   => 0.0,
            'seller_debit_exposure_amount' => 0.0,
            'seller_debit_exposure_status' => '',
            'seller_debit_exposure_posting_key' => '',
            'courier_liability_item_amount' => 0.0,
            'courier_liability_shipping_amount' => 0.0,
            'courier_liability_total_amount' => 0.0,
            'order_shipping_refund_bucket' => [],
            'shipping_payer'          => '',
            'initial_fault'           => 'unknown',
            'resolved_fault_party'    => '',
            'fault_resolution_status' => 'unresolved',
            'fault_resolution_note'   => '',
            'fault_resolved_at'       => 0,
            'fault_resolved_by'       => 0,
            'requires_evidence'       => 0,
            'manual_review'           => 0,
            'low_value_refund_only'   => 0,
            'return_required'         => 1,
            'request_only'            => 1,
            'deadline'                => 0,
            'window_days'             => 0,
            'delivered_at'            => 0,
            'return_address'          => '',

            'customer_note'           => '',
            'seller_note'             => '',
            'admin_note'              => '',

            'created_at'              => 0,
            'updated_at'              => 0,
            'seller_confirmed_at'     => 0,
            'admin_reviewed_at'       => 0,
            'admin_user_id'           => 0,

            'financial_status'        => 'none',
            'financial_txn_ref'       => '',
            'financial_lock'          => '',

            'refund_id'               => 0,
            'refund_payment'          => 0,
            'executed'                => 0,
            'cancelled_at'            => 0,
        ];
    }

    public static function create_case(array $payload): array {
        $case = self::normalize_case($payload);

        if ($case['case_id'] === '') {
            $case['case_id'] = self::generate_case_id((int) $case['order_id']);
        }

        $now = time();
        if ((int) $case['created_at'] <= 0) {
            $case['created_at'] = $now;
        }
        $case['updated_at'] = $now;

        $all = self::read_all();
        $all[$case['case_id']] = $case;
        self::write_all($all);
        self::sync_case_to_legacy_store($case);

        return $case;
    }

    public static function create_or_update_case(array $payload): array {
        $case_id = trim((string) ($payload['case_id'] ?? ''));
        if ($case_id !== '' && self::case_exists($case_id)) {
            return self::update_case($case_id, $payload) ?: self::get_case($case_id);
        }

        return self::create_case($payload);
    }

    public static function upsert_legacy_case_for_order(int $order_id, array $legacy_case, array $context = []): array {
        $order_id = (int) $order_id;
        if ($order_id <= 0) {
            return self::create_case($legacy_case);
        }

        $order = function_exists('wc_get_order') ? wc_get_order($order_id) : null;
        $currency = (string) ($context['currency'] ?? ($order && method_exists($order, 'get_currency') ? $order->get_currency() : get_woocommerce_currency()));
        $customer_id = (int) ($context['customer_id'] ?? ($order && method_exists($order, 'get_customer_id') ? $order->get_customer_id() : 0));
        $normalized = self::normalize_legacy_case($legacy_case, 0, $order_id, $currency, $customer_id, $context);
        return self::create_or_merge_import($normalized);
    }

    public static function get_case(string $case_id): ?array {
        $case_id = trim($case_id);
        if ($case_id === '') {
            return null;
        }

        $all = self::read_all();
        if (isset($all[$case_id]) && is_array($all[$case_id])) {
            return self::normalize_case($all[$case_id]);
        }

        return null;
    }


    public static function resolve_case_by_context(int $order_id, int $order_item_id = 0, int $shipment_id = 0, string $case_id_hint = '', string $case_type = ''): ?array {
        $case_id_hint = trim((string) $case_id_hint);
        $case_type = sanitize_key((string) $case_type);

        if ($case_id_hint !== '') {
            $direct = self::get_case($case_id_hint);
            if ($direct) {
                return $direct;
            }
        }

        $rows = self::list_order_cases($order_id);
        if (!$rows) {
            return null;
        }

        $fallback = null;
        foreach ($rows as $row) {
            $row_case_id = (string) ($row['case_id'] ?? '');
            if ($case_type !== '' && (string) ($row['case_type'] ?? '') !== $case_type) {
                continue;
            }
            if ($case_id_hint !== '') {
                if ($row_case_id === $case_id_hint || self::case_ids_loose_match($row_case_id, $case_id_hint, $order_id, $order_item_id)) {
                    return $row;
                }
                continue;
            }
            if ($order_item_id > 0 && (int) ($row['order_item_id'] ?? 0) !== $order_item_id) {
                continue;
            }
            if ($shipment_id > 0 && (int) ($row['shipment_id'] ?? 0) !== $shipment_id) {
                continue;
            }
            return $row;
        }

        if ($shipment_id > 0 || $order_item_id > 0) {
            foreach ($rows as $row) {
                if ($case_type !== '' && (string) ($row['case_type'] ?? '') !== $case_type) {
                    continue;
                }
                if ($order_item_id > 0 && (int) ($row['order_item_id'] ?? 0) === $order_item_id) {
                    return $row;
                }
                if ($shipment_id > 0 && (int) ($row['shipment_id'] ?? 0) === $shipment_id) {
                    $fallback = $fallback ?: $row;
                }
            }
        }

        return $fallback ?: self::resolve_case($order_id, $order_item_id, $case_id_hint, $case_type);
    }

    public static function resolve_case(int $order_id, int $order_item_id = 0, string $case_id_hint = '', string $case_type = ''): ?array {
        $case_id_hint = trim((string) $case_id_hint);
        $case_type = sanitize_key((string) $case_type);

        if ($case_id_hint !== '') {
            $direct = self::get_case($case_id_hint);
            if ($direct) {
                return $direct;
            }
        }

        $rows = self::list_order_cases($order_id);
        if (!$rows) {
            return null;
        }

        foreach ($rows as $row) {
            if ($order_item_id > 0 && (int) ($row['order_item_id'] ?? 0) !== $order_item_id) {
                continue;
            }
            if ($case_type !== '' && (string) ($row['case_type'] ?? '') !== $case_type) {
                continue;
            }
            $row_case_id = (string) ($row['case_id'] ?? '');
            if ($case_id_hint !== '') {
                if ($row_case_id === $case_id_hint) {
                    return $row;
                }
                if (self::case_ids_loose_match($row_case_id, $case_id_hint, $order_id, $order_item_id)) {
                    return $row;
                }
                continue;
            }
            return $row;
        }

        return null;
    }

    public static function list_cases(array $args = []): array {
        $rows = array_values(self::read_all());

        foreach ($rows as &$row) {
            $row = self::normalize_case($row);
        }
        unset($row);

        $status = isset($args['status']) ? sanitize_key((string) $args['status']) : '';
        if ($status !== '') {
            $rows = array_values(array_filter($rows, static function ($row) use ($status) {
                return (string) ($row['status'] ?? '') === $status;
            }));
        }

        $financial_status = isset($args['financial_status']) ? sanitize_key((string) $args['financial_status']) : '';
        if ($financial_status !== '') {
            $rows = array_values(array_filter($rows, static function ($row) use ($financial_status) {
                return (string) ($row['financial_status'] ?? '') === $financial_status;
            }));
        }

        $vendor_id = isset($args['vendor_id']) ? (int) $args['vendor_id'] : 0;
        if ($vendor_id > 0) {
            $rows = array_values(array_filter($rows, static function ($row) use ($vendor_id) {
                return (int) ($row['vendor_id'] ?? 0) === $vendor_id;
            }));
        }

        $order_id = isset($args['order_id']) ? (int) $args['order_id'] : 0;
        if ($order_id > 0) {
            $rows = array_values(array_filter($rows, static function ($row) use ($order_id) {
                return (int) ($row['order_id'] ?? 0) === $order_id;
            }));
        }

        $case_type = isset($args['case_type']) ? sanitize_key((string) $args['case_type']) : '';
        if ($case_type !== '') {
            $rows = array_values(array_filter($rows, static function ($row) use ($case_type) {
                return (string) ($row['case_type'] ?? '') === $case_type;
            }));
        }

        usort($rows, static function ($a, $b) {
            $at = (int) ($a['created_at'] ?? 0);
            $bt = (int) ($b['created_at'] ?? 0);
            if ($at === $bt) return strcmp((string) ($a['case_id'] ?? ''), (string) ($b['case_id'] ?? ''));
            return $at <=> $bt;
        });

        return $rows;
    }

    public static function list_order_cases(int $order_id, array $args = []): array {
        $order_id = (int) $order_id;
        if ($order_id <= 0) {
            return [];
        }

        $rows = self::list_cases(array_merge($args, ['order_id' => $order_id]));
        if (empty($rows)) {
            $rows = self::import_legacy_cases_for_order($order_id);
        }

        return array_values(array_filter($rows, static function ($row) use ($order_id) {
            return (int) ($row['order_id'] ?? 0) === $order_id;
        }));
    }

    public static function list_legacy_cases_for_order(int $order_id, array $args = []): array {
        $rows = self::list_order_cases($order_id, $args);
        $out = [];
        foreach ($rows as $row) {
            $out[] = self::project_case_to_legacy($row);
        }
        return $out;
    }

    private static function case_shipping_component_posted(array $case): bool {
        $shipping_amount  = round(max(0.0, (float) ($case['outbound_shipping_refund_amount_customer'] ?? 0)), 2);
        $financial_status = sanitize_key((string) ($case['financial_status'] ?? ''));
        $posted_status    = sanitize_key((string) ($case['shipping_posting_status'] ?? ''));
        $visible_status   = sanitize_key((string) ($case['shipping_visibility_status'] ?? ''));
        $posted_key       = trim((string) ($case['shipping_refund_posting_key'] ?? $case['shipping_liability_posting_key'] ?? $case['shipping_posting_key'] ?? ''));

        if ($shipping_amount <= 0) {
            return false;
        }

        return (
            $posted_key !== ''
            || in_array($posted_status, ['posted', 'visible'], true)
            || in_array($visible_status, ['posted', 'visible'], true)
            || in_array($financial_status, ['shipping_posted', 'refund_posted', 'completed', 'debit_posted', 'reversal_posted'], true)
        );
    }

    private static function case_item_component_posted(array $case): bool {
        $item_amount      = round(max(0.0, (float) ($case['item_refund_amount_customer'] ?? 0)), 2);
        $financial_status = sanitize_key((string) ($case['financial_status'] ?? ''));
        $status           = sanitize_key((string) ($case['status'] ?? ''));
        $item_key         = trim((string) ($case['item_refund_posting_key'] ?? ''));

        if ($item_amount <= 0) {
            return false;
        }

        if ($item_key !== '') {
            return true;
        }

        if (in_array($financial_status, ['refund_posted', 'completed', 'debit_posted', 'reversal_posted'], true)) {
            return true;
        }

        return $status === 'refunded';
    }

    private static function posted_customer_refund_total(array $case): float {
        $total = 0.0;

        if (self::case_shipping_component_posted($case)) {
            $total += round((float) ($case['outbound_shipping_refund_amount_customer'] ?? 0), 2);
        }

        if (self::case_item_component_posted($case)) {
            $total += round((float) ($case['item_refund_amount_customer'] ?? 0), 2);
        }

        $total = round(max(0.0, $total), 2);
        if ($total > 0) {
            return $total;
        }

        $financial_status = sanitize_key((string) ($case['financial_status'] ?? ''));
        if (in_array($financial_status, ['shipping_posted', 'refund_posted', 'completed', 'debit_posted', 'reversal_posted'], true)) {
            return round(max(0.0, (float) ($case['customer_total_refund'] ?? 0)), 2);
        }

        return 0.0;
    }

    public static function project_case_to_legacy(array $case): array {
        $case = self::normalize_case($case);
        $display_total = self::posted_customer_refund_total($case);

        if ($display_total <= 0) {
            $display_total = (float) ($case['refund_amount_approved'] > 0 ? $case['refund_amount_approved'] : $case['refund_amount_requested']);
        }

        $display_total = round(max(0.0, $display_total), 2);
        $reason_label = (string) ($case['reason_text'] ?: $case['reason_code']);

        return [
            'case_id'               => (string) $case['case_id'],
            'rma_id'                => (string) $case['case_id'],
            'order_id'              => (int) $case['order_id'],
            'order_number'          => (string) $case['order_number'],
            'parent_order_id'       => (int) $case['parent_order_id'],
            'shipment_id'           => (int) $case['shipment_id'],
            'vendor_id'             => (int) $case['vendor_id'],
            'vendor_name'           => (string) $case['vendor_name'],
            'customer_id'           => (int) $case['customer_id'],
            'item_id'               => (int) $case['order_item_id'],
            'order_item_id'         => (int) $case['order_item_id'],
            'line_item_id'          => (int) $case['order_item_id'],
            'product_id'            => (int) $case['product_id'],
            'pid'                   => (int) $case['product_id'],
            'product_name'          => (string) $case['product_name'],
            'qty'                   => (int) $case['qty_requested'],
            'qty_requested'         => (int) $case['qty_requested'],
            'qty_received'          => (int) $case['qty_received'],
            'qty_refundable'        => (int) $case['qty_refundable'],
            'cancel_qty_delta'      => (int) $case['cancel_qty_delta'],
            'cancel_qty_total'      => (int) $case['cancel_qty_total'],
            'reason_code'           => (string) $case['reason_code'],
            'reason'                => (string) $case['reason_code'],
            'reason_label'          => $reason_label,
            'decision_code'         => (string) $case['decision_code'],
            'currency'              => (string) $case['currency'],
            'refund_currency'       => (string) $case['currency'],
            'requested_amount'      => $display_total > 0 ? $display_total : (float) $case['refund_amount_requested'],
            'amount_requested'      => $display_total > 0 ? $display_total : (float) $case['refund_amount_requested'],
            'refund_suggested'      => (float) $case['refund_suggested'],
            'refund_amount'         => $display_total,
            'amount_refunded'       => $display_total > 0 ? $display_total : (float) $case['refund_amount_approved'],
            'declined_amount'       => (float) $case['declined_amount'],
            'amount_declined'       => (float) $case['declined_amount'],
            'item_refund_amount_customer' => (float) $case['item_refund_amount_customer'],
            'item_refund_amount_customer_pending' => (float) ($case['item_refund_amount_customer_pending'] ?? 0),
            'refund_amount_requested_pending' => (float) ($case['refund_amount_requested_pending'] ?? 0),
            'refund_amount_approved_pending' => (float) ($case['refund_amount_approved_pending'] ?? 0),
            'outbound_shipping_refund_amount_customer' => (float) $case['outbound_shipping_refund_amount_customer'],
            'return_shipping_cost_internal' => (float) $case['return_shipping_cost_internal'],
            'shipping_liability_amount_internal' => (float) $case['shipping_liability_amount_internal'],
            'customer_total_refund' => (float) $display_total,
            'total_customer_refund' => (float) $display_total,
            'unit_price'            => (float) $case['unit_price'],
            'gross_refund_base'     => (float) $case['gross_refund_base'],
            'restocking_fee_rate'   => (float) $case['restocking_fee_rate'],
            'restocking_fee_amount' => (float) $case['restocking_fee_amount'],
            'refund_timing'         => (string) $case['refund_timing'],
            'refund_line'           => (string) $case['refund_timing'],
            'refund_release'        => (string) $case['refund_timing'],
            'shipping_payer'        => (string) $case['shipping_payer'],
            'return_shipping'       => (string) $case['shipping_payer'],
            'shipping_party'        => (string) $case['shipping_payer'],
            'return_shipping_party' => (string) $case['shipping_payer'],
            'shipping_liability_party' => (string) $case['shipping_liability_party'],
            'item_received_flag'    => (int) $case['item_received_flag'],
            'refund_execution_mode' => (string) $case['refund_execution_mode'],
            'shipping_refund_selected' => (int) $case['shipping_refund_selected'],
            'shipping_posting_status' => (string) $case['shipping_posting_status'],
            'shipping_visibility_status' => (string) $case['shipping_visibility_status'],
            'shipping_posting_key'  => (string) $case['shipping_posting_key'],
            'shipping_reversal_parent_key' => (string) $case['shipping_reversal_parent_key'],
            'item_refund_posting_key' => (string) ($case['item_refund_posting_key'] ?? ''),
            'shipping_refund_posting_key' => (string) ($case['shipping_refund_posting_key'] ?? ''),
            'shipping_liability_posting_key' => (string) ($case['shipping_liability_posting_key'] ?? ''),
            'seller_debit_exposure_amount' => (float) ($case['seller_debit_exposure_amount'] ?? 0),
            'seller_debit_exposure_status' => (string) ($case['seller_debit_exposure_status'] ?? ''),
            'seller_debit_exposure_posting_key' => (string) ($case['seller_debit_exposure_posting_key'] ?? ''),
            'courier_liability_item_amount' => (float) ($case['courier_liability_item_amount'] ?? 0),
            'courier_liability_shipping_amount' => (float) ($case['courier_liability_shipping_amount'] ?? 0),
            'courier_liability_total_amount' => (float) ($case['courier_liability_total_amount'] ?? 0),
            'fault'                 => (string) $case['initial_fault'],
            'initial_fault'         => (string) $case['initial_fault'],
            'resolved_fault_party'  => (string) $case['resolved_fault_party'],
            'fault_resolution_status' => (string) $case['fault_resolution_status'],
            'fault_resolution_note' => (string) $case['fault_resolution_note'],
            'fault_resolved_at'     => (int) $case['fault_resolved_at'],
            'fault_resolved_by'     => (int) $case['fault_resolved_by'],
            'requires_evidence'     => !empty($case['requires_evidence']),
            'manual_review'         => !empty($case['manual_review']),
            'low_value_refund_only' => !empty($case['low_value_refund_only']),
            'return_required'       => !empty($case['return_required']),
            'request_only'          => (int) $case['request_only'],
            'deadline'              => (int) $case['deadline'],
            'status'                => (string) $case['status'],
            'state'                 => (string) $case['status'],
            'case_status'           => (string) $case['status'],
            'mode'                  => (string) ( $case['case_type'] === 'cancellation' ? 'cancel' : 'return' ),
            'created'               => (int) $case['created_at'],
            'created_at'            => (int) $case['created_at'],
            'updated'               => (int) $case['updated_at'],
            'updated_at'            => (int) $case['updated_at'],
            'seller_confirmed_at'   => (int) $case['seller_confirmed_at'],
            'admin_reviewed_at'     => (int) $case['admin_reviewed_at'],
            'admin_note'            => (string) $case['admin_note'],
            'admin_note_ts'         => (int) $case['admin_reviewed_at'],
            'admin_user_id'         => (int) $case['admin_user_id'],
            'customer_note'         => (string) $case['customer_note'],
            'seller_note'           => (string) $case['seller_note'],
            'return_address'        => (string) $case['return_address'],
            'case_type'             => (string) $case['case_type'],
            'type'                  => (string) $case['case_type'],
            'action'                => (string) $case['case_type'],
            'delivered_at'          => (int) $case['delivered_at'],
            'window_days'           => (int) $case['window_days'],
            'financial_status'      => (string) $case['financial_status'],
            'financial_txn_ref'     => (string) $case['financial_txn_ref'],
            'financial_lock'        => (string) $case['financial_lock'],
            'refund_id'             => (int) $case['refund_id'],
            'refund_record_id'      => (int) $case['refund_id'],
            'refund_record'         => (int) $case['refund_id'],
            'refund_payment'        => (int) $case['refund_payment'],
            'executed'              => (int) $case['executed'],
            'cancelled_at'          => (int) $case['cancelled_at'],
        ];
    }

    private static function status_triggers_financial_rollback(string $status): bool {
        return in_array($status, ['declined', 'cancelled', 'cancelled_partial'], true);
    }

    private static function financial_status_is_posted(string $status): bool {
        return in_array($status, ['shipping_posted', 'refund_posted', 'reversal_posted', 'debit_posted', 'completed'], true);
    }

    public static function is_terminal_case(array $case): bool {
        $status = sanitize_key((string) ($case['status'] ?? ''));
        $financial = sanitize_key((string) ($case['financial_status'] ?? ''));
        return in_array($status, ['refunded', 'completed', 'closed', 'resolved', 'declined', 'cancelled', 'cancelled_partial'], true)
            || in_array($financial, ['refund_posted', 'reversal_posted', 'debit_posted', 'completed', 'rolled_back'], true)
            || trim((string) ($case['item_refund_posting_key'] ?? '')) !== '';
    }

    public static function has_posted_item_refund(array $case): bool {
        $status = sanitize_key((string) ($case['status'] ?? ''));
        $financial = sanitize_key((string) ($case['financial_status'] ?? ''));
        return trim((string) ($case['item_refund_posting_key'] ?? '')) !== ''
            || $status === 'refunded'
            || in_array($financial, ['refund_posted', 'reversal_posted', 'debit_posted', 'completed'], true);
    }

    public static function update_case(string $case_id, array $patch): ?array {
        $case_id = trim($case_id);
        if ($case_id === '') {
            return null;
        }

        $all = self::read_all();
        if (!isset($all[$case_id]) || !is_array($all[$case_id])) {
            return null;
        }

        $current = self::normalize_case($all[$case_id]);
        if (self::is_terminal_case($current)) {
            $incoming_status = isset($patch['status']) ? self::normalize_status((string) $patch['status']) : (string) ($current['status'] ?? '');
            $incoming_financial = isset($patch['financial_status']) ? self::normalize_financial_status((string) $patch['financial_status']) : (string) ($current['financial_status'] ?? '');
            $allowed_same_terminal = (
                $incoming_status === (string) ($current['status'] ?? '')
                || ($incoming_status === 'refunded' && (string) ($current['status'] ?? '') === 'refunded')
                || $incoming_financial === (string) ($current['financial_status'] ?? '')
            );
            if (!$allowed_same_terminal && !self::status_triggers_financial_rollback($incoming_status)) {
                return $current;
            }
        }
        $merged  = array_merge($current, $patch);
        $merged['case_id'] = $case_id;
        $merged['updated_at'] = time();

        $all[$case_id] = self::normalize_case($merged);
        self::write_all($all);
        self::sync_case_to_legacy_store($all[$case_id]);

        $updated = $all[$case_id];

        $needsRollback = (
            self::financial_status_is_posted((string) ($current['financial_status'] ?? ''))
            && self::status_triggers_financial_rollback((string) ($updated['status'] ?? ''))
            && !in_array((string) ($updated['financial_status'] ?? ''), ['rolled_back', 'rollback_blocked'], true)
        );

        if ($needsRollback && class_exists(__NAMESPACE__ . '\\BankRefunds')) {
            try {
                $rollback = BankRefunds::rollback_financials_for_case($updated);
                if (!empty($rollback['success'])) {
                    $updated = self::mark_financial_state($case_id, 'rolled_back', [
                        'financial_txn_ref' => (string) ($rollback['financial_txn_ref'] ?? ($updated['financial_txn_ref'] ?? '')),
                        'financial_lock'    => '',
                    ]) ?: self::get_case($case_id) ?: $updated;
                } else {
                    $updated = self::mark_financial_state($case_id, 'rollback_blocked', [
                        'financial_lock' => (string) ($rollback['error'] ?? 'Financial rollback could not be completed safely.'),
                    ]) ?: self::get_case($case_id) ?: $updated;
                }
            } catch (\Throwable $e) {
                $updated = self::mark_financial_state($case_id, 'rollback_blocked', [
                    'financial_lock' => 'Financial rollback exception: ' . $e->getMessage(),
                ]) ?: self::get_case($case_id) ?: $updated;
            }
        }

        return $updated;
    }

    public static function set_received_qty(string $case_id, int $qty_received, array $meta = []): ?array {
        $case = self::get_case($case_id);
        if (!$case) {
            return null;
        }
        if (self::is_terminal_case($case)) {
            return $case;
        }

        $qty_total = max(1, (int) $case['qty_requested']);
        $qty_received = max(0, min($qty_received, $qty_total));

        // Canonical rule for return-required flows:
        // received qty is the ceiling for refundable qty.
        // If received qty is 0, refundable qty must remain 0.
        $qty_refundable = $qty_received;

        $patch = [
            'qty_received'        => $qty_received,
            'qty_refundable'      => $qty_refundable,
            'item_received_flag'  => $qty_received > 0 ? 1 : 0,
            'seller_confirmed_at' => time(),
        ];

        if (!empty($case['return_required']) && $qty_received > 0) {
            $pending_item_base = round(max(
                (float) ($case['item_refund_amount_customer_pending'] ?? 0),
                (float) ($case['refund_amount_requested_pending'] ?? 0),
                (float) ($case['refund_amount_approved_pending'] ?? 0)
            ), 2);

            if ($pending_item_base > 0) {
                $received_item_amount = self::received_item_refund_amount($case, $pending_item_base, $qty_received);
                $patch['item_refund_amount_customer'] = $received_item_amount;
                $patch['refund_amount_requested'] = $received_item_amount;
                $patch['refund_amount_approved'] = 0.0;
                $patch['customer_total_refund'] = round(
                    $received_item_amount + (float) ($case['outbound_shipping_refund_amount_customer'] ?? 0),
                    2
                );
                $patch['item_refund_amount_customer_pending'] = max(0.0, round($pending_item_base - $received_item_amount, 2));
                $patch['refund_amount_requested_pending'] = 0.0;
                $patch['refund_amount_approved_pending'] = 0.0;
            }
        }

        if (!empty($meta['seller_note'])) {
            $patch['seller_note'] = (string) $meta['seller_note'];
        }

        if (!empty($meta['status'])) {
            $patch['status'] = self::normalize_status((string) $meta['status']);
        } else {
            $patch['status'] = $qty_received > 0 ? 'received' : $case['status'];
        }

        return self::update_case($case_id, $patch);
    }

    public static function set_status(string $case_id, string $status, array $meta = []): ?array {
        $current = self::get_case($case_id);
        $normalized_status = self::normalize_status($status);
        if ($current && self::is_terminal_case($current) && $normalized_status !== (string) ($current['status'] ?? '')) {
            return $current;
        }
        $patch = [
            'status' => $normalized_status,
        ];

        if (isset($meta['admin_note'])) {
            $patch['admin_note'] = (string) $meta['admin_note'];
            $patch['admin_reviewed_at'] = time();
        }

        if (isset($meta['admin_user_id'])) {
            $patch['admin_user_id'] = (int) $meta['admin_user_id'];
        }

        if (isset($meta['seller_note'])) {
            $patch['seller_note'] = (string) $meta['seller_note'];
        }

        return self::update_case($case_id, $patch);
    }

    public static function mark_financial_state(string $case_id, string $financial_status, array $meta = []): ?array {
        $financial_status = self::normalize_financial_status($financial_status);

        $patch = [
            'financial_status' => $financial_status,
        ];

        if (isset($meta['financial_txn_ref'])) {
            $patch['financial_txn_ref'] = (string) $meta['financial_txn_ref'];
        }

        if (isset($meta['financial_lock'])) {
            $patch['financial_lock'] = (string) $meta['financial_lock'];
        }

        if (isset($meta['refund_amount_approved'])) {
            $patch['refund_amount_approved'] = (float) $meta['refund_amount_approved'];
        }

        if (isset($meta['declined_amount'])) {
            $patch['declined_amount'] = (float) $meta['declined_amount'];
        }

        return self::update_case($case_id, $patch);
    }

    public static function case_exists(string $case_id): bool {
        return self::get_case($case_id) !== null;
    }

    public static function import_legacy_cases_for_order(int $order_id): array {
        $order_id = (int) $order_id;
        if ($order_id <= 0) {
            return [];
        }

        $order = function_exists('wc_get_order') ? wc_get_order($order_id) : null;
        $currency = $order && method_exists($order, 'get_currency') ? (string) $order->get_currency() : get_woocommerce_currency();
        $customer_id = $order && method_exists($order, 'get_customer_id') ? (int) $order->get_customer_id() : 0;

        $raw = get_post_meta($order_id, self::LEGACY_ORDER_META, true);
        if (!is_array($raw)) {
            return [];
        }

        $imported = [];

        foreach ($raw as $i => $c) {
            if (!is_array($c)) {
                continue;
            }

            $normalized = self::normalize_legacy_case($c, (int) $i, $order_id, $currency, $customer_id);
            $imported[] = self::create_or_merge_import($normalized);
        }

        return $imported;
    }

    private static function create_or_merge_import(array $normalized): array {
        $case_id = (string) ($normalized['case_id'] ?? '');
        if ($case_id === '') {
            $normalized['case_id'] = self::generate_case_id((int) ($normalized['order_id'] ?? 0));
            return self::create_case($normalized);
        }

        $existing = self::get_case($case_id);
        if ($existing) {
            $patch = $normalized;
            unset($patch['updated_at']);
            return self::update_case($case_id, $patch) ?: $existing;
        }

        return self::create_case($normalized);
    }

    private static function sync_case_to_legacy_store(array $case): void {
        $case = self::normalize_case($case);
        $order_id = (int) ($case['order_id'] ?? 0);
        $case_id  = (string) ($case['case_id'] ?? '');

        if ($order_id <= 0 || $case_id === '') {
            return;
        }

        foreach (self::related_order_ids($case) as $target_order_id) {
            self::sync_case_to_specific_order_meta($target_order_id, $case);
        }

        self::sync_case_to_item_markers($case);
    }

    private static function sync_case_to_specific_order_meta(int $order_id, array $case): void {
        if ($order_id <= 0) {
            return;
        }

        $raw = get_post_meta($order_id, self::LEGACY_ORDER_META, true);
        if (!is_array($raw)) {
            $raw = [];
        }

        $projected = self::project_case_to_legacy($case);
        $matched = false;

        foreach ($raw as $i => $legacy_case) {
            if (!is_array($legacy_case)) {
                continue;
            }
            if (!self::legacy_case_matches($legacy_case, $case)) {
                continue;
            }
            $raw[$i] = array_merge($legacy_case, $projected);
            $matched = true;
            break;
        }

        if (!$matched) {
            $raw[] = $projected;
        }

        update_post_meta($order_id, self::LEGACY_ORDER_META, array_values($raw));
    }

    private static function sync_case_to_item_markers(array $case): void {
        $item_id = (int) ($case['order_item_id'] ?? 0);
        if ($item_id <= 0 || !function_exists('wc_update_order_item_meta')) {
            return;
        }

        $status = (string) ($case['status'] ?? 'requested');
        $case_type = (string) ($case['case_type'] ?? 'return');
        $qty_refunded = in_array($status, ['refunded', 'cancelled', 'cancelled_partial'], true)
            ? max((int) ($case['qty_refundable'] ?? 0), (int) ($case['qty_requested'] ?? 0))
            : (int) ($case['qty_refundable'] ?? 0);

        $map = [
            '_caricove_case_type'      => $case_type,
            '_caricove_case_status'    => $status,
            '_caricove_return_status'  => $status,
            '_caricove_qty_received'   => (int) ($case['qty_received'] ?? 0),
            '_caricove_qty_requested'  => (int) ($case['qty_requested'] ?? 0),
            '_caricove_qty_return_requested' => (int) ($case['qty_requested'] ?? 0),
            '_caricove_qty_refunded'   => $qty_refunded,
            '_caricove_rma_id'         => (string) ($case['case_id'] ?? ''),
            '_caricove_reason_label'   => (string) ($case['reason_text'] ?: $case['reason_code']),
            '_caricove_reason_code'    => (string) ($case['reason_code'] ?? ''),
            '_caricove_return_required'=> !empty($case['return_required']) ? 1 : 0,
            '_caricove_fault'          => (string) ($case['initial_fault'] ?? 'unknown'),
            '_caricove_initial_fault'  => (string) ($case['initial_fault'] ?? 'unknown'),
            '_caricove_resolved_fault_party' => (string) ($case['resolved_fault_party'] ?? ''),
            '_caricove_fault_resolution_status' => (string) ($case['fault_resolution_status'] ?? 'unresolved'),
            '_caricove_vendor_id'      => (int) ($case['vendor_id'] ?? 0),
            '_caricove_vendor_name'    => (string) ($case['vendor_name'] ?? ''),
            '_caricove_item_received_flag' => !empty($case['item_received_flag']) ? 1 : 0,
            '_caricove_refund_execution_mode' => (string) ($case['refund_execution_mode'] ?? ''),
            '_caricove_shipping_liability_party' => (string) ($case['shipping_liability_party'] ?? ''),
            '_caricove_shipping_refund_selected' => !empty($case['shipping_refund_selected']) ? 1 : 0,
            '_caricove_shipping_liability_amount_internal' => round((float) ($case['shipping_liability_amount_internal'] ?? 0), 2),
            '_caricove_outbound_shipping_refund_amount_customer' => round((float) ($case['outbound_shipping_refund_amount_customer'] ?? 0), 2),
            '_caricove_return_address' => (string) ($case['return_address'] ?? ''),
        ];

        if ($case_type === 'cancellation') {
            $map['_caricove_cancel_status'] = $status;
            $map['_caricove_cancellation_status'] = $status;
        }

        foreach ($map as $meta_key => $meta_value) {
            wc_update_order_item_meta($item_id, $meta_key, $meta_value);
        }
    }

    private static function normalize_case(array $case): array {
        $d = self::default_case();
        $c = array_merge($d, $case);

        $c['case_id']                 = trim((string) $c['case_id']);
        $c['status']                  = self::normalize_status((string) $c['status']);
        $c['case_type']               = self::normalize_case_type((string) $c['case_type']);

        $c['order_id']                = max(0, (int) $c['order_id']);
        $c['order_number']            = sanitize_text_field((string) $c['order_number']);
        $c['parent_order_id']         = max(0, (int) $c['parent_order_id']);
        $c['shipment_id']             = max(0, (int) $c['shipment_id']);
        $c['shipment_resolution_status']= sanitize_key((string) ($c['shipment_resolution_status'] ?? ($c['shipment_id'] > 0 ? 'resolved' : 'ambiguous')));
        if ($c['shipment_resolution_status'] === '') {
            $c['shipment_resolution_status'] = $c['shipment_id'] > 0 ? 'resolved' : 'ambiguous';
        }
        $c['vendor_id']               = max(0, (int) $c['vendor_id']);
        $c['vendor_name']             = sanitize_text_field((string) $c['vendor_name']);
        $c['customer_id']             = max(0, (int) $c['customer_id']);

        $c['order_item_id']           = max(0, (int) $c['order_item_id']);
        $c['product_id']              = max(0, (int) $c['product_id']);
        $c['product_name']            = sanitize_text_field((string) $c['product_name']);

        $c['qty_requested']  = max(1, (int) $c['qty_requested']);
        $c['qty_received']   = max(0, (int) $c['qty_received']);
        if ($c['qty_received'] > $c['qty_requested']) {
            $c['qty_received'] = $c['qty_requested'];
        }

        $raw_qty_refundable = max(0, (int) $c['qty_refundable']);
        $is_cancellation = ((string) $c['case_type'] === 'cancellation');
        $return_required = !empty($c['return_required']);

        if ($is_cancellation || !$return_required) {
            // Cancellation / no-return flows may legitimately refund requested qty
            // even when nothing is physically received.
            if ($raw_qty_refundable <= 0) {
                $c['qty_refundable'] = $c['qty_requested'];
            } else {
                $c['qty_refundable'] = min($raw_qty_refundable, $c['qty_requested']);
            }
        } else {
            // Return-required flows must never inflate refundable qty above received qty.
            if ($c['qty_received'] <= 0) {
                $c['qty_refundable'] = 0;
            } elseif ($raw_qty_refundable <= 0) {
                $c['qty_refundable'] = min($c['qty_received'], $c['qty_requested']);
            } else {
                $c['qty_refundable'] = min($raw_qty_refundable, $c['qty_received'], $c['qty_requested']);
            }
        }

        $c['cancel_qty_delta']        = max(0, (int) $c['cancel_qty_delta']);
        $c['cancel_qty_total']        = max(0, (int) $c['cancel_qty_total']);

        $c['reason_code']             = sanitize_key((string) $c['reason_code']);
        $c['reason_text']             = sanitize_text_field((string) $c['reason_text']);
        $c['decision_code']           = sanitize_text_field((string) $c['decision_code']);

        $c['currency']                = strtoupper(sanitize_text_field((string) $c['currency']));
        $c['refund_amount_requested'] = round(max(0.0, (float) $c['refund_amount_requested']), 2);
        $c['refund_amount_approved']  = round(max(0.0, (float) $c['refund_amount_approved']), 2);
        $c['declined_amount']         = round(max(0.0, (float) $c['declined_amount']), 2);
        $c['unit_price']              = round(max(0.0, (float) $c['unit_price']), 6);
        $c['gross_refund_base']       = round(max(0.0, (float) $c['gross_refund_base']), 2);
        $c['restocking_fee_rate']     = max(0.0, (float) $c['restocking_fee_rate']);
        $c['restocking_fee_amount']   = round(max(0.0, (float) $c['restocking_fee_amount']), 2);
        $c['refund_suggested']        = round(max(0.0, (float) $c['refund_suggested']), 2);
        $c['item_refund_amount_customer'] = round(max(0.0, (float) $c['item_refund_amount_customer']), 2);
        $c['item_refund_amount_customer_pending'] = round(max(0.0, (float) ($c['item_refund_amount_customer_pending'] ?? 0)), 2);
        $c['refund_amount_requested_pending'] = round(max(0.0, (float) ($c['refund_amount_requested_pending'] ?? 0)), 2);
        $c['refund_amount_approved_pending'] = round(max(0.0, (float) ($c['refund_amount_approved_pending'] ?? 0)), 2);
        $c['outbound_shipping_refund_amount_customer'] = round(max(0.0, (float) $c['outbound_shipping_refund_amount_customer']), 2);
        $c['return_shipping_cost_internal'] = round(max(0.0, (float) $c['return_shipping_cost_internal']), 2);
        $c['shipping_liability_amount_internal'] = round(max(0.0, (float) $c['shipping_liability_amount_internal']), 2);

        $c['refund_timing']           = sanitize_text_field((string) $c['refund_timing']);
        $c['shipping_payer']          = sanitize_text_field((string) $c['shipping_payer']);
        $c['shipping_liability_party']= self::normalize_resolved_fault_value((string) ($c['shipping_liability_party'] ?: ($case['shipping_liability_party'] ?? '')));
        $c['item_received_flag']      = !empty($c['item_received_flag']) ? 1 : 0;
        $c['refund_execution_mode']   = sanitize_key((string) $c['refund_execution_mode']);
        if (!in_array($c['refund_execution_mode'], ['never_received','return_required','returnless'], true)) {
            $c['refund_execution_mode'] = '';
        }
        $c['shipping_refund_selected']= !empty($c['shipping_refund_selected']) ? 1 : 0;
        $c['shipping_posting_status'] = sanitize_key((string) $c['shipping_posting_status']);
        $c['shipping_visibility_status'] = sanitize_key((string) $c['shipping_visibility_status']);
        $c['shipping_posting_key']    = sanitize_text_field((string) $c['shipping_posting_key']);
        $c['shipping_reversal_parent_key'] = sanitize_text_field((string) $c['shipping_reversal_parent_key']);
        $c['item_refund_posting_key'] = sanitize_text_field((string) ($c['item_refund_posting_key'] ?? ''));
        $c['shipping_refund_posting_key'] = sanitize_text_field((string) ($c['shipping_refund_posting_key'] ?? ''));
        $c['shipping_liability_posting_key'] = sanitize_text_field((string) ($c['shipping_liability_posting_key'] ?? ''));
        $c['customer_total_refund'] = round(max(0.0, (float) ($c['customer_total_refund'] ?? 0)), 2);
        $c['seller_debit_exposure_amount'] = round(max(0.0, (float) ($c['seller_debit_exposure_amount'] ?? 0)), 2);
        $c['seller_debit_exposure_status'] = sanitize_key((string) ($c['seller_debit_exposure_status'] ?? ''));
        $c['seller_debit_exposure_posting_key'] = sanitize_text_field((string) ($c['seller_debit_exposure_posting_key'] ?? ''));
        $c['courier_liability_item_amount'] = round(max(0.0, (float) ($c['courier_liability_item_amount'] ?? 0)), 2);
        $c['courier_liability_shipping_amount'] = round(max(0.0, (float) ($c['courier_liability_shipping_amount'] ?? 0)), 2);
        $c['courier_liability_total_amount'] = round(max(0.0, (float) ($c['courier_liability_total_amount'] ?? 0)), 2);
        $c['order_shipping_refund_bucket'] = self::live_order_shipping_bucket($c);
        $effective_case_shipping_refund = self::effective_case_shipping_refund_amount($c, $c['order_shipping_refund_bucket']);
        $shipping_consumed_by_other_case = (
            (float) ($c['order_shipping_refund_bucket']['already_allocated_shipping'] ?? 0) > 0
            && !self::case_matches_shipping_bucket($c, $c['order_shipping_refund_bucket'])
        );

        if ($shipping_consumed_by_other_case) {
            $pre_receive_return_required = (
                !empty($c['return_required'])
                && (string) ($c['refund_execution_mode'] ?? '') === 'return_required'
                && (int) ($c['qty_received'] ?? 0) <= 0
            );

            $c['outbound_shipping_refund_amount_customer'] = 0.0;
            $c['shipping_liability_amount_internal'] = 0.0;
            $c['courier_liability_shipping_amount'] = 0.0;
            $c['courier_liability_total_amount'] = round((float) $c['courier_liability_item_amount'], 2);
            $c['customer_total_refund'] = $pre_receive_return_required ? 0.0 : round(max(
                (float) ($c['item_refund_amount_customer'] ?? 0),
                (float) ($c['refund_amount_approved'] ?? 0),
                (float) ($c['refund_amount_requested'] ?? 0),
                0.0
            ), 2);
            $c['shipping_refund_selected'] = 0;
            if (
                trim((string) ($c['shipping_refund_posting_key'] ?? '')) === ''
                && trim((string) ($c['shipping_liability_posting_key'] ?? '')) === ''
                && trim((string) ($c['shipping_posting_key'] ?? '')) === ''
            ) {
                $c['shipping_posting_status'] = '';
                $c['shipping_visibility_status'] = '';
            }
        } else {
            $c['outbound_shipping_refund_amount_customer'] = $effective_case_shipping_refund;
        }
        $c['initial_fault']           = self::normalize_fault_value((string) ($c['initial_fault'] ?: ($case['fault'] ?? 'unknown')));
        $c['resolved_fault_party']    = self::normalize_resolved_fault_value((string) $c['resolved_fault_party']);
        $c['fault_resolution_status'] = self::normalize_fault_resolution_status((string) $c['fault_resolution_status']);
        $c['fault_resolution_note']   = sanitize_textarea_field((string) $c['fault_resolution_note']);
        $c['fault_resolved_at']       = max(0, (int) $c['fault_resolved_at']);
        $c['fault_resolved_by']       = max(0, (int) $c['fault_resolved_by']);
        $c['requires_evidence']       = !empty($c['requires_evidence']) ? 1 : 0;
        $c['manual_review']           = !empty($c['manual_review']) ? 1 : 0;
        $c['low_value_refund_only']   = !empty($c['low_value_refund_only']) ? 1 : 0;
        $c['return_required']         = !empty($c['return_required']) ? 1 : 0;
        $c['request_only']            = !empty($c['request_only']) ? 1 : 0;
        $c['deadline']                = max(0, (int) $c['deadline']);
        $c['window_days']             = max(0, (int) $c['window_days']);
        $c['delivered_at']            = max(0, (int) $c['delivered_at']);
        $c['return_address']          = sanitize_textarea_field((string) $c['return_address']);

        if ($c['shipping_liability_party'] === '' && $c['resolved_fault_party'] !== '') {
            $c['shipping_liability_party'] = (string) $c['resolved_fault_party'];
        }

       if ($c['refund_execution_mode'] === '') {
    if (!empty($c['return_required'])) {
        $c['refund_execution_mode'] = 'return_required';
    } elseif ((string) $c['reason_code'] === 'never_arrived') {
        $c['refund_execution_mode'] = 'never_received';
    } else {
        $c['refund_execution_mode'] = 'returnless';
    }
}

$is_shipping_only_pre_return = (
    (string) ($c['financial_status'] ?? '') === 'shipping_posted'
    && (string) ($c['refund_execution_mode'] ?? '') === 'return_required'
    && (int) ($c['qty_received'] ?? 0) <= 0
);

if ((string) $c['refund_execution_mode'] === 'never_received') {
    $c['item_received_flag'] = 0;
    $c['return_required'] = 0;
} elseif (!empty($c['return_required'])) {
    $c['item_received_flag'] = (int) ($c['qty_received'] ?? 0) > 0 ? 1 : 0;
} elseif ((int) $c['item_received_flag'] === 0 && (int) ($c['qty_received'] ?? 0) > 0) {
    $c['item_received_flag'] = 1;
}

if ($c['shipping_refund_selected'] === 0 && $c['outbound_shipping_refund_amount_customer'] > 0) {
    $c['shipping_refund_selected'] = 1;
}

$split_requested_total = round((float) $c['item_refund_amount_customer'] + (float) $c['outbound_shipping_refund_amount_customer'], 2);

$latent_item_amount = round(max(
    (float) ($c['item_refund_amount_customer_pending'] ?? 0),
    (float) ($c['refund_amount_requested_pending'] ?? 0),
    (float) ($c['refund_amount_approved_pending'] ?? 0)
), 2);

if ($is_shipping_only_pre_return) {
    /*
     * Shipping-only pre-return case:
     * - shipping is posted now
     * - item is NOT received yet
     * - item refund / seller debit exposure must stay at zero for now
     * - BUT the future item refund must remain latent so it can be restored
     *   after seller confirms receipt.
     */
    if ($latent_item_amount <= 0) {
        $latent_item_amount = round(max(
            (float) ($c['item_refund_amount_customer'] ?? 0),
            (float) ($c['refund_amount_requested'] ?? 0),
            (float) ($c['refund_amount_approved'] ?? 0),
            (float) ($c['refund_suggested'] ?? 0)
        ), 2);
    }

    if ($latent_item_amount > 0) {
        $c['item_refund_amount_customer_pending'] = $latent_item_amount;
        if ((float) ($c['refund_amount_requested_pending'] ?? 0) <= 0) {
            $c['refund_amount_requested_pending'] = round(max(
                (float) ($c['refund_amount_requested'] ?? 0),
                (float) ($c['refund_suggested'] ?? 0),
                $latent_item_amount
            ), 2);
        }
        if ((float) ($c['refund_amount_approved_pending'] ?? 0) <= 0) {
            $c['refund_amount_approved_pending'] = round(max(
                (float) ($c['refund_amount_approved'] ?? 0),
                $latent_item_amount
            ), 2);
        }
    }

    $c['item_received_flag'] = 0;
    $c['qty_refundable'] = 0;
    $c['item_refund_amount_customer'] = 0.0;
    $c['refund_amount_requested'] = 0.0;
    $c['refund_amount_approved'] = 0.0;
    $c['seller_debit_exposure_amount'] = 0.0;
    $c['seller_debit_exposure_status'] = '';
    $c['seller_debit_exposure_posting_key'] = '';
    $c['customer_total_refund'] = round((float) $c['outbound_shipping_refund_amount_customer'], 2);
} else {
    /*
     * Once the return is actually received, restore the latent item-side refund
     * back into the active fields so downstream refund UIs can post it.
     */
    if (!empty($c['return_required']) && (int) ($c['qty_received'] ?? 0) > 0 && $c['item_refund_amount_customer'] <= 0 && $latent_item_amount > 0) {
        $received_item_amount = self::received_item_refund_amount($c, $latent_item_amount, (int) ($c['qty_received'] ?? 0));
        $c['item_refund_amount_customer'] = $received_item_amount;
        if ($c['refund_amount_requested'] <= 0) {
            $c['refund_amount_requested'] = round(max(
                0.0,
                $received_item_amount
            ), 2);
        }
        if ($c['refund_amount_approved'] < 0) {
            $c['refund_amount_approved'] = 0.0;
        }
        $c['customer_total_refund'] = round(
            (float) $c['item_refund_amount_customer'] + (float) $c['outbound_shipping_refund_amount_customer'],
            2
        );
        $c['item_refund_amount_customer_pending'] = max(0.0, round($latent_item_amount - (float) $c['item_refund_amount_customer'], 2));
    }

    if ($split_requested_total > 0 && $c['customer_total_refund'] <= 0) {
        $c['customer_total_refund'] = $split_requested_total;
    }
    if ($c['item_refund_amount_customer'] > 0 && $c['refund_amount_requested'] <= 0) {
        $c['refund_amount_requested'] = (float) $c['item_refund_amount_customer'];
    }
    if ($c['item_refund_amount_customer'] > 0 && $c['refund_amount_approved'] <= 0 && $c['financial_status'] !== 'none') {
        $c['refund_amount_approved'] = (float) $c['item_refund_amount_customer'];
    }
}

if ($c['courier_liability_total_amount'] <= 0) {
    $c['courier_liability_total_amount'] = round((float) $c['courier_liability_item_amount'] + (float) $c['courier_liability_shipping_amount'], 2);
}

        $c['customer_note']           = sanitize_textarea_field((string) $c['customer_note']);
        $c['seller_note']             = sanitize_textarea_field((string) $c['seller_note']);
        $c['admin_note']              = sanitize_textarea_field((string) $c['admin_note']);

        $c['created_at']              = max(0, (int) $c['created_at']);
        $c['updated_at']              = max(0, (int) $c['updated_at']);
        $c['seller_confirmed_at']     = max(0, (int) $c['seller_confirmed_at']);
        $c['admin_reviewed_at']       = max(0, (int) $c['admin_reviewed_at']);
        $c['admin_user_id']           = max(0, (int) $c['admin_user_id']);

        $c['financial_status']        = self::normalize_financial_status((string) $c['financial_status']);
        $c['financial_txn_ref']       = sanitize_text_field((string) $c['financial_txn_ref']);
        $c['financial_lock']          = sanitize_text_field((string) $c['financial_lock']);

        $c['refund_id']               = max(0, (int) $c['refund_id']);
        $c['refund_payment']          = max(0, (int) $c['refund_payment']);
        $c['executed']                = !empty($c['executed']) ? 1 : 0;
        $c['cancelled_at']            = max(0, (int) $c['cancelled_at']);

        return $c;
    }

    private static function normalize_legacy_case(array $c, int $i, int $order_id, string $currency, int $customer_id, array $context = []): array {
        $case_id = (string) ($c['rma_id'] ?? $c['case_id'] ?? '');
        if ($case_id === '') {
            $case_id = 'RMA-' . $order_id . '-' . ($i + 1);
        }

        $status = (string) ($c['status'] ?? $c['state'] ?? 'requested');
        $case_type = (string) ($c['case_type'] ?? $c['type'] ?? $c['action'] ?? 'return');

        $requested = 0.0;
        foreach (['requested_amount', 'amount_requested', 'refund_suggested', 'refund_amount_requested', 'amount'] as $key) {
            if (isset($c[$key]) && is_numeric($c[$key])) {
                $requested = (float) $c[$key];
                break;
            }
        }

        $approved = 0.0;
        foreach (['refund_amount', 'amount_refunded', 'refund_amount_approved'] as $key) {
            if (isset($c[$key]) && is_numeric($c[$key])) {
                $approved = (float) $c[$key];
                break;
            }
        }

        $created_at = 0;
        foreach (['created', 'created_at', 'requested_at'] as $key) {
            if (isset($c[$key]) && is_numeric($c[$key])) {
                $created_at = (int) $c[$key];
                break;
            }
        }

        $updated_at = 0;
        foreach (['updated', 'updated_at'] as $key) {
            if (isset($c[$key]) && is_numeric($c[$key])) {
                $updated_at = (int) $c[$key];
                break;
            }
        }

        $order_item_id = (int) ($c['item_id'] ?? $c['order_item_id'] ?? 0);
        $product_id    = (int) ($c['product_id'] ?? ($context['product_id'] ?? 0));
        $shipment_id   = (int) ($c['shipment_id'] ?? ($context['shipment_id'] ?? 0));
        $vendor_id     = (int) ($c['vendor_id'] ?? ($context['vendor_id'] ?? 0));
        $vendor_name   = (string) ($c['vendor_name'] ?? ($context['vendor_name'] ?? ''));
        $order_number  = (string) ($c['order_number'] ?? ($context['order_number'] ?? ''));
        $product_name  = (string) ($c['product_name'] ?? ($context['product_name'] ?? ''));

        if ($shipment_id <= 0 && $order_item_id > 0) {
            if (class_exists('\Caricove\Logistics\Core\Schema')) {
                $k = \Caricove\Logistics\Core\Schema::META_ITEM_SHIPMENT_ID;
                $shipment_id = (int) wc_get_order_item_meta($order_item_id, $k, true);
            }

            if ($shipment_id <= 0) {
                foreach (['_cc_item_shipment_id', '_cc_shipment_id', '_cc_shipment_post_id'] as $k) {
                    $shipment_id = (int) wc_get_order_item_meta($order_item_id, $k, true);
                    if ($shipment_id > 0) {
                        break;
                    }
                }
            }
        }

        if ($shipment_id <= 0 && class_exists('\Caricove\Logistics\Core\ShipmentManager')) {
            $ships = \Caricove\Logistics\Core\ShipmentManager::get_shipments_for_order($order_id);
            if (is_array($ships) && !empty($ships)) {
                // Never silently bind a legacy case to the first shipment on the order.
                // Leave shipment unresolved so downstream surfaces do not display the wrong shipment.
                $shipment_id = 0;
                $c['shipment_resolution_status'] = (string) ($c['shipment_resolution_status'] ?? 'ambiguous');
            }
        }

        if ($vendor_id <= 0 && $shipment_id > 0) {
            if (class_exists('\Caricove\Logistics\Core\Schema')) {
                $vendor_id = (int) get_post_meta($shipment_id, \Caricove\Logistics\Core\Schema::META_SHIPMENT_VENDOR_ID, true);
            }

            if ($vendor_id <= 0) {
                $vendor_id = (int) get_post_meta($shipment_id, '_cc_shipment_vendor_id', true);
            }
        }

        if ($vendor_name === '' && $vendor_id > 0) {
            $vendor_name = self::resolve_vendor_name($vendor_id);
        }

        if ($product_id <= 0 && $order_item_id > 0 && function_exists('wc_get_order')) {
            $order = wc_get_order($order_id);
            if ($order) {
                $item = $order->get_item($order_item_id);
                if ($item && method_exists($item, 'get_product_id')) {
                    $product_id = (int) $item->get_product_id();
                }
                if ($product_name === '' && $item && method_exists($item, 'get_name')) {
                    $product_name = (string) $item->get_name();
                }
            }
        }

        $reason_text = (string) ($c['reason_label'] ?? $c['reason_text'] ?? '');
        if ($reason_text === '') {
            $reason_text = (string) ($c['reason_code'] ?? $c['reason'] ?? '');
        }

        return self::normalize_case([
            'case_id'                 => $case_id,
            'status'                  => $status,
            'case_type'               => $case_type,

            'order_id'                => $order_id,
            'order_number'            => $order_number,
            'parent_order_id'         => (int) ($c['parent_order_id'] ?? ($context['parent_order_id'] ?? 0)),
            'shipment_id'             => $shipment_id,
            'shipment_resolution_status' => (string) ($c['shipment_resolution_status'] ?? ($shipment_id > 0 ? 'resolved' : 'ambiguous')),
            'vendor_id'               => $vendor_id,
            'vendor_name'             => $vendor_name,
            'customer_id'             => $customer_id,

            'order_item_id'           => $order_item_id,
            'product_id'              => $product_id,
            'product_name'            => $product_name,

            'qty_requested'           => max(1, (int) ($c['qty'] ?? $c['qty_requested'] ?? 1)),
            'qty_received'            => max(0, (int) ($c['qty_received'] ?? 0)),
            'qty_refundable'          => max(0, (int) ($c['qty_refundable'] ?? 0)),
            'cancel_qty_delta'        => max(0, (int) ($c['cancel_qty_delta'] ?? 0)),
            'cancel_qty_total'        => max(0, (int) ($c['cancel_qty_total'] ?? 0)),

            'reason_code'             => (string) ($c['reason_code'] ?? $c['reason'] ?? ''),
            'reason_text'             => $reason_text,
            'decision_code'           => (string) ($c['decision_code'] ?? ''),

            'currency'                => (string) ($c['currency'] ?? $c['refund_currency'] ?? $currency),
            'refund_amount_requested' => $requested,
            'refund_amount_approved'  => $approved,
            'declined_amount'         => (float) ($c['declined_amount'] ?? $c['amount_declined'] ?? 0),
            'unit_price'              => (float) ($c['unit_price'] ?? 0),
            'gross_refund_base'       => (float) ($c['gross_refund_base'] ?? 0),
            'restocking_fee_rate'     => (float) ($c['restocking_fee_rate'] ?? 0),
            'restocking_fee_amount'   => (float) ($c['restocking_fee_amount'] ?? 0),
            'refund_suggested'        => (float) ($c['refund_suggested'] ?? $requested),
            'item_refund_amount_customer' => (float) ($c['item_refund_amount_customer'] ?? $c['item_refund_amount'] ?? 0),
            'item_refund_amount_customer_pending' => (float) ($c['item_refund_amount_customer_pending'] ?? 0),
            'refund_amount_requested_pending' => (float) ($c['refund_amount_requested_pending'] ?? 0),
            'refund_amount_approved_pending' => (float) ($c['refund_amount_approved_pending'] ?? 0),
            'outbound_shipping_refund_amount_customer' => (float) ($c['outbound_shipping_refund_amount_customer'] ?? $c['shipping_refund_amount'] ?? 0),
            'return_shipping_cost_internal' => (float) ($c['return_shipping_cost_internal'] ?? 0),
            'shipping_liability_amount_internal' => (float) ($c['shipping_liability_amount_internal'] ?? 0),

            'refund_timing'           => (string) ($c['refund_timing'] ?? ''),
            'shipping_payer'          => (string) ($c['shipping_payer'] ?? ''),
            'shipping_liability_party'=> (string) ($c['shipping_liability_party'] ?? ''),
            'item_received_flag'      => isset($c['item_received_flag']) ? (!empty($c['item_received_flag']) ? 1 : 0) : ((string) ($c['reason_code'] ?? $c['reason'] ?? '') === 'never_arrived' ? 0 : 1),
            'refund_execution_mode'   => (string) ($c['refund_execution_mode'] ?? ''),
            'shipping_refund_selected'=> !empty($c['shipping_refund_selected']) ? 1 : 0,
            'shipping_posting_status' => (string) ($c['shipping_posting_status'] ?? ''),
            'shipping_visibility_status' => (string) ($c['shipping_visibility_status'] ?? ''),
            'shipping_posting_key'    => (string) ($c['shipping_posting_key'] ?? ''),
            'shipping_reversal_parent_key' => (string) ($c['shipping_reversal_parent_key'] ?? ''),
            'item_refund_posting_key' => (string) ($c['item_refund_posting_key'] ?? ''),
            'shipping_refund_posting_key' => (string) ($c['shipping_refund_posting_key'] ?? ''),
            'shipping_liability_posting_key' => (string) ($c['shipping_liability_posting_key'] ?? ''),
            'customer_total_refund'   => (float) ($c['customer_total_refund'] ?? $c['total_customer_refund'] ?? 0),
            'seller_debit_exposure_amount' => (float) ($c['seller_debit_exposure_amount'] ?? 0),
            'seller_debit_exposure_status' => (string) ($c['seller_debit_exposure_status'] ?? ''),
            'seller_debit_exposure_posting_key' => (string) ($c['seller_debit_exposure_posting_key'] ?? ''),
            'courier_liability_item_amount' => (float) ($c['courier_liability_item_amount'] ?? 0),
            'courier_liability_shipping_amount' => (float) ($c['courier_liability_shipping_amount'] ?? 0),
            'courier_liability_total_amount' => (float) ($c['courier_liability_total_amount'] ?? 0),
            'initial_fault'           => (string) ($c['initial_fault'] ?? $c['fault'] ?? 'unknown'),
            'resolved_fault_party'    => (string) ($c['resolved_fault_party'] ?? ''),
            'fault_resolution_status' => (string) ($c['fault_resolution_status'] ?? 'unresolved'),
            'fault_resolution_note'   => (string) ($c['fault_resolution_note'] ?? ''),
            'fault_resolved_at'       => (int) ($c['fault_resolved_at'] ?? 0),
            'fault_resolved_by'       => (int) ($c['fault_resolved_by'] ?? 0),
            'requires_evidence'       => !empty($c['requires_evidence']) ? 1 : 0,
            'manual_review'           => !empty($c['manual_review']) ? 1 : 0,
            'low_value_refund_only'   => !empty($c['low_value_refund_only']) ? 1 : 0,
            'return_required'         => isset($c['return_required']) ? (!empty($c['return_required']) ? 1 : 0) : 1,
            'request_only'            => isset($c['request_only']) ? (!empty($c['request_only']) ? 1 : 0) : 1,
            'deadline'                => (int) ($c['deadline'] ?? 0),
            'window_days'             => (int) ($c['window_days'] ?? 0),
            'delivered_at'            => (int) ($c['delivered_at'] ?? 0),
            'return_address'          => (string) ($c['return_address'] ?? ($context['return_address'] ?? '')),

            'customer_note'           => (string) ($c['customer_note'] ?? ''),
            'seller_note'             => (string) ($c['seller_note'] ?? ''),
            'admin_note'              => (string) ($c['admin_note'] ?? ''),

            'created_at'              => $created_at,
            'updated_at'              => $updated_at,
            'seller_confirmed_at'     => (int) ($c['seller_confirmed_at'] ?? 0),
            'admin_reviewed_at'       => (int) ($c['admin_note_ts'] ?? $c['admin_reviewed_at'] ?? 0),
            'admin_user_id'           => (int) ($c['admin_user_id'] ?? 0),

            'financial_status'        => (string) ($c['financial_status'] ?? ((int) ($c['refund_id'] ?? 0) > 0 ? 'completed' : 'none')),
            'financial_txn_ref'       => (string) ($c['financial_txn_ref'] ?? ''),
            'financial_lock'          => (string) ($c['financial_lock'] ?? ''),

            'refund_id'               => (int) ($c['refund_id'] ?? 0),
            'refund_payment'          => (int) ($c['refund_payment'] ?? 0),
            'executed'                => !empty($c['executed']) ? 1 : 0,
            'cancelled_at'            => (int) ($c['cancelled_at'] ?? 0),
        ]);
    }

    private static function normalize_status(string $status): string {
        $status = sanitize_key(str_replace('-', '_', $status));
        if ($status === 'canceled') {
            $status = 'cancelled';
        }
        if (!in_array($status, self::canonical_statuses(), true)) {
            return 'requested';
        }
        return $status;
    }

    private static function normalize_financial_status(string $status): string {
        $status = sanitize_key($status);
        if (!in_array($status, self::canonical_financial_statuses(), true)) {
            return 'none';
        }
        return $status;
    }

   private static function normalize_case_type(string $case_type): string {
        $case_type = sanitize_key(str_replace('-', '_', $case_type));
        if (in_array($case_type, ['cancel', 'cancellation'], true)) {
            return 'cancellation';
        }
        return 'return';
    }

    private static function normalize_fault_value(string $fault): string {
        $fault = sanitize_key(str_replace('-', '_', trim($fault)));

        if ($fault === '') {
            return 'unknown';
        }

        if (in_array($fault, ['customer','seller','carrier','mixed','unknown'], true)) {
            return $fault;
        }

        // Common aliases / legacy drift
        if (in_array($fault, ['vendor','merchant'], true)) {
            return 'seller';
        }

        if (in_array($fault, ['courier','shipping','logistics'], true)) {
            return 'carrier';
        }

        if (in_array($fault, ['cx','buyer','user'], true)) {
            return 'customer';
        }

        return 'unknown';
    }

    private static function normalize_resolved_fault_value(string $fault): string {
        $fault = sanitize_key(str_replace('-', '_', trim($fault)));

        if ($fault === '' || $fault === 'clear') {
            return '';
        }

        if (in_array($fault, ['customer','seller','carrier','none'], true)) {
            return $fault;
        }

        if (in_array($fault, ['vendor','merchant'], true)) {
            return 'seller';
        }

        if (in_array($fault, ['courier','shipping','logistics'], true)) {
            return 'carrier';
        }

        if (in_array($fault, ['cx','buyer','user'], true)) {
            return 'customer';
        }

        return '';
    }

    private static function normalize_fault_resolution_status(string $status): string {
        $status = sanitize_key(str_replace('-', '_', trim($status)));

        if ($status === '') {
            return 'unresolved';
        }

        if (in_array($status, ['unresolved','resolved','overridden'], true)) {
            return $status;
        }

        return 'unresolved';
    }

    private static function generate_case_id(int $order_id): string {
        $order_id = max(0, $order_id);
        return 'RMA-' . $order_id . '-' . wp_generate_password(8, false, false);
    }

    private static function read_all(): array {
        $all = get_option(self::STORE_OPTION, []);
        return is_array($all) ? $all : [];
    }

    private static function write_all(array $all): void {
        update_option(self::STORE_OPTION, $all, false);
    }

    private static function related_order_ids(array $case): array {
        $order_ids = [];
        $order_id = (int) ($case['order_id'] ?? 0);
        if ($order_id > 0) {
            $order_ids[] = $order_id;
        }

        $parent_order_id = (int) ($case['parent_order_id'] ?? 0);
        if ($parent_order_id <= 0 && $order_id > 0 && function_exists('wc_get_order')) {
            $order = wc_get_order($order_id);
            if ($order && method_exists($order, 'get_parent_id')) {
                $parent_order_id = (int) $order->get_parent_id();
            }
        }
        if ($parent_order_id > 0) {
            $order_ids[] = $parent_order_id;
        }

        return array_values(array_unique(array_filter(array_map('intval', $order_ids))));
    }

    private static function case_ids_loose_match(string $left, string $right, int $order_id = 0, int $item_id = 0): bool {
        $left = strtolower(trim($left));
        $right = strtolower(trim($right));
        if ($left === '' || $right === '') {
            return false;
        }
        if ($left === $right) {
            return true;
        }
        if ($order_id > 0 && $item_id > 0) {
            $stable = strtolower('rcc-' . $order_id . '-' . $item_id);
            if (strpos($left, $stable) === 0 && strpos($right, $stable) === 0) {
                return true;
            }
        }
        return strpos($left, $right) === 0 || strpos($right, $left) === 0;
    }

    private static function legacy_case_matches(array $legacy_case, array $case): bool {
        $legacy_id = (string) ($legacy_case['rma_id'] ?? $legacy_case['case_id'] ?? '');
        $case_id   = (string) ($case['case_id'] ?? '');
        $order_id  = (int) ($case['order_id'] ?? 0);
        $item_id   = (int) ($case['order_item_id'] ?? 0);
        if ($legacy_id !== '' && self::case_ids_loose_match($legacy_id, $case_id, $order_id, $item_id)) {
            return true;
        }

        $legacy_item = (int) ($legacy_case['item_id'] ?? $legacy_case['order_item_id'] ?? 0);
        $legacy_type = self::normalize_case_type((string) ($legacy_case['case_type'] ?? $legacy_case['type'] ?? $legacy_case['action'] ?? 'return'));
        return $legacy_item > 0 && $item_id > 0 && $legacy_item === $item_id && $legacy_type === (string) ($case['case_type'] ?? 'return');
    }

    private static function resolve_vendor_name(int $vendor_id): string {
        $vendor_id = max(0, $vendor_id);
        if ($vendor_id <= 0) {
            return '';
        }

        if (function_exists('dokan_get_store_info')) {
            $store = dokan_get_store_info($vendor_id);
            if (is_array($store)) {
                $store_name = trim((string) ($store['store_name'] ?? ''));
                if ($store_name !== '') {
                    return $store_name;
                }
            }
        }

        $user = get_user_by('id', $vendor_id);
        return $user ? (string) $user->display_name : '';
    }
}