<?php
namespace Caricove\Bank;

if (!defined('ABSPATH')) exit;

if (!class_exists(__NAMESPACE__ . '\\SafeMoneyCourierResolver')) {

/**
 * Resolves the courier behind a courier-liable bank/recovery row without moving money.
 *
 * Doctrine:
 * - Prefer explicit IDs already stored on the recovery/fronted/bank rows.
 * - Then use exact shipment assignment truth from Logistics.
 * - Then use exact courier-earning rows tied to that same shipment.
 * - Never pool or guess across unrelated couriers.
 */
final class SafeMoneyCourierResolver
{
    public static function resolve(array $case, string $bank_table = '', ?array $fronted_store = null): array
    {
        $direct = self::direct_field($case, [
            'courier_id',
            'carrier_courier_id',
            'assigned_courier_id',
            'resolved_courier_id',
            'delivery_courier_id',
            'driver_id',
        ], 'recovery_row');
        if ($direct['courier_id'] > 0) {
            return $direct;
        }

        if ($fronted_store === null) {
            $fronted_store = maybe_unserialize(get_option('caricove_bank_platform_fronted_v1', []));
            if (!is_array($fronted_store)) {
                $fronted_store = [];
            }
        }

        $fronted = self::from_fronted_store($case, $fronted_store);
        if ($fronted['courier_id'] > 0) {
            return $fronted;
        }

        $bank = self::from_bank_events($case, $bank_table);
        if ($bank['courier_id'] > 0) {
            return $bank;
        }

        $shipment_id = self::int_value($case, ['shipment_id', 'source_shipment_id', 'target_shipment_id']);
        if ($shipment_id > 0) {
            $summary = self::from_shipment_summary($shipment_id);
            if ($summary['courier_id'] > 0) {
                return $summary;
            }

            $meta = self::from_shipment_meta($shipment_id);
            if ($meta['courier_id'] > 0) {
                return $meta;
            }

            $earning = self::from_courier_earning_shipment($shipment_id);
            if ($earning['courier_id'] > 0) {
                return $earning;
            }
        }

        return [
            'courier_id' => 0,
            'source' => 'unresolved',
            'confidence' => 'none',
            'proof' => 'No explicit courier_id, fronted row, bank event, shipment assignment, shipment meta, or exact shipment earning could prove ownership.',
        ];
    }

    public static function courier_id(array $case, string $bank_table = '', ?array $fronted_store = null): int
    {
        $resolved = self::resolve($case, $bank_table, $fronted_store);
        return (int) ($resolved['courier_id'] ?? 0);
    }

    private static function direct_field(array $row, array $keys, string $source_prefix): array
    {
        foreach ($keys as $key) {
            if (!array_key_exists($key, $row)) {
                continue;
            }
            $cid = (int) $row[$key];
            if ($cid > 0) {
                return [
                    'courier_id' => $cid,
                    'source' => $source_prefix . '.' . $key,
                    'confidence' => 'direct',
                    'proof' => 'Explicit courier id field `' . $key . '` was present on the row.',
                ];
            }
        }

        return ['courier_id' => 0, 'source' => $source_prefix . '.none', 'confidence' => 'none', 'proof' => ''];
    }

    private static function from_fronted_store(array $case, array $fronted_store): array
    {
        $matches = [];
        $case_refs = self::case_refs($case);
        $fronted_refs = self::fronted_refs($case);
        $recovery_refs = self::recovery_refs($case);
        $shipment_id = self::int_value($case, ['shipment_id', 'source_shipment_id', 'target_shipment_id']);
        $order_id = self::int_value($case, ['order_id', 'source_order_id', 'target_order_id']);

        foreach ($fronted_store as $idx => $fronted) {
            if (!is_array($fronted)) {
                continue;
            }

            $match_reason = '';
            $fronted_source_case = (string) ($fronted['source_case_id'] ?? '');
            $fronted_id = (string) ($fronted['fronted_case_id'] ?? '');
            $fronted_recovery = (string) ($fronted['recovery_case_id'] ?? '');

            if ($fronted_source_case !== '' && in_array($fronted_source_case, $case_refs, true)) {
                $match_reason = 'source_case_id';
            } elseif ($fronted_id !== '' && in_array($fronted_id, $fronted_refs, true)) {
                $match_reason = 'fronted_case_id';
            } elseif ($fronted_recovery !== '' && in_array($fronted_recovery, $recovery_refs, true)) {
                $match_reason = 'recovery_case_id';
            } elseif ($shipment_id > 0 && (int) ($fronted['shipment_id'] ?? 0) === $shipment_id) {
                $match_reason = 'shipment_id';
            } elseif ($order_id > 0 && (int) ($fronted['order_id'] ?? 0) === $order_id && (!empty($case_refs) || !empty($fronted_refs) || !empty($recovery_refs))) {
                $match_reason = 'order_id_plus_case_ref';
            }

            if ($match_reason === '') {
                continue;
            }

            $cid = (int) ($fronted['courier_id'] ?? 0);
            if ($cid > 0) {
                $matches[$cid][] = 'fronted[' . (string) $idx . '].' . $match_reason;
            }
        }

        return self::single_candidate($matches, 'platform_fronted_option');
    }

    private static function from_bank_events(array $case, string $bank_table): array
    {
        global $wpdb;
        $bank_table = trim($bank_table);
        if ($bank_table === '') {
            return ['courier_id' => 0, 'source' => 'bank_events.no_table', 'confidence' => 'none', 'proof' => ''];
        }

        $where = [];
        $args = [];
        foreach (self::case_refs($case) as $ref) {
            $where[] = 'return_case_id = %s';
            $args[] = $ref;
            $like = '%' . $wpdb->esc_like($ref) . '%';
            $where[] = 'lineage_key LIKE %s';
            $args[] = $like;
            $where[] = 'canonical_event_key LIKE %s';
            $args[] = $like;
            $where[] = 'source_ref LIKE %s';
            $args[] = $like;
            $where[] = 'meta_json LIKE %s';
            $args[] = $like;
        }

        $shipment_id = self::int_value($case, ['shipment_id', 'source_shipment_id', 'target_shipment_id']);
        if ($shipment_id > 0) {
            $where[] = 'shipment_id = %d';
            $args[] = $shipment_id;
        }

        $order_id = self::int_value($case, ['order_id', 'source_order_id', 'target_order_id']);
        if ($order_id > 0 && !empty($where)) {
            $where[] = 'order_id = %d';
            $args[] = $order_id;
        }

        if (empty($where)) {
            return ['courier_id' => 0, 'source' => 'bank_events.no_match_key', 'confidence' => 'none', 'proof' => ''];
        }

        $sql = "SELECT id, courier_id, return_case_id, shipment_id, order_id, meta_json
                FROM {$bank_table}
                WHERE (" . implode(' OR ', $where) . ")
                ORDER BY id DESC
                LIMIT 200";
        $rows = (array) $wpdb->get_results($wpdb->prepare($sql, $args), ARRAY_A);

        $matches = [];
        foreach ($rows as $row) {
            $direct = (int) ($row['courier_id'] ?? 0);
            if ($direct > 0) {
                $matches[$direct][] = 'bank_event#' . (string) ($row['id'] ?? '') . '.courier_id';
            }

            $meta = json_decode((string) ($row['meta_json'] ?? ''), true);
            if (is_array($meta)) {
                foreach (self::courier_ids_from_nested_array($meta) as $cid => $paths) {
                    $matches[(int) $cid][] = 'bank_event#' . (string) ($row['id'] ?? '') . '.meta_json.' . implode('|', $paths);
                }
            }
        }

        return self::single_candidate($matches, 'bank_events');
    }

    private static function from_shipment_summary(int $shipment_id): array
    {
        if ($shipment_id <= 0 || !class_exists('\\Caricove\Logistics\Core\ShipmentManager') || !method_exists('\\Caricove\Logistics\Core\ShipmentManager', 'get_shipment_summary')) {
            return ['courier_id' => 0, 'source' => 'shipment_summary.unavailable', 'confidence' => 'none', 'proof' => ''];
        }

        $summary = \Caricove\Logistics\Core\ShipmentManager::get_shipment_summary($shipment_id);
        if (!is_array($summary)) {
            return ['courier_id' => 0, 'source' => 'shipment_summary.empty', 'confidence' => 'none', 'proof' => ''];
        }

        foreach (['courier_id', 'assigned_courier_id', 'delivery_courier_id', 'rescue_courier_id'] as $key) {
            $cid = (int) ($summary[$key] ?? 0);
            if ($cid > 0) {
                return [
                    'courier_id' => $cid,
                    'source' => 'shipment_summary.' . $key,
                    'confidence' => 'direct',
                    'proof' => 'ShipmentManager summary for shipment #' . $shipment_id . ' contains `' . $key . '`.',
                ];
            }
        }

        return ['courier_id' => 0, 'source' => 'shipment_summary.none', 'confidence' => 'none', 'proof' => ''];
    }

    private static function from_shipment_meta(int $shipment_id): array
    {
        if ($shipment_id <= 0) {
            return ['courier_id' => 0, 'source' => 'shipment_meta.no_shipment', 'confidence' => 'none', 'proof' => ''];
        }

        $matches = [];
        foreach (self::shipment_courier_meta_keys() as $meta_key) {
            $cid = (int) get_post_meta($shipment_id, $meta_key, true);
            if ($cid > 0) {
                $matches[$cid][] = $meta_key;
            }
        }

        return self::single_candidate($matches, 'shipment_meta');
    }

    private static function from_courier_earning_shipment(int $shipment_id): array
    {
        global $wpdb;
        if ($shipment_id <= 0) {
            return ['courier_id' => 0, 'source' => 'courier_earning.no_shipment', 'confidence' => 'none', 'proof' => ''];
        }

        $cpt = class_exists('\\Caricove_Courier_Earnings_Engine') ? \Caricove_Courier_Earnings_Engine::CPT_EARNING : 'cc_courier_earning';
        $shipment_meta = class_exists('\\Caricove_Courier_Earnings_Engine') ? \Caricove_Courier_Earnings_Engine::META_SHIPMENT_ID : '_cc_earning_shipment_id';
        $courier_meta = class_exists('\\Caricove_Courier_Earnings_Engine') ? \Caricove_Courier_Earnings_Engine::META_COURIER_ID : '_cc_earning_courier_id';

        $rows = (array) $wpdb->get_results($wpdb->prepare(
            "SELECT p.ID AS earning_id, cid.meta_value AS courier_id
             FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->postmeta} sid ON sid.post_id=p.ID AND sid.meta_key=%s AND sid.meta_value=%d
             INNER JOIN {$wpdb->postmeta} cid ON cid.post_id=p.ID AND cid.meta_key=%s
             WHERE p.post_type=%s AND p.post_status <> 'trash'
             ORDER BY p.ID DESC
             LIMIT 50",
            $shipment_meta,
            $shipment_id,
            $courier_meta,
            $cpt
        ), ARRAY_A);

        $matches = [];
        foreach ($rows as $row) {
            $cid = (int) ($row['courier_id'] ?? 0);
            if ($cid > 0) {
                $matches[$cid][] = 'earning#' . (string) ($row['earning_id'] ?? '');
            }
        }

        return self::single_candidate($matches, 'courier_earning.shipment_id');
    }

    private static function from_order_unique_shipment_courier(int $order_id, int $primary_shipment_id = 0): array
    {
        global $wpdb;
        if ($order_id <= 0) {
            return ['courier_id' => 0, 'source' => 'order_unique.no_order', 'confidence' => 'none', 'proof' => ''];
        }

        $order_keys = ['_cc_shipment_order_id', '_cc_order_id', '_caricove_order_id'];
        if (class_exists('\\Caricove\Logistics\Core\Schema') && defined('\\Caricove\Logistics\Core\Schema::META_SHIPMENT_ORDER_ID')) {
            array_unshift($order_keys, \Caricove\Logistics\Core\Schema::META_SHIPMENT_ORDER_ID);
        }
        $order_keys = array_values(array_unique(array_filter($order_keys)));

        $placeholders = implode(',', array_fill(0, count($order_keys), '%s'));
        $args = array_merge($order_keys, [$order_id]);
        $rows = (array) $wpdb->get_results($wpdb->prepare(
            "SELECT DISTINCT pm.post_id AS shipment_id
             FROM {$wpdb->postmeta} pm
             INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
             WHERE pm.meta_key IN ({$placeholders})
               AND pm.meta_value = %d
               AND p.post_status <> 'trash'
             LIMIT 100",
            $args
        ), ARRAY_A);

        $matches = [];
        foreach ($rows as $row) {
            $sid = (int) ($row['shipment_id'] ?? 0);
            if ($sid <= 0) {
                continue;
            }
            $meta = self::from_shipment_meta($sid);
            $cid = (int) ($meta['courier_id'] ?? 0);
            if ($cid <= 0) {
                $earning = self::from_courier_earning_shipment($sid);
                $cid = (int) ($earning['courier_id'] ?? 0);
            }
            if ($cid > 0) {
                $matches[$cid][] = 'order#' . $order_id . '.shipment#' . $sid . ($sid === $primary_shipment_id ? '.primary' : '.sibling');
            }
        }

        $resolved = self::single_candidate($matches, 'order_unique_shipment_courier');
        if ($resolved['courier_id'] > 0) {
            $resolved['confidence'] = 'order_unique';
            $resolved['proof'] .= ' This is still an order-level fallback, not pooled money.';
        }
        return $resolved;
    }

    private static function shipment_courier_meta_keys(): array
    {
        $keys = [
            '_cc_shipment_courier_id',
            '_cc_courier_id',
            '_caricove_job_courier_id',
            '_cc_assigned_courier_id',
            '_cc_job_courier_id',
            '_cc_delivery_courier_id',
            '_cc_current_courier_id',
            '_cc_last_courier_id',
            '_caricove_courier_id',
            '_caricove_assigned_courier_id',
            '_cc_driver_id',
        ];

        if (class_exists('\\Caricove\Logistics\Core\Schema')) {
            if (defined('\\Caricove\Logistics\Core\Schema::META_SHIPMENT_COURIER_ID')) {
                $keys[] = \Caricove\Logistics\Core\Schema::META_SHIPMENT_COURIER_ID;
            }
            if (defined('\\Caricove\Logistics\Core\Schema::META_SHIPMENT_RESCUE_COURIER_ID')) {
                $keys[] = \Caricove\Logistics\Core\Schema::META_SHIPMENT_RESCUE_COURIER_ID;
            }
        }

        return array_values(array_unique(array_filter($keys)));
    }

    private static function case_refs(array $case): array
    {
        $refs = [];
        foreach (['source_case_id', 'return_case_id', 'case_id', 'rma_id', 'refund_case_id'] as $key) {
            $value = trim((string) ($case[$key] ?? ''));
            if ($value !== '') {
                $refs[] = $value;
            }
        }
        return array_values(array_unique($refs));
    }

    private static function fronted_refs(array $case): array
    {
        $refs = [];
        foreach (['platform_fronted_case_id', 'fronted_case_id'] as $key) {
            $value = trim((string) ($case[$key] ?? ''));
            if ($value !== '') {
                $refs[] = $value;
            }
        }
        return array_values(array_unique($refs));
    }

    private static function recovery_refs(array $case): array
    {
        $refs = [];
        foreach (['recovery_case_id', 'courier_recovery_case_id'] as $key) {
            $value = trim((string) ($case[$key] ?? ''));
            if ($value !== '') {
                $refs[] = $value;
            }
        }
        return array_values(array_unique($refs));
    }

    private static function int_value(array $case, array $keys): int
    {
        foreach ($keys as $key) {
            $value = (int) ($case[$key] ?? 0);
            if ($value > 0) {
                return $value;
            }
        }
        return 0;
    }

    private static function single_candidate(array $matches, string $source): array
    {
        $clean = [];
        foreach ($matches as $cid => $proofs) {
            $cid = (int) $cid;
            if ($cid <= 0) {
                continue;
            }
            $clean[$cid] = array_values(array_unique(array_filter(array_map('strval', (array) $proofs))));
        }

        if (count($clean) === 1) {
            $cid = (int) array_key_first($clean);
            return [
                'courier_id' => $cid,
                'source' => $source,
                'confidence' => 'direct',
                'proof' => implode(', ', $clean[$cid]),
            ];
        }

        if (count($clean) > 1) {
            return [
                'courier_id' => 0,
                'source' => $source . '.conflict',
                'confidence' => 'conflict',
                'proof' => 'Multiple courier IDs found: ' . wp_json_encode(array_keys($clean)),
            ];
        }

        return ['courier_id' => 0, 'source' => $source . '.none', 'confidence' => 'none', 'proof' => ''];
    }

    private static function courier_ids_from_nested_array(array $meta, string $prefix = ''): array
    {
        $out = [];
        foreach ($meta as $key => $value) {
            $path = $prefix === '' ? (string) $key : $prefix . '.' . (string) $key;
            $norm_key = strtolower((string) $key);

            if (is_array($value)) {
                foreach (self::courier_ids_from_nested_array($value, $path) as $cid => $paths) {
                    foreach ((array) $paths as $p) {
                        $out[(int) $cid][] = $p;
                    }
                }
                continue;
            }

            if (strpos($norm_key, 'courier') === false && strpos($norm_key, 'driver') === false) {
                continue;
            }
            if (strpos($norm_key, 'declined') !== false || strpos($norm_key, 'reject') !== false || strpos($norm_key, 'offer') !== false || strpos($norm_key, 'candidate') !== false) {
                continue;
            }

            $cid = (int) $value;
            if ($cid > 0) {
                $out[$cid][] = $path;
            }
        }

        foreach ($out as $cid => $paths) {
            $out[$cid] = array_values(array_unique($paths));
        }
        return $out;
    }
}
}

final class BankDashboard
{
    /**
     * Canonical reporting anchors
     *
     * IMPORTANT:
     * - Ledger tables remain the single financial truth.
     * - These epoch values are reporting / migration lenses only.
     * - They do NOT create a second truth system.
     */
   private const BANK_EPOCH_LEDGER_ID        = 1;
private const SELLER_LEDGER_EPOCH_ID      = 1;
private const EPOCH_FALLBACK_CREATED_AT   = '2025-03-12 04:27:55';

public static function overview_metrics(): array
{
    global $wpdb;

    $seller_ledger_table = Ledger::table();
    $seller_epoch_id     = self::sellerEpochLedgerId();
    $today               = current_time('Y-m-d');

  $courier_available = 0.0;
    $courier_clearing  = 0.0;
    $courier_held      = 0.0;
    $courier_paid      = 0.0;
    $courier_forfeited = 0.0;
    $platform_fronted_total = 0.0;
    $platform_fronted_today = 0.0;
    $courier_recovery_total = 0.0;
$courier_recovery_remaining_total = 0.0;
$courier_waived_total = 0.0;
$courier_available_by_id = [];
$courier_recovery_remaining_by_id = [];

    /*
     * Courier overview metrics must read the live courier earning ledger, not only
     * publish-status posts or the old instant/scheduled request surface. Using the
     * engine constants keeps this aligned if the CPT/meta names are adjusted later.
     */
    $courier_cpt         = class_exists('\Caricove_Courier_Earnings_Engine') ? \Caricove_Courier_Earnings_Engine::CPT_EARNING : 'cc_courier_earning';
    $courier_status_meta = class_exists('\Caricove_Courier_Earnings_Engine') ? \Caricove_Courier_Earnings_Engine::META_STATUS : '_cc_earning_status';
    $courier_amount_meta = class_exists('\Caricove_Courier_Earnings_Engine') ? \Caricove_Courier_Earnings_Engine::META_AMOUNT_GYD : '_cc_earning_amount_gyd';
    $courier_id_meta     = class_exists('\Caricove_Courier_Earnings_Engine') ? \Caricove_Courier_Earnings_Engine::META_COURIER_ID : '_cc_earning_courier_id';

    $courier_post_ids = $wpdb->get_col($wpdb->prepare(
        "SELECT p.ID
         FROM {$wpdb->posts} p
         WHERE p.post_type = %s
           AND p.post_status <> 'trash'
           AND p.post_date >= %s",
        $courier_cpt,
        self::epochFallbackCreatedAt()
    ));

    foreach ((array) $courier_post_ids as $eid) {
        $eid    = (int) $eid;
        $status     = (string) get_post_meta($eid, $courier_status_meta, true);
        $amt        = (float) get_post_meta($eid, $courier_amount_meta, true);
        $courier_id = (int) get_post_meta($eid, $courier_id_meta, true);

        if ($amt <= 0) {
            continue;
        }

        if ($status === 'available') {
            $courier_available += $amt;
            if ($courier_id > 0) {
                $courier_available_by_id[$courier_id] = (float) ($courier_available_by_id[$courier_id] ?? 0) + $amt;
            }
        } elseif ($status === 'clearing') {
            $courier_clearing += $amt;
        } elseif ($status === 'held') {
            $courier_held += $amt;
        } elseif ($status === 'paid') {
            $courier_paid += $amt;
        } elseif ($status === 'forfeited') {
            $courier_forfeited += $amt;
        }
    }
    /*
     * Platform-fronted reporting must follow the bank ledger customer refund events.
     * Option stores remain transitional projections for courier workflows only.
     */

   $recovery_store = get_option('caricove_bank_courier_recovery_v1', []);
    if (!is_array($recovery_store)) {
        $recovery_store = [];
    }

    $fronted_store = get_option('caricove_bank_platform_fronted_v1', []);
    if (!is_array($fronted_store)) {
        $fronted_store = [];
    }
    $bank_event_table = class_exists(__NAMESPACE__ . '\BankLedger') ? BankLedger::table() : '';

    foreach ($recovery_store as $row) {
        if (!is_array($row)) {
            continue;
        }

       $courier_recovery_total += abs((float) ($row['recovered_amount_total'] ?? 0));
$courier_remaining_amount = abs((float) ($row['remaining_amount_total'] ?? 0));
$courier_recovery_remaining_total += $courier_remaining_amount;
$courier_waived_total += abs((float) ($row['waived_amount_total'] ?? 0));

$courier_recovery_resolved = class_exists(__NAMESPACE__ . '\\SafeMoneyCourierResolver') ? SafeMoneyCourierResolver::resolve($row, $bank_event_table, $fronted_store) : ['courier_id' => (int) ($row['courier_id'] ?? 0)];
$courier_recovery_courier_id = (int) ($courier_recovery_resolved['courier_id'] ?? 0);
if ($courier_remaining_amount > 0) {
    $courier_recovery_remaining_by_id[$courier_recovery_courier_id] = (float) ($courier_recovery_remaining_by_id[$courier_recovery_courier_id] ?? 0) + $courier_remaining_amount;
}
    }

    $neutral_meta_sql = "(
                meta IS NULL
                OR meta = ''
                OR meta = '{}'
                OR meta = '[]'
                OR meta LIKE '%%\"chain_role_state\":\"NEUTRAL\"%%'
           )";

$platform_earned = (float) $wpdb->get_var($wpdb->prepare(
        "SELECT COALESCE(SUM(commission),0)
         FROM {$seller_ledger_table}
         WHERE id >= %d
           AND state IN ('pending','available','paid','reversed')",
        $seller_epoch_id
    ));

    /*
     * KFC-money doctrine:
     * Net Platform Revenue must be the conservative internal spendable number,
     * not gross commission and not money that belongs to sellers/couriers/customers.
     *
     * Therefore the spendable base starts only with platform commission attached
     * to seller-ledger rows that have actually cleared to available/paid.
     * Pending, hold, debit and reversed rows are intentionally excluded.
     */
    $platform_cleared_commission = (float) $wpdb->get_var($wpdb->prepare(
        "SELECT COALESCE(SUM(CASE WHEN commission > 0 THEN commission ELSE 0 END),0)
         FROM {$seller_ledger_table}
         WHERE id >= %d
           AND state IN ('available','paid')",
        $seller_epoch_id
    ));

    $commission_reversed = (float) $wpdb->get_var($wpdb->prepare(
        "SELECT COALESCE(SUM(ABS(commission)),0)
         FROM {$seller_ledger_table}
         WHERE id >= %d
           AND state = 'reversed'",
        $seller_epoch_id
    ));

    $bank_commission_reversed = 0.0;

    $vendor_pending = (float) $wpdb->get_var($wpdb->prepare(
        "SELECT COALESCE(SUM(CASE WHEN net > 0 THEN net ELSE 0 END),0)
         FROM {$seller_ledger_table}
         WHERE id >= %d
           AND state = 'pending'
           AND {$neutral_meta_sql}",
        $seller_epoch_id
    ));

    $vendor_hold_funds = (float) $wpdb->get_var($wpdb->prepare(
        "SELECT COALESCE(SUM(CASE WHEN net > 0 THEN net ELSE 0 END),0)
         FROM {$seller_ledger_table}
         WHERE id >= %d
           AND state = 'hold'
           AND {$neutral_meta_sql}",
        $seller_epoch_id
    ));

    $available_for_payout = (float) $wpdb->get_var($wpdb->prepare(
        "SELECT COALESCE(SUM(CASE WHEN net > 0 THEN net ELSE 0 END),0)
         FROM {$seller_ledger_table}
         WHERE id >= %d
           AND state='available'",
        $seller_epoch_id
    ));



$payouts_table = Ledger::payouts_table();

    $paid_out = (float) $wpdb->get_var(
        "SELECT COALESCE(SUM(amount_net),0)
         FROM {$payouts_table}
         WHERE status = 'sent'"
    );

    $vendor_debit_exposure = (float) $wpdb->get_var($wpdb->prepare(
        "SELECT COALESCE(SUM(ABS(net)),0)
         FROM {$seller_ledger_table}
         WHERE id >= %d
           AND state='debit'
           AND net < 0
           AND meta NOT LIKE '%\"shipping_liability\":1%'
           AND meta NOT LIKE '%\"debit_component\":\"shipping_liability\"%'
           AND meta NOT LIKE '%\"debit_component\":\"shipping\"%'
           AND meta NOT LIKE '%\"kind\":\"shipping\"%'",
        $seller_epoch_id
    ));


$refunds_today   = 0.0;
    $refund_exposure = 0.0;
    $seen_refund_events = [];

    foreach (self::filtered_bank_rows(['event_type' => 'customer_refund_issued'], 2000) as $row) {
        $created_at = (string) ($row['created_at'] ?? '');
        $amount     = (float) ($row['amount'] ?? 0);
        $meta_raw   = $row['meta_json'] ?? [];
        $meta       = is_array($meta_raw) ? $meta_raw : json_decode((string) $meta_raw, true);

        if (!is_array($meta)) {
            $meta = [];
        }

        $event_key = (string) ($row['canonical_event_key'] ?? '');
        if ($event_key === '' && !empty($meta['shipping_posting_key'])) {
            $event_key = 'shipping|' . (string) $meta['shipping_posting_key'];
        }
        if ($event_key === '') {
            $event_key = (string) ($row['source_ref'] ?? '');
        }
        if ($event_key !== '' && isset($seen_refund_events[$event_key])) {
            continue;
        }
        if ($event_key !== '') {
            $seen_refund_events[$event_key] = true;
        }

        $refund_exposure += abs($amount);

        if ($created_at !== '' && substr($created_at, 0, 10) === $today) {
            $refunds_today += abs($amount);
        }

        /*
         * Only add bank-side commission reversal for true clawback cases.
         * Reversal cases are already counted from seller-ledger state='reversed'.
         */
        $mode = strtolower((string) ($meta['financial_mode'] ?? ($meta['mode'] ?? '')));
        if ($mode === 'debit') {
            $bank_commission_reversed += abs((float) ($meta['commission_reversal'] ?? 0));
        }
    }

   $commission_reversed += $bank_commission_reversed;

    $platform_fronted_total = $refund_exposure;
    $platform_fronted_today = $refunds_today;

    $platform_absorbed_total = 0.0;
    foreach (['platform_loss_booked', 'platform_absorption'] as $loss_event_type) {
        foreach (self::filtered_bank_rows(['event_type' => $loss_event_type], 2000) as $row) {
            $platform_absorbed_total += abs((float) ($row['amount'] ?? 0));
        }
    }

    $vendor_funds_clearing = $vendor_pending;
    $locked_funds          = $vendor_funds_clearing + $vendor_hold_funds + $courier_clearing + $courier_held;

    /*
     * Open debt is NOT platform revenue.
     * It also should not erase platform revenue dollar-for-dollar when there are
     * live funds that can cover it. Only the uncovered part is reserved against
     * Net Platform Revenue.
     */
    $courier_recovery_covered_now = 0.0;
    $courier_uncovered_exposure = 0.0;
    foreach ($courier_recovery_remaining_by_id as $recovery_courier_id => $courier_debt_amount) {
        $courier_debt_amount = max(0.0, (float) $courier_debt_amount);
        if ($courier_debt_amount <= 0) {
            continue;
        }

        /*
         * Coverage is per courier, never pooled across couriers.
         * Courier A's available funds cannot make Courier B's debt safe.
         */
        $cover_pool = ((int) $recovery_courier_id > 0)
            ? max(0.0, (float) ($courier_available_by_id[(int) $recovery_courier_id] ?? 0))
            : 0.0;

        $covered_here = min($courier_debt_amount, $cover_pool);
        $courier_recovery_covered_now += $covered_here;
        $courier_uncovered_exposure += max(0.0, $courier_debt_amount - $covered_here);
    }

    /*
     * Vendor exposure is also covered per vendor, not globally.
     * Vendor A's available payout funds cannot safely cover Vendor B's debt.
     */
    $vendor_debit_covered_now = 0.0;
    $vendor_uncovered_exposure = 0.0;
    $vendor_debt_by_id = [];

    $vendor_debt_rows = (array) $wpdb->get_results($wpdb->prepare(
        "SELECT vendor_id, COALESCE(SUM(ABS(net)),0) AS debt
         FROM {$seller_ledger_table}
         WHERE id >= %d
           AND state='debit'
           AND net < 0
           AND meta NOT LIKE '%\"shipping_liability\":1%'
           AND meta NOT LIKE '%\"debit_component\":\"shipping_liability\"%'
           AND meta NOT LIKE '%\"debit_component\":\"shipping\"%'
           AND meta NOT LIKE '%\"kind\":\"shipping\"%'
         GROUP BY vendor_id",
        $seller_epoch_id
    ), ARRAY_A);

    foreach ($vendor_debt_rows as $debt_row) {
        $vid = (int) ($debt_row['vendor_id'] ?? 0);
        $debt = max(0.0, (float) ($debt_row['debt'] ?? 0));
        if ($vid > 0 && $debt > 0) {
            $vendor_debt_by_id[$vid] = $debt;
        }
    }

    $vendor_available_by_id = [];
    $vendor_available_rows = (array) $wpdb->get_results($wpdb->prepare(
        "SELECT vendor_id, COALESCE(SUM(CASE WHEN net > 0 THEN net ELSE 0 END),0) AS available
         FROM {$seller_ledger_table}
         WHERE id >= %d
           AND state='available'
         GROUP BY vendor_id",
        $seller_epoch_id
    ), ARRAY_A);

    foreach ($vendor_available_rows as $available_row) {
        $vid = (int) ($available_row['vendor_id'] ?? 0);
        $available = max(0.0, (float) ($available_row['available'] ?? 0));
        if ($vid > 0 && $available > 0) {
            $vendor_available_by_id[$vid] = $available;
        }
    }

    foreach ($vendor_debt_by_id as $vid => $debt) {
        $cover_pool = max(0.0, (float) ($vendor_available_by_id[$vid] ?? 0));
        $covered_here = min((float) $debt, $cover_pool);
        $vendor_debit_covered_now += $covered_here;
        $vendor_uncovered_exposure += max(0.0, (float) $debt - $covered_here);
    }

    $platform_spendability_reserve = max(0.0,
        (float) $commission_reversed
        + (float) $platform_absorbed_total
        + (float) $courier_waived_total
        + (float) $courier_uncovered_exposure
        + (float) $vendor_uncovered_exposure
    );

    $net_platform_revenue = max(
        0.0,
        (float) $platform_cleared_commission - (float) $platform_spendability_reserve
    );

    $alerts_total = 0;
    if (class_exists(__NAMESPACE__ . '\\BankAlerts')) {
        $alerts_total = array_sum(array_map(static function ($a) {
            return (int) ($a['count'] ?? 0);
        }, BankAlerts::collect()));
    }

  return [
    ['label' => 'Platform Commission Earned',      'value' => 'GYD ' . number_format($platform_earned, 2)],
    ['label' => 'Platform Commission Cleared',     'value' => 'GYD ' . number_format($platform_cleared_commission, 2)],
    ['label' => 'Commission Reversed',             'value' => 'GYD ' . number_format($commission_reversed, 2)],
    [
        'label' => 'Net Platform Revenue',
        'value' => 'GYD ' . number_format($net_platform_revenue, 2),
        'href'  => '#cbank-net-platform-audit',
        'help'  => 'Click to audit the exact source rows behind this spendable number.',
    ],
    ['label' => 'Platform Spendability Reserve',   'value' => 'GYD ' . number_format($platform_spendability_reserve, 2)],
   ['label' => 'Courier Liability to Platform Remaining',     'value' => 'GYD ' . number_format($courier_recovery_remaining_total, 2)],
   ['label' => 'Courier Liability Covered By Funds',     'value' => 'GYD ' . number_format($courier_recovery_covered_now, 2)],
   ['label' => 'Uncovered Courier Exposure',     'value' => 'GYD ' . number_format($courier_uncovered_exposure, 2)],
   ['label' => 'Uncovered Vendor Exposure',     'value' => 'GYD ' . number_format($vendor_uncovered_exposure, 2)],
   ['label' => 'Waived Recovery (Platform Loss)', 'value' => 'GYD ' . number_format($courier_waived_total, 2)],
    ['label' => 'Seller Funds Clearing',           'value' => 'GYD ' . number_format($vendor_funds_clearing, 2)],
    ['label' => 'Seller Funds On Hold',            'value' => 'GYD ' . number_format($vendor_hold_funds, 2)],
    ['label' => 'Seller Funds Available',          'value' => 'GYD ' . number_format($available_for_payout, 2)],
    ['label' => 'Seller Payouts Completed',        'value' => 'GYD ' . number_format($paid_out, 2)],

    ['label' => 'Courier Funds Clearing',          'value' => 'GYD ' . number_format($courier_clearing, 2)],
    ['label' => 'Courier Funds Available',         'value' => 'GYD ' . number_format($courier_available, 2)],
    ['label' => 'Courier Funds Held',              'value' => 'GYD ' . number_format($courier_held, 2)],
    ['label' => 'Courier Payouts Completed',       'value' => 'GYD ' . number_format($courier_paid, 2)],

    ['label' => 'Locked Funds',                    'value' => 'GYD ' . number_format($locked_funds, 2)],

    ['label' => 'Vendor Liability To Platform',    'value' => 'GYD ' . number_format($vendor_debit_exposure, 2)],
    ['label' => 'Vendor Liability Covered By Funds','value' => 'GYD ' . number_format($vendor_debit_covered_now, 2)],

    ['label' => 'Total Refunds Issued',            'value' => 'GYD ' . number_format($refund_exposure, 2)],
    ['label' => 'Refunds Today',                   'value' => 'GYD ' . number_format($refunds_today, 2)],

    ['label' => 'Alerts',                          'value' => (string) $alerts_total],
];
}

public static function render_page(): void
{
        $metrics = self::overview_metrics();
        $alerts  = class_exists(__NAMESPACE__ . '\\BankAlerts') ? BankAlerts::collect() : [];

        $tab = isset($_GET['tab']) ? sanitize_key((string) $_GET['tab']) : 'overview';
        if ($tab === 'instant_payout_requests') {
            $tab = 'payout_requests';
        }
        ?>
        <div class="wrap caricove-bank-wrap">
          <h2 class="nav-tab-wrapper">
    <a href="<?php echo esc_url(admin_url('admin.php?page=caricove-bank&tab=overview')); ?>" class="nav-tab <?php echo $tab === 'overview' ? 'nav-tab-active' : ''; ?>">Overview</a>
    <a href="<?php echo esc_url(admin_url('admin.php?page=caricove-bank&tab=platform_wallet')); ?>" class="nav-tab <?php echo $tab === 'platform_wallet' ? 'nav-tab-active' : ''; ?>">Platform Wallet</a>
    <a href="<?php echo esc_url(admin_url('admin.php?page=caricove-bank&tab=payment_setup')); ?>" class="nav-tab <?php echo $tab === 'payment_setup' ? 'nav-tab-active' : ''; ?>">Payment Setup</a>
    <a href="<?php echo esc_url(admin_url('admin.php?page=caricove-bank&tab=guyana_rails')); ?>" class="nav-tab <?php echo $tab === 'guyana_rails' ? 'nav-tab-active' : ''; ?>">Guyana Rails</a>
    <a href="<?php echo esc_url(admin_url('admin.php?page=caricove-bank&tab=provider_events')); ?>" class="nav-tab <?php echo $tab === 'provider_events' ? 'nav-tab-active' : ''; ?>">Provider Events</a>
    <a href="<?php echo esc_url(admin_url('admin.php?page=caricove-bank&tab=sellers')); ?>" class="nav-tab <?php echo $tab === 'sellers' ? 'nav-tab-active' : ''; ?>">Seller Overview</a>
    <a href="<?php echo esc_url(admin_url('admin.php?page=caricove-bank&tab=payouts')); ?>" class="nav-tab <?php echo $tab === 'payouts' ? 'nav-tab-active' : ''; ?>">Seller Payouts</a>
    <a href="<?php echo esc_url(admin_url('admin.php?page=caricove-bank&tab=refunds')); ?>" class="nav-tab <?php echo $tab === 'refunds' ? 'nav-tab-active' : ''; ?>">CX Refund Requests</a>
    <a href="<?php echo esc_url(admin_url('admin.php?page=caricove-bank&tab=platform_fronted')); ?>" class="nav-tab <?php echo $tab === 'platform_fronted' ? 'nav-tab-active' : ''; ?>">Platform Fronted</a>
    <a href="<?php echo esc_url(admin_url('admin.php?page=caricove-bank&tab=payout_requests')); ?>" class="nav-tab <?php echo $tab === 'payout_requests' ? 'nav-tab-active' : ''; ?>">Courier Payout Requests</a>
    <a href="<?php echo esc_url(admin_url('admin.php?page=caricove-bank&tab=hold')); ?>" class="nav-tab <?php echo $tab === 'hold' ? 'nav-tab-active' : ''; ?>">Held Queue</a>
    <a href="<?php echo esc_url(admin_url('admin.php?page=caricove-bank&tab=forfeited')); ?>" class="nav-tab <?php echo $tab === 'forfeited' ? 'nav-tab-active' : ''; ?>">Forfeited</a>
    <a href="<?php echo esc_url(admin_url('admin.php?page=caricove-bank&tab=courier_recovery')); ?>" class="nav-tab <?php echo $tab === 'courier_recovery' ? 'nav-tab-active' : ''; ?>">Courier Recovery</a>
</h2>

            <?php if ($tab === 'platform_wallet'): ?>
                <?php self::render_platform_wallet_tab(); ?>
            <?php endif; ?>

            <?php if ($tab === 'payment_setup'): ?>
                <?php self::render_payment_setup_tab(); ?>
            <?php endif; ?>

            <?php if ($tab === 'guyana_rails'): ?>
                <?php self::render_guyana_payment_rails_tab(); ?>
            <?php endif; ?>

            <?php if ($tab === 'provider_events'): ?>
                <?php self::render_provider_events_tab(); ?>
            <?php endif; ?>

            <?php if ($tab === 'overview'): ?>
                <h1>Caricove Bank</h1>
                <p class="description">
                    Human-readable finance on top. Canonical ledger truth underneath.
                    <br>
                    <small>
                        Bank epoch ledger ID: <?php echo esc_html((string) self::BANK_EPOCH_LEDGER_ID); ?><br>
                        Seller ledger epoch ID: <?php echo esc_html((string) self::SELLER_LEDGER_EPOCH_ID); ?><br>
                        Fallback timestamp: <?php echo esc_html(self::EPOCH_FALLBACK_CREATED_AT); ?>
                    </small>
                </p>

                <div class="cbank-grid cbank-grid--metrics">
                    <?php foreach ($metrics as $metric): ?>
                        <?php if (!empty($metric['href'])): ?>
                            <a class="cbank-card" href="<?php echo esc_url((string) $metric['href']); ?>" style="display:block;text-decoration:none;color:#eef4ff;">
                                <div class="cbank-kicker"><?php echo esc_html((string) ($metric['label'] ?? '')); ?></div>
                                <div class="cbank-value"><?php echo esc_html((string) ($metric['value'] ?? '')); ?></div>
                                <?php if (!empty($metric['help'])): ?>
                                    <div class="cbank-help"><?php echo esc_html((string) $metric['help']); ?></div>
                                <?php endif; ?>
                            </a>
                        <?php else: ?>
                            <div class="cbank-card">
                                <div class="cbank-kicker"><?php echo esc_html((string) ($metric['label'] ?? '')); ?></div>
                                <div class="cbank-value"><?php echo esc_html((string) ($metric['value'] ?? '')); ?></div>
                                <?php if (!empty($metric['help'])): ?>
                                    <div class="cbank-help"><?php echo esc_html((string) $metric['help']); ?></div>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </div>

                <?php self::render_net_platform_audit_panel(); ?>

                <div class="cbank-grid cbank-grid--two">
                    <div class="cbank-card">
<h2 style="color:#ffffff !important; 
           font-weight:600 !important;">
  Recent Money Events
</h2>                   <table class="widefat striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Event</th>
                                    <th>Shipment</th>
                                    <th>Order</th>
                                    <th>Store</th>
                                    <th>Amount</th>
                                    <th>Created</th>
                                </tr>
                            </thead>
                            <tbody>
<?php
$recent_rows = self::filtered_bank_rows([], 20);

/* ALSO SHOW SELLER-LEDGER SHIPMENT EARNINGS IN GENERAL OVERVIEW */
global $wpdb;
$seller_table = Ledger::table();

$seller_recent_rows = $wpdb->get_results(
    $wpdb->prepare(
        "SELECT
            id,
            shipment_id,
            order_id,
            vendor_id,
            gross AS amount,
            created_at
         FROM {$seller_table}
         WHERE id >= %d
           AND state IN ('pending','available','paid','reversed')
         ORDER BY created_at DESC, id DESC
         LIMIT 20",
        self::sellerEpochLedgerId()
    ),
    ARRAY_A
);

if (is_array($seller_recent_rows)) {
    foreach ($seller_recent_rows as &$sr) {
        $sr['event_type'] = 'shipment_earnings_created';
    }
    unset($sr);

    $recent_rows = array_merge($seller_recent_rows, $recent_rows);

    usort($recent_rows, static function ($a, $b) {
        $ta = strtotime((string) ($a['created_at'] ?? ''));
        $tb = strtotime((string) ($b['created_at'] ?? ''));
        if ($ta === $tb) {
            return ((int) ($b['id'] ?? 0)) <=> ((int) ($a['id'] ?? 0));
        }
        return $tb <=> $ta;
    });

    $recent_rows = array_slice($recent_rows, 0, 20);
}
?>
                                <?php if (!empty($recent_rows)): ?>
                                    <?php foreach ($recent_rows as $row): ?>
                                        <?php $vendor_id = (int) ($row['vendor_id'] ?? 0); ?>
                                        <tr
                                            class="cbank-ledger-row"
                                            data-shipment="<?php echo esc_attr((string) ($row['shipment_id'] ?? '')); ?>"
                                            data-vendor="<?php echo esc_attr((string) $vendor_id); ?>"
                                        >
                                            <td><?php echo esc_html((string) ($row['id'] ?? '')); ?></td>
                                         <td>
<?php
$event = (string) ($row['event_type'] ?? '');

$labels = [
    'shipment_earnings_created'   => 'Shipment Earnings Created',
    'reversal'                    => 'Seller Earnings Reversed Before Payout',
    'seller_deduction_created'    => 'Seller Owes Caricove',
    'customer_refund_issued'      => 'Customer Refund Sent',
    'vendor_liability_recovered'  => 'Vendor Liability Cleared From Payout',
    'seller_payout_sent'          => 'Seller Payout Sent'
];

echo esc_html($labels[$event] ?? $event);
?>
</td>
                                            <td><?php echo esc_html((string) ($row['shipment_id'] ?? '')); ?></td>
                                            <td><?php echo esc_html((string) ($row['order_id'] ?? '')); ?></td>
                                            <td><?php echo esc_html($vendor_id > 0 ? self::seller_store_name($vendor_id) : '—'); ?></td>
                                            <td><?php echo esc_html('GYD ' . number_format((float) ($row['amount'] ?? 0), 2)); ?></td>
                                            <td><?php echo esc_html((string) ($row['created_at'] ?? '')); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr><td colspan="7">No bank ledger rows found in current reporting window.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="cbank-card">
<h2 style="color:#ffffff !important;">
  Alerts
</h2>                        <ul class="cbank-alerts">
                            <?php if (!empty($alerts)): ?>
                                <?php foreach ($alerts as $alert): ?>
                                    <li>
                                        <strong><?php echo esc_html((string) ($alert['count'] ?? 0)); ?></strong>
                                        — <?php echo esc_html((string) ($alert['label'] ?? '')); ?>
                                    </li>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <li><strong>0</strong> — No alerts available.</li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            <?php endif; ?>

            <?php if ($tab === 'sellers'): ?>
                <?php
                $vendor_search  = isset($_GET['vendor_search']) ? sanitize_text_field((string) $_GET['vendor_search']) : '';
                $vendor_user    = self::resolve_vendor_from_search($vendor_search);
                $vendor_metrics = null;

                if ($vendor_user instanceof \WP_User) {
                    $vendor_metrics = self::seller_metrics((int) $vendor_user->ID);
                }
                ?>

                <h1>Seller Overview</h1>
                <p class="description">
                    Search a vendor by storefront name or vendor ID to inspect canonical seller-ledger truth inside the Bank reporting window.
                </p>

                <form method="get" style="margin:16px 0;display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
                    <input type="hidden" name="page" value="caricove-bank">
                    <input type="hidden" name="tab" value="sellers">

                    <input
                        type="text"
                        name="vendor_search"
                        value="<?php echo esc_attr($vendor_search); ?>"
                        placeholder="Search storefront or vendor ID"
                        style="min-width:320px;padding:10px 12px;border:1px solid #000;border-radius:6px;background:#fff;color:#000;"
                    >

                    <button type="submit" style="padding:10px 16px;border:1px solid #000;background:#000;color:#fff;border-radius:6px;cursor:pointer;">
                        Search
                    </button>
                </form>

                <?php if ($vendor_search !== '' && !($vendor_user instanceof \WP_User)): ?>
                    <div class="cbank-card" style="margin-top:16px;border:1px solid #000;background:#fff;color:#000;">
                        <h2>No vendor found</h2>
                        <p style="margin:0;">No vendor matched that search.</p>
                    </div>
                <?php endif; ?>

                <?php if ($vendor_user instanceof \WP_User && is_array($vendor_metrics)): ?>
                    <?php if (!empty($vendor_metrics['_unavailable'])): ?>
                        <div class="cbank-card" style="margin-top:16px;border:1px solid #000;background:#fff;color:#000;">
                            <h2>Seller ledger unavailable</h2>
                            <p style="margin:0;">The dashboard could not read the canonical Ledger class for this vendor right now. Financial values below may be incomplete until the ledger class is loaded correctly.</p>
                        </div>
                    <?php endif; ?>

                    <div class="cbank-card" style="margin-top:16px;border:1px solid #000;background:#fff;color:#000;">
                        <h2>
                            <a href="<?php echo esc_url(admin_url('admin.php?page=caricove-bank&tab=sellers&vendor_search=' . rawurlencode((string) $vendor_user->ID))); ?>" style="color:#000;text-decoration:underline;">
                                <?php echo esc_html(self::seller_store_name((int) $vendor_user->ID)); ?>
                            </a>
                        </h2>
                        <p style="margin:6px 0 0 0;"><strong>Vendor ID:</strong> <?php echo esc_html((string) $vendor_user->ID); ?></p>
                        <p style="margin:6px 0 0 0;"><strong>Payout Method:</strong> <?php echo esc_html(self::seller_payment_method_label((int) $vendor_user->ID)); ?></p>
                    </div>

                    <div class="cbank-grid cbank-grid--metrics" style="margin-top:16px;">
                        <div class="cbank-card" style="border:1px solid #000;background:#fff;color:#000;">
                            <div class="cbank-kicker">Seller Funds Clearing</div>
                            <div class="cbank-value">GYD <?php echo esc_html(number_format((float) ($vendor_metrics['pending'] ?? 0), 2)); ?></div>
                        </div>

                        <div class="cbank-card" style="border:1px solid #000;background:#fff;color:#000;">
                            <div class="cbank-kicker">Seller Funds Available</div>
                            <div class="cbank-value">GYD <?php echo esc_html(number_format((float) ($vendor_metrics['available'] ?? 0), 2)); ?></div>
                        </div>

                        <div class="cbank-card" style="border:1px solid #000;background:#fff;color:#000;">
                            <div class="cbank-kicker">Paid Out</div>
                            <div class="cbank-value">GYD <?php echo esc_html(number_format((float) ($vendor_metrics['paid'] ?? 0), 2)); ?></div>
                        </div>

                        <div class="cbank-card" style="border:1px solid #000;background:#fff;color:#000;">
                            <div class="cbank-kicker">Vendor Liability To Platform</div>
                            <div class="cbank-value">GYD <?php echo esc_html(number_format((float) ($vendor_metrics['debit_exposure'] ?? 0), 2)); ?></div>
                        </div>

                        <div class="cbank-card" style="border:1px solid #000;background:#fff;color:#000;">
                            <div class="cbank-kicker">Withdrawable Now</div>
                            <div class="cbank-value">GYD <?php echo esc_html(number_format((float) ($vendor_metrics['withdrawable_now'] ?? 0), 2)); ?></div>
                        </div>
                    </div>

                    <?php $seller_rows = self::seller_ledger_rows((int) $vendor_user->ID, 100); ?>

                    <div class="cbank-card" style="margin-top:16px;border:1px solid #000;background:#fff;color:#000;">
                        <h2 style="margin-top:0;">Canonical Seller Ledger Entries</h2>

                        <table class="widefat striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Shipment</th>
                                    <th>Order</th>
                                    <th>Ledger State</th>
                                    <th>Gross</th>
                                    <th>Commission</th>
                                    <th>Courier</th>
                                    <th>Reserve</th>
                                    <th>Net</th>
                                    <th>Delivered</th>
                                    <th>Pending Until</th>
                                    <th>Updated</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($seller_rows)): ?>
                                    <?php foreach ($seller_rows as $row): ?>
                                        <tr class="cbank-ledger-row"
                                            data-shipment="<?php echo esc_attr((string) ($row['shipment_id'] ?? '')); ?>"
                                            data-vendor="<?php echo esc_attr((string) $vendor_user->ID); ?>">
                                            <td><?php echo esc_html((string) ($row['id'] ?? '')); ?></td>
                                            <td><span style="text-decoration:underline;cursor:pointer;"><?php echo esc_html((string) ($row['shipment_id'] ?? '')); ?></span></td>
                                            <td><?php echo esc_html((string) ($row['order_id'] ?? '')); ?></td>
                                           <td>
<?php
$state = (string) ($row['state'] ?? '');

$state_labels = [
    'pending' => 'Clearing',
    'available' => 'Available For Payout',
    'paid' => 'Paid To Seller',
    'reversed' => 'Seller Earnings Reversed',
    'debit' => 'Seller Liability'
];

echo esc_html($state_labels[$state] ?? $state);
?>
</td>
                                            <td><?php echo esc_html(number_format((float) ($row['gross'] ?? 0), 2)); ?></td>
                                            <td><?php echo esc_html(number_format((float) ($row['commission'] ?? 0), 2)); ?></td>
                                            <td><?php echo esc_html(number_format((float) ($row['courier_fees'] ?? 0), 2)); ?></td>
                                            <td><?php echo esc_html(number_format((float) ($row['reserve'] ?? 0), 2)); ?></td>
                                            <td><?php echo esc_html(number_format((float) ($row['net'] ?? 0), 2)); ?></td>
                                            <td><?php echo esc_html((string) ($row['delivered_at'] ?? '')); ?></td>
                                            <td><?php echo esc_html((string) ($row['pending_until'] ?? '')); ?></td>
                                            <td><?php echo esc_html((string) ($row['updated_at'] ?? '')); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr><td colspan="12">No seller ledger rows found for this vendor in the current reporting window.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            <?php endif; ?>

            <?php if ($tab === 'payouts'): ?>
                <?php
                $payout_search = isset($_GET['payout_search']) ? sanitize_text_field((string) $_GET['payout_search']) : '';
                $payout_status = isset($_GET['payout_status']) ? sanitize_key((string) $_GET['payout_status']) : '';
                $payout_date   = isset($_GET['payout_date']) ? sanitize_text_field((string) $_GET['payout_date']) : '';

                $payout_rows = self::payout_rows([
                    'search' => $payout_search,
                    'status' => $payout_status,
                    'date'   => $payout_date,
                    'limit'  => 200,
                ]);

                $summary_cards = self::payout_summary_cards($payout_rows);
                $queue_groups  = self::group_payout_rows($payout_rows);
                ?>

                <h1>Payout Requests</h1>
                <p class="description">
                    Manual payout control surface. Sellers request payout only after funds become available. Bank evaluates live seller-ledger truth before any payment is sent.
                </p>

                <div class="cbank-grid cbank-grid--metrics" style="margin-top:16px;">
                    <?php foreach ($summary_cards as $card): ?>
                        <div class="cbank-card" style="border:1px solid #000;background:#fff;color:#000;">
                            <div class="cbank-kicker"><?php echo esc_html((string) ($card['label'] ?? '')); ?></div>
                            <div class="cbank-value"><?php echo esc_html((string) ($card['value'] ?? '')); ?></div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <form method="get" style="margin:16px 0;display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
                    <input type="hidden" name="page" value="caricove-bank">
                    <input type="hidden" name="tab" value="payouts">

                    <input
                        type="text"
                        name="payout_search"
                        value="<?php echo esc_attr($payout_search); ?>"
                        placeholder="Search storefront or vendor ID"
                        style="min-width:260px;padding:10px 12px;border:1px solid #000;border-radius:6px;background:#fff;color:#000;"
                    >

                    <select
                        name="payout_status"
                        style="padding:10px 12px;border:1px solid #000;border-radius:6px;background:#fff;color:#000;"
                    >
                        <option value="">All statuses</option>
                        <option value="requested" <?php selected($payout_status, 'requested'); ?>>requested</option>
                        <option value="queued" <?php selected($payout_status, 'queued'); ?>>queued</option>
                        <option value="sent" <?php selected($payout_status, 'sent'); ?>>sent</option>
                        <option value="failed" <?php selected($payout_status, 'failed'); ?>>failed</option>
                        <option value="denied" <?php selected($payout_status, 'denied'); ?>>denied</option>
                    </select>

                    <input
                        type="date"
                        name="payout_date"
                        value="<?php echo esc_attr($payout_date); ?>"
                        style="padding:10px 12px;border:1px solid #000;border-radius:6px;background:#fff;color:#000;"
                    >

                    <button type="submit" style="padding:10px 16px;border:1px solid #000;background:#000;color:#fff;border-radius:6px;cursor:pointer;">
                        Filter
                    </button>
                </form>

                <?php self::render_payout_table_section('Payable Now', $queue_groups['payable'] ?? []); ?>
                <?php self::render_payout_table_section('Needs Attention', $queue_groups['attention'] ?? []); ?>
                <?php self::render_payout_table_section('Legacy / Historical Open Requests', $queue_groups['legacy'] ?? []); ?>
            <?php endif; ?>

         <?php if ($tab === 'refunds'): ?>
                <?php \Caricove\Bank\BankRefundsView::render(); ?>
            <?php endif; ?>

<?php if ($tab === 'platform_fronted') : ?>
    <?php \Caricove\Bank\BankPlatformFrontedTab::render(); ?>
<?php endif; ?>

<?php if ($tab === 'payout_requests') : ?>
    <?php \Caricove\Bank\BankCourierPayoutRequestsTab::render(); ?>
<?php endif; ?>


<?php if ($tab === 'instant_payout_requests') : ?>
    <?php \Caricove\Bank\BankCourierPayoutRequestsTab::render(); ?>
<?php endif; ?>

<?php if ($tab === 'hold') : ?>
    <?php \Caricove\Bank\BankCourierHeldQueueTab::render(); ?>
<?php endif; ?>

<?php if ($tab === 'forfeited') : ?>
    <?php \Caricove\Bank\BankCourierForfeitedTab::render(); ?>
<?php endif; ?>

<?php if ($tab === 'courier_recovery') : ?>
    <?php \Caricove\Bank\BankCourierRecoveryTab::render(); ?>
<?php endif; ?>
        </div>
        <?php
    }


    private static function render_platform_wallet_tab(): void
    {
        $wallet = self::platform_wallet_snapshot();
        $status = (string) ($wallet['status'] ?? 'blocked');
        $status_label = (string) ($wallet['status_label'] ?? 'Blocked');
        $reason = (string) ($wallet['reason'] ?? 'Provider balance is not connected yet.');
        $status_bg = $status === 'safe' ? 'rgba(23,202,130,.18)' : ($status === 'review' ? 'rgba(255,193,7,.20)' : 'rgba(255,76,96,.18)');
        $status_border = $status === 'safe' ? 'rgba(23,202,130,.55)' : ($status === 'review' ? 'rgba(255,193,7,.55)' : 'rgba(255,76,96,.55)');
        ?>
        <style>
            .cc-wallet-hero{position:relative;overflow:hidden;border-radius:26px;padding:28px;margin:18px 0;background:radial-gradient(circle at 14% 18%,rgba(0,216,255,.35),transparent 30%),radial-gradient(circle at 88% 5%,rgba(255,209,102,.24),transparent 24%),linear-gradient(135deg,#07152e 0%,#112b57 48%,#071222 100%);box-shadow:0 24px 70px rgba(0,0,0,.28),inset 0 0 0 1px rgba(255,255,255,.14);color:#eef7ff}
            .cc-wallet-hero:before{content:"";position:absolute;inset:-2px;background:linear-gradient(115deg,transparent 0%,rgba(255,255,255,.14) 36%,transparent 52%);transform:translateX(-70%);animation:ccWalletSheen 6s ease-in-out infinite;pointer-events:none}
            @keyframes ccWalletSheen{0%,65%{transform:translateX(-75%)}100%{transform:translateX(95%)}}
            .cc-wallet-top{position:relative;display:grid;grid-template-columns:minmax(0,1.25fr) minmax(280px,.75fr);gap:20px;align-items:stretch}
            .cc-wallet-title{margin:0 0 7px;font-size:30px;line-height:1.05;color:#fff;text-shadow:0 0 18px rgba(97,209,255,.36)}
            .cc-wallet-sub{margin:0;color:#c8e5ff;max-width:760px;font-size:14px;line-height:1.55}
            .cc-wallet-big{font-size:44px;line-height:1;font-weight:900;letter-spacing:.02em;margin:16px 0 4px;color:#fff}
            .cc-wallet-pill{display:inline-flex;align-items:center;gap:8px;border-radius:999px;padding:9px 13px;font-weight:800;letter-spacing:.04em;text-transform:uppercase;border:1px solid <?php echo esc_html($status_border); ?>;background:<?php echo esc_html($status_bg); ?>;color:#fff}
            .cc-wallet-glass{background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.14);border-radius:22px;padding:16px;box-shadow:inset 0 0 22px rgba(255,255,255,.04)}
            .cc-wallet-micro{font-size:12px;color:#b9d9ff;margin-top:8px;line-height:1.45}
            .cc-wallet-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px;margin:16px 0}
            .cc-wallet-card{background:linear-gradient(150deg,#081a35,#122d59);border:1px solid rgba(255,255,255,.13);border-radius:20px;padding:18px;color:#eef7ff;box-shadow:0 18px 42px rgba(0,0,0,.18)}
            .cc-wallet-kicker{text-transform:uppercase;letter-spacing:.16em;font-size:12px;color:#b9d9ff;font-weight:800;margin-bottom:8px}
            .cc-wallet-value{font-size:22px;font-weight:900;color:#fff}
            .cc-wallet-note{font-size:12px;color:#cde7ff;margin-top:8px;line-height:1.45}
            .cc-wallet-section{background:#fff;color:#0b1220;border:1px solid #d6e1ee;border-radius:20px;padding:18px;margin-top:16px;box-shadow:0 12px 34px rgba(8,24,54,.08)}
            .cc-wallet-section h2,.cc-wallet-section h3{color:#071225!important;margin-top:0}
            .cc-wallet-table{width:100%;border-collapse:collapse;min-width:760px}
            .cc-wallet-table th{background:#071225;color:#fff;text-align:left;padding:11px;font-size:12px;text-transform:uppercase;letter-spacing:.08em}
            .cc-wallet-table td{padding:11px;border-bottom:1px solid #e6eef7;vertical-align:top}
            .cc-wallet-rail{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin-top:12px}
            .cc-wallet-rail-card{border-radius:18px;border:1px solid #d6e1ee;background:linear-gradient(180deg,#fff,#f5f9ff);padding:14px}
            .cc-wallet-rail-card strong{display:block;color:#071225;margin:9px 0 6px}
            .cc-wallet-badge{display:inline-flex;border-radius:999px;padding:5px 9px;font-size:11px;font-weight:800;text-transform:uppercase;letter-spacing:.05em;background:#edf4ff;color:#183b72;border:1px solid #cdddf2}
            .cc-wallet-badge.bad{background:#fff0f2;color:#9b1024;border-color:#ffc9d1}
            .cc-wallet-badge.warn{background:#fff8e6;color:#7a5200;border-color:#ffe29a}
            .cc-wallet-badge.good{background:#ebfff6;color:#05603a;border-color:#a6f4c5}
            @media(max-width:1200px){.cc-wallet-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.cc-wallet-rail{grid-template-columns:repeat(2,minmax(0,1fr))}.cc-wallet-top{grid-template-columns:1fr}}
            @media(max-width:720px){.cc-wallet-grid,.cc-wallet-rail{grid-template-columns:1fr}.cc-wallet-big{font-size:34px}.cc-wallet-title{font-size:24px}}
        </style>

        <h1>Platform Wallet</h1>
        <p class="description">Spendable platform cash only. This tab does not move money yet; it protects the future withdrawal button by comparing ledger-safe Caricove money against real provider cash.</p>

        <div class="cc-wallet-hero">
            <div class="cc-wallet-top">
                <div>
                    <h2 class="cc-wallet-title">Spendable Platform Cash</h2>
                    <p class="cc-wallet-sub">This is the future takeout/KFC-money gate. It uses the lower of internal safe revenue and provider available balance, then subtracts the emergency reserve. Seller funds, courier funds, refund reserves, pending money, and unresolved debt are not spendable by the platform owner.</p>
                    <div class="cc-wallet-big"><?php echo esc_html(self::money_label((float) ($wallet['spendable_platform_cash'] ?? 0))); ?></div>
                    <span class="cc-wallet-pill"><?php echo esc_html($status_label); ?></span>
                    <div class="cc-wallet-micro"><?php echo esc_html($reason); ?></div>
                </div>
                <div class="cc-wallet-glass">
                    <div class="cc-wallet-kicker">Provider Sync</div>
                    <div class="cc-wallet-value"><?php echo esc_html((string) ($wallet['provider_label'] ?? 'Not connected')); ?></div>
                    <div class="cc-wallet-micro">Mode: <?php echo esc_html((string) ($wallet['provider_mode'] ?? 'not wired')); ?></div>
                    <div class="cc-wallet-micro">Status: <?php echo esc_html((string) ($wallet['provider_status_label'] ?? 'Not wired')); ?></div>
                    <div class="cc-wallet-micro">Target currency: <?php echo esc_html((string) ($wallet['provider_target_currency'] ?? 'GYD')); ?></div>
                    <div class="cc-wallet-micro">Last sync: <?php echo esc_html((string) ($wallet['provider_synced_at'] ?? 'Never')); ?></div>
                    <div class="cc-wallet-micro">Expires: <?php echo esc_html((string) ($wallet['provider_expires_at'] ?? '') ?: 'Not synced'); ?></div>
                    <?php if (!empty($wallet['provider_status_message'])): ?><div class="cc-wallet-micro"><?php echo esc_html((string) $wallet['provider_status_message']); ?></div><?php endif; ?>
                    <div class="cc-wallet-micro">Hard takeout gate: <?php echo esc_html(self::money_label((float) ($wallet['hard_takeout_gate'] ?? 0))); ?></div>
                </div>
            </div>
        </div>

        <div class="cc-wallet-grid">
            <div class="cc-wallet-card"><div class="cc-wallet-kicker">Internal Safe Revenue</div><div class="cc-wallet-value"><?php echo esc_html(self::money_label((float) ($wallet['internal_safe_revenue'] ?? 0))); ?></div><div class="cc-wallet-note">Caricove ledger-safe revenue after reserve math.</div></div>
            <div class="cc-wallet-card"><div class="cc-wallet-kicker">Provider Available Cash</div><div class="cc-wallet-value"><?php echo esc_html(self::money_label((float) ($wallet['provider_available'] ?? 0))); ?></div><div class="cc-wallet-note">Real provider/bank cash available now. Zero until Stripe/PayPal/bank mirror is wired.</div></div>
            <div class="cc-wallet-card"><div class="cc-wallet-kicker">Provider Pending / Withheld</div><div class="cc-wallet-value"><?php echo esc_html(self::money_label((float) ($wallet['provider_pending_withheld'] ?? 0))); ?></div><div class="cc-wallet-note">Not spendable. Pending, held, or withheld provider money stays locked.</div></div>
            <div class="cc-wallet-card"><div class="cc-wallet-kicker">Emergency Reserve</div><div class="cc-wallet-value"><?php echo esc_html(self::money_label((float) ($wallet['emergency_reserve'] ?? 0))); ?></div><div class="cc-wallet-note">Extra owner safety buffer. Configure later when provider rails are active.</div></div>
        </div>

        <div class="cc-wallet-section">
            <h2>Money Waterfall</h2>
            <p>This is the boring brutal math that prevents Caricove from spending someone else’s money.</p>
            <div style="overflow:auto;">
                <table class="cc-wallet-table">
                    <thead><tr><th>Step</th><th>Amount</th><th>Rule</th></tr></thead>
                    <tbody>
                        <?php foreach ((array) ($wallet['waterfall'] ?? []) as $row): ?>
                            <tr>
                                <td><strong><?php echo esc_html((string) ($row['step'] ?? '')); ?></strong></td>
                                <td><?php echo esc_html(self::money_label((float) ($row['amount'] ?? 0))); ?></td>
                                <td><?php echo esc_html((string) ($row['rule'] ?? '')); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="cc-wallet-section">
            <h2>Party Wallets / Who The Money Belongs To</h2>
            <div class="cc-wallet-rail">
                <?php foreach ((array) ($wallet['party_wallets'] ?? []) as $rail): ?>
                    <div class="cc-wallet-rail-card">
                        <span class="cc-wallet-badge <?php echo esc_attr((string) ($rail['class'] ?? '')); ?>"><?php echo esc_html((string) ($rail['badge'] ?? 'Locked')); ?></span>
                        <strong><?php echo esc_html((string) ($rail['label'] ?? '')); ?></strong>
                        <div style="font-size:22px;font-weight:900;color:#071225;"><?php echo esc_html(self::money_label((float) ($rail['amount'] ?? 0))); ?></div>
                        <p style="margin:8px 0 0;color:#36506f;line-height:1.45;"><?php echo esc_html((string) ($rail['note'] ?? '')); ?></p>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="cc-wallet-section">
            <h2>Payment Rails Wiring Map</h2>
            <p>This is the clean route for wiring real cash without letting any party’s money disappear.</p>
            <div style="overflow:auto;">
                <table class="cc-wallet-table">
                    <thead><tr><th>Party</th><th>Money movement</th><th>Current gate</th><th>Next provider wire</th></tr></thead>
                    <tbody>
                        <?php foreach ((array) ($wallet['rails'] ?? []) as $rail): ?>
                            <tr>
                                <td><strong><?php echo esc_html((string) ($rail['party'] ?? '')); ?></strong></td>
                                <td><?php echo esc_html((string) ($rail['movement'] ?? '')); ?></td>
                                <td><?php echo esc_html((string) ($rail['gate'] ?? '')); ?></td>
                                <td><?php echo esc_html((string) ($rail['next'] ?? '')); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php
    }


    private static function render_payment_setup_tab(): void
    {
        $saved = (array) get_option('caricove_bank_payment_setup_v1', []);
        $notice = '';

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cc_bank_payment_setup_action'])) {
            if ((!current_user_can('manage_woocommerce') && !current_user_can('manage_options')) || !isset($_POST['caricove_bank_payment_setup_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash((string) $_POST['caricove_bank_payment_setup_nonce'])), 'caricove_bank_payment_setup_save')) {
                $notice = '<div class="notice notice-error"><p>Payment setup was not saved. Refresh the page and try again.</p></div>';
            } else {
                $allowed = [
                    'preferred_provider' => ['not_selected','mmg','card_gateway','wipay','republic_epay','scotia_ecom','stripe','paypal','manual_bank','local_bank'],
                    'provider_environment' => ['not_selected','test','live'],
                    'customer_checkout_rail' => ['not_selected','mmg_checkout','card_gateway','wipay_checkout','woocommerce_gateway','stripe_checkout','paypal_checkout','manual_bank_hidden'],
                    'seller_payout_rail' => ['not_selected','mmg_or_bank','bank_payout','manual_bank','stripe_connect','paypal_payouts'],
                    'courier_payout_rail' => ['not_selected','mmg_or_bank','bank_payout','manual_bank','stripe_connect','paypal_payouts'],
                    'owner_takeout_rail' => ['not_selected','owner_bank','manual_bank','stripe_payout','paypal_transfer'],
                ];

                $next = [];
                foreach ($allowed as $key => $choices) {
                    $value = isset($_POST[$key]) ? sanitize_key((string) wp_unslash($_POST[$key])) : 'not_selected';
                    $next[$key] = in_array($value, $choices, true) ? $value : 'not_selected';
                }
                $next['provider_balance_policy'] = 'api_or_webhook_snapshot_only';
                $next['stores_secrets_in_dashboard'] = false;
                $next['notes'] = isset($_POST['payment_setup_notes']) ? sanitize_textarea_field(wp_unslash((string) $_POST['payment_setup_notes'])) : '';
                $next['updated_at'] = current_time('mysql');
                $next['updated_by'] = get_current_user_id();
                update_option('caricove_bank_payment_setup_v1', $next, false);

                $reserve_raw = isset($_POST['emergency_reserve']) ? preg_replace('/[^0-9.\-]/', '', (string) wp_unslash($_POST['emergency_reserve'])) : '0';
                update_option('caricove_bank_platform_wallet_emergency_reserve_v1', max(0.0, is_numeric($reserve_raw) ? (float) $reserve_raw : 0.0), false);

                $saved = $next;
                $notice = '<div class="notice notice-success"><p>Payment setup saved. No real money moved and no provider secret was stored.</p></div>';
            }
        }

        if (isset($_GET['provider_sync'])) {
            $sync_status = sanitize_key((string) wp_unslash($_GET['provider_sync']));
            if ($sync_status === 'synced') {
                $notice .= '<div class="notice notice-success"><p>Provider balance synced. Platform Wallet now has a fresh read-only cash snapshot.</p></div>';
            } elseif ($sync_status === 'failed') {
                $msg = isset($_GET['provider_sync_msg']) ? sanitize_text_field(rawurldecode((string) wp_unslash($_GET['provider_sync_msg']))) : 'Provider balance sync failed.';
                $notice .= '<div class="notice notice-error"><p>' . esc_html($msg) . '</p></div>';
            }
        }

        $provider = (string) ($saved['preferred_provider'] ?? 'not_selected');
        $env = (string) ($saved['provider_environment'] ?? 'not_selected');
        $reserve = max(0.0, (float) get_option('caricove_bank_platform_wallet_emergency_reserve_v1', 0));
        $provider_snapshot = self::provider_balance_snapshot();
        $balance_wired = !empty($provider_snapshot['connected']);
        $balance_status_label = (string) ($provider_snapshot['status_label'] ?? ($balance_wired ? 'Synced' : 'Blocked'));
        $balance_status_message = (string) ($provider_snapshot['status_message'] ?? '');
        $stripe_key_status = class_exists(__NAMESPACE__ . '\\BankProviderMirror')
            ? BankProviderMirror::stripe_key_status($env)
            : ['ready' => (self::ccbank_constant_ready('CARICOVE_STRIPE_SECRET_KEY') || self::ccbank_constant_ready('STRIPE_SECRET_KEY')), 'source' => '', 'masked' => '', 'mode' => $env];
        $stripe_secret = !empty($stripe_key_status['ready']);
        $paypal_secret = (self::ccbank_constant_ready('CARICOVE_PAYPAL_CLIENT_ID') || self::ccbank_constant_ready('PAYPAL_CLIENT_ID')) && (self::ccbank_constant_ready('CARICOVE_PAYPAL_SECRET') || self::ccbank_constant_ready('PAYPAL_SECRET'));
        $stripe_webhook_status = class_exists(__NAMESPACE__ . '\\BankProviderEvents') ? BankProviderEvents::stripe_webhook_secret_status() : ['ready' => false, 'source' => '', 'masked' => ''];
        $webhook_ready = !empty($stripe_webhook_status['ready']) || self::ccbank_constant_ready('CARICOVE_PAYPAL_WEBHOOK_ID') || self::ccbank_constant_ready('PAYPAL_WEBHOOK_ID');
        $secret_ready = ($provider === 'stripe' && $stripe_secret) || ($provider === 'paypal' && $paypal_secret) || in_array($provider, ['manual_bank','local_bank'], true);

        $provider_labels = ['not_selected'=>'Not selected','mmg'=>'MMG Checkout','card_gateway'=>'Card Gateway','wipay'=>'WiPay','republic_epay'=>'Republic EPay / local bank e-commerce','scotia_ecom'=>'Scotia eCom+ / local bank e-commerce','stripe'=>'Stripe dev/future rail','paypal'=>'PayPal backup','manual_bank'=>'Manual bank fallback','local_bank'=>'Local bank/provider'];
        $customer_labels = ['not_selected'=>'Not selected','mmg_checkout'=>'MMG Checkout','card_gateway'=>'Card Gateway','wipay_checkout'=>'WiPay checkout','woocommerce_gateway'=>'Existing WooCommerce gateway','stripe_checkout'=>'Stripe checkout/payment intent','paypal_checkout'=>'PayPal checkout','manual_bank_hidden'=>'Manual bank hidden fallback'];
        $payout_labels = ['not_selected'=>'Not selected','mmg_or_bank'=>'MMG or bank payout profile later','bank_payout'=>'Bank payout profile later','manual_bank'=>'Manual bank payout','stripe_connect'=>'Stripe connected account','paypal_payouts'=>'PayPal payouts'];
        $owner_labels = ['not_selected'=>'Not selected','owner_bank'=>'Owner bank profile later','manual_bank'=>'Manual owner bank transfer','stripe_payout'=>'Stripe platform payout','paypal_transfer'=>'PayPal/bank transfer'];
        ?>
        <style>
            .cc-pay-hero{border-radius:26px;padding:26px;margin:18px 0;background:radial-gradient(circle at 18% 15%,rgba(0,216,255,.30),transparent 30%),linear-gradient(135deg,#061225 0%,#102a55 52%,#06101f 100%);box-shadow:0 24px 70px rgba(0,0,0,.24),inset 0 0 0 1px rgba(255,255,255,.14);color:#eef7ff}.cc-pay-hero h1{margin:0 0 8px;color:#fff!important}.cc-pay-sub{max-width:900px;color:#c8e5ff;line-height:1.55;margin:0}.cc-pay-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px;margin:16px 0}.cc-pay-card{background:linear-gradient(150deg,#081a35,#122d59);border:1px solid rgba(255,255,255,.13);border-radius:20px;padding:17px;color:#eef7ff;box-shadow:0 18px 42px rgba(0,0,0,.16)}.cc-pay-kicker{text-transform:uppercase;letter-spacing:.14em;font-size:11px;color:#b9d9ff;font-weight:800;margin-bottom:8px}.cc-pay-value{font-size:21px;font-weight:900;color:#fff;line-height:1.2}.cc-pay-note{font-size:12px;color:#cde7ff;margin-top:8px;line-height:1.45}.cc-pay-section{background:#fff;color:#0b1220;border:1px solid #d6e1ee;border-radius:20px;padding:18px;margin-top:16px;box-shadow:0 12px 34px rgba(8,24,54,.08)}.cc-pay-section h2,.cc-pay-section h3{color:#071225!important;margin-top:0}.cc-pay-table{width:100%;border-collapse:collapse;min-width:760px}.cc-pay-table th{background:#071225;color:#fff;text-align:left;padding:11px;font-size:12px;text-transform:uppercase;letter-spacing:.08em}.cc-pay-table td{padding:11px;border-bottom:1px solid #e6eef7;vertical-align:top}.cc-pay-badge{display:inline-flex;border-radius:999px;padding:5px 9px;font-size:11px;font-weight:900;text-transform:uppercase;letter-spacing:.05em;background:#fff8e6;color:#7a5200;border:1px solid #ffe29a}.cc-pay-badge.good{background:#ebfff6;color:#05603a;border-color:#a6f4c5}.cc-pay-badge.bad{background:#fff0f2;color:#9b1024;border-color:#ffc9d1}.cc-pay-form-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}.cc-pay-field label{display:block;font-weight:800;color:#071225;margin-bottom:6px}.cc-pay-field select,.cc-pay-field input,.cc-pay-field textarea{width:100%;max-width:100%;border:1px solid #cdddf2;border-radius:12px;padding:10px;background:#f8fbff;color:#071225}.cc-pay-field small{display:block;color:#36506f;margin-top:6px;line-height:1.4}@media(max-width:1200px){.cc-pay-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.cc-pay-form-grid{grid-template-columns:1fr}}@media(max-width:720px){.cc-pay-grid{grid-template-columns:1fr}}
        </style>
        <?php echo wp_kses_post($notice); ?>
        <div class="cc-pay-hero"><h1>Payment Setup</h1><p class="cc-pay-sub">Phase 2C wires the read-only provider balance mirror and keeps preparing the payment rails for customer payments, seller payouts, courier payouts, and owner takeout. It does not move money, does not store provider secrets, and keeps Platform Wallet withdrawals locked until real provider balance is fresh and reconciled.</p></div>
        <div class="cc-pay-grid">
            <div class="cc-pay-card"><div class="cc-pay-kicker">Preferred Provider</div><div class="cc-pay-value"><?php echo esc_html($provider_labels[$provider] ?? 'Not selected'); ?></div><div class="cc-pay-note">Main rail for the first real-cash integration.</div></div>
            <div class="cc-pay-card"><div class="cc-pay-kicker">Provider Secrets</div><div class="cc-pay-value"><?php echo esc_html($secret_ready ? 'Ready' : 'Missing'); ?></div><div class="cc-pay-note">Secrets must live in server constants/wp-config, not this screen. <?php if ($provider === 'stripe' && !empty($stripe_key_status['source'])): ?>Source: <?php echo esc_html((string) $stripe_key_status['source']); ?><?php endif; ?></div></div>
            <div class="cc-pay-card"><div class="cc-pay-kicker">Balance Mirror</div><div class="cc-pay-value"><?php echo esc_html($balance_status_label); ?></div><div class="cc-pay-note">Last sync: <?php echo esc_html((string) ($provider_snapshot['synced_at'] ?? 'Never')); ?>. Provider available cash is required before spendable cash unlocks.</div></div>
            <div class="cc-pay-card"><div class="cc-pay-kicker">Emergency Reserve</div><div class="cc-pay-value"><?php echo esc_html(self::money_label($reserve)); ?></div><div class="cc-pay-note">Extra buffer removed from owner takeout.</div></div>
        </div>
        <div class="cc-pay-section"><h2>Payment Rail Controls</h2><p>These settings are safe prep only. They do not create charges, payouts, transfers, refunds, or withdrawals.</p><form method="post"><?php wp_nonce_field('caricove_bank_payment_setup_save', 'caricove_bank_payment_setup_nonce'); ?><input type="hidden" name="cc_bank_payment_setup_action" value="save"><div class="cc-pay-form-grid">
            <div class="cc-pay-field"><label>Preferred provider</label><select name="preferred_provider"><?php self::ccbank_options($provider_labels, $provider); ?></select><small>Recommended first: Stripe if your entity/currency/country fit; PayPal/local bank as fallback.</small></div>
            <div class="cc-pay-field"><label>Environment</label><select name="provider_environment"><?php self::ccbank_options(['not_selected'=>'Not selected','test'=>'Test / sandbox','live'=>'Live'], $env); ?></select><small>Use test/sandbox until every money event reconciles.</small></div>
            <div class="cc-pay-field"><label>Customer checkout rail</label><select name="customer_checkout_rail"><?php self::ccbank_options($customer_labels, (string) ($saved['customer_checkout_rail'] ?? 'not_selected')); ?></select><small>Must store provider payment IDs on each order.</small></div>
            <div class="cc-pay-field"><label>Seller payout rail</label><select name="seller_payout_rail"><?php self::ccbank_options($payout_labels, (string) ($saved['seller_payout_rail'] ?? 'not_selected')); ?></select><small>Seller money is protected and never platform spendable.</small></div>
            <div class="cc-pay-field"><label>Courier payout rail</label><select name="courier_payout_rail"><?php self::ccbank_options($payout_labels, (string) ($saved['courier_payout_rail'] ?? 'not_selected')); ?></select><small>Same-courier debt offsets before courier payout leaves.</small></div>
            <div class="cc-pay-field"><label>Owner takeout rail</label><select name="owner_takeout_rail"><?php self::ccbank_options($owner_labels, (string) ($saved['owner_takeout_rail'] ?? 'not_selected')); ?></select><small>Owner withdrawal only from Platform Wallet hard gate.</small></div>
            <div class="cc-pay-field"><label>Emergency reserve (GYD)</label><input name="emergency_reserve" value="<?php echo esc_attr(number_format($reserve, 2, '.', '')); ?>" inputmode="decimal"><small>Optional extra KFC-money safety buffer.</small></div>
            <div class="cc-pay-field"><label>Notes</label><textarea name="payment_setup_notes" rows="3"><?php echo esc_textarea((string) ($saved['notes'] ?? '')); ?></textarea><small>Never paste secret keys here.</small></div>
        </div><p style="margin-top:14px"><button type="submit" class="button button-primary">Save Payment Setup</button></p></form></div>
        <div class="cc-pay-section"><h2>Provider Balance Mirror</h2><p>This is Phase 2C: read-only proof of real provider cash. It fetches balances only; it does not create charges, refunds, payouts, transfers, or withdrawals.</p>
            <div class="cc-pay-form-grid">
                <div class="cc-pay-field"><label>Mirror status</label><div class="cc-pay-value" style="color:#071225;font-size:18px"><?php echo esc_html($balance_status_label); ?></div><small><?php echo esc_html($balance_status_message ?: 'No provider cash proof yet.'); ?></small></div>
                <div class="cc-pay-field"><label>Provider available counted</label><div class="cc-pay-value" style="color:#071225;font-size:18px"><?php echo esc_html(self::money_label((float) ($provider_snapshot['available'] ?? 0))); ?></div><small>Only the store currency is counted toward KFC money. Raw available: <?php echo esc_html(self::provider_currency_map_label((array) ($provider_snapshot['available_by_currency'] ?? []))); ?>.</small></div>
                <div class="cc-pay-field"><label>Provider pending counted</label><div class="cc-pay-value" style="color:#071225;font-size:18px"><?php echo esc_html(self::money_label((float) ($provider_snapshot['pending'] ?? 0))); ?></div><small>Pending provider funds are not spendable. Raw pending: <?php echo esc_html(self::provider_currency_map_label((array) ($provider_snapshot['pending_by_currency'] ?? []))); ?>.</small></div>
                <div class="cc-pay-field"><label>Sync action</label><?php if (class_exists(__NAMESPACE__ . '\\BankProviderMirror') && $provider === 'stripe' && $stripe_secret): ?><?php echo BankProviderMirror::sync_button_html('payment_setup'); ?><?php elseif ($provider !== 'stripe'): ?><small>This provider balance mirror is adapter-specific. For Guyana rails, Platform Wallet stays locked until the MMG/card gateway adapter proves available cash or settlement proof. Stripe sync remains dev/future only.</small><?php else: ?><small>Add a Stripe read-only/restricted key in wp-config.php/server environment, then sync. Never paste keys into this dashboard.</small><?php endif; ?></div>
            </div>
        </div>
        <div class="cc-pay-section"><h2>Readiness Gates</h2><div style="overflow:auto"><table class="cc-pay-table"><thead><tr><th>Gate</th><th>Status</th><th>Meaning</th></tr></thead><tbody>
            <tr><td><strong>Rail selected</strong></td><td><span class="cc-pay-badge <?php echo esc_attr(($provider !== 'not_selected' && $env !== 'not_selected') ? 'good' : 'bad'); ?>"><?php echo esc_html(($provider !== 'not_selected' && $env !== 'not_selected') ? 'Ready' : 'Blocked'); ?></span></td><td>Choose provider and test/live environment before adapter wiring.</td></tr>
            <tr><td><strong>Provider secrets</strong></td><td><span class="cc-pay-badge <?php echo esc_attr($secret_ready ? 'good' : 'bad'); ?>"><?php echo esc_html($secret_ready ? 'Ready' : 'Missing'); ?></span></td><td>Secrets should be placed in wp-config/server constants, never saved in this dashboard.</td></tr>
            <tr><td><strong>Webhook proof</strong></td><td><span class="cc-pay-badge <?php echo esc_attr($webhook_ready ? 'good' : ''); ?>"><?php echo esc_html($webhook_ready ? 'Ready' : 'Pending'); ?></span></td><td>Webhook signatures must be verified before refunds/payouts become automated truth.</td></tr>
            <tr><td><strong>Provider balance mirror</strong></td><td><span class="cc-pay-badge <?php echo esc_attr($balance_wired ? 'good' : 'bad'); ?>"><?php echo esc_html($balance_wired ? 'Fresh' : $balance_status_label); ?></span></td><td><?php echo esc_html($balance_status_message ?: 'Platform Wallet spendable cash stays zero until provider available balance is synced.'); ?></td></tr>
            <tr><td><strong>Owner takeout</strong></td><td><span class="cc-pay-badge">Locked</span></td><td>No withdrawal button is created in Phase 2C.</td></tr>
        </tbody></table></div></div>
        <?php
    }

    private static function render_guyana_payment_rails_tab(): void
    {
        if (!class_exists(__NAMESPACE__ . '\\BankPaymentRails')) {
            echo '<div class="notice notice-error"><p>BankPaymentRails.php is not loaded. Recheck bank-loader.php.</p></div>';
            return;
        }

        $settings = BankPaymentRails::settings();
        $choices = BankPaymentRails::choices();
        $notice = '';
        if (isset($_GET['rails_saved']) && sanitize_key((string) wp_unslash($_GET['rails_saved'])) === '1') {
            $notice = '<div class="notice notice-success"><p>Guyana payment rails saved. No money moved and no customer checkout changed yet.</p></div>';
        }

        $primary = (string) ($settings['primary_checkout_rail'] ?? 'mmg');
        $secondary = (string) ($settings['secondary_checkout_rail'] ?? 'card_gateway');
        $card_candidate = (string) ($settings['card_gateway_candidate'] ?? 'not_selected');
        $mmg_status = (string) ($settings['mmg_status'] ?? 'not_contacted');
        $card_status = (string) ($settings['card_gateway_status'] ?? 'not_contacted');
        $proof_mode = (string) ($settings['provider_proof_mode'] ?? 'webhook_or_api_required');
        ?>
        <style>
            .cc-gy-hero{position:relative;overflow:hidden;border-radius:28px;padding:28px;margin:18px 0;background:radial-gradient(circle at 14% 18%,rgba(0,216,255,.34),transparent 30%),radial-gradient(circle at 86% 8%,rgba(98,255,211,.20),transparent 28%),linear-gradient(135deg,#061225 0%,#112d58 54%,#06101f 100%);box-shadow:0 26px 74px rgba(0,0,0,.27),inset 0 0 0 1px rgba(255,255,255,.14);color:#eef7ff}.cc-gy-hero:before{content:"";position:absolute;inset:-2px;background:linear-gradient(115deg,transparent 0%,rgba(255,255,255,.13) 36%,transparent 52%);transform:translateX(-70%);animation:ccGySheen 6s ease-in-out infinite;pointer-events:none}@keyframes ccGySheen{0%,65%{transform:translateX(-75%)}100%{transform:translateX(95%)}}
            .cc-gy-hero h1{position:relative;margin:0 0 8px;color:#fff!important;font-size:30px;line-height:1.1;text-shadow:0 0 18px rgba(97,209,255,.35)}.cc-gy-sub{position:relative;max-width:980px;color:#c8e5ff;line-height:1.55;margin:0}.cc-gy-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px;margin:16px 0}.cc-gy-card{background:linear-gradient(150deg,#081a35,#122d59);border:1px solid rgba(255,255,255,.13);border-radius:20px;padding:17px;color:#eef7ff;box-shadow:0 18px 42px rgba(0,0,0,.16)}.cc-gy-kicker{text-transform:uppercase;letter-spacing:.14em;font-size:11px;color:#b9d9ff;font-weight:900;margin-bottom:8px}.cc-gy-value{font-size:21px;font-weight:900;color:#fff;line-height:1.2}.cc-gy-note{font-size:12px;color:#cde7ff;margin-top:8px;line-height:1.45}.cc-gy-section{background:#fff;color:#0b1220;border:1px solid #d6e1ee;border-radius:20px;padding:18px;margin-top:16px;box-shadow:0 12px 34px rgba(8,24,54,.08)}.cc-gy-section h2,.cc-gy-section h3{color:#071225!important;margin-top:0}.cc-gy-table{width:100%;border-collapse:collapse;min-width:860px}.cc-gy-table th{background:#071225;color:#fff;text-align:left;padding:11px;font-size:12px;text-transform:uppercase;letter-spacing:.08em}.cc-gy-table td{padding:11px;border-bottom:1px solid #e6eef7;vertical-align:top}.cc-gy-badge{display:inline-flex;border-radius:999px;padding:5px 9px;font-size:11px;font-weight:900;text-transform:uppercase;letter-spacing:.05em;background:#fff8e6;color:#7a5200;border:1px solid #ffe29a}.cc-gy-badge.good{background:#ebfff6;color:#05603a;border-color:#a6f4c5}.cc-gy-badge.bad{background:#fff0f2;color:#9b1024;border-color:#ffc9d1}.cc-gy-badge.warn{background:#fff8e6;color:#7a5200;border-color:#ffe29a}.cc-gy-form-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}.cc-gy-field label{display:block;font-weight:900;color:#071225;margin-bottom:6px}.cc-gy-field select,.cc-gy-field input,.cc-gy-field textarea{width:100%;max-width:100%;border:1px solid #cdddf2;border-radius:12px;padding:10px;background:#f8fbff;color:#071225}.cc-gy-field small{display:block;color:#36506f;margin-top:6px;line-height:1.4}.cc-gy-lock{border-radius:18px;padding:14px;background:linear-gradient(135deg,#fff0f2,#fff8e6);border:1px solid #ffd1d9;color:#4d111a;font-weight:800}.cc-gy-questions{columns:2;column-gap:24px;margin:0;padding-left:18px}.cc-gy-questions li{break-inside:avoid;margin:0 0 9px;color:#243b59;line-height:1.45}@media(max-width:1200px){.cc-gy-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.cc-gy-form-grid{grid-template-columns:1fr}.cc-gy-questions{columns:1}}@media(max-width:720px){.cc-gy-grid{grid-template-columns:1fr}.cc-gy-hero h1{font-size:24px}}
        </style>
        <?php echo wp_kses_post($notice); ?>
        <div class="cc-gy-hero">
            <h1>Guyana Payment Rails</h1>
            <p class="cc-gy-sub">Phase 2C-GY replaces Stripe-first thinking with a Guyana-first payment map: MMG for local fast trust, a card gateway race for frictionless card checkout, manual bank as hidden fallback only, and COD disabled. This is still read-only planning/proof infrastructure. No money moves here.</p>
        </div>

        <div class="cc-gy-grid">
            <div class="cc-gy-card"><div class="cc-gy-kicker">Primary Checkout</div><div class="cc-gy-value"><?php echo esc_html(BankPaymentRails::label_for('primary_checkout_rail', $primary)); ?></div><div class="cc-gy-note">Recommended doctrine: MMG first for Guyana-local trust.</div></div>
            <div class="cc-gy-card"><div class="cc-gy-kicker">Card Candidate</div><div class="cc-gy-value"><?php echo esc_html(BankPaymentRails::label_for('card_gateway_candidate', $card_candidate)); ?></div><div class="cc-gy-note">WiPay / bank e-commerce / MPGS/NMI/CyberSource/KnitPay candidate race.</div></div>
            <div class="cc-gy-card"><div class="cc-gy-kicker">Proof Mode</div><div class="cc-gy-value"><?php echo esc_html(BankPaymentRails::label_for('provider_proof_mode', $proof_mode)); ?></div><div class="cc-gy-note">Payment submitted is not enough. Payment proof unlocks money logic.</div></div>
            <div class="cc-gy-card"><div class="cc-gy-kicker">Money Movement</div><div class="cc-gy-value">Locked</div><div class="cc-gy-note">No checkout capture, refund, payout, seller transfer, courier payout, or KFC takeout is created in this phase.</div></div>
        </div>

        <div class="cc-gy-section">
            <h2>Rail Controls</h2>
            <p>These settings decide the payment roadmap without touching live checkout yet.</p>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <?php wp_nonce_field(BankPaymentRails::NONCE_SAVE); ?>
                <input type="hidden" name="action" value="<?php echo esc_attr(BankPaymentRails::ACTION_SAVE); ?>">
                <div class="cc-gy-form-grid">
                    <div class="cc-gy-field"><label>Primary checkout rail</label><select name="primary_checkout_rail"><?php self::ccbank_options($choices['primary_checkout_rail'], $primary); ?></select><small>Best current recommendation: MMG Checkout.</small></div>
                    <div class="cc-gy-field"><label>Secondary checkout rail</label><select name="secondary_checkout_rail"><?php self::ccbank_options($choices['secondary_checkout_rail'], $secondary); ?></select><small>Best current recommendation: card gateway.</small></div>
                    <div class="cc-gy-field"><label>Card gateway candidate</label><select name="card_gateway_candidate"><?php self::ccbank_options($choices['card_gateway_candidate'], $card_candidate); ?></select><small>Use this to track WiPay vs Republic/Scotia/bank gateway/KnitPay-compatible provider.</small></div>
                    <div class="cc-gy-field"><label>MMG status</label><select name="mmg_status"><?php self::ccbank_options($choices['mmg_status'], $mmg_status); ?></select><small>Set to sandbox/live credentials only after MMG gives real merchant details.</small></div>
                    <div class="cc-gy-field"><label>Card gateway status</label><select name="card_gateway_status"><?php self::ccbank_options($choices['card_gateway_status'], $card_status); ?></select><small>Set to credentials received only after the chosen card provider gives test/live credentials.</small></div>
                    <div class="cc-gy-field"><label>Manual bank status</label><select name="manual_bank_status"><?php self::ccbank_options($choices['manual_bank_status'], (string) ($settings['manual_bank_status'] ?? 'hidden_fallback')); ?></select><small>Manual bank should stay hidden/admin-only, never main checkout.</small></div>
                    <div class="cc-gy-field"><label>Customer trust label</label><select name="customer_trust_badge"><?php self::ccbank_options($choices['customer_trust_badge'], (string) ($settings['customer_trust_badge'] ?? 'protected_checkout')); ?></select><small>Recommended: Caricove Protected Checkout.</small></div>
                    <div class="cc-gy-field"><label>Provider proof mode</label><select name="provider_proof_mode"><?php self::ccbank_options($choices['provider_proof_mode'], $proof_mode); ?></select><small>Webhook/API proof is the clean path. Manual proof only as fallback.</small></div>
                    <div class="cc-gy-field"><label>Seller payout identity</label><select name="seller_payout_identity"><?php self::ccbank_options($choices['seller_payout_identity'], (string) ($settings['seller_payout_identity'] ?? 'later')); ?></select><small>Prep only. Seller payout movement comes later.</small></div>
                    <div class="cc-gy-field"><label>Courier payout identity</label><select name="courier_payout_identity"><?php self::ccbank_options($choices['courier_payout_identity'], (string) ($settings['courier_payout_identity'] ?? 'later')); ?></select><small>Prep only. Same-courier debt offset comes before courier payout.</small></div>
                    <div class="cc-gy-field"><label>Owner takeout identity</label><select name="owner_takeout_identity"><?php self::ccbank_options($choices['owner_takeout_identity'], (string) ($settings['owner_takeout_identity'] ?? 'later')); ?></select><small>Prep only. Owner takeout stays locked.</small></div>
                    <div class="cc-gy-field"><label>Manual bank visibility</label><select name="manual_bank_visibility"><?php self::ccbank_options($choices['manual_bank_visibility'], (string) ($settings['manual_bank_visibility'] ?? 'hidden_admin_fallback')); ?></select><small>Keep friction away from normal checkout.</small></div>
                    <div class="cc-gy-field" style="grid-column:1/-1"><label>Provider notes / next calls</label><textarea name="notes" rows="3"><?php echo esc_textarea((string) ($settings['notes'] ?? '')); ?></textarea><small>Never paste merchant secrets, API keys, webhook secrets, or bank details here.</small></div>
                </div>
                <p style="margin-top:14px"><button type="submit" class="button button-primary">Save Guyana Rails</button></p>
            </form>
        </div>

        <div class="cc-gy-section">
            <h2>Checkout Order Doctrine</h2>
            <div style="overflow:auto"><table class="cc-gy-table"><thead><tr><th>Rank</th><th>Rail</th><th>Status</th><th>Customer Label</th><th>Why</th><th>Money Rule</th></tr></thead><tbody>
                <?php foreach (BankPaymentRails::checkout_order() as $row): ?>
                    <tr><td><strong><?php echo esc_html((string) $row['rank']); ?></strong></td><td><?php echo esc_html((string) $row['rail']); ?></td><td><span class="cc-gy-badge warn"><?php echo esc_html((string) $row['status']); ?></span></td><td><?php echo esc_html((string) $row['customer_label']); ?></td><td><?php echo esc_html((string) $row['why']); ?></td><td><?php echo esc_html((string) $row['money_rule']); ?></td></tr>
                <?php endforeach; ?>
            </tbody></table></div>
        </div>

        <div class="cc-gy-section">
            <h2>Readiness Gates</h2>
            <div style="overflow:auto"><table class="cc-gy-table"><thead><tr><th>Gate</th><th>Status</th><th>Meaning</th></tr></thead><tbody>
                <?php foreach (BankPaymentRails::readiness_rows() as $row): ?>
                    <tr><td><strong><?php echo esc_html((string) $row['gate']); ?></strong></td><td><span class="cc-gy-badge <?php echo esc_attr((string) ($row['class'] ?? 'warn')); ?>"><?php echo esc_html((string) $row['status']); ?></span></td><td><?php echo esc_html((string) $row['meaning']); ?></td></tr>
                <?php endforeach; ?>
            </tbody></table></div>
        </div>

        <div class="cc-gy-section">
            <h2>Party Payment Profiles — Later Build Order</h2>
            <div style="overflow:auto"><table class="cc-gy-table"><thead><tr><th>Party</th><th>Profile</th><th>Current Phase</th><th>Hard Rule</th></tr></thead><tbody>
                <?php foreach (BankPaymentRails::payout_identity_plan() as $row): ?>
                    <tr><td><strong><?php echo esc_html((string) $row['party']); ?></strong></td><td><?php echo esc_html((string) $row['profile']); ?></td><td><?php echo esc_html((string) $row['current_phase']); ?></td><td><?php echo esc_html((string) $row['hard_rule']); ?></td></tr>
                <?php endforeach; ?>
            </tbody></table></div>
        </div>

        <div class="cc-gy-section">
            <h2>Provider Callback / Proof Reference</h2>
            <p>These are reserved references only. They are not active money-proof adapters yet. We enable them only after the chosen provider gives official signature/API rules.</p>
            <div style="overflow:auto"><table class="cc-gy-table"><thead><tr><th>Provider</th><th>Reference URL</th><th>Status</th><th>Rule</th></tr></thead><tbody>
                <?php foreach (BankPaymentRails::callback_reference() as $row): ?>
                    <tr><td><strong><?php echo esc_html((string) $row['provider']); ?></strong></td><td><code><?php echo esc_html((string) $row['url']); ?></code></td><td><span class="cc-gy-badge warn"><?php echo esc_html((string) $row['status']); ?></span></td><td><?php echo esc_html((string) $row['rule']); ?></td></tr>
                <?php endforeach; ?>
            </tbody></table></div>
        </div>

        <div class="cc-gy-section">
            <h2>Provider Questions To Ask Before We Touch Checkout</h2>
            <ol class="cc-gy-questions">
                <?php foreach (BankPaymentRails::provider_questions() as $question): ?>
                    <li><?php echo esc_html((string) $question); ?></li>
                <?php endforeach; ?>
            </ol>
        </div>

        <div class="cc-gy-lock">Hard lock: this phase does not change WooCommerce checkout, does not mark orders paid, does not create refunds, does not pay sellers/couriers, and does not unlock owner KFC takeout.</div>
        <?php
    }

    private static function render_provider_events_tab(): void
    {
        $summary = class_exists(__NAMESPACE__ . '\BankProviderEvents') ? BankProviderEvents::summary() : [];
        $rows = class_exists(__NAMESPACE__ . '\BankProviderEvents') ? BankProviderEvents::recent(50) : [];
        $endpoint = (string) ($summary['stripe_endpoint'] ?? (class_exists(__NAMESPACE__ . '\BankProviderEvents') ? BankProviderEvents::webhook_url('stripe') : rest_url('caricove-bank/v1/stripe/webhook')));
        $secret_ready = !empty($summary['stripe_secret_ready']);
        $secret_source = (string) ($summary['stripe_secret_source'] ?? '');
        $latest = (string) ($summary['latest_received_at'] ?? 'Never');
        $latest_type = (string) ($summary['latest_type'] ?? 'None');
        ?>
        <style>
            .cc-events-hero{border-radius:26px;padding:26px;margin:18px 0;background:radial-gradient(circle at 18% 15%,rgba(0,216,255,.28),transparent 30%),linear-gradient(135deg,#061225 0%,#102a55 52%,#06101f 100%);box-shadow:0 24px 70px rgba(0,0,0,.24),inset 0 0 0 1px rgba(255,255,255,.14);color:#eef7ff}.cc-events-hero h1{margin:0 0 8px;color:#fff!important}.cc-events-sub{max-width:980px;color:#c8e5ff;line-height:1.55;margin:0}.cc-events-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px;margin:16px 0}.cc-events-card{background:linear-gradient(150deg,#081a35,#122d59);border:1px solid rgba(255,255,255,.13);border-radius:20px;padding:17px;color:#eef7ff;box-shadow:0 18px 42px rgba(0,0,0,.16)}.cc-events-kicker{text-transform:uppercase;letter-spacing:.14em;font-size:11px;color:#b9d9ff;font-weight:800;margin-bottom:8px}.cc-events-value{font-size:21px;font-weight:900;color:#fff;line-height:1.2}.cc-events-note{font-size:12px;color:#cde7ff;margin-top:8px;line-height:1.45}.cc-events-section{background:#fff;color:#0b1220;border:1px solid #d6e1ee;border-radius:20px;padding:18px;margin-top:16px;box-shadow:0 12px 34px rgba(8,24,54,.08)}.cc-events-section h2,.cc-events-section h3{color:#071225!important;margin-top:0}.cc-events-table{width:100%;border-collapse:collapse;min-width:980px}.cc-events-table th{background:#071225;color:#fff;text-align:left;padding:11px;font-size:12px;text-transform:uppercase;letter-spacing:.08em}.cc-events-table td{padding:11px;border-bottom:1px solid #e6eef7;vertical-align:top}.cc-events-badge{display:inline-flex;border-radius:999px;padding:5px 9px;font-size:11px;font-weight:900;text-transform:uppercase;letter-spacing:.05em;background:#fff8e6;color:#7a5200;border:1px solid #ffe29a}.cc-events-badge.good{background:#ebfff6;color:#05603a;border-color:#a6f4c5}.cc-events-badge.bad{background:#fff0f2;color:#9b1024;border-color:#ffc9d1}.cc-events-code{background:#071225;color:#e8f8ff;border-radius:12px;padding:11px;display:block;overflow:auto;white-space:nowrap}.cc-events-copy{font-size:12px;color:#36506f;line-height:1.45}@media(max-width:1200px){.cc-events-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}@media(max-width:720px){.cc-events-grid{grid-template-columns:1fr}}
        </style>
        <div class="cc-events-hero">
            <h1>Provider Events</h1>
            <p class="cc-events-sub">Phase 2D is the signed provider-event inbox. It catches Stripe webhook proof before Caricove is allowed to automate refunds, payouts, transfers, or owner takeout. This screen is read-only and does not move money.</p>
        </div>
        <div class="cc-events-grid">
            <div class="cc-events-card"><div class="cc-events-kicker">Webhook Secret</div><div class="cc-events-value"><?php echo esc_html($secret_ready ? 'Ready' : 'Missing'); ?></div><div class="cc-events-note"><?php echo esc_html($secret_ready ? ('Source: ' . $secret_source) : 'Add CARICOVE_STRIPE_WEBHOOK_SECRET or STRIPE_WEBHOOK_SECRET in wp-config/server env.'); ?></div></div>
            <div class="cc-events-card"><div class="cc-events-kicker">Events Captured</div><div class="cc-events-value"><?php echo esc_html(number_format((int) ($summary['total_events'] ?? 0))); ?></div><div class="cc-events-note">Verified: <?php echo esc_html(number_format((int) ($summary['verified_events'] ?? 0))); ?>. Duplicate deliveries: <?php echo esc_html(number_format((int) ($summary['duplicate_deliveries'] ?? 0))); ?>.</div></div>
            <div class="cc-events-card"><div class="cc-events-kicker">Latest Event</div><div class="cc-events-value"><?php echo esc_html($latest_type); ?></div><div class="cc-events-note">Received: <?php echo esc_html($latest); ?></div></div>
            <div class="cc-events-card"><div class="cc-events-kicker">Money Movement</div><div class="cc-events-value">Locked</div><div class="cc-events-note">This inbox records proof only. No payouts, refunds, or owner withdrawal are triggered here.</div></div>
        </div>
        <div class="cc-events-section">
            <h2>Stripe Webhook Endpoint</h2>
            <p class="cc-events-copy">Add this URL in Stripe as the webhook endpoint. Keep the endpoint secret in wp-config.php or your server environment, never in the dashboard.</p>
            <code class="cc-events-code"><?php echo esc_html($endpoint); ?></code>
            <div style="margin-top:12px;overflow:auto">
                <table class="cc-events-table">
                    <thead><tr><th>Required Piece</th><th>Status</th><th>Meaning</th></tr></thead>
                    <tbody>
                        <tr><td><strong>Endpoint URL</strong></td><td><span class="cc-events-badge good">Ready</span></td><td>Stripe can POST signed events to the WordPress REST endpoint.</td></tr>
                        <tr><td><strong>Webhook signing secret</strong></td><td><span class="cc-events-badge <?php echo esc_attr($secret_ready ? 'good' : 'bad'); ?>"><?php echo esc_html($secret_ready ? 'Ready' : 'Missing'); ?></span></td><td>The inbox rejects unsigned or incorrectly signed Stripe events.</td></tr>
                        <tr><td><strong>Ledger mutation</strong></td><td><span class="cc-events-badge">Disabled</span></td><td>Provider events are not allowed to change Caricove money balances until later phases.</td></tr>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="cc-events-section">
            <h2>Recent Provider Events</h2>
            <div style="overflow:auto">
                <table class="cc-events-table">
                    <thead>
                        <tr><th>ID</th><th>Received</th><th>Provider</th><th>Type</th><th>Object</th><th>Amount</th><th>Order</th><th>Shipment</th><th>Signature</th><th>Status</th></tr>
                    </thead>
                    <tbody>
                    <?php if (empty($rows)): ?>
                        <tr><td colspan="10">No provider events received yet. After the Stripe endpoint is added and a test event is sent, rows will appear here.</td></tr>
                    <?php else: ?>
                        <?php foreach ($rows as $row): ?>
                            <tr>
                                <td><?php echo esc_html((string) ($row['id'] ?? '')); ?></td>
                                <td><?php echo esc_html((string) ($row['received_at'] ?? '')); ?></td>
                                <td><?php echo esc_html(strtoupper((string) ($row['provider'] ?? '')) . ' ' . strtoupper((string) ($row['mode'] ?? ''))); ?></td>
                                <td><strong><?php echo esc_html((string) ($row['provider_event_type'] ?? '')); ?></strong><br><small><?php echo esc_html((string) ($row['provider_event_id'] ?? '')); ?></small></td>
                                <td><?php echo esc_html((string) ($row['object_type'] ?? '')); ?><br><small><?php echo esc_html((string) ($row['object_id'] ?? '')); ?></small></td>
                                <td><?php echo esc_html(strtoupper((string) ($row['currency'] ?? '')) . ' ' . number_format((float) ($row['amount'] ?? 0), 2)); ?></td>
                                <td><?php echo esc_html((string) ((int) ($row['order_id'] ?? 0) ?: '—')); ?></td>
                                <td><?php echo esc_html((string) ((int) ($row['shipment_id'] ?? 0) ?: '—')); ?></td>
                                <td><span class="cc-events-badge <?php echo esc_attr(((string) ($row['signature_status'] ?? '')) === 'verified' ? 'good' : 'bad'); ?>"><?php echo esc_html((string) ($row['signature_status'] ?? '')); ?></span></td>
                                <td><?php echo esc_html((string) ($row['event_status'] ?? '')); ?><?php if ((int) ($row['duplicate_count'] ?? 0) > 0): ?><br><small>duplicates: <?php echo esc_html((string) (int) $row['duplicate_count']); ?></small><?php endif; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php
    }

    private static function ccbank_constant_ready(string $name): bool
    {
        return defined($name) && is_scalar(constant($name)) && trim((string) constant($name)) !== '';
    }

    private static function ccbank_options(array $options, string $selected): void
    {
        foreach ($options as $value => $label) {
            echo '<option value="' . esc_attr((string) $value) . '" ' . selected($selected, (string) $value, false) . '>' . esc_html((string) $label) . '</option>';
        }
    }

    private static function platform_wallet_snapshot(): array
    {
        $audit = self::overview_net_platform_audit();
        $formula = (array) ($audit['formula'] ?? []);
        $metrics = self::overview_metrics();
        $provider = self::provider_balance_snapshot();

        $internal_safe = max(0.0, (float) ($formula['net_platform_revenue'] ?? 0));
        $provider_available = max(0.0, (float) ($provider['available'] ?? 0));
        $provider_pending = max(0.0, (float) ($provider['pending'] ?? 0));
        $provider_withheld = max(0.0, (float) ($provider['withheld'] ?? 0));
        $emergency_reserve = max(0.0, (float) get_option('caricove_bank_platform_wallet_emergency_reserve_v1', 0));

        $lower_of_truths = min($internal_safe, $provider_available);
        $pre_gate_spendable = max(0.0, $lower_of_truths - $emergency_reserve);

        $uncovered_exposure = max(0.0, (float) ($formula['courier_uncovered_exposure'] ?? 0) + (float) ($formula['vendor_uncovered_exposure'] ?? 0));
        $provider_connected = !empty($provider['connected']);

        $status = 'blocked';
        $status_label = 'Blocked';
        $reason = 'Provider available balance is not wired yet, so physical takeout stays locked.';
        $hard_takeout_gate = 0.0;

        if ($internal_safe <= 0) {
            $reason = 'Internal Caricove ledger-safe revenue is GYD 0.00, so nothing is spendable yet.';
        } elseif (!$provider_connected) {
            $reason = 'Internal safe revenue exists, but real provider/bank available balance is not connected yet.';
        } elseif ($provider_available <= 0) {
            $reason = 'Provider is connected, but available cash is GYD 0.00.';
        } elseif ($uncovered_exposure > 0) {
            $status = 'review';
            $status_label = 'Needs Review';
            $reason = 'Open uncovered courier/vendor exposure still exists. Keep owner takeout locked until those debts are covered, waived, or resolved.';
        } elseif ($pre_gate_spendable <= 0) {
            $reason = 'Emergency reserve consumes the lower safe number, so physical takeout remains GYD 0.00.';
        } else {
            $status = 'safe';
            $status_label = 'Safe';
            $reason = 'Internal safe revenue and provider available cash both support this spendable amount.';
            $hard_takeout_gate = $pre_gate_spendable;
        }

        if ($status !== 'safe') {
            $hard_takeout_gate = 0.0;
        }

        $seller_locked = self::metric_amount($metrics, 'Seller Funds Clearing') + self::metric_amount($metrics, 'Seller Funds On Hold') + self::metric_amount($metrics, 'Seller Funds Available');
        $courier_locked = self::metric_amount($metrics, 'Courier Funds Clearing') + self::metric_amount($metrics, 'Courier Funds Available') + self::metric_amount($metrics, 'Courier Funds Held');
        $spendability_reserve = max(0.0, (float) ($formula['platform_spendability_reserve'] ?? 0));

        return [
            'spendable_platform_cash' => $hard_takeout_gate,
            'hard_takeout_gate' => $hard_takeout_gate,
            'internal_safe_revenue' => $internal_safe,
            'provider_available' => $provider_available,
            'provider_pending_withheld' => $provider_pending + $provider_withheld,
            'emergency_reserve' => $emergency_reserve,
            'status' => $status,
            'status_label' => $status_label,
            'reason' => $reason,
            'provider_label' => (string) ($provider['label'] ?? 'Not connected'),
            'provider_mode' => (string) ($provider['mode'] ?? 'not wired'),
            'provider_status_label' => (string) ($provider['status_label'] ?? 'Not wired'),
            'provider_status_message' => (string) ($provider['status_message'] ?? ''),
            'provider_target_currency' => (string) ($provider['target_currency'] ?? 'GYD'),
            'provider_synced_at' => (string) ($provider['synced_at'] ?? 'Never'),
            'provider_expires_at' => (string) ($provider['expires_at'] ?? ''),
            'provider_request_id' => (string) ($provider['request_id'] ?? ''),
            'provider_available_by_currency' => (array) ($provider['available_by_currency'] ?? []),
            'provider_pending_by_currency' => (array) ($provider['pending_by_currency'] ?? []),
            'waterfall' => [
                ['step' => 'Internal Safe Revenue', 'amount' => $internal_safe, 'rule' => 'Cleared platform commission minus commission reversals, platform losses, waived recovery, and uncovered party exposure.'],
                ['step' => 'Provider Available Cash', 'amount' => $provider_available, 'rule' => 'Real payment-provider/bank available balance. This is zero until provider balance mirror is wired.'],
                ['step' => 'Lower Of Both Truths', 'amount' => $lower_of_truths, 'rule' => 'Caricove can only spend the lower number between ledger-safe money and real available cash.'],
                ['step' => 'Emergency Reserve', 'amount' => $emergency_reserve, 'rule' => 'Extra owner safety buffer kept behind before takeout.'],
                ['step' => 'Hard Takeout Gate', 'amount' => $hard_takeout_gate, 'rule' => 'This is the only number that should ever become a withdraw button.'],
            ],
            'party_wallets' => [
                ['label' => 'Platform Wallet', 'amount' => $hard_takeout_gate, 'badge' => $status_label, 'class' => $status === 'safe' ? 'good' : ($status === 'review' ? 'warn' : 'bad'), 'note' => 'Owner spendable money after ledger and provider gates agree.'],
                ['label' => 'Seller Payables Wallet', 'amount' => $seller_locked, 'badge' => 'Not Yours', 'class' => 'warn', 'note' => 'Seller clearing, hold, and available funds are protected from platform spending.'],
                ['label' => 'Courier Payables Wallet', 'amount' => $courier_locked, 'badge' => 'Not Yours', 'class' => 'warn', 'note' => 'Courier clearing, available, and held earnings are protected from platform spending.'],
                ['label' => 'Recovery / Loss Reserve', 'amount' => $spendability_reserve, 'badge' => 'Protected', 'class' => 'bad', 'note' => 'Commission reversals, platform losses, waived recovery, and uncovered debt reduce owner takeout.'],
            ],
            'rails' => [
                ['party' => 'Customer', 'movement' => 'Checkout payment capture → provider transaction → order/bank event link.', 'gate' => 'Payment exists, but provider balance mirror is not connected in this dashboard-only phase.', 'next' => 'Add provider adapter + webhook event capture.'],
                ['party' => 'Seller', 'movement' => 'Seller funds clear after delivery/risk checks → payout request → payout reference.', 'gate' => 'Existing seller payout logic remains untouched.', 'next' => 'Map each seller to a provider payout identity.'],
                ['party' => 'Courier', 'movement' => 'Courier earning clears → same-courier debt offsets first → payout.', 'gate' => 'Existing courier payout/recovery logic remains untouched.', 'next' => 'Map each courier to a provider payout identity.'],
                ['party' => 'Platform Owner', 'movement' => 'Owner takeout only from hard takeout gate.', 'gate' => $reason, 'next' => 'Add provider balance sync, then a locked withdrawal request flow with audit snapshots.'],
            ],
        ];
    }

    private static function provider_balance_snapshot(): array
    {
        if (class_exists(__NAMESPACE__ . "\\BankProviderMirror")) {
            return BankProviderMirror::snapshot();
        }

        return [
            "connected" => false,
            "fresh" => false,
            "stale" => true,
            "label" => "Not connected",
            "mode" => "not wired",
            "status" => "not_wired",
            "status_label" => "Not wired",
            "status_message" => "Provider balance mirror class is not loaded.",
            "available" => 0.0,
            "pending" => 0.0,
            "withheld" => 0.0,
            "synced_at" => "Never",
        ];
    }

    private static function metric_amount(array $metrics, string $label): float
    {
        foreach ($metrics as $metric) {
            if (!is_array($metric)) {
                continue;
            }
            if ((string) ($metric['label'] ?? '') !== $label) {
                continue;
            }
            $value = (string) ($metric['value'] ?? '0');
            $value = preg_replace('/[^0-9.\-]/', '', $value);
            return is_numeric($value) ? (float) $value : 0.0;
        }
        return 0.0;
    }

    private static function first_float(array $row, array $keys): float
    {
        foreach ($keys as $key) {
            if (isset($row[$key]) && is_numeric($row[$key])) {
                return (float) $row[$key];
            }
        }
        return 0.0;
    }

    private static function first_string(array $row, array $keys, string $fallback = ''): string
    {
        foreach ($keys as $key) {
            if (isset($row[$key]) && is_scalar($row[$key]) && trim((string) $row[$key]) !== '') {
                return trim((string) $row[$key]);
            }
        }
        return $fallback;
    }


    private static function money_label(float $amount): string
    {
        return 'GYD ' . number_format((float) $amount, 2);
    }

    private static function provider_currency_map_label(array $map): string
    {
        if (empty($map)) {
            return 'None';
        }

        $parts = [];
        foreach ($map as $currency => $amount) {
            $code = strtoupper(preg_replace('/[^A-Z]/', '', strtoupper((string) $currency)) ?: 'CUR');
            $parts[] = $code . ' ' . number_format((float) $amount, 2);
        }

        return implode(' • ', $parts);
    }

    private static function courier_display_name(int $courier_id): string
    {
        if ($courier_id <= 0) {
            return 'Unknown courier';
        }

        $user = get_userdata($courier_id);
        if ($user instanceof \WP_User) {
            $name = trim((string) $user->display_name);
            if ($name !== '') {
                return $name . ' (#' . $courier_id . ')';
            }
        }

        return 'Courier #' . $courier_id;
    }

    private static function audit_meta_value(array $row, array $keys, string $fallback = '—'): string
    {
        foreach ($keys as $key) {
            if (array_key_exists($key, $row) && $row[$key] !== '' && $row[$key] !== null) {
                if (is_scalar($row[$key])) {
                    return (string) $row[$key];
                }
            }
        }

        return $fallback;
    }

    private static function overview_net_platform_audit(): array
    {
        global $wpdb;

        $seller_table = Ledger::table();
        $seller_epoch = self::sellerEpochLedgerId();

        $cleared_rows_raw = (array) $wpdb->get_results($wpdb->prepare(
            "SELECT id, shipment_id, order_id, vendor_id, state, gross, commission, net, created_at, updated_at
             FROM {$seller_table}
             WHERE id >= %d
               AND state IN ('available','paid')
               AND commission > 0
             ORDER BY id ASC",
            $seller_epoch
        ), ARRAY_A);

        $platform_cleared_commission = 0.0;
        $cleared_rows = [];
        foreach ($cleared_rows_raw as $row) {
            $commission = max(0.0, (float) ($row['commission'] ?? 0));
            $platform_cleared_commission += $commission;
            $vendor_id = (int) ($row['vendor_id'] ?? 0);
            $cleared_rows[] = [
                'Ledger ID'  => (string) ($row['id'] ?? ''),
                'Shipment'   => (string) ($row['shipment_id'] ?? ''),
                'Order'      => (string) ($row['order_id'] ?? ''),
                'Vendor'     => $vendor_id > 0 ? self::seller_store_name($vendor_id) . ' (#' . $vendor_id . ')' : '—',
                'State'      => (string) ($row['state'] ?? ''),
                'Commission' => self::money_label($commission),
                'Created'    => (string) ($row['created_at'] ?? ''),
            ];
        }

        $reversed_rows_raw = (array) $wpdb->get_results($wpdb->prepare(
            "SELECT id, shipment_id, order_id, vendor_id, state, gross, commission, net, note, created_at, updated_at
             FROM {$seller_table}
             WHERE id >= %d
               AND state = 'reversed'
               AND commission <> 0
             ORDER BY id ASC",
            $seller_epoch
        ), ARRAY_A);

        $commission_reversed = 0.0;
        $commission_reversal_rows = [];
        foreach ($reversed_rows_raw as $row) {
            $amount = abs((float) ($row['commission'] ?? 0));
            $commission_reversed += $amount;
            $vendor_id = (int) ($row['vendor_id'] ?? 0);
            $commission_reversal_rows[] = [
                'Source'     => 'Seller ledger reversed row',
                'ID'         => (string) ($row['id'] ?? ''),
                'Shipment'   => (string) ($row['shipment_id'] ?? ''),
                'Order'      => (string) ($row['order_id'] ?? ''),
                'Party'      => $vendor_id > 0 ? self::seller_store_name($vendor_id) . ' (#' . $vendor_id . ')' : '—',
                'Amount'     => self::money_label($amount),
                'Reason'     => (string) ($row['note'] ?? 'Seller commission reversed'),
                'Created'    => (string) ($row['created_at'] ?? ''),
            ];
        }

        $seen_refund_events = [];
        foreach (self::filtered_bank_rows(['event_type' => 'customer_refund_issued'], 2000) as $row) {
            $meta_raw = $row['meta_json'] ?? [];
            $meta     = is_array($meta_raw) ? $meta_raw : json_decode((string) $meta_raw, true);
            if (!is_array($meta)) {
                $meta = [];
            }

            $event_key = (string) ($row['canonical_event_key'] ?? '');
            if ($event_key === '' && !empty($meta['shipping_posting_key'])) {
                $event_key = 'shipping|' . (string) $meta['shipping_posting_key'];
            }
            if ($event_key === '') {
                $event_key = (string) ($row['source_ref'] ?? '');
            }
            if ($event_key !== '' && isset($seen_refund_events[$event_key])) {
                continue;
            }
            if ($event_key !== '') {
                $seen_refund_events[$event_key] = true;
            }

            $mode = strtolower((string) ($meta['financial_mode'] ?? ($meta['mode'] ?? '')));
            if ($mode !== 'debit') {
                continue;
            }

            $amount = abs((float) ($meta['commission_reversal'] ?? 0));
            if ($amount <= 0) {
                continue;
            }

            $commission_reversed += $amount;
            $vendor_id = (int) ($row['vendor_id'] ?? 0);
            $commission_reversal_rows[] = [
                'Source'     => 'Bank refund clawback',
                'ID'         => (string) ($row['id'] ?? ''),
                'Shipment'   => (string) ($row['shipment_id'] ?? ''),
                'Order'      => (string) ($row['order_id'] ?? ''),
                'Party'      => $vendor_id > 0 ? self::seller_store_name($vendor_id) . ' (#' . $vendor_id . ')' : '—',
                'Amount'     => self::money_label($amount),
                'Reason'     => (string) ($row['reason_label'] ?? 'Commission reversal from refund debit'),
                'Created'    => (string) ($row['created_at'] ?? ''),
            ];
        }

        $platform_loss_rows = [];
        $platform_absorbed_total = 0.0;
        foreach (['platform_loss_booked', 'platform_absorption'] as $loss_event_type) {
            foreach (self::filtered_bank_rows(['event_type' => $loss_event_type], 2000) as $row) {
                $amount = abs((float) ($row['amount'] ?? 0));
                $platform_absorbed_total += $amount;
                $platform_loss_rows[] = [
                    'Source'   => self::human_event_type_label($loss_event_type),
                    'ID'       => (string) ($row['id'] ?? ''),
                    'Shipment' => (string) ($row['shipment_id'] ?? ''),
                    'Order'    => (string) ($row['order_id'] ?? ''),
                    'Amount'   => self::money_label($amount),
                    'Reason'   => (string) ($row['reason_label'] ?? 'Platform loss booked'),
                    'Created'  => (string) ($row['created_at'] ?? ''),
                ];
            }
        }

        $courier_cpt         = class_exists('\Caricove_Courier_Earnings_Engine') ? \Caricove_Courier_Earnings_Engine::CPT_EARNING : 'cc_courier_earning';
        $courier_status_meta = class_exists('\Caricove_Courier_Earnings_Engine') ? \Caricove_Courier_Earnings_Engine::META_STATUS : '_cc_earning_status';
        $courier_amount_meta = class_exists('\Caricove_Courier_Earnings_Engine') ? \Caricove_Courier_Earnings_Engine::META_AMOUNT_GYD : '_cc_earning_amount_gyd';
        $courier_id_meta     = class_exists('\Caricove_Courier_Earnings_Engine') ? \Caricove_Courier_Earnings_Engine::META_COURIER_ID : '_cc_earning_courier_id';

        $courier_available_by_id = [];
        $courier_available_source_rows = [];
        $courier_post_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT p.ID
             FROM {$wpdb->posts} p
             WHERE p.post_type = %s
               AND p.post_status <> 'trash'
               AND p.post_date >= %s",
            $courier_cpt,
            self::epochFallbackCreatedAt()
        ));

        foreach ((array) $courier_post_ids as $eid) {
            $eid = (int) $eid;
            $status = (string) get_post_meta($eid, $courier_status_meta, true);
            if ($status !== 'available') {
                continue;
            }

            $amount = (float) get_post_meta($eid, $courier_amount_meta, true);
            if ($amount <= 0) {
                continue;
            }

            $courier_id = (int) get_post_meta($eid, $courier_id_meta, true);
            if ($courier_id > 0) {
                $courier_available_by_id[$courier_id] = (float) ($courier_available_by_id[$courier_id] ?? 0) + $amount;
            }

            $courier_available_source_rows[] = [
                'Earning Post' => (string) $eid,
                'Courier'      => self::courier_display_name($courier_id),
                    'Resolution'   => 'courier_earning_available_row',
                'Status'       => $status,
                'Amount'       => self::money_label($amount),
            ];
        }

        $recovery_store = get_option('caricove_bank_courier_recovery_v1', []);
        if (!is_array($recovery_store)) {
            $recovery_store = [];
        }

    $fronted_store = get_option('caricove_bank_platform_fronted_v1', []);
    if (!is_array($fronted_store)) {
        $fronted_store = [];
    }
    $bank_event_table = class_exists(__NAMESPACE__ . '\BankLedger') ? BankLedger::table() : '';

        $courier_recovery_remaining_by_id = [];
        $courier_recovery_source_rows = [];
        $courier_waived_rows = [];
        $courier_waived_total = 0.0;
        foreach ($recovery_store as $key => $row) {
            if (!is_array($row)) {
                continue;
            }
            $courier_resolved = class_exists(__NAMESPACE__ . '\SafeMoneyCourierResolver') ? SafeMoneyCourierResolver::resolve($row, $bank_event_table, $fronted_store) : ['courier_id' => (int) ($row['courier_id'] ?? 0)];
            $courier_id = (int) ($courier_resolved['courier_id'] ?? 0);
            $courier_resolution_source = (string) ($courier_resolved['source'] ?? 'raw');
            $remaining = abs((float) ($row['remaining_amount_total'] ?? 0));
            $waived    = abs((float) ($row['waived_amount_total'] ?? 0));

            if ($remaining > 0) {
                $courier_recovery_remaining_by_id[$courier_id] = (float) ($courier_recovery_remaining_by_id[$courier_id] ?? 0) + $remaining;
                $courier_recovery_source_rows[] = [
                    'Recovery Key' => (string) $key,
                    'Courier'      => self::courier_display_name($courier_id),
                    'Resolution'   => $courier_resolution_source,
                    'Shipment'     => self::audit_meta_value($row, ['shipment_id', 'source_shipment_id', 'target_shipment_id']),
                    'Order'        => self::audit_meta_value($row, ['order_id', 'source_order_id', 'target_order_id']),
                    'Remaining'    => self::money_label($remaining),
                    'Recovered'    => self::money_label(abs((float) ($row['recovered_amount_total'] ?? 0))),
                    'Updated'      => self::audit_meta_value($row, ['updated_at', 'created_at']),
                ];
            }

            if ($waived > 0) {
                $courier_waived_total += $waived;
                $courier_waived_rows[] = [
                    'Recovery Key' => (string) $key,
                    'Courier'      => self::courier_display_name($courier_id),
                    'Resolution'   => $courier_resolution_source,
                    'Shipment'     => self::audit_meta_value($row, ['shipment_id', 'source_shipment_id', 'target_shipment_id']),
                    'Order'        => self::audit_meta_value($row, ['order_id', 'source_order_id', 'target_order_id']),
                    'Waived Loss'  => self::money_label($waived),
                    'Updated'      => self::audit_meta_value($row, ['updated_at', 'created_at']),
                ];
            }
        }

        $courier_recovery_covered_now = 0.0;
        $courier_uncovered_exposure = 0.0;
        $courier_exposure_rows = [];
        foreach ($courier_recovery_remaining_by_id as $courier_id => $debt) {
            $debt = max(0.0, (float) $debt);
            $available = ((int) $courier_id > 0) ? max(0.0, (float) ($courier_available_by_id[(int) $courier_id] ?? 0)) : 0.0;
            $covered = min($debt, $available);
            $uncovered = max(0.0, $debt - $covered);
            $courier_recovery_covered_now += $covered;
            $courier_uncovered_exposure += $uncovered;

            $courier_exposure_rows[] = [
                'Courier'   => self::courier_display_name((int) $courier_id),
                'Debt'      => self::money_label($debt),
                'Own Available Funds' => self::money_label($available),
                'Covered'   => self::money_label($covered),
                'Uncovered' => self::money_label($uncovered),
                'Rule'      => 'Only this courier\'s own available funds can cover this courier\'s debt.',
            ];
        }

        $vendor_debt_sql = "SELECT id, shipment_id, order_id, vendor_id, gross, commission, net, note, created_at, updated_at
             FROM {$seller_table}
             WHERE id >= %d
               AND state='debit'
               AND net < 0
               AND meta NOT LIKE '%\"shipping_liability\":1%'
               AND meta NOT LIKE '%\"debit_component\":\"shipping_liability\"%'
               AND meta NOT LIKE '%\"debit_component\":\"shipping\"%'
               AND meta NOT LIKE '%\"kind\":\"shipping\"%'
             ORDER BY vendor_id ASC, id ASC";
        $vendor_debt_rows_raw = (array) $wpdb->get_results($wpdb->prepare($vendor_debt_sql, $seller_epoch), ARRAY_A);

        $vendor_debt_by_id = [];
        $vendor_debt_rows = [];
        foreach ($vendor_debt_rows_raw as $row) {
            $vendor_id = (int) ($row['vendor_id'] ?? 0);
            $debt = abs((float) ($row['net'] ?? 0));
            if ($vendor_id > 0 && $debt > 0) {
                $vendor_debt_by_id[$vendor_id] = (float) ($vendor_debt_by_id[$vendor_id] ?? 0) + $debt;
            }
            $vendor_debt_rows[] = [
                'Ledger ID' => (string) ($row['id'] ?? ''),
                'Shipment'  => (string) ($row['shipment_id'] ?? ''),
                'Order'     => (string) ($row['order_id'] ?? ''),
                'Vendor'    => $vendor_id > 0 ? self::seller_store_name($vendor_id) . ' (#' . $vendor_id . ')' : '—',
                'Debt'      => self::money_label($debt),
                'Note'      => (string) ($row['note'] ?? ''),
                'Created'   => (string) ($row['created_at'] ?? ''),
            ];
        }

        $vendor_available_rows_raw = (array) $wpdb->get_results($wpdb->prepare(
            "SELECT id, shipment_id, order_id, vendor_id, net, created_at, updated_at
             FROM {$seller_table}
             WHERE id >= %d
               AND state='available'
               AND net > 0
             ORDER BY vendor_id ASC, id ASC",
            $seller_epoch
        ), ARRAY_A);

        $vendor_available_by_id = [];
        $vendor_available_rows = [];
        foreach ($vendor_available_rows_raw as $row) {
            $vendor_id = (int) ($row['vendor_id'] ?? 0);
            $available = max(0.0, (float) ($row['net'] ?? 0));
            if ($vendor_id > 0 && $available > 0) {
                $vendor_available_by_id[$vendor_id] = (float) ($vendor_available_by_id[$vendor_id] ?? 0) + $available;
            }
            $vendor_available_rows[] = [
                'Ledger ID' => (string) ($row['id'] ?? ''),
                'Shipment'  => (string) ($row['shipment_id'] ?? ''),
                'Order'     => (string) ($row['order_id'] ?? ''),
                'Vendor'    => $vendor_id > 0 ? self::seller_store_name($vendor_id) . ' (#' . $vendor_id . ')' : '—',
                'Available' => self::money_label($available),
                'Created'   => (string) ($row['created_at'] ?? ''),
            ];
        }

        $vendor_debit_covered_now = 0.0;
        $vendor_uncovered_exposure = 0.0;
        $vendor_exposure_rows = [];
        foreach ($vendor_debt_by_id as $vendor_id => $debt) {
            $available = max(0.0, (float) ($vendor_available_by_id[$vendor_id] ?? 0));
            $covered = min((float) $debt, $available);
            $uncovered = max(0.0, (float) $debt - $covered);
            $vendor_debit_covered_now += $covered;
            $vendor_uncovered_exposure += $uncovered;
            $vendor_exposure_rows[] = [
                'Vendor'    => self::seller_store_name((int) $vendor_id) . ' (#' . (int) $vendor_id . ')',
                'Debt'      => self::money_label((float) $debt),
                'Own Available Funds' => self::money_label($available),
                'Covered'   => self::money_label($covered),
                'Uncovered' => self::money_label($uncovered),
                'Rule'      => 'Only this vendor\'s own available funds can cover this vendor\'s debt.',
            ];
        }

        $platform_spendability_reserve = max(0.0,
            (float) $commission_reversed
            + (float) $platform_absorbed_total
            + (float) $courier_waived_total
            + (float) $courier_uncovered_exposure
            + (float) $vendor_uncovered_exposure
        );

        $raw_net = (float) $platform_cleared_commission - (float) $platform_spendability_reserve;
        $net_platform_revenue = max(0.0, $raw_net);

        return [
            'formula' => [
                'platform_cleared_commission' => $platform_cleared_commission,
                'commission_reversed' => $commission_reversed,
                'platform_absorbed_total' => $platform_absorbed_total,
                'courier_waived_total' => $courier_waived_total,
                'courier_recovery_covered_now' => $courier_recovery_covered_now,
                'courier_uncovered_exposure' => $courier_uncovered_exposure,
                'vendor_debit_covered_now' => $vendor_debit_covered_now,
                'vendor_uncovered_exposure' => $vendor_uncovered_exposure,
                'platform_spendability_reserve' => $platform_spendability_reserve,
                'raw_net' => $raw_net,
                'net_platform_revenue' => $net_platform_revenue,
            ],
            'reserve_components' => [
                ['Component' => 'Commission Reversed', 'Amount' => self::money_label($commission_reversed), 'Why It Reduces KFC Money' => 'Commission that had to be clawed back or neutralized after refunds/reversals.'],
                ['Component' => 'Booked Platform Losses', 'Amount' => self::money_label($platform_absorbed_total), 'Why It Reduces KFC Money' => 'Losses already booked against Caricove.'],
                ['Component' => 'Waived Recovery / Platform Loss', 'Amount' => self::money_label($courier_waived_total), 'Why It Reduces KFC Money' => 'Courier recovery that Caricove gave up, so Caricove absorbed it.'],
                ['Component' => 'Uncovered Courier Exposure', 'Amount' => self::money_label($courier_uncovered_exposure), 'Why It Reduces KFC Money' => 'Courier debt not currently covered by that same courier\'s available funds.'],
                ['Component' => 'Uncovered Vendor Exposure', 'Amount' => self::money_label($vendor_uncovered_exposure), 'Why It Reduces KFC Money' => 'Vendor debt not currently covered by that same vendor\'s available funds.'],
            ],
            'cleared_rows' => $cleared_rows,
            'commission_reversal_rows' => $commission_reversal_rows,
            'platform_loss_rows' => $platform_loss_rows,
            'courier_exposure_rows' => $courier_exposure_rows,
            'courier_recovery_source_rows' => $courier_recovery_source_rows,
            'courier_available_source_rows' => $courier_available_source_rows,
            'courier_waived_rows' => $courier_waived_rows,
            'vendor_exposure_rows' => $vendor_exposure_rows,
            'vendor_debt_rows' => $vendor_debt_rows,
            'vendor_available_rows' => $vendor_available_rows,
        ];
    }

    private static function render_net_platform_audit_panel(): void
    {
        $audit = self::overview_net_platform_audit();
        $f = (array) ($audit['formula'] ?? []);
        ?>
        <div id="cbank-net-platform-audit" class="cbank-card" style="margin-top:16px;scroll-margin-top:40px;">
            <h2 style="color:#ffffff !important;margin-top:0;">Net Platform Revenue Audit</h2>
            <p style="margin:0 0 14px;color:#eef4ff;max-width:980px;">
                This is the row-level proof for the KFC-money card. It starts with cleared platform commission, subtracts only protected reserve items, and clamps below-zero results to GYD 0.00 so the dashboard never pretends unsafe money is spendable.
            </p>

            <div class="cbank-grid cbank-grid--metrics" style="margin-top:12px;">
                <div class="cbank-card" style="background:rgba(255,255,255,.06);box-shadow:none;"><div class="cbank-kicker">Cleared Platform Commission</div><div class="cbank-value"><?php echo esc_html(self::money_label((float) ($f['platform_cleared_commission'] ?? 0))); ?></div></div>
                <div class="cbank-card" style="background:rgba(255,255,255,.06);box-shadow:none;"><div class="cbank-kicker">Spendability Reserve</div><div class="cbank-value"><?php echo esc_html(self::money_label((float) ($f['platform_spendability_reserve'] ?? 0))); ?></div></div>
                <div class="cbank-card" style="background:rgba(255,255,255,.06);box-shadow:none;"><div class="cbank-kicker">Raw Result Before Clamp</div><div class="cbank-value"><?php echo esc_html(self::money_label((float) ($f['raw_net'] ?? 0))); ?></div></div>
                <div class="cbank-card" style="background:rgba(255,255,255,.06);box-shadow:none;"><div class="cbank-kicker">Safe Net Platform Revenue</div><div class="cbank-value"><?php echo esc_html(self::money_label((float) ($f['net_platform_revenue'] ?? 0))); ?></div></div>
            </div>

            <p style="margin:14px 0;color:#eef4ff;">
                Formula: <?php echo esc_html(self::money_label((float) ($f['platform_cleared_commission'] ?? 0))); ?> − <?php echo esc_html(self::money_label((float) ($f['platform_spendability_reserve'] ?? 0))); ?> = <?php echo esc_html(self::money_label((float) ($f['raw_net'] ?? 0))); ?>, then safe spendable is <?php echo esc_html(self::money_label((float) ($f['net_platform_revenue'] ?? 0))); ?>.
            </p>

            <details open style="margin-top:14px;">
                <summary style="cursor:pointer;font-weight:700;color:#fff;">Reserve contributors</summary>
                <?php self::render_audit_table((array) ($audit['reserve_components'] ?? []), 'No reserve contributors.'); ?>
            </details>

            <details open style="margin-top:14px;">
                <summary style="cursor:pointer;font-weight:700;color:#fff;">Rows adding to Platform Commission Cleared</summary>
                <?php self::render_audit_table((array) ($audit['cleared_rows'] ?? []), 'No cleared commission rows found.'); ?>
            </details>

            <details open style="margin-top:14px;">
                <summary style="cursor:pointer;font-weight:700;color:#fff;">Rows adding to Commission Reversed</summary>
                <?php self::render_audit_table((array) ($audit['commission_reversal_rows'] ?? []), 'No commission reversal rows found.'); ?>
            </details>

            <details style="margin-top:14px;">
                <summary style="cursor:pointer;font-weight:700;color:#fff;">Courier exposure proof</summary>
                <p style="color:#eef4ff;">This proves whether courier debt is covered by that same courier's available funds. It never pools another courier's money.</p>
                <?php self::render_audit_table((array) ($audit['courier_exposure_rows'] ?? []), 'No open courier exposure found.'); ?>
                <h3 style="color:#ffffff !important;">Courier recovery source rows</h3>
                <?php self::render_audit_table((array) ($audit['courier_recovery_source_rows'] ?? []), 'No courier recovery source rows found.'); ?>
                <h3 style="color:#ffffff !important;">Courier available-fund source rows</h3>
                <?php self::render_audit_table((array) ($audit['courier_available_source_rows'] ?? []), 'No available courier earning rows found.'); ?>
            </details>

            <details style="margin-top:14px;">
                <summary style="cursor:pointer;font-weight:700;color:#fff;">Waived recovery / platform loss proof</summary>
                <?php self::render_audit_table((array) ($audit['courier_waived_rows'] ?? []), 'No waived courier recovery rows found.'); ?>
                <h3 style="color:#ffffff !important;">Booked platform loss rows</h3>
                <?php self::render_audit_table((array) ($audit['platform_loss_rows'] ?? []), 'No booked platform loss rows found.'); ?>
            </details>

            <details style="margin-top:14px;">
                <summary style="cursor:pointer;font-weight:700;color:#fff;">Vendor exposure proof</summary>
                <p style="color:#eef4ff;">This proves whether vendor debt is covered by that same vendor's available funds. It never pools another vendor's money.</p>
                <?php self::render_audit_table((array) ($audit['vendor_exposure_rows'] ?? []), 'No open vendor exposure found.'); ?>
                <h3 style="color:#ffffff !important;">Vendor debt source rows</h3>
                <?php self::render_audit_table((array) ($audit['vendor_debt_rows'] ?? []), 'No vendor debt source rows found.'); ?>
                <h3 style="color:#ffffff !important;">Vendor available-fund source rows</h3>
                <?php self::render_audit_table((array) ($audit['vendor_available_rows'] ?? []), 'No vendor available rows found.'); ?>
            </details>
        </div>
        <?php
    }

    private static function render_audit_table(array $rows, string $empty_message): void
    {
        if (empty($rows)) {
            echo '<p style="color:#eef4ff;margin:10px 0 0;">' . esc_html($empty_message) . '</p>';
            return;
        }

        $columns = [];
        foreach ($rows as $row) {
            if (!is_array($row)) {
                continue;
            }
            foreach (array_keys($row) as $key) {
                if (!in_array($key, $columns, true)) {
                    $columns[] = $key;
                }
            }
        }

        if (empty($columns)) {
            echo '<p style="color:#eef4ff;margin:10px 0 0;">' . esc_html($empty_message) . '</p>';
            return;
        }
        ?>
        <div style="overflow:auto;margin-top:10px;">
            <table class="widefat striped" style="min-width:900px;">
                <thead>
                    <tr>
                        <?php foreach ($columns as $column): ?>
                            <th><?php echo esc_html((string) $column); ?></th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($rows as $row): ?>
                        <?php if (!is_array($row)) { continue; } ?>
                        <tr>
                            <?php foreach ($columns as $column): ?>
                                <td><?php echo esc_html((string) ($row[$column] ?? '')); ?></td>
                            <?php endforeach; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    private static function render_payout_table_section(string $title, array $rows): void
    {
        ?>
        <div class="cbank-card" style="margin-top:16px;border:1px solid #000;background:#fff;color:#000;">
            <h2 style="margin-top:0;"><?php echo esc_html($title); ?></h2>

            <table class="widefat striped">
                <thead>
                    <tr>
                        <th>Storefront</th>
                        <th>Requested</th>
                        <th>Withdrawable Now</th>
                        <th>Debit Exposure</th>
                        <th>Method</th>
                        <th>Destination</th>
                        <th>Requested At</th>
                        <th>Age</th>
                        <th>Status</th>
                        <th>Eligibility</th>
                        <th>Reason</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($rows)): ?>
                        <?php foreach ($rows as $entry): ?>
                            <?php
                            $row       = (array) ($entry['row'] ?? []);
                            $truth     = (array) ($entry['truth'] ?? []);
                            $vendor_id = (int) ($row['vendor_id'] ?? 0);

                            $eligibility = (string) ($truth['eligibility'] ?? 'blocked');

                            $eligibility_label = 'Blocked';
                            if ($eligibility === 'payable') {
                                $eligibility_label = 'Payable';
                            } elseif ($eligibility === 'partial') {
                                $eligibility_label = 'Partial';
                            } elseif ($eligibility === 'closed') {
                                $eligibility_label = 'Closed';
                            }

                            $action_label = self::payout_action_label($row, $truth);
                            ?>
                            <tr>
                                <td>
                                    <strong><?php echo esc_html((string) ($row['store_name'] ?? '')); ?></strong><br>
                                    <small>Vendor #<?php echo esc_html((string) $vendor_id); ?></small>
                                </td>
                                <td><?php echo esc_html('GYD ' . number_format((float) ($row['amount_net'] ?? 0), 2)); ?></td>
                                <td><?php echo esc_html('GYD ' . number_format((float) ($truth['withdrawable_now'] ?? 0), 2)); ?></td>
                                <td><?php echo esc_html('GYD ' . number_format((float) ($truth['debit_exposure'] ?? 0), 2)); ?></td>
                                <td><?php echo esc_html((string) ($row['method'] ?? '')); ?></td>
                                <td><?php echo esc_html(self::payout_destination_label($row)); ?></td>
                                <td><?php echo esc_html((string) ($row['created_at'] ?? '')); ?></td>
                                <td><?php echo esc_html(self::payout_age_label((string) ($row['created_at'] ?? ''))); ?></td>
                                <td><?php echo esc_html(self::payout_status_label((string) ($row['status'] ?? ''))); ?></td>
                                <td><?php echo esc_html($eligibility_label); ?></td>
                                <td><?php echo esc_html((string) ($truth['eligibility_reason'] ?? '')); ?></td>
                                <td>
                                    <?php
                                    $payout_id    = (int) ($row['id'] ?? 0);
                                    $can_pay      = !empty($truth['can_pay']);
                                    $button_label = $can_pay ? 'Pay Now' : $action_label;
                                    ?>
                                    <button
                                        type="button"
                                        class="cbank-pay-btn <?php echo $can_pay ? 'is-payable' : 'is-blocked'; ?>"
                                        data-payout-id="<?php echo esc_attr((string) $payout_id); ?>"
                                        data-vendor-id="<?php echo esc_attr((string) $vendor_id); ?>"
                                        data-can-pay="<?php echo $can_pay ? '1' : '0'; ?>"
                                        <?php disabled(!$can_pay); ?>
                                        style="
                                            padding:10px 14px;
                                            min-width:120px;
                                            border:1px solid <?php echo $can_pay ? '#0f5132' : '#9ca3af'; ?>;
                                            background:<?php echo $can_pay ? 'linear-gradient(180deg,#22c55e 0%,#16a34a 100%)' : '#e5e7eb'; ?>;
                                            color:<?php echo $can_pay ? '#ffffff' : '#6b7280'; ?>;
                                            border-radius:10px;
                                            font-weight:700;
                                            cursor:<?php echo $can_pay ? 'pointer' : 'not-allowed'; ?>;
                                            opacity:1;
                                            box-shadow:<?php echo $can_pay ? '0 0 0 1px rgba(34,197,94,.18), 0 10px 24px rgba(22,163,74,.22)' : 'none'; ?>;
                                        "
                                        aria-label="<?php echo esc_attr($button_label); ?>"
                                        title="<?php echo esc_attr((string) ($truth['eligibility_reason'] ?? $button_label)); ?>"
                                    >
                                        <?php echo esc_html($button_label); ?>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="12">No rows in this section.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    private static function group_payout_rows(array $rows): array
    {
        $groups = [
            'payable'   => [],
            'attention' => [],
            'legacy'    => [],
        ];

        foreach ($rows as $row) {
            $vendor_id  = (int) ($row['vendor_id'] ?? 0);
            $truth      = self::payout_live_truth($vendor_id, $row);
            $created_at = (string) ($row['created_at'] ?? '');

            $entry = [
                'row'   => $row,
                'truth' => $truth,
            ];

            if (($truth['eligibility'] ?? '') === 'payable') {
                $groups['payable'][] = $entry;
                continue;
            }

            if (self::is_legacy_payout_request($created_at)) {
                $groups['legacy'][] = $entry;
                continue;
            }

            $groups['attention'][] = $entry;
        }

        return $groups;
    }

    private static function is_legacy_payout_request(string $created_at): bool
    {
        $ts = strtotime($created_at);
        if (!$ts) return false;

        $days_old = (int) floor((time() - $ts) / DAY_IN_SECONDS);
        return $days_old >= 30;
    }

    private static function payout_action_label(array $row, array $truth): string
    {
        $eligibility = (string) ($truth['eligibility'] ?? 'blocked');
        $reason      = strtolower((string) ($truth['eligibility_reason'] ?? ''));
        $created_at  = (string) ($row['created_at'] ?? '');

        if ($eligibility === 'closed') {
            return 'Resolved';
        }

        if (self::is_legacy_payout_request($created_at)) {
            return 'Legacy Review';
        }

        if (strpos($reason, 'destination') !== false || strpos($reason, 'configured') !== false) {
            return 'Needs Method';
        }

        if (strpos($reason, 'exceeds') !== false) {
            return 'Partial Coverage';
        }

        if (strpos($reason, 'withdrawable balance') !== false || strpos($reason, 'withdrawable') !== false) {
            return 'Insufficient Funds';
        }

        return 'Blocked';
    }

    private static function payout_age_label(string $created_at): string
    {
        $ts = strtotime($created_at);
        if (!$ts) return '—';

        $diff = time() - $ts;
        if ($diff < 0) $diff = 0;

        $days = (int) floor($diff / DAY_IN_SECONDS);
        if ($days <= 0) return 'Today';
        if ($days === 1) return '1 day';
        return $days . ' days';
    }

    private static function resolve_vendor_from_search(string $search): ?\WP_User
    {
        global $wpdb;

        $search = trim($search);
        if ($search === '') return null;

        if (ctype_digit($search)) {
            $user = get_user_by('id', (int) $search);
            if ($user instanceof \WP_User) return $user;
        }

        $like = '%' . $wpdb->esc_like($search) . '%';

        $vendor_ids = $wpdb->get_col($wpdb->prepare(
            "
            SELECT user_id
            FROM {$wpdb->usermeta}
            WHERE meta_key = 'dokan_store_name'
              AND meta_value LIKE %s
            ORDER BY umeta_id DESC
            LIMIT 25
            ",
            $like
        ));

        if (!empty($vendor_ids)) {
            foreach ($vendor_ids as $vendor_id) {
                $vendor_id = (int) $vendor_id;
                if ($vendor_id <= 0) continue;

                $resolved_store = self::seller_store_name($vendor_id);
                if ($resolved_store !== '' && stripos($resolved_store, $search) !== false) {
                    $user = get_user_by('id', $vendor_id);
                    if ($user instanceof \WP_User) return $user;
                }
            }
        }

        $users = get_users([
            'number'  => 200,
            'fields'  => ['ID'],
            'orderby' => 'ID',
            'order'   => 'DESC',
        ]);

        foreach ((array) $users as $u) {
            $vendor_id = (int) (is_object($u) ? $u->ID : $u);
            if ($vendor_id <= 0) continue;

            $resolved_store = self::seller_store_name($vendor_id);
            if ($resolved_store !== '' && stripos($resolved_store, $search) !== false) {
                $user = get_user_by('id', $vendor_id);
                if ($user instanceof \WP_User) return $user;
            }
        }

        $user = get_user_by('login', $search);
        if ($user instanceof \WP_User) return $user;

        $user = get_user_by('email', $search);
        if ($user instanceof \WP_User) return $user;

        $q = new \WP_User_Query([
            'number'         => 1,
            'count_total'    => false,
            'search'         => '*' . $search . '*',
            'search_columns' => ['user_login', 'user_email', 'display_name'],
        ]);

        $results = $q->get_results();
        if (!empty($results) && $results[0] instanceof \WP_User) {
            return $results[0];
        }

        return null;
    }

    private static function seller_store_name(int $vendor_id): string
    {
        $store_name = '';

        if (function_exists('dokan_get_store_info')) {
            $store_info = dokan_get_store_info($vendor_id);
            if (!empty($store_info['store_name'])) {
                $store_name = (string) $store_info['store_name'];
            }
        }

        if ($store_name === '') {
            $profile_settings = get_user_meta($vendor_id, 'dokan_profile_settings', true);
            if (is_array($profile_settings) && !empty($profile_settings['store_name'])) {
                $store_name = (string) $profile_settings['store_name'];
            }
        }

        if ($store_name === '') {
            $meta_name = get_user_meta($vendor_id, 'dokan_store_name', true);
            if (!empty($meta_name)) {
                $store_name = (string) $meta_name;
            }
        }

        if ($store_name === '' && function_exists('dokan') && method_exists(dokan(), 'vendor')) {
            $vendor_obj = dokan()->vendor->get($vendor_id);
            if ($vendor_obj && method_exists($vendor_obj, 'get_shop_name')) {
                $maybe = $vendor_obj->get_shop_name();
                if (!empty($maybe)) {
                    $store_name = (string) $maybe;
                }
            }
        }

        if ($store_name === '') {
            $u = get_userdata($vendor_id);
            if ($u && !empty($u->display_name)) {
                $store_name = (string) $u->display_name;
            }
        }

        return trim((string) $store_name);
    }

    private static function seller_metrics(int $vendor_id): array
    {
        $ledger_class = self::seller_ledger_class();

        if ($ledger_class && method_exists($ledger_class, 'seller_metrics')) {
            $metrics = \call_user_func([$ledger_class, 'seller_metrics'], $vendor_id, self::sellerEpochLedgerId());
            if (is_array($metrics)) {
                return [
                    'pending'          => (float) ($metrics['pending'] ?? 0),
                    'available'        => (float) ($metrics['available'] ?? 0),
'paid'             => (float) $GLOBALS['wpdb']->get_var(
                        $GLOBALS['wpdb']->prepare(
                            "SELECT COALESCE(SUM(amount_net),0)
                             FROM " . Ledger::payouts_table() . "
                             WHERE vendor_id = %d
                               AND status = 'sent'",
                            $vendor_id
                        )
                    ),                    'debit_exposure'   => (float) ($metrics['debit_exposure'] ?? 0),
                    'withdrawable_now' => (float) ($metrics['withdrawable_now'] ?? max(0, ((float) ($metrics['available'] ?? 0) - (float) ($metrics['debit_exposure'] ?? 0)))),
                ];
            }
        }

        error_log('[Caricove Bank][BankDashboard::seller_metrics] Ledger class unavailable or unreadable for vendor_id=' . $vendor_id);

        return [
            'pending'          => 0.0,
            'available'        => 0.0,
            'paid'             => 0.0,
            'debit_exposure'   => 0.0,
            'withdrawable_now' => 0.0,
            '_unavailable'     => true,
        ];
    }

    private static function seller_ledger_rows(int $vendor_id, int $limit = 100): array
    {
        $ledger_class = self::seller_ledger_class();

        if ($ledger_class && method_exists($ledger_class, 'list_for_vendor')) {
            $rows = \call_user_func([$ledger_class, 'list_for_vendor'], $vendor_id, '', self::sellerEpochLedgerId(), $limit);
            return is_array($rows) ? $rows : [];
        }

        error_log('[Caricove Bank][BankDashboard::seller_ledger_rows] Ledger class unavailable or unreadable for vendor_id=' . $vendor_id);

        return [];
    }

    private static function payout_storefront_name(int $vendor_id): string
    {
        return self::seller_store_name($vendor_id);
    }

    private static function payout_rows(array $args = []): array
    {
        global $wpdb;

        $table = Ledger::payouts_table();

        $search = isset($args['search']) ? trim((string) $args['search']) : '';
        $status = isset($args['status']) ? trim((string) $args['status']) : '';
        $date   = isset($args['date']) ? trim((string) $args['date']) : '';
        $limit  = isset($args['limit']) ? (int) $args['limit'] : 200;

        $limit = max(1, min(500, $limit));

        $where  = ['1=1'];
        $params = [];

        if ($status !== '') {
            $where[]  = 'status = %s';
            $params[] = $status;
        }

        if ($date !== '') {
            $where[]  = 'DATE(created_at) = %s';
            $params[] = $date;
        }

        if ($search !== '') {
            if (ctype_digit($search)) {
                $where[]  = 'vendor_id = %d';
                $params[] = (int) $search;
            } else {
                $matched_vendor_ids = [];

                $users = get_users([
                    'number'  => 300,
                    'fields'  => ['ID'],
                    'orderby' => 'ID',
                    'order'   => 'DESC',
                ]);

                foreach ((array) $users as $u) {
                    $vendor_id = (int) (is_object($u) ? $u->ID : $u);
                    if ($vendor_id <= 0) continue;

                    $store_name = self::seller_store_name($vendor_id);
                    if ($store_name !== '' && stripos($store_name, $search) !== false) {
                        $matched_vendor_ids[] = $vendor_id;
                    }
                }

                $matched_vendor_ids = array_values(array_unique(array_filter(array_map('intval', $matched_vendor_ids))));
                if (!empty($matched_vendor_ids)) {
                    $where[] = 'vendor_id IN (' . implode(',', $matched_vendor_ids) . ')';
                } else {
                    return [];
                }
            }
        }

        $sql = "
            SELECT id, vendor_id, status, amount_gross, fee, amount_net, method, destination, reference, created_at
            FROM {$table}
            WHERE " . implode(' AND ', $where) . "
            ORDER BY created_at ASC, id ASC
            LIMIT %d
        ";

        $params[] = $limit;
        $prepared = $wpdb->prepare($sql, $params);
        $rows     = $wpdb->get_results($prepared, ARRAY_A);

        if (!is_array($rows)) return [];

        foreach ($rows as &$row) {
            $vendor_id = (int) ($row['vendor_id'] ?? 0);
            $row['store_name'] = $vendor_id > 0 ? self::payout_storefront_name($vendor_id) : '';
        }
        unset($row);

        return $rows;
    }

    private static function payout_destination_label(array $row): string
    {
        $destination = trim((string) ($row['destination'] ?? ''));
        if ($destination !== '') {
            return $destination;
        }

        $vendor_id = (int) ($row['vendor_id'] ?? 0);
        if ($vendor_id <= 0) {
            return 'Not set';
        }

        return self::seller_payment_method_label($vendor_id);
    }

    private static function payout_status_label(string $status): string
    {
        $status = strtolower(trim($status));

        if ($status === 'queued' || $status === 'requested') return 'Requested';
        if ($status === 'sent') return 'Paid';
        if ($status === 'failed') return 'Failed';
        if ($status === 'denied') return 'Denied';

        return ucfirst($status !== '' ? $status : 'Unknown');
    }

    private static function payout_live_truth(int $vendor_id, array $request_row = []): array
    {
        $metrics = self::seller_metrics($vendor_id);

        $requested_amount = (float) ($request_row['amount_net'] ?? 0.0);

        $available_now    = (float) ($metrics['available'] ?? 0.0);
        $debit_exposure   = (float) ($metrics['debit_exposure'] ?? 0.0);
        $withdrawable_now = max(0.0, $available_now - $debit_exposure);

        $method_label    = self::seller_payment_method_label($vendor_id);
        $has_destination = trim($method_label) !== '' && strtolower(trim($method_label)) !== 'Not set';

        $raw_status     = strtolower(trim((string) ($request_row['status'] ?? '')));
        $is_open_status = in_array($raw_status, ['requested', 'queued'], true);

        $eligibility        = 'blocked';
        $eligibility_reason = 'Not eligible.';
        $can_pay            = false;

        if (!$is_open_status) {
            $eligibility = 'closed';
            $eligibility_reason = 'This payout request is already resolved.';
        } elseif (!$has_destination) {
            $eligibility = 'blocked';
            $eligibility_reason = 'No payout destination is configured for this seller.';
        } elseif ($requested_amount <= 0) {
            $eligibility = 'blocked';
            $eligibility_reason = 'Requested amount is invalid.';
        } elseif ($withdrawable_now <= 0) {
            $eligibility = 'blocked';
            $eligibility_reason = 'Seller has no withdrawable balance.';
        } elseif ($withdrawable_now < $requested_amount) {
            $eligibility = 'partial';
            $eligibility_reason = 'Requested amount exceeds current withdrawable balance.';
        } else {
            $eligibility = 'payable';
            $eligibility_reason = 'Request is fully covered by current withdrawable balance.';
            $can_pay = true;
        }

        return [
            'available_now'      => $available_now,
            'debit_exposure'     => $debit_exposure,
            'withdrawable_now'   => $withdrawable_now,
            'requested_amount'   => $requested_amount,
            'payable_amount'     => min($withdrawable_now, max(0.0, $requested_amount)),
            'eligibility'        => $eligibility,
            'eligibility_reason' => $eligibility_reason,
            'can_pay'            => $can_pay,
        ];
    }

    private static function payout_summary_cards(array $rows): array
    {
        $open_requests       = 0;
        $payable_now         = 0;
        $blocked_requests    = 0;
        $total_requested     = 0.0;
        $total_payable       = 0.0;
        $total_blocked_value = 0.0;

        foreach ($rows as $row) {
            $vendor_id   = (int) ($row['vendor_id'] ?? 0);
            $status      = strtolower(trim((string) ($row['status'] ?? '')));
            $request_net = (float) ($row['amount_net'] ?? 0);
            $truth       = self::payout_live_truth($vendor_id, $row);

            if (in_array($status, ['requested', 'queued'], true)) {
                $open_requests++;
                $total_requested += $request_net;
            }

            if (($truth['eligibility'] ?? '') === 'payable') {
                $payable_now++;
                $total_payable += (float) ($truth['payable_amount'] ?? 0);
            } elseif (in_array(($truth['eligibility'] ?? ''), ['blocked', 'partial'], true)) {
                $blocked_requests++;
                $total_blocked_value += $request_net;
            }
        }

        return [
            ['label' => 'Open Requests',    'value' => (string) $open_requests],
            ['label' => 'Payable Now',      'value' => (string) $payable_now],
            ['label' => 'Blocked Requests', 'value' => (string) $blocked_requests],
            ['label' => 'Total Requested',  'value' => 'GYD ' . number_format($total_requested, 2)],
            ['label' => 'Total Payable',    'value' => 'GYD ' . number_format($total_payable, 2)],
            ['label' => 'Blocked Value',    'value' => 'GYD ' . number_format($total_blocked_value, 2)],
        ];
    }

    private static function seller_payment_method_label(int $vendor_id): string
    {
        $method = (string) get_user_meta($vendor_id, '_cc_sp_method', true);

        if ($method === 'gtt') {
            $phone = (string) get_user_meta($vendor_id, '_cc_sp_gtt_phone', true);
            return 'GTT Mobile Money' . ($phone !== '' ? ' • ' . $phone : '');
        }

        if ($method === 'bank') {
            $bank_name = (string) get_user_meta($vendor_id, '_cc_sp_bank_name', true);
            $last4     = (string) get_user_meta($vendor_id, '_cc_sp_bank_last4', true);

            $label = trim($bank_name);
            if ($last4 !== '') {
                $label .= ($label !== '' ? ' • ' : '') . '****' . $last4;
            }

            return $label !== '' ? $label : 'Bank';
        }

        return 'Not set';
    }

    private static function seller_ledger_class(): ?string
    {
        $class = __NAMESPACE__ . '\\Ledger';
        return class_exists($class) ? $class : null;
    }

    private static function bankEpochLedgerId(): int
    {
        return (int) self::BANK_EPOCH_LEDGER_ID;
    }

    private static function sellerEpochLedgerId(): int
    {
        return (int) self::SELLER_LEDGER_EPOCH_ID;
    }

    private static function epochFallbackCreatedAt(): string
    {
        return (string) self::EPOCH_FALLBACK_CREATED_AT;
    }

    private static function is_after_bank_epoch_row(array $row): bool
    {
        $rowId = (int) ($row['id'] ?? 0);
        if ($rowId > 0) {
            return $rowId >= self::bankEpochLedgerId();
        }

        $createdAt = (string) ($row['created_at'] ?? '');
        if ($createdAt === '') return false;

        $rowTs   = strtotime($createdAt);
        $epochTs = strtotime(self::epochFallbackCreatedAt());

        if (!$rowTs || !$epochTs) return false;

        return $rowTs >= $epochTs;
    }

    private static function filtered_bank_rows(array $filters = [], int $limit = 100): array
    {
        if (!class_exists(__NAMESPACE__ . '\\BankLedger')) {
            return [];
        }

        $rows = BankLedger::list($filters, max(100, $limit * 5));
        if (!is_array($rows)) return [];

        $rows = array_values(array_filter($rows, static function ($row) {
            return is_array($row) && self::is_after_bank_epoch_row($row);
        }));

        usort($rows, static function ($a, $b) {
            $aId = (int) ($a['id'] ?? 0);
            $bId = (int) ($b['id'] ?? 0);
            return $bId <=> $aId;
        });

        if ($limit > 0 && count($rows) > $limit) {
            $rows = array_slice($rows, 0, $limit);
        }

        return $rows;
    }

    private static function human_event_type_label(string $event_type): string
    {
        $event_type = strtolower(trim($event_type));

$map = [
            'reversal'                  => 'Seller Earnings Reversed Before Payout',
            'seller_deduction_created'  => 'Seller Owes Caricove',
            'customer_refund_issued'    => 'Customer Refund Sent',
            'shipment_earnings_created' => 'Shipment Earnings Created',
            'vendor_liability_recovered'=> 'Vendor Liability Cleared From Payout',
            'seller_payout_sent'        => 'Seller Payout Sent',
        ];

        return $map[$event_type] ?? ucwords(str_replace('_', ' ', $event_type));
    }

private static function human_seller_state_label(string $state): string
{
    $state = strtolower(trim($state));

    $map = [
        'pending'   => 'Clearing',
        'available' => 'Available',
        'paid'      => 'Paid',
        'debit'     => 'Debt / Recovery',
        'reversed'  => 'Reversed',
        'hold'      => 'On Hold',
    ];

    return $map[$state] ?? ucfirst($state !== '' ? $state : 'Unknown');
}

public static function rest_ledger(\WP_REST_Request $request): \WP_REST_Response
{
    $filters = [
        'shipment_id' => (int) $request->get_param('shipment_id'),
        'order_id'    => (int) $request->get_param('order_id'),
        'vendor_id'   => (int) $request->get_param('vendor_id'),
        'courier_id'  => (int) $request->get_param('courier_id'),
        'event_type'  => sanitize_text_field((string) $request->get_param('event_type')),
    ];

    $rows = self::filtered_bank_rows($filters, 100);

    foreach ($rows as &$row) {
        $vendor_id = (int) ($row['vendor_id'] ?? 0);
        $row['store_name'] = $vendor_id > 0 ? self::seller_store_name($vendor_id) : '';
        $row['debug_vendor_id'] = $vendor_id;
    }
    unset($row);

    $shipment_id = (int) ($filters['shipment_id'] ?? 0);
    $vendor_id   = (int) ($filters['vendor_id'] ?? 0);

    $seller_rows = [];

    if ($shipment_id > 0) {
        global $wpdb;

        $seller_table = Ledger::table();

        if ($vendor_id > 0) {
            $seller_rows = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT *
                     FROM {$seller_table}
                     WHERE shipment_id = %d
                       AND vendor_id = %d
                     ORDER BY id ASC",
                    $shipment_id,
                    $vendor_id
                ),
                ARRAY_A
            );
        } else {
            $seller_rows = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT *
                     FROM {$seller_table}
                     WHERE shipment_id = %d
                     ORDER BY id ASC",
                    $shipment_id
                ),
                ARRAY_A
            );
        }

        if (!is_array($seller_rows)) {
            $seller_rows = [];
        }
    }

    $shipment_snapshot = [];

    if ($shipment_id > 0) {
       $pickup_address_raw  = (string) get_post_meta($shipment_id, '_cc_shipment_pickup_address', true);
$dropoff_address_raw = (string) get_post_meta($shipment_id, '_cc_shipment_dropoff_address', true);

$pickup_address  = $pickup_address_raw;
$dropoff_address = $dropoff_address_raw;

$vendor_id_for_address = (int) get_post_meta($shipment_id, '_cc_shipment_vendor_id', true);

$store_address_parts = [];
if ($vendor_id_for_address > 0) {
    $profile_settings = get_user_meta($vendor_id_for_address, 'dokan_profile_settings', true);

    if (is_array($profile_settings) && !empty($profile_settings['address']) && is_array($profile_settings['address'])) {
        $addr = $profile_settings['address'];

        $store_address_parts = array_values(array_filter([
            $addr['street_1'] ?? '',
            $addr['street_2'] ?? '',
            $addr['city'] ?? '',
            $addr['state'] ?? '',
            $addr['zip'] ?? '',
            $addr['country'] ?? '',
        ], static function ($v) {
            return $v !== null && $v !== '';
        }));
    }
}

if (!empty($store_address_parts)) {
    $pickup_address = implode(', ', $store_address_parts);
} else {
    $pickup_json = json_decode($pickup_address_raw, true);
    if (is_array($pickup_json)) {
        $pickup_address = implode(', ', array_values(array_filter([
            $pickup_json['street']   ?? '',
            $pickup_json['street_2'] ?? '',
            $pickup_json['village']  ?? '',
            $pickup_json['city']     ?? '',
            $pickup_json['region']   ?? '',
            $pickup_json['postcode'] ?? '',
            $pickup_json['country']  ?? '',
        ], static function ($v) {
            return $v !== null && $v !== '';
        })));
    }
}

        $dropoff_json = json_decode($dropoff_address_raw, true);
        if (is_array($dropoff_json)) {
            $dropoff_address = implode(', ', array_values(array_filter([
                $dropoff_json['street']   ?? '',
                $dropoff_json['street_2'] ?? '',
                $dropoff_json['village']  ?? '',
                $dropoff_json['city']     ?? '',
                $dropoff_json['region']   ?? '',
                $dropoff_json['postcode'] ?? '',
                $dropoff_json['country']  ?? '',
            ], static function ($v) {
                return $v !== null && $v !== '';
            })));
        }

        $order_id = (int) get_post_meta($shipment_id, '_cc_shipment_order_id', true);
        $order    = $order_id > 0 && function_exists('wc_get_order') ? wc_get_order($order_id) : null;

        $product_lines = [];

        if ($order) {
            foreach ($order->get_items() as $item_id => $item) {
                $linked_shipment_id = (int) wc_get_order_item_meta($item_id, '_cc_item_shipment_id', true);
                if ($linked_shipment_id !== $shipment_id) {
                    continue;
                }

                $product_lines[] = [
                    'name'  => $item->get_name(),
                    'qty'   => (int) $item->get_quantity(),
                    'total' => (float) $item->get_total(),
                ];
            }
        }

     $seller_by_state = [];
        foreach ((array) $seller_rows as $sr) {
            if (!is_array($sr)) continue;
            $seller_by_state[strtolower((string) ($sr['state'] ?? ''))] = $sr;
        }

        $pending_row   = $seller_by_state['pending']   ?? null;
        $available_row = $seller_by_state['available'] ?? null;
        $paid_row      = $seller_by_state['paid']      ?? null;
        $reversed_row  = $seller_by_state['reversed']  ?? null;
        $debit_row     = $seller_by_state['debit']     ?? null;

        $baseline_row = $pending_row ?: $available_row ?: $paid_row ?: $reversed_row ?: null;
        $baseline_meta = [];
        if (is_array($baseline_row) && !empty($baseline_row['meta'])) {
            $decoded = json_decode((string) $baseline_row['meta'], true);
            if (is_array($decoded)) {
                $baseline_meta = $decoded;
            }
        }

        $product_value_from_lines = 0.0;
        foreach ($product_lines as $pl) {
            $product_value_from_lines += (float) ($pl['total'] ?? 0);
        }

        $sale_gross = null;
        if (is_array($baseline_row) && isset($baseline_row['gross']) && (float) $baseline_row['gross'] > 0) {
            $sale_gross = (float) $baseline_row['gross'];
        } elseif ($product_value_from_lines > 0) {
            $sale_gross = round($product_value_from_lines, 2);
        } else {
            $declared = (float) get_post_meta($shipment_id, '_cc_shipment_declared_value', true);
            $sale_gross = $declared > 0 ? $declared : null;
        }

        $sale_commission = null;
        if (is_array($baseline_row) && isset($baseline_row['commission'])) {
            $sale_commission = (float) $baseline_row['commission'];
        } elseif ($sale_gross !== null && !empty($baseline_meta['return_bridge']['commission_rate'])) {
            $sale_commission = round($sale_gross * (float) $baseline_meta['return_bridge']['commission_rate'], 2);
        }

        $sale_vendor_net_original = null;
        if ($sale_gross !== null && $sale_commission !== null) {
            $sale_vendor_net_original = round($sale_gross - $sale_commission, 2);
        }

        if ($reversed_row) {
            $reversed_meta = [];
            if (!empty($reversed_row['meta'])) {
                $decoded = json_decode((string) $reversed_row['meta'], true);
                if (is_array($decoded)) {
                    $reversed_meta = $decoded;
                }
            }

            if (isset($reversed_meta['return_bridge']['reversed_amount'])) {
                $sale_vendor_net_original = (float) $reversed_meta['return_bridge']['reversed_amount'];
            } elseif ($sale_gross !== null && $sale_commission !== null) {
                $sale_vendor_net_original = round($sale_gross - $sale_commission, 2);
            }
        }

        $seller_funds_reversed = 0.0;
        if ($reversed_row) {
            $reversed_meta = [];
            if (!empty($reversed_row['meta'])) {
                $decoded = json_decode((string) $reversed_row['meta'], true);
                if (is_array($decoded)) {
                    $reversed_meta = $decoded;
                }
            }

            if (isset($reversed_meta['return_bridge']['reversed_amount'])) {
                $seller_funds_reversed = abs((float) $reversed_meta['return_bridge']['reversed_amount']);
            } elseif ($sale_vendor_net_original !== null) {
                $seller_funds_reversed = abs((float) $sale_vendor_net_original);
            }
        }

        $seller_funds_debited = $debit_row ? abs((float) ($debit_row['net'] ?? 0)) : 0.0;

$seller_funds_paid = 0.0;

/*
 * Prefer bank payout events tied to this shipment.
 * If none are present, fall back to the seller-ledger paid row.
 */
foreach ((array) $rows as $bank_row) {
    if (!is_array($bank_row)) continue;
    if ((string) ($bank_row['event_type'] ?? '') !== 'seller_payout_sent') continue;

    $seller_funds_paid += abs((float) ($bank_row['amount'] ?? 0));
}

if ($seller_funds_paid <= 0 && $paid_row) {
    $seller_funds_paid = abs((float) ($paid_row['net'] ?? 0));
}
        $commission_reversed = 0.0;
        foreach ((array) $rows as $bank_row) {
            if (!is_array($bank_row)) continue;
            if ((string) ($bank_row['event_type'] ?? '') !== 'customer_refund_issued') continue;

            $meta = [];
            if (!empty($bank_row['meta_json'])) {
                $decoded = is_array($bank_row['meta_json']) ? $bank_row['meta_json'] : json_decode((string) $bank_row['meta_json'], true);
                if (is_array($decoded)) {
                    $meta = $decoded;
                }
            }

            if (isset($meta['commission_reversal'])) {
                $commission_reversed += abs((float) $meta['commission_reversal']);
            }
        }

        if ($commission_reversed <= 0 && $reversed_row && $sale_commission !== null) {
            $commission_reversed = abs((float) $sale_commission);
        }

        $platform_net_effect = null;
        if ($sale_commission !== null) {
            $platform_net_effect = round((float) $sale_commission - (float) $commission_reversed, 2);
        }

        $shipment_snapshot = [
            'shipment_id'             => $shipment_id,
            'order_id'                => (int) get_post_meta($shipment_id, '_cc_shipment_order_id', true),
            'shipment_status'         => (string) get_post_meta($shipment_id, '_cc_shipment_status', true),
            'store_name'              => (string) get_post_meta($shipment_id, '_cc_shipment_pickup_name', true),
            'pickup_name'             => (string) get_post_meta($shipment_id, '_cc_shipment_pickup_name', true),
            'customer_name'           => (string) get_post_meta($shipment_id, '_cc_shipment_dropoff_name', true),
            'dropoff_name'            => (string) get_post_meta($shipment_id, '_cc_shipment_dropoff_name', true),
            'item_count'              => (int) get_post_meta($shipment_id, '_cc_shipment_item_count', true),
            'shipment_declared_value' => (float) get_post_meta($shipment_id, '_cc_shipment_declared_value', true),
            'pickup_address'          => $pickup_address,
            'dropoff_address'         => $dropoff_address,
            'order_total'             => $order ? (float) $order->get_total() : null,
            'order_shipping_total'    => $order ? (float) $order->get_shipping_total() : 0,
            'product_lines'           => $product_lines,

            'sale_gross'              => $sale_gross,
            'sale_commission'         => $sale_commission,
            'sale_vendor_net_original'=> $sale_vendor_net_original,
           'seller_funds_reversed'   => $seller_funds_reversed,
'seller_funds_debited'    => $seller_funds_debited,
'seller_funds_paid'       => $seller_funds_paid,
'commission_reversed'     => $commission_reversed,
'platform_net_effect'     => $platform_net_effect,
        ];
    }

    return new \WP_REST_Response([
        'rows'                      => $rows,
        'seller_rows'               => $seller_rows,
        'shipment_snapshot'         => $shipment_snapshot,
        'bank_epoch_ledger_id'      => self::bankEpochLedgerId(),
        'seller_epoch_ledger_id'    => self::sellerEpochLedgerId(),
        'epoch_fallback_created_at' => self::epochFallbackCreatedAt(),
    ]);
}
}
