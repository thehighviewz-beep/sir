<?php
/**
 * Plugin Name: Caricove Ledger Purity Repair
 * Description: One-time admin repair tool for normalizing seller ledger meta after legacy wallet/inspector drift. Not loaded by the bank plugin.
 */

if (!defined('ABSPATH')) exit;

final class Caricove_Ledger_Purity_Repair {
    public static function boot(): void {
        add_management_page('Ledger Purity Repair', 'Ledger Purity Repair', 'manage_options', 'caricove-ledger-purity-repair', [__CLASS__, 'render']);
        add_action('admin_post_caricove_ledger_purity_repair', [__CLASS__, 'handle']);
    }

    private static function table(): string {
        global $wpdb;
        return $wpdb->prefix . 'cc_sp_ledger';
    }

    private static function money($v): float { return round((float)$v, 2); }
    private static function decode($raw): array { $d = json_decode((string)$raw, true); return is_array($d) ? $d : []; }
    private static function encode(array $meta): string { return wp_json_encode($meta, JSON_UNESCAPED_SLASHES); }

    private static function fallback_slice_id(int $shipment_id, int $order_item_id = 0): string {
        return $order_item_id > 0 ? 'ship:' . $shipment_id . ':item:' . $order_item_id : 'ship:' . $shipment_id . ':fallback';
    }

    private static function normalize_slices($raw, int $shipment_id): array {
        $out = [];
        foreach ((array)$raw as $slice) {
            if (!is_array($slice)) continue;
            $amount = self::money(max(0, (float)($slice['amount'] ?? 0)));
            if ($amount <= 0) continue;
            $qty = max(0.000001, round((float)($slice['qty'] ?? 1), 6));
            $order_item_id = (int)($slice['order_item_id'] ?? 0);
            $slice_id = trim((string)($slice['slice_id'] ?? ''));
            if ($slice_id === '') $slice_id = self::fallback_slice_id($shipment_id, $order_item_id);
            $out[] = [
                'slice_id' => $slice_id,
                'shipment_id' => $shipment_id,
                'order_item_id' => $order_item_id,
                'product_id' => (int)($slice['product_id'] ?? 0),
                'name' => (string)($slice['name'] ?? ''),
                'qty' => $qty,
                'amount' => $amount,
                'unit_amount' => self::money($amount / max(0.000001, $qty)),
                'legacy_fallback' => !empty($slice['legacy_fallback']),
            ];
        }
        return $out;
    }

    private static function slices_total(array $slices): float {
        $sum = 0.0;
        foreach ($slices as $slice) $sum += (float)($slice['amount'] ?? 0);
        return self::money($sum);
    }

    private static function scale_slices(array $slices, float $target, int $shipment_id): array {
        $target = self::money(max(0, $target));
        $slices = self::normalize_slices($slices, $shipment_id);
        if ($target <= 0) return [];
        if (!$slices) {
            return [[
                'slice_id' => self::fallback_slice_id($shipment_id),
                'shipment_id' => $shipment_id,
                'order_item_id' => 0,
                'product_id' => 0,
                'name' => 'Ledger amount',
                'qty' => 1,
                'amount' => $target,
                'unit_amount' => $target,
                'legacy_fallback' => true,
            ]];
        }
        $current = self::slices_total($slices);
        if (abs($current - $target) <= 0.02) return $slices;
        $remaining = $target;
        $scaled = [];
        $count = count($slices);
        foreach ($slices as $i => $slice) {
            if ($i === $count - 1) $amount = $remaining;
            else $amount = self::money($target * ((float)$slice['amount'] / max(0.000001, $current)));
            $remaining = self::money($remaining - $amount);
            if ($amount <= 0) continue;
            $slice['amount'] = $amount;
            $slice['unit_amount'] = self::money($amount / max(0.000001, (float)($slice['qty'] ?? 1)));
            $scaled[] = $slice;
        }
        return self::normalize_slices($scaled, $shipment_id);
    }

    private static function edges_total($edges): float {
        $sum = 0.0;
        foreach ((array)$edges as $edge) if (is_array($edge)) $sum += max(0, (float)($edge['amount'] ?? 0));
        return self::money($sum);
    }

    private static function slices_from_offset_sources(array $edges, int $shipment_id, float $target_total): array {
        $slices = [];
        foreach ($edges as $edge) {
            if (!is_array($edge)) continue;
            $amount = self::money(max(0, (float)($edge['amount'] ?? 0)));
            if ($amount <= 0) continue;
            $order_item_id = (int)($edge['target_order_item_id'] ?? 0);
            $slice_id = trim((string)($edge['target_slice_id'] ?? ''));
            if ($slice_id === '' || strpos($slice_id, 'auto-target-') === 0 || strpos($slice_id, 'pending-target-') === 0) {
                $slice_id = self::fallback_slice_id($shipment_id, $order_item_id);
            }
            if (!isset($slices[$slice_id])) {
                $slices[$slice_id] = [
                    'slice_id' => $slice_id,
                    'shipment_id' => $shipment_id,
                    'order_item_id' => $order_item_id,
                    'product_id' => (int)($edge['target_product_id'] ?? 0),
                    'name' => (string)($edge['target_name'] ?? 'Recovered seller earnings'),
                    'qty' => 1,
                    'amount' => 0,
                    'unit_amount' => 0,
                    'legacy_fallback' => ($order_item_id <= 0),
                ];
            }
            $slices[$slice_id]['amount'] = self::money((float)$slices[$slice_id]['amount'] + $amount);
            $slices[$slice_id]['unit_amount'] = self::money((float)$slices[$slice_id]['amount'] / max(0.000001, (float)$slices[$slice_id]['qty']));
        }
        return self::scale_slices(array_values($slices), $target_total, $shipment_id);
    }

    private static function normalize_reopen_history($events, float $source_original): array {
        $source_original = self::money(max(0, $source_original));
        $out = [];
        $seen = [];
        $total = 0.0;
        foreach ((array)$events as $event) {
            if (!is_array($event)) continue;
            $amount = self::money(max(0, (float)($event['amount'] ?? 0)));
            if ($amount <= 0) continue;
            $key = implode('|', [
                (int)($event['target_row_id'] ?? 0),
                (string)($event['target_slice_id'] ?? ''),
                (string)($event['source_slice_id'] ?? ''),
                (string)($event['case_id'] ?? ($event['refund_case_id'] ?? '')),
                number_format($amount, 2, '.', ''),
            ]);
            if (isset($seen[$key])) continue;
            $seen[$key] = true;
            if ($source_original > 0) {
                $cap = self::money($source_original - $total);
                if ($cap <= 0) break;
                $amount = min($amount, $cap);
            }
            $event['amount'] = self::money($amount);
            $out[] = $event;
            $total = self::money($total + $amount);
        }
        return array_values($out);
    }

    private static function repair_row(array $row): array {
        $meta = self::decode($row['meta'] ?? '');
        $before = $meta;
        $shipment_id = (int)($row['shipment_id'] ?? ($meta['shipment_id'] ?? 0));
        $vendor_id = (int)($row['vendor_id'] ?? ($meta['vendor_id'] ?? 0));
        $state = strtolower((string)($row['state'] ?? ''));
        $net = self::money((float)($row['net'] ?? 0));
        $payout_mode = strtolower((string)($meta['payout_mode'] ?? ''));

        $target_slice_total = ($state === 'debit') ? abs($net) : max(0, $net);
        if ($target_slice_total <= 0) {
            $meta['financial_slices'] = [];
        } elseif ($payout_mode === 'offset' && !empty($meta['offset_sources']) && is_array($meta['offset_sources'])) {
            $meta['financial_slices'] = self::slices_from_offset_sources((array)$meta['offset_sources'], $shipment_id, $target_slice_total);
        } else {
            $meta['financial_slices'] = self::scale_slices((array)($meta['financial_slices'] ?? []), $target_slice_total, $shipment_id);
        }

        if ($state !== 'pending') {
            unset($meta['pending_offset_reserved_total'], $meta['pending_offset_reserved_at'], $meta['reserved_offset_sources']);
        }
        unset($meta['refund_target_unwind_fallback_reason']);

        foreach (['historical_offset_sources_unwound'] as $key) {
            $clean = [];
            $archive = [];
            foreach ((array)($meta[$key] ?? []) as $edge) {
                if (!is_array($edge)) continue;
                if ((string)($edge['match_mode'] ?? '') === 'edge_fallback_offset_sources') {
                    $edge['legacy_archived_reason'] = 'Removed from canonical chain because it was produced by fallback source guessing.';
                    $archive[] = $edge;
                    continue;
                }
                $clean[] = $edge;
            }
            if ($archive) {
                $meta['legacy_' . $key . '_archived'] = $archive;
                $meta[$key] = $clean;
            }
        }

        $is_debit_like = ($state === 'debit' || (string)($meta['type'] ?? '') === 'debit' || strpos((string)($row['unique_key'] ?? ''), 'refund-debit:') === 0 || strpos((string)($row['unique_key'] ?? ''), 'shipping:') === 0);
        if ($is_debit_like) {
            $offset_targets = array_values(array_filter((array)($meta['offset_targets'] ?? []), static function($edge){
                return is_array($edge) && (float)($edge['amount'] ?? 0) > 0;
            }));
            $recovered = self::edges_total($offset_targets);
            $open = ($state === 'debit') ? abs($net) : 0.0;
            $bridge = isset($meta['return_bridge']) && is_array($meta['return_bridge']) ? $meta['return_bridge'] : [];
            $bridge_amount = max(0, (float)($bridge['seller_impact'] ?? 0), (float)($bridge['vendor_impact'] ?? 0), (float)($bridge['item_price_net'] ?? 0), (float)($bridge['original_net'] ?? 0));
            $source_original = self::money(max($open + $recovered, (float)($meta['source_amount_original'] ?? 0), $bridge_amount));
            if ($source_original <= 0) $source_original = self::money($open + $recovered);
            $history = self::normalize_reopen_history((array)($meta['historical_offset_targets_reopened'] ?? []), $source_original);
            $events = self::normalize_reopen_history((array)($meta['source_reopen_events'] ?? []), $source_original);
            $meta['historical_offset_targets_reopened'] = $history;
            $meta['source_reopen_events'] = $events;
            $meta['source_amount_original'] = $source_original;
            $meta['source_amount_still_recovered'] = $recovered;
            $meta['source_amount_currently_open'] = self::money($open);
            $meta['source_amount_reopened_total'] = self::money(min($source_original, max(self::edges_total($history), $open)));
            $meta['debit_offset_applied'] = $recovered;
            $meta['chain_source_slice'] = $source_original;
            $meta['chain_source_remaining'] = self::money($open);
            $meta['chain_role_state'] = $open > 0.009 ? 'SOURCE' : 'RESOLVED';
            $meta['offset_targets'] = $offset_targets;
        }

        if (isset($meta['trace_context']) && is_array($meta['trace_context']) && $vendor_id > 0 && (int)($meta['trace_context']['vendor_id'] ?? 0) <= 0) {
            $meta['trace_context']['vendor_id'] = $vendor_id;
        }

        $changed = (self::encode($before) !== self::encode($meta));
        return ['changed' => $changed, 'meta' => $meta];
    }

    public static function handle(): void {
        if (!current_user_can('manage_options')) wp_die('Forbidden');
        check_admin_referer('caricove_ledger_purity_repair');
        $apply = !empty($_POST['apply']);
        $vendor_id = absint($_POST['vendor_id'] ?? 0);
        $result = self::run($apply, $vendor_id);
        set_transient('caricove_ledger_purity_repair_last', $result, 300);
        wp_safe_redirect(add_query_arg(['page' => 'caricove-ledger-purity-repair', 'done' => 1], admin_url('tools.php')));
        exit;
    }

    private static function run(bool $apply, int $vendor_id = 0): array {
        global $wpdb;
        $table = self::table();
        $exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table));
        if (!$exists) return ['error' => 'Ledger table not found: ' . $table];
        $where = $vendor_id > 0 ? $wpdb->prepare('WHERE vendor_id=%d', $vendor_id) : '';
        $rows = $wpdb->get_results("SELECT * FROM {$table} {$where} ORDER BY id ASC", ARRAY_A);
        $changed = [];
        foreach ((array)$rows as $row) {
            $fixed = self::repair_row((array)$row);
            if (empty($fixed['changed'])) continue;
            $changed[] = [
                'id' => (int)$row['id'],
                'shipment_id' => (int)$row['shipment_id'],
                'state' => (string)$row['state'],
                'event_type' => (string)$row['event_type'],
            ];
            if ($apply) {
                $wpdb->update($table, ['meta' => self::encode($fixed['meta']), 'updated_at' => current_time('mysql')], ['id' => (int)$row['id']], ['%s','%s'], ['%d']);
            }
        }
        return ['apply' => $apply, 'vendor_id' => $vendor_id, 'scanned' => count((array)$rows), 'changed' => count($changed), 'rows' => $changed];
    }

    public static function render(): void {
        if (!current_user_can('manage_options')) return;
        $last = get_transient('caricove_ledger_purity_repair_last');
        ?>
        <div class="wrap">
            <h1>Caricove Ledger Purity Repair</h1>
            <p>This is a one-time meta normalizer for legacy rows. It does not create payouts, refunds, or ledger rows. Dry run first, then apply after a database backup.</p>
            <?php if (is_array($last)): ?><pre style="background:#fff;border:1px solid #ccd0d4;padding:12px;max-height:360px;overflow:auto"><?php echo esc_html(wp_json_encode($last, JSON_PRETTY_PRINT)); ?></pre><?php endif; ?>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="background:#fff;border:1px solid #ccd0d4;padding:16px;max-width:760px">
                <?php wp_nonce_field('caricove_ledger_purity_repair'); ?>
                <input type="hidden" name="action" value="caricove_ledger_purity_repair">
                <p><label><strong>Vendor ID</strong> <input type="number" min="0" name="vendor_id" value="1"> <span class="description">0 = all vendors</span></label></p>
                <p><button class="button">Dry run</button> <button class="button button-primary" name="apply" value="1" onclick="return confirm('Apply ledger purity repair after backup?');">Apply repair</button></p>
            </form>
        </div>
        <?php
    }
}

Caricove_Ledger_Purity_Repair::boot();
