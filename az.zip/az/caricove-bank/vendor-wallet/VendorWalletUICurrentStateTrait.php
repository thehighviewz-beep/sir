<?php
namespace Caricove\SellerPayouts;

use Caricove\Bank\Ledger;

if (!defined('ABSPATH')) exit;

trait VendorWalletUICurrentStateTrait {
    protected function buildWalletCurrentStateContext(array $ctx): array {
        extract($ctx, EXTR_SKIP);
        $wallet_inspector_enabled = false;

        // Read-only wallet path: do not mutate ledger state during render.
        // Pending->available promotion must happen in command/scheduler flows only.

        // Totals (include debit in truthy available)
        $s = Ledger::sums_for_vendor($uid);
        $pending_total    = (float)($s['pending'] ?? 0);
        $available_total  = (float)($s['available'] ?? 0);
        $paid_total       = (float)($s['paid'] ?? 0);
        $hold_total       = (float)($s['hold'] ?? 0); // backend logic only (not displayed)
        $debit_total      = (float)($s['debit'] ?? 0); // negative if vendor owes

        $ledger_pending_total   = $pending_total;
        $ledger_available_total = $available_total;
        $ledger_paid_total      = $paid_total;
        $ledger_hold_total      = $hold_total;
        $ledger_debit_total     = $debit_total;


        // ------------------------------------------------------------
        // Pending tile must reflect return debits for shipments still pending
        // (Otherwise cards show deduction but Pending total looks unchanged.)
        // ------------------------------------------------------------
        global $wpdb;

        $pending_payable = $pending_total;     // what we will display in the Pending tile
        $pending_debits_abs = 0.0;             // absolute total of debits tied to pending shipments only

        // We already load rows below, but we can safely read them here as well.
        // If you prefer not to call list_for_vendor twice, move this block lower
        // (after $rows_all = Ledger::list_for_vendor($uid);) and remove this call.
        $rows_all_for_pending = Ledger::list_for_vendor($uid);

        // Collect shipment_ids that are currently in state='pending'
        $pending_shipment_ids = [];
        foreach ($rows_all_for_pending as $r) {
            $state = strtolower((string)($r['state'] ?? ''));
            if ($state !== 'pending') continue;

            $sid = (int)($r['shipment_id'] ?? 0);
            if ($sid > 0) $pending_shipment_ids[$sid] = true;
        }
        $pending_shipment_ids = array_keys($pending_shipment_ids);

        if (!empty($pending_shipment_ids)) {
            $lt = Ledger::table();
            $placeholders = implode(',', array_fill(0, count($pending_shipment_ids), '%d'));

            // Sum net for debit rows (negative values). We take abs() so it's a positive "deduction".
            $sql = "
        SELECT COALESCE(SUM(net), 0)
        FROM {$lt}
        WHERE vendor_id = %d
          AND state = 'debit'
          AND net < 0
          AND shipment_id IN ($placeholders)
            ";

            $args = array_merge([$uid], $pending_shipment_ids);
            $prep = $wpdb->prepare($sql, $args);
            $sum_net = (float) $wpdb->get_var($prep); // negative or 0

            if ($sum_net < 0) {
        $pending_debits_abs = abs($sum_net);
        $pending_payable = $pending_total - $pending_debits_abs;
        if ($pending_payable < 0) $pending_payable = 0.0;
            }
        }




             // Separate truths:
        // Temporarily seed these from raw ledger; they will be recomputed later
        // from canonical shipment rows after dedupe/recovery mapping.
        $debit_exposure_abs = 0.0;
        if ($debit_total < 0) {
            $debit_exposure_abs = abs($debit_total);
        }

        $available_payable = $available_total + $debit_total;
        if ($available_payable < 0) $available_payable = 0.0;

        $available_hint = 'No funds yet';
        if ($available_total > 0) {
            $available_hint = 'Ready';
            if ($debit_exposure_abs > 0) {
                $available_hint = 'Active debit exposure • Residual withdrawable ' . number_format($available_payable, 2) . ' GYD';
            }
        }

        $is_wallet_admin = current_user_can('manage_options');
        $inspector_rows = [];
        $inspector_rows[] = [
            'label' => 'Pending',
            'ledger' => round((float)$ledger_pending_total, 2),
            'canonical' => round((float)$pending_total, 2),
        ];
        $inspector_rows[] = [
            'label' => 'Available',
            'ledger' => round((float)$ledger_available_total, 2),
            'canonical' => round((float)$available_total, 2),
        ];
        $inspector_rows[] = [
            'label' => 'Paid',
            'ledger' => round((float)$ledger_paid_total, 2),
            'canonical' => round((float)$paid_total, 2),
        ];
        $inspector_rows[] = [
            'label' => 'Debit exposure',
            'ledger' => round(abs((float)min(0.0, (float)$ledger_debit_total)), 2),
            'canonical' => round((float)$debit_exposure_abs, 2),
        ];

        $inspector_mismatches = [];
        foreach ($inspector_rows as $ir) {
            $diff = round((float)$ir['canonical'] - (float)$ir['ledger'], 2);
            if (abs($diff) > 0.009) {
                $inspector_mismatches[] = [
                    'label' => $ir['label'],
                    'diff' => $diff,
                ];
            }
        }

        if (!isset($debit_queue) || !is_array($debit_queue)) {
            $debit_queue = [];
        }

        $inspector_open_debits = [];
        foreach ($debit_queue as $dq) {
            $rem = round((float)($dq['remaining'] ?? 0), 2);
            if ($rem <= 0) continue;
            $inspector_open_debits[] = [
                'shipment_id' => (int)($dq['shipment_id'] ?? 0),
                'remaining' => $rem,
            ];
        }

        // Payout method
        $method = (string)get_user_meta($uid, '_cc_sp_method', true);
        if ($method !== 'gtt' && $method !== 'bank') $method = 'gtt';

        $gtt_phone   = (string)get_user_meta($uid, '_cc_sp_gtt_phone', true);
        $bank_name   = (string)get_user_meta($uid, '_cc_sp_bank_name', true);
        $bank_holder = (string)get_user_meta($uid, '_cc_sp_bank_holder', true);
        $bank_last4  = (string)get_user_meta($uid, '_cc_sp_bank_last4', true);

        $dest_display = $this->display_destination($method, $gtt_phone, $bank_name, $bank_holder, $bank_last4);

        // Nonces
        $nonce_method  = wp_create_nonce('cc_sp_save_payout_method_v2');
        $nonce_instant = wp_create_nonce('cc_sp_instant_cashout');

        // Instant fee rate from settings
              $instant_fee_rate = 0.0; $this->bank_setting('instant_fee_rate', 0.00);
        // Has payout method?
        $has_method = false;
        if ($method === 'gtt') {
            $has_method = (trim($gtt_phone) !== '');
        } elseif ($method === 'bank') {
            $has_method = (trim($bank_name) !== '' && trim($bank_holder) !== '' && trim($bank_last4) !== '');
        }

        // Ledger rows (raw)
        $rows_all = Ledger::list_for_vendor($uid);
        $shipping_liability_rows = [];
        $active_debit_rows = [];
        $active_debit_breakdown_rows = [];
        $shipping_liability_total_abs = 0.0;
        $active_debit_exposure_total_abs = 0.0;
        $open_shipping_liability_by_shipment = [];
        $open_active_debit_by_shipment = [];

        foreach ((array) $rows_all as $r) {
            $state = strtolower((string) ($r['state'] ?? ''));
            if ($state !== 'debit') {
                continue;
            }

            $meta = json_decode((string) ($r['meta'] ?? ''), true);
            $meta = is_array($meta) ? $meta : [];
            $bridge = !empty($meta['return_bridge']) && is_array($meta['return_bridge']) ? $meta['return_bridge'] : [];
            $kind = strtolower(trim((string) ($bridge['kind'] ?? $meta['debit_component'] ?? '')));
            $note = strtolower((string) ($r['note'] ?? ''));
            $amount_abs = abs((float) ($r['net'] ?? 0));
            $shipment_id_for_row = (int) ($r['shipment_id'] ?? 0);

            $is_shipping = !empty($meta['shipping_liability'])
                || !empty($meta['shipping_liability_posting_key'])
                || !empty($meta['shipping_posting_key'])
                || !empty($bridge['is_shipping_component'])
                || in_array($kind, ['shipping', 'shipping_liability'], true);

            if ($is_shipping) {
                $shipping_liability_rows[] = $r;
                $shipping_liability_total_abs += $amount_abs;
                if ($shipment_id_for_row > 0) {
                    $open_shipping_liability_by_shipment[$shipment_id_for_row] = round((float) ($open_shipping_liability_by_shipment[$shipment_id_for_row] ?? 0) + $amount_abs, 2);
                }
                continue;
            }

            $active_debit_rows[] = $r;
            $active_debit_exposure_total_abs += $amount_abs;
            if ($shipment_id_for_row > 0) {
                $open_active_debit_by_shipment[$shipment_id_for_row] = round((float) ($open_active_debit_by_shipment[$shipment_id_for_row] ?? 0) + $amount_abs, 2);
            }

            $reason = trim((string) ($r['note'] ?? 'Debit exposure'));
            if (!empty($meta['seller_debit_exposure']) || $kind === 'seller_debit_exposure') {
                $reason = 'Seller Debit Exposure';
            } elseif ($kind === 'return') {
                $reason = 'Refund adjustment';
            } elseif ($kind === 'cancel') {
                $reason = 'Cancellation adjustment';
            }

            $active_debit_breakdown_rows[] = [
                'reason' => $reason,
                'amount' => round($amount_abs, 2),
                'shipment_id' => $shipment_id_for_row,
                'order_id' => (int) ($r['order_id'] ?? 0),
                'status' => (string) ($meta['settlement_state'] ?? ($r['state'] ?? 'posted')),
            ];
        }

        $shipping_liability_total_abs = round($shipping_liability_total_abs, 2);
        $active_debit_exposure_total_abs = round($active_debit_exposure_total_abs, 2);

        /**
         * OPTION A rule:
         * - Do NOT show standalone "debit" rows in the feed.
         * - Do NOT show the "marker reversal" rows (the all-zero reversal audit row).
         * - Show deductions inline on the shipment row instead.
         */
              $rows = array_values(array_filter($rows_all, function($r){
            $state = strtolower((string)($r['state'] ?? ''));
            if ($state === 'debit') return false;

            // Hide the all-zero reversal marker row (inserted for audit/idempotency)
            if ($state === 'reversed') {
                $gross      = (float)($r['gross'] ?? 0);
                $commission = (float)($r['commission'] ?? 0);
                $courier    = (float)($r['courier_fees'] ?? 0);
                $reserve    = (float)($r['reserve'] ?? 0);
                $net        = (float)($r['net'] ?? 0);

                if ($gross == 0.0 && $commission == 0.0 && $courier == 0.0 && $reserve == 0.0 && $net == 0.0) {
                    // CCVW_KEEP_FULLY_REVERSED_RETURN_HISTORY_ROW
                    // Fully-refunded-before-payout shipments can become all-zero
                    // ledger rows, but still carry the authoritative return history
                    // used by the wallet modal. Those rows are not junk markers.
                    $meta_raw = (string)($r['meta'] ?? '');
                    $meta = $meta_raw !== '' ? json_decode($meta_raw, true) : [];
                    $meta = is_array($meta) ? $meta : [];

                    $has_return_history = false;
                    if (!empty($meta['historical_return_slices']) && is_array($meta['historical_return_slices'])) {
                        $has_return_history = true;
                    }
                    if (!empty($meta['audit_return_bridge']) && is_array($meta['audit_return_bridge'])) {
                        $has_return_history = true;
                    }
                    if (!empty($meta['return_bridge']) && is_array($meta['return_bridge'])) {
                        $has_return_history = true;
                    }
                    if (!empty($meta['embedded_return_history_only'])) {
                        $has_return_history = true;
                    }

                    if (!$has_return_history) {
                        return false;
                    }
                }
            }

            return true;
        }));

        // Canonicalize feed: one visible row per shipment_id.
        // Keep the "best" row for the shipment using state priority, then newest id.
             // Conservative canonicalization: prefer earlier states so
        // shipments never appear available prematurely.
        $state_rank = [
            'hold'      => 500,
            'pending'   => 400,
            'available' => 300,
            'paid'      => 200,
            'reversed'  => 100,
        ];
        $deduped = [];
        foreach ($rows as $r) {
            $sid = (int)($r['shipment_id'] ?? 0);
            if ($sid <= 0) continue;

            $state = strtolower((string)($r['state'] ?? 'pending'));
            $rank  = (int)($state_rank[$state] ?? 0);
            $id    = (int)($r['id'] ?? 0);

            if (!isset($deduped[$sid])) {
                $deduped[$sid] = $r;
                continue;
            }

            $existing      = $deduped[$sid];
            $existingState = strtolower((string)($existing['state'] ?? 'pending'));
            $existingRank  = (int)($state_rank[$existingState] ?? 0);
            $existingId    = (int)($existing['id'] ?? 0);

            if ($rank > $existingRank || ($rank === $existingRank && $id > $existingId)) {
                $deduped[$sid] = $r;
            }
        }

        $rows = array_values($deduped);

        // ------------------------------------------------------------
        // Recalculate wallet tiles from canonical shipment rows
        // so cards and tiles always reconcile
        // ------------------------------------------------------------

        $pending_total = 0.0;
        $available_total = 0.0;
        $paid_total = 0.0;

        foreach ($rows as $rr) {

            $state = strtolower((string)($rr['state'] ?? ''));

            $net = (float)($rr['net'] ?? 0);

            // handle reversed shipments
            if ($state === 'reversed') {
        $meta_raw = (string)($rr['meta'] ?? '');
        if ($meta_raw) {
            $j = json_decode($meta_raw, true);
            if (is_array($j) && isset($j['return_bridge']['original_net'])) {
                $net = (float)$j['return_bridge']['original_net'];
            }
        }
        $net = 0.0;
            }

            if ($state === 'pending') {
        $pending_total += max(0.0, $net);
            }

            if ($state === 'available') {
        $available_total += max(0.0, $net);
            }

            if ($state === 'paid') {
        $paid_total += max(0.0, $net);
            }
        }

        $pending_total   = round($pending_total, 2);
        $available_total = round($available_total, 2);
        $paid_total      = round($paid_total, 2);

        // Pending payable must follow the same canonical shipment-row truth
        $pending_payable = $pending_total;
        $pending_debits_abs = 0.0;

        // available/debit/wallet hint are recomputed later after recovery allocation



        usort($rows, function($a, $b){
            $aState = strtolower((string)($a['state'] ?? ''));
            $bState = strtolower((string)($b['state'] ?? ''));

            $state_rank = [
                'pending'   => 500,
                'hold'      => 400,
                'available' => 300,
                'paid'      => 200,
                'reversed'  => 100,
            ];

            $ar = (int)($state_rank[$aState] ?? 0);
            $br = (int)($state_rank[$bState] ?? 0);

            if ($ar !== $br) return $br <=> $ar;

            $aId = (int)($a['id'] ?? 0);
            $bId = (int)($b['id'] ?? 0);
            return $bId <=> $aId;
        });








        $stage_defined = get_defined_vars();
        unset($stage_defined['ctx'], $stage_defined['stage_defined']);
        return array_merge($ctx, $stage_defined);
    }
}