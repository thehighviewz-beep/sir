<?php
namespace Caricove\SellerPayouts;

use Caricove\Bank\Ledger;

if (!defined('ABSPATH')) exit;

trait VendorWalletUIModalPresenterTrait {
    protected function buildWalletModalPresenterContext(array $ctx): array {
        extract($ctx, EXTR_SKIP);
        // Prebuild shipment modal payload (server-side) — dedupe by shipment_id
        $modal_map = [];
        foreach ($rows as $r) {
            $ledger_id   = (int)($r['id'] ?? 0);
            $shipment_id = (int)($r['shipment_id'] ?? 0);
            $order_id    = (int)($r['order_id'] ?? 0);

            if ($ledger_id <= 0 || $shipment_id <= 0) continue;
            if (isset($modal_map[$shipment_id])) continue;

            $cx_name  = (string) get_post_meta($shipment_id, '_cc_shipment_dropoff_name', true);
            $cx_phone = (string) get_post_meta($shipment_id, '_cc_shipment_dropoff_phone', true);
            $addr_raw = (string) get_post_meta($shipment_id, '_cc_shipment_dropoff_address', true);

            $addr = $this->parse_address($addr_raw);

            // Ledger-based item outcome quantities (delta model)
            $cancelled_qty_by_item = $this->get_cancelled_qty_by_item_for_shipment($shipment_id);
            $refund_outcome_qty_by_item = $this->get_refund_outcome_qty_by_item_for_shipment($shipment_id);
            $returned_qty_by_item       = (array)($refund_outcome_qty_by_item['returned'] ?? []);
            $returnless_qty_by_item     = (array)($refund_outcome_qty_by_item['returnless'] ?? []);
            $never_received_qty_by_item = (array)($refund_outcome_qty_by_item['never_received'] ?? []);
            $return_pending_qty_by_item = (array)($refund_outcome_qty_by_item['return_pending'] ?? []);

            $items = [];
            $order_number = $order_id ? (string)$order_id : '';

            if (function_exists('wc_get_order') && $order_id > 0) {
                $order = wc_get_order($order_id);
                if ($order) {
                    $order_number = method_exists($order, 'get_order_number') ? (string)$order->get_order_number() : (string)$order_id;

                    if (!$cx_name) {
                        $cx_name = trim($order->get_shipping_first_name() . ' ' . $order->get_shipping_last_name());
                        if (!$cx_name) $cx_name = trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name());
                    }
                    if (!$cx_phone) {
                        $cx_phone = (string)$order->get_billing_phone();
                    }
                    if (!$addr['street']) {
                        $addr['street']  = (string)$order->get_shipping_address_1();
                        $addr['city']    = (string)$order->get_shipping_city();
                        $addr['region']  = (string)$order->get_shipping_state();
                        $addr['country'] = (string)$order->get_shipping_country();
                    }

                    $shipment_item_ids = [];
                    $shipment_item_ids_raw = get_post_meta($shipment_id, '_cc_shipment_item_ids', true);
                    if (is_string($shipment_item_ids_raw)) {
                        $shipment_item_ids_raw = maybe_unserialize($shipment_item_ids_raw);
                    }
                    if (is_array($shipment_item_ids_raw) && !empty($shipment_item_ids_raw)) {
                        $shipment_item_ids = array_values(array_filter(array_map('intval', $shipment_item_ids_raw)));
                    }
                    $item_shipment_meta_key = class_exists('\Caricove\Logistics\Core\Schema')
                        ? \Caricove\Logistics\Core\Schema::META_ITEM_SHIPMENT_ID
                        : '_cc_item_shipment_id';

                    foreach ($order->get_items() as $item_id => $item) {
                        $product = $item->get_product();
                        if (!$product) continue;

                        $mapped_shipment_id = (int) wc_get_order_item_meta($item_id, $item_shipment_meta_key, true);
                        if ($shipment_id > 0) {
                            if ($mapped_shipment_id > 0 && $mapped_shipment_id !== (int) $shipment_id) {
                                continue;
                            }
                            if ($mapped_shipment_id <= 0 && $shipment_item_ids && !in_array((int) $item_id, $shipment_item_ids, true)) {
                                continue;
                            }
                            if ($mapped_shipment_id <= 0 && !$shipment_item_ids) {
                                continue;
                            }
                        }

                        $pid = $product->get_id();
                        $author_id = (int) get_post_field('post_author', $pid);
                        if ($author_id !== $uid) continue;

                        $ordered_qty   = (int) $item->get_quantity();
                        $cancelled_qty = (int) ($cancelled_qty_by_item[(int)$item_id] ?? 0);
                        if ($cancelled_qty < 0) $cancelled_qty = 0;
                        if ($cancelled_qty > $ordered_qty) $cancelled_qty = $ordered_qty;

                        $delivered_qty = max(0, $ordered_qty - $cancelled_qty);

                        $returned_qty = (int) ($returned_qty_by_item[(int)$item_id] ?? 0);
                        if ($returned_qty < 0) $returned_qty = 0;
                        if ($returned_qty > $delivered_qty) $returned_qty = $delivered_qty;

                        $returnless_qty = (int) ($returnless_qty_by_item[(int)$item_id] ?? 0);
                        if ($returnless_qty < 0) $returnless_qty = 0;
                        if ($returnless_qty > $delivered_qty) $returnless_qty = $delivered_qty;

                        $never_received_qty = (int) ($never_received_qty_by_item[(int)$item_id] ?? 0);
                        if ($never_received_qty < 0) $never_received_qty = 0;
                        if ($never_received_qty > $ordered_qty) $never_received_qty = $ordered_qty;

                        $return_pending_qty = (int) ($return_pending_qty_by_item[(int)$item_id] ?? 0);
                        if ($return_pending_qty < 0) $return_pending_qty = 0;
                        if ($return_pending_qty > $delivered_qty) $return_pending_qty = $delivered_qty;

                      // Base product name (deduped): use parent title for variations
                        $base_name = (string) $item->get_name();
                        if ( $product ) {
                            if ( method_exists($product, 'is_type') && $product->is_type('variation') ) {
                                $parent_id = (int) $product->get_parent_id();
                                if ( $parent_id > 0 ) {
                                    $pt = (string) get_the_title($parent_id);
                                    if ( $pt !== '' ) $base_name = $pt;
                                }
                            } elseif ( $pid > 0 ) {
                                $pt = (string) get_the_title($pid);
                                if ( $pt !== '' ) $base_name = $pt;
                            }
                        }

                       // Variation/meta pills (hide internal keys like _cc_* etc)
                        $meta_pairs = [];
                        foreach ( $item->get_formatted_meta_data() as $md ) {
                            $k = is_object($md) && isset($md->display_key) ? (string) $md->display_key : '';
                            $v = is_object($md) && isset($md->display_value) ? wp_strip_all_tags((string) $md->display_value) : '';
                            $k = trim($k); $v = trim($v);
                            if ( $k === '' || $v === '' ) continue;

                            // Block internal/private keys
                            $k_l = strtolower($k);
                            if ( strpos($k, '_') === 0 ) continue;
                            if ( strpos($k_l, 'cc_') === 0 || strpos($k_l, '_cc_') === 0 ) continue;

                            // Exclude Vendor (you never want it as a pill)
                            if ( $k_l === 'vendor' || strpos($k_l, 'vendor') !== false ) continue;

                            $meta_pairs[] = [ 'k' => $k, 'v' => $v ];
                        }

                        /**
                         * Fallback: if Woo doesn't provide useful meta pills (common when name is "de - White, XS"),
                         * parse the "tail" after " - " and make value-only pills.
                         */
                        $has_real_meta = ! empty($meta_pairs);
                        if ( ! $has_real_meta ) {
                            $nm = (string) $item->get_name();
                            if ( $nm !== '' && strpos($nm, ' - ') !== false ) {
                                $tail = trim( substr($nm, strpos($nm, ' - ') + 3) );
                                if ( $tail !== '' ) {
                                    $parts = preg_split('/\s*,\s*/', $tail);
                                    foreach ( $parts as $tok ) {
                                        $tok = trim((string)$tok);
                                        if ( $tok === '' ) continue;

                                        // Dedupe vs existing values (case-insensitive)
                                        $dupe = false;
                                        foreach ( $meta_pairs as $mp ) {
                                            $vv = isset($mp['v']) ? strtolower(trim((string)$mp['v'])) : '';
                                            if ( $vv !== '' && $vv === strtolower($tok) ) { $dupe = true; break; }
                                        }
                                        if ( ! $dupe ) $meta_pairs[] = [ 'k' => '', 'v' => $tok ];
                                    }
                                }
                            }
                        }
                        $items[] = [
                            'item_id'        => (int) $item_id,
                            'name'           => (string) $item->get_name(),
                            'base_name'      => (string) $base_name,
                            'ordered_qty'    => (int) $ordered_qty,
                            'delivered_qty'  => (int) $delivered_qty,
                            'cancelled_qty'  => (int) $cancelled_qty,
                            'returned_qty'   => (int) $returned_qty,
                            'returnless_qty' => (int) $returnless_qty,
                            'never_received_qty' => (int) $never_received_qty,
                            'return_pending_qty' => (int) $return_pending_qty,
                            'meta'           => $meta_pairs,
                        
                            // Back-compat: previously rendered as ×qty
                            'qty'            => $delivered_qty,
                        ];
                    }
                }
            }

            $cx_name_priv  = $this->mask_name($cx_name);
            $cx_phone_priv = $this->mask_phone($cx_phone);

            $addr_line1 = $addr['street'] ?: '—';
            $addr_line2 = trim(($addr['city'] ?: '') . (($addr['region'] ? ', ' . $addr['region'] : '')));
            if (!$addr_line2) $addr_line2 = '—';

        $row_state = strtolower((string)($r['state'] ?? ''));

          $is_guilty_shipment = ($shipment_id > 0 && isset($guilty_shipment_ids[$shipment_id]));

        $historical_paid_recovery_deduct = 0.0;
        if ($row_state === 'paid' && isset($canonical_display_recovery_by_target_shipment[$shipment_id])) {
            // Keep paid rows on the same visible card story they used before cash-out.
            // Do not fall back to historical paid-offset reconstruction for display math.
            $historical_paid_recovery_deduct = max(0.0, (float)$canonical_display_recovery_by_target_shipment[$shipment_id]);
        }

        $card_modal_type = 'normal';
        if ($row_state === 'reversed') {
            $card_modal_type = 'reversed';
        } elseif (
            !$is_guilty_shipment &&
            (
        ((float)($card_recovery_by_shipment[$shipment_id] ?? 0)) > 0 ||
        $historical_paid_recovery_deduct > 0
            )
        ) {
            $card_modal_type = 'recovery';
        }

           $adjustment_source_shipment_id = 0;
        $adjustment_source_shipment_ids = [];
        $deduct_source_shipments = [];

        if ($row_state === 'reversed') {
            $adjustment_source_shipment_id = $shipment_id;
            $adjustment_source_shipment_ids = [$shipment_id];
            $deduct_source_shipments = [$shipment_id];
        } elseif ($card_modal_type === 'recovery') {
            $merged_source_ids = array_map('intval', array_keys((array)($trace_source_ids_by_target_shipment[$shipment_id] ?? [])));

            // Read persisted scar snapshot first if available on the row itself.
            $snapshot_source_ids = [];
            $snapshot_meta_rows = [];
            $meta_raw_for_snapshot = (string)($r['meta'] ?? '');
            if ($meta_raw_for_snapshot !== '') {
        $mmSnapshot = json_decode($meta_raw_for_snapshot, true);
        if (is_array($mmSnapshot)) {
            if (!empty($mmSnapshot['trace_historical_offset_snapshot']) && is_array($mmSnapshot['trace_historical_offset_snapshot'])) {
                $snap = $mmSnapshot['trace_historical_offset_snapshot'];
                if (!empty($snap['source_shipment_ids']) && is_array($snap['source_shipment_ids'])) {
                    $snapshot_source_ids = array_values(array_map('intval', $snap['source_shipment_ids']));
                }
                if (!empty($snap['return_rows']) && is_array($snap['return_rows'])) {
                    $snapshot_meta_rows = $snap['return_rows'];
                }
            }
            if (!$snapshot_source_ids && !empty($mmSnapshot['trace_source_shipment_ids']) && is_array($mmSnapshot['trace_source_shipment_ids'])) {
                $snapshot_source_ids = array_values(array_map('intval', $mmSnapshot['trace_source_shipment_ids']));
            }
        }
            }

            // Visible source lineage must not mutate after cash-out by importing
            // paid-history/reconstructed source ids. Use live/trace ids plus any
            // explicit frozen snapshot only.
            $merged_source_ids = array_merge($merged_source_ids, $snapshot_source_ids);

            $adjustment_source_shipment_ids = array_values(array_unique(array_filter($merged_source_ids, function($v) use ($shipment_id){
        return (int)$v > 0 && (int)$v !== (int)$shipment_id;
            })));

            $adjustment_source_shipment_id = (int)($adjustment_source_shipment_ids[0] ?? ($card_recovery_source_by_shipment[$shipment_id] ?? 0));
            $deduct_source_shipments = $adjustment_source_shipment_ids;
        } else {
            // Normal/target shipments do not become their own source just because a modal opens.
            // They can still show direct shipment-local return rows separately via direct_return_rows.
            $adjustment_source_shipment_id = 0;
            $adjustment_source_shipment_ids = [];
            $deduct_source_shipments = [];
        }

            $meta_rows = [];
            $current_case_id = '';
            $current_case = [];
            $force_case_scoped_return_breakdown = false;

            $return_rows = $this->build_deduction_explain_for_shipments($deduct_source_shipments);
            $meta_raw_for_trace = (string)($r['meta'] ?? '');
            if ($meta_raw_for_trace !== '') {
                $mm = json_decode($meta_raw_for_trace, true);
                if (is_array($mm) && !empty($mm['trace_return_rows']) && is_array($mm['trace_return_rows'])) {
                    $meta_rows = $mm['trace_return_rows'];
                }
               if (is_array($mm)) {
                    $rb = !empty($mm['return_bridge']) && is_array($mm['return_bridge']) ? (array) $mm['return_bridge'] : [];

                    $case_ids_in_trace = [];

                    foreach ((array)($mm['historical_return_slices'] ?? []) as $slice) {
                        if (!is_array($slice)) continue;
                        $cid = trim((string)($slice['case_id'] ?? ''));
                        if ($cid !== '') {
                            $case_ids_in_trace[$cid] = true;
                        }
                    }

                    $bridge_case_id = trim((string) ($rb['case_id'] ?? ($mm['case_id'] ?? '')));
                    if ($bridge_case_id !== '') {
                        $case_ids_in_trace[$bridge_case_id] = true;
                    }

                    // Only force case-scoped breakdown when this shipment row truly maps to ONE case.
                    if (count($case_ids_in_trace) === 1) {
                        $current_case_id = (string) array_key_first($case_ids_in_trace);
                    } else {
                        $current_case_id = '';
                    }

                    if ($current_case_id !== '') {
                        $force_case_scoped_return_breakdown = true;
                        if (class_exists('Caricove\Bank\BankRefundCases')) {
                            $loaded_case = \Caricove\Bank\BankRefundCases::get_case($current_case_id);
                            if (is_array($loaded_case)) {
                                $current_case = $loaded_case;
                            }
                        }
                        $return_rows = $this->build_deduction_explain_for_shipments($deduct_source_shipments, '');
                    }
                }
            }
            if (!$return_rows && !$force_case_scoped_return_breakdown && isset($trace_return_rows_by_target_shipment[$shipment_id])) {
                $return_rows = (array)$trace_return_rows_by_target_shipment[$shipment_id];
            }
            if (!$return_rows && !$force_case_scoped_return_breakdown && $meta_rows) {
                $return_rows = $meta_rows;
            }
            if (!$return_rows && !$force_case_scoped_return_breakdown && !empty($snapshot_meta_rows)) {
                $return_rows = (array)$snapshot_meta_rows;
            }
            $return_rows = $normalize_trace_rows($return_rows);
            if (($row_state === 'reversed' || $card_modal_type === 'recovery') && !$adjustment_source_shipment_ids && !empty($return_rows)) {
                $from_rows = [];
                foreach ($return_rows as $rrx) {
                    $sidv = (int)($rrx['source_shipment_id'] ?? 0);
                    if ($sidv > 0) $from_rows[$sidv] = true;
                }
                $adjustment_source_shipment_ids = array_values(array_map('intval', array_keys($from_rows)));
                $adjustment_source_shipment_id = (int)($adjustment_source_shipment_ids[0] ?? 0);
            }
            $direct_return_rows = $this->build_deduction_explain_for_shipments([$shipment_id], '');
            if (!$direct_return_rows && !$force_case_scoped_return_breakdown && isset($trace_return_rows_by_source_shipment[$shipment_id])) {
                $direct_return_rows = (array)$trace_return_rows_by_source_shipment[$shipment_id];
            }
            if (!$direct_return_rows && !$force_case_scoped_return_breakdown && !empty($trace_snapshot_by_source_shipment[$shipment_id]['return_rows'])) {
                $direct_return_rows = (array)$trace_snapshot_by_source_shipment[$shipment_id]['return_rows'];
            }
            if (!$direct_return_rows && !$force_case_scoped_return_breakdown && $meta_rows) {
                $direct_return_rows = $meta_rows;
            }
            $direct_return_rows = $normalize_trace_rows($direct_return_rows);

          $modal_map[$shipment_id] = [
                'ledger_id'                      => $ledger_id,
                'shipment_id'                    => $shipment_id,
                'order_number'                   => $order_number ?: '—',
                'cx_name'                        => $cx_name_priv ?: '—',
                'cx_phone'                       => $cx_phone_priv ?: '—',
                'addr1'                          => $addr_line1,
                'addr2'                          => $addr_line2,
                'items'                          => $items,
                'deduct_explain'                 => $return_rows,
                'direct_return_rows'             => $direct_return_rows,
                'has_return_breakdown'           => !empty($return_rows),
                'has_direct_return_breakdown'    => !empty($direct_return_rows),
                'case_id'                       => $current_case_id,
                'case_initial_fault'            => (string) ($current_case['initial_fault'] ?? ''),
                'case_shipping_liability_party' => (string) ($current_case['shipping_liability_party'] ?? ''),
                'case_refund_execution_mode'    => (string) ($current_case['refund_execution_mode'] ?? ''),
                'case_financial_status'         => (string) ($current_case['financial_status'] ?? ''),
                'case_order_shipping_already_allocated' => (function($bucket) {
                    if (is_string($bucket) && $bucket !== '') {
                        $bucket = maybe_unserialize($bucket);
                    }
                    return round((float) (is_array($bucket) ? ($bucket['already_allocated_shipping'] ?? 0) : 0), 2);
                })($current_case['order_shipping_refund_bucket'] ?? []),
                'case_order_shipping_total_refundable' => (function($bucket) {
                    if (is_string($bucket) && $bucket !== '') {
                        $bucket = maybe_unserialize($bucket);
                    }
                    return round((float) (is_array($bucket) ? ($bucket['total_shipping_refundable'] ?? 0) : 0), 2);
                })($current_case['order_shipping_refund_bucket'] ?? []),
                'case_item_received_flag'       => !empty($current_case['item_received_flag']) ? 1 : 0,
                'case_return_required'          => !empty($current_case['return_required']) ? 1 : 0,
                'case_chain_mode'               => (string) ($ledger_meta_by_shipment[$shipment_id]['chain_mode'] ?? ''),
            'card_recovery_deduct'           => ($historical_paid_recovery_deduct > 0
                    ? (float)$historical_paid_recovery_deduct
                    : (float)($visible_current_nonshipping_absorb_by_target_shipment[$shipment_id] ?? ($card_recovery_by_shipment[$shipment_id] ?? 0))),
                'live_recovery_sources'          => (function() use ($shipment_id, $visible_current_nonshipping_sources_by_target_shipment, $card_recovery_sources_by_shipment) {
                    $out = [];
                    $srcMap = (array)($visible_current_nonshipping_sources_by_target_shipment[$shipment_id] ?? ($card_recovery_sources_by_shipment[$shipment_id] ?? []));
                    foreach ($srcMap as $source_sid => $amt) {
                        $source_sid = (int)$source_sid;
                        $amt = round((float)$amt, 2);
                        if ($source_sid <= 0 || $amt <= 0) continue;
                        $out[$source_sid] = $amt;
                    }
                    ksort($out, SORT_NUMERIC);
                    return $out;
                })(),
                'debug_chain_role'               => (function() use ($shipment_id, $uid) {
                    $chain = \Caricove\Bank\Ledger::inspect_shipment_chain_state((int)$shipment_id, (int)$uid);
                    return [
                        'role_state' => (string)($chain['role_state'] ?? ''),
                        'active_source_amount' => round((float)($chain['active_source_amount'] ?? 0), 2),
                        'active_target_amount' => round((float)($chain['active_target_amount'] ?? 0), 2),
                    ];
                })(),
                'debug_live_recovery_sources'    => (function() use ($shipment_id, $visible_current_nonshipping_sources_by_target_shipment, $card_recovery_sources_by_shipment) {
                    $out = [];
                    $srcMap = (array)($visible_current_nonshipping_sources_by_target_shipment[$shipment_id] ?? ($card_recovery_sources_by_shipment[$shipment_id] ?? []));
                    foreach ($srcMap as $k => $v) {
                        $out[(int)$k] = round((float)$v, 2);
                    }
                    return $out;
                })(),
                'card_modal_type'                => $card_modal_type,
                'adjustment_source_shipment_id'  => $adjustment_source_shipment_id,
                'adjustment_source_shipment_ids' => $adjustment_source_shipment_ids,
                'is_guilty_shipment'             => $is_guilty_shipment,
                'open_source_liability_amount'   => round((float)(($open_active_debit_by_shipment[$shipment_id] ?? 0) + ($open_shipping_liability_by_shipment[$shipment_id] ?? 0)), 2),
                
                'affected_recovery_shipments'    => (function() use ($shipment_id, $guilty_shipment_ids, $trace_targets_by_source_shipment, $r, $trace_snapshot_by_source_shipment, $canonical_display_recovery_by_target_shipment, $canonical_display_earnings_by_target_shipment, $ledger_meta_by_shipment) {
                    $raw_targets = [];
                    foreach ((array)($trace_targets_by_source_shipment[$shipment_id] ?? []) as $sid => $amt) {
                        $sid = (int)$sid;
                        $amt = round((float)$amt, 2);
                        if ($sid <= 0 || $sid === (int)$shipment_id || $amt <= 0) {
                            continue;
                        }
                        $raw_targets[$sid] = max((float)($raw_targets[$sid] ?? 0.0), $amt);
                    }
                    if (!$raw_targets && !empty($trace_snapshot_by_source_shipment[$shipment_id]['affected_recovery_shipments'])) {
                        foreach ((array)$trace_snapshot_by_source_shipment[$shipment_id]['affected_recovery_shipments'] as $rowv) {
                            if (!is_array($rowv)) continue;
                            $sid = (int)($rowv['shipment_id'] ?? 0);
                            $amt = round((float)($rowv['amount'] ?? 0), 2);
                            if ($sid <= 0 || $sid === (int)$shipment_id || $amt <= 0) continue;
                            $raw_targets[$sid] = max((float)($raw_targets[$sid] ?? 0.0), $amt);
                        }
                    }
                    if (!$raw_targets) {
                        $mraw = (string)($r['meta'] ?? '');
                        if ($mraw !== '') {
                            $mm = json_decode($mraw, true);
                            if (is_array($mm)) {
                                $rowsv = [];
                                if (!empty($mm['trace_historical_offset_snapshot']) && is_array($mm['trace_historical_offset_snapshot']) && !empty($mm['trace_historical_offset_snapshot']['affected_recovery_shipments']) && is_array($mm['trace_historical_offset_snapshot']['affected_recovery_shipments'])) {
                                    $rowsv = $mm['trace_historical_offset_snapshot']['affected_recovery_shipments'];
                                }
                                if (!$rowsv) {
                                    foreach (['trace_affected_recovery_shipments','affected_recovery_shipments'] as $k) {
                                        if (!empty($mm[$k]) && is_array($mm[$k])) { $rowsv = $mm[$k]; break; }
                                    }
                                }
                                foreach ((array)$rowsv as $rowv) {
                                    if (!is_array($rowv)) continue;
                                    $sid = (int)($rowv['shipment_id'] ?? 0);
                                    $amt = round((float)($rowv['amount'] ?? 0), 2);
                                    if ($sid <= 0 || $sid === (int)$shipment_id || $amt <= 0) continue;
                                    $raw_targets[$sid] = max((float)($raw_targets[$sid] ?? 0.0), $amt);
                                }
                            }
                        }
                    }

                    // Final truth filter: a source modal may only show a contributor shipment
                    // if that contributor row's CURRENT source allocation map still allocates a
                    // positive amount to this source shipment. This suppresses stale
                    // affected_recovery_shipments history after contributor-side rebalancing.
                    foreach ($raw_targets as $sid => $raw_amt) {
                        $sid = (int)$sid;
                        $current_meta = (array)($ledger_meta_by_shipment[$sid] ?? []);
                        $current_map = [];
                        if (!empty($current_meta['trace_source_shipment_amounts']) && is_array($current_meta['trace_source_shipment_amounts'])) {
                            $current_map = $current_meta['trace_source_shipment_amounts'];
                        } elseif (!empty($current_meta['source_shipment_amounts']) && is_array($current_meta['source_shipment_amounts'])) {
                            $current_map = $current_meta['source_shipment_amounts'];
                        }

                        // If contributor row has a current map and this source is no longer in it,
                        // suppress it from this source modal entirely.
                        if ($current_map) {
                            $current_amt = round((float)($current_map[$shipment_id] ?? $current_map[(string)$shipment_id] ?? 0), 2);
                            if ($current_amt <= 0) {
                                unset($raw_targets[$sid]);
                                continue;
                            }
                            // Contributor-side current map wins over stale source-side history.
                            $raw_targets[$sid] = $current_amt;
                        }
                    }

                    $out = [];
                    foreach ($raw_targets as $sid => $raw_amt) {
                        $sid = (int)$sid;
                        $raw_amt = round((float)$raw_amt, 2);
                        if ($sid <= 0 || $raw_amt <= 0) continue;

                        $display_cap = round((float)($canonical_display_recovery_by_target_shipment[$sid] ?? 0.0), 2);
                        $earnings_cap = round((float)($canonical_display_earnings_by_target_shipment[$sid] ?? 0.0), 2);
                        if ($display_cap <= 0 && $earnings_cap > 0) {
                            $display_cap = $earnings_cap;
                        }
                        if ($display_cap > 0) {
                            $raw_amt = min($raw_amt, $display_cap);
                        } elseif ($earnings_cap > 0) {
                            $raw_amt = min($raw_amt, $earnings_cap);
                        }

                        $raw_amt = round((float)$raw_amt, 2);
                        if ($raw_amt <= 0) continue;

                        $out[] = [
                            'shipment_id' => $sid,
                            'amount'      => $raw_amt,
                        ];
                    }

                    usort($out, static function($a, $b) {
                        return (int)($a['shipment_id'] ?? 0) <=> (int)($b['shipment_id'] ?? 0);
                    });
                    return array_values($out);
                })(),
            ];
        }

        $stage_defined = get_defined_vars();
        unset($stage_defined['ctx'], $stage_defined['stage_defined']);
        return array_merge($ctx, $stage_defined);
    }
}