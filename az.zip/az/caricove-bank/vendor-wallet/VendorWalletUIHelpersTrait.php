<?php
namespace Caricove\SellerPayouts;

use Caricove\Bank\Ledger;

if (!defined('ABSPATH')) exit;

trait VendorWalletUIHelpersTrait {
    private function display_destination(string $method, string $gtt_phone, string $bank_name, string $bank_holder, string $bank_last4): string {
        if ($method === 'bank') {
            if (!$bank_name || !$bank_holder || !$bank_last4) return '';
            $h = $this->mask_holder($bank_holder);
            return "{$bank_name} • {$h} • acct ****{$bank_last4}";
        }
        if (!$gtt_phone) return '';
        return "GTT Mobile Money • ****" . $this->last4_digits($gtt_phone);
    }
    
    private function bank_setting(string $key, $default = null) {
        $filtered = apply_filters('caricove_bank_seller_ledger_setting', null, $key, $default);
        if ($filtered !== null) {
            return $filtered;
        }

        $bank_store = get_option('caricove_bank_settings', []);
        if (is_array($bank_store) && array_key_exists($key, $bank_store)) {
            return $bank_store[$key];
        }

        $bank_seller_store = get_option('caricove_bank_seller_settings', []);
        if (is_array($bank_seller_store) && array_key_exists($key, $bank_seller_store)) {
            return $bank_seller_store[$key];
        }

        // legacy fallback only if bank settings are not present
        $legacy = get_option('cc_sp_settings', []);
        if (is_array($legacy) && array_key_exists($key, $legacy)) {
            return $legacy[$key];
        }

        $single_keys = [
            'caricove_bank_' . $key,
            'caricove_bank_seller_' . $key,
            'cc_sp_' . $key,
        ];

        foreach ($single_keys as $opt_key) {
            $value = get_option($opt_key, null);
            if ($value !== null) {
                return $value;
            }
        }

        return $default;
    }

    private function last4_digits(string $s): string {
        $d = preg_replace('/\D+/', '', $s);
        if ($d === '') return '';
        return substr($d, -4);
    }

    private function mask_holder(string $name): string {
        $name = trim($name);
        if ($name === '') return '';
        $parts = preg_split('/\s+/', $name);
        $first = $parts[0] ?? '';
        $last = end($parts) ?: '';
        $l = $last ? strtoupper(substr($last,0,1)) . '.' : '';
        return trim($first . ' ' . $l);
    }

    private function mask_name(string $name): string {
        $name = trim($name);
        if ($name === '') return '';
        $parts = preg_split('/\s+/', $name);
        $first = $parts[0] ?? '';
        $last = end($parts) ?: '';
        $li = $last ? strtoupper(substr($last,0,1)) . '.' : '';
        return trim($first . ' ' . $li);
    }

    private function mask_phone(string $phone): string {
        $d = preg_replace('/\D+/', '', (string)$phone);
        if ($d === '') return '';
        $last4 = substr($d, -4);
        return '*** ' . $last4;
    }

    private function parse_address(string $raw): array {
        $out = ['street'=>'','city'=>'','region'=>'','country'=>''];
        $raw = trim($raw);
        if ($raw === '') return $out;

        $j = json_decode($raw, true);
        if (is_array($j)) {
            $out['street']  = trim((string)($j['street'] ?? ''));
            $out['city']    = trim((string)($j['city'] ?? ''));
            $out['region']  = trim((string)($j['region'] ?? ''));
            $out['country'] = trim((string)($j['country'] ?? ''));
        }
        return $out;
    }

    /**
     * Ledger truth: sum delta-cancel quantities per order item for this shipment.
     * Uses cc_sp_ledger debit rows with meta.type === 'cancellation_adjustment'.
     *
     * @return array<int,int> map of item_id => cancelled_qty_total
     */
    private function get_cancelled_qty_by_item_for_shipment(int $shipment_id): array {
        global $wpdb;
        $out = [];
        if ($shipment_id <= 0) return $out;
if (!class_exists('Caricove\Bank\Ledger')) return $out;
        $table = Ledger::table();

        $rows = $wpdb->get_results(
            $wpdb->prepare("SELECT meta FROM {$table} WHERE shipment_id=%d AND state IN ('debit','reversed') ORDER BY id ASC", $shipment_id),
            ARRAY_A
        );

        if (!is_array($rows) || !$rows) return $out;

        foreach ($rows as $r) {
            $mraw = $r['meta'] ?? '';
            if (!is_string($mraw) || $mraw === '') continue;

            $m = json_decode($mraw, true);
            if (!is_array($m)) continue;

            $type = strtolower((string)($m['type'] ?? ''));
            if ($type !== 'cancellation_adjustment') continue;

            $item_id = (int)($m['item_id'] ?? 0);
            $qty     = (int)($m['cancel_qty'] ?? 0);

            if ($item_id <= 0 || $qty <= 0) continue;

            $out[$item_id] = (int)($out[$item_id] ?? 0) + $qty;
        }

        return $out;
    }

    /**
     * Truth buckets per order item for refund outcomes on this shipment.
     *
     * Seller-facing “Returned” must mean physically returned AND received.
     * Returnless/refund-only and never-received cases are money outcomes, not physical returns.
     *
     * @return array{returned:array<int,int>,returnless:array<int,int>,never_received:array<int,int>,return_pending:array<int,int>}
     */
    private function get_refund_outcome_qty_by_item_for_shipment(int $shipment_id): array {
        global $wpdb;

        $out = [
            'returned'       => [],
            'returnless'     => [],
            'never_received' => [],
            'return_pending' => [],
        ];

        if ($shipment_id <= 0) return $out;
        if (!class_exists('Caricove\\Bank\\Ledger')) return $out;

        $table = Ledger::table();
        $rows = $wpdb->get_results(
            $wpdb->prepare("SELECT state, meta FROM {$table} WHERE shipment_id=%d ORDER BY id ASC", $shipment_id),
            ARRAY_A
        );

        if (!is_array($rows) || !$rows) return $out;

        $seen_history = [];

        foreach ($rows as $r) {
            $mraw = $r['meta'] ?? '';
            if (!is_string($mraw) || $mraw === '') continue;

            $m = json_decode($mraw, true);
            if (!is_array($m)) continue;

            $history = [];
            if (!empty($m['historical_return_slices']) && is_array($m['historical_return_slices'])) {
                $history = array_merge($history, (array) $m['historical_return_slices']);
            }
            if (!empty($m['return_bridge']) && is_array($m['return_bridge'])) {
                $history[] = $m['return_bridge'];
            }

            foreach ($history as $rb) {
                if (!is_array($rb)) continue;

                $kind = strtolower(trim((string)($rb['kind'] ?? 'return')));
                if (!empty($rb['is_shipping_component']) || !empty($rb['is_seller_debit_exposure']) || $kind === 'shipping' || $kind === 'seller_debit_exposure') continue;

                $item_id = (int)($rb['item_id'] ?? 0);
                if ($item_id <= 0) continue;

                $case_id = trim((string)($rb['case_id'] ?? ($m['case_id'] ?? '')));
                $hk = $case_id . '|' . (string)($rb['unique_key'] ?? '') . '|' . (string)($rb['slice_id'] ?? '') . '|' . $kind . '|' . (string)$item_id . '|' . (string)($rb['seller_impact'] ?? $rb['original_net'] ?? 0);
                if (isset($seen_history[$hk])) continue;
                $seen_history[$hk] = true;

                $outcome = $this->wallet_refund_outcome_for_row($rb, $m);
                if (!isset($out[$outcome])) $outcome = 'returned';

                $qty = $this->wallet_refund_qty_for_row($rb, $m, $outcome);
                if ($qty <= 0) continue;

                $out[$outcome][$item_id] = (float)($out[$outcome][$item_id] ?? 0) + $qty;
            }
        }

        foreach ($out as $bucket => $map) {
            foreach ($map as $item_id => $qty) {
                $out[$bucket][$item_id] = (int) round((float)$qty);
            }
        }

        return $out;
    }

    /**
     * Back-compat: returned_qty now means physically returned and received only.
     * @return array<int,int>
     */
    private function get_returned_qty_by_item_for_shipment(int $shipment_id): array {
        $buckets = $this->get_refund_outcome_qty_by_item_for_shipment($shipment_id);
        return (array)($buckets['returned'] ?? []);
    }

    private function wallet_truth_bool($value, bool $default = false): bool {
        if (is_bool($value)) return $value;
        if (is_int($value) || is_float($value)) return ((float)$value) > 0;
        if (is_string($value)) {
            $v = strtolower(trim($value));
            if ($v === '') return $default;
            if (in_array($v, ['1','yes','true','y','on','received','complete','completed'], true)) return true;
            if (in_array($v, ['0','no','false','n','off','none','pending'], true)) return false;
        }
        return $default;
    }

    private function wallet_refund_case_context(array $rb, array $m): array {
        $case_id = trim((string)($rb['case_id'] ?? ($m['case_id'] ?? '')));
        $case = [];
        if ($case_id !== '' && class_exists('Caricove\\Bank\\BankRefundCases')) {
            try {
                $loaded = \Caricove\Bank\BankRefundCases::get_case($case_id);
                if (is_array($loaded)) $case = $loaded;
            } catch (\Throwable $e) {
                $case = [];
            }
        }

        $mode = strtolower(trim((string)($case['refund_execution_mode'] ?? $rb['refund_execution_mode'] ?? $m['refund_execution_mode'] ?? '')));
        $reason = strtolower(trim((string)($case['reason_code'] ?? $case['reason'] ?? $rb['reason_code'] ?? $m['reason_code'] ?? '')));
        $status = strtolower(trim((string)($case['status'] ?? $case['financial_status'] ?? $rb['status'] ?? $m['financial_status'] ?? '')));

        $return_required_raw = $case['return_required'] ?? $rb['return_required'] ?? $m['return_required'] ?? null;
        $return_required_known = ($return_required_raw !== null && $return_required_raw !== '');
        $return_required = $this->wallet_truth_bool($return_required_raw, false);

        $item_received_raw = $case['item_received_flag'] ?? $case['item_received'] ?? $case['received_flag'] ?? $rb['item_received_flag'] ?? $m['item_received_flag'] ?? null;
        $item_received_known = ($item_received_raw !== null && $item_received_raw !== '');
        $item_received = $this->wallet_truth_bool($item_received_raw, false);

        return [
            'case_found'            => !empty($case),
            'case_id'               => $case_id,
            'case'                  => $case,
            'mode'                  => $mode,
            'reason'                => $reason,
            'status'                => $status,
            'return_required'       => $return_required,
            'return_required_known' => $return_required_known,
            'item_received'         => $item_received,
            'item_received_known'   => $item_received_known,
        ];
    }

    private function wallet_refund_outcome_for_row(array $rb, array $m): string {
        $ctx = $this->wallet_refund_case_context($rb, $m);
        $mode = $ctx['mode'];
        $reason = $ctx['reason'];
        $status = $ctx['status'];
        $case = (array)($ctx['case'] ?? []);

        $needle = $mode . '|' . $reason . '|' . $status;
        if (preg_match('/never[_ -]?received|not[_ -]?received|never[_ -]?arriv|not[_ -]?arriv|lost[_ -]?package|missing[_ -]?package/', $needle)) {
            return 'never_received';
        }

        $is_returnless_mode = in_array($mode, [
            'refund_only',
            'returnless',
            'returnless_refund',
            'no_return_required',
            'refund_without_return',
            'low_value_refund_only',
            'instant_refund',
        ], true);

        $is_returnless_flag = !empty($case['low_value_refund_only'])
            || !empty($case['returnless_refund'])
            || !empty($case['refund_only'])
            || !empty($rb['low_value_refund_only'])
            || !empty($m['low_value_refund_only']);

        if ($is_returnless_mode || $is_returnless_flag) {
            return 'returnless';
        }

        if ($ctx['return_required_known'] && !$ctx['return_required']) {
            return 'returnless';
        }

        if ($ctx['return_required'] || $mode === 'return_required') {
            return $ctx['item_received'] ? 'returned' : 'return_pending';
        }

        // Legacy fallback: old rows without case metadata used to mean a returned/refunded item.
        return 'returned';
    }

    private function wallet_refund_qty_for_row(array $rb, array $m, string $outcome): float {
        $ctx = $this->wallet_refund_case_context($rb, $m);
        $case = (array)($ctx['case'] ?? []);

        $qty = (float)($rb['qty_refundable'] ?? $rb['qty'] ?? 0);
        if ($qty <= 0) $qty = 1.0;

        if ($outcome === 'returned') {
            foreach (['item_received_qty','received_qty','qty_received','return_received_qty','actual_received_qty'] as $key) {
                if (isset($case[$key]) && (float)$case[$key] > 0) {
                    $qty = min($qty, (float)$case[$key]);
                    break;
                }
            }
        }

        return max(0.0, $qty);
    }

    /**
     * Build deduction explainer rows for a shipment block (returns + cancellations).
     * Output is consumed client-side (modal) only.
     */

  private function build_deduction_explain_for_shipments(array $shipment_ids, string $case_id_filter = ''): array {
        global $wpdb;
        $out = [];

        if (!class_exists('Caricove\Bank\Ledger')) return $out;

        $shipping_only_pre_return_case = false;
        if ($case_id_filter !== '' && class_exists('Caricove\Bank\BankRefundCases')) {
            $case = \Caricove\Bank\BankRefundCases::get_case($case_id_filter);
            if (is_array($case)) {
                $shipping_only_pre_return_case = (
                    (string) ($case['financial_status'] ?? '') === 'shipping_posted'
                    && (string) ($case['refund_execution_mode'] ?? '') === 'return_required'
                    && empty($case['item_received_flag'])
                );
            }
        }

        $shipment_ids = array_values(array_unique(array_filter(array_map('intval', $shipment_ids), function($v){
            return $v > 0;
        })));

        if (!$shipment_ids) return $out;

        $table = Ledger::table();
        $placeholders = implode(',', array_fill(0, count($shipment_ids), '%d'));

        $sql = $wpdb->prepare(
            "SELECT shipment_id, state, net, currency, meta
             FROM {$table}
             WHERE shipment_id IN ({$placeholders})
             ORDER BY id ASC",
            ...$shipment_ids
        );

        $rows = $wpdb->get_results($sql, ARRAY_A);
        if (!is_array($rows) || !$rows) return $out;

        $seen_histories = [];

        foreach ($rows as $r) {
            $mraw = $r['meta'] ?? '';
            if (!is_string($mraw) || $mraw === '') continue;

$m = json_decode($mraw, true);
            if (!is_array($m)) continue;

            $row_kind = strtolower(trim((string)($m['kind'] ?? ($m['type'] ?? ''))));
            $row_bridge = !empty($m['return_bridge']) && is_array($m['return_bridge']) ? (array)$m['return_bridge'] : [];
            $row_case_id = trim((string)($row_bridge['case_id'] ?? ($m['case_id'] ?? '')));

            $row_is_shipping = !empty($m['shipping_liability'])
                || !empty($m['shipping_liability_posting_key'])
                || !empty($m['is_shipping_component'])
                || !empty($row_bridge['is_shipping_component'])
                || in_array($row_kind, ['shipping', 'shipping_liability'], true);

            // Standalone shipping-liability debit row: synthesize a shipping modal row even when
            // there is no historical_return_slices / return_bridge breakdown on that ledger row.
            if ($row_is_shipping && empty($m['historical_return_slices']) && empty($row_bridge)) {
                if ($case_id_filter !== '' && $row_case_id !== '' && $row_case_id !== $case_id_filter) {
                    continue;
                }

                $currency = (string)($r['currency'] ?? 'GYD');

                $impact = 0.0;
                if (isset($m['shipping_liability_amount'])) {
                    $impact = (float)$m['shipping_liability_amount'];
                } elseif (isset($m['shipping_amount'])) {
                    $impact = (float)$m['shipping_amount'];
                } else {
                    $impact = abs((float)($r['net'] ?? 0));
                }

                $impact = round(max(0.0, $impact), 2);
                if ($impact > 0) {
                    $name = trim((string)($m['item_name'] ?? ($m['note'] ?? 'Shipping fee charge')));
                    if ($name === '') $name = 'Shipping fee charge';

                    $out[] = [
                        'kind'               => 'shipping',
                        'source_shipment_id' => (int)($r['shipment_id'] ?? 0),
                        'item_id'            => 0,
                        'name'               => $name,
                        'qty'                => 1,
                        'unit_ex'            => number_format($impact, 2),
                        'unit_net'           => number_format($impact, 2),
'impact'             => round($impact, 2),                        'currency'           => $currency,
                    ];
                }
                continue;
            }

            $histories = [];
            if (!empty($m['historical_return_slices']) && is_array($m['historical_return_slices'])) {
                $histories = array_merge($histories, (array) $m['historical_return_slices']);
            }
            if (!empty($m['return_bridge']) && is_array($m['return_bridge'])) {
                $histories[] = $m['return_bridge'];
            }

            foreach ($histories as $rb) {
                if (!is_array($rb)) continue;
                $rb_case_id = trim((string) ($rb['case_id'] ?? ($m['case_id'] ?? '')));
                if ($case_id_filter !== '' && $rb_case_id !== '' && $rb_case_id !== $case_id_filter) continue;
                if ($case_id_filter !== '' && $rb_case_id === '') continue;
                $kind = strtolower(trim((string)($rb['kind'] ?? 'return')));
                $is_shipping = !empty($rb['is_shipping_component']) || $kind === 'shipping';
                $is_seller_debit_exposure = !empty($rb['is_seller_debit_exposure']) || $kind === 'seller_debit_exposure';

                if ($shipping_only_pre_return_case && !$is_shipping) {
                    continue;
                }
                $hk = $rb_case_id . '|' . (string)($rb['unique_key'] ?? '') . '|' . (string)($rb['slice_id'] ?? '') . '|' . $kind . '|' . (string)($rb['item_id'] ?? 0) . '|' . (string)($rb['seller_impact'] ?? $rb['original_net'] ?? 0);
                if ($hk !== '|||return|0|0' && isset($seen_histories[$hk])) continue;
                $seen_histories[$hk] = true;

                $currency  = (string)($r['currency'] ?? ($rb['currency'] ?? 'GYD'));
                $impact = 0.0;
                if (isset($rb['seller_impact']) && (float)$rb['seller_impact'] > 0) {
                    $impact = (float)$rb['seller_impact'];
                } elseif (isset($rb['original_net']) && (float)$rb['original_net'] > 0) {
                    $impact = (float)$rb['original_net'];
                } elseif (isset($rb['vendor_impact']) && (float)$rb['vendor_impact'] > 0) {
                    $impact = (float)$rb['vendor_impact'];
                } else {
                    $impact = abs((float)($r['net'] ?? 0));
                }
                $impact = round(max(0.0, $impact), 2);
                if ($impact <= 0) continue;

                if ($is_shipping) {
                    $name = trim((string)($rb['item_name'] ?? 'Shipping fee charge'));
                    if ($name === '') $name = 'Shipping fee charge';
                    $out[] = [
                        'kind'               => 'shipping',
                        'source_shipment_id' => (int)($r['shipment_id'] ?? 0),
                        'item_id'            => 0,
                        'name'               => $name,
                        'qty'                => 1,
                        'unit_ex'            => number_format($impact, 2),
                        'unit_net'           => number_format($impact, 2),
'impact'             => round($impact, 2),                        'currency'           => $currency,
                    ];
                    continue;
                }

                if ($is_seller_debit_exposure) {
                    $name = trim((string)($rb['item_name'] ?? 'Seller Debit Exposure'));
                    if ($name === '') $name = 'Seller Debit Exposure';
                    $out[] = [
                        'kind'               => 'seller_debit_exposure',
                        'source_shipment_id' => (int)($r['shipment_id'] ?? 0),
                        'item_id'            => 0,
                        'name'               => $name,
                        'qty'                => 1,
                        'unit_ex'            => number_format($impact, 2),
                        'unit_net'           => number_format($impact, 2),
'impact'             => round($impact, 2),                        'currency'           => $currency,
                    ];
                    continue;
                }

                $item_id = (int)($rb['item_id'] ?? 0);
                $outcome = $this->wallet_refund_outcome_for_row($rb, $m);
                $qty     = $this->wallet_refund_qty_for_row($rb, $m, $outcome);
                if ($item_id <= 0 || $qty <= 0) continue;

                $unit_net  = (float)($rb['unit_price_net'] ?? $rb['item_price_net'] ?? 0);
                if ($unit_net <= 0 && $qty > 0 && $impact > 0) {
                    $unit_net = round($impact / $qty, 2);
                }

                $name = trim((string)($rb['item_name'] ?? ''));
                if ($name === '') {
                    $name = 'Item #' . $item_id;
                    if (function_exists('wc_get_order')) {
                        $order = wc_get_order((int)($m['order_id'] ?? 0));
                        if ($order) {
                            $item = $order->get_item($item_id);
                            if ($item && method_exists($item, 'get_name')) {
                                $resolved = trim((string)$item->get_name());
                                if ($resolved !== '') $name = $resolved;
                            }
                        }
                    }
                }

                $display_kind = ($outcome === 'returnless' || $outcome === 'never_received' || $outcome === 'return_pending') ? $outcome : 'return';

                $out[] = [
                    'kind'               => $display_kind,
                    'return_outcome'     => $outcome,
                    'case_id'            => $rb_case_id,
                    'source_shipment_id' => (int)($r['shipment_id'] ?? 0),
                    'item_id'            => $item_id,
                    'name'               => $name,
                    'qty'                => (int) round($qty),
                    'unit_ex'            => number_format($unit_net, 2),
                    'unit_net'           => number_format($unit_net, 2),
'impact'             => round($impact, 2),                    'currency'           => $currency,
                ];
            }
        }

        return $out;
    }



    /**
     * Returns: [timing_line, clears_at_iso, clears_in_text, progress_percent]
     */
    private function timing_pack(string $state, string $delivered_at, string $pending_until): array {
        $state = strtolower(trim($state));
        $clears_at_iso = '';
        $clears_in_text = '';
        $pct = 0;

        if ($state === 'pending') {
            $end = strtotime($pending_until);
            $start = strtotime($delivered_at);
            if (!$start) $start = time();
            if (!$end) $end = $start;

            $clears_at_iso = $end ? gmdate('c', $end) : '';
            $clears_in_text = $this->clears_in($pending_until);

            $total = max(1, $end - $start);
            $elapsed = max(0, time() - $start);
            $pct = (int) max(0, min(100, round(($elapsed / $total) * 100)));

            $line = "Pending clearing";
            if ($delivered_at) $line .= " • delivered " . $this->nice_time($delivered_at);
            return [$line, $clears_at_iso, ($clears_in_text ?: 'clearing'), $pct];
        }

        if ($state === 'available') {
            $line = "Available";
            if ($delivered_at) $line .= " • delivered " . $this->nice_time($delivered_at);
            return [$line, '', '', 0];
        }

        if ($state === 'paid') {
            $line = "Paid";
            if ($delivered_at) $line .= " • delivered " . $this->nice_time($delivered_at);
            return [$line, '', '', 0];
        }

        if ($state === 'hold') {
            return ["On hold", '', '', 0];
        }

        if ($state === 'reversed') {
            $line = "Reversed (return)";
            if ($delivered_at) $line .= " • delivered " . $this->nice_time($delivered_at);
            return [$line, '', '', 0];
        }

        return [ucfirst($state ?: 'pending'), '', '', 0];
    }

    private function nice_time(string $mysql): string {
        $ts = strtotime($mysql);
        if (!$ts) return $mysql;
        return date('M j, g:ia', $ts);
    }

    private function clears_in(string $pending_until): string {
        if (!$pending_until) return '';
        $ts = strtotime($pending_until);
        if (!$ts) return '';
        $diff = $ts - time();
        if ($diff <= 0) return 'clearing now';
        $s = (int) floor($diff);
        $d = (int) floor($s / 86400);
        $h = (int) floor(($s % 86400) / 3600);
        $m = (int) floor(($s % 3600) / 60);
        if ($d > 0) return $d . 'd ' . $h . 'h ' . $m . 'm';
        if ($h > 0) return $h . 'h ' . $m . 'm';
        return $m . 'm';
    }

}
