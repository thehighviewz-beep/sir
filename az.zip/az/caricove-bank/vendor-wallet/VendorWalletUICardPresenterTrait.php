<?php
namespace Caricove\SellerPayouts;

use Caricove\Bank\Ledger;

if (!defined('ABSPATH')) exit;

trait VendorWalletUICardPresenterTrait {
    protected function buildWalletCardPresenterContext(array $ctx): array {
        extract($ctx, EXTR_SKIP);
        // v10: make feed cards derive recovery from the same source->target map
        // that the source modal already uses. This prevents a target shipment card
        // from showing an older blended shipment-level recovery total when the
        // source-side map has already been lawfully split into exact contributor
        // portions (e.g. 19241=1300.99 and 19245=1760.00 for source 19237).
        $source_consistent_recovery_by_target_shipment = [];
        foreach ((array)$trace_targets_by_source_shipment as $src_sid => $tgts) {
            foreach ((array)$tgts as $tgt_sid => $amt) {
                $tgt_sid = (int)$tgt_sid;
                $amt = round((float)$amt, 2);
                if ($tgt_sid <= 0 || $amt <= 0) continue;
                if (!isset($source_consistent_recovery_by_target_shipment[$tgt_sid])) {
                    $source_consistent_recovery_by_target_shipment[$tgt_sid] = 0.0;
                }
                $source_consistent_recovery_by_target_shipment[$tgt_sid] += $amt;
                $source_consistent_recovery_by_target_shipment[$tgt_sid] = round($source_consistent_recovery_by_target_shipment[$tgt_sid], 2);
            }
        }

        // Historical canonical maps remain useful for already-applied / persisted
        // recovery history, but they must NOT overwrite the live allocator preview
        // for current wallet rendering.
        $historical_canonical_recovery_by_target_shipment = $source_consistent_recovery_by_target_shipment ?: $canonical_recovery_by_target_shipment;
        $historical_canonical_recovery_sources_by_target_shipment = $canonical_recovery_sources_by_target_shipment;
        $historical_canonical_first_source_by_target_shipment = $canonical_first_source_by_target_shipment;
        $historical_canonical_recovery_targets_by_source_shipment = $canonical_recovery_targets_by_source_shipment;

        // Ledger-only wallet truth:
        // The wallet must not run a live allocator preview. It displays only
        // recovery edges already persisted by BankSellerLedger.
        $card_recovery_by_shipment = $historical_canonical_recovery_by_target_shipment;
        $card_recovery_sources_by_shipment = $historical_canonical_recovery_sources_by_target_shipment;
        $card_recovery_source_by_shipment = $historical_canonical_first_source_by_target_shipment;
        $source_recovery_targets_by_shipment = $historical_canonical_recovery_targets_by_source_shipment;

        // v13: residualize over-claimed target rows per source so old blended
        // shipment-level claims cannot exceed the source's actual debit total.
        // Example: if source 19237 has total 3060.99 and targets claim
        // 19241=1300.99 plus 19245=3060.99, shrink the largest claim to the
        // lawful residual 1760.00.
        $source_caps_by_shipment = [];
        foreach ((array)$debit_rows as $dr) {
            $ss = (int)($dr['shipment_id'] ?? 0);
            if ($ss <= 0) continue;
            $source_caps_by_shipment[$ss] = round((float)($source_caps_by_shipment[$ss] ?? 0.0) + abs((float)($dr['net'] ?? 0)), 2);
        }
        foreach ((array)$source_recovery_targets_by_shipment as $src_sid => $targets) {
            $src_sid = (int)$src_sid;
            $cap = round((float)($source_caps_by_shipment[$src_sid] ?? 0.0), 2);
            if ($src_sid <= 0 || $cap <= 0 || !is_array($targets) || !$targets) continue;
            $sum = 0.0;
            foreach ($targets as $amt) $sum += round((float)$amt, 2);
            $sum = round($sum, 2);
            if ($sum - $cap <= 0.009) continue;

            $overflow = round($sum - $cap, 2);

            // shrink the largest target claims first; this preserves smaller
            // explicit claims and trims the older blended catch-all row.
            arsort($targets, SORT_NUMERIC);
            foreach ($targets as $tgt_sid => $amt) {
                $amt = round((float)$amt, 2);
                if ($overflow <= 0.009) break;
                if ($amt <= 0) continue;
                $reduce = min($amt, $overflow);
                $targets[$tgt_sid] = round($amt - $reduce, 2);
                $overflow = round($overflow - $reduce, 2);
            }

            // remove exhausted target claims and write back adjusted maps
            foreach ($targets as $tgt_sid => $amt) {
                $amt = round((float)$amt, 2);
                if ($amt <= 0.009) unset($targets[$tgt_sid]);
                else $targets[$tgt_sid] = $amt;
            }
            $source_recovery_targets_by_shipment[$src_sid] = $targets;
        }

        // rebuild target-side recovery maps from residualized source targets
        $card_recovery_by_shipment = [];
        $card_recovery_sources_by_shipment = [];
        $card_recovery_source_by_shipment = [];
        foreach ((array)$source_recovery_targets_by_shipment as $src_sid => $targets) {
            foreach ((array)$targets as $tgt_sid => $amt) {
                $src_sid = (int)$src_sid;
                $tgt_sid = (int)$tgt_sid;
                $amt = round((float)$amt, 2);
                if ($src_sid <= 0 || $tgt_sid <= 0 || $amt <= 0) continue;
                if (!isset($card_recovery_by_shipment[$tgt_sid])) $card_recovery_by_shipment[$tgt_sid] = 0.0;
                $card_recovery_by_shipment[$tgt_sid] = round((float)$card_recovery_by_shipment[$tgt_sid] + $amt, 2);
                if (!isset($card_recovery_sources_by_shipment[$tgt_sid])) $card_recovery_sources_by_shipment[$tgt_sid] = [];
                $card_recovery_sources_by_shipment[$tgt_sid][$src_sid] = $amt;
            }
        }
        foreach ((array)$card_recovery_sources_by_shipment as $tgt_sid => $srcs) {
            ksort($srcs, SORT_NUMERIC);
            $card_recovery_sources_by_shipment[$tgt_sid] = $srcs;
            $card_recovery_source_by_shipment[$tgt_sid] = (int)array_key_first($srcs);
        }


        // Paid cards should use persisted/applied recovery, not the live preview map.
        $historical_paid_offset_by_shipment = $historical_canonical_recovery_by_target_shipment;
        $historical_paid_source_ids_by_shipment = [];
        foreach ((array)$trace_source_ids_by_target_shipment as $target_sid => $srcs) {
            $historical_paid_source_ids_by_shipment[(int)$target_sid] = [];
            foreach ((array)$srcs as $source_sid => $flag) {
                $historical_paid_source_ids_by_shipment[(int)$target_sid][(int)$source_sid] = true;
            }
        }

        // Keep persisted graph rows as the strongest recovery scar, and only
        // fall back to rebuilt rows if the graph node itself has no rows.
        foreach ((array)($persisted_trace_graph['sources'] ?? []) as $source_sid_raw => $node) {
            $source_sid = (int)$source_sid_raw;
            if ($source_sid > 0 && !empty($node['rows']) && is_array($node['rows'])) {
                $trace_return_rows_by_source_shipment[$source_sid] = $normalize_trace_rows($node['rows']);
            }
        }
        foreach ((array)($persisted_trace_graph['targets'] ?? []) as $target_sid_raw => $node) {
            $target_sid = (int)$target_sid_raw;
            if ($target_sid > 0 && !empty($node['rows']) && is_array($node['rows'])) {
                $trace_return_rows_by_target_shipment[$target_sid] = $normalize_trace_rows($node['rows']);
            }
        }

        // Basic reconciliation flags so the UI does not silently tell polished lies.
        $graph_reconciliation = [
            'source_overalloc' => [],
            'target_overalloc' => [],
        ];
        foreach ((array)$canonical_recovery_targets_by_source_shipment as $source_sid => $targets) {
            $sum = 0.0;
            foreach ((array)$targets as $amt) {
                $sum += round((float)$amt, 2);
            }
            $sum = round($sum, 2);
            $source_cap = 0.0;
            foreach ((array)$debit_rows as $dr) {
                if ((int)($dr['shipment_id'] ?? 0) === (int)$source_sid) {
                    $source_cap += abs((float)($dr['net'] ?? 0));
                }
            }
            $source_cap = round($source_cap, 2);
            if ($source_cap > 0 && $sum - $source_cap > 0.009) {
                $graph_reconciliation['source_overalloc'][(int)$source_sid] = [
                    'allocated' => $sum,
                    'cap' => $source_cap,
                ];
            }
        }
        foreach ((array)$rows as $rr) {
            $target_sid = (int)($rr['shipment_id'] ?? 0);
            if ($target_sid <= 0) continue;
            $state = strtolower((string)($rr['state'] ?? ''));
            if (!in_array($state, ['pending','available','hold','paid'], true)) continue;
            if (isset($guilty_shipment_ids[$target_sid])) continue;
            $cap = round(max(0.0, (float)($rr['net'] ?? 0)), 2);
            $alloc = round((float)($canonical_recovery_by_target_shipment[$target_sid] ?? 0), 2);
            if ($cap > 0 && $alloc - $cap > 0.009) {
                $graph_reconciliation['target_overalloc'][(int)$target_sid] = [
                    'allocated' => $alloc,
                    'cap' => $cap,
                ];
            }
        }

        // Top wallet summary must follow canonical ledger truth and must never alarm the vendor
        // from UI-side reconstruction drift. Keep any graph diagnostics internal only.
        $wallet_reconciliation_blocked = false;
        $wallet_reconciliation_block_reason = '';
        $wallet_reconciliation_warning = '';

        // Aggregate full paid shipment earnings across all paid rows for the same shipment.
        // This prevents one deduped paid row from understating a shipment that was split
        // into offset + cash slices during payout.
        $historical_paid_total_by_shipment = [];
        $historical_paid_cash_total = 0.0;

        if (is_array($historical_paid_offset_rows)) {
            foreach ($historical_paid_offset_rows as $hr) {
                $hist_sid = (int)($hr['shipment_id'] ?? 0);
                $hist_net = round((float)($hr['net'] ?? 0), 2);

                if ($hist_sid <= 0 || $hist_net <= 0) continue;

                if (!isset($historical_paid_total_by_shipment[$hist_sid])) {
                    $historical_paid_total_by_shipment[$hist_sid] = 0.0;
                }

                $historical_paid_total_by_shipment[$hist_sid] += $hist_net;
                $historical_paid_total_by_shipment[$hist_sid] = round($historical_paid_total_by_shipment[$hist_sid], 2);

                $hist_meta = json_decode((string)($hr['meta'] ?? ''), true);
                $hist_mode = is_array($hist_meta) ? strtolower((string)($hist_meta['payout_mode'] ?? '')) : '';
                if ($hist_mode !== 'offset') {
                    $historical_paid_cash_total += $hist_net;
                    $historical_paid_cash_total = round($historical_paid_cash_total, 2);
                }
            }
        }

        // ------------------------------------------------------------
        // CURRENT seller-facing card truth:
        // Wallet display projections are disabled. These arrays stay empty
        // unless BankSellerLedger has already written real offset edges into
        // ledger meta, which are carried by $card_recovery_* above.
        // ------------------------------------------------------------
        $visible_current_nonshipping_absorb_by_target_shipment = [];
        $visible_current_nonshipping_sources_by_target_shipment = [];
        $visible_current_nonshipping_targets_by_source_shipment = [];

        // ------------------------------------------------------------
        // Recompute seller-facing top-tile truth from the same final
        // per-shipment card math used in the feed.
        // ------------------------------------------------------------
        $pending_total      = 0.0;
        $pending_payable    = 0.0;
        $pending_debits_abs = 0.0;
        $available_total    = 0.0;
        $available_payable  = 0.0;
        $paid_total         = 0.0;
        $canonical_display_recovery_by_target_shipment = [];
        $canonical_display_earnings_by_target_shipment = [];

        foreach ($rows as $tr) {
            $tile_sid   = (int)($tr['shipment_id'] ?? 0);
            $tile_state = strtolower((string)($tr['state'] ?? ''));
            $tile_net   = (float)($tr['net'] ?? 0);

            if ($tile_sid <= 0) continue;

            $tile_deduct = 0.0;
            if (isset($visible_current_nonshipping_absorb_by_target_shipment[$tile_sid])) {
                // Current seller-facing card truth comes only from current open
                // non-shipping debit exposure absorbed by this target shipment.
                $tile_deduct = max(0.0, (float)$visible_current_nonshipping_absorb_by_target_shipment[$tile_sid]);
            } elseif (isset($canonical_display_recovery_by_target_shipment[$tile_sid])) {
                $tile_deduct = max(0.0, (float)$canonical_display_recovery_by_target_shipment[$tile_sid]);
            } elseif (isset($card_recovery_by_shipment[$tile_sid])) {
                $tile_deduct = max(0.0, (float)$card_recovery_by_shipment[$tile_sid]);
            }

            $tile_amount_of_shipment = max(0.0, $tile_net);

            if ($tile_state === 'reversed') {
                $meta_raw = (string)($tr['meta'] ?? '');
                if ($meta_raw) {
                    $j = json_decode($meta_raw, true);
                    if (is_array($j) && isset($j['return_bridge']['original_net'])) {
                        $orig = (float)$j['return_bridge']['original_net'];
                        if ($orig > 0) {
                            $tile_deduct = max($tile_deduct, $orig);
                            $tile_amount_of_shipment = $orig;
                        }
                    }
                }
            }

            if ($tile_deduct > $tile_amount_of_shipment) {
                $tile_deduct = $tile_amount_of_shipment;
            }

            if ($tile_sid > 0) {
                $canonical_display_earnings_by_target_shipment[$tile_sid] = round((float)$tile_amount_of_shipment, 2);
                $canonical_display_recovery_by_target_shipment[$tile_sid] = round((float)min($tile_amount_of_shipment, $tile_deduct), 2);
            }

            $tile_total_to_receive = $tile_amount_of_shipment;
            if ($tile_deduct > 0) {
                $tile_total_to_receive = $tile_amount_of_shipment - $tile_deduct;
                if ($tile_total_to_receive < 0) $tile_total_to_receive = 0.0;
            }

            if ($tile_state === 'pending') {
                $pending_total += $tile_total_to_receive;
                $pending_payable += $tile_total_to_receive;
                $pending_debits_abs += min($tile_amount_of_shipment, $tile_deduct);
            }

            if ($tile_state === 'available') {
                $available_total += $tile_total_to_receive;
                $available_payable += $tile_total_to_receive;
            }

            if ($tile_state === 'paid') {
                // Paid history is computed from the full paid-row ledger history below
                // so partially paid shipments do not disappear when the visible row stays available.
            }
        }

        $pending_total      = round($pending_total, 2);
        $pending_payable    = round($pending_payable, 2);
        $pending_debits_abs = round($pending_debits_abs, 2);
        $available_total    = round($available_total, 2);
        $available_payable  = round($available_payable, 2);
        $paid_total         = round($historical_paid_cash_total, 2);
              
              
              
              
              
              
              
              
              
              
              
              
              
              

        // Outstanding debit exposure shown in wallet UI must exclude shipping liabilities.
        // Shipping liabilities are surfaced separately below.
        $gate_truth = Ledger::seller_metrics($uid);
        $gate_withdrawable_now = round((float) ($gate_truth['withdrawable_now'] ?? 0), 2);

        $debit_exposure_abs = round((float) $active_debit_exposure_total_abs, 2);
        $total_open_liability_abs = round($debit_exposure_abs + $shipping_liability_total_abs, 2);

        // Cash-out gate and top summary must follow canonical ledger truth.
        $available_payable = $gate_withdrawable_now;
        $available_display_total = round(max(0.0, (float)$available_payable), 2);

        $available_hint = 'No funds yet';
        if ($available_payable <= 0 && $total_open_liability_abs > 0) {
            if ($debit_exposure_abs > 0 && $shipping_liability_total_abs > 0) {
                $available_hint = 'Active debit exposure and shipping liabilities are absorbing current funds';
            } elseif ($shipping_liability_total_abs > 0) {
                $available_hint = 'Shipping liabilities are absorbing current funds';
            } else {
                $available_hint = 'Active debit exposure is absorbing current funds';
            }
        } elseif ($available_total > 0 || $available_payable > 0) {
            $available_hint = 'Ready';
            if ($debit_exposure_abs > 0 && $shipping_liability_total_abs > 0) {
                $available_hint = 'Residual withdrawable after active debit exposure and shipping liabilities';
            } elseif ($debit_exposure_abs > 0) {
                $available_hint = 'Chain-aware residual withdrawable after active debit exposure';
            } elseif ($shipping_liability_total_abs > 0) {
                $available_hint = 'Residual withdrawable after shipping liabilities';
            }
        }

        // Prevent repeat instant requests if one is already in progress
        $pt = Ledger::payouts_table();
        $open_instant = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$pt}
             WHERE vendor_id=%d AND kind='instant'
               AND status IN ('requested','approved','queued')",
            $uid
        ));

        $instant_disabled_reason = '';
        if (!$has_method) $instant_disabled_reason = 'Add a payout method first';
        elseif ($available_payable <= 0) $instant_disabled_reason = 'No available funds';
        elseif ($open_instant > 0) $instant_disabled_reason = 'Instant request already pending approval';

        // Filter tab
        $filter = isset($_GET['cc_sp_filter']) ? sanitize_key((string)$_GET['cc_sp_filter']) : 'all';
        $allowed = ['all','pending','available','paid','hold'];
        if (!in_array($filter, $allowed, true)) $filter = 'all';

        if ($filter !== 'all') {
            $rows = array_values(array_filter($rows, function($r) use ($filter){
                return isset($r['state']) && strtolower((string)$r['state']) === $filter;
            }));
        }

        // Build a shipment_id => decoded meta lookup so source contributor displays can
        // validate contributors against the contributor row's CURRENT source map, not stale
        // source-side affected_recovery history.
        $ledger_meta_by_shipment = [];
        foreach ($rows as $rr_lookup) {
            $sid_lookup = (int)($rr_lookup['shipment_id'] ?? 0);
            if ($sid_lookup <= 0) continue;
            $mraw_lookup = (string)($rr_lookup['meta'] ?? '');
            $ledger_meta_by_shipment[$sid_lookup] = $mraw_lookup !== '' ? (json_decode($mraw_lookup, true) ?: []) : [];
        }

        // Renderer-only wallet doctrine: do not read or persist frozen card
        // story snapshots. They can preserve stale UI-derived math after the
        // ledger has been corrected. Every card must be recomputed from current
        // persisted ledger rows only.
        $card_story_snapshot_by_shipment = [];

        $persist_card_story_snapshot = function(int $shipment_id, array $snapshot): void {
            return;
        };

        $stage_defined = get_defined_vars();
        unset($stage_defined['ctx'], $stage_defined['stage_defined']);
        return array_merge($ctx, $stage_defined);
    }
}