<?php
namespace Caricove\SellerPayouts;

if (!defined('ABSPATH')) exit;

trait VendorWalletUIRenderTrait {
    public function render(): string {
        if (!is_user_logged_in()) return '';

        $uid = get_current_user_id();
        $ctx = ['uid' => $uid, 'wallet_inspector_enabled' => false];
        $ctx = $this->buildWalletCurrentStateContext($ctx);
        $ctx = $this->buildWalletHistoryStateContext($ctx);
        $ctx = $this->buildWalletCardPresenterContext($ctx);
        $ctx = $this->buildWalletModalPresenterContext($ctx);
        extract($ctx, EXTR_SKIP);

        ob_start(); ?>

        <div class="ccp2">
            <?php if (!empty($ccvw_debug_payload)) : ?>
            <div style="background:#fff3cd;color:#111;border:2px solid #d39e00;padding:12px;margin:12px 0;border-radius:10px;">
              <strong>CCVW Recovery Debug</strong>
              <pre style="white-space:pre-wrap;word-break:break-word;"><?php echo esc_html(wp_json_encode($ccvw_debug_payload, JSON_PRETTY_PRINT)); ?></pre>
            </div>
            <?php endif; ?>

            <style>
                .ccp2{max-width:1200px;margin:0 auto;padding:18px}
                .ccp2 *{box-sizing:border-box}
                .ccp2{--cc-off:#f6f7fb;--cc-off2:#f3f6fb;--cc-border:rgba(25,60,100,.12);--cc-ink:#0b1220;}
                .ccp2 .wrap{
                    border-radius:12px;
                    padding:12px;
                    background:var(--cc-off);
                    border:1px solid var(--cc-border);
                    box-shadow:0 10px 30px rgba(16,40,80,.06);
                }
                
                
         

                .ccp2 .states{display:flex;gap:10px}
                .ccp2 .st{
                    flex:1;border-radius:8px;padding:10px 12px;background:var(--cc-off2);
                    border:1px solid var(--cc-border);min-height:46px;
                    display:flex;align-items:center;justify-content:space-between;
                }
                .ccp2 .k{font-size:14px;color:#41506a;font-weight:800}
                .ccp2 .n{font-size:18px;color:var(--cc-ink);font-weight:900;line-height:1;margin-top:2px}
                .ccp2 .h{font-size:13.5px;color:#5b6a84;font-weight:800;margin-top:2px}
                .ccp2 .pending .k:before{content:"🔒 ";opacity:.9}
                .ccp2 .actions{display:flex;align-items:center;gap:12px;margin-top:12px}
                .ccp2 .leftActions{display:flex;align-items:center;gap:12px;flex:1}
                .ccp2 .rightActions{display:flex;justify-content:flex-end}
                .ccp2 .pill{
                    border:1px solid rgba(25,60,100,.18);
                    background:#fff;
                    cursor:pointer;
                    border-radius:999px;
                    padding:11px 16px;
                    font-weight:900;
                    font-size:14px;
                    display:inline-flex;
                    align-items:center;
                    gap:10px;
                    white-space:nowrap;
                    color:var(--cc-ink);
                    box-shadow:0 10px 24px rgba(16,40,80,.06);
                }
                
                
                
                
                
                
                
                
                
         .ccp2 .items .nm{display:flex;flex-direction:column;align-items:flex-start;gap:6px;font-weight:900;color:var(--cc-ink)}
        .ccp2 .items .nm .t{line-height:1.15}
        /* Sexy clean variation pills */
        .ccp2 .items .vpills{
            display:flex;
            flex-wrap:wrap;
            gap:8px;
            align-items:center;
            margin-top:4px;
        }

        .ccp2 .items .vpill{
            display:inline-flex;
            align-items:center;
            gap:6px;
            padding:6px 12px;
            border-radius:999px;
            background:#1a1a1a;              /* light clean blue */
            color:#fff;                   /* deep royal text */
            font-weight:700;
            font-size:12px;
            border:1px solid #cfe0ff;
        }

        .ccp2 .items .vpill b{
            color:#fff;                   /* accent label color */
            font-weight:800;
        }

        .ccp2 .items .vmore{
            padding:6px 10px;
            border-radius:999px;
            background:#2563eb;
            color:#fff;
            font-weight:800;
            font-size:12px;
        }
                
                
           
                
                
                
                
             
             
             
             
          /* Shipping liabilities — make it match the rest of the wallet UI */
                .ccp2 .ship-liab{
                    margin-top:14px;
                    border-radius:12px;
                    padding:12px 14px;
                    background:var(--cc-off);
                    border:1px solid var(--cc-border);
                    box-shadow:0 10px 30px rgba(16,40,80,.06);
                    color:var(--cc-ink);
                }
                .ccp2 .ship-liab *{
                    color:inherit;
                    box-sizing:border-box;
                }
                .ccp2 .ship-liab-head{
                    display:flex;
                    align-items:flex-start;
                    justify-content:space-between;
                    gap:12px;
                    flex-wrap:wrap;
                }
                .ccp2 .ship-liab-title{
                    font-size:14px;
                    font-weight:900;
                    color:#2b3a55;
                    line-height:1.15;
                }
                .ccp2 .ship-liab-note{
                    margin-top:4px;
                    font-size:13px;
                    font-weight:800;
                    color:#5b6a84;
                    line-height:1.45;
                }
                .ccp2 .ship-liab .chip{
                    color:var(--cc-ink);
                }
                .ccp2 .ship-liab-toggle{
                    cursor:pointer;
                    appearance:none;
                    -webkit-appearance:none;
                    background:#fff;
                }
                .ccp2 .ship-liab-toggle[aria-expanded="true"]{
                    box-shadow:0 0 0 2px rgba(0,115,170,.10) inset;
                }
                .ccp2 .ship-liab-list{
                    display:grid;
                    gap:10px;
                    margin-top:12px;
                }
                .ccp2 .ship-liab-list[hidden]{
                    display:none !important;
                }
                .ccp2 .ship-liab-row{
                    display:grid;
                    grid-template-columns:repeat(5,minmax(0,1fr));
                    gap:10px;
                    padding:12px;
                    border-radius:10px;
                    background:#fff;
                    border:1px solid rgba(25,60,100,.14);
                }
                .ccp2 .ship-liab .xk{
                    font-size:11px;
                    font-weight:900;
                    text-transform:uppercase;
                    letter-spacing:.04em;
                    color:#5b6a84;
                    margin-bottom:4px;
                }
                .ccp2 .ship-liab .xv{
                    font-size:13px;
                    font-weight:900;
                    color:var(--cc-ink);
                    line-height:1.35;
                    word-break:break-word;
                }
                .ccp2 .ship-liab-empty{
                    margin-top:12px;
                    padding:10px 12px;
                    border-radius:10px;
                    background:#fff;
                    border:1px solid rgba(25,60,100,.14);
                    color:#5b6a84;
                    font-size:13px;
                    font-weight:800;
                }
                @media(max-width:900px){
                    .ccp2 .ship-liab-row{
                        grid-template-columns:1fr;
                    }
                }   
             
             
             
             
             
             
             
          
                
                
                
                
                
                .ccp2 .pill:active{transform:translateY(1px)}
                .ccp2 .pill[disabled]{opacity:.55;cursor:not-allowed}
                .ccp2 .chip{
                    border-radius:999px;padding:9px 12px;font-size:14px;font-weight:900;color:var(--cc-ink);
                    background:var(--cc-off2);border:1px solid var(--cc-border);
                    display:inline-flex;align-items:center;gap:8px;
                }
                .ccp2 .dest{
                    margin-top:14px;border-radius:12px;background:var(--cc-off);
                    border:1px solid var(--cc-border);padding:12px 14px;
                    display:flex;align-items:center;justify-content:space-between;gap:12px;
                }
                .ccp2 .dest .dv{font-size:15px;font-weight:900;color:var(--cc-ink);margin-top:3px}
                .ccp2 .dest a{font-size:14px;font-weight:900;color:#000;text-decoration:none;opacity:.85}
                .ccp2 .dest a:hover{opacity:1}
                .ccp2 .drawer{margin-top:10px;border-radius:12px;background:var(--cc-off);border:1px solid var(--cc-border);padding:14px;display:none}
                .ccp2 .drawer.show{display:block}
                .ccp2 label{display:block;font-size:13px;font-weight:900;color:#2b3a55;margin:10px 0 6px}
                .ccp2 input,.ccp2 select{
                    width:100%;height:44px;border-radius:12px;border:1px solid rgba(25,60,100,.18);
                    background:#fff;padding:0 12px;font-size:14px;color:#000;outline:none;
                }
                .ccp2 .row2{display:grid;grid-template-columns:1fr 1fr;gap:10px}
                .ccp2 .rowFull{grid-column:1/-1}
                .ccp2 .secureNote{font-size:13px;color:#5b6a84;font-weight:800;margin-top:10px}
                .ccp2 .saveRow{display:flex;gap:10px;justify-content:flex-end;align-items:center;margin-top:12px}
                .ccp2 .msg{font-size:13px;font-weight:900;color:#51607a;margin-right:auto}
                .ccp2 .btn{
                    border-radius:12px;height:42px;padding:0 14px;font-weight:900;font-size:14px;
                    border:1px solid rgba(25,60,100,.18);background:#fff;color:#000;cursor:pointer;
                }
                .ccp2 .btn.primary{background:#1ea0ff;border-color:#1ea0ff;color:#fff}
                .ccp2 .act{margin-top:14px;border-radius:12px;background:var(--cc-off);border:1px solid var(--cc-border);padding:12px}
                .ccp2 .actTop{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;margin-bottom:10px}
                .ccp2 .actTitle{font-size:14px;font-weight:900;color:#2b3a55}
                .ccp2 .tabs{display:flex;gap:8px;flex-wrap:wrap}
                .ccp2 .tab{
                    display:inline-flex;align-items:center;gap:6px;padding:8px 12px;border-radius:999px;
                    background:#fff;border:1px solid rgba(25,60,100,.18);
                    font-size:13px;font-weight:900;color:#2b3a55;text-decoration:none;
                }
                .ccp2 .tab.active{background:#eaf2ff;border-color:rgba(30,160,255,.35)}
                .ccp2 .feedRow{
                    background:#fff;border:1px solid rgba(25,60,100,.14);border-radius:10px;
                    padding:10px 12px;margin-bottom:8px;cursor:pointer;
                }
                .ccp2 .feedRow:hover{background:#fbfcff}
                .ccp2 .feedTop{display:flex;align-items:flex-start;justify-content:space-between;gap:10px}
                .ccp2 .feedLeft{min-width:0}
                .ccp2 .feedH{font-weight:900;color:var(--cc-ink);font-size:14px;line-height:1.15}
                .ccp2 .feedS{font-size:13px;font-weight:800;color:#5b6a84;margin-top:4px}
                .ccp2 .feedRight{display:flex;align-items:flex-start;gap:-600px; white-space:nowrap}
                .ccp2 .dest a{
            display:inline-flex;
            align-items:center;
            justify-content:center;
            height:36px;
            padding:0 16px;
            border-radius:30px;
            background:#fff;
            border:1px solid rgba(25,60,100,.18);
            font-size:14px;
            font-weight:900;
            color:#000;
            text-decoration:none;
            cursor:pointer;
            box-shadow:0 8px 18px rgba(16,40,80,.06);
        }

        .ccp2 .dest a:hover{
            background:#f7f9fc;
        }

        .ccp2 .dest a:active{
            transform:translateY(1px);
        }
                
         .ccp2 .feedRight .badge{
          margin-right:50px;
        }

                .ccp2 .badge{
                    font-size:12px;font-weight:900;padding:4px 10px;border-radius:999px;
                    border:1px solid rgba(25,60,100,.14);background:var(--cc-off2);color:#41506a;
                }
                .ccp2 .badge.pending:before{content:"🔒 ";opacity:.9}
                .ccp2 .badge.available:before{content:"✅ ";opacity:.9}
                .ccp2 .badge.paid:before{content:"📌 ";opacity:.9}
                .ccp2 .badge.hold:before{content:"⏸ ";opacity:.9}
                .ccp2 .badge.reversed:before{content:"↩ ";opacity:.9}
                .ccp2 .payStack{
                    display:flex;flex-direction:column;align-items:flex-end;gap:2px;
                    font-weight:900;color:var(--cc-ink);
                }
                .ccp2 .payLine{font-size:13px}
                .ccp2 .payLine.dim{font-weight:800;color:#5b6a84}
                .ccp2 .payLine.neg{color:#b91c1c}
        .ccp2 .payLine.total{font-size:14px}
               .ccp2 a.ccp2EarningsWhy{
                    display:inline-block;
                    color:inherit;
                    text-decoration:underline;
                    text-underline-offset:2px;
                    cursor:pointer;
                }
                .ccp2 a.ccp2EarningsWhy:hover{
                    opacity:.85;
                }
                }                .ccp2 a.ccp2Why{color:#1e3a8a;font-weight:900;text-decoration:underline;cursor:pointer}
                .ccp2 a.ccp2Why:hover{opacity:.85}
                .ccp2 .metaRow{margin-top:6px;font-size:12.5px;color:#6a7892;font-weight:800}
                .ccp2 .metaRow code{font-weight:900;color:#2b3a55}
                .ccp2 .prog{height:6px;border-radius:999px;background:rgba(25,60,100,.10);overflow:hidden;margin-top:8px}
                .ccp2 .prog > i{display:block;height:100%;width:0%;background:linear-gradient(90deg, rgba(30,160,255,.45), rgba(30,160,255,.15))}
                .ccp2 .ship-pill{
                    display:inline-flex;align-items:center;padding:4px 10px;border-radius:999px;
                    background:#e2e7f0;border:1px solid #c7d0df;color:#273247;
                    font-weight:900;font-size:13px;
                }
                /* Modals */
                .ccp2 .modalBack{
                    display:none;position:fixed;inset:0;z-index:999999;
                    background:rgba(8,12,20,.45);
                    align-items:center;justify-content:center;padding:18px;
                }
                    .ccp2 .modalBack.show{display:flex}                        .ccp2 .modal{
                    width:min(720px, 100%);
                    max-height:86vh;
                    display:flex;
                    flex-direction:column;
                    background:var(--cc-off);
                    border:1px solid rgba(255,255,255,.14);
                    border-radius:14px;
                    box-shadow:0 30px 90px rgba(0,0,0,.20);
                    overflow:hidden;
                }
                .ccp2 .modalHd{
                    display:flex;align-items:center;justify-content:space-between;gap:12px;
                    padding:12px 14px;border-bottom:1px solid var(--cc-border);
                }
                .ccp2 .modalHd .t{font-size:14px;font-weight:900;color:#2b3a55}
                .ccp2 .x{
                    width:28px;height:28px;border-radius:8px;
                    display:flex;align-items:center;justify-content:center;
                    line-height:1;padding:0;font-size:16px;
                    border:1px solid rgba(25,60,100,.18);
                    background:#fff;color:#000;font-weight:900;cursor:pointer;
                }
                .ccp2 .modalBd{padding:14px;overflow:auto;max-height:calc(86vh - 60px);overscroll-behavior:contain}\n                .ccp2 .modalBd .card .lv{word-break:break-word}
                .ccp2 .items.items-scroll{max-height:38vh;overflow:auto;padding-right:4px}
                .ccp2 .grid2{display:grid;grid-template-columns:1fr 1fr;gap:10px}
                .ccp2 .card{
                    background:#fff;border:1px solid rgba(25,60,100,.14);border-radius:12px;padding:12px;
                }
                .ccp2 .card .lk{font-size:12.5px;font-weight:900;color:#5b6a84}
                .ccp2 .card .lv{margin-top:4px;font-size:14px;font-weight:900;color:var(--cc-ink)}
                .ccp2 .items{margin-top:10px}
                .ccp2 .items .it{display:flex;justify-content:space-between;gap:10px;padding:8px 0;border-bottom:1px solid rgba(25,60,100,.10)}
                .ccp2 .items .it:last-child{border-bottom:none}
                .ccp2 .items .nm{font-weight:900;color:var(--cc-ink)}
                .ccp2 .items .qt{font-weight:900;color:#41506a}
                .ccp2 .smallNote{margin-top:10px;font-size:12.5px;color:#6a7892;font-weight:800}
                .ccp2 .vwHero{
                    position:relative;overflow:hidden;margin-bottom:12px;
                    border-radius:18px;padding:18px;border:1px solid rgba(30,58,138,.12);
                    background:linear-gradient(135deg,#ffffff 0%,#eef7ff 48%,#fffaf0 100%);
                    box-shadow:0 18px 50px rgba(25,60,100,.12);
                }
                .ccp2 .vwHero:before{
                    content:"";position:absolute;inset:-60px auto auto -60px;width:180px;height:180px;border-radius:999px;
                    background:radial-gradient(circle,rgba(56,189,248,.24),rgba(56,189,248,0) 68%);
                }
                .ccp2 .vwHero .eyebrow{position:relative;font-size:12px;font-weight:1000;letter-spacing:.08em;text-transform:uppercase;color:#54708f}
                .ccp2 .vwHero .headline{position:relative;margin-top:5px;font-size:20px;line-height:1.15;font-weight:1000;color:#0f172a}
                .ccp2 .vwHero .sub{position:relative;margin-top:8px;font-size:13px;line-height:1.45;font-weight:850;color:#536174}
                .ccp2 .vwStatus{
                    display:inline-flex;align-items:center;gap:7px;margin-top:12px;padding:8px 12px;border-radius:999px;
                    font-size:12.5px;font-weight:1000;border:1px solid rgba(22,101,52,.18);background:#ecfdf3;color:#166534;
                }
                .ccp2 .vwStatus.warn{background:#fff7ed;color:#9a3412;border-color:rgba(154,52,18,.20)}
                .ccp2 .vwStatus.info{background:#eff6ff;color:#1d4ed8;border-color:rgba(29,78,216,.20)}
                .ccp2 .vwMoneyGrid{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-top:12px}
                .ccp2 .vwMoneyCard{background:#fff;border:1px solid rgba(25,60,100,.12);border-radius:16px;padding:13px;box-shadow:0 10px 28px rgba(16,40,80,.06)}
                .ccp2 .vwMoneyCard .k{font-size:12px;font-weight:1000;color:#5b6a84;letter-spacing:.02em}
                .ccp2 .vwMoneyCard .v{margin-top:5px;font-size:17px;font-weight:1000;color:#101827;word-break:break-word}
                .ccp2 .vwMoneyCard .v.neg{color:#b91c1c}.ccp2 .vwMoneyCard .v.open{color:#b91c1c}.ccp2 .vwMoneyCard .v.good{color:#166534}.ccp2 .vwMoneyCard .v.blue{color:#1d4ed8}
                .ccp2 .vwSectionTitle{margin:14px 0 8px;font-size:13px;font-weight:1000;color:#25324a}
                .ccp2 .vwTimeline{display:grid;gap:8px;margin-top:8px}
                .ccp2 .vwStep{display:grid;grid-template-columns:auto 1fr auto;gap:10px;align-items:center;background:#fff;border:1px solid rgba(25,60,100,.10);border-radius:14px;padding:10px 12px}
                .ccp2 .vwStep .dot{width:28px;height:28px;border-radius:999px;display:flex;align-items:center;justify-content:center;background:#eff6ff;color:#1d4ed8;font-weight:1000}
                .ccp2 .vwStep .name{font-weight:1000;color:#111827}.ccp2 .vwStep .note{font-size:12px;font-weight:800;color:#6b7280;margin-top:2px}.ccp2 .vwStep .amt{font-weight:1000;color:#111827;white-space:nowrap}.ccp2 .vwStep .amt.neg{color:#b91c1c}.ccp2 .vwStep .amt.open{color:#b91c1c}.ccp2 .vwStep .amt.good{color:#166534}
                .ccp2 .vwSourceCard{margin-top:10px;background:#fff;border:1px solid rgba(25,60,100,.12);border-radius:16px;padding:14px;box-shadow:0 10px 28px rgba(16,40,80,.06)}
                .ccp2 .vwSourceHead{display:flex;justify-content:space-between;gap:12px;align-items:flex-start}
                .ccp2 .vwSourceEyebrow{font-size:11.5px;font-weight:1000;letter-spacing:.08em;text-transform:uppercase;color:#5b6a84}
                .ccp2 .vwSourceTitle{margin-top:4px;font-size:18px;line-height:1.15;font-weight:1000;color:#0f172a}
                .ccp2 .vwSourceSub{margin-top:6px;font-size:12.5px;line-height:1.45;font-weight:850;color:#5f6d82}
                .ccp2 .vwSourcePill{display:inline-flex;align-items:center;justify-content:center;padding:7px 11px;border-radius:999px;background:#eff6ff;border:1px solid rgba(29,78,216,.18);color:#1d4ed8;font-size:12px;font-weight:1000;white-space:nowrap}
                .ccp2 .vwSourceCard .vwMoneyGrid{margin-top:10px}
                .ccp2 details.vwDebug{margin-top:14px;background:#fff8e7;border:1px solid rgba(180,140,40,.22);border-radius:14px;padding:10px}
                .ccp2 details.vwDebug summary{cursor:pointer;font-weight:1000;color:#5b4216}
                .ccp2 details.vwDebug pre{white-space:pre-wrap;font-size:11px;line-height:1.35;color:#3b2f12}
                @media(max-width:720px){.ccp2 .vwMoneyGrid{grid-template-columns:1fr}.ccp2 .vwStep{grid-template-columns:auto 1fr}.ccp2 .vwStep .amt{grid-column:2}.ccp2 .vwSourceHead{display:block}.ccp2 .vwSourcePill{margin-top:10px}}
                .ccp2 .ship-summary{display:flex;gap:8px;flex-wrap:wrap;margin:8px 0 10px}
                .ccp2 .sum-pill{
                    display:inline-flex;align-items:center;gap:6px;
                    padding:6px 11px;border-radius:999px;
                    font-weight:900;font-size:12.5px;
                    border:1px solid rgba(25,60,100,.18);
                    background:#fff;
                    box-shadow:0 10px 24px rgba(16,40,80,.06);
                    color:#2b3a55;
                }
                .ccp2 .sum-pill b{font-weight:900}
                .ccp2 .sum-pill.total{box-shadow:0 0 14px rgba(60,90,140,.10), 0 10px 24px rgba(16,40,80,.06)}
                .ccp2 .sum-pill.delivered{box-shadow:0 0 14px rgba(30,160,255,.18), 0 10px 24px rgba(16,40,80,.06)}
                .ccp2 .sum-pill.cancelled{box-shadow:0 0 14px rgba(235,87,87,.18), 0 10px 24px rgba(16,40,80,.06)}
                .ccp2 .sum-pill.returned{background:#f0fdf4;color:#166534;border-color:rgba(22,101,52,.20);box-shadow:0 0 14px rgba(22,163,74,.18),0 10px 24px rgba(16,40,80,.06)}
                .ccp2 .sum-pill.returnless{background:#eef2ff;color:#3730a3;border-color:rgba(55,48,163,.20);box-shadow:0 0 14px rgba(79,70,229,.18),0 10px 24px rgba(16,40,80,.06)}
                .ccp2 .sum-pill.never{background:#fff7ed;color:#9a3412;border-color:rgba(154,52,18,.20);box-shadow:0 0 14px rgba(249,115,22,.18),0 10px 24px rgba(16,40,80,.06)}
                .ccp2 .sum-pill.pending-return{background:#fff1f2;color:#be123c;border-color:rgba(190,18,60,.18);box-shadow:0 0 14px rgba(244,63,94,.16),0 10px 24px rgba(16,40,80,.06)}
                .ccp2 .shipTruthCard{position:relative;overflow:hidden;background:linear-gradient(135deg,#ffffff 0%,#f7fbff 54%,#fff8ed 100%);border:1px solid rgba(25,60,100,.12);box-shadow:0 18px 55px rgba(16,40,80,.10)}
                .ccp2 .shipTruthCard:before{content:"";position:absolute;inset:-70px auto auto -70px;width:190px;height:190px;border-radius:999px;background:radial-gradient(circle,rgba(56,189,248,.24),rgba(56,189,248,0) 70%)}
                .ccp2 .shipTruthCard>.lk,.ccp2 .shipTruthCard>.items{position:relative}
                .ccp2 .items .it{align-items:flex-start;border-radius:14px;padding:10px 10px;margin:4px 0;background:rgba(255,255,255,.72);border:1px solid rgba(25,60,100,.08)}
                .ccp2 .items .qt{display:flex;align-items:flex-end;justify-content:center;min-width:128px;text-align:right}
                .ccp2 .qtStack{display:flex;flex-direction:column;align-items:flex-end;gap:6px}
                .ccp2 .qchip{display:inline-flex;align-items:center;justify-content:center;border-radius:999px;padding:6px 10px;font-size:12.5px;font-weight:1000;border:1px solid rgba(25,60,100,.14);white-space:nowrap;background:#f8fafc;color:#334155;box-shadow:0 8px 18px rgba(16,40,80,.06)}
                .ccp2 .qchip.returned{background:#ecfdf3;color:#166534;border-color:rgba(22,101,52,.20)}
                .ccp2 .qchip.returnless{background:#eef2ff;color:#3730a3;border-color:rgba(55,48,163,.20)}
                .ccp2 .qchip.never{background:#fff7ed;color:#9a3412;border-color:rgba(154,52,18,.20)}
                .ccp2 .qchip.pending-return{background:#fff1f2;color:#be123c;border-color:rgba(190,18,60,.18)}
                .ccp2 .qchip.delivered{background:#eff6ff;color:#1d4ed8;border-color:rgba(29,78,216,.18)}
                .ccp2 .qchip.cancelled{background:#fef2f2;color:#b91c1c;border-color:rgba(185,28,28,.18)}
                @media(max-width:640px){.ccp2 .items .it{display:block}.ccp2 .items .qt{justify-content:flex-start;text-align:left;margin-top:8px}.ccp2 .qtStack{align-items:flex-start}}
                /* Instant confirm UX */
                .ccp2 .holdBtn{user-select:none}
                .ccp2 .holdBtn.is-holding{opacity:.75}
                .ccp2 .adminInspector{margin-top:14px;border-radius:12px;background:#fff8e7;border:1px solid rgba(180,140,40,.22);padding:12px}
                .ccp2 .adminInspector h3{margin:0 0 8px;font-size:14px;font-weight:900;color:#3b2f12}
                .ccp2 .adminInspector .muted{font-size:12.5px;color:#6b5a2b;font-weight:800}
                .ccp2 .adminInspector .ok{color:#166534;font-weight:900}
                .ccp2 .adminInspector .bad{color:#b91c1c;font-weight:900}
                .ccp2 .insGrid{display:grid;grid-template-columns:1.3fr 1fr 1fr 1fr;gap:8px;margin-top:10px}
                .ccp2 .insHead,.ccp2 .insCell{padding:8px 10px;border-radius:10px;background:#fff;border:1px solid rgba(25,60,100,.10);font-size:12.5px}
                .ccp2 .insHead{font-weight:900;color:#5b4b1b;background:#fff3cf}
                .ccp2 .insCell strong{font-weight:900;color:#0b1220}
                .ccp2 .insList{margin-top:10px;background:#fff;border:1px solid rgba(25,60,100,.10);border-radius:10px;padding:10px}
                .ccp2 .insList .row{display:flex;justify-content:space-between;gap:10px;padding:6px 0;border-bottom:1px solid rgba(25,60,100,.08)}
                .ccp2 .insList .row:last-child{border-bottom:none}
                @media(max-width:900px){
                    .ccp2 .states{flex-direction:column}
                    .ccp2 .actions{flex-direction:column;align-items:stretch}
                    .ccp2 .leftActions{flex-direction:column;align-items:stretch}
                    .ccp2 .rightActions{justify-content:flex-start}
                    .ccp2 .pill{width:100%;justify-content:center}
                    .ccp2 .row2{grid-template-columns:1fr}
                    .ccp2 .feedTop{flex-direction:column;align-items:flex-start}
                    .ccp2 .feedRight{width:100%;justify-content:space-between}
                    .ccp2 .grid2{grid-template-columns:1fr}
                }
            </style>

            <div class="wrap">
                <div class="states">
                    <div class="st pending">
                        <div class="left"><div class="k">Pending</div>
                        <div class="n"><?php echo esc_html(number_format($pending_payable,2)); ?> GYD</div>
                        <div class="h">Clearing</div></div>
                    </div>
                   <div class="st">
                        <div class="left">
                            <div class="k">Available</div>
                            <div class="n"><?php echo esc_html(number_format($available_display_total,2)); ?> GYD</div>
                            <div class="h"><?php echo esc_html($available_hint); ?></div>
                        </div>
                    </div>
                    <div class="st">
                        <div class="left"><div class="k">Paid</div><div class="n"><?php echo esc_html(number_format($paid_total,2)); ?> GYD</div><div class="h">History</div></div>
                    </div>
                </div>

               <div class="actions">
                    <div class="leftActions">
                       <button
            class="pill"
            type="button"
            id="ccp2-cashout-open"
            <?php echo ($instant_disabled_reason !== '') ? 'disabled' : ''; ?>
            title="<?php echo esc_attr($instant_disabled_reason); ?>"
        >
            <?php echo ($available_payable>0 ? 'Cash-out' : 'Waiting for funds'); ?>
        </button>
                        <div class="chip">
                            <?php
                                if ($available_payable > 0) {
                                    echo '✅ Residual withdrawable: ' . esc_html(number_format($available_payable, 2)) . ' GYD';
                                } elseif ($debit_exposure_abs > 0 && $shipping_liability_total_abs > 0) {
                                    echo '⚠️ Open debit and shipping balances are waiting for eligible earnings to become available';
                                } elseif ($debit_exposure_abs > 0) {
                                    echo '⚠️ Open debit balance is waiting for eligible earnings to become available';
                                } elseif ($shipping_liability_total_abs > 0) {
                                    echo '⚠️ Open shipping liability is waiting for eligible earnings to become available';
                                } else {
                                    echo '🔒 Funds must clear first';
                                }
                            ?>
                        </div>
                        <?php if ($debit_exposure_abs > 0): ?>
                            <div class="chip">Active debit exposure: <?php echo esc_html(number_format($debit_exposure_abs, 2)); ?> GYD open</div>
                        <?php endif; ?>
                        <?php if ($shipping_liability_total_abs > 0): ?>
                            <div class="chip">Shipping liabilities: <?php echo esc_html(number_format($shipping_liability_total_abs, 2)); ?> GYD open</div>
                        <?php endif; ?>
                        <?php if ($wallet_reconciliation_warning !== ''): ?>
                            <div class="chip"><?php echo esc_html($wallet_reconciliation_warning); ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="rightActions">
                        <button
                            class="pill"
                            type="button"
                            id="ccp2-instant-btn"
                            <?php echo ($instant_disabled_reason !== '') ? 'disabled' : ''; ?>
                            title="<?php echo esc_attr($instant_disabled_reason); ?>"
                        >
                            Cash-out 
                        </button>
                    </div>
                </div>
            </div>

            <div class="dest">
                <div>
                    <div class="k">Getting paid to</div>
                    <div class="dv"><?php echo esc_html($dest_display ?: 'Not set'); ?></div>
                </div>
                <a href="#" id="ccp2-change">Change</a>
            </div>

            <div class="ship-liab">
                <div class="ship-liab-head">
                    <div>
                        <div class="ship-liab-title">Active debit exposure</div>
                        <div class="ship-liab-note">Non-shipping seller debt such as Seller Debit Exposure appears here. Shipping fee charges stay in Shipping liabilities.</div>
                    </div>
                    <button type="button"
                            class="chip ship-liab-toggle"
                            aria-expanded="false"
                            aria-controls="active-debit-list">
                        Open active debit exposure: <?php echo (int) count($active_debit_breakdown_rows); ?>
                    </button>
                </div>
                <?php if (!empty($active_debit_breakdown_rows)): ?>
                    <div class="ship-liab-list" id="active-debit-list" hidden>
                        <?php foreach (array_slice($active_debit_breakdown_rows, 0, 12) as $adr): ?>
                            <div class="ship-liab-row">
                                <div><div class="xk">Reason</div><div class="xv"><?php echo esc_html((string) ($adr['reason'] ?? 'Debit exposure')); ?></div></div>
                                <div><div class="xk">Amount</div><div class="xv">−<?php echo esc_html(number_format((float) ($adr['amount'] ?? 0), 2)); ?> GYD</div></div>
                                <div><div class="xk">Order / shipment</div><div class="xv">#<?php echo esc_html((string) ($adr['order_id'] ?? 0)); ?> / #<?php echo esc_html((string) ($adr['shipment_id'] ?? 0)); ?></div></div>
                                <div><div class="xk">Bucket</div><div class="xv">Active debit exposure</div></div>
                                <div><div class="xk">Status</div><div class="xv"><?php echo esc_html(str_replace('_', ' ', (string) ($adr['status'] ?? 'posted'))); ?></div></div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="ship-liab-empty">No active debit exposure is open right now.</div>
                <?php endif; ?>
            </div>

            <div class="ship-liab">
                <div class="ship-liab-head">
                    <div>
                        <div class="ship-liab-title">Shipping liabilities</div>
                        <div class="ship-liab-note">Explicit shipping fee charges created by refund fault routing now appear here instead of being buried in generic debit exposure.</div>
                    </div>
                    <button type="button"
                            class="chip ship-liab-toggle"
                            aria-expanded="false"
                            aria-controls="ship-liab-list">
                        Open shipping liabilities: <?php echo (int) count($shipping_liability_rows); ?>
                    </button>
                </div>
                <?php if (!empty($shipping_liability_rows)): ?>
        <div class="ship-liab-list" id="ship-liab-list" hidden>                        <?php foreach (array_slice($shipping_liability_rows, 0, 12) as $slr):
                            $sl_meta = json_decode((string) ($slr['meta'] ?? ''), true);
                            $sl_meta = is_array($sl_meta) ? $sl_meta : [];
                            $sl_case = (string) ($sl_meta['case_id'] ?? '');
                            $sl_ship = (int) ($slr['shipment_id'] ?? 0);
                            $sl_order = (int) ($slr['order_id'] ?? 0);
                            $sl_status = (string) ($sl_meta['settlement_state'] ?? ($slr['state'] ?? 'posted'));
                            $sl_amount = abs((float) ($slr['net'] ?? 0));
                            $sl_reason = (string) ($slr['note'] ?? 'Shipping fee charge');
                        ?>
                        <div class="ship-liab-row">
                            <div><div class="xk">Case / reason</div><div class="xv"><?php echo esc_html(($sl_case !== '' ? $sl_case . ' — ' : '') . $sl_reason); ?></div></div>
                            <div><div class="xk">Amount</div><div class="xv">−<?php echo esc_html(number_format($sl_amount, 2)); ?> GYD</div></div>
                            <div><div class="xk">Order / shipment</div><div class="xv">#<?php echo esc_html((string) $sl_order); ?> / #<?php echo esc_html((string) $sl_ship); ?></div></div>
                            <div><div class="xk">Party</div><div class="xv"><?php echo esc_html(ucfirst((string) ($sl_meta['shipping_liability_party'] ?? 'seller'))); ?></div></div>
                            <div><div class="xk">Status</div><div class="xv"><?php echo esc_html(str_replace('_', ' ', $sl_status)); ?></div></div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="ship-liab-empty">No explicit shipping fee liabilities are open right now.</div>
                <?php endif; ?>
            </div>

            <?php if ($wallet_inspector_enabled): ?>
                <div class="adminInspector">
                    <h3>Admin Wallet Inspector</h3>
                    <div class="muted">Visible only to admins. Compares raw ledger truth to canonical wallet/card truth and shows remaining open debit exposures.</div>
                    <div style="margin-top:8px">
                        <?php if (empty($inspector_mismatches)): ?>
                            <span class="ok">All tracked wallet totals reconcile.</span>
                        <?php else: ?>
                            <span class="bad">Mismatch detected in <?php echo esc_html((string)count($inspector_mismatches)); ?> area(s).</span>
                        <?php endif; ?>
                    </div>

                    <div class="insGrid">
                        <div class="insHead">Metric</div>
                        <div class="insHead">Ledger</div>
                        <div class="insHead">Canonical</div>
                        <div class="insHead">Difference</div>
                        <?php foreach ($inspector_rows as $ir): $diff = round((float)$ir['canonical'] - (float)$ir['ledger'], 2); ?>
                            <div class="insCell"><strong><?php echo esc_html($ir['label']); ?></strong></div>
                            <div class="insCell"><?php echo esc_html(number_format((float)$ir['ledger'], 2)); ?> GYD</div>
                            <div class="insCell"><?php echo esc_html(number_format((float)$ir['canonical'], 2)); ?> GYD</div>
                            <div class="insCell <?php echo abs($diff) > 0.009 ? 'bad' : 'ok'; ?>"><?php echo esc_html(number_format($diff, 2)); ?> GYD</div>
                        <?php endforeach; ?>
                    </div>

                    <div class="insList">
                        <div class="muted" style="margin-bottom:6px">Remaining open debit exposures</div>
                        <?php if ($inspector_open_debits): ?>
                            <?php foreach ($inspector_open_debits as $od): ?>
                                <div class="row">
                                    <div>Shipment #<?php echo esc_html((string)$od['shipment_id']); ?></div>
                                    <div class="bad">−<?php echo esc_html(number_format((float)$od['remaining'], 2)); ?> GYD</div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="row"><div>No open debit exposures remain.</div><div class="ok">0.00 GYD</div></div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
            

            
            

            <div class="drawer" id="ccp2-drawer">
                <div class="row2">
                    <div class="rowFull">
                        <label>Payout method</label>
                        <select id="ccp2-method">
                            <option value="gtt" <?php selected($method,'gtt'); ?>>GTT Mobile Money</option>
                            <option value="bank" <?php selected($method,'bank'); ?>>Bank transfer</option>
                        </select>
                    </div>

                    <div class="rowFull" data-block="gtt">
                        <label>Mobile money number</label>
                        <input id="ccp2-gtt" type="text" inputmode="tel" placeholder="Enter mobile money number" value="<?php echo esc_attr($gtt_phone); ?>">
                    </div>

                    <div class="rowFull" data-block="bank" style="display:none">
                        <label>Bank name</label>
                        <input id="ccp2-bank" type="text" placeholder="Enter bank name" value="<?php echo esc_attr($bank_name); ?>">
                        <label>Account holder name</label>
                        <input id="ccp2-holder" type="text" placeholder="Enter account holder name" value="<?php echo esc_attr($bank_holder); ?>">
                        <label>Account number</label>
                        <input id="ccp2-acct" type="text" inputmode="numeric" placeholder="Enter account number" value="">
                        <div class="secureNote">Stored securely. Display will be masked (****1234).</div>
                    </div>
                </div>

                <div class="saveRow">
                    <div class="msg" id="ccp2-msg"></div>
                    <button class="btn" type="button" id="ccp2-cancel">Cancel</button>
                    <button class="btn primary" type="button" id="ccp2-save">Save method</button>
                </div>
            </div>

            <div class="act">
                <div class="actTop">
                    <div class="actTitle">Shipment sources</div>
                    <div class="tabs">
                        <?php
                            $base = remove_query_arg('cc_sp_filter');
                            $mk = function($k) use ($filter, $base){
                                $url = add_query_arg('cc_sp_filter', $k, $base);
                                $cls = 'tab' . ($filter === $k ? ' active' : '');
                                echo '<a class="'.esc_attr($cls).'" href="'.esc_url($url).'">'.esc_html(ucfirst($k)).'</a>';
                            };
                            $mk('all'); $mk('pending'); $mk('available'); $mk('paid'); $mk('hold');
                        ?>
                    </div>
                </div>

                <?php
                /* Vendor-safe receipt truth: build shipment-level figures from real ledger rows. */
                $ccvw_receipt_truth_by_shipment = [];
                $ccvw_receipt_shipments = [];

                // Label safety: order items are stronger than dirty legacy financial_slices.
                // If a label cannot be matched cleanly, the modal must show a neutral slice label,
                // never the wrong product name.
                $ccvw_order_item_name_cache = [];
                $ccvw_resolve_order_item_name = function($ccvw_order_id, $ccvw_order_item_id) use (&$ccvw_order_item_name_cache) {
                    $ccvw_order_id = absint($ccvw_order_id);
                    $ccvw_order_item_id = absint($ccvw_order_item_id);
                    if (!$ccvw_order_id || !$ccvw_order_item_id || !function_exists('wc_get_order')) return '';
                    $ccvw_cache_key = $ccvw_order_id . ':' . $ccvw_order_item_id;
                    if (array_key_exists($ccvw_cache_key, $ccvw_order_item_name_cache)) {
                        return $ccvw_order_item_name_cache[$ccvw_cache_key];
                    }
                    $ccvw_name = '';
                    try {
                        $ccvw_order = \wc_get_order($ccvw_order_id);
                        if ($ccvw_order) {
                            $ccvw_item = $ccvw_order->get_item($ccvw_order_item_id);
                            if ($ccvw_item && is_callable([$ccvw_item, 'get_name'])) {
                                $ccvw_name = trim(wp_strip_all_tags((string)$ccvw_item->get_name()));
                            }
                        }
                    } catch (\Throwable $ccvw_e) {
                        $ccvw_name = '';
                    }
                    $ccvw_order_item_name_cache[$ccvw_cache_key] = $ccvw_name;
                    return $ccvw_name;
                };
                foreach ((array) $rows as $ccvw_row_for_truth) {
                    $ccvw_sid_for_truth = (int)($ccvw_row_for_truth['shipment_id'] ?? 0);
                    if ($ccvw_sid_for_truth > 0) $ccvw_receipt_shipments[$ccvw_sid_for_truth] = $ccvw_sid_for_truth;
                }
                if (!empty($ccvw_receipt_shipments)) {
                    global $wpdb;
                    $ccvw_ledger_table = $wpdb->prefix . 'cc_sp_ledger';
                    $ccvw_ids = array_values(array_map('intval', $ccvw_receipt_shipments));
                    $ccvw_placeholders = implode(',', array_fill(0, count($ccvw_ids), '%d'));
                    $ccvw_sql = "SELECT id, unique_key, shipment_id, order_id, vendor_id, state, event_type, gross, commission, courier_fees, reserve, net, meta FROM {$ccvw_ledger_table} WHERE shipment_id IN ({$ccvw_placeholders}) ORDER BY id ASC";
                    $ccvw_ledger_rows_for_truth = $wpdb->get_results($wpdb->prepare($ccvw_sql, $ccvw_ids), ARRAY_A);
                    foreach ((array) $ccvw_ledger_rows_for_truth as $ccvw_lr) {
                        $ccvw_sid = (int)($ccvw_lr['shipment_id'] ?? 0);
                        if ($ccvw_sid <= 0) continue;
                        if (!isset($ccvw_receipt_truth_by_shipment[$ccvw_sid])) {
                            $ccvw_receipt_truth_by_shipment[$ccvw_sid] = ['original'=>0.0,'recovered'=>0.0,'unpaid_reversed'=>0.0,'unpaid_reversal_rows'=>[],'paid_payable'=>0.0,'own_debit_total'=>0.0,'own_debit_rows'=>[],'own_debit_cleared_by'=>[],'own_debit_seen'=>[],'offset_rows'=>[],'cash_rows'=>[],'source_shipments'=>[],'source_recovery_target_rows'=>[],'source_recovery_target_seen'=>[],'unpaid_reversal_seen'=>[],'unwind_rows'=>[],'reopened_rows'=>[],'trace_warnings'=>[],'offset_row_seen'=>[],'unwind_row_seen'=>[],'reopened_row_seen'=>[]];
                        }
                        $ccvw_event = strtolower(trim((string)($ccvw_lr['event_type'] ?? '')));
                        $ccvw_state = strtolower(trim((string)($ccvw_lr['state'] ?? '')));
                        $ccvw_net   = (float)($ccvw_lr['net'] ?? 0);
                        $ccvw_gross = (float)($ccvw_lr['gross'] ?? 0);
                        $ccvw_comm  = (float)($ccvw_lr['commission'] ?? 0);
                        $ccvw_cour  = (float)($ccvw_lr['courier_fees'] ?? 0);
                        $ccvw_res   = (float)($ccvw_lr['reserve'] ?? 0);
                        $ccvw_meta  = json_decode((string)($ccvw_lr['meta'] ?? ''), true);
                        $ccvw_meta  = is_array($ccvw_meta) ? $ccvw_meta : [];
                        $ccvw_payout_mode = strtolower(trim((string)($ccvw_meta['payout_mode'] ?? '')));

                        // Strict ledger trace rows: target unwind and source reopen are first-class story movements.
                        foreach ((array)($ccvw_meta['historical_offset_sources_unwound'] ?? []) as $ccvw_unwind_edge) {
                            if (!is_array($ccvw_unwind_edge)) continue;
                            $ccvw_unwind_amount = abs((float)($ccvw_unwind_edge['amount'] ?? 0));
                            if ($ccvw_unwind_amount <= 0) continue;
                            // CCVW_TRACE_DEDUPE_LEDGER_READER_V1: historical unwind edges can be embedded
                            // on more than one role row. The wallet is a reader, so it must collapse exact
                            // edge identity instead of replaying every embedded copy as a new movement.
                            $ccvw_unwind_key = implode('|', [
                                (string)($ccvw_unwind_edge['debit_row_id'] ?? $ccvw_unwind_edge['source_debit_row_id'] ?? 0),
                                (string)($ccvw_unwind_edge['source_shipment_id'] ?? 0),
                                (string)($ccvw_unwind_edge['source_slice_id'] ?? ''),
                                (string)($ccvw_unwind_edge['target_slice_id'] ?? ''),
                                (string)($ccvw_unwind_edge['refund_case_id'] ?? $ccvw_meta['refund_target_unwind_case_id'] ?? ''),
                                number_format($ccvw_unwind_amount, 2, '.', ''),
                            ]);
                            if (isset($ccvw_receipt_truth_by_shipment[$ccvw_sid]['unwind_row_seen'][$ccvw_unwind_key])) continue;
                            $ccvw_receipt_truth_by_shipment[$ccvw_sid]['unwind_row_seen'][$ccvw_unwind_key] = true;
                            $ccvw_receipt_truth_by_shipment[$ccvw_sid]['unwind_rows'][] = [
                                'row_id' => (int)($ccvw_lr['id'] ?? 0),
                                'amount' => round($ccvw_unwind_amount, 2),
                                'currency' => (string)($ccvw_lr['currency'] ?? 'GYD'),
                                'source_debit_row_id' => (int)($ccvw_unwind_edge['debit_row_id'] ?? $ccvw_unwind_edge['source_debit_row_id'] ?? 0),
                                'source_shipment_id' => (int)($ccvw_unwind_edge['source_shipment_id'] ?? 0),
                                'source_order_id' => (int)($ccvw_unwind_edge['source_order_id'] ?? 0),
                                'source_order_item_id' => (int)($ccvw_unwind_edge['source_order_item_id'] ?? 0),
                                'source_slice_id' => (string)($ccvw_unwind_edge['source_slice_id'] ?? ''),
                                'target_slice_id' => (string)($ccvw_unwind_edge['target_slice_id'] ?? ''),
                                'target_order_item_id' => (int)($ccvw_unwind_edge['target_order_item_id'] ?? 0),
                                'match_mode' => (string)($ccvw_unwind_edge['match_mode'] ?? ''),
                                'refund_case_id' => (string)($ccvw_unwind_edge['refund_case_id'] ?? $ccvw_meta['refund_target_unwind_case_id'] ?? ''),
                                'at' => (string)($ccvw_unwind_edge['refund_unwound_at'] ?? $ccvw_meta['refund_target_unwind_at'] ?? ''),
                            ];
                        }

                        foreach ((array)($ccvw_meta['historical_offset_targets_reopened'] ?? []) as $ccvw_reopen_edge) {
                            if (!is_array($ccvw_reopen_edge)) continue;
                            $ccvw_reopen_amount = abs((float)($ccvw_reopen_edge['amount'] ?? 0));
                            if ($ccvw_reopen_amount <= 0) continue;
                            // CCVW_TRACE_DEDUPE_LEDGER_READER_V1: source reopen events can be copied into
                            // later role rows for lineage. Show each exact source/target/case movement once.
                            $ccvw_reopen_key = implode('|', [
                                (string)($ccvw_reopen_edge['target_row_id'] ?? 0),
                                (string)($ccvw_reopen_edge['target_shipment_id'] ?? $ccvw_meta['target_shipment_id'] ?? 0),
                                (string)($ccvw_reopen_edge['target_slice_id'] ?? ''),
                                (string)($ccvw_reopen_edge['source_slice_id'] ?? $ccvw_meta['source_slice_id'] ?? ''),
                                (string)($ccvw_reopen_edge['case_id'] ?? $ccvw_meta['refund_target_reopen_case_id'] ?? ''),
                                number_format($ccvw_reopen_amount, 2, '.', ''),
                            ]);
                            if (isset($ccvw_receipt_truth_by_shipment[$ccvw_sid]['reopened_row_seen'][$ccvw_reopen_key])) continue;
                            $ccvw_receipt_truth_by_shipment[$ccvw_sid]['reopened_row_seen'][$ccvw_reopen_key] = true;
                            $ccvw_receipt_truth_by_shipment[$ccvw_sid]['reopened_rows'][] = [
                                'row_id' => (int)($ccvw_lr['id'] ?? 0),
                                'amount' => round($ccvw_reopen_amount, 2),
                                'currency' => (string)($ccvw_lr['currency'] ?? 'GYD'),
                                'target_row_id' => (int)($ccvw_reopen_edge['target_row_id'] ?? 0),
                                'target_shipment_id' => (int)($ccvw_reopen_edge['target_shipment_id'] ?? $ccvw_meta['target_shipment_id'] ?? 0),
                                'target_order_id' => (int)($ccvw_reopen_edge['target_order_id'] ?? $ccvw_meta['target_order_id'] ?? 0),
                                'target_slice_id' => (string)($ccvw_reopen_edge['target_slice_id'] ?? ''),
                                'source_slice_id' => (string)($ccvw_reopen_edge['source_slice_id'] ?? $ccvw_meta['source_slice_id'] ?? ''),
                                'source_order_item_id' => (int)($ccvw_reopen_edge['source_order_item_id'] ?? $ccvw_meta['source_order_item_id'] ?? 0),
                                'case_id' => (string)($ccvw_reopen_edge['case_id'] ?? $ccvw_meta['refund_target_reopen_case_id'] ?? ''),
                                'source_original_amount' => round(abs((float)($ccvw_reopen_edge['source_original_amount'] ?? $ccvw_meta['source_amount_original'] ?? 0)), 2),
                                'source_still_recovered_after_reopen' => round(abs((float)($ccvw_reopen_edge['source_still_recovered_after_reopen'] ?? $ccvw_meta['source_amount_still_recovered'] ?? 0)), 2),
                                'source_currently_open_after_reopen' => round(abs((float)($ccvw_reopen_edge['source_currently_open_after_reopen'] ?? $ccvw_meta['source_amount_currently_open'] ?? abs($ccvw_net))), 2),
                                'at' => (string)($ccvw_reopen_edge['at'] ?? $ccvw_meta['state_timestamp'] ?? ''),
                            ];
                        }

                        // Vendor receipt truth layer:
                        // returns that reversed unpaid seller earnings are real deductions,
                        // but they are NOT later recovery offsets and should not be shown as payable.
                        // Example: Shipment #20547 had 80,500.99 reversed before payout, then
                        // another 9,680.00 was consumed as an offset. Final payable is 0.
                        if (!empty($ccvw_meta['historical_return_slices']) && is_array($ccvw_meta['historical_return_slices'])) {
                            foreach ((array)$ccvw_meta['historical_return_slices'] as $ccvw_hist_slice) {
                                if (!is_array($ccvw_hist_slice)) continue;
                                $ccvw_hist_state = strtolower(trim((string)($ccvw_hist_slice['state'] ?? '')));
                                if ($ccvw_hist_state !== 'reversed_unpaid') continue;

                                // These historical return slices can be embedded repeatedly on multiple
                                // ledger rows for the same shipment. They are story truth, not separate
                                // deductions each time they appear. Dedupe them before summing or the
                                // vendor receipt can triple-count the same unpaid reversal family.
                                $ccvw_hist_case = trim((string)($ccvw_hist_slice['case_id'] ?? ''));
                                $ccvw_hist_slice_id = trim((string)($ccvw_hist_slice['slice_id'] ?? ''));
                                $ccvw_hist_item_id = (string)($ccvw_hist_slice['item_id'] ?? $ccvw_hist_slice['order_item_id'] ?? '');
                                $ccvw_hist_unique = trim((string)($ccvw_hist_slice['unique_key'] ?? ''));
                                $ccvw_hist_key = $ccvw_hist_case . '|' . $ccvw_hist_slice_id . '|' . $ccvw_hist_item_id . '|' . $ccvw_hist_state;
                                if ($ccvw_hist_key === '|||reversed_unpaid' && $ccvw_hist_unique !== '') {
                                    $ccvw_hist_key = $ccvw_hist_unique . '|' . $ccvw_hist_state;
                                }
                                if ($ccvw_hist_key === '|||reversed_unpaid') {
                                    $ccvw_hist_key = md5(wp_json_encode($ccvw_hist_slice));
                                }
                                if (isset($ccvw_receipt_truth_by_shipment[$ccvw_sid]['unpaid_reversal_seen'][$ccvw_hist_key])) {
                                    continue;
                                }
                                $ccvw_receipt_truth_by_shipment[$ccvw_sid]['unpaid_reversal_seen'][$ccvw_hist_key] = true;

                                $ccvw_hist_amount = abs((float)($ccvw_hist_slice['seller_impact'] ?? $ccvw_hist_slice['vendor_impact'] ?? $ccvw_hist_slice['reversed_amount'] ?? 0));
                                if ($ccvw_hist_amount > 0) {
                                    $ccvw_receipt_truth_by_shipment[$ccvw_sid]['unpaid_reversed'] += $ccvw_hist_amount;
                                    $ccvw_receipt_truth_by_shipment[$ccvw_sid]['unpaid_reversal_rows'][] = [
                                        'kind' => !empty($ccvw_hist_slice['is_shipping_component']) || (($ccvw_hist_slice['kind'] ?? '') === 'shipping') ? 'shipping' : 'return',
                                        'name' => (string)($ccvw_hist_slice['item_name'] ?? $ccvw_hist_slice['name'] ?? 'Returned item'),
                                        'qty' => (float)($ccvw_hist_slice['qty_refundable'] ?? $ccvw_hist_slice['qty'] ?? 1),
                                        'amount' => round($ccvw_hist_amount, 2),
                                        'currency' => (string)($ccvw_hist_slice['currency'] ?? $ccvw_lr['currency'] ?? 'GYD'),
                                        'case_id' => $ccvw_hist_case,
                                        'slice_id' => $ccvw_hist_slice_id,
                                    ];
                                }
                            }
                        }

                        // If a returned item on THIS shipment became source debt after payout, show it
                        // as this shipment's own debit exposure instead of pretending this shipment paid another shipment.
                        // Example: #20547 chicken/Brush were later returned as open debit rows and were cleared by #20551.
                        $ccvw_meta_type = strtolower(trim((string)($ccvw_meta['type'] ?? '')));
                        $ccvw_chain_mode = strtolower(trim((string)($ccvw_meta['chain_mode'] ?? '')));
                        $ccvw_is_own_debit = (
                            $ccvw_meta_type === 'debit'
                            || strpos($ccvw_event, 'seller_deduction') !== false
                            || $ccvw_chain_mode === 'source_open'
                        );

                        if ($ccvw_is_own_debit) {
                            $ccvw_debit_case = trim((string)($ccvw_meta['case_id'] ?? ''));
                            $ccvw_debit_slice = trim((string)($ccvw_meta['slice_id'] ?? ''));
                            $ccvw_debit_item = (string)($ccvw_meta['order_item_id'] ?? '');
                            $ccvw_debit_key = $ccvw_debit_case . '|' . $ccvw_debit_slice . '|' . $ccvw_debit_item;
                            if ($ccvw_debit_key === '||') {
                                $ccvw_debit_key = (string)($ccvw_lr['unique_key'] ?? ('row:' . (int)($ccvw_lr['id'] ?? 0)));
                            }

                            if (!isset($ccvw_receipt_truth_by_shipment[$ccvw_sid]['own_debit_seen'][$ccvw_debit_key])) {
                                $ccvw_receipt_truth_by_shipment[$ccvw_sid]['own_debit_seen'][$ccvw_debit_key] = true;

                                $ccvw_debit_amount = 0.0;
                                $ccvw_debit_name = 'Returned item';
                                $ccvw_debit_qty = 1.0;
                                $ccvw_debit_kind = 'return';
                                $ccvw_debit_label_candidates = [];

                                if (!empty($ccvw_meta['shipping_liability']) || !empty($ccvw_meta['shipping_liability_amount'])) {
                                    $ccvw_debit_kind = 'shipping';
                                    $ccvw_debit_name = 'Shipping fee charge';
                                    $ccvw_debit_amount = abs((float)($ccvw_meta['shipping_liability_amount'] ?? 0));
                                }

                                if (!empty($ccvw_meta['financial_slices']) && is_array($ccvw_meta['financial_slices'])) {
                                    foreach ((array)$ccvw_meta['financial_slices'] as $ccvw_debit_slice_row) {
                                        if (!is_array($ccvw_debit_slice_row)) continue;
                                        // Financial slices can be legacy-dirty after repeated reopen/unwind.
                                        // Keep them only as weak label candidates; do not blindly use the name.
                                        $ccvw_candidate_name = trim((string)($ccvw_debit_slice_row['name'] ?? $ccvw_debit_slice_row['item_name'] ?? ''));
                                        $ccvw_candidate_amount = abs((float)($ccvw_debit_slice_row['seller_impact'] ?? $ccvw_debit_slice_row['vendor_impact'] ?? $ccvw_debit_slice_row['amount'] ?? $ccvw_debit_slice_row['reversed_amount'] ?? 0));
                                        if ($ccvw_candidate_name !== '') {
                                            $ccvw_debit_label_candidates[] = [
                                                'name' => $ccvw_candidate_name,
                                                'amount' => round($ccvw_candidate_amount, 2),
                                                'order_item_id' => absint($ccvw_debit_slice_row['order_item_id'] ?? $ccvw_debit_slice_row['item_id'] ?? 0),
                                            ];
                                        }
                                        if (isset($ccvw_debit_slice_row['qty'])) $ccvw_debit_qty = (float)$ccvw_debit_slice_row['qty'];
                                    }
                                }

                                if ($ccvw_debit_amount <= 0 && !empty($ccvw_meta['return_bridge']) && is_array($ccvw_meta['return_bridge'])) {
                                    $ccvw_rb = $ccvw_meta['return_bridge'];
                                    $ccvw_debit_amount = abs((float)($ccvw_rb['seller_impact'] ?? $ccvw_rb['vendor_impact'] ?? $ccvw_rb['item_price_net'] ?? 0));
                                    if (!empty($ccvw_rb['item_name'])) {
                                        $ccvw_debit_label_candidates[] = [
                                            'name' => trim((string)$ccvw_rb['item_name']),
                                            'amount' => round($ccvw_debit_amount, 2),
                                            'order_item_id' => absint($ccvw_rb['order_item_id'] ?? $ccvw_rb['item_id'] ?? 0),
                                        ];
                                    }
                                    if (isset($ccvw_rb['qty_refundable'])) $ccvw_debit_qty = (float)$ccvw_rb['qty_refundable'];
                                    if (!empty($ccvw_rb['is_shipping_component']) || (($ccvw_rb['kind'] ?? '') === 'shipping')) $ccvw_debit_kind = 'shipping';
                                }

                                if ($ccvw_debit_amount > 0 || ($ccvw_state === 'debit' && $ccvw_net < 0)) {
                                    $ccvw_cleared_by = [];
                                    $ccvw_cleared_by_edges = [];
                                    $ccvw_row_recovered = 0.0;
                                    foreach ((array)($ccvw_meta['offset_targets'] ?? []) as $ccvw_target_edge) {
                                        if (!is_array($ccvw_target_edge)) continue;
                                        $ccvw_target_sid = (int)($ccvw_target_edge['target_shipment_id'] ?? 0);
                                        $ccvw_target_amount = abs((float)($ccvw_target_edge['amount'] ?? 0));
                                        if ($ccvw_target_sid > 0) {
                                            $ccvw_cleared_by[$ccvw_target_sid] = $ccvw_target_sid;
                                            $ccvw_receipt_truth_by_shipment[$ccvw_sid]['own_debit_cleared_by'][$ccvw_target_sid] = $ccvw_target_sid;
                                            if ($ccvw_target_amount > 0) {
                                                $ccvw_cleared_by_edges[] = [
                                                    'target_shipment_id' => $ccvw_target_sid,
                                                    'target_order_id' => (int)($ccvw_target_edge['target_order_id'] ?? 0),
                                                    'target_row_id' => (int)($ccvw_target_edge['target_row_id'] ?? 0),
                                                    'target_slice_id' => (string)($ccvw_target_edge['target_slice_id'] ?? ''),
                                                    'target_order_item_id' => (int)($ccvw_target_edge['target_order_item_id'] ?? 0),
                                                    'amount' => round($ccvw_target_amount, 2),
                                                    'currency' => (string)($ccvw_lr['currency'] ?? 'GYD'),
                                                    'reference' => (string)($ccvw_target_edge['reference'] ?? ''),
                                                    'allocated_at' => (string)($ccvw_target_edge['allocated_at'] ?? ''),
                                                    'finalized_at' => (string)($ccvw_target_edge['finalized_at'] ?? ''),
                                                ];
                                            }
                                        }
                                        $ccvw_row_recovered += $ccvw_target_amount;
                                    }

                                    // Prefer explicit clean ledger truth when present. Otherwise derive from row net
                                    // and edge totals, not from dirty legacy reopened financial_slices that can double.
                                    $ccvw_clean_original  = abs((float)($ccvw_meta['source_amount_original'] ?? 0));
                                    $ccvw_clean_open      = abs((float)($ccvw_meta['source_amount_currently_open'] ?? 0));
                                    $ccvw_clean_recovered = abs((float)($ccvw_meta['source_amount_still_recovered'] ?? 0));

                                    if ($ccvw_clean_recovered <= 0) {
                                        $ccvw_clean_recovered = $ccvw_row_recovered;
                                    }
                                    if ($ccvw_clean_recovered <= 0 && isset($ccvw_meta['debit_offset_applied'])) {
                                        $ccvw_clean_recovered = abs((float)$ccvw_meta['debit_offset_applied']);
                                    }

                                    if ($ccvw_clean_open <= 0 && $ccvw_state === 'debit' && $ccvw_net < 0) {
                                        // Current open source debt is the negative row net. This is safer than legacy
                                        // chain_source_remaining on pre-cleanup rows such as reopened source rows.
                                        $ccvw_clean_open = abs($ccvw_net);
                                    } elseif ($ccvw_clean_open <= 0 && isset($ccvw_meta['chain_source_remaining']) && $ccvw_state !== 'reversed') {
                                        $ccvw_clean_open = abs((float)$ccvw_meta['chain_source_remaining']);
                                    }

                                    if ($ccvw_clean_original > 0) {
                                        $ccvw_debit_amount = $ccvw_clean_original;
                                    } elseif ($ccvw_state === 'debit' && $ccvw_net < 0) {
                                        $ccvw_debit_amount = max(abs($ccvw_net), abs($ccvw_net) + $ccvw_clean_recovered);
                                    } elseif ($ccvw_debit_amount <= 0 && $ccvw_clean_open > 0) {
                                        $ccvw_debit_amount = $ccvw_clean_open + $ccvw_clean_recovered;
                                    }

                                    if ($ccvw_debit_amount <= 0) {
                                        continue;
                                    }

                                    if ($ccvw_clean_open <= 0 && $ccvw_state === 'reversed') {
                                        $ccvw_clean_open = 0.0;
                                    }
                                    if ($ccvw_clean_recovered <= 0 && $ccvw_clean_open <= 0 && $ccvw_state === 'reversed') {
                                        $ccvw_clean_recovered = $ccvw_debit_amount;
                                    }
                                    if ($ccvw_clean_recovered <= 0 && $ccvw_clean_open > 0) {
                                        $ccvw_clean_recovered = max(0.0, $ccvw_debit_amount - $ccvw_clean_open);
                                    }
                                    if ($ccvw_clean_open <= 0 && $ccvw_clean_recovered > 0) {
                                        $ccvw_clean_open = max(0.0, $ccvw_debit_amount - $ccvw_clean_recovered);
                                    }
                                    // If a row is currently open, prior historical recovery cannot also count
                                    // as current recovered money against that same open exposure.
                                    if ($ccvw_clean_open > 0 && $ccvw_clean_recovered > max(0.0, $ccvw_debit_amount - $ccvw_clean_open) + 0.01) {
                                        $ccvw_clean_recovered = max(0.0, $ccvw_debit_amount - $ccvw_clean_open);
                                    }

                                    // Final label resolution: exact candidate by amount/order item, otherwise neutral.
                                    if ($ccvw_debit_kind !== 'shipping') {
                                        $ccvw_order_id = absint($ccvw_meta['order_id'] ?? $ccvw_meta['source_order_id'] ?? $ccvw_lr['order_id'] ?? 0);
                                        $ccvw_order_item_id = absint($ccvw_meta['order_item_id'] ?? $ccvw_meta['source_order_item_id'] ?? 0);
                                        $ccvw_order_name = $ccvw_resolve_order_item_name($ccvw_order_id, $ccvw_order_item_id);
                                        $ccvw_amount_matches = [];
                                        $ccvw_item_matches = [];
                                        foreach ((array)$ccvw_debit_label_candidates as $ccvw_candidate) {
                                            if (!is_array($ccvw_candidate)) continue;
                                            $ccvw_candidate_name = trim((string)($ccvw_candidate['name'] ?? ''));
                                            if ($ccvw_candidate_name === '') continue;
                                            $ccvw_candidate_amount = round(abs((float)($ccvw_candidate['amount'] ?? 0)), 2);
                                            $ccvw_candidate_item_id = absint($ccvw_candidate['order_item_id'] ?? 0);
                                            if ($ccvw_candidate_amount > 0 && abs($ccvw_candidate_amount - round($ccvw_debit_amount, 2)) < 0.02) {
                                                $ccvw_amount_matches[$ccvw_candidate_name] = $ccvw_candidate_name;
                                            }
                                            if ($ccvw_order_item_id > 0 && $ccvw_candidate_item_id === $ccvw_order_item_id && ($ccvw_candidate_amount <= 0 || abs($ccvw_candidate_amount - round($ccvw_debit_amount, 2)) < 0.02)) {
                                                $ccvw_item_matches[$ccvw_candidate_name] = $ccvw_candidate_name;
                                            }
                                        }
                                        if (count($ccvw_amount_matches) === 1) {
                                            $ccvw_debit_name = (string)reset($ccvw_amount_matches);
                                        } elseif (count($ccvw_item_matches) === 1) {
                                            $ccvw_debit_name = (string)reset($ccvw_item_matches);
                                        } elseif ($ccvw_order_name !== '' && empty($ccvw_debit_label_candidates)) {
                                            $ccvw_debit_name = $ccvw_order_name;
                                        } else {
                                            $ccvw_debit_name = 'Returned item slice';
                                        }
                                    }

                                    $ccvw_receipt_truth_by_shipment[$ccvw_sid]['own_debit_total'] += $ccvw_debit_amount;
                                    $ccvw_receipt_truth_by_shipment[$ccvw_sid]['own_debit_rows'][] = [
                                        'kind' => $ccvw_debit_kind,
                                        'name' => $ccvw_debit_name,
                                        'qty' => $ccvw_debit_qty,
                                        'amount' => round($ccvw_debit_amount, 2),
                                        'recovered_amount' => round($ccvw_clean_recovered, 2),
                                        'remaining_amount' => round($ccvw_clean_open, 2),
                                        'current_open_amount' => round($ccvw_clean_open, 2),
                                        'currency' => (string)($ccvw_lr['currency'] ?? 'GYD'),
                                        'case_id' => $ccvw_debit_case,
                                        'slice_id' => $ccvw_debit_slice,
                                        'order_item_id' => (int)($ccvw_meta['order_item_id'] ?? 0),
                                        'source_amount_original' => round($ccvw_debit_amount, 2),
                                        'source_amount_still_recovered' => round($ccvw_clean_recovered, 2),
                                        'source_amount_currently_open' => round($ccvw_clean_open, 2),
                                        'ledger_row_id' => (int)($ccvw_lr['id'] ?? 0),
                                        'ledger_state' => $ccvw_state,
                                        'chain_mode' => $ccvw_chain_mode,
                                        'cleared_by_shipments' => array_values($ccvw_cleared_by),
                                        'cleared_by_edges' => array_values($ccvw_cleared_by_edges),
                                    ];
                                }
                            }
                        }

                        $ccvw_is_offset = ($ccvw_event === 'seller_offset_consumed' || $ccvw_payout_mode === 'offset');
                        if ($ccvw_is_offset) {
                            $ccvw_amount = abs($ccvw_net);
                            if ($ccvw_amount > 0) {
                                $ccvw_receipt_truth_by_shipment[$ccvw_sid]['recovered'] += $ccvw_amount;
                            }

                            $ccvw_has_source_edges = false;
                            foreach ((array)($ccvw_meta['offset_sources'] ?? []) as $ccvw_src_edge) {
                                if (!is_array($ccvw_src_edge)) continue;

                                $ccvw_src_sid = (int)($ccvw_src_edge['source_shipment_id'] ?? 0);
                                $ccvw_edge_amount = abs((float)($ccvw_src_edge['amount'] ?? 0));

                                if ($ccvw_src_sid > 0) {
                                    $ccvw_receipt_truth_by_shipment[$ccvw_sid]['source_shipments'][$ccvw_src_sid] = $ccvw_src_sid;
                                }

                                if ($ccvw_src_sid > 0 && $ccvw_edge_amount > 0) {
                                    $ccvw_offset_key = implode('|', [
                                        (string)($ccvw_src_edge['debit_row_id'] ?? $ccvw_src_edge['source_debit_row_id'] ?? 0),
                                        (string)$ccvw_src_sid,
                                        (string)($ccvw_src_edge['source_slice_id'] ?? ''),
                                        (string)($ccvw_src_edge['target_row_id'] ?? $ccvw_lr['id'] ?? 0),
                                        (string)($ccvw_src_edge['target_slice_id'] ?? ''),
                                        number_format($ccvw_edge_amount, 2, '.', ''),
                                    ]);
                                    if (isset($ccvw_receipt_truth_by_shipment[$ccvw_sid]['offset_row_seen'][$ccvw_offset_key])) continue;
                                    $ccvw_receipt_truth_by_shipment[$ccvw_sid]['offset_row_seen'][$ccvw_offset_key] = true;
                                    $ccvw_has_source_edges = true;
                                    $ccvw_receipt_truth_by_shipment[$ccvw_sid]['offset_rows'][] = [
                                        'row_id'               => (int)($ccvw_lr['id'] ?? 0),
                                        'target_row_id'        => (int)($ccvw_src_edge['target_row_id'] ?? $ccvw_lr['id'] ?? 0),
                                        'target_shipment_id'   => $ccvw_sid,
                                        'target_order_id'      => (int)($ccvw_src_edge['target_order_id'] ?? $ccvw_lr['order_id'] ?? 0),
                                        'target_slice_id'      => (string)($ccvw_src_edge['target_slice_id'] ?? ''),
                                        'target_order_item_id' => (int)($ccvw_src_edge['target_order_item_id'] ?? 0),
                                        'debit_row_id'         => (int)($ccvw_src_edge['debit_row_id'] ?? $ccvw_src_edge['source_debit_row_id'] ?? 0),
                                        'amount'               => round($ccvw_edge_amount, 2),
                                        'currency'             => (string)($ccvw_lr['currency'] ?? 'GYD'),
                                        'source_shipment_id'   => $ccvw_src_sid,
                                        'source_order_id'      => (int)($ccvw_src_edge['source_order_id'] ?? 0),
                                        'source_order_item_id' => (int)($ccvw_src_edge['source_order_item_id'] ?? 0),
                                        'source_slice_id'      => (string)($ccvw_src_edge['source_slice_id'] ?? ''),
                                        'reference'            => (string)($ccvw_src_edge['reference'] ?? ''),
                                        'allocation_status'    => (string)($ccvw_src_edge['allocation_status'] ?? ''),
                                        'allocated_at'         => (string)($ccvw_src_edge['allocated_at'] ?? ''),
                                        'finalized_at'         => (string)($ccvw_src_edge['finalized_at'] ?? ''),
                                    ];

                                    // Mirror the same edge onto the source shipment's return-balance modal.
                                    // This prevents the source modal from omitting a target payout that helped recover it.
                                    if (isset($ccvw_receipt_truth_by_shipment[$ccvw_src_sid]) && is_array($ccvw_receipt_truth_by_shipment[$ccvw_src_sid])) {
                                        if (!isset($ccvw_receipt_truth_by_shipment[$ccvw_src_sid]['source_recovery_target_seen']) || !is_array($ccvw_receipt_truth_by_shipment[$ccvw_src_sid]['source_recovery_target_seen'])) {
                                            $ccvw_receipt_truth_by_shipment[$ccvw_src_sid]['source_recovery_target_seen'] = [];
                                        }
                                        if (!isset($ccvw_receipt_truth_by_shipment[$ccvw_src_sid]['source_recovery_target_rows']) || !is_array($ccvw_receipt_truth_by_shipment[$ccvw_src_sid]['source_recovery_target_rows'])) {
                                            $ccvw_receipt_truth_by_shipment[$ccvw_src_sid]['source_recovery_target_rows'] = [];
                                        }
                                        $ccvw_source_target_key = implode('|', [
                                            (string)($ccvw_src_edge['debit_row_id'] ?? $ccvw_src_edge['source_debit_row_id'] ?? 0),
                                            (string)$ccvw_src_sid,
                                            (string)($ccvw_src_edge['source_slice_id'] ?? ''),
                                            (string)$ccvw_sid,
                                            (string)($ccvw_src_edge['target_row_id'] ?? $ccvw_lr['id'] ?? 0),
                                            (string)($ccvw_src_edge['target_slice_id'] ?? ''),
                                            number_format($ccvw_edge_amount, 2, '.', ''),
                                        ]);
                                        if (!isset($ccvw_receipt_truth_by_shipment[$ccvw_src_sid]['source_recovery_target_seen'][$ccvw_source_target_key])) {
                                            $ccvw_receipt_truth_by_shipment[$ccvw_src_sid]['source_recovery_target_seen'][$ccvw_source_target_key] = true;
                                            $ccvw_receipt_truth_by_shipment[$ccvw_src_sid]['source_recovery_target_rows'][] = [
                                                'target_shipment_id'   => $ccvw_sid,
                                                'target_order_id'      => (int)($ccvw_src_edge['target_order_id'] ?? $ccvw_lr['order_id'] ?? 0),
                                                'target_row_id'        => (int)($ccvw_src_edge['target_row_id'] ?? $ccvw_lr['id'] ?? 0),
                                                'target_slice_id'      => (string)($ccvw_src_edge['target_slice_id'] ?? ''),
                                                'target_order_item_id' => (int)($ccvw_src_edge['target_order_item_id'] ?? 0),
                                                'source_debit_row_id'  => (int)($ccvw_src_edge['debit_row_id'] ?? $ccvw_src_edge['source_debit_row_id'] ?? 0),
                                                'source_slice_id'      => (string)($ccvw_src_edge['source_slice_id'] ?? ''),
                                                'source_order_item_id' => (int)($ccvw_src_edge['source_order_item_id'] ?? 0),
                                                'amount'               => round($ccvw_edge_amount, 2),
                                                'currency'             => (string)($ccvw_lr['currency'] ?? 'GYD'),
                                                'reference'            => (string)($ccvw_src_edge['reference'] ?? ''),
                                                'allocated_at'         => (string)($ccvw_src_edge['allocated_at'] ?? ''),
                                                'finalized_at'         => (string)($ccvw_src_edge['finalized_at'] ?? ''),
                                            ];
                                        }
                                    }
                                }
                            }

                            foreach ((array)($ccvw_meta['offset_source_shipments'] ?? []) as $ccvw_src_sid) {
                                $ccvw_src_sid = (int)$ccvw_src_sid;
                                if ($ccvw_src_sid > 0) $ccvw_receipt_truth_by_shipment[$ccvw_sid]['source_shipments'][$ccvw_src_sid] = $ccvw_src_sid;
                            }

                            if (!$ccvw_has_source_edges && $ccvw_amount > 0) {
                                $ccvw_fallback_src_sid = 0;
                                if (!empty($ccvw_meta['offset_source_shipments']) && is_array($ccvw_meta['offset_source_shipments'])) {
                                    $ccvw_fallback_src_sid = (int) reset($ccvw_meta['offset_source_shipments']);
                                }
                                $ccvw_receipt_truth_by_shipment[$ccvw_sid]['offset_rows'][] = [
                                    'row_id'             => (int)($ccvw_lr['id'] ?? 0),
                                    'amount'             => round($ccvw_amount, 2),
                                    'source_shipment_id' => max(0, $ccvw_fallback_src_sid),
                                ];
                            }
                            continue;
                        }
                        $ccvw_capacity = 0.0;
                        if (isset($ccvw_meta['chain_target_capacity_original'])) $ccvw_capacity = max($ccvw_capacity, (float)$ccvw_meta['chain_target_capacity_original']);
                        $ccvw_gross_net = $ccvw_gross - $ccvw_comm - $ccvw_cour - $ccvw_res;
                        if ($ccvw_gross_net > 0) $ccvw_capacity = max($ccvw_capacity, $ccvw_gross_net);
                        if ($ccvw_capacity > 0) $ccvw_receipt_truth_by_shipment[$ccvw_sid]['original'] = max((float)$ccvw_receipt_truth_by_shipment[$ccvw_sid]['original'], $ccvw_capacity);
                        $ccvw_is_cash_row = ($ccvw_event === 'vendor_withdrawal_paid' || $ccvw_payout_mode === 'cash');
                        if ($ccvw_is_cash_row && $ccvw_state === 'paid' && $ccvw_net > 0) {
                            $ccvw_receipt_truth_by_shipment[$ccvw_sid]['paid_payable'] += $ccvw_net;
                            $ccvw_receipt_truth_by_shipment[$ccvw_sid]['cash_rows'][] = ['row_id'=>(int)($ccvw_lr['id'] ?? 0),'amount'=>round($ccvw_net,2)];
                        }
                    }
                    foreach ($ccvw_receipt_truth_by_shipment as $ccvw_sid => $ccvw_truth) {
                        $ccvw_original = round((float)($ccvw_truth['original'] ?? 0), 2);
                        $ccvw_recovered = round((float)($ccvw_truth['recovered'] ?? 0), 2);
                        $ccvw_unpaid_reversed = round((float)($ccvw_truth['unpaid_reversed'] ?? 0), 2);
                        $ccvw_paid = round((float)($ccvw_truth['paid_payable'] ?? 0), 2);
                        $ccvw_own_debit_total = round((float)($ccvw_truth['own_debit_total'] ?? 0), 2);
                        $ccvw_unwind_total = 0.0;
                        foreach ((array)($ccvw_truth['unwind_rows'] ?? []) as $ccvw_unwind_row_for_sum) {
                            if (!is_array($ccvw_unwind_row_for_sum)) continue;
                            $ccvw_unwind_total += abs((float)($ccvw_unwind_row_for_sum['amount'] ?? 0));
                        }
                        $ccvw_unwind_total = round($ccvw_unwind_total, 2);

                        if ($ccvw_own_debit_total > 0 && $ccvw_recovered > 0 && abs($ccvw_own_debit_total - $ccvw_recovered) < 0.02) {
                            $ccvw_truth['offset_rows'] = [];
                            $ccvw_truth['source_shipments'] = [];
                        }

                        // CCVW_PURE_READER_RECEIPT_MATH_V3
                        // Receipt math is cash/payable math only:
                        //   original shipment capacity
                        // - own unpaid return reversals
                        // - recovery actually applied from this shipment
                        // = paid/payable from this shipment.
                        // Unwind/reopen rows are trace history, not an extra receipt subtraction.
                        $ccvw_has_cash_rows = !empty($ccvw_truth['cash_rows']);
                        $ccvw_post_return_capacity = round(max(0.0, $ccvw_original), 2);
                        $ccvw_receipt_deduct_total = round($ccvw_recovered + $ccvw_unpaid_reversed, 2);

                        if ($ccvw_post_return_capacity > 0 || $ccvw_unpaid_reversed > 0 || $ccvw_paid > 0) {
                            $ccvw_original = round(max($ccvw_original, $ccvw_post_return_capacity + $ccvw_unpaid_reversed), 2);
                        } elseif ($ccvw_receipt_deduct_total > 0) {
                            $ccvw_original = round($ccvw_receipt_deduct_total, 2);
                        }

                        $ccvw_formula_paid = round(max(0.0, $ccvw_original - $ccvw_unpaid_reversed - $ccvw_recovered), 2);
                        if (!$ccvw_has_cash_rows) {
                            $ccvw_paid = round(max(0.0, $ccvw_post_return_capacity - $ccvw_recovered), 2);
                        } else {
                            $ccvw_paid = min(round($ccvw_paid, 2), $ccvw_formula_paid);
                        }
                        $ccvw_receipt_truth_by_shipment[$ccvw_sid]['original'] = $ccvw_original;
                        $ccvw_receipt_truth_by_shipment[$ccvw_sid]['recovered'] = $ccvw_recovered;
                        $ccvw_receipt_truth_by_shipment[$ccvw_sid]['unpaid_reversed'] = $ccvw_unpaid_reversed;
                        $ccvw_receipt_truth_by_shipment[$ccvw_sid]['unpaid_reversal_rows'] = array_values((array)($ccvw_truth['unpaid_reversal_rows'] ?? []));
                        $ccvw_receipt_truth_by_shipment[$ccvw_sid]['paid_payable'] = $ccvw_paid;
                        $ccvw_receipt_truth_by_shipment[$ccvw_sid]['unwind_total'] = $ccvw_unwind_total;
                        $ccvw_receipt_truth_by_shipment[$ccvw_sid]['own_debit_total'] = $ccvw_own_debit_total;
                        $ccvw_receipt_truth_by_shipment[$ccvw_sid]['own_debit_rows'] = array_values((array)($ccvw_truth['own_debit_rows'] ?? []));
                        $ccvw_receipt_truth_by_shipment[$ccvw_sid]['own_debit_cleared_by'] = array_values((array)($ccvw_truth['own_debit_cleared_by'] ?? []));
                        $ccvw_receipt_truth_by_shipment[$ccvw_sid]['source_shipments'] = array_values((array)($ccvw_truth['source_shipments'] ?? []));
                        $ccvw_receipt_truth_by_shipment[$ccvw_sid]['unwind_rows'] = array_values((array)($ccvw_truth['unwind_rows'] ?? []));
                        $ccvw_receipt_truth_by_shipment[$ccvw_sid]['reopened_rows'] = array_values((array)($ccvw_truth['reopened_rows'] ?? []));
                        $ccvw_receipt_truth_by_shipment[$ccvw_sid]['source_recovery_target_rows'] = array_values((array)($ccvw_truth['source_recovery_target_rows'] ?? []));
                        $ccvw_receipt_truth_by_shipment[$ccvw_sid]['trace_warnings'] = array_values((array)($ccvw_truth['trace_warnings'] ?? []));
                        unset($ccvw_receipt_truth_by_shipment[$ccvw_sid]['unpaid_reversal_seen'], $ccvw_receipt_truth_by_shipment[$ccvw_sid]['own_debit_seen'], $ccvw_receipt_truth_by_shipment[$ccvw_sid]['offset_row_seen'], $ccvw_receipt_truth_by_shipment[$ccvw_sid]['unwind_row_seen'], $ccvw_receipt_truth_by_shipment[$ccvw_sid]['reopened_row_seen'], $ccvw_receipt_truth_by_shipment[$ccvw_sid]['source_recovery_target_seen']);
                    }
                }
                ?>

                <?php if (!$rows): ?>
                    <div class="feedRow">
                        <div class="feedTop">
                            <div class="feedLeft">
                                <div class="feedH">No shipments in this view</div>
                                <div class="feedS">Delivered shipments will appear here automatically.</div>
                            </div>
                        </div>
                    </div>
                <?php else: foreach ($rows as $r):
                    $id          = (int)($r['id'] ?? 0);
                    $shipment_id  = (int)($r['shipment_id'] ?? 0);
                    $state        = strtolower((string)($r['state'] ?? 'pending'));

                    $net          = (float)($r['net'] ?? 0);
                    $gross        = (float)($r['gross'] ?? 0);
                    $commission   = (float)($r['commission'] ?? 0);
                    $courier      = (float)($r['courier_fees'] ?? 0);

                    $delivered_at  = (string)($r['delivered_at'] ?? '');
                    $pending_until = (string)($r['pending_until'] ?? '');

                    [$timing_line, $clears_at_iso, $clears_in_text, $pct] = $this->timing_pack($state, $delivered_at, $pending_until);

                   // Card deduction truth:
                    // while active seller debit exposure exists,
                    // future shipment earnings cards visibly reimburse it until exhausted.
                  $is_guilty_shipment = ($shipment_id > 0 && isset($guilty_shipment_ids[$shipment_id]));

        $historical_paid_recovery_deduct = 0.0;
        if ($state === 'paid' && isset($canonical_display_recovery_by_target_shipment[$shipment_id])) {
            // Keep paid cards on the same visible card story they had before cash-out.
            $historical_paid_recovery_deduct = max(0.0, (float)$canonical_display_recovery_by_target_shipment[$shipment_id]);
        }

        $deduct = 0.0;
        $current_visible_nonshipping_deduct = max(0.0, (float)($visible_current_nonshipping_absorb_by_target_shipment[$shipment_id] ?? 0));
        if (!$is_guilty_shipment && $shipment_id > 0 && in_array($state, ['pending','available','hold'], true) && $current_visible_nonshipping_deduct > 0) {
            // Live seller-facing absorber cards must use current open non-shipping
            // debt only. Shipping stays separate and historical lineage stays historical.
            $deduct = $current_visible_nonshipping_deduct;
        } elseif ($historical_paid_recovery_deduct > 0) {
            $deduct = $historical_paid_recovery_deduct;
        } elseif (
            !$is_guilty_shipment &&
            $shipment_id > 0 &&
            isset($canonical_display_recovery_by_target_shipment[$shipment_id])
        ) {
            $deduct = max(0.0, (float)$canonical_display_recovery_by_target_shipment[$shipment_id]);
        } elseif (
            !$is_guilty_shipment &&
            $shipment_id > 0 &&
            isset($card_recovery_by_shipment[$shipment_id])
        ) {
            $deduct = (float)$card_recovery_by_shipment[$shipment_id];
            if ($deduct < 0) $deduct = 0.0;
        }
                   // Reversed path (unpaid refund before payout):
                    // show what was removed from that shipment itself.
                    if ($state === 'reversed') {
                        $meta_raw = (string)($r['meta'] ?? '');
                        if ($meta_raw) {
                            $j = json_decode($meta_raw, true);
                            if (is_array($j) && isset($j['return_bridge']['original_net'])) {
                                $orig = (float)$j['return_bridge']['original_net'];
                                if ($orig > 0) {
                                    $deduct = max($deduct, $orig);
                                    $net = 0.0; // already reversed
                                    $r['_cc_orig_net'] = $orig;
                                }
                            }
                        }

                        $shipping_adjustment = 0.0;
                        foreach ((array) $shipping_liability_rows as $slr) {
                            if ((int) ($slr['shipment_id'] ?? 0) !== (int) $shipment_id) {
                                continue;
                            }
                            $sl_meta = json_decode((string) ($slr['meta'] ?? ''), true);
                            $sl_meta = is_array($sl_meta) ? $sl_meta : [];
                            $sl_amount = 0.0;
                            if (isset($sl_meta['return_bridge']['original_net'])) {
                                $sl_amount = (float) $sl_meta['return_bridge']['original_net'];
                            } elseif (isset($sl_meta['shipping_liability_amount'])) {
                                $sl_amount = (float) $sl_meta['shipping_liability_amount'];
                            } elseif (isset($slr['amount'])) {
                                $sl_amount = (float) $slr['amount'];
                            } elseif (isset($slr['net'])) {
                                $sl_amount = abs((float) $slr['net']);
                            }
                            if ($sl_amount > 0) {
                                $shipping_adjustment += $sl_amount;
                            }
                        }
                        if ($shipping_adjustment > 0) {
                            $shipping_adjustment = round($shipping_adjustment, 2);
                            $deduct += $shipping_adjustment;
                            $r['_cc_shipping_adjustment'] = $shipping_adjustment;
                        }

                        $seller_debit_exposure_adjustment = 0.0;
                        foreach ((array) $active_debit_rows as $adr) {
                            if ((int) ($adr['shipment_id'] ?? 0) !== (int) $shipment_id) {
                                continue;
                            }
                            $ad_meta = json_decode((string) ($adr['meta'] ?? ''), true);
                            $ad_meta = is_array($ad_meta) ? $ad_meta : [];
                            $ad_bridge = !empty($ad_meta['return_bridge']) && is_array($ad_meta['return_bridge']) ? $ad_meta['return_bridge'] : [];
                            $ad_kind = strtolower(trim((string) ($ad_bridge['kind'] ?? $ad_meta['debit_component'] ?? '')));
                            if (empty($ad_meta['seller_debit_exposure']) && $ad_kind !== 'seller_debit_exposure') {
                                continue;
                            }
                            $seller_debit_exposure_adjustment += abs((float) ($adr['net'] ?? 0));
                        }
                        if ($seller_debit_exposure_adjustment > 0) {
                            $seller_debit_exposure_adjustment = round($seller_debit_exposure_adjustment, 2);
                            $deduct += $seller_debit_exposure_adjustment;
                            $r['_cc_seller_debit_exposure_adjustment'] = $seller_debit_exposure_adjustment;
                        }
                    }

                  $amount_of_shipment = max(0.0, ($state === 'reversed' ? (float)($r['_cc_orig_net'] ?? 0) : $net));

        if ($state !== 'reversed' && $deduct > $amount_of_shipment) {
            $deduct = $amount_of_shipment;
        }

        $display_shipment_earnings = $amount_of_shipment;

        if (
            $state === 'reversed'
            && !empty($modal_map[$shipment_id]['direct_return_rows'])
            && is_array($modal_map[$shipment_id]['direct_return_rows'])
        ) {
            $display_return_sum = 0.0;

            foreach ((array)$modal_map[$shipment_id]['direct_return_rows'] as $dr) {
        if (!is_array($dr)) continue;
        if (strtolower(trim((string)($dr['kind'] ?? 'return'))) !== 'return') continue;
        $display_return_sum += (float)($dr['impact'] ?? 0);
            }

            if ($display_return_sum > 0) {
        $display_shipment_earnings = round($display_return_sum, 2);
            }
        }

        $total_to_receive   = $amount_of_shipment;
        if ($deduct > 0) {
            $total_to_receive = $amount_of_shipment - $deduct;
            if ($total_to_receive < 0) $total_to_receive = 0.0;
        }
        $ccvw_receipt_truth_applied = false;
        if ($shipment_id > 0 && !empty($ccvw_receipt_truth_by_shipment[$shipment_id]) && is_array($ccvw_receipt_truth_by_shipment[$shipment_id])) {
            $ccvw_truth = $ccvw_receipt_truth_by_shipment[$shipment_id];
            $ccvw_truth_original  = round((float)($ccvw_truth['original'] ?? 0), 2);
            $ccvw_truth_recovered = round((float)($ccvw_truth['recovered'] ?? 0), 2);
            $ccvw_truth_unpaid_reversed = round((float)($ccvw_truth['unpaid_reversed'] ?? 0), 2);
            $ccvw_truth_unwind = round((float)($ccvw_truth['unwind_total'] ?? 0), 2);
            $ccvw_truth_paid      = round((float)($ccvw_truth['paid_payable'] ?? 0), 2);
            // CCVW_SIMPLE_PATH_TRACE_SEPARATION_V1: unwind/reopen trace does not reduce payout receipt math.
            $ccvw_truth_total_deduct = round(max(0.0, $ccvw_truth_recovered + $ccvw_truth_unpaid_reversed), 2);

            if ($ccvw_truth_original > 0 && ($ccvw_truth_total_deduct > 0 || $ccvw_truth_paid > 0)) {
                $amount_of_shipment       = $ccvw_truth_original;
                $display_shipment_earnings = $ccvw_truth_original;
                $deduct                   = min($ccvw_truth_original, $ccvw_truth_total_deduct);
                $total_to_receive         = ($ccvw_truth_paid > 0) ? $ccvw_truth_paid : max(0.0, $ccvw_truth_original - $deduct);
                $ccvw_receipt_truth_applied = true;

                if (!isset($modal_map[$shipment_id]) || !is_array($modal_map[$shipment_id])) {
                    $modal_map[$shipment_id] = [];
                }
                $modal_map[$shipment_id]['receipt_truth_source'] = 'ledger_rows_by_shipment';
                $modal_map[$shipment_id]['receipt_unpaid_reversed'] = $ccvw_truth_unpaid_reversed;
                $modal_map[$shipment_id]['receipt_unpaid_reversal_rows'] = array_values((array)($ccvw_truth['unpaid_reversal_rows'] ?? []));
                $modal_map[$shipment_id]['receipt_recovery_only'] = $ccvw_truth_recovered;
                $modal_map[$shipment_id]['receipt_offset_rows'] = array_values((array)($ccvw_truth['offset_rows'] ?? []));
                $modal_map[$shipment_id]['receipt_cash_rows'] = array_values((array)($ccvw_truth['cash_rows'] ?? []));
                $modal_map[$shipment_id]['receipt_final_payable'] = $ccvw_truth_paid;
                $modal_map[$shipment_id]['receipt_source_recovery_target_rows'] = array_values((array)($ccvw_truth['source_recovery_target_rows'] ?? []));
                $modal_map[$shipment_id]['receipt_own_debit_total'] = (float)($ccvw_truth['own_debit_total'] ?? 0);
                $modal_map[$shipment_id]['receipt_own_debit_rows'] = array_values((array)($ccvw_truth['own_debit_rows'] ?? []));
                $modal_map[$shipment_id]['receipt_own_debit_cleared_by'] = array_values(array_map('intval', (array)($ccvw_truth['own_debit_cleared_by'] ?? [])));
                $modal_map[$shipment_id]['receipt_unwind_rows'] = array_values((array)($ccvw_truth['unwind_rows'] ?? []));
                $modal_map[$shipment_id]['receipt_reopened_rows'] = array_values((array)($ccvw_truth['reopened_rows'] ?? []));
                $modal_map[$shipment_id]['receipt_trace_warnings'] = array_values((array)($ccvw_truth['trace_warnings'] ?? []));
                if (!empty($ccvw_truth['source_shipments'])) {
                    $modal_map[$shipment_id]['adjustment_source_shipment_ids'] = array_values(array_map('intval', (array)$ccvw_truth['source_shipments']));
                    $modal_map[$shipment_id]['adjustment_source_shipment_id'] = (int)reset($modal_map[$shipment_id]['adjustment_source_shipment_ids']);
                }
            }
        }
        $story_snapshot = [];
        if ($shipment_id > 0) {
            if (!isset($modal_map[$shipment_id]) || !is_array($modal_map[$shipment_id])) {
        $modal_map[$shipment_id] = [];
            }

            $modal_map[$shipment_id]['shipment_earnings']  = (float)$display_shipment_earnings;
            $modal_map[$shipment_id]['shipment_deduction'] = (float)$deduct;
            $modal_map[$shipment_id]['shipment_remaining'] = (float)$total_to_receive;

            if ($state === 'reversed') {
        $modal_map[$shipment_id]['card_modal_type'] = 'reversed';
            } elseif (!$is_guilty_shipment && $deduct > 0) {
        $modal_map[$shipment_id]['card_modal_type'] = 'recovery';
            } else {
        $modal_map[$shipment_id]['card_modal_type'] = 'normal';
            }

            $modal_map[$shipment_id]['source_lineage_bound'] = round(max(0.0, (float)($modal_map[$shipment_id]['open_source_liability_amount'] ?? 0), (float)(($modal_map[$shipment_id]['debug_chain_role']['active_source_amount'] ?? 0))), 2);

            $story_snapshot = (array)($card_story_snapshot_by_shipment[$shipment_id] ?? []);
            if ($state === 'paid' && !empty($story_snapshot) && empty($ccvw_receipt_truth_applied)) {
        foreach ([
            'card_modal_type',
            'deduct_explain',
            'direct_return_rows',
            'has_return_breakdown',
            'has_direct_return_breakdown',
            'adjustment_source_shipment_id',
            'adjustment_source_shipment_ids',
            'affected_recovery_shipments',
            'open_source_liability_amount',
            'source_lineage_bound',
            'card_recovery_deduct',
            'live_recovery_sources',
        ] as $frozenKey) {
            if (array_key_exists($frozenKey, $story_snapshot)) {
                $modal_map[$shipment_id][$frozenKey] = $story_snapshot[$frozenKey];
            }
        }

        $display_shipment_earnings = round((float)($story_snapshot['shipment_earnings'] ?? $display_shipment_earnings), 2);
        $deduct                   = round((float)($story_snapshot['shipment_deduction'] ?? $deduct), 2);
        $total_to_receive         = round((float)($story_snapshot['shipment_remaining'] ?? $total_to_receive), 2);
        $amount_of_shipment       = $display_shipment_earnings;

        $modal_map[$shipment_id]['shipment_earnings']  = $display_shipment_earnings;
        $modal_map[$shipment_id]['shipment_deduction'] = $deduct;
        $modal_map[$shipment_id]['shipment_remaining'] = $total_to_receive;
            }
        }

                ?>
                    <div class="feedRow"
                         data-state="<?php echo esc_attr($state); ?>"
                         data-clears-at="<?php echo esc_attr($clears_at_iso); ?>"
                         data-ledger="<?php echo esc_attr((string)$id); ?>"
                         data-shipment="<?php echo esc_attr((string)$shipment_id); ?>">
                        <div class="feedTop">
                            <div class="feedLeft">
                                <div class="feedH"><span class="ship-pill">Shipment #<?php echo esc_html((string)$shipment_id); ?></span></div>
                                <div class="feedS">
                                    <?php echo esc_html($timing_line); ?>
                                    <?php if ($state === 'pending'): ?>
                                        <span style="font-weight:900;color:#2b3a55"> • <span class="cc-clears-in"><?php echo esc_html($clears_in_text); ?></span></span>
                                    <?php endif; ?>
                                </div>

                                <?php if ($state === 'pending'): ?>
                                    <div class="prog"><i style="width:<?php echo esc_attr((string)$pct); ?>%"></i></div>
                                    <div class="metaRow">Clears at <code><?php echo esc_html($pending_until ?: '—'); ?></code></div>
                                <?php endif; ?>
              
              
              
                          </div>
                          
                          
                          
        <div class="feedRight">
            
            <?php
            $summary_detail_rows = [];
            if (!empty($modal_map[$shipment_id]['direct_return_rows']) && is_array($modal_map[$shipment_id]['direct_return_rows'])) {
        $summary_detail_rows = (array) $modal_map[$shipment_id]['direct_return_rows'];
            } elseif (!empty($modal_map[$shipment_id]['deduct_explain']) && is_array($modal_map[$shipment_id]['deduct_explain'])) {
        $summary_detail_rows = (array) $modal_map[$shipment_id]['deduct_explain'];
            }

          $shipment_return_adjust_summary = 0.0;
            $shipping_fee_adjust_summary = 0.0;
            $seller_debit_exposure_adjust_summary = 0.0;

            foreach ($summary_detail_rows as $sr) {
        if (!is_array($sr)) continue;
        $kind   = strtolower(trim((string) ($sr['kind'] ?? '')));
        $impact = abs((float) ($sr['impact'] ?? 0));

        if (in_array($kind, ['return','returnless','never_received','return_pending'], true)) {
            $shipment_return_adjust_summary += $impact;
        } elseif ($kind === 'shipping') {
            $shipping_fee_adjust_summary += $impact;
        } elseif ($kind === 'seller_debit_exposure') {
            $seller_debit_exposure_adjust_summary += $impact;
        }
            }

            $display_return_adjustment = $deduct;
            $display_net_after_adjustments = $total_to_receive;

            if ($state === 'reversed' && !empty($summary_detail_rows)) {
        if ($shipment_return_adjust_summary > 0) {
            $display_return_adjustment = round($shipment_return_adjust_summary, 2);
        }

        $display_net_after_adjustments = max(
            0.0,
            (float)$display_shipment_earnings
            - (float)$display_return_adjustment
            - (float)$shipping_fee_adjust_summary
            - (float)$seller_debit_exposure_adjust_summary
        );
            }

            if ($state === 'paid' && !empty($story_snapshot) && empty($ccvw_receipt_truth_applied)) {
        $display_return_adjustment = round((float)($story_snapshot['display_return_adjustment'] ?? $display_return_adjustment), 2);
        $display_net_after_adjustments = round((float)($story_snapshot['display_net_after_adjustments'] ?? $display_net_after_adjustments), 2);
            }

            if ($shipment_id > 0) {
        $modal_map[$shipment_id]['display_return_adjustment'] = round((float)$display_return_adjustment, 2);
        $modal_map[$shipment_id]['display_net_after_adjustments'] = round((float)$display_net_after_adjustments, 2);
        $modal_map[$shipment_id]['display_shipping_fee_adjustment'] = round((float)$shipping_fee_adjust_summary, 2);
        $modal_map[$shipment_id]['display_seller_debit_exposure_adjustment'] = round((float)$seller_debit_exposure_adjust_summary, 2);
            }

            if ($shipment_id > 0 && in_array($state, ['pending','available','hold','reversed'], true)) {
        $persist_card_story_snapshot($shipment_id, [
            'card_modal_type'                => (string)($modal_map[$shipment_id]['card_modal_type'] ?? 'normal'),
            'shipment_earnings'              => round((float)$display_shipment_earnings, 2),
            'shipment_deduction'             => round((float)$deduct, 2),
            'shipment_remaining'             => round((float)$total_to_receive, 2),
            'display_return_adjustment'      => round((float)$display_return_adjustment, 2),
            'display_net_after_adjustments'  => round((float)$display_net_after_adjustments, 2),
            'deduct_explain'                 => array_values((array)($modal_map[$shipment_id]['deduct_explain'] ?? [])),
            'direct_return_rows'             => array_values((array)($modal_map[$shipment_id]['direct_return_rows'] ?? [])),
            'has_return_breakdown'           => !empty($modal_map[$shipment_id]['has_return_breakdown']),
            'has_direct_return_breakdown'    => !empty($modal_map[$shipment_id]['has_direct_return_breakdown']),
            'adjustment_source_shipment_id'  => (int)($modal_map[$shipment_id]['adjustment_source_shipment_id'] ?? 0),
            'adjustment_source_shipment_ids' => array_values(array_map('intval', (array)($modal_map[$shipment_id]['adjustment_source_shipment_ids'] ?? []))),
            'affected_recovery_shipments'    => array_values((array)($modal_map[$shipment_id]['affected_recovery_shipments'] ?? [])),
            'open_source_liability_amount'   => round((float)($modal_map[$shipment_id]['open_source_liability_amount'] ?? 0), 2),
            'source_lineage_bound'           => round((float)($modal_map[$shipment_id]['source_lineage_bound'] ?? 0), 2),
            'card_recovery_deduct'           => round((float)($modal_map[$shipment_id]['card_recovery_deduct'] ?? 0), 2),
            'live_recovery_sources'          => (array)($modal_map[$shipment_id]['live_recovery_sources'] ?? []),
        ]);
            }

        $card_modal_type_for_label = strtolower(trim((string)($modal_map[$shipment_id]['card_modal_type'] ?? 'normal')));
        $has_prior_recovery_on_card = (
            $state !== 'reversed'
            && (
                $card_modal_type_for_label === 'recovery'
                || !empty($modal_map[$shipment_id]['adjustment_source_shipment_ids'])
                || ((float)($modal_map[$shipment_id]['receipt_recovery_only'] ?? 0)) > 0
                || ((float)($modal_map[$shipment_id]['card_recovery_deduct'] ?? 0)) > 0
            )
        );
        $card_total_deduct_abs = round(abs((float)$deduct), 2);
        $card_return_removed_abs = round(max(0.0, (float)($modal_map[$shipment_id]['receipt_unpaid_reversed'] ?? 0)), 2);
        if ($card_total_deduct_abs > 0 && $card_return_removed_abs > $card_total_deduct_abs) {
            $card_return_removed_abs = $card_total_deduct_abs;
        }
        $card_recovery_applied_abs = round(max(0.0, (float)($modal_map[$shipment_id]['receipt_recovery_only'] ?? 0)), 2);
        if ($card_total_deduct_abs > 0) {
            $card_remaining_deduct_after_returns = round(max(0.0, $card_total_deduct_abs - $card_return_removed_abs), 2);
            if ($card_recovery_applied_abs <= 0.004 || $card_recovery_applied_abs > $card_remaining_deduct_after_returns + 0.01) {
                $card_recovery_applied_abs = $card_remaining_deduct_after_returns;
            }
        }
        $card_has_split_adjustments = ($state !== 'reversed' && $card_return_removed_abs > 0.004 && $card_recovery_applied_abs > 0.004);
        $card_adjustment_label = $has_prior_recovery_on_card ? 'Recovery applied' : 'Return adjustment';
        $card_remaining_label  = $card_has_split_adjustments ? 'Payable after adjustments' : ($has_prior_recovery_on_card ? 'Payable after recovery' : 'New shipment earnings');
        ?>
            
            
            <span class="badge <?php echo esc_attr($state); ?>"><?php echo esc_html(ucfirst($state)); ?></span>

            <div class="payStack" aria-label="payout breakdown">

        <div class="payLine dim">Shipment earnings</div>
        <div class="payLine"><?php echo esc_html(number_format($display_shipment_earnings,2)); ?> GYD</div>

        <?php if ($state === 'reversed'): ?>
            <?php $card_return_adjustment_abs = round(abs((float)$display_return_adjustment), 2); ?>
            <?php if ($card_return_adjustment_abs > 0): ?>
                <div class="payLine dim" style="margin-top:4px">Return adjustment</div>
                <div class="payLine neg">−<?php echo esc_html(number_format($card_return_adjustment_abs,2)); ?> GYD</div>
            <?php else: ?>
                <div class="payLine dim" style="margin-top:4px">No payout reversal</div>
                <div class="payLine"><?php echo esc_html(number_format(0,2)); ?> GYD</div>
            <?php endif; ?>

            <?php if (!empty($modal_map[$shipment_id]['has_direct_return_breakdown'])): ?>
                <div class="payLine dim" style="font-size:12px;line-height:1.2;opacity:.9">
                    <a href="#" class="ccp2Why" data-shipment="<?php echo esc_attr((string)$shipment_id); ?>">
                        Returns Breakdown
                    </a>
                </div>
            <?php endif; ?>

            <div class="payLine dim" style="margin-top:4px">
            <a href="#" class="ccp2EarningsWhy" data-shipment="<?php echo esc_attr((string)$shipment_id); ?>" style="color:inherit;text-decoration:underline;font-weight:inherit;">
        Net after adjustments
            </a>
        </div>
        <div class="payLine total">
            <a href="#" class="ccp2EarningsWhy" data-shipment="<?php echo esc_attr((string)$shipment_id); ?>" style="color:inherit;text-decoration:none;font-weight:inherit;">
               <?php echo esc_html(number_format($display_net_after_adjustments,2)); ?> GYD
            </a>
        </div>

           <?php elseif ($deduct > 0): ?>
            <?php if ($card_has_split_adjustments): ?>
                <div class="payLine dim" style="margin-top:4px">Returns removed before payout</div>
                <div class="payLine neg">−<?php echo esc_html(number_format($card_return_removed_abs,2)); ?> GYD</div>
                <div class="payLine dim" style="margin-top:4px">Recovery applied</div>
                <div class="payLine neg">−<?php echo esc_html(number_format($card_recovery_applied_abs,2)); ?> GYD</div>
            <?php else: ?>
                <div class="payLine dim" style="margin-top:4px"><?php echo esc_html($card_adjustment_label); ?></div>
                <div class="payLine neg">−<?php echo esc_html(number_format($deduct,2)); ?> GYD</div>
            <?php endif; ?>
            <div class="payLine dim" style="margin-top:4px">
                <a href="#" class="ccp2EarningsWhy" data-shipment="<?php echo esc_attr((string)$shipment_id); ?>" style="color:inherit;text-decoration:underline;font-weight:inherit;">
                    <?php echo esc_html($card_remaining_label); ?>
                </a>
            </div>
            <div class="payLine total">
                <a href="#" class="ccp2EarningsWhy" data-shipment="<?php echo esc_attr((string)$shipment_id); ?>" style="color:inherit;text-decoration:none;font-weight:inherit;">
                    <?php echo esc_html(number_format($total_to_receive,2)); ?> GYD
                </a>
            </div>

        <?php elseif (!empty($modal_map[$shipment_id]['has_direct_return_breakdown'])): ?>
            <div class="payLine dim" style="font-size:12px;line-height:1.2;opacity:.9;margin-top:4px">
                <a href="#" class="ccp2Why" data-shipment="<?php echo esc_attr((string)$shipment_id); ?>">
                    Returns Breakdown
                </a>
            </div>

            <div class="payLine dim" style="margin-top:4px">Total to receive</div>
            <div class="payLine total"><?php echo esc_html(number_format($total_to_receive,2)); ?> GYD</div>

        <?php else: ?>

            <div class="payLine dim" style="margin-top:4px">Total to receive</div>
            <div class="payLine total"><?php echo esc_html(number_format($total_to_receive,2)); ?> GYD</div>

        <?php endif; ?>

            </div>
        </div>
                        </div>

                        <div class="metaRow" style="display:none">
                            Item value <?php echo esc_html(number_format($gross,2)); ?> • fee −<?php echo esc_html(number_format($commission,2)); ?> • delivery −<?php echo esc_html(number_format($courier,2)); ?>
                        </div>
                    </div>
              <?php endforeach; endif; ?>
            </div>

            <?php $modal_blocks = array_values($modal_map); ?>

            <!-- Shipment Details Modal -->
            <div class="modalBack" id="ccspModalBack" role="dialog" aria-modal="true" aria-hidden="true">
                <div class="modal">
                    <div class="modalHd">
                        <div class="t" id="ccspModalTitle">Shipment</div>
                        <button class="x" type="button" id="ccspModalClose">✕</button>
                    </div>
                    <div class="modalBd" id="ccspModalBody"></div>
                </div>
            </div>

            <!-- Instant Cash-out Modal -->
            <div class="modalBack" id="ccp2InstantBack" role="dialog" aria-modal="true" aria-hidden="true">
                <div class="modal">
                    <div class="modalHd">
                        <div class="t">Cash-out</div>
                        <button class="x" type="button" id="ccp2InstantClose">✕</button>
                    </div>
                    <div class="modalBd">
                        <div class="grid2">
                            <div class="card">
                                <div class="lk">Residual withdrawable</div>
                                <div class="lv" id="ccp2AvailTxt"></div>
                            </div>
                            <div class="card">
                                <div class="lk">You receive</div>
                                <div class="lv" id="ccp2NetTxt"></div>
                            </div>
                        </div>

                       <div class="card" style="margin-top:10px">
            <div class="lk">Destination</div>
            <div class="lv"><?php echo esc_html($dest_display ?: 'Not set'); ?></div>
        </div>

                        <div class="smallNote" id="ccp2InstantNote" style="margin-top:10px">
                            Hold to send a request for admin approval.
                        </div>

                        <button class="pill holdBtn" type="button" id="ccp2HoldConfirm" style="width:100%;justify-content:center;margin-top:10px">
                            Hold to confirm (1s)
                        </button>
                    </div>
                </div>
            </div>

            <script>
                (function(){
                    const $ = (s)=>document.querySelector(s);

                    /* ----------------- Method drawer ----------------- */
                    const drawer = $('#ccp2-drawer');
                    const change = $('#ccp2-change');
                    const cancel = $('#ccp2-cancel');
                    const save = $('#ccp2-save');
                    const msg = $('#ccp2-msg');
                    const method = $('#ccp2-method');

                    function setBlocks(){
                        const v = method.value;
                        drawer.querySelector('[data-block="gtt"]').style.display = (v==='gtt') ? '' : 'none';
                        drawer.querySelector('[data-block="bank"]').style.display = (v==='bank') ? '' : 'none';
                    }

                    if(change) change.addEventListener('click', (e)=>{ e.preventDefault(); drawer.classList.add('show'); setBlocks(); msg.textContent=''; });
                    if(cancel) cancel.addEventListener('click', ()=>{ drawer.classList.remove('show'); msg.textContent=''; });
                    if(method) method.addEventListener('change', ()=>{ setBlocks(); msg.textContent=''; });

                    if(save){
                        save.addEventListener('click', async ()=>{
                            save.disabled = true;
                            msg.textContent = 'Saving…';

                            const v = method.value;
                            const gtt = $('#ccp2-gtt').value.trim();
                            const bank = $('#ccp2-bank') ? $('#ccp2-bank').value.trim() : '';
                            const holder = $('#ccp2-holder') ? $('#ccp2-holder').value.trim() : '';
                            const acct = $('#ccp2-acct') ? $('#ccp2-acct').value.trim() : '';

                            if (v === 'gtt' && !gtt){ msg.textContent = 'Enter mobile money number.'; save.disabled = false; return; }
                            if (v === 'bank' && (!bank || !holder || !acct)){ msg.textContent = 'Fill bank name, account holder, and account number.'; save.disabled = false; return; }

                            const fd = new FormData();
                            fd.append('action','cc_sp_save_payout_method_v2');
                            fd.append('nonce','<?php echo esc_js($nonce_method); ?>');
                            fd.append('method', v);
                            fd.append('gtt_phone', gtt);
                            fd.append('bank_name', bank);
                            fd.append('bank_holder', holder);
                            fd.append('bank_acct', acct);

                            try{
                                const res = await fetch('<?php echo esc_js(admin_url('admin-ajax.php')); ?>', {method:'POST', credentials:'same-origin', body: fd});
                                const json = await res.json();
                                if(json && json.success){ msg.textContent = 'Saved.'; setTimeout(()=>location.reload(), 350); }
                                else { msg.textContent = (json?.data?.message || 'Could not save.'); }
                            }catch(e){ msg.textContent = 'Network error.'; }
                            finally{ save.disabled = false; }
                        });
                    }

                    /* ----------------- Live countdown ----------------- */
                    function fmt(ms){
                        if (ms <= 0) return 'clearing now';
                        const s = Math.floor(ms/1000);
                        const d = Math.floor(s/86400);
                        const h = Math.floor((s%86400)/3600);
                        const m = Math.floor((s%3600)/60);
                        if (d>0) return `${d}d ${h}h ${m}m`;
                        if (h>0) return `${h}h ${m}m`;
                        return `${m}m`;
                    }
                    function tick(){
                        document.querySelectorAll('.feedRow[data-state="pending"][data-clears-at]').forEach((row)=>{
                            const iso = row.getAttribute('data-clears-at');
                            if(!iso) return;
                            const end = Date.parse(iso);
                            if(!end) return;
                            const left = end - Date.now();
                            const span = row.querySelector('.cc-clears-in');
                            if(span) span.textContent = fmt(left);
                        });
                    }
                    tick();
                    setInterval(tick, 30000);

                    /* ----------------- Shipment modal ----------------- */
                    const shipBack = $('#ccspModalBack');
                    const shipClose = $('#ccspModalClose');
                    const shipTitle = $('#ccspModalTitle');
                    const shipBody = $('#ccspModalBody');

                    function openShip(html, ttl){
                        shipTitle.textContent = ttl || 'Shipment';
                        shipBody.innerHTML = html;
                        shipBack.classList.add('show');
                        shipBack.setAttribute('aria-hidden','false');
                        document.body.style.overflow = 'hidden';
                    }
                    function closeShip(){
                        shipBack.classList.remove('show');
                        shipBack.setAttribute('aria-hidden','true');
                        document.body.style.overflow = '';
                    }
                    if(shipClose) shipClose.addEventListener('click', closeShip);
                    if(shipBack) shipBack.addEventListener('click', (e)=>{ if(e.target === shipBack) closeShip(); });

                    const blocks = <?php echo wp_json_encode($modal_blocks); ?>;

                    function findBlockByShipment(shipmentId){
                        shipmentId = parseInt(shipmentId, 10);
                        return blocks.find(b => parseInt(b.shipment_id,10) === shipmentId);
                    }
                    function esc(s){
                        return String(s ?? '').replace(/[&<>"']/g, (m)=>({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;' }[m]));
                    }

                                        function fmtMoney(v){
                        v = Number(v || 0);
                        if(!isFinite(v)) v = 0;
                        return v.toLocaleString(undefined, {minimumFractionDigits:2, maximumFractionDigits:2});
                    }
                    function num(v){
                        v = parseFloat(String(v === undefined || v === null || v === '' ? 0 : v).replace(/,/g,''));
                        return isFinite(v) ? Math.round(v * 100) / 100 : 0;
                    }
                    function ccwvStableKeyPart(v){
                        return String(v === undefined || v === null ? '' : v).trim();
                    }
                    function ccwvAmountKey(v){
                        return fmtMoney(num(v || 0));
                    }
                    function ccwvDedupeRows(rows, keyFn){
                        rows = Array.isArray(rows) ? rows : [];
                        const seen = {};
                        const out = [];
                        rows.forEach((r, idx) => {
                            const k = String(keyFn ? keyFn(r, idx) : JSON.stringify(r || {}));
                            if(!k || seen[k]) return;
                            seen[k] = true;
                            out.push(r);
                        });
                        return out;
                    }
                    function hasOwn(obj, key){
                        return !!obj && Object.prototype.hasOwnProperty.call(obj, key) && obj[key] !== undefined && obj[key] !== null && obj[key] !== '';
                    }
                    function firstNum(obj, keys, fallback){
                        keys = Array.isArray(keys) ? keys : [keys];
                        for(const key of keys){
                            if(hasOwn(obj, key)) return num(obj[key]);
                        }
                        return num(fallback || 0);
                    }
                    function curFromRows(rows, fallback){
                        return esc((rows && rows[0] && rows[0].currency) ? rows[0].currency : (fallback || 'GYD'));
                    }
                    function classifyReturnRows(rows){
                        rows = Array.isArray(rows) ? rows : [];
                        const returnKinds = ['return','returnless','never_received','return_pending'];
                        return {
                            returns: rows.filter(r => returnKinds.includes(String(r.kind || 'return').toLowerCase())),
                            shipping: rows.filter(r => String(r.kind || '').toLowerCase() === 'shipping'),
                            exposure: rows.filter(r => String(r.kind || '').toLowerCase() === 'seller_debit_exposure'),
                            other: rows.filter(r => !returnKinds.concat(['shipping','seller_debit_exposure']).includes(String(r.kind || '').toLowerCase()))
                        };
                    }
                    function rowsTotal(rows){
                        return (Array.isArray(rows) ? rows : []).reduce((sum, r) => sum + num(r.impact || r.amount || 0), 0);
                    }
                    function sourceShipmentText(b){
                        const ids = Array.isArray(b.adjustment_source_shipment_ids)
                            ? b.adjustment_source_shipment_ids.map(v => parseInt(v || 0,10)).filter(v => v > 0)
                            : [];
                        if(ids.length) return ids.map(v => '#'+v).join(', ');
                        const one = parseInt(b.adjustment_source_shipment_id || 0,10);
                        return one > 0 ? '#'+one : '—';
                    }
                    function recoveredShipments(b){
                        const out = {};
                        const add = (sid, amt, mode) => {
                            sid = parseInt(sid || 0, 10);
                            amt = num(amt || 0);
                            if(sid <= 0 || amt <= 0) return;
                            if(mode === 'sum') out[sid] = num((out[sid] || 0) + amt);
                            else out[sid] = Math.max(out[sid] || 0, amt);
                        };

                        // Authoritative source-side recovery edges mirrored from receipt_offset_rows.
                        // These are what the source shipment's Return Balance modal must show.
                        const sourceTargets = Array.isArray(b.receipt_source_recovery_target_rows) ? b.receipt_source_recovery_target_rows : [];
                        if(sourceTargets.length){
                            sourceTargets.forEach(r => add((r && r.target_shipment_id) || 0, (r && r.amount) || 0, 'sum'));
                            return Object.keys(out).map(k => ({shipment_id: parseInt(k,10), amount: out[k]})).sort((a,b)=>a.shipment_id-b.shipment_id);
                        }

                        // Fallback: row-level cleared-by edges on debit rows.
                        const ownRows = Array.isArray(b.receipt_own_debit_rows) ? b.receipt_own_debit_rows : [];
                        ownRows.forEach(row => {
                            const edges = Array.isArray(row && row.cleared_by_edges) ? row.cleared_by_edges : [];
                            if(edges.length){
                                edges.forEach(edge => add((edge && edge.target_shipment_id) || 0, (edge && edge.amount) || 0, 'sum'));
                            }
                        });
                        if(Object.keys(out).length){
                            return Object.keys(out).map(k => ({shipment_id: parseInt(k,10), amount: out[k]})).sort((a,b)=>a.shipment_id-b.shipment_id);
                        }

                        if (Array.isArray(b.affected_recovery_shipments)) {
                            b.affected_recovery_shipments.forEach(r => {
                                add((r && r.shipment_id) || 0, (r && (r.amount || r.current_amount)) || 0, 'max');
                            });
                        }
                        const live = (b.live_recovery_sources && typeof b.live_recovery_sources === 'object') ? b.live_recovery_sources : {};
                        Object.keys(live).forEach(k => add(k, live[k] || 0, 'max'));
                        return Object.keys(out).map(k => ({shipment_id: parseInt(k,10), amount: out[k]})).sort((a,b)=>a.shipment_id-b.shipment_id);
                    }
                    function blockDetailRows(b){
                        const rows = (b && Array.isArray(b.direct_return_rows) && b.direct_return_rows.length) ? b.direct_return_rows : ((b && Array.isArray(b.deduct_explain) && b.deduct_explain.length) ? b.deduct_explain : []);
                        return ccwvDedupeRows(rows, r => [ccwvStableKeyPart(r && r.kind), ccwvStableKeyPart(r && r.case_id), ccwvStableKeyPart(r && r.slice_id), ccwvStableKeyPart(r && r.name), ccwvAmountKey((r && (r.impact || r.amount)) || 0)].join('|'));
                    }
                    function rowKindIcon(kind){
                        kind = String(kind || '').toLowerCase();
                        if(kind === 'return') return '↩';
                        if(kind === 'returnless') return '✨';
                        if(kind === 'never_received') return '📦';
                        if(kind === 'return_pending') return '⏳';
                        if(kind === 'shipping') return '🚚';
                        if(kind === 'seller_debit_exposure') return '➕';
                        return '•';
                    }
                    function rowKindTitle(r){
                        const kind = String((r && r.kind) || 'return').toLowerCase();
                        const name = String((r && r.name) || '').trim();
                        if(kind === 'return') return name ? 'Returned & received — ' + name : 'Returned & received';
                        if(kind === 'returnless') return name ? 'Returnless refund — ' + name : 'Returnless refund';
                        if(kind === 'never_received') return name ? 'Never arrived — ' + name : 'Never arrived';
                        if(kind === 'return_pending') return name ? 'Return pending — ' + name : 'Return pending';
                        if(kind === 'shipping') return name ? 'Shipping fee — ' + name : 'Shipping fee';
                        if(kind === 'seller_debit_exposure') return name ? 'Seller debit exposure — ' + name : 'Seller debit exposure';
                        return name || 'Adjustment';
                    }
                    function wholeQtyPlain(raw){
                        const qty = parseFloat(raw || 0);
                        if(!isFinite(qty) || qty <= 0) return '';
                        const rounded = Math.round(qty);
                        if(Math.abs(qty - rounded) > 0.001) return '';
                        return String(rounded);
                    }
                    function wholeQtyText(raw){
                        const q = wholeQtyPlain(raw);
                        return q ? ('Qty ' + q + '. ') : '';
                    }
                    function rowKindNote(r, shipmentId){
                        const kind = String((r && r.kind) || '').toLowerCase();
                        const qtyText = wholeQtyText(r && r.qty);
                        if(kind === 'return') return qtyText + 'Item was physically returned and received for Shipment #' + shipmentId + '.';
                        if(kind === 'returnless') return qtyText + 'Refund was issued with no item return required for Shipment #' + shipmentId + '.';
                        if(kind === 'never_received') return qtyText + 'Customer never received this item; no seller-facing return pickup is counted for Shipment #' + shipmentId + '.';
                        if(kind === 'return_pending') return qtyText + 'Return was required, but receipt is not confirmed yet for Shipment #' + shipmentId + '.';
                        if(kind === 'shipping') return 'Shipping responsibility tied to Shipment #' + shipmentId + '.';
                        if(kind === 'seller_debit_exposure') return 'Additional seller-side debit exposure on Shipment #' + shipmentId + '.';
                        return 'Historical ledger adjustment on Shipment #' + shipmentId + '.';
                    }
                    function sourceLedgerDebitRows(sourceBlock){
                        const rows = (sourceBlock && Array.isArray(sourceBlock.receipt_own_debit_rows)) ? sourceBlock.receipt_own_debit_rows : [];
                        return ccwvDedupeRows(rows, r => [ccwvStableKeyPart(r && r.kind), ccwvStableKeyPart(r && r.ledger_row_id), ccwvStableKeyPart(r && r.case_id), ccwvStableKeyPart(r && r.slice_id), ccwvStableKeyPart(r && r.order_item_id), ccwvAmountKey((r && (r.source_amount_original || r.amount)) || 0)].join('|'));
                    }
                    function sourceDebitOriginalTotal(rows){
                        rows = Array.isArray(rows) ? rows : [];
                        return rows.reduce((a, r) => a + firstNum(r, ['source_amount_original', 'amount'], 0), 0);
                    }
                    function sourceDebitRecoveredTotal(rows){
                        rows = Array.isArray(rows) ? rows : [];
                        return rows.reduce((a, r) => a + firstNum(r, ['source_amount_still_recovered', 'recovered_amount'], 0), 0);
                    }
                    function sourceDebitOpenTotal(rows){
                        rows = Array.isArray(rows) ? rows : [];
                        return rows.reduce((a, r) => a + firstNum(r, ['source_amount_currently_open', 'current_open_amount', 'remaining_amount'], 0), 0);
                    }
                    function matchSourceDebitRowInfo(edge, debitRows){
                        debitRows = Array.isArray(debitRows) ? debitRows : [];
                        if(!edge || !debitRows.length) return {row:null, mode:''};
                        const debitId = parseInt(edge.debit_row_id || edge.source_debit_row_id || 0, 10);
                        const itemId = parseInt(edge.source_order_item_id || 0, 10);
                        const sliceId = String(edge.source_slice_id || '').trim();

                        // Prefer precise identity first. Legacy rows can reuse a debit row id for multiple slices;
                        // matching row-id first is what produced confusing duplicated item names.
                        if(sliceId){
                            const bySlice = debitRows.find(r => String((r && r.slice_id) || '').trim() === sliceId);
                            if(bySlice) return {row:bySlice, mode:'slice_id'};
                        }
                        if(itemId > 0){
                            const byItem = debitRows.find(r => parseInt((r && r.order_item_id) || 0, 10) === itemId);
                            if(byItem) return {row:byItem, mode:'order_item_id'};
                        }
                        if(debitId > 0){
                            const byId = debitRows.find(r => parseInt((r && r.ledger_row_id) || 0, 10) === debitId);
                            if(byId) return {row:byId, mode:'row_id'};
                        }
                        return {row:null, mode:''};
                    }
                    function matchSourceDebitRow(edge, debitRows){
                        const info = matchSourceDebitRowInfo(edge, debitRows);
                        return info ? info.row : null;
                    }
                    function readableSourceLineTitle(match, edge, applied, original, matchMode){
                        const name = String((match && match.name) || '').trim();
                        const kind = String((match && match.kind) || '').toLowerCase();
                        const rowId = parseInt((edge && (edge.debit_row_id || edge.source_debit_row_id)) || (match && match.ledger_row_id) || 0, 10);
                        const itemId = parseInt((edge && edge.source_order_item_id) || 0, 10);
                        const exactAmount = Math.abs(num(applied) - num(original)) < 0.02;
                        const precise = (matchMode === 'slice_id' || matchMode === 'order_item_id' || (matchMode === 'row_id' && exactAmount));
                        if(kind === 'shipping') return 'Shipping fee cleared';
                        if(name && precise) return 'Cleared source debit — ' + name;
                        if(itemId > 0 && !name) return 'Cleared source debit — item #' + itemId;
                        if(rowId > 0) return exactAmount ? ('Cleared source debit row #' + rowId) : ('Cleared part of source debit row #' + rowId);
                        if(name) return 'Cleared source debit — ' + name;
                        return 'Cleared source debit';
                    }
                    function buildAppliedSourceRows(rawRows, sourceBlock, fallbackCur){
                        rawRows = Array.isArray(rawRows) ? rawRows : [];
                        const debitRows = sourceLedgerDebitRows(sourceBlock);
                        return rawRows.map(edge => {
                            const matchInfo = matchSourceDebitRowInfo(edge, debitRows);
                            const match = matchInfo ? matchInfo.row : null;
                            const matchMode = matchInfo ? matchInfo.mode : '';
                            const applied = num((edge && edge.amount) || 0);
                            const original = match ? firstNum(match, ['source_amount_original', 'amount'], 0) : applied;
                            const recovered = match ? firstNum(match, ['source_amount_still_recovered', 'recovered_amount'], 0) : applied;
                            const remaining = match ? firstNum(match, ['source_amount_currently_open', 'current_open_amount', 'remaining_amount'], 0) : 0;
                            return {
                                title: readableSourceLineTitle(match, edge, applied, original, matchMode),
                                kind: String((match && match.kind) || '').toLowerCase(),
                                name: String((match && match.name) || '').trim(),
                                match_mode: matchMode,
                                applied_amount: applied,
                                original_amount: original,
                                recovered_amount: recovered,
                                remaining_amount: remaining,
                                currency: (match && match.currency) || (edge && edge.currency) || fallbackCur || 'GYD',
                                source_debit_row_id: parseInt((edge && (edge.debit_row_id || edge.source_debit_row_id)) || (match && match.ledger_row_id) || 0, 10),
                                source_order_item_id: parseInt((edge && edge.source_order_item_id) || (match && match.order_item_id) || 0, 10),
                                source_slice_id: String((edge && edge.source_slice_id) || (match && match.slice_id) || ''),
                                reference: String((edge && edge.reference) || '')
                            };
                        }).filter(r => num(r.applied_amount) > 0);
                    }
                    function recoveryAllocationEntries(b){
                        const grouped = {};
                        const ensure = (sid) => {
                            if(!grouped[sid]) grouped[sid] = { shipment_id: sid, amount: 0, raw_rows: [] };
                            return grouped[sid];
                        };

                        const cleanOffsetRows = Array.isArray(b.receipt_offset_rows)
                            ? ccwvDedupeRows(b.receipt_offset_rows, r => [ccwvStableKeyPart(r && r.debit_row_id), ccwvStableKeyPart(r && r.source_shipment_id), ccwvStableKeyPart(r && r.source_slice_id), ccwvStableKeyPart(r && r.target_row_id), ccwvStableKeyPart(r && r.target_slice_id), ccwvAmountKey((r && r.amount) || 0)].join('|'))
                            : [];
                        if (cleanOffsetRows.length) {
                            cleanOffsetRows.forEach(r => {
                                const sid = parseInt((r && r.source_shipment_id) || 0, 10);
                                const amt = num((r && (r.amount || r.current_amount)) || 0);
                                if(sid > 0 && amt > 0){
                                    const box = ensure(sid);
                                    box.amount += amt;
                                    box.raw_rows.push(r);
                                }
                            });
                        }

                        // Use older fuzzy recovery sources only as a fallback. When receipt_offset_rows
                        // exists, it is the authoritative source-by-source ledger trail.
                        if (!cleanOffsetRows.length) {
                            recoveredShipments(b).forEach(r => {
                                const sid = parseInt((r && r.shipment_id) || 0, 10);
                                const amt = num((r && r.amount) || 0);
                                if(sid > 0 && amt > 0){
                                    const box = ensure(sid);
                                    if(box.amount <= 0) box.amount = amt;
                                }
                            });
                        }

                        return Object.keys(grouped).map(k => {
                            const sid = parseInt(k || 0, 10);
                            const sourceBlock = findBlockByShipment(sid);
                            const debitRows = sourceLedgerDebitRows(sourceBlock);
                            const rows = blockDetailRows(sourceBlock);
                            const rowCur = curFromRows(debitRows.length ? debitRows : rows, 'GYD');
                            const appliedRows = buildAppliedSourceRows(grouped[k].raw_rows || [], sourceBlock, rowCur);
                            const debitOriginalTotal = sourceDebitOriginalTotal(debitRows);
                            const debitOpenTotal = sourceDebitOpenTotal(debitRows);
                            const historicalTotal = debitOriginalTotal > 0 ? debitOriginalTotal : (rows.length ? rowsTotal(rows) : num(grouped[k].amount || 0));
                            const fallbackOpen = Math.max(0, num(sourceBlock && sourceBlock.open_source_liability_amount || 0));
                            const openNow = debitRows.length ? debitOpenTotal : fallbackOpen;
                            return {
                                shipment_id: sid,
                                amount: num(grouped[k].amount || 0),
                                raw_rows: grouped[k].raw_rows || [],
                                applied_rows: appliedRows,
                                source_block: sourceBlock || null,
                                rows: rows,
                                source_debit_rows: debitRows,
                                currency: rowCur,
                                historical_total: historicalTotal,
                                open_now: openNow,
                                recovered_total: sourceDebitRecoveredTotal(debitRows)
                            };
                        }).sort((a,b)=>a.shipment_id-b.shipment_id);
                    }
                    function renderOwnReversalSection(b, fallbackCur){
                        const rows = (b && Array.isArray(b.receipt_unpaid_reversal_rows)) ? b.receipt_unpaid_reversal_rows : [];
                        const cur = fallbackCur || curFromRows(rows, 'GYD');
                        const unpaid = num(b && b.receipt_unpaid_reversed || 0);
                        if(unpaid <= 0) return '';

                        let html = '<div class="vwSectionTitle">Returns already removed from this shipment</div>';
                        html += '<div class="card" style="margin-bottom:10px"><div class="lk">This is this shipment’s own return reversal</div><div class="lv" style="line-height:1.45">Only the items listed here were removed before this shipment became cash-payable. Items shown later under debit exposure were not removed at this stage.</div></div>';
                        if(rows.length){
                            html += '<div class="vwTimeline">';
                            rows.forEach(r => {
                                const kind = String((r && r.kind) || 'return').toLowerCase();
                                const note = wholeQtyText(r && r.qty) + 'Removed from this shipment before payout.';
                                html += simpleStep(rowKindIcon(kind), rowKindTitle(r) + ' removed before payout', note, num((r && r.amount) || 0), (r && r.currency) || cur, 'neg');
                            });
                            html += '</div>';
                        } else {
                            html += '<div class="vwTimeline">'+simpleStep('↩', 'Unpaid return reversal', 'The ledger says returned items already reduced this shipment before payout.', unpaid, cur, 'neg')+'</div>';
                        }
                        return html;
                    }
                    function ownDebitRows(b){
                        const rows = (b && Array.isArray(b.receipt_own_debit_rows)) ? b.receipt_own_debit_rows : [];
                        return ccwvDedupeRows(rows, r => [ccwvStableKeyPart(r && r.kind), ccwvStableKeyPart(r && r.ledger_row_id), ccwvStableKeyPart(r && r.case_id), ccwvStableKeyPart(r && r.slice_id), ccwvStableKeyPart(r && r.order_item_id), ccwvAmountKey(rowAmount(r))].join('|'));
                    }
                    function ownDebitClearedByText(b){
                        const ids = (b && Array.isArray(b.receipt_own_debit_cleared_by)) ? b.receipt_own_debit_cleared_by : [];
                        const clean = ids.map(x => parseInt(x || 0, 10)).filter(x => x > 0);
                        return clean.length ? clean.map(x => 'remaining payout on #' + x).join(', ') : 'later shipment payout rows';
                    }
                    function rowClearedByText(r){
                        const ids = (r && Array.isArray(r.cleared_by_shipments)) ? r.cleared_by_shipments : [];
                        const clean = ids.map(x => parseInt(x || 0, 10)).filter(x => x > 0);
                        return clean.length ? clean.map(x => 'remaining payout on #' + x).join(', ') : 'other payout rows';
                    }
                    function rowClearedByIds(r){
                        const ids = (r && Array.isArray(r.cleared_by_shipments)) ? r.cleared_by_shipments : [];
                        return ids.map(x => parseInt(x || 0, 10)).filter(x => x > 0);
                    }
                    function isSameShipmentDebitRow(b, r){
                        const sid = parseInt((b && b.shipment_id) || 0, 10);
                        if(!sid) return false;
                        return rowClearedByIds(r).includes(sid);
                    }
                    function ownImmediateDebitRows(b){
                        return ownDebitRows(b).filter(r => isSameShipmentDebitRow(b, r));
                    }
                    function ownLaterDebitRows(b){
                        return ownDebitRows(b).filter(r => !isSameShipmentDebitRow(b, r));
                    }
                    function rowAmount(r){
                        return firstNum(r, ['amount', 'source_amount_original'], 0);
                    }
                    function rowRemainingNow(r){
                        return firstNum(r, ['source_amount_currently_open', 'current_open_amount', 'remaining_amount'], 0);
                    }
                    function rowRecoveredNow(r){
                        const amount = rowAmount(r);
                        const remaining = rowRemainingNow(r);
                        const explicit = firstNum(r, ['source_amount_still_recovered', 'recovered_amount'], 0);
                        if(remaining > 0 && explicit > Math.max(0, amount - remaining) + 0.01){
                            return Math.max(0, amount - remaining);
                        }
                        return explicit;
                    }
                    function sumRowsAmount(rows){
                        return rows.reduce((a, r) => a + rowAmount(r), 0);
                    }
                    function sumRowsRecovered(rows){
                        return rows.reduce((a, r) => a + rowRecoveredNow(r), 0);
                    }
                    function sumRowsRemaining(rows){
                        return rows.reduce((a, r) => a + rowRemainingNow(r), 0);
                    }
                    function receiptCashPaidTotal(b){
                        const rows = (b && Array.isArray(b.receipt_cash_rows)) ? b.receipt_cash_rows : [];
                        return rows.reduce((a, r) => a + num((r && r.amount) || 0), 0);
                    }
                    function finalReceiptPayable(b, fallback){
                        // Final payable must match the actual card/cash truth, not the older
                        // "earnings minus recovery" shortcut. Some shipments first act as
                        // recovery targets, then a later refund unwinds part of that target.
                        // In that case the stale shortcut shows values like 271.30, while
                        // the real payable row/card is 141.94.
                        const cash = receiptCashPaidTotal(b);
                        if(cash > 0.004) return cash;

                        const base = Math.max(0, num(fallback || (b && b.shipment_remaining) || 0));
                        const unwind = sumLedgerRows(ledgerUnwindRows(b));
                        if(unwind > 0.004){
                            return Math.max(0, base - unwind);
                        }

                        const explicit = hasOwn(b, 'receipt_final_payable') ? num(b.receipt_final_payable) : 0;
                        if(explicit > 0.004) return explicit;

                        if(hasOwn(b, 'display_net_after_adjustments')) return Math.max(0, num(b.display_net_after_adjustments));
                        if(hasOwn(b, 'shipment_remaining')) return Math.max(0, num(b.shipment_remaining));
                        return Math.max(0, base);
                    }
                    function sameShipmentSourceRecoveryEntries(b){
                        const sid = parseInt((b && b.shipment_id) || 0, 10);
                        return recoveryAllocationEntries(b).filter(entry => parseInt((entry && entry.shipment_id) || 0, 10) === sid);
                    }
                    function otherShipmentRecoveryEntries(b){
                        const sid = parseInt((b && b.shipment_id) || 0, 10);
                        return recoveryAllocationEntries(b).filter(entry => parseInt((entry && entry.shipment_id) || 0, 10) !== sid);
                    }
                    function ledgerUnwindRows(b){
                        const rows = (b && Array.isArray(b.receipt_unwind_rows)) ? b.receipt_unwind_rows : [];
                        return ccwvDedupeRows(rows, r => [ccwvStableKeyPart(r && r.source_debit_row_id), ccwvStableKeyPart(r && r.source_shipment_id), ccwvStableKeyPart(r && r.source_slice_id), ccwvStableKeyPart(r && r.target_slice_id), ccwvStableKeyPart(r && r.refund_case_id), ccwvAmountKey((r && r.amount) || 0)].join('|'));
                    }
                    function ledgerReopenedRows(b){
                        const rows = (b && Array.isArray(b.receipt_reopened_rows)) ? b.receipt_reopened_rows : [];
                        return ccwvDedupeRows(rows, r => [ccwvStableKeyPart(r && r.target_row_id), ccwvStableKeyPart(r && r.target_shipment_id), ccwvStableKeyPart(r && r.target_slice_id), ccwvStableKeyPart(r && r.source_slice_id), ccwvStableKeyPart(r && r.case_id), ccwvAmountKey((r && r.amount) || 0)].join('|'));
                    }
                    function sumLedgerRows(rows){
                        return rows.reduce((a, r) => a + num((r && r.amount) || 0), 0);
                    }
                    function renderLedgerUnwindSection(b, fallbackCur){
                        const rows = ledgerUnwindRows(b);
                        if(!rows.length) return '';
                        const cur = fallbackCur || 'GYD';
                        const total = sumLedgerRows(rows);
                        let html = '<div class="vwSectionTitle">Refund unwind / reopened prior debt</div>';
                        html += '<div class="card"><div class="lk">This shipment had already helped clear older balances</div><div class="lv">A later refund on this shipment invalidated part of that recovery. The ledger unwound those target links and reopened the original source debts shown below. This is not a new mystery charge; it is the old recovery being reversed because this shipment no longer had that earning available.</div></div>';
                        html += '<div class="vwMoneyGrid" style="margin-top:10px">';
                        html += moneyCard('Prior recovery unwound', total, cur, 'neg', 'Amount of older recovery this shipment could no longer cover after the refund.');
                        html += '</div><div class="vwTimeline">';
                        rows.forEach(r => {
                            const source = parseInt((r && r.source_shipment_id) || 0, 10);
                            const debitRow = parseInt((r && r.source_debit_row_id) || 0, 10);
                            const match = String((r && r.match_mode) || '').replace(/_/g, ' ');
                            let title = source > 0 ? ('Reopened debt on shipment #' + source) : 'Reopened older source debt';
                            let note = 'Unwound from target row #' + String((r && r.row_id) || '?') + '.';
                            if(debitRow > 0) note += ' Source debit row #' + debitRow + '.';
                            if(match) note += ' Match: ' + match + '.';
                            html += simpleStep('↺', title, note, num((r && r.amount) || 0), (r && r.currency) || cur, 'neg');
                        });
                        html += '</div>';
                        return html;
                    }
                    function renderLedgerReopenedSourceSection(b, fallbackCur){
                        const rows = ledgerReopenedRows(b);
                        if(!rows.length) return '';
                        const cur = fallbackCur || 'GYD';
                        const total = sumLedgerRows(rows);
                        let html = '<div class="vwSectionTitle">Historical source debt reopened</div>';
                        html += '<div class="card"><div class="lk">A target payout was refunded later</div><div class="lv">This section shows historical source debt that was reopened after another shipment stopped covering it. It is not a second mystery charge. The current open seller debit is shown separately below.</div></div>';
                        html += '<div class="vwMoneyGrid" style="margin-top:10px">';
                        html += moneyCard('Historical source debt reopened', total, cur, 'neg', 'Total historical source debt reopened by later target refunds. Current still-open debt is shown separately.');
                        html += '</div><div class="vwTimeline">';
                        rows.forEach(r => {
                            const target = parseInt((r && r.target_shipment_id) || 0, 10);
                            const openAfter = num((r && r.source_currently_open_after_reopen) || 0);
                            let title = target > 0 ? ('Target shipment #' + target + ' stopped covering this debt') : 'Target recovery stopped covering this debt';
                            let note = 'Reopened amount: '+fmtMoney(num((r && r.amount) || 0))+' '+cur+'.';
                            if(openAfter > 0) note += ' Open after this movement: '+fmtMoney(openAfter)+' '+cur+'.';
                            html += simpleStep('↻', title, note, num((r && r.amount) || 0), (r && r.currency) || cur, 'neg');
                        });
                        html += '</div>';
                        return html;
                    }

                    function sumOwnDebitRecovered(rows){
                        return rows.reduce((a, r) => a + firstNum(r, ['recovered_amount'], 0), 0);
                    }
                    function sumOwnDebitRemaining(rows){
                        return rows.reduce((a, r) => a + num((r && r.remaining_amount) || 0), 0);
                    }
                    function renderSameShipmentLiabilitySection(b, fallbackCur){
                        const rows = ownImmediateDebitRows(b);
                        if(!rows.length) return '';
                        const cur = fallbackCur || 'GYD';
                        const total = sumRowsAmount(rows);
                        const recovered = sumRowsRecovered(rows);
                        const remaining = sumRowsRemaining(rows);

                        let html = '<div class="vwSectionTitle">Same-shipment liability recovered from this payout</div>';
                        html += '<div class="card"><div class="lk">This did not come from another shipment</div><div class="lv">This was this shipment’s own shipping or return liability, recovered from this shipment’s own remaining payout before the vendor payable amount was finalized.</div></div>';
                        html += '<div class="vwMoneyGrid" style="margin-top:10px">';
                        html += moneyCard('Recovered from this shipment', recovered, cur, 'neg', 'Amount taken from this same shipment’s remaining payout.');
                        html += moneyCard('Still open from this same-shipment liability', remaining, cur, remaining > 0 ? 'open' : 'good', remaining > 0 ? 'Some of this liability is still open.' : 'This same-shipment liability is fully cleared.');
                        html += '</div>';

                        html += '<div class="vwTimeline">';
                        rows.forEach(r => {
                            const kind = String((r && r.kind) || 'return').toLowerCase();
                            const amount = num((r && r.amount) || 0);
                            const rec = firstNum(r, ['recovered_amount'], 0);
                            const rem = num((r && r.remaining_amount) || 0);
                            let label = rowKindTitle(r) + ' recovered from this shipment';
                            let note = 'Created '+fmtMoney(amount)+' '+cur+'. Recovered '+fmtMoney(rec)+' '+cur+' from this same shipment’s remaining payout.';
                            if(rem > 0) note += ' Still open: '+fmtMoney(rem)+' '+cur+'.';
                            html += simpleStep(rowKindIcon(kind), label, note, amount, (r && r.currency) || cur, 'neg');
                        });
                        html += '</div>';
                        return html;
                    }

                    function renderOwnDebitExposureSection(b, fallbackCur){
                        const rows = ownLaterDebitRows(b);
                        const total = sumRowsAmount(rows);
                        if(total <= 0 && !rows.length) return '';
                        const cur = fallbackCur || 'GYD';
                        const recovered = sumRowsRecovered(rows);
                        const remaining = sumRowsRemaining(rows);
                        const clearedBy = rows.length
                            ? Array.from(new Set(rows.flatMap(r => rowClearedByIds(r)))).map(x => 'remaining payout on #' + x).join(', ')
                            : ownDebitClearedByText(b);

                        let html = '<div class="vwSectionTitle">This shipment later created new debit exposure</div>';
                        html += '<div class="card"><div class="lk">Complete later-debit trace</div><div class="lv">These returned item or shipping amounts came from this same shipment after payout logic had already moved forward. They became seller debit exposure, then were recovered from '+esc(clearedBy || 'other payout rows')+'.</div></div>';

                        html += '<div class="vwMoneyGrid" style="margin-top:10px">';
                        html += moneyCard('Debit exposure from this shipment', total, cur, 'neg', 'Total seller-side return or shipping responsibility created by this shipment. Uses clean open/recovered ledger fields when available.');
                        html += moneyCard('Recovered from other payout rows', recovered, cur, 'good', 'Amount actually recovered against this later exposure. Recovered from '+(clearedBy || 'other payout rows')+'.');
                        html += moneyCard('Still open seller debit', remaining, cur, remaining > 0 ? 'open' : 'good', remaining > 0 ? 'This amount is still open and should be recovered by a later payout row.' : 'This debit exposure is fully cleared.');
                        html += '</div>';
                        if(remaining > 0){
                            html += '<div class="card" style="margin-top:10px"><div class="lk">What this means</div><div class="lv">This amount has not been recovered yet. It should remain visible as open seller debit exposure until a later shipment or payout row clears it.</div></div>';
                        }

                        if(rows.length){
                            html += '<div class="vwSectionTitle">Line-by-line later debit exposure trail</div>';
                            html += '<div class="vwTimeline">';
                            rows.forEach(r => {
                                const kind = String((r && r.kind) || 'return').toLowerCase();
                                const amount = rowAmount(r);
                                const rec = rowRecoveredNow(r);
                                const rem = rowRemainingNow(r);
                                const by = rowClearedByText(r);
                                let label = rowKindTitle(r) + ' became later debit exposure';
                                let note = 'Created '+fmtMoney(amount)+' '+cur+'. Recovered '+fmtMoney(rec)+' '+cur+' from '+by+'.';
                                if(rem > 0) note += ' Still open: '+fmtMoney(rem)+' '+cur+'.';
                                html += simpleStep(rowKindIcon(kind), label, note, amount, (r && r.currency) || cur, 'neg');
                            });
                            html += '</div>';
                        }

                        return html;
                    }

                    function renderRecoverySourceCard(entry, index, fallbackCur){
                        const cur = entry.currency || fallbackCur || 'GYD';
                        const sourceTitle = 'Shipment #' + entry.shipment_id;
                        const appliedRows = Array.isArray(entry.applied_rows) ? entry.applied_rows : [];
                        const rowsLabel = appliedRows.length ? 'Total source debit exposure currently represented by the ledger for this source shipment.' : (entry.rows.length ? 'Full return / shipping history on the source shipment.' : 'Using the recovered amount because no finer line-item breakdown was found.');
                        let html = '<div class="vwSourceCard">';
                        html += '<div class="vwSourceHead"><div><div class="vwSourceEyebrow">Other balance cleared</div><div class="vwSourceTitle">Balance from '+esc(sourceTitle)+'</div><div class="vwSourceSub">This shipment applied '+esc(fmtMoney(entry.amount) + ' ' + cur)+' to clear older debit exposure from '+esc(sourceTitle)+'. Every applied slice found in the ledger is shown below.</div></div><div class="vwSourcePill">Trail '+esc(index)+'</div></div>';
                        html += '<div class="vwMoneyGrid">';
                        html += moneyCard('Applied from this payout', entry.amount, cur, 'neg', 'Exact amount taken from the current shipment and applied to this source shipment’s open debit.');
                        html += moneyCard('Total debit exposure on '+sourceTitle, entry.historical_total, cur, '', rowsLabel);
                        html += moneyCard('Still open on '+sourceTitle, entry.open_now, cur, entry.open_now > 0 ? 'open' : 'good', entry.open_now > 0 ? 'Some source debt is still open after this allocation.' : 'That source debt is now fully cleared.');
                        html += '</div>';
                        if(num(entry.historical_total) > num(entry.amount) + 0.01){
                            html += '<div class="card" style="margin-top:10px"><div class="lk">Why the total can be bigger than this payout</div><div class="lv">'+esc(sourceTitle)+' may have older source debt that was already recovered elsewhere, is still open, or was reopened later. This card shows the full source-debt picture, while this payout applied only '+esc(fmtMoney(entry.amount)+' '+cur)+'.</div></div>';
                        }

                        if(appliedRows.length){
                            html += '<div class="vwSectionTitle">What this payout cleared from '+esc(sourceTitle)+'</div>';
                            html += '<div class="vwTimeline">';
                            appliedRows.forEach(r => {
                                let note = 'Applied by this payout.';
                                const original = num(r.original_amount || 0);
                                const recovered = firstNum(r, ['recovered_amount', 'source_amount_still_recovered'], 0);
                                const remaining = num(r.remaining_amount || 0);
                                const rowId = parseInt(r.source_debit_row_id || 0, 10);
                                if(rowId > 0) note += ' Source debit row #' + rowId + '.';
                                if(String(r.match_mode || '') === 'row_id' && original > 0 && Math.abs(num(r.applied_amount || 0) - original) > 0.01) note += ' This is one applied slice from that larger source-debt row.';
                                if(original > 0) note += ' Original source exposure: ' + fmtMoney(original) + ' ' + cur + '.';
                                if(recovered > 0) note += ' Total recovered on that source row: ' + fmtMoney(recovered) + ' ' + cur + '.';
                                if(remaining > 0) note += ' Still open on that source row: ' + fmtMoney(remaining) + ' ' + cur + '.';
                                const icon = String(r.kind || '').toLowerCase() === 'shipping' ? '🚚' : '↩';
                                html += simpleStep(icon, r.title || 'Cleared source debit', note, num(r.applied_amount || 0), r.currency || cur, 'neg');
                            });
                            html += '</div>';
                        } else if(entry.rows.length){
                            html += '<div class="vwSectionTitle">What created the balance on '+esc(sourceTitle)+'</div>';
                            if(num(entry.historical_total) > num(entry.amount)){
                                html += '<div class="smallNote" style="margin:0 0 10px">This list shows the full return / shipping history for '+esc(sourceTitle)+'. This payout only applied '+esc(fmtMoney(entry.amount) + ' ' + cur)+' to it.</div>';
                            }
                            html += '<div class="vwTimeline">';
                            entry.rows.forEach(r => {
                                html += simpleStep(rowKindIcon(r.kind), rowKindTitle(r), rowKindNote(r, entry.shipment_id), num((r && (r.impact || r.amount)) || 0), (r && r.currency) || cur, 'neg');
                            });
                            html += '</div>';
                        } else {
                            html += '<div class="card" style="margin-top:10px"><div class="lk">What created the other balance</div><div class="lv">Detailed source debit lines were not found, but the ledger shows that this payout cleared part of '+esc(sourceTitle)+' balance.</div></div>';
                        }
                        html += '</div>';
                        return html;
                    }
                    function debugBlock(b){
                        try{
                            if(!(window.CARICOVE_WALLET_DEBUG === true || localStorage.getItem('ccp2_debug') === '1')) return '';
                        }catch(e){ return ''; }
                        return '<details class="vwDebug"><summary>Admin debug details</summary><pre>'+esc(JSON.stringify({
                            shipment_id: b.shipment_id,
                            card_modal_type: b.card_modal_type,
                            open_source_liability_amount: b.open_source_liability_amount,
                            source_lineage_bound: b.source_lineage_bound,
                            debug_chain_role: b.debug_chain_role || null,
                            live_recovery_sources: b.live_recovery_sources || {},
                            affected_recovery_shipments: b.affected_recovery_shipments || []
                        }, null, 2))+'</pre></details>';
                    }
                    function vendorHero(kind, title, sub, status, statusClass){
                        return '<div class="vwHero">'
                            + '<div class="eyebrow">'+esc(kind)+'</div>'
                            + '<div class="headline">'+esc(title)+'</div>'
                            + '<div class="sub">'+esc(sub)+'</div>'
                            + '<div class="vwStatus '+esc(statusClass || '')+'">'+esc(status)+'</div>'
                            + '</div>';
                    }
                    function cleanMoneyAmount(v){
                        v = Number(v || 0);
                        if(!isFinite(v)) v = 0;
                        return Math.abs(v) < 0.005 ? 0 : v;
                    }
                    function moneyCard(k, v, cur, cls, note){
                        const raw = cleanMoneyAmount(v);
                        const shown = Math.abs(raw);
                        const isNeg = (cls === 'neg' && shown > 0);
                        const outCls = shown <= 0 && cls === 'neg' ? '' : (cls || '');
                        return '<div class="vwMoneyCard"><div class="k">'+esc(k)+'</div><div class="v '+esc(outCls)+'">'+esc((isNeg ? '−' : '') + fmtMoney(shown) + ' ' + (cur || 'GYD'))+'</div>'+(note ? '<div class="smallNote">'+esc(note)+'</div>' : '')+'</div>';
                    }
                    function simpleStep(icon, name, note, amount, cur, cls){
                        if(amount === null || amount === undefined){
                            return '<div class="vwStep"><div class="dot">'+esc(icon)+'</div><div><div class="name">'+esc(name)+'</div>'+(note ? '<div class="note">'+esc(note)+'</div>' : '')+'</div></div>';
                        }
                        const raw = cleanMoneyAmount(amount);
                        const shown = Math.abs(raw);
                        const isNeg = (cls === 'neg' && shown > 0);
                        const outCls = shown <= 0 && cls === 'neg' ? '' : (cls || '');
                        const amtHtml = '<div class="amt '+esc(outCls)+'">'+esc((isNeg ? '−' : '') + fmtMoney(shown) + ' ' + (cur || 'GYD'))+'</div>';
                        return '<div class="vwStep"><div class="dot">'+esc(icon)+'</div><div><div class="name">'+esc(name)+'</div>'+(note ? '<div class="note">'+esc(note)+'</div>' : '')+'</div>'+amtHtml+'</div>';
                    }
                    function renderFriendlyReturnModal(b){
                        const rawRows = ccwvDedupeRows(Array.isArray(b.direct_return_rows) ? b.direct_return_rows : [], r => [ccwvStableKeyPart(r && r.kind), ccwvStableKeyPart(r && r.case_id), ccwvStableKeyPart(r && r.slice_id), ccwvStableKeyPart(r && r.name), ccwvAmountKey((r && (r.impact || r.amount)) || 0)].join('|'));
                        const sourceRows = sourceLedgerDebitRows(b);
                        const sourceOriginalTotal = Math.max(0, sourceDebitOriginalTotal(sourceRows));
                        const sourceRecoveredTotal = Math.max(0, sourceDebitRecoveredTotal(sourceRows));
                        const sourceOpenTotal = Math.max(0, sourceDebitOpenTotal(sourceRows));
                        const hasSourceLedgerTruth = !!(sourceRows.length || sourceOriginalTotal > 0 || sourceRecoveredTotal > 0 || sourceOpenTotal > 0);
                        const rows = hasSourceLedgerTruth ? sourceRows : rawRows;
                        const cur = curFromRows(rows.length ? rows : rawRows, 'GYD');
                        const grouped = classifyReturnRows(rows);
                        const historicalTotalRaw = Math.max(0, rowsTotal(rows));
                        const currentOpenRaw = Math.max(0, num(b.open_source_liability_amount || 0));
                        const recovered = recoveredShipments(b);
                        const recoveredFromAvailable = Math.max(0, recovered.reduce((s,r)=>s+num(r.amount),0));

                        // CCWV_RETURN_BALANCE_MATH_GUARD_V3:
                        // The return-balance receipt must obey the same invariant as the ledger inspector:
                        //
                        //   total seller responsibility = already recovered from available earnings + still open now
                        //
                        // when the row is still open or partially recovered. Some visible row lists only contain
                        // the currently-open slice, while the recovery map contains the amount already recovered
                        // from later available shipments. Build the visible total from BOTH sides so the UI can
                        // never imply that Caricove recovered more than the debt.
                        let currentOpen = hasSourceLedgerTruth ? Math.max(0, (sourceOpenTotal > 0.004 ? sourceOpenTotal : currentOpenRaw)) : Math.max(0, currentOpenRaw);
                        let recoveredTotal = hasSourceLedgerTruth ? Math.max(0, (sourceRecoveredTotal > 0.004 ? sourceRecoveredTotal : recoveredFromAvailable)) : Math.max(0, recoveredFromAvailable);
                        let totalResponsibility = hasSourceLedgerTruth
                            ? (sourceOriginalTotal > 0.004 ? sourceOriginalTotal : Math.max(0, currentOpen + recoveredTotal))
                            : Math.max(0, historicalTotalRaw, currentOpenRaw + recoveredFromAvailable);

                        if (totalResponsibility <= 0 && (currentOpen > 0 || recoveredTotal > 0)) {
                            totalResponsibility = currentOpen + recoveredTotal;
                        }

                        if (totalResponsibility > 0) {
                            currentOpen = Math.min(currentOpen, totalResponsibility);
                            recoveredTotal = Math.min(recoveredTotal, totalResponsibility);

                            // Prefer live-open truth, then cap recovered so recovered + open never exceeds total.
                            if (currentOpen + recoveredTotal > totalResponsibility + 0.01) {
                                recoveredTotal = Math.max(0, totalResponsibility - currentOpen);
                            }
                        }

                        const closed = currentOpen <= 0.004;
                        const partiallyRecovered = !closed && recoveredTotal > 0.004;
                        let html = '';

                        html += vendorHero(
                            'Vendor return receipt',
                            closed ? 'This return balance is closed.' : (partiallyRecovered ? 'This return balance is partially recovered.' : 'This return balance still needs recovery.'),
                            closed
                                ? 'The return or shipping responsibility is already settled. No money is currently owed from this shipment.'
                                : 'Recovery only starts when later shipment earnings become available. This receipt separates what was already recovered from what is still open right now.',
                            closed ? '✅ No money is currently owed' : (partiallyRecovered ? '⚠️ Partially recovered — balance still open' : '⚠️ Open seller balance'),
                            closed ? '' : 'warn'
                        );

                        html += '<div class="vwMoneyGrid">';
                        html += moneyCard('Total seller responsibility', totalResponsibility, cur, totalResponsibility > 0 ? 'open' : 'good', 'Original seller-side return/shipping responsibility. If partially recovered, this equals already recovered plus still open.');
                        html += moneyCard('Already recovered from available earnings', recoveredTotal, cur, 'good', 'Amount already cleared only after later shipment earnings became available.');
                        html += moneyCard('Still open right now', currentOpen, cur, currentOpen > 0 ? 'open' : 'good', 'Live remaining balance. This is the only amount still waiting for future recovery.');
                        html += '</div>';

                        if (!hasSourceLedgerTruth && totalResponsibility > historicalTotalRaw + 0.01) {
                            html += '<div class="card" style="margin-top:10px"><div class="lk">Why the total is higher than the visible rows</div><div class="lv" style="line-height:1.45">The item list below may only show the currently-open slice. The total responsibility above is reconstructed from ledger truth: already recovered plus still open, so recovery never appears larger than the original responsibility.</div></div>';
                        }

                        html += '<div class="card" style="margin-top:12px"><div class="lk">Plain-English explanation</div><div class="lv" style="line-height:1.45">'
                            + (closed
                                ? 'This shipment had a return/refund responsibility, but the balance has already been recovered or reversed. The vendor wallet shows this history so you can understand why earlier payouts changed, but there is no open debt right now.'
                                : (partiallyRecovered
                                    ? 'This shipment created seller responsibility. Later available shipment earnings have already cleared part of it, and the remaining open balance will wait for a future available shipment before more recovery can happen.'
                                    : 'This shipment created seller responsibility. No later available shipment earnings have cleared it yet, so the open balance remains waiting for future recovery.'))
                            + '</div></div>';

                        if(rows.length){
                            html += '<div class="vwSectionTitle">What was included</div><div class="vwTimeline">';
                            grouped.returns.forEach(r=>{
                                html += simpleStep(rowKindIcon(r && r.kind), rowKindTitle(r), rowKindNote(r, b.shipment_id || ''), num((r && (r.impact || r.amount)) || 0), r.currency || cur, 'neg');
                            });
                            grouped.shipping.forEach(r=>{
                                html += simpleStep('🚚', r.name || 'Shipping fee', 'Shipping responsibility tied to this return.', num((r && (r.impact || r.amount)) || 0), r.currency || cur, 'neg');
                            });
                            grouped.exposure.forEach(r=>{
                                html += simpleStep('➕', r.name || 'Seller top-up', 'Extra seller-side balance needed after item/shipping math.', num((r && (r.impact || r.amount)) || 0), r.currency || cur, 'neg');
                            });
                            grouped.other.forEach(r=>{
                                html += simpleStep('•', r.name || 'Adjustment', 'Historical adjustment detail.', num((r && (r.impact || r.amount)) || 0), r.currency || cur, 'neg');
                            });
                            html += '</div>';
                        }

                        if(recovered.length){
                            html += '<div class="vwSectionTitle">Recovered from later payout(s)</div><div class="vwTimeline">';
                            recovered.forEach(r=>{
                                html += simpleStep('✓', 'Shipment #'+r.shipment_id, 'This later shipment helped clear the balance.', r.amount, cur, 'good');
                            });
                            html += '</div>';
                        }

                        html += debugBlock(b);
                        return html;
                    }

                    // Returns Breakdown modal — vendor-safe receipt, not a forensic dump.
                    document.querySelectorAll('.ccp2Why').forEach((a)=>{
                        a.addEventListener('click', (e)=>{
                            e.preventDefault();
                            e.stopPropagation();
                            const sid = a.getAttribute('data-shipment');
                            const b = findBlockByShipment(sid);
                            if(!b){
                                openShip('<div class="card"><div class="lk">No return details available.</div></div>', 'Return Summary');
                                return;
                            }
                            openShip(renderFriendlyReturnModal(b), 'Return Balance Summary');
                        });
                    });
                    // New Shipment Earnings modal — payout receipt experience.
                    document.querySelectorAll('.ccp2EarningsWhy').forEach((a)=>{
                        a.addEventListener('click', (e)=>{
                            e.preventDefault();
                            e.stopPropagation();

                            const sid = a.getAttribute('data-shipment');
                            const b = findBlockByShipment(sid);
                            if(!b){
                                openShip('<div class="card"><div class="lk">No earnings details available.</div></div>', 'Payout Summary');
                                return;
                            }

                            const modalType = String(b.card_modal_type || 'normal');
                            const earnings  = num(b.shipment_earnings || 0);
                            const deduct    = num(b.shipment_deduction || 0);
                            const remain    = num(b.shipment_remaining || 0);
                            const finalRemain = finalReceiptPayable(b, remain);
                            const unpaidReversed = num(b.receipt_unpaid_reversed || 0);
                            const recoveryOnly = num(b.receipt_recovery_only || (deduct - unpaidReversed));
                            const cur = 'GYD';
                            const sourceText = sourceShipmentText(b);
                            let html = '';

                            if(modalType === 'recovery' || deduct > 0){
                                const allOwnDebitRows = ownDebitRows(b);
                                const sameShipmentDebitRows = ownImmediateDebitRows(b);
                                const laterDebitRows = ownLaterDebitRows(b);
                                const sameShipmentDebitTotal = sumRowsAmount(sameShipmentDebitRows);
                                const sameShipmentRecovered = sumRowsRecovered(sameShipmentDebitRows);
                                const sameShipmentRemaining = sumRowsRemaining(sameShipmentDebitRows);
                                const laterDebitTotal = sumRowsAmount(laterDebitRows);
                                const laterRecovered = sumRowsRecovered(laterDebitRows);
                                const laterRemaining = sumRowsRemaining(laterDebitRows);
                                const recoveryEntries = otherShipmentRecoveryEntries(b);
                                const sameRecoveryEntries = sameShipmentSourceRecoveryEntries(b);
                                const otherRecoveryOnly = recoveryEntries.reduce((a, entry) => a + num((entry && entry.amount) || 0), 0);
                                const unwindRows = ledgerUnwindRows(b);
                                const reopenedRows = ledgerReopenedRows(b);
                                const unwindTotal = sumLedgerRows(unwindRows);
                                const reopenedTotal = sumLedgerRows(reopenedRows);
                                const hasOlderBalanceCleared = otherRecoveryOnly > 0 && recoveryEntries.length > 0;
                                const hasSameShipmentDebitStory = sameShipmentDebitTotal > 0;
                                const hasOwnDebitStory = laterDebitTotal > 0;
                                const hasOwnReversalStory = unpaidReversed > 0;
                                const hasUnwindStory = unwindTotal > 0;
                                const hasReopenedSourceStory = reopenedTotal > 0;

                                html += vendorHero(
                                    'Payout receipt',
                                    'This shipment has a ledger story.',
                                    'This view follows the ledger in order: what this shipment earned, what was removed before payout, what it recovered, what later got unwound/reopened, what stayed payable, and what source debt remains open.',
                                    '✅ Ledger trail explained',
                                    'info'
                                );

                                html += '<div class="vwMoneyGrid">';
                                html += moneyCard('Shipment earnings before adjustments', earnings, cur, '', 'What this shipment earned before returns, recovery, or payout movements.');
                                if(hasOwnReversalStory){
                                    html += moneyCard('Returns removed before payout', unpaidReversed, cur, 'neg', 'This shipment’s own return/refund amounts were reversed before this money became cash-payable.');
                                }
                                if(hasSameShipmentDebitStory){
                                    html += moneyCard('Recovery applied', sameShipmentRecovered, cur, 'neg', 'This shipment’s own shipping or return liability was recovered from this shipment’s own remaining payout.');
                                }
                                if(otherRecoveryOnly > 0){
                                    html += moneyCard('Prior debit recovery applied', Math.max(0, otherRecoveryOnly), cur, 'neg', 'This shipment acted as a recovery payout row and cleared older/open debt from another shipment.');
                                }
                                if(hasUnwindStory){
                                    html += moneyCard('Later return/unwind removed', unwindTotal, cur, 'neg', 'A later refund reopened part of what this shipment had previously applied to recovery, so this amount is no longer payable from this shipment.');
                                }
                                html += moneyCard('Paid / payable to you', finalRemain, cur, 'good', 'What remains payable from this shipment after returns, recovery, and later unwind/reopen movements.');
                                if(Math.abs(finalRemain - remain) > 0.01){
                                    html += '<div class="card" style="margin-top:10px"><div class="lk">Final payable locked to ledger cash truth</div><div class="lv" style="line-height:1.45">This shipment had a later unwind/recovery story. The simple subtraction can imply '+esc(fmtMoney(remain)+' '+cur)+', but the actual cash/payable row for this shipment is '+esc(fmtMoney(finalRemain)+' '+cur)+'. The modal now follows that final ledger row.</div></div>';
                                }
                                html += '</div>';

                                html += '<div class="card" style="margin-top:12px"><div class="lk">How to read this</div><div class="lv" style="line-height:1.45">A shipment can have more than one ledger role. It can pay you, it can recover its own shipping liability, it can clear older debt from another shipment, and it can later become the source of a new debit if items from this shipment are refunded. Each role is separated below so the story does not blend together.</div></div>';

                                if(hasOwnReversalStory){
                                    html += renderOwnReversalSection(b, cur);
                                }

                                if(hasSameShipmentDebitStory){
                                    html += renderSameShipmentLiabilitySection(b, cur);
                                }

                                if(otherRecoveryOnly > 0){
                                    html += '<div class="vwSectionTitle">Prior debit recovery this shipment cleared</div>';
                                    if(recoveryEntries.length){
                                        html += '<div class="card"><div class="lk">This is this shipment acting as a recovery target</div><div class="lv">Money from this shipment was used to clear prior debit exposure that came from another shipment. The cards below show which shipment created that older balance and exactly how much this shipment applied to it.</div></div>';
                                        recoveryEntries.forEach((entry, idx) => {
                                            html += renderRecoverySourceCard(entry, idx + 1, cur);
                                        });
                                    } else {
                                        html += '<div class="card"><div class="lk">Prior debit recovery cleared</div><div class="lv">The ledger says this shipment applied '+esc(fmtMoney(otherRecoveryOnly)+' '+cur)+' to older/open debt, but this payload did not include a finer source-shipment breakdown.</div></div>';
                                    }
                                }

                                if(hasUnwindStory){
                                    html += renderLedgerUnwindSection(b, cur);
                                }

                                if(hasReopenedSourceStory){
                                    html += renderLedgerReopenedSourceSection(b, cur);
                                }

                                if(hasOwnDebitStory){
                                    html += renderOwnDebitExposureSection(b, cur);
                                }

                                html += '<div class="vwSectionTitle">Simple money path</div><div class="vwTimeline">';
                                let stepNo = 1;
                                html += simpleStep(String(stepNo++), 'Shipment earned money', 'Original earning before ledger movements.', earnings, cur, '');
                                if(hasOwnReversalStory){
                                    html += simpleStep(String(stepNo++), 'Returns removed before payout', 'These were reversed before this shipment became cash-payable.', unpaidReversed, cur, 'neg');
                                }
                                if(hasSameShipmentDebitStory){
                                    html += simpleStep(String(stepNo++), 'Recovery applied', 'Recovered from this shipment’s own remaining payout before final payable was calculated.', sameShipmentRecovered, cur, 'neg');
                                }
                                if(otherRecoveryOnly > 0){
                                    html += simpleStep(String(stepNo++), 'Prior debit cleared by this shipment', recoveryEntries.length ? 'See the older/open balance section above.' : ('Source shipment(s): ' + sourceText), otherRecoveryOnly, cur, 'neg');
                                }
                                if(hasUnwindStory){
                                    html += simpleStep(String(stepNo++), 'Later return/unwind removed', 'A later refund reopened part of this shipment’s recovery role, so it cannot be counted as payable.', unwindTotal, cur, 'neg');
                                }
                                html += simpleStep(String(stepNo++), 'Paid / payable from this shipment', 'This is the amount left payable from this shipment after payout-side adjustments.', finalRemain, cur, 'good');
                                html += '</div>';
                                html += debugBlock(b);
                                openShip(html, 'Payout Summary');
                                return;
                            }

                            if(modalType === 'reversed'){
                                const returnAdjust = cleanMoneyAmount(b.display_return_adjustment !== undefined ? b.display_return_adjustment : deduct);
                                const netAfterAdjust = cleanMoneyAmount(b.display_net_after_adjustments !== undefined ? b.display_net_after_adjustments : remain);
                                const hasReturnAdjustment = Math.abs(returnAdjust) >= 0.005;

                                if(!hasReturnAdjustment){
                                    html += vendorHero(
                                        'Payout receipt',
                                        'No return adjustment was applied to this payout.',
                                        'This shipment has return/reversal trace data, but the payout-side return adjustment is zero. No seller earnings were removed from this receipt.',
                                        '✅ No payout reversal',
                                        ''
                                    );
                                    html += '<div class="vwMoneyGrid">';
                                    html += moneyCard('Shipment earnings', earnings || remain, cur, 'good', 'Seller earnings available on this receipt.');
                                    html += moneyCard('Paid / payable to you', netAfterAdjust || remain || earnings, cur, 'good', 'Final amount after confirming no payout-side return adjustment.');
                                    html += '</div>';
                                    html += debugBlock(b);
                                    openShip(html, 'Payout Summary');
                                    return;
                                }

                                html += vendorHero(
                                    'Return receipt',
                                    'This shipment was adjusted before payout.',
                                    'The related order was refunded before these earnings were released, so the seller earning was reversed before payout instead of becoming an open debt.',
                                    '✅ No separate recovery needed',
                                    ''
                                );
                                html += '<div class="vwMoneyGrid">';
                                html += moneyCard('Original shipment earnings', earnings, cur, '', 'Before return adjustment.');
                                html += moneyCard('Return adjustment', returnAdjust, cur, 'neg', 'Amount reversed before payout.');
                                html += moneyCard('Paid / payable to you', netAfterAdjust, cur, netAfterAdjust > 0 ? 'good' : '', 'Final amount after adjustment.');
                                html += '</div>';
                                html += debugBlock(b);
                                openShip(html, 'Return Summary');
                                return;
                            }

                            html += vendorHero(
                                'Payout receipt',
                                'This shipment has no return or recovery adjustment.',
                                'These earnings are not currently being used to clear a return, shipping, or prior-debit balance.',
                                '✅ Clean payout',
                                ''
                            );
                            html += '<div class="vwMoneyGrid">';
                            html += moneyCard('Shipment earnings', remain || earnings, cur, 'good', 'Current seller amount for this shipment.');
                            html += moneyCard('Recovery applied', 0, cur, '', 'No recovery deduction on this shipment.');
                            html += moneyCard('Still owed', 0, cur, 'good', 'No open seller balance on this payout.');
                            html += '</div>';
                            html += debugBlock(b);
                            openShip(html, 'Payout Summary');
                        });
                    });
document.querySelectorAll('.feedRow[data-shipment]').forEach((row)=>{
                        row.addEventListener('click', ()=>{
                            
                            
                            
                            
                            const sid = row.getAttribute('data-shipment');
                            const b = findBlockByShipment(sid);
                            if(!b){
                                openShip('<div class="card"><div class="lk">Details</div><div class="lv">No detail payload found.</div></div>', 'Shipment #' + sid);
                                return;
                            }

                            let itemsHtml = '';
                            let sumTotal = 0, sumDelivered = 0, sumCancelled = 0, sumReturned = 0, sumReturnless = 0, sumNever = 0, sumPendingReturn = 0;
                            const chip = (cls, txt) => '<span class="qchip '+cls+'">'+txt+'</span>';
                            const summaryPill = (cls, label, n) => n > 0 ? '<span class="sum-pill '+cls+'">'+label+' <b>'+esc(String(n))+'</b></span>' : '';

                            if (b.items && b.items.length){
                                itemsHtml = '<div class="items">';
                                // ---- Shipment summary pills (truth status) ----
                                b.items.forEach(it2=>{
                                    const od2 = (it2.ordered_qty!==undefined)?parseInt(it2.ordered_qty,10):parseInt(it2.qty,10);
                                    const dl2 = (it2.delivered_qty!==undefined)?parseInt(it2.delivered_qty,10):parseInt(it2.qty,10);
                                    const cx2 = (it2.cancelled_qty!==undefined)?parseInt(it2.cancelled_qty,10):0;
                                    const rt2 = (it2.returned_qty!==undefined)?parseInt(it2.returned_qty,10):0;
                                    const rl2 = (it2.returnless_qty!==undefined)?parseInt(it2.returnless_qty,10):0;
                                    const nr2 = (it2.never_received_qty!==undefined)?parseInt(it2.never_received_qty,10):0;
                                    const rp2 = (it2.return_pending_qty!==undefined)?parseInt(it2.return_pending_qty,10):0;
                                    sumTotal += Math.max(0, isNaN(od2)?0:od2);
                                    sumDelivered += Math.max(0, isNaN(dl2)?0:dl2);
                                    sumCancelled += Math.max(0, isNaN(cx2)?0:cx2);
                                    sumReturned += Math.max(0, isNaN(rt2)?0:rt2);
                                    sumReturnless += Math.max(0, isNaN(rl2)?0:rl2);
                                    sumNever += Math.max(0, isNaN(nr2)?0:nr2);
                                    sumPendingReturn += Math.max(0, isNaN(rp2)?0:rp2);
                                });

                                let pills = '<div class="ship-summary">';
                                pills += summaryPill('total', 'TOTAL', sumTotal);
                                pills += summaryPill('delivered', 'DELIVERED', sumDelivered);
                                pills += summaryPill('returned', 'RETURNED & RECEIVED', sumReturned);
                                pills += summaryPill('returnless', 'RETURNLESS REFUND', sumReturnless);
                                pills += summaryPill('never', 'NEVER ARRIVED', sumNever);
                                pills += summaryPill('pending-return', 'AWAITING RETURN', sumPendingReturn);
                                pills += summaryPill('cancelled', 'CANCELLED', sumCancelled);
                                pills += '</div>';

                                itemsHtml += pills;
                                // ---- end summary ----

                              b.items.forEach(it=>{
          const od = (it.ordered_qty!==undefined)?parseInt(it.ordered_qty,10):parseInt(it.qty,10);
          const dl = (it.delivered_qty!==undefined)?parseInt(it.delivered_qty,10):0;
          const cx = (it.cancelled_qty!==undefined)?parseInt(it.cancelled_qty,10):0;
          const rt = (it.returned_qty!==undefined)?parseInt(it.returned_qty,10):0;
          const rl = (it.returnless_qty!==undefined)?parseInt(it.returnless_qty,10):0;
          const nr = (it.never_received_qty!==undefined)?parseInt(it.never_received_qty,10):0;
          const rp = (it.return_pending_qty!==undefined)?parseInt(it.return_pending_qty,10):0;

          const title = esc(it.base_name || it.name || '');

         // up to 3 slick pills; remaining collapses into +N
        const pillsHTML = (meta)=>{
          if(!meta || !meta.length) return '';

          const fmt = (s)=>{
            s = (s||'').toString().trim();
            if(!s) return '';
            // if 1–2 letters, FULL CAPS (XS, M, DE)
            if(/^[A-Za-z]{1,2}$/.test(s)) return s.toUpperCase();
            // otherwise Title-case first letter
            return s.charAt(0).toUpperCase() + s.slice(1).toLowerCase();
          };

          const max = 3;
          const shown = meta.slice(0, max);
          const more = meta.length - shown.length;

          let out = '<div class="vpills">';
          shown.forEach(p=>{
            const rawK = (p && p.k) ? p.k : '';
            const rawV = (p && p.v) ? p.v : '';
            if(!rawV) return;

            const k = esc(fmt(rawK));
            const v = esc(fmt(rawV));

            // allow value-only pills (no label)
            if(k) out += '<span class="vpill"><b>'+k+':</b> '+v+'</span>';
            else  out += '<span class="vpill">'+v+'</span>';
          });

          if(more > 0) out += '<span class="vmore">+'+more+'</span>';
          out += '</div>';
          return out;
        };

          const statusChips = [];
          if(rt>0) statusChips.push(chip('returned', 'Returned & received ×'+esc(String(rt))));
          if(rl>0) statusChips.push(chip('returnless', 'Returnless refund ×'+esc(String(rl))));
          if(nr>0) statusChips.push(chip('never', 'Never arrived ×'+esc(String(nr))));
          if(rp>0) statusChips.push(chip('pending-return', 'Awaiting return ×'+esc(String(rp))));
          if(cx>0) statusChips.push(chip('cancelled', 'Cancelled ×'+esc(String(cx))));
          if(!statusChips.length){
              let deliveredTxt = 'Delivered ×' + esc(String(isNaN(dl) || dl <= 0 ? (isNaN(od)?1:od) : dl));
              if(dl>0 && od>0 && dl!==od) deliveredTxt += ' / '+esc(String(od));
              statusChips.push(chip('delivered', deliveredTxt));
          }

          itemsHtml += '<div class="it">';
          itemsHtml +=   '<div class="nm"><div class="t">'+title+'</div>'+pillsHTML(it.meta)+'</div>';
          itemsHtml +=   '<div class="qt"><div class="qtStack">'+statusChips.join('')+'</div></div>';
          itemsHtml += '</div>';
        });
                                itemsHtml += '</div>';
                            } else {
                                itemsHtml = '<div class="smallNote">Items will appear here once shipment-to-item mapping is available. (Currently using best-effort vendor items from the order.)</div>';
                            }

                            const statusLine = [];
                            if(sumReturned > 0) statusLine.push(sumReturned + ' returned & received');
                            if(sumReturnless > 0) statusLine.push(sumReturnless + ' returnless refund');
                            if(sumNever > 0) statusLine.push(sumNever + ' never arrived');
                            if(sumPendingReturn > 0) statusLine.push(sumPendingReturn + ' awaiting return');
                            const truthSub = statusLine.length ? 'This modal separates physical returns from returnless refunds and never-arrived cases.' : 'This modal shows the delivered item truth for this shipment.';
                            const truthStatus = statusLine.length ? statusLine.join(' • ') : 'Delivered item truth';

                            const html =
                                vendorHero(
                                    'Shipment item truth',
                                    'Shipment #' + esc(b.shipment_id),
                                    truthSub,
                                    truthStatus,
                                    statusLine.length ? 'info' : ''
                                ) +
                                '<div class="grid2">' +
                                  '<div class="card"><div class="lk">Shipment</div><div class="lv">#'+esc(b.shipment_id)+'</div></div>' +
                                  '<div class="card"><div class="lk">Order</div><div class="lv">#'+esc(b.order_number)+'</div></div>' +
                                '</div>' +
                                '<div class="grid2" style="margin-top:10px">' +
                                  '<div class="card"><div class="lk">Delivering to</div><div class="lv">'+esc(b.cx_name)+'</div><div class="lk" style="margin-top:8px">Phone</div><div class="lv">'+esc(b.cx_phone)+'</div></div>' +
                                  '<div class="card"><div class="lk">Address</div><div class="lv">'+esc(b.addr1)+'</div><div class="lv" style="margin-top:6px">'+esc(b.addr2)+'</div></div>' +
                                '</div>' +
                                '<div class="card shipTruthCard" style="margin-top:10px"><div class="lk">Items in this shipment</div>' +
                                  itemsHtml +
                                ((Array.isArray(b.direct_return_rows) && b.direct_return_rows.length) ? ('<div class="smallNote" style="margin-top:10px">Historical refund / return trace is preserved for this shipment.</div>') : '') +
                                '</div>' +
                                '<div class="smallNote">Customer privacy: phone is masked; address is shown at delivery level only.</div>';

                            openShip(html, 'Shipment #' + b.shipment_id);
                        });
                    });

                    /* ----------------- Instant modal (REQUEST) ----------------- */
                   const instantBtn = $('#ccp2-instant-btn');
        const cashoutOpenBtn = $('#ccp2-cashout-open');
        const instBack = $('#ccp2InstantBack');
        const instClose = $('#ccp2InstantClose');
        const holdBtn = $('#ccp2HoldConfirm');

        const availTxt = $('#ccp2AvailTxt');
        const netTxt   = $('#ccp2NetTxt');
        const noteTxt  = $('#ccp2InstantNote');

                    // IMPORTANT: use truthful available (available + debit)
                    const AVAIL = <?php echo json_encode((float)$available_payable); ?>;

                    function money(n){
                        const x = Number(n)||0;
                        try{
                            return x.toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2}) + ' GYD';
                        }catch(e){
                            return x.toFixed(2) + ' GYD';
                        }
                    }

                   function openInstant(){
            if (!instBack || !availTxt || !netTxt || !noteTxt) return;

            const net = AVAIL;

            availTxt.textContent = money(AVAIL);
            netTxt.textContent   = money(net);
            noteTxt.textContent  = 'Hold to send a request for admin approval.';
            instBack.classList.add('show');
            instBack.setAttribute('aria-hidden','false');
            document.body.style.overflow = 'hidden';
        }

                    function closeInstant(){
                        instBack.classList.remove('show');
                        instBack.setAttribute('aria-hidden','true');
                        document.body.style.overflow = '';
                        cancelHold();
                    }

                 if (instantBtn && !instantBtn.disabled) {
            instantBtn.addEventListener('click', openInstant);
        }
        if (cashoutOpenBtn && !cashoutOpenBtn.disabled) {
            cashoutOpenBtn.addEventListener('click', openInstant);
        }
        if (instClose) instClose.addEventListener('click', closeInstant);
        if (instBack) instBack.addEventListener('click', (e)=>{ if(e.target === instBack) closeInstant(); });

                    let holdTimer = null;
                    let holding = false;

                    function startHold(){
                        if(holding) return;
                        holding = true;
                        holdBtn.classList.add('is-holding');
                        noteTxt.textContent = 'Sending request… keep holding…';
                        holdTimer = setTimeout(runInstant, 1000);
                    }

                    function cancelHold(){
                        holding = false;
                        if(holdBtn) holdBtn.classList.remove('is-holding');
                        if(holdTimer){ clearTimeout(holdTimer); holdTimer = null; }
                        if(noteTxt) noteTxt.textContent = 'Hold to send a request for admin approval.';
                    }

                    async function runInstant(){
                        cancelHold();
                        holdBtn.disabled = true;
                        noteTxt.textContent = 'Sending request…';

                        const fd = new FormData();
                        fd.append('action','cc_sp_instant_cashout');
                        fd.append('nonce','<?php echo esc_js($nonce_instant); ?>');
                        fd.append('amount', String((Number(AVAIL) || 0).toFixed(2)));

                        try{
                            const res = await fetch('<?php echo esc_js(admin_url('admin-ajax.php')); ?>', {
                                method:'POST',
                                credentials:'same-origin',
                                body: fd
                            });
                            const json = await res.json();

                            if(json && json.success){
                                noteTxt.textContent = 'Request sent to admin for approval.';
                                setTimeout(()=>location.reload(), 700);
                                return;
                            }
                            noteTxt.textContent = (json?.data?.message || 'Could not send request.');
                        }catch(e){
                            noteTxt.textContent = 'Network error.';
                        }finally{
                            holdBtn.disabled = false;
                        }
                    }

                    if(holdBtn){
                        holdBtn.addEventListener('mousedown', startHold);
                        holdBtn.addEventListener('touchstart', (e)=>{ e.preventDefault(); startHold(); }, {passive:false});
                        ['mouseup','mouseleave','touchend','touchcancel'].forEach(ev=>{
                            holdBtn.addEventListener(ev, cancelHold);
                        });
                    }

                    document.addEventListener('keydown', (e)=>{
                        if(e.key === 'Escape'){
                            if(shipBack && shipBack.classList.contains('show')) closeShip();
                            if(instBack && instBack.classList.contains('show')) closeInstant();
                        }
                    });
                })();
            

                    /* ----------------- Deep link: focus a shipment ----------------- */
                    try{
                        const sp = new URLSearchParams(window.location.search);
                        const focusSid = sp.get('cc_sp_shipment');
                        if(focusSid){
                            // Ensure filter shows it even if pending/available
                            // (link should pass cc_sp_filter=all, but this is a safety net)
                            const row = document.querySelector('.feedRow[data-shipment="'+focusSid+'"]');
                            if(row){
                                row.scrollIntoView({behavior:'smooth', block:'center'});
                                row.classList.add('ccp2Focus');
                                setTimeout(()=>row.classList.remove('ccp2Focus'), 2200);
                                // open the existing details modal
                                row.click();
                            }
                        }
                    }catch(e){}
                    
                    
                    
                    document.querySelectorAll('.ship-liab-toggle[aria-controls]').forEach(function(toggleBtn){
                        const targetId = toggleBtn.getAttribute('aria-controls') || '';
                        const targetEl = targetId ? document.getElementById(targetId) : null;
                        if (!targetEl) return;
                        toggleBtn.addEventListener('click', function () {
                            const isOpen = toggleBtn.getAttribute('aria-expanded') === 'true';
                            toggleBtn.setAttribute('aria-expanded', isOpen ? 'false' : 'true');
                            targetEl.hidden = isOpen;
                        });
                    });
                    
                    
                    
                    
                    
                    
        </script>
        </div>
        <?php
        return (string)ob_get_clean();
    }
}
