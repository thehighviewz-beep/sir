<?php
namespace Caricove\SellerPayouts;

if (!defined('ABSPATH')) exit;

trait VendorWalletUISaveMethodTrait {
    public function save_method(): void {
        if (!is_user_logged_in()) wp_send_json_error(['message' => 'Not logged in.'], 401);
        check_ajax_referer('cc_sp_save_payout_method_v2','nonce');
        
        
$uid = get_current_user_id();


        $method = isset($_POST['method']) ? sanitize_text_field((string)$_POST['method']) : 'gtt';
        if ($method !== 'gtt' && $method !== 'bank') $method = 'gtt';

        $gtt = isset($_POST['gtt_phone']) ? sanitize_text_field((string)$_POST['gtt_phone']) : '';
        $bank_name = isset($_POST['bank_name']) ? sanitize_text_field((string)$_POST['bank_name']) : '';
        $bank_holder = isset($_POST['bank_holder']) ? sanitize_text_field((string)$_POST['bank_holder']) : '';
        $bank_acct = isset($_POST['bank_acct']) ? preg_replace('/\D+/', '', (string)$_POST['bank_acct']) : '';

        if ($method === 'gtt') {
            if (trim($gtt) === '') wp_send_json_error(['message'=>'Enter mobile money number.'], 400);
            update_user_meta($uid, '_cc_sp_method', 'gtt');
            update_user_meta($uid, '_cc_sp_gtt_phone', $gtt);
            wp_send_json_success(['message'=>'Saved.']);
        }

        if (trim($bank_name)==='' || trim($bank_holder)==='' || trim($bank_acct)==='') {
            wp_send_json_error(['message'=>'Fill bank name, account holder, and account number.'], 400);
        }

        $last4 = substr($bank_acct, -4);
        update_user_meta($uid, '_cc_sp_method', 'bank');
        update_user_meta($uid, '_cc_sp_bank_name', $bank_name);
        update_user_meta($uid, '_cc_sp_bank_holder', $bank_holder);
        update_user_meta($uid, '_cc_sp_bank_last4', $last4);

        wp_send_json_success(['message'=>'Saved.']);
    }

}
