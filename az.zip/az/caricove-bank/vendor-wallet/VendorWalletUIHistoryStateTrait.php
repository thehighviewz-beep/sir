<?php
namespace Caricove\SellerPayouts;

use Caricove\Bank\Ledger;

if (!defined('ABSPATH')) exit;

trait VendorWalletUIHistoryStateTrait {
    protected function buildWalletHistoryStateContext(array $ctx): array {
        extract($ctx, EXTR_SKIP);
        // --- Build card-level recovery history map + true source tracing ---
        global $wpdb;
        $lt = Ledger::table();

        $card_recovery_by_shipment         = []; // [target_shipment_id => total recovered on this card]
        $card_recovery_source_by_shipment  = []; // [target_shipment_id => first source shipment id]
        $card_recovery_sources_by_shipment = []; // [target_shipment_id => [source_shipment_id => amount]]
        $source_recovery_targets_by_shipment = []; // [source_shipment_id => [target_shipment_id => amount]]

        // Level 4 persisted historical offset graph (vendor-scoped scar store).
        // This is the primary permanent trace memory; live allocator + reconstruction can feed it,
        // but future reloads should be able to rebuild from this store first.
        $persisted_trace_graph = get_user_meta($uid, '_cc_sp_trace_graph_v4', true);
        if (!is_array($persisted_trace_graph)) {
            $persisted_trace_graph = [];
        }
        if (empty($persisted_trace_graph['targets']) || !is_array($persisted_trace_graph['targets'])) {
            $persisted_trace_graph['targets'] = [];
        }
        if (empty($persisted_trace_graph['sources']) || !is_array($persisted_trace_graph['sources'])) {
            $persisted_trace_graph['sources'] = [];
        }
        $trace_graph_dirty = false;

        $normalize_trace_rows = function($rows){
            $out = [];
            $seen = [];
            foreach ((array)$rows as $rr) {
                if (!is_array($rr)) continue;
                $src = (int)($rr['source_shipment_id'] ?? 0);
                $iid = (int)($rr['item_id'] ?? 0);
                $qty = (int)($rr['qty'] ?? 0);
                $name = trim((string)($rr['name'] ?? ''));
                $kind = trim((string)($rr['kind'] ?? 'return')) ?: 'return';
                $unit = trim((string)($rr['unit_ex'] ?? '0.00'));
                $rate = trim((string)($rr['comm_rate'] ?? '0.00'));
                $impact = trim((string)($rr['impact'] ?? '0.00'));
                $cur = trim((string)($rr['currency'] ?? 'GYD')) ?: 'GYD';
                if ($src <= 0 && $iid <= 0 && $name === '' && $qty <= 0) continue;
                $key = implode('|', [
                    $kind,
                    $src,
                    $iid,
                    strtolower($name),
                    $qty,
                    $unit,
                    $rate,
                    $impact,
                    $cur,
                ]);
                if (isset($seen[$key])) continue;
                $seen[$key] = true;
                $out[] = [
                    'kind' => $kind,
                    'source_shipment_id' => $src,
                    'item_id' => $iid,
                    'name' => $name,
                    'qty' => $qty,
                    'unit_ex' => $unit,
                    'comm_rate' => $rate,
                    'impact' => $impact,
                    'currency' => $cur,
                ];
            }
            return array_values($out);
        };

        $graph_record_edge = function(int $source_sid, int $target_sid, float $amt, array $return_rows = []) use (&$persisted_trace_graph, &$trace_graph_dirty, $normalize_trace_rows): void {
            $source_sid = (int)$source_sid;
            $target_sid = (int)$target_sid;
            $amt = round((float)$amt, 2);
            if ($source_sid <= 0 || $target_sid <= 0 || $source_sid === $target_sid || $amt <= 0) return;

            if (!isset($persisted_trace_graph['targets'][$target_sid]) || !is_array($persisted_trace_graph['targets'][$target_sid])) {
                $persisted_trace_graph['targets'][$target_sid] = ['sources' => [], 'rows' => []];
                $trace_graph_dirty = true;
            }
            if (!isset($persisted_trace_graph['sources'][$source_sid]) || !is_array($persisted_trace_graph['sources'][$source_sid])) {
                $persisted_trace_graph['sources'][$source_sid] = ['targets' => [], 'rows' => []];
                $trace_graph_dirty = true;
            }
            if (!isset($persisted_trace_graph['targets'][$target_sid]['sources']) || !is_array($persisted_trace_graph['targets'][$target_sid]['sources'])) {
                $persisted_trace_graph['targets'][$target_sid]['sources'] = [];
                $trace_graph_dirty = true;
            }
            if (!isset($persisted_trace_graph['sources'][$source_sid]['targets']) || !is_array($persisted_trace_graph['sources'][$source_sid]['targets'])) {
                $persisted_trace_graph['sources'][$source_sid]['targets'] = [];
                $trace_graph_dirty = true;
            }

            $prevT = round((float)($persisted_trace_graph['targets'][$target_sid]['sources'][$source_sid] ?? 0), 2);
            $prevS = round((float)($persisted_trace_graph['sources'][$source_sid]['targets'][$target_sid] ?? 0), 2);
            if (abs($prevT - $amt) > 0.009) {
                $persisted_trace_graph['targets'][$target_sid]['sources'][$source_sid] = $amt;
                $trace_graph_dirty = true;
            }
            if (abs($prevS - $amt) > 0.009) {
                $persisted_trace_graph['sources'][$source_sid]['targets'][$target_sid] = $amt;
                $trace_graph_dirty = true;
            }

            $rowsNorm = $normalize_trace_rows($return_rows);
            if ($rowsNorm) {
                if (($persisted_trace_graph['targets'][$target_sid]['rows'] ?? []) !== $rowsNorm) {
                    $persisted_trace_graph['targets'][$target_sid]['rows'] = $rowsNorm;
                    $trace_graph_dirty = true;
                }
                if (($persisted_trace_graph['sources'][$source_sid]['rows'] ?? []) !== $rowsNorm) {
                    $persisted_trace_graph['sources'][$source_sid]['rows'] = $rowsNorm;
                    $trace_graph_dirty = true;
                }
            }
        };

        $debit_rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, shipment_id, net
                 FROM {$lt}
                 WHERE vendor_id = %d
                   AND state = 'debit'
                   AND net < 0
                 ORDER BY id ASC",
                $uid
            ),
            ARRAY_A
        );

        $debit_queue = [];
        $guilty_shipment_ids = [];
        $shipment_chain_role_map = [];

        // First pass: explicit debit rows are always guilty/source debt.
        if (is_array($debit_rows)) {
            foreach ($debit_rows as $dr) {
        $source_sid = (int)($dr['shipment_id'] ?? 0);
        $amount     = abs((float)($dr['net'] ?? 0));

        if ($source_sid <= 0 || $amount <= 0) continue;

        $guilty_shipment_ids[$source_sid] = true;

        $debit_queue[] = [
            'shipment_id' => $source_sid,
            'remaining'   => round($amount, 2),
        ];
            }
        }

        // Second pass: inspect current chain truth per shipment.
        // This catches shipments that have transitioned into SOURCE/MIXED/RESET
        // even if their visible card row is still available/paid.
        $shipment_ids_for_chain_truth = [];
        foreach ($rows as $rr) {
            $sid = (int)($rr['shipment_id'] ?? 0);
            if ($sid > 0) {
        $shipment_ids_for_chain_truth[$sid] = true;
            }
        }

        foreach (array_keys($shipment_ids_for_chain_truth) as $sid) {
            $chain = \Caricove\Bank\Ledger::inspect_shipment_chain_state((int)$sid, (int)$uid);
            $role  = strtoupper((string)($chain['role_state'] ?? ''));
            if ($role !== '') {
        $shipment_chain_role_map[$sid] = $role;
            }

            if (in_array($role, ['SOURCE', 'MIXED', 'RESET'], true)) {
        $guilty_shipment_ids[$sid] = true;

        $active_source_amount = round((float)($chain['active_source_amount'] ?? 0), 2);
        if ($active_source_amount > 0) {
            $found = false;
            foreach ($debit_queue as &$dq) {
                if ((int)($dq['shipment_id'] ?? 0) === (int)$sid) {
                    $dq['remaining'] = round(max((float)($dq['remaining'] ?? 0), $active_source_amount), 2);
                    $found = true;
                    break;
                }
            }
            unset($dq);

            if (!$found) {
                $debit_queue[] = [
                    'shipment_id' => (int)$sid,
                    'remaining'   => $active_source_amount,
                ];
            }
        }
            }
        }

        $shipment_time_map = [];
        foreach ($rows as $rr) {
            $sid = (int)($rr['shipment_id'] ?? 0);
            if ($sid <= 0) continue;

            $ts = strtotime((string)($rr['delivered_at'] ?? $rr['created_at'] ?? '')) ?: 0;
            if (!isset($shipment_time_map[$sid]) || $ts > $shipment_time_map[$sid]) {
        $shipment_time_map[$sid] = $ts;
            }

            if (strtolower((string)($rr['state'] ?? '')) === 'reversed') {
        $guilty_shipment_ids[$sid] = true;
            }
        }

        $alloc_rows = $rows;
        usort($alloc_rows, function($a, $b){
            $a_ts = strtotime((string)($a['delivered_at'] ?? $a['created_at'] ?? '')) ?: 0;
            $b_ts = strtotime((string)($b['delivered_at'] ?? $b['created_at'] ?? '')) ?: 0;
            if ($a_ts !== $b_ts) return $a_ts <=> $b_ts;

            $a_id = (int)($a['id'] ?? 0);
            $b_id = (int)($b['id'] ?? 0);
            return $a_id <=> $b_id;
        });

        foreach ($alloc_rows as $ar) {
            $target_sid   = (int)($ar['shipment_id'] ?? 0);
            $target_state = strtolower((string)($ar['state'] ?? ''));

            if ($target_sid <= 0) continue;
            if (!in_array($target_state, ['pending','available','hold','paid'], true)) continue;
            if (isset($guilty_shipment_ids[$target_sid])) continue; // only innocent shipments may absorb recovery

            $earnings_remaining = round(max(0.0, (float)($ar['net'] ?? 0)), 2);
            if ($earnings_remaining <= 0) continue;

            $target_ts = (int)($shipment_time_map[$target_sid] ?? (strtotime((string)($ar['delivered_at'] ?? $ar['created_at'] ?? '')) ?: 0));

            foreach ($debit_queue as $dq_idx => $dq) {
                if ($earnings_remaining <= 0) break;

                $source_sid = (int)($dq['shipment_id'] ?? 0);
                $source_rem = round((float)($dq['remaining'] ?? 0), 2);

                if ($source_sid <= 0 || $source_rem <= 0) {
                    continue;
                }

                $source_ts = (int)($shipment_time_map[$source_sid] ?? 0);

                // Only later innocent shipments may offset an earlier guilty shipment.
                if (
                    $target_sid === $source_sid ||
                    isset($guilty_shipment_ids[$target_sid]) ||
                    ($source_ts > 0 && $target_ts > 0 && $target_ts < $source_ts)
                ) {
                    continue;
                }

                $applied = round(min($earnings_remaining, $source_rem), 2);
                if ($applied <= 0) {
                    continue;
                }

                if (!isset($card_recovery_by_shipment[$target_sid])) {
                    $card_recovery_by_shipment[$target_sid] = 0.0;
                }
                $card_recovery_by_shipment[$target_sid] += $applied;
                $card_recovery_by_shipment[$target_sid] = round($card_recovery_by_shipment[$target_sid], 2);

                if (!isset($card_recovery_source_by_shipment[$target_sid])) {
                    $card_recovery_source_by_shipment[$target_sid] = $source_sid;
                }

                if (!isset($card_recovery_sources_by_shipment[$target_sid])) {
                    $card_recovery_sources_by_shipment[$target_sid] = [];
                }
                if (!isset($card_recovery_sources_by_shipment[$target_sid][$source_sid])) {
                    $card_recovery_sources_by_shipment[$target_sid][$source_sid] = 0.0;
                }
                $card_recovery_sources_by_shipment[$target_sid][$source_sid] += $applied;
                $card_recovery_sources_by_shipment[$target_sid][$source_sid] = round($card_recovery_sources_by_shipment[$target_sid][$source_sid], 2);

                if (!isset($source_recovery_targets_by_shipment[$source_sid])) {
                    $source_recovery_targets_by_shipment[$source_sid] = [];
                }
                if (!isset($source_recovery_targets_by_shipment[$source_sid][$target_sid])) {
                    $source_recovery_targets_by_shipment[$source_sid][$target_sid] = 0.0;
                }
                $source_recovery_targets_by_shipment[$source_sid][$target_sid] += $applied;
                $source_recovery_targets_by_shipment[$source_sid][$target_sid] = round($source_recovery_targets_by_shipment[$source_sid][$target_sid], 2);

                // allocator-time scar write (Level 4.5): persist the relationship when it is known with certainty
                $graph_record_edge($source_sid, $target_sid, $source_recovery_targets_by_shipment[$source_sid][$target_sid]);

                $earnings_remaining = round($earnings_remaining - $applied, 2);
                $debit_queue[$dq_idx]['remaining'] = round($source_rem - $applied, 2);
            }
        }

        // Preserve the live allocator preview before any historical graph / trace
        // normalization runs. These live maps are the only trustworthy source for
        // CURRENT wallet deductions while debit exposure is still open.
        $live_preview_recovery_by_target_shipment = $card_recovery_by_shipment;
        $live_preview_recovery_sources_by_target_shipment = $card_recovery_sources_by_shipment;
        $live_preview_first_source_by_target_shipment = $card_recovery_source_by_shipment;
        $live_preview_recovery_targets_by_source_shipment = $source_recovery_targets_by_shipment;

        // Historical recovery truth:
        // once offset has actually happened in ledger, preserve it on the shipment card
        // even after later payout / refresh / debit queue depletion.
        $historical_paid_offset_by_shipment = [];
        $historical_paid_source_ids_by_shipment = [];
        $historical_paid_offset_rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT shipment_id, net, meta, note, delivered_at, created_at, id
                 FROM {$lt}
                 WHERE vendor_id = %d
                   AND state = 'paid'
                   AND net > 0
                 ORDER BY id ASC",
                $uid
            ),
            ARRAY_A
        );

        if (is_array($historical_paid_offset_rows)) {
            foreach ($historical_paid_offset_rows as $hr) {
                $hist_sid = (int)($hr['shipment_id'] ?? 0);
                $hist_net = round((float)($hr['net'] ?? 0), 2);
                if ($hist_sid <= 0 || $hist_net <= 0) continue;

                $hist_meta = json_decode((string)($hr['meta'] ?? ''), true);
                if (!is_array($hist_meta)) continue;

                $hist_mode = strtolower((string)($hist_meta['payout_mode'] ?? ''));
                if ($hist_mode !== 'offset') continue;

                if (!isset($historical_paid_offset_by_shipment[$hist_sid])) {
                    $historical_paid_offset_by_shipment[$hist_sid] = 0.0;
                }
                $historical_paid_offset_by_shipment[$hist_sid] += $hist_net;
                $historical_paid_offset_by_shipment[$hist_sid] = round($historical_paid_offset_by_shipment[$hist_sid], 2);

                $possible_source_ids = [];
                $collect_source_ids = function($node, $keyHint = '') use (&$collect_source_ids, &$possible_source_ids, $hist_sid) {
                    if (is_array($node)) {
                        foreach ($node as $k => $v) {
                            $collect_source_ids($v, is_string($k) ? strtolower($k) : '');
                        }
                        return;
                    }
                    $hint = strtolower((string)$keyHint);
                    if (preg_match('/(^|_)(source|debit|adjustment|offset)_shipment_id$/', $hint)) {
                        $sidv = (int)$node;
                        if ($sidv > 0 && $sidv !== $hist_sid) $possible_source_ids[$sidv] = true;
                        return;
                    }
                    if (preg_match('/(^|_)(source|debit|adjustment|offset)_shipment_ids$/', $hint)) {
                        if (is_string($node)) {
                            if (preg_match_all('/\d+/', $node, $m)) {
                                foreach (($m[0] ?? []) as $sidraw) {
                                    $sidv = (int)$sidraw;
                                    if ($sidv > 0 && $sidv !== $hist_sid) $possible_source_ids[$sidv] = true;
                                }
                            }
                        } elseif (is_numeric($node)) {
                            $sidv = (int)$node;
                            if ($sidv > 0 && $sidv !== $hist_sid) $possible_source_ids[$sidv] = true;
                        }
                        return;
                    }
                };
                foreach (['source_shipment_id','debit_shipment_id','offset_source_shipment_id','adjustment_source_shipment_id'] as $k) {
                    if (!empty($hist_meta[$k])) {
                        $sidv = (int)$hist_meta[$k];
                        if ($sidv > 0 && $sidv !== $hist_sid) $possible_source_ids[$sidv] = true;
                    }
                }
                if (!empty($hist_meta['source_shipment_ids']) && is_array($hist_meta['source_shipment_ids'])) {
                    foreach ($hist_meta['source_shipment_ids'] as $sidv) {
                        $sidv = (int)$sidv;
                        if ($sidv > 0 && $sidv !== $hist_sid) $possible_source_ids[$sidv] = true;
                    }
                }
                if (!empty($hist_meta['return_bridge']) && is_array($hist_meta['return_bridge']) && !empty($hist_meta['return_bridge']['source_shipment_id'])) {
                    $sidv = (int)$hist_meta['return_bridge']['source_shipment_id'];
                    if ($sidv > 0 && $sidv !== $hist_sid) $possible_source_ids[$sidv] = true;
                }
                $collect_source_ids($hist_meta);
                if (!$possible_source_ids && !empty($hr['note']) && is_string($hr['note'])) {
                    if (preg_match_all('/#?(\d{3,})/', $hr['note'], $m)) {
                        foreach (($m[1] ?? []) as $sidraw) {
                            $sidv = (int)$sidraw;
                            if ($sidv > 0 && $sidv !== $hist_sid) $possible_source_ids[$sidv] = true;
                        }
                    }
                }
                if (!isset($historical_paid_source_ids_by_shipment[$hist_sid])) {
                    $historical_paid_source_ids_by_shipment[$hist_sid] = [];
                }
                foreach (array_keys($possible_source_ids) as $sidv) {
                    $historical_paid_source_ids_by_shipment[$hist_sid][$sidv] = true;
                }
            }
        }

        // Reconstruct historical source relationships for already-cleared recovery cards.
        // This is display-only fallback when live allocator memory is gone and older paid rows
        // did not persist explicit source shipment ids in meta. Reconstruct per shipment-level
        // recovery amount, not per paid row, so mixed paid shipments keep their source chain.
        $historical_reconstructed_source_ids_by_shipment = [];
        $historical_reconstructed_targets_by_source_shipment = [];
        $historical_reversed_source_pool = [];
        foreach ($rows as $rr) {
            $sid = (int)($rr['shipment_id'] ?? 0);
            $state = strtolower((string)($rr['state'] ?? ''));
            if ($sid <= 0 || !in_array($state, ['reversed','debit','source','mixed'], true)) continue;

            $source_amount = 0.0;
            $meta_raw = (string)($rr['meta'] ?? '');
            if ($meta_raw !== '') {
                $j = json_decode($meta_raw, true);
                if (is_array($j) && isset($j['return_bridge']['original_net'])) {
                    $source_amount = (float)$j['return_bridge']['original_net'];
                } elseif (is_array($j) && isset($j['trace_original_shipment_earnings'])) {
                    $source_amount = (float)$j['trace_original_shipment_earnings'];
                }
            }
            if ($source_amount <= 0) {
                $source_amount = abs((float)($rr['net'] ?? 0));
            }
            $source_amount = round(max(0.0, $source_amount), 2);
            if ($source_amount <= 0) continue;

            $source_ts = (int)($shipment_time_map[$sid] ?? (strtotime((string)($rr['delivered_at'] ?? $rr['created_at'] ?? '')) ?: 0));
            $historical_reversed_source_pool[] = [
                'shipment_id' => $sid,
                'remaining'   => $source_amount,
                'ts'          => $source_ts,
                'row_id'      => (int)($rr['id'] ?? 0),
            ];
        }
        usort($historical_reversed_source_pool, function($a, $b){
            $ats = (int)($a['ts'] ?? 0);
            $bts = (int)($b['ts'] ?? 0);
            if ($ats !== $bts) return $ats <=> $bts;
            return ((int)($a['row_id'] ?? 0)) <=> ((int)($b['row_id'] ?? 0));
        });

        $historical_paid_target_pool = [];
        foreach ($rows as $rr) {
            $sid = (int)($rr['shipment_id'] ?? 0);
            $state = strtolower((string)($rr['state'] ?? ''));
            if ($sid <= 0 || $state !== 'paid') continue;
            $recover_amt = round(max(0.0, (float)($historical_paid_offset_by_shipment[$sid] ?? 0)), 2);
            if ($recover_amt <= 0) continue;
            $target_ts = (int)($shipment_time_map[$sid] ?? (strtotime((string)($rr['delivered_at'] ?? $rr['created_at'] ?? '')) ?: 0));
            $historical_paid_target_pool[$sid] = [
                'shipment_id' => $sid,
                'remaining'   => $recover_amt,
                'ts'          => $target_ts,
                'row_id'      => (int)($rr['id'] ?? 0),
            ];
        }
        uasort($historical_paid_target_pool, function($a, $b){
            $ats = (int)($a['ts'] ?? 0);
            $bts = (int)($b['ts'] ?? 0);
            if ($ats !== $bts) return $ats <=> $bts;
            return ((int)($a['row_id'] ?? 0)) <=> ((int)($b['row_id'] ?? 0));
        });

        if ($historical_reversed_source_pool && $historical_paid_target_pool) {
            foreach ($historical_paid_target_pool as $hist_sid => $target) {
                $remaining_hist = round((float)($target['remaining'] ?? 0), 2);
                $target_ts = (int)($target['ts'] ?? 0);
                if ($remaining_hist <= 0) continue;

                foreach ($historical_reversed_source_pool as $idx => $src) {
                    if ($remaining_hist <= 0) break;
                    $src_sid = (int)($src['shipment_id'] ?? 0);
                    $src_rem = round((float)($src['remaining'] ?? 0), 2);
                    $src_ts  = (int)($src['ts'] ?? 0);
                    if ($src_sid <= 0 || $src_rem <= 0) continue;
                    if ($target_ts > 0 && $src_ts > 0 && $target_ts < $src_ts) continue;

                    $applied = round(min($remaining_hist, $src_rem), 2);
                    if ($applied <= 0) continue;

                    if (!isset($historical_reconstructed_source_ids_by_shipment[$hist_sid])) {
                        $historical_reconstructed_source_ids_by_shipment[$hist_sid] = [];
                    }
                    $historical_reconstructed_source_ids_by_shipment[$hist_sid][$src_sid] = true;

                    if (!isset($historical_reconstructed_targets_by_source_shipment[$src_sid])) {
                        $historical_reconstructed_targets_by_source_shipment[$src_sid] = [];
                    }
                    if (!isset($historical_reconstructed_targets_by_source_shipment[$src_sid][$hist_sid])) {
                        $historical_reconstructed_targets_by_source_shipment[$src_sid][$hist_sid] = 0.0;
                    }
                    $historical_reconstructed_targets_by_source_shipment[$src_sid][$hist_sid] += $applied;
                    $historical_reconstructed_targets_by_source_shipment[$src_sid][$hist_sid] = round($historical_reconstructed_targets_by_source_shipment[$src_sid][$hist_sid], 2);

                    $historical_reversed_source_pool[$idx]['remaining'] = round($src_rem - $applied, 2);
                    $remaining_hist = round($remaining_hist - $applied, 2);
                }
            }
        }

        // Build a permanent trace layer (Option A) plus reconstruction fallback (Option B).
        // This does NOT change allocator behavior or card math. It only strengthens history.
        $trace_source_ids_by_target_shipment = [];
        $trace_targets_by_source_shipment = [];

        $trace_add_source = function(array &$map, int $target_sid, int $source_sid): void {
            if ($target_sid <= 0 || $source_sid <= 0 || $target_sid === $source_sid) return;
            if (!isset($map[$target_sid])) $map[$target_sid] = [];
            $map[$target_sid][$source_sid] = true;
        };
        $trace_add_target = function(array &$map, int $source_sid, int $target_sid, float $amt) use ($graph_record_edge): void {
            $amt = round((float)$amt, 2);
            if ($source_sid <= 0 || $target_sid <= 0 || $source_sid === $target_sid || $amt <= 0) return;
            if (!isset($map[$source_sid])) $map[$source_sid] = [];

            // IMPORTANT:
            // Multiple historical builders can discover the same source->target edge
            // during the same render (allocator, reconstructed history, ledger scars,
            // persisted graph, backfill). This layer must NEVER sum duplicate discoveries
            // of the same edge, or the modal will inflate beyond the original debit.
            // Treat the pair as a unique edge and keep the strongest exact amount seen.
            $prev = round((float)($map[$source_sid][$target_sid] ?? 0), 2);
            $next = max($prev, $amt);
            if (abs($next - $prev) > 0.009) {
                $map[$source_sid][$target_sid] = $next;
            } else {
                $map[$source_sid][$target_sid] = $prev;
            }

            $graph_record_edge($source_sid, $target_sid, $map[$source_sid][$target_sid]);
        };

        // Seed from live allocator memory.
        foreach ((array)$card_recovery_sources_by_shipment as $target_sid => $sources) {
            $target_sid = (int)$target_sid;
            foreach ((array)$sources as $source_sid => $amt) {
                $source_sid = (int)$source_sid;
                $trace_add_source($trace_source_ids_by_target_shipment, $target_sid, $source_sid);
            }
        }
        foreach ((array)$source_recovery_targets_by_shipment as $source_sid => $targets) {
            $source_sid = (int)$source_sid;
            foreach ((array)$targets as $target_sid => $amt) {
                $trace_add_target($trace_targets_by_source_shipment, $source_sid, (int)$target_sid, (float)$amt);
            }
        }

        // Seed from explicit historical paid-row source ids.
        foreach ((array)$historical_paid_source_ids_by_shipment as $target_sid => $sources) {
            $target_sid = (int)$target_sid;
            foreach ((array)$sources as $source_sid => $_) {
                $trace_add_source($trace_source_ids_by_target_shipment, $target_sid, (int)$source_sid);
            }
        }

        // Seed from reconstructed history.
        foreach ((array)$historical_reconstructed_source_ids_by_shipment as $target_sid => $sources) {
            $target_sid = (int)$target_sid;
            foreach ((array)$sources as $source_sid => $_) {
                $trace_add_source($trace_source_ids_by_target_shipment, $target_sid, (int)$source_sid);
            }
        }
        foreach ((array)$historical_reconstructed_targets_by_source_shipment as $source_sid => $targets) {
            $source_sid = (int)$source_sid;
            foreach ((array)$targets as $target_sid => $amt) {
                $trace_add_target($trace_targets_by_source_shipment, $source_sid, (int)$target_sid, (float)$amt);
            }
        }

        // Seed from already-persisted scars in ledger meta if they exist.
        foreach ((array)$rows as $rr) {
            $sid = (int)($rr['shipment_id'] ?? 0);
            if ($sid <= 0) continue;
            $mraw = (string)($rr['meta'] ?? '');
            if ($mraw === '') continue;
            $mm = json_decode($mraw, true);
            if (!is_array($mm)) continue;

            foreach (['trace_source_shipment_ids','source_shipment_ids'] as $k) {
                if (!empty($mm[$k]) && is_array($mm[$k])) {
                    foreach ($mm[$k] as $source_sid) {
                        $trace_add_source($trace_source_ids_by_target_shipment, $sid, (int)$source_sid);
                    }
                }
            }
            foreach (['trace_source_shipment_id','source_shipment_id','debit_shipment_id','offset_source_shipment_id','adjustment_source_shipment_id'] as $k) {
                if (!empty($mm[$k])) {
                    $trace_add_source($trace_source_ids_by_target_shipment, $sid, (int)$mm[$k]);
                }
            }
            foreach (['trace_affected_recovery_shipments','affected_recovery_shipments'] as $k) {
                if (!empty($mm[$k]) && is_array($mm[$k])) {
                    foreach ($mm[$k] as $rowv) {
                        if (!is_array($rowv)) continue;
                        $trace_add_target($trace_targets_by_source_shipment, $sid, (int)($rowv['shipment_id'] ?? 0), (float)($rowv['amount'] ?? 0));
                    }
                }
            }
        }


        // Seed from vendor-scoped persisted graph store (strongest historical scar source).
        foreach ((array)($persisted_trace_graph['targets'] ?? []) as $target_sid => $node) {
            $target_sid = (int)$target_sid;
            foreach ((array)($node['sources'] ?? []) as $source_sid => $amt) {
                $source_sid = (int)$source_sid;
                $amt = round((float)$amt, 2);
                if ($source_sid <= 0 || $target_sid <= 0 || $amt <= 0) continue;
                $trace_add_source($trace_source_ids_by_target_shipment, $target_sid, $source_sid);
                $trace_add_target($trace_targets_by_source_shipment, $source_sid, $target_sid, $amt);
            }
        }
        // Invert any known source->target scars back into target->source scars.
        foreach ((array)$trace_targets_by_source_shipment as $source_sid => $targets) {
            $source_sid = (int)$source_sid;
            foreach ((array)$targets as $target_sid => $amt) {
                $trace_add_source($trace_source_ids_by_target_shipment, (int)$target_sid, $source_sid);
            }
        }

        // Write-through backfill:
        // If a target shipment still has a known recovery amount but no persisted/live/reconstructed source chain,
        // rebuild the missing graph from remaining historical source capacity and immediately treat that result
        // as first-class trace data for this render so future meta persistence can imprint it permanently.
        $source_capacity_by_shipment = [];
        $source_ts_by_shipment = [];
        foreach ((array)$rows as $rr) {
            $sid = (int)($rr['shipment_id'] ?? 0);
            $state = strtolower((string)($rr['state'] ?? ''));
            if ($sid <= 0 || !in_array($state, ['reversed','debit','source','mixed'], true)) continue;

            $orig = 0.0;
            $mraw = (string)($rr['meta'] ?? '');
            if ($mraw !== '') {
                $mm = json_decode($mraw, true);
                if (is_array($mm)) {
                    if (!empty($mm['trace_original_shipment_earnings'])) {
                        $orig = (float)$mm['trace_original_shipment_earnings'];
                    } elseif (!empty($mm['return_bridge']) && is_array($mm['return_bridge']) && !empty($mm['return_bridge']['original_net'])) {
                        $orig = (float)$mm['return_bridge']['original_net'];
                    }
                }
            }
            if ($orig <= 0) {
                $orig = abs((float)($rr['net'] ?? 0));
            }
            $orig = round(max(0.0, $orig), 2);
            if ($orig <= 0) continue;

            if (!isset($source_capacity_by_shipment[$sid]) || $orig > $source_capacity_by_shipment[$sid]) {
                $source_capacity_by_shipment[$sid] = $orig;
            }
            $source_ts_by_shipment[$sid] = (int)($shipment_time_map[$sid] ?? (strtotime((string)($rr['delivered_at'] ?? $rr['created_at'] ?? '')) ?: 0));
        }

        // Subtract what is already known from trace_targets_by_source_shipment so we only backfill the missing scar.
        foreach ((array)$trace_targets_by_source_shipment as $source_sid => $targets) {
            $source_sid = (int)$source_sid;
            foreach ((array)$targets as $target_sid => $amt) {
                $amt = round((float)$amt, 2);
                if ($amt <= 0 || !isset($source_capacity_by_shipment[$source_sid])) continue;
                $source_capacity_by_shipment[$source_sid] = round(max(0.0, (float)$source_capacity_by_shipment[$source_sid] - $amt), 2);
            }
        }

        $known_target_alloc_by_shipment = [];
        foreach ((array)$trace_targets_by_source_shipment as $source_sid => $targets) {
            foreach ((array)$targets as $target_sid => $amt) {
                $target_sid = (int)$target_sid;
                $amt = round((float)$amt, 2);
                if ($target_sid <= 0 || $amt <= 0) continue;
                if (!isset($known_target_alloc_by_shipment[$target_sid])) {
                    $known_target_alloc_by_shipment[$target_sid] = 0.0;
                }
                $known_target_alloc_by_shipment[$target_sid] += $amt;
                $known_target_alloc_by_shipment[$target_sid] = round($known_target_alloc_by_shipment[$target_sid], 2);
            }
        }

        $target_backfill_queue = [];
        foreach ((array)$historical_paid_offset_by_shipment as $target_sid => $need_amt) {
            $target_sid = (int)$target_sid;
            $need_amt = round((float)$need_amt, 2);
            if ($target_sid <= 0 || $need_amt <= 0) continue;

            $already = round((float)($known_target_alloc_by_shipment[$target_sid] ?? 0), 2);
            $remaining = round(max(0.0, $need_amt - $already), 2);
            if ($remaining <= 0) continue;

            $target_backfill_queue[$target_sid] = [
                'shipment_id' => $target_sid,
                'remaining'   => $remaining,
                'ts'          => (int)($shipment_time_map[$target_sid] ?? 0),
            ];
        }

        uasort($target_backfill_queue, function($a, $b){
            $ats = (int)($a['ts'] ?? 0);
            $bts = (int)($b['ts'] ?? 0);
            if ($ats !== $bts) return $ats <=> $bts;
            return ((int)($a['shipment_id'] ?? 0)) <=> ((int)($b['shipment_id'] ?? 0));
        });

        $source_backfill_pool = [];
        foreach ((array)$source_capacity_by_shipment as $source_sid => $remaining) {
            $source_sid = (int)$source_sid;
            $remaining = round((float)$remaining, 2);
            if ($source_sid <= 0 || $remaining <= 0) continue;
            $source_backfill_pool[$source_sid] = [
                'shipment_id' => $source_sid,
                'remaining'   => $remaining,
                'ts'          => (int)($source_ts_by_shipment[$source_sid] ?? 0),
            ];
        }

        uasort($source_backfill_pool, function($a, $b){
            $ats = (int)($a['ts'] ?? 0);
            $bts = (int)($b['ts'] ?? 0);
            if ($ats !== $bts) return $ats <=> $bts;
            return ((int)($a['shipment_id'] ?? 0)) <=> ((int)($b['shipment_id'] ?? 0));
        });

        if ($target_backfill_queue && $source_backfill_pool) {
            foreach ($target_backfill_queue as $target_sid => $target) {
                $remaining = round((float)($target['remaining'] ?? 0), 2);
                if ($remaining <= 0) continue;

                // Prefer chronological candidates first; if none fit, fall back to any remaining source
                // so historical scars are still imprinted for already-cleared legacy rows.
                $passes = ['chronological', 'any'];
                foreach ($passes as $pass) {
                    if ($remaining <= 0) break;

                    foreach ($source_backfill_pool as $source_sid => $src) {
                        if ($remaining <= 0) break;
                        $source_sid = (int)$source_sid;
                        $src_rem = round((float)($src['remaining'] ?? 0), 2);
                        if ($source_sid <= 0 || $src_rem <= 0 || $source_sid === (int)$target_sid) continue;

                        $target_ts = (int)($target['ts'] ?? 0);
                        $src_ts = (int)($src['ts'] ?? 0);
                        if ($pass === 'chronological' && $target_ts > 0 && $src_ts > 0 && $target_ts < $src_ts) {
                            continue;
                        }

                        $applied = round(min($remaining, $src_rem), 2);
                        if ($applied <= 0) continue;

                        $trace_add_source($trace_source_ids_by_target_shipment, (int)$target_sid, $source_sid);
                        $trace_add_target($trace_targets_by_source_shipment, $source_sid, (int)$target_sid, $applied);

                        $known_target_alloc_by_shipment[(int)$target_sid] = round((float)($known_target_alloc_by_shipment[(int)$target_sid] ?? 0) + $applied, 2);
                        $source_backfill_pool[$source_sid]['remaining'] = round($src_rem - $applied, 2);
                        $remaining = round($remaining - $applied, 2);
                    }
                }
            }

            // Re-invert after write-through backfill so every target gets its source ids for this same render.
            foreach ((array)$trace_targets_by_source_shipment as $source_sid => $targets) {
                $source_sid = (int)$source_sid;
                foreach ((array)$targets as $target_sid => $amt) {
                    $trace_add_source($trace_source_ids_by_target_shipment, (int)$target_sid, $source_sid);
                }
            }
        }

        // Build persistent item-detail scars for both source and target shipment history.
        $trace_return_rows_by_source_shipment = [];
        foreach ((array)$rows as $rr) {
            $sid = (int)($rr['shipment_id'] ?? 0);
            $state = strtolower((string)($rr['state'] ?? ''));
            if ($sid <= 0 || !in_array($state, ['reversed','debit','source','mixed'], true)) continue;
            $trace_return_rows_by_source_shipment[$sid] = $this->build_deduction_explain_for_shipments([$sid]);
        }
        $trace_return_rows_by_target_shipment = [];
        foreach ((array)$trace_source_ids_by_target_shipment as $target_sid => $sources) {
            $target_sid = (int)$target_sid;
            $src_ids = array_values(array_map('intval', array_keys((array)$sources)));
            $src_ids = array_values(array_filter($src_ids, fn($v) => $v > 0 && $v !== $target_sid));
            if (!$src_ids) continue;
            $trace_return_rows_by_target_shipment[$target_sid] = $this->build_deduction_explain_for_shipments($src_ids);
        }

        // Merge persisted item-detail scars from the vendor graph if live rebuild returned nothing.
        foreach ((array)($persisted_trace_graph['sources'] ?? []) as $source_sid => $node) {
            $source_sid = (int)$source_sid;
            if ($source_sid > 0 && empty($trace_return_rows_by_source_shipment[$source_sid]) && !empty($node['rows']) && is_array($node['rows'])) {
                $trace_return_rows_by_source_shipment[$source_sid] = $normalize_trace_rows($node['rows']);
            }
        }
        foreach ((array)($persisted_trace_graph['targets'] ?? []) as $target_sid => $node) {
            $target_sid = (int)$target_sid;
            if ($target_sid > 0 && empty($trace_return_rows_by_target_shipment[$target_sid]) && !empty($node['rows']) && is_array($node['rows'])) {
                $trace_return_rows_by_target_shipment[$target_sid] = $normalize_trace_rows($node['rows']);
            }
        }

        // Feed rebuilt rows back into the vendor graph so future reloads do not lose them.
        foreach ((array)$trace_targets_by_source_shipment as $source_sid => $targets) {
            $source_sid = (int)$source_sid;
            $rowsForSource = (array)($trace_return_rows_by_source_shipment[$source_sid] ?? []);
            foreach ((array)$targets as $target_sid => $amt) {
                $graph_record_edge($source_sid, (int)$target_sid, (float)$amt, $rowsForSource);
            }
        }

        // Build normalized full historical offset snapshots (Option A primary truth).
        // These snapshots are in-memory for this render and also get persisted into ledger meta below,
        // so future reloads can rebuild from a single authoritative scar map instead of only live allocator state.
        $trace_snapshot_by_target_shipment = [];
        foreach ((array)$trace_source_ids_by_target_shipment as $target_sid => $sources) {
            $target_sid = (int)$target_sid;
            if ($target_sid <= 0) continue;
            $source_ids = array_values(array_map('intval', array_keys((array)$sources)));
            $source_ids = array_values(array_filter($source_ids, function($v) use ($target_sid){ return (int)$v > 0 && (int)$v !== (int)$target_sid; }));
            if (!$source_ids) continue;
            sort($source_ids, SORT_NUMERIC);
            $source_amounts = [];
            foreach ($source_ids as $source_sid) {
                $amt = round((float)($trace_targets_by_source_shipment[$source_sid][$target_sid] ?? 0), 2);
                if ($amt > 0) {
                    $source_amounts[(string)$source_sid] = $amt;
                }
            }
            $trace_snapshot_by_target_shipment[$target_sid] = [
                'source_shipment_ids' => $source_ids,
                'source_shipment_amounts' => $source_amounts,
                'return_rows' => array_values((array)($trace_return_rows_by_target_shipment[$target_sid] ?? [])),
            ];
        }

        $trace_snapshot_by_source_shipment = [];
        foreach ((array)$trace_targets_by_source_shipment as $source_sid => $targets) {
            $source_sid = (int)$source_sid;
            if ($source_sid <= 0) continue;
            $target_rows = [];
            foreach ((array)$targets as $target_sid => $amt) {
                $target_sid = (int)$target_sid;
                $amt = round((float)$amt, 2);
                if ($target_sid <= 0 || $target_sid === $source_sid || $amt <= 0) continue;
                $target_rows[] = [
                    'shipment_id' => $target_sid,
                    'amount'      => $amt,
                ];
            }
            if (!$target_rows) continue;
            usort($target_rows, function($a, $b){ return ((int)$a['shipment_id']) <=> ((int)$b['shipment_id']); });
            $trace_snapshot_by_source_shipment[$source_sid] = [
                'affected_recovery_shipments' => $target_rows,
                'return_rows' => array_values((array)($trace_return_rows_by_source_shipment[$source_sid] ?? [])),
            ];
        }

        // Read-only wallet path: historical trace persistence is disabled during render.
        // Any trace/meta backfill must run in an explicit repair, migration, or
        // projection command path instead of a GET/render request.
        $persist_trace_meta = static function(int $shipment_id, array $states, array $patch): void {
            // Intentionally no-op in read-only mode.
        };

        foreach ((array)$trace_snapshot_by_target_shipment as $target_sid => $snap) {
            $target_sid = (int)$target_sid;
            $source_ids = array_values(array_map('intval', (array)($snap['source_shipment_ids'] ?? [])));
            if (!$source_ids) continue;
            $persist_trace_meta($target_sid, ['paid','available','pending','hold'], [
                'trace_snapshot_version'      => 1,
                'trace_source_shipment_ids'  => $source_ids,
                'source_shipment_ids'        => $source_ids,
                'trace_source_shipment_id'   => (int)($source_ids[0] ?? 0),
                'source_shipment_id'         => (int)($source_ids[0] ?? 0),
                'trace_source_shipment_amounts' => (array)($snap['source_shipment_amounts'] ?? []),
                'trace_return_rows'          => (array)($snap['return_rows'] ?? []),
                'trace_historical_offset_snapshot' => [
                    'kind' => 'target',
                    'source_shipment_ids' => $source_ids,
                    'source_shipment_amounts' => (array)($snap['source_shipment_amounts'] ?? []),
                    'return_rows' => (array)($snap['return_rows'] ?? []),
                ],
            ]);
        }

        foreach ((array)$trace_snapshot_by_source_shipment as $source_sid => $snap) {
            $source_sid = (int)$source_sid;
            $target_rows = array_values((array)($snap['affected_recovery_shipments'] ?? []));
            if (!$target_rows) continue;
            $persist_trace_meta($source_sid, ['reversed','debit','paid','available','pending','hold'], [
                'trace_snapshot_version'           => 1,
                'trace_affected_recovery_shipments' => $target_rows,
                'affected_recovery_shipments'       => $target_rows,
                'trace_return_rows'                 => (array)($snap['return_rows'] ?? []),
                'trace_historical_offset_snapshot'  => [
                    'kind' => 'source',
                    'affected_recovery_shipments' => $target_rows,
                    'return_rows' => (array)($snap['return_rows'] ?? []),
                ],
            ]);
        }


        // Rebuild the persisted graph from the final normalized source->target map for THIS render.
        // This purges historical duplicate inflation from older versions where the same edge could be
        // appended more than once by different trace builders. After this point the graph becomes a
        // clean exact mirror of the final trace map, not an accumulation bucket.
        $rebuilt_trace_graph = [
            'targets' => [],
            'sources' => [],
        ];
        foreach ((array)$trace_targets_by_source_shipment as $source_sid => $targets) {
            $source_sid = (int)$source_sid;
            if ($source_sid <= 0) continue;
            foreach ((array)$targets as $target_sid => $amt_raw) {
                $target_sid = (int)$target_sid;
                $amt = round((float)$amt_raw, 2);
                if ($target_sid <= 0 || $target_sid === $source_sid || $amt <= 0) continue;

                if (!isset($rebuilt_trace_graph['sources'][$source_sid])) {
                    $rebuilt_trace_graph['sources'][$source_sid] = ['targets' => [], 'rows' => []];
                }
                if (!isset($rebuilt_trace_graph['targets'][$target_sid])) {
                    $rebuilt_trace_graph['targets'][$target_sid] = ['sources' => [], 'rows' => []];
                }

                $rebuilt_trace_graph['sources'][$source_sid]['targets'][$target_sid] = $amt;
                $rebuilt_trace_graph['targets'][$target_sid]['sources'][$source_sid] = $amt;
            }
        }
        foreach ((array)$trace_return_rows_by_source_shipment as $source_sid => $rowsv) {
            $source_sid = (int)$source_sid;
            if ($source_sid <= 0 || empty($rebuilt_trace_graph['sources'][$source_sid])) continue;
            $rebuilt_trace_graph['sources'][$source_sid]['rows'] = $normalize_trace_rows((array)$rowsv);
        }
        foreach ((array)$trace_return_rows_by_target_shipment as $target_sid => $rowsv) {
            $target_sid = (int)$target_sid;
            if ($target_sid <= 0 || empty($rebuilt_trace_graph['targets'][$target_sid])) continue;
            $rebuilt_trace_graph['targets'][$target_sid]['rows'] = $normalize_trace_rows((array)$rowsv);
        }

        // Keep the graph symmetric and deterministic so future reloads cannot revive old inflated values.
        foreach ((array)$rebuilt_trace_graph['sources'] as $source_sid => $node) {
            if (!empty($node['targets']) && is_array($node['targets'])) {
                ksort($rebuilt_trace_graph['sources'][$source_sid]['targets'], SORT_NUMERIC);
            }
        }
        foreach ((array)$rebuilt_trace_graph['targets'] as $target_sid => $node) {
            if (!empty($node['sources']) && is_array($node['sources'])) {
                ksort($rebuilt_trace_graph['targets'][$target_sid]['sources'], SORT_NUMERIC);
            }
        }

        if ($persisted_trace_graph !== $rebuilt_trace_graph) {
            $persisted_trace_graph = $rebuilt_trace_graph;
            $trace_graph_dirty = true;
        }

        if ($trace_graph_dirty) {
            // Read-only wallet path: do not persist trace graph caches during render.
            // Persist from an explicit command/projection flow if needed.
        }

        // ------------------------------------------------------------
        // Canonical render truth collapse:
        // Persisted graph remains the historical/audit backbone, BUT
        // cards + modal + tiles must prefer the live allocator maps
        // when they exist. Otherwise stale historical max-edges can
        // keep rendering old amounts after dynamic reallocation.
        // ------------------------------------------------------------
        $live_recovery_sources_by_target_shipment = [];
        foreach ((array)$card_recovery_sources_by_shipment as $target_sid => $srcs) {
            $target_sid = (int)$target_sid;
            if ($target_sid <= 0 || !is_array($srcs)) continue;

            foreach ((array)$srcs as $source_sid => $amt_raw) {
                $source_sid = (int)$source_sid;
                $amt = round((float)$amt_raw, 2);
                if ($source_sid <= 0 || $source_sid === $target_sid || $amt <= 0) continue;
                if (!isset($live_recovery_sources_by_target_shipment[$target_sid])) {
                    $live_recovery_sources_by_target_shipment[$target_sid] = [];
                }
                $live_recovery_sources_by_target_shipment[$target_sid][$source_sid] = $amt;
            }

            if (!empty($live_recovery_sources_by_target_shipment[$target_sid])) {
                ksort($live_recovery_sources_by_target_shipment[$target_sid], SORT_NUMERIC);
            }
        }

        $live_recovery_targets_by_source_shipment = [];
        foreach ((array)$source_recovery_targets_by_shipment as $source_sid => $tgts) {
            $source_sid = (int)$source_sid;
            if ($source_sid <= 0 || !is_array($tgts)) continue;

            foreach ((array)$tgts as $target_sid => $amt_raw) {
                $target_sid = (int)$target_sid;
                $amt = round((float)$amt_raw, 2);
                if ($target_sid <= 0 || $target_sid === $source_sid || $amt <= 0) continue;
                if (!isset($live_recovery_targets_by_source_shipment[$source_sid])) {
                    $live_recovery_targets_by_source_shipment[$source_sid] = [];
                }
                $live_recovery_targets_by_source_shipment[$source_sid][$target_sid] = $amt;
            }

            if (!empty($live_recovery_targets_by_source_shipment[$source_sid])) {
                ksort($live_recovery_targets_by_source_shipment[$source_sid], SORT_NUMERIC);
            }
        }

        $canonical_recovery_by_target_shipment = [];
        $canonical_recovery_sources_by_target_shipment = [];
        $canonical_recovery_targets_by_source_shipment = [];
        $canonical_first_source_by_target_shipment = [];

        foreach ((array)($persisted_trace_graph['targets'] ?? []) as $target_sid_raw => $node) {
            $target_sid = (int)$target_sid_raw;
            if ($target_sid <= 0 || !is_array($node)) continue;

            $sum = 0.0;
            $srcs = [];
            foreach ((array)($node['sources'] ?? []) as $source_sid_raw => $amt_raw) {
                $source_sid = (int)$source_sid_raw;
                $amt = round((float)$amt_raw, 2);
                if ($source_sid <= 0 || $source_sid === $target_sid || $amt <= 0) continue;
                $srcs[$source_sid] = $amt;
                $sum += $amt;
                $sum = round($sum, 2);
            }

            if ($srcs) {
                ksort($srcs, SORT_NUMERIC);
                $canonical_recovery_sources_by_target_shipment[$target_sid] = $srcs;
                $canonical_recovery_by_target_shipment[$target_sid] = round($sum, 2);
                $canonical_first_source_by_target_shipment[$target_sid] = (int)array_key_first($srcs);
            }
        }

        foreach ((array)($persisted_trace_graph['sources'] ?? []) as $source_sid_raw => $node) {
            $source_sid = (int)$source_sid_raw;
            if ($source_sid <= 0 || !is_array($node)) continue;

            $tgts = [];
            foreach ((array)($node['targets'] ?? []) as $target_sid_raw => $amt_raw) {
                $target_sid = (int)$target_sid_raw;
                $amt = round((float)$amt_raw, 2);
                if ($target_sid <= 0 || $target_sid === $source_sid || $amt <= 0) continue;
                $tgts[$target_sid] = $amt;
            }

            if ($tgts) {
                ksort($tgts, SORT_NUMERIC);
                $canonical_recovery_targets_by_source_shipment[$source_sid] = $tgts;
            }
        }

        foreach ((array)$live_recovery_sources_by_target_shipment as $target_sid => $srcs) {
            $target_sid = (int)$target_sid;
            if ($target_sid <= 0 || !$srcs) continue;

            $canonical_recovery_sources_by_target_shipment[$target_sid] = [];
            $sum = 0.0;
            foreach ((array)$srcs as $source_sid => $amt_raw) {
                $source_sid = (int)$source_sid;
                $amt = round((float)$amt_raw, 2);
                if ($source_sid <= 0 || $source_sid === $target_sid || $amt <= 0) continue;
                $canonical_recovery_sources_by_target_shipment[$target_sid][$source_sid] = $amt;
                $sum += $amt;
                $sum = round($sum, 2);
            }

            if (!empty($canonical_recovery_sources_by_target_shipment[$target_sid])) {
                ksort($canonical_recovery_sources_by_target_shipment[$target_sid], SORT_NUMERIC);
                $canonical_recovery_by_target_shipment[$target_sid] = round($sum, 2);
                $canonical_first_source_by_target_shipment[$target_sid] = (int)array_key_first($canonical_recovery_sources_by_target_shipment[$target_sid]);
            } else {
                unset($canonical_recovery_sources_by_target_shipment[$target_sid], $canonical_recovery_by_target_shipment[$target_sid], $canonical_first_source_by_target_shipment[$target_sid]);
            }
        }

        foreach ((array)$live_recovery_targets_by_source_shipment as $source_sid => $tgts) {
            $source_sid = (int)$source_sid;
            if ($source_sid <= 0 || !$tgts) continue;

            $canonical_recovery_targets_by_source_shipment[$source_sid] = [];
            foreach ((array)$tgts as $target_sid => $amt_raw) {
                $target_sid = (int)$target_sid;
                $amt = round((float)$amt_raw, 2);
                if ($target_sid <= 0 || $target_sid === $source_sid || $amt <= 0) continue;
                $canonical_recovery_targets_by_source_shipment[$source_sid][$target_sid] = $amt;
            }

            if (!empty($canonical_recovery_targets_by_source_shipment[$source_sid])) {
                ksort($canonical_recovery_targets_by_source_shipment[$source_sid], SORT_NUMERIC);
            } else {
                unset($canonical_recovery_targets_by_source_shipment[$source_sid]);
            }
        }

        // -----------------------------------------------------------------
        // Historical blended contributor normalization (display-only):
        // Old contributor rows may still remember a whole source shipment total
        // even after newer slice-aware rows have already claimed exact sibling
        // portions. Recalculate a conservative, non-overlapping source->target
        // attribution for rendering so one contributor card does not keep a
        // pooled amount that really belongs to multiple targets/sources.
        // -----------------------------------------------------------------
        $row_state_by_shipment = [];
        $target_source_count_by_shipment = [];
        $source_slice_amounts_by_shipment = [];
        foreach ((array)$rows as $rr) {
            $sid = (int)($rr['shipment_id'] ?? 0);
            if ($sid <= 0) continue;
            $row_state_by_shipment[$sid] = strtolower((string)($rr['state'] ?? ''));

            $mraw = (string)($rr['meta'] ?? '');
            $mm = ($mraw !== '') ? json_decode($mraw, true) : [];
            if (!is_array($mm)) $mm = [];

            $source_count = 0;
            if (!empty($mm['trace_source_shipment_amounts']) && is_array($mm['trace_source_shipment_amounts'])) {
                foreach ((array)$mm['trace_source_shipment_amounts'] as $raw_source_sid => $raw_amt) {
                    if ((int)$raw_source_sid > 0 && round((float)$raw_amt, 2) > 0) $source_count++;
                }
            }
            if (!$source_count && !empty($mm['trace_source_shipment_ids']) && is_array($mm['trace_source_shipment_ids'])) {
                foreach ((array)$mm['trace_source_shipment_ids'] as $raw_source_sid) {
                    if ((int)$raw_source_sid > 0) $source_count++;
                }
            }
            $target_source_count_by_shipment[$sid] = $source_count;

            if (!in_array(strtolower((string)($rr['state'] ?? '')), ['reversed','debit','source','mixed'], true)) {
                continue;
            }

            $slices = [];
            if (!empty($mm['financial_slices']) && is_array($mm['financial_slices'])) {
                $seen_slice_ids = [];
                foreach ((array)$mm['financial_slices'] as $fs) {
                    if (!is_array($fs)) continue;
                    $slice_id = (string)($fs['slice_id'] ?? '');
                    $amt = round((float)($fs['amount'] ?? 0), 2);
                    if ($amt <= 0) continue;
                    $key = $slice_id !== '' ? $slice_id : ('order_item:' . (int)($fs['order_item_id'] ?? 0) . '|amt:' . number_format($amt, 2, '.', ''));
                    if (isset($seen_slice_ids[$key])) continue;
                    $seen_slice_ids[$key] = true;
                    $slices[] = ['slice_id' => $slice_id, 'amount' => $amt];
                }
            }
            if (!$slices) {
                $amt = round(abs((float)($rr['net'] ?? 0)), 2);
                if ($amt > 0) $slices[] = ['slice_id' => 'legacy:' . $sid, 'amount' => $amt];
            }
            if ($slices) {
                $source_slice_amounts_by_shipment[$sid] = $slices;
            }
        }

        $normalized_targets_by_source = [];
        foreach ((array)$canonical_recovery_targets_by_source_shipment as $source_sid => $tgts) {
            $source_sid = (int)$source_sid;
            if ($source_sid <= 0 || empty($source_slice_amounts_by_shipment[$source_sid]) || !is_array($tgts)) continue;

            $remaining_slices = [];
            foreach ((array)$source_slice_amounts_by_shipment[$source_sid] as $slice) {
                $amt = round((float)($slice['amount'] ?? 0), 2);
                if ($amt > 0) $remaining_slices[] = $amt;
            }
            if (!$remaining_slices) continue;
            sort($remaining_slices, SORT_NUMERIC);

            $raw_targets = [];
            foreach ((array)$tgts as $target_sid => $amt_raw) {
                $target_sid = (int)$target_sid;
                $amt = round((float)$amt_raw, 2);
                if ($target_sid <= 0 || $amt <= 0 || isset($guilty_shipment_ids[$target_sid])) continue;
                $raw_targets[$target_sid] = $amt;
            }
            if (!$raw_targets) continue;

            $claims = [];

            // First pass: rows already carrying multiple sources usually have the most
            // trustworthy explicit source amount; if one of those amounts matches a single
            // source slice exactly, claim that slice first.
            foreach ($raw_targets as $target_sid => $amt) {
                $source_count = (int)($target_source_count_by_shipment[$target_sid] ?? 0);
                if ($source_count <= 1) continue;
                foreach ($remaining_slices as $idx => $slice_amt) {
                    if (abs($slice_amt - $amt) <= 0.009) {
                        $claims[$target_sid] = round((float)($claims[$target_sid] ?? 0) + $slice_amt, 2);
                        unset($remaining_slices[$idx]);
                        $remaining_slices = array_values($remaining_slices);
                        break;
                    }
                }
            }

            // Second pass: any remaining target rows may only claim what remains of the
            // source after explicit sibling claims. Allocate in shipment order using their
            // own recorded cap, never more than the residual source slices.
            ksort($raw_targets, SORT_NUMERIC);
            foreach ($raw_targets as $target_sid => $amt) {
                $already = round((float)($claims[$target_sid] ?? 0), 2);
                $room = round(max(0.0, $amt - $already), 2);
                if ($room <= 0) continue;
                if (!$remaining_slices) continue;

                $take = 0.0;
                foreach ($remaining_slices as $idx => $slice_amt) {
                    if ($room <= 0) break;
                    if ($slice_amt <= 0) continue;
                    if ($slice_amt - $room > 0.009) {
                        continue;
                    }
                    $take = round($take + $slice_amt, 2);
                    $room = round($room - $slice_amt, 2);
                    unset($remaining_slices[$idx]);
                }
                $remaining_slices = array_values($remaining_slices);
                if ($take > 0) {
                    $claims[$target_sid] = round((float)($claims[$target_sid] ?? 0) + $take, 2);
                }
            }

            // If a single contributor remains and nothing else could prove the split,
            // allow it to carry the whole remaining source amount, bounded by its raw cap.
            if (!$claims && count($raw_targets) === 1) {
                $only_target_sid = (int)array_key_first($raw_targets);
                $only_cap = round((float)$raw_targets[$only_target_sid], 2);
                $source_total = round(array_sum($remaining_slices), 2);
                if ($only_cap > 0 && $source_total > 0) {
                    $claims[$only_target_sid] = round(min($only_cap, $source_total), 2);
                    $remaining_slices = [];
                }
            }

            if (!$claims) continue;
            foreach ($claims as $target_sid => $claim_amt) {
                $claim_amt = round((float)$claim_amt, 2);
                if ($claim_amt <= 0) continue;
                if (!isset($normalized_targets_by_source[$source_sid])) $normalized_targets_by_source[$source_sid] = [];
                $normalized_targets_by_source[$source_sid][$target_sid] = $claim_amt;
            }
        }

        if ($normalized_targets_by_source) {
            $canonical_recovery_targets_by_source_shipment = [];
            $canonical_recovery_sources_by_target_shipment = [];
            $canonical_recovery_by_target_shipment = [];
            $canonical_first_source_by_target_shipment = [];

            foreach ((array)$normalized_targets_by_source as $source_sid => $tgts) {
                $source_sid = (int)$source_sid;
                if ($source_sid <= 0 || !$tgts) continue;
                ksort($tgts, SORT_NUMERIC);
                $canonical_recovery_targets_by_source_shipment[$source_sid] = [];
                foreach ((array)$tgts as $target_sid => $amt) {
                    $target_sid = (int)$target_sid;
                    $amt = round((float)$amt, 2);
                    if ($target_sid <= 0 || $amt <= 0) continue;
                    $canonical_recovery_targets_by_source_shipment[$source_sid][$target_sid] = $amt;
                    if (!isset($canonical_recovery_sources_by_target_shipment[$target_sid])) $canonical_recovery_sources_by_target_shipment[$target_sid] = [];
                    $canonical_recovery_sources_by_target_shipment[$target_sid][$source_sid] = $amt;
                }
            }

            foreach ((array)$canonical_recovery_sources_by_target_shipment as $target_sid => $srcs) {
                ksort($srcs, SORT_NUMERIC);
                $canonical_recovery_sources_by_target_shipment[$target_sid] = $srcs;
                $sum = round(array_sum(array_map('floatval', $srcs)), 2);
                $canonical_recovery_by_target_shipment[$target_sid] = $sum;
                $canonical_first_source_by_target_shipment[$target_sid] = (int)array_key_first($srcs);
            }
        }

        $trace_source_ids_by_target_shipment = [];
        foreach ((array)$canonical_recovery_sources_by_target_shipment as $target_sid => $srcs) {
            foreach ((array)$srcs as $source_sid => $amt) {
                if ((float)$amt <= 0) continue;
                if (!isset($trace_source_ids_by_target_shipment[$target_sid])) $trace_source_ids_by_target_shipment[$target_sid] = [];
                $trace_source_ids_by_target_shipment[$target_sid][(int)$source_sid] = true;
            }
        }

        $trace_targets_by_source_shipment = $canonical_recovery_targets_by_source_shipment;

        // Cap enforcement on CURRENT live preview only:
        // a source shipment's active debit exposure is the hard ceiling for how much
        // later contributor shipments may currently claim from it. This prevents a
        // contributor card/modal from showing the contributor's whole shipment total
        // when only a smaller residual source debt remains open.
        $live_preview_source_caps_by_shipment = [];
        foreach ((array)$debit_rows as $dr) {
            $ss = (int)($dr['shipment_id'] ?? 0);
            if ($ss <= 0) continue;
            $live_preview_source_caps_by_shipment[$ss] = round((float)($live_preview_source_caps_by_shipment[$ss] ?? 0.0) + abs((float)($dr['net'] ?? 0)), 2);
        }
        foreach ((array)$debit_queue as $dq_cap) {
            $ss = (int)($dq_cap['shipment_id'] ?? 0);
            $rem = round((float)($dq_cap['remaining'] ?? 0), 2);
            if ($ss <= 0 || $rem <= 0) continue;
            if (!isset($live_preview_source_caps_by_shipment[$ss]) || $rem > $live_preview_source_caps_by_shipment[$ss]) {
                $live_preview_source_caps_by_shipment[$ss] = $rem;
            }
        }

        $capped_live_preview_targets_by_source_shipment = [];
        foreach ((array)$live_preview_recovery_targets_by_source_shipment as $src_sid => $targets) {
            $src_sid = (int)$src_sid;
            if ($src_sid <= 0 || !is_array($targets) || !$targets) continue;

            $cap = round((float)($live_preview_source_caps_by_shipment[$src_sid] ?? 0.0), 2);
            if ($cap <= 0) continue;

            $working = [];
            foreach ((array)$targets as $tgt_sid => $amt_raw) {
                $tgt_sid = (int)$tgt_sid;
                $amt = round((float)$amt_raw, 2);
                if ($tgt_sid <= 0 || $tgt_sid === $src_sid || $amt <= 0) continue;
                $working[$tgt_sid] = $amt;
            }
            if (!$working) continue;

            $sum = round(array_sum(array_map('floatval', $working)), 2);
            if ($sum - $cap > 0.009) {
                arsort($working, SORT_NUMERIC);
                $overflow = round($sum - $cap, 2);
                foreach ($working as $tgt_sid => $amt) {
                    $amt = round((float)$amt, 2);
                    if ($overflow <= 0.009) break;
                    if ($amt <= 0) continue;
                    $reduce = min($amt, $overflow);
                    $working[$tgt_sid] = round($amt - $reduce, 2);
                    $overflow = round($overflow - $reduce, 2);
                }
            }

            foreach ($working as $tgt_sid => $amt) {
                $amt = round((float)$amt, 2);
                if ($amt <= 0.009) continue;
                if (!isset($capped_live_preview_targets_by_source_shipment[$src_sid])) $capped_live_preview_targets_by_source_shipment[$src_sid] = [];
                $capped_live_preview_targets_by_source_shipment[$src_sid][$tgt_sid] = $amt;
            }
            if (!empty($capped_live_preview_targets_by_source_shipment[$src_sid])) {
                ksort($capped_live_preview_targets_by_source_shipment[$src_sid], SORT_NUMERIC);
            }
        }

        if ($capped_live_preview_targets_by_source_shipment) {
            $live_preview_recovery_targets_by_source_shipment = $capped_live_preview_targets_by_source_shipment;
            $live_preview_recovery_by_target_shipment = [];
            $live_preview_recovery_sources_by_target_shipment = [];
            $live_preview_first_source_by_target_shipment = [];
            foreach ((array)$live_preview_recovery_targets_by_source_shipment as $src_sid => $targets) {
                $src_sid = (int)$src_sid;
                foreach ((array)$targets as $tgt_sid => $amt_raw) {
                    $tgt_sid = (int)$tgt_sid;
                    $amt = round((float)$amt_raw, 2);
                    if ($src_sid <= 0 || $tgt_sid <= 0 || $src_sid === $tgt_sid || $amt <= 0) continue;
                    if (!isset($live_preview_recovery_by_target_shipment[$tgt_sid])) $live_preview_recovery_by_target_shipment[$tgt_sid] = 0.0;
                    $live_preview_recovery_by_target_shipment[$tgt_sid] = round((float)$live_preview_recovery_by_target_shipment[$tgt_sid] + $amt, 2);
                    if (!isset($live_preview_recovery_sources_by_target_shipment[$tgt_sid])) $live_preview_recovery_sources_by_target_shipment[$tgt_sid] = [];
                    $live_preview_recovery_sources_by_target_shipment[$tgt_sid][$src_sid] = $amt;
                }
            }
            foreach ((array)$live_preview_recovery_sources_by_target_shipment as $tgt_sid => $srcs) {
                ksort($srcs, SORT_NUMERIC);
                $live_preview_recovery_sources_by_target_shipment[$tgt_sid] = $srcs;
                $live_preview_first_source_by_target_shipment[$tgt_sid] = (int)array_key_first($srcs);
            }
        }

        // -----------------------------------------------------------------
        // Ledger-only wallet doctrine:
        // The vendor wallet must not forecast, reserve, or reconstruct recovery.
        // It may display only recovery edges that the bank ledger already wrote
        // as real consumed offsets. This kills UI-side duplication of
        // BankSellerLedger allocation behavior and ignores old pending-reserve
        // scars such as pending-auto-allocation / reserved_pending.
        // -----------------------------------------------------------------
        $ledger_only_targets_by_source = [];
        $ledger_only_sources_by_target = [];
        $ledger_only_first_source_by_target = [];
        $ledger_only_recovery_by_target = [];

        $edge_is_real_consumed = static function($edge): bool {
            if (!is_array($edge)) return false;
            $amount = round((float)($edge['amount'] ?? 0), 2);
            if ($amount <= 0) return false;
            $status = (string)($edge['allocation_status'] ?? '');
            $ref = (string)($edge['reference'] ?? '');
            $target_slice = (string)($edge['target_slice_id'] ?? '');
            if ($status === 'reserved_pending') return false;
            if (strpos($ref, 'pending-auto-allocation:') === 0) return false;
            if (strpos($target_slice, 'pending-target-') === 0) return false;
            return ($status === 'consumed' || (int)($edge['target_row_id'] ?? 0) > 0 || strpos($ref, 'auto-allocation:') === 0);
        };

        $ledger_rows_for_edges = isset($rows_all) && is_array($rows_all) ? $rows_all : (isset($rows) && is_array($rows) ? $rows : []);
        foreach ((array)$ledger_rows_for_edges as $edge_row) {
            $row_sid = (int)($edge_row['shipment_id'] ?? 0);
            if ($row_sid <= 0) continue;
            $row_meta_raw = (string)($edge_row['meta'] ?? '');
            if ($row_meta_raw === '') continue;
            $row_meta = json_decode($row_meta_raw, true);
            if (!is_array($row_meta)) continue;

            $edge_row_event_type = strtolower(trim((string)($edge_row['event_type'] ?? '')));
            if ($edge_row_event_type !== 'seller_offset_consumed') {
                continue;
            }

            foreach ((array)($row_meta['offset_sources'] ?? []) as $edge) {
                if (!$edge_is_real_consumed($edge)) continue;
                $source_sid = (int)($edge['source_shipment_id'] ?? 0);
                $target_sid = (int)($edge['target_shipment_id'] ?? $row_sid);
                $amount = round((float)($edge['amount'] ?? 0), 2);
                if ($source_sid <= 0 || $target_sid <= 0 || $source_sid === $target_sid || $amount <= 0) continue;
                if (!isset($ledger_only_targets_by_source[$source_sid])) $ledger_only_targets_by_source[$source_sid] = [];
                if (!isset($ledger_only_sources_by_target[$target_sid])) $ledger_only_sources_by_target[$target_sid] = [];
                $ledger_only_targets_by_source[$source_sid][$target_sid] = round((float)($ledger_only_targets_by_source[$source_sid][$target_sid] ?? 0) + $amount, 2);
                $ledger_only_sources_by_target[$target_sid][$source_sid] = round((float)($ledger_only_sources_by_target[$target_sid][$source_sid] ?? 0) + $amount, 2);
            }

            // IMPORTANT: Renderer-only wallet doctrine.
            // Do not count source-side offset_targets here. BankSellerLedger writes
            // the same consumed edge in two places:
            //   1) target offset row meta.offset_sources  = canonical display truth
            //   2) source debit row meta.offset_targets   = backlink for audit/source tracing
            // Counting both sides doubles the card adjustment (ex: 9,680 -> 19,360).
            // Shipment-card recovery totals must come only from real target-side
            // seller_offset_consumed rows / offset_sources.
        }

        foreach ((array)$ledger_only_sources_by_target as $target_sid => $srcs) {
            ksort($srcs, SORT_NUMERIC);
            $ledger_only_sources_by_target[$target_sid] = $srcs;
            $ledger_only_first_source_by_target[$target_sid] = (int)array_key_first($srcs);
            $ledger_only_recovery_by_target[$target_sid] = round(array_sum(array_map('floatval', $srcs)), 2);
        }
        foreach ((array)$ledger_only_targets_by_source as $source_sid => $tgts) {
            ksort($tgts, SORT_NUMERIC);
            $ledger_only_targets_by_source[$source_sid] = $tgts;
        }

        $canonical_recovery_targets_by_source_shipment = $ledger_only_targets_by_source;
        $canonical_recovery_sources_by_target_shipment = $ledger_only_sources_by_target;
        $canonical_recovery_by_target_shipment = $ledger_only_recovery_by_target;
        $canonical_first_source_by_target_shipment = $ledger_only_first_source_by_target;

        $trace_targets_by_source_shipment = $ledger_only_targets_by_source;
        $trace_source_ids_by_target_shipment = [];
        foreach ((array)$ledger_only_sources_by_target as $target_sid => $srcs) {
            $trace_source_ids_by_target_shipment[(int)$target_sid] = [];
            foreach ((array)$srcs as $source_sid => $_amt) {
                $trace_source_ids_by_target_shipment[(int)$target_sid][(int)$source_sid] = true;
            }
        }

        $card_recovery_by_shipment = $ledger_only_recovery_by_target;
        $card_recovery_sources_by_shipment = $ledger_only_sources_by_target;
        $card_recovery_source_by_shipment = $ledger_only_first_source_by_target;
        $source_recovery_targets_by_shipment = $ledger_only_targets_by_source;

        $live_preview_recovery_by_target_shipment = [];
        $live_preview_recovery_sources_by_target_shipment = [];
        $live_preview_first_source_by_target_shipment = [];
        $live_preview_recovery_targets_by_source_shipment = [];

        $trace_return_rows_by_target_shipment = [];
        foreach ((array)$trace_source_ids_by_target_shipment as $target_sid => $sources) {
            $target_sid = (int)$target_sid;
            $src_ids = array_values(array_map('intval', array_keys((array)$sources)));
            $src_ids = array_values(array_filter($src_ids, fn($v) => $v > 0 && $v !== $target_sid));
            if ($src_ids) {
                $trace_return_rows_by_target_shipment[$target_sid] = $this->build_deduction_explain_for_shipments($src_ids);
            }
        }
        $wallet_recovery_projection_disabled = true;

        $stage_defined = get_defined_vars();
        unset($stage_defined['ctx'], $stage_defined['stage_defined']);
        return array_merge($ctx, $stage_defined);
    }
}