<?php
namespace Caricove\SellerPayouts;

use Caricove\Bank\Ledger;

if (!defined('ABSPATH')) exit;

require_once __DIR__ . '/VendorWalletUIRenderTrait.php';
require_once __DIR__ . '/VendorWalletUISaveMethodTrait.php';
require_once __DIR__ . '/VendorWalletUIHelpersTrait.php';

final class VendorWalletUI {
    use VendorWalletUICurrentStateTrait;
    use VendorWalletUIHistoryStateTrait;
    use VendorWalletUICardPresenterTrait;
    use VendorWalletUIModalPresenterTrait;
    use VendorWalletUIRenderTrait;
    use VendorWalletUISaveMethodTrait;
    use VendorWalletUIHelpersTrait;

    public function register(): void {
        add_shortcode('caricove_vendor_wallet', [$this,'render']);
        add_action('wp_ajax_cc_sp_save_payout_method_v2', [$this,'save_method']);
    }
}
