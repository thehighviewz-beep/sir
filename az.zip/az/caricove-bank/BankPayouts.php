<?php
namespace Caricove\Bank;

if (!defined('ABSPATH')) exit;

final class BankPayouts
{
    private const CRON_HOOK = 'caricove_bank_promote_pending_run';

    // legacy-compatible runner health options
    private const OPT_LAST_PING    = 'cc_sp_runner_last_ping_ts';
    private const OPT_LAST_SUCCESS = 'cc_sp_runner_last_success_ts';
    private const OPT_LAST_ERROR   = 'cc_sp_runner_last_error';
    private const OPT_RUNNER_TOKEN = 'cc_sp_runner_token';

    private const OPT_SCHEMA_VER = 'caricove_bank_payouts_schema_version';
    private const SCHEMA_VERSION = '2.0.0';

    public static function register(): void
    {
        add_action('init', [__CLASS__, 'maybe_install_schema'], 1);
        add_action('init', [__CLASS__, 'ensure_runner_token'], 2);
        add_action('init', [__CLASS__, 'register_cron_interval'], 3);
        add_action('init', [__CLASS__, 'ensure_cron'], 4);

        add_action(self::CRON_HOOK, [__CLASS__, 'run_promotion_cycle']);

        add_action('rest_api_init', [__CLASS__, 'register_rest']);

        // legacy vendor wallet compatibility
        add_action('wp_ajax_cc_sp_instant_cashout', [__CLASS__, 'ajax_instant_cashout_request']);

        // shipment watcher absorbed here so old file can go
        add_action('updated_post_meta', [__CLASS__, 'on_meta_change'], 10, 4);
        add_action('added_post_meta',   [__CLASS__, 'on_meta_change'], 10, 4);
    }

    /* =========================================================
     * SETTINGS / DEFAULTS / LEGACY COMPAT
     * ======================================================= */

    private static function defaults(): array
    {
        return [
            'currency'                    => 'GYD',
            'commission_rate'             => 0.12,
            'instant_fee_rate'            => 0.00,
            'clearing_hours'              => 72,
            'timezone'                    => 'America/Guyana',
            'enable_bank'                 => true,

            'min_payout_threshold'        => 0.0,
            'new_vendor_reserve_rate'     => 0.00,
            'new_vendor_reserve_days'     => 0,

            'max_instant_per_day'         => 0,
            'max_instant_per_tx'          => 0.0,

            'runner_health_stale_minutes' => 120,
            'enable_rest_runner'          => true,
            'payout_hold_default'         => 'hold',
        ];
    }

    private static function setting(string $key, $default = null)
    {
        $filtered = apply_filters('caricove_bank_seller_ledger_setting', null, $key, $default);
        if ($filtered !== null) {
            return $filtered;
        }

        $bank_store = get_option('caricove_bank_settings', []);
        if (is_array($bank_store) && array_key_exists($key, $bank_store)) {
            return $bank_store[$key];
        }

        $bank_seller_store = get_option('caricove_bank_seller_settings', []);
        if (is_array($bank_seller_store) && array_key_exists($key, $bank_seller_store)) {
            return $bank_seller_store[$key];
        }

        // legacy seller-payouts settings compatibility
        $legacy = get_option('cc_sp_settings', []);
        if (is_array($legacy) && array_key_exists($key, $legacy)) {
            return $legacy[$key];
        }

        $single_keys = [
            'caricove_bank_' . $key,
            'caricove_bank_seller_' . $key,
            'cc_sp_' . $key,
        ];

        foreach ($single_keys as $opt_key) {
            $value = get_option($opt_key, null);
            if ($value !== null) {
                return $value;
            }
        }

        $defaults = self::defaults();
        if (array_key_exists($key, $defaults)) {
            return $defaults[$key];
        }

        return $default;
    }

    private static function build_trace_context(array $context = []): array
    {
        $existing = trim((string) ($context['correlation_id'] ?? $context['trace_context']['correlation_id'] ?? ''));
        if ($existing === '') {
            $existing = 'payout-' . substr(md5(wp_json_encode($context) . '|' . microtime(true)), 0, 16);
        }
        return [
            'correlation_id' => $existing,
            'command_source' => 'bank_payouts',
            'payout_id' => (int) ($context['payout_id'] ?? 0),
            'vendor_id' => (int) ($context['vendor_id'] ?? 0),
            'requested_by' => (int) ($context['requested_by'] ?? 0),
            'actor_user_id' => function_exists('get_current_user_id') ? (int) get_current_user_id() : 0,
            'captured_at' => self::now(),
        ];
    }

    private static function with_trace_meta(array $meta, array $context = [], string $operation = ''): array
    {
        $trace = self::build_trace_context($context);
        $existing = isset($meta['trace_context']) && is_array($meta['trace_context']) ? $meta['trace_context'] : [];
        $meta['trace_context'] = array_merge($existing, $trace);
        if ($operation !== '') {
            $meta['trace_operation'] = $operation;
        }
        if (!empty($trace['correlation_id'])) {
            $meta['correlation_id'] = (string) $trace['correlation_id'];
        }
        return $meta;
    }

    private static function currency(): string
    {
        $currency = strtoupper(trim((string) self::setting('currency', 'GYD')));
        return $currency !== '' ? substr($currency, 0, 10) : 'GYD';
    }

   private static function instant_fee_rate(): float
{
    return 0.0;
}

    private static function max_instant_per_day(): int
    {
        return max(0, (int) self::setting('max_instant_per_day', 0));
    }

    private static function max_instant_per_tx(): float
    {
        return max(0.0, (float) self::setting('max_instant_per_tx', 0.0));
    }

    private static function min_payout_threshold(): float
    {
        return max(0.0, (float) self::setting('min_payout_threshold', 0.0));
    }

    private static function enable_rest_runner(): bool
    {
        return (bool) self::setting('enable_rest_runner', true);
    }

    private static function now(): string
    {
        return current_time('mysql');
    }

    private static function decode_meta($raw): array
    {
        if (is_array($raw)) return $raw;
        if (!is_string($raw) || trim($raw) === '') return [];

        $decoded = json_decode($raw, true);
        return is_array($decoded) ? $decoded : [];
    }

    private static function encode_meta(array $meta): string
    {
        return wp_json_encode($meta);
    }

    /* =========================================================
     * SCHEMA
     * ======================================================= */

    public static function maybe_install_schema(): void
    {
        if (!function_exists('dbDelta')) {
            require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        }

        $installed = (string) get_option(self::OPT_SCHEMA_VER, '');
        if ($installed === self::SCHEMA_VERSION) {
            return;
        }

        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        $payouts = Ledger::payouts_table();

        $sql = "CREATE TABLE {$payouts} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            vendor_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            currency VARCHAR(8) NOT NULL DEFAULT 'GYD',

            kind VARCHAR(16) NOT NULL DEFAULT 'instant',
            status VARCHAR(24) NOT NULL DEFAULT 'requested',
            created_at DATETIME NOT NULL,
            status_updated_at DATETIME NULL,

            amount_gross DECIMAL(18,4) NOT NULL DEFAULT 0,
            fee DECIMAL(18,4) NOT NULL DEFAULT 0,
            amount_net DECIMAL(18,4) NOT NULL DEFAULT 0,

            method VARCHAR(24) NOT NULL DEFAULT 'gtt',
            destination VARCHAR(190) NOT NULL DEFAULT '',
            reference VARCHAR(190) NOT NULL DEFAULT '',

            requested_by BIGINT UNSIGNED NULL,
            decided_by BIGINT UNSIGNED NULL,
            decided_at DATETIME NULL,
            decision_note VARCHAR(190) NULL,

            error_text TEXT NULL,
            meta LONGTEXT NULL,

            PRIMARY KEY (id),
            KEY vendor_id (vendor_id),
            KEY status (status),
            KEY created_at (created_at),
            KEY kind_status (kind, status)
        ) {$charset};";

        dbDelta($sql);

        update_option(self::OPT_SCHEMA_VER, self::SCHEMA_VERSION, false);
    }

    public static function ensure_runner_token(): void
    {
        $tok = (string) get_option(self::OPT_RUNNER_TOKEN, '');
        if ($tok === '') {
            update_option(self::OPT_RUNNER_TOKEN, wp_generate_password(32, false, false), false);
        }
    }

    /* =========================================================
     * CRON / RUNNER
     * ======================================================= */

    public static function register_cron_interval(): void
    {
        add_filter('cron_schedules', static function ($schedules) {
            if (!isset($schedules['caricove_every_five_minutes'])) {
                $schedules['caricove_every_five_minutes'] = [
                    'interval' => 300,
                    'display'  => 'Every Five Minutes',
                ];
            }
            return $schedules;
        });
    }

    public static function ensure_cron(): void
    {
        self::ping();

        if (wp_next_scheduled(self::CRON_HOOK)) {
            return;
        }

        wp_schedule_event(time() + 300, 'caricove_every_five_minutes', self::CRON_HOOK);
    }

    public static function run_promotion_cycle(): int
    {
        self::ping();

        try {
            $moved = Ledger::promote_pending_to_available();
            self::success();
            return (int) $moved;
        } catch (\Throwable $e) {
            self::set_error('Promotion runner exception: ' . $e->getMessage());
            return 0;
        }
    }

    public static function register_rest(): void
    {
        register_rest_route('caricove-bank/v1', '/payouts/runner', [
            'methods'  => 'GET',
            'callback' => [__CLASS__, 'rest_runner'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route('caricove-bank/v1', '/payouts/request', [
            'methods'  => 'POST',
            'callback' => [__CLASS__, 'rest_request'],
            'permission_callback' => static function () {
                return is_user_logged_in();
            },
        ]);

        register_rest_route('caricove-bank/v1', '/payouts/(?P<id>\d+)/approve', [
            'methods'  => 'POST',
            'callback' => [__CLASS__, 'rest_approve'],
            'permission_callback' => [__CLASS__, 'admin_permission'],
        ]);

        register_rest_route('caricove-bank/v1', '/payouts/(?P<id>\d+)/deny', [
            'methods'  => 'POST',
            'callback' => [__CLASS__, 'rest_deny'],
            'permission_callback' => [__CLASS__, 'admin_permission'],
        ]);

        register_rest_route('caricove-bank/v1', '/payouts/(?P<id>\d+)/execute', [
            'methods'  => 'POST',
            'callback' => [__CLASS__, 'rest_execute'],
            'permission_callback' => [__CLASS__, 'admin_permission'],
        ]);
    }

    public static function admin_permission(): bool
    {
        return current_user_can('manage_options') || current_user_can('manage_woocommerce');
    }

    public static function rest_runner(\WP_REST_Request $req): \WP_REST_Response
    {
        $token = (string) $req->get_param('token');
        $good  = (string) get_option(self::OPT_RUNNER_TOKEN, '');

        if (!$good || !hash_equals($good, $token)) {
            self::set_error('REST runner: invalid token');
            return new \WP_REST_Response(['ok' => false, 'error' => 'invalid_token'], 403);
        }

        $moved = self::run_promotion_cycle();

        return new \WP_REST_Response([
            'ok'            => true,
            'promoted_rows' => (int) $moved,
            'ts'            => time(),
        ], 200);
    }

    public static function rest_request(\WP_REST_Request $req): \WP_REST_Response
    {
        if (!is_user_logged_in()) {
            return new \WP_REST_Response(['ok' => false, 'message' => 'Not logged in.'], 401);
        }

        $vendor_id = get_current_user_id();
        $kind      = sanitize_key((string) $req->get_param('kind'));
        if ($kind === '') $kind = 'instant';

        $amount = (float) $req->get_param('amount');

        $payout_id = self::create_request($vendor_id, $amount, $kind, $vendor_id);

        if ($payout_id <= 0) {
            return new \WP_REST_Response(['ok' => false, 'message' => 'Could not create payout request.'], 400);
        }

        return new \WP_REST_Response([
            'ok'        => true,
            'payout_id' => $payout_id,
            'message'   => 'Request sent.',
        ], 200);
    }

    public static function rest_approve(\WP_REST_Request $req): \WP_REST_Response
    {
        $id   = (int) $req['id'];
        $note = sanitize_text_field((string) $req->get_param('note'));
        $ok   = self::approve($id, get_current_user_id(), $note);

        return new \WP_REST_Response(['ok' => $ok], $ok ? 200 : 400);
    }

    public static function rest_deny(\WP_REST_Request $req): \WP_REST_Response
    {
        $id   = (int) $req['id'];
        $note = sanitize_text_field((string) $req->get_param('note'));
        $ok   = self::deny($id, get_current_user_id(), $note);

        return new \WP_REST_Response(['ok' => $ok], $ok ? 200 : 400);
    }

    public static function rest_execute(\WP_REST_Request $req): \WP_REST_Response
    {
        $id   = (int) $req['id'];
        $note = sanitize_text_field((string) $req->get_param('note'));
        $ok   = self::execute($id, get_current_user_id(), $note);

        return new \WP_REST_Response(['ok' => $ok], $ok ? 200 : 400);
    }

    /* =========================================================
     * DASHBOARD DATA
     * ======================================================= */

    public static function list_requests(array $filters = [], int $limit = 200): array
    {
        global $wpdb;

        $table = Ledger::payouts_table();
        $where = ['1=1'];
        $args  = [];

        if (!empty($filters['vendor_id'])) {
            $where[] = 'vendor_id = %d';
            $args[]  = (int) $filters['vendor_id'];
        }

        if (!empty($filters['status'])) {
            $where[] = 'status = %s';
            $args[]  = (string) $filters['status'];
        }

        if (!empty($filters['date'])) {
            $where[] = 'DATE(created_at) = %s';
            $args[]  = (string) $filters['date'];
        }

        $sql = "
            SELECT *
            FROM {$table}
            WHERE " . implode(' AND ', $where) . "
            ORDER BY created_at ASC, id ASC
            LIMIT %d
        ";

        $args[] = max(1, min(500, (int) $limit));

        $rows = $wpdb->get_results($wpdb->prepare($sql, ...$args), ARRAY_A);
        return is_array($rows) ? $rows : [];
    }

    public static function vendor_truth(int $vendor_id): array
    {
        $metrics = Ledger::seller_metrics($vendor_id);

        $available_residual = (float) ($metrics['canonical_available_pool'] ?? ($metrics['available'] ?? 0));
        $debit              = (float) ($metrics['debit_exposure'] ?? ($metrics['active_source_exposure'] ?? 0));
        $withdrawable_now   = (float) ($metrics['withdrawable_now'] ?? 0);

        return [
            'pending'             => (float) ($metrics['pending'] ?? 0),
            'available'           => $available_residual,
            'paid'                => (float) ($metrics['paid'] ?? 0),
            'debit_exposure'      => $debit,
            'active_live_holds'   => (float) ($metrics['active_live_holds'] ?? 0),
            'withdrawable_now'    => $withdrawable_now,
            'available_payable'   => (float) ($metrics['available_payable'] ?? $withdrawable_now),
        ];
    }

    private static function payout_method(int $vendor_id): array
    {
        $method = (string) get_user_meta($vendor_id, '_cc_sp_method', true);
        $method = trim($method);

        if ($method === 'bank') {
            $bank_name   = (string) get_user_meta($vendor_id, '_cc_sp_bank_name', true);
            $bank_holder = (string) get_user_meta($vendor_id, '_cc_sp_bank_holder', true);
            $bank_last4  = (string) get_user_meta($vendor_id, '_cc_sp_bank_last4', true);

            $dest = trim($bank_name);
            $holder_mask = self::mask_holder($bank_holder);
            if ($holder_mask !== '') {
                $dest .= ($dest !== '' ? ' • ' : '') . $holder_mask;
            }
            if ($bank_last4 !== '') {
                $dest .= ($dest !== '' ? ' • ' : '') . 'acct ****' . preg_replace('/\D+/', '', $bank_last4);
            }

            return ['bank', trim($dest)];
        }

        if ($method === 'gtt' || $method === '') {
            $phone = trim((string) get_user_meta($vendor_id, '_cc_sp_gtt_phone', true));
            return ['gtt', $phone];
        }

        return [$method, ''];
    }

    private static function mask_holder(string $name): string
    {
        $name = trim($name);
        if ($name === '') return '';

        $parts = preg_split('/\s+/', $name);
        $first = (string) ($parts[0] ?? '');
        $last  = (string) (count($parts) > 1 ? end($parts) : '');

        $lastInitial = $last !== '' ? strtoupper(substr($last, 0, 1)) . '.' : '';
        return trim($first . ($lastInitial !== '' ? ' ' . $lastInitial : ''));
    }

    private static function open_request_count(int $vendor_id): int
    {
        global $wpdb;

        $table = Ledger::payouts_table();

        return (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*)
             FROM {$table}
             WHERE vendor_id = %d
               AND status IN ('requested','approved','queued')",
            $vendor_id
        ));
    }

    private static function instant_requests_today(int $vendor_id): int
    {
        global $wpdb;

        $table = Ledger::payouts_table();
        $today = current_time('Y-m-d');

        return (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*)
             FROM {$table}
             WHERE vendor_id = %d
               AND kind = 'instant'
               AND DATE(created_at) = %s",
            $vendor_id,
            $today
        ));
    }

 private static function payout_snapshot(int $vendor_id, string $kind): array
{
    $truth = self::vendor_truth($vendor_id);

    $gross = round((float) ($truth['withdrawable_now'] ?? 0), 4);
    $fee   = 0.0;
    $net   = $gross;

    return [
        'truth'        => $truth,
        'amount_gross' => $gross,
        'fee'          => $fee,
        'amount_net'   => $net,
    ];
}

    private static function resolve_requested_amount(float $requested_amount, float $withdrawable_now): float
    {
        $withdrawable_now = round(max(0.0, $withdrawable_now), 4);
        $requested_amount = round(max(0.0, $requested_amount), 4);

        if ($requested_amount <= 0.0) {
            return $withdrawable_now;
        }

        return $requested_amount;
    }

    private static function ledger_supports_exact_amount_payouts(): bool
    {
        if (method_exists(Ledger::class, 'mark_paid_for_vendor_detailed')) {
            return true;
        }

        try {
            $method = new \ReflectionMethod(Ledger::class, 'mark_paid_for_vendor');
            return $method->getNumberOfParameters() >= 2;
        } catch (\Throwable $e) {
            return false;
        }
    }

    private static function execute_ledger_payout(int $vendor_id, float $requested_amount, float $current_withdrawable): array
    {
        $requested_amount     = round(max(0.0, $requested_amount), 4);
        $current_withdrawable = round(max(0.0, $current_withdrawable), 4);

        if ($requested_amount <= 0.0) {
            return ['ok' => false, 'error' => 'Requested amount is invalid.'];
        }

        $supports_exact = self::ledger_supports_exact_amount_payouts();
        $is_partial     = ($requested_amount + 0.009) < $current_withdrawable;

        if ($is_partial && !$supports_exact) {
            return [
                'ok'             => false,
                'supports_exact' => false,
                'error'          => 'Exact-amount payouts are not supported by the current ledger implementation.',
            ];
        }

        $details = [];
        if (method_exists(Ledger::class, 'mark_paid_for_vendor_detailed')) {
            $details = Ledger::mark_paid_for_vendor_detailed($vendor_id, $requested_amount, [
                'payout_id' => $payout_id,
                'vendor_id' => $vendor_id,
                'correlation_id' => (string) ($queueMeta['correlation_id'] ?? ($queueMeta['trace_context']['correlation_id'] ?? '')),
                'trace_context' => (array) ($queueMeta['trace_context'] ?? []),
            ]);
            $paid = round((float) ($details['paid'] ?? 0), 4);
        } else {
            $paid = $supports_exact
                ? Ledger::mark_paid_for_vendor($vendor_id, $requested_amount)
                : Ledger::mark_paid_for_vendor($vendor_id);
            $paid = round((float) $paid, 4);
            $details = [
                'paid' => $paid,
                'cash_sources' => [],
                'offset_applied' => 0.0,
                'offset_events' => [],
            ];
        }

        if ($paid <= 0.0) {
            return [
                'ok'             => false,
                'supports_exact' => $supports_exact,
                'details'        => $details,
                'error'          => (string) ($details['error'] ?? 'Ledger execution returned no payable amount.'),
            ];
        }

        if (abs($paid - $requested_amount) > 0.009) {
            return [
                'ok'             => false,
                'supports_exact' => $supports_exact,
                'paid'           => $paid,
                'details'        => $details,
                'error'          => 'Ledger execution did not honor the exact requested amount.',
            ];
        }

        return [
            'ok'             => true,
            'supports_exact' => $supports_exact,
            'paid'           => $paid,
            'details'        => $details,
        ];
    }

   private static function record_payout_bank_event(
    string $event_type,
    int $vendor_id,
    int $payout_id,
    float $amount,
    string $reason_label,
    array $meta = [],
    int $order_id = 0,
    int $shipment_id = 0
): void {
    if (!class_exists(__NAMESPACE__ . '\\BankLedger') || $amount <= 0 || $vendor_id <= 0) {
        return;
    }

    $direction  = 'debit';
    $payer_type = 'platform';
    $payer_id   = 0;
    $payee_type = 'vendor';
    $payee_id   = $vendor_id;

    if ($event_type === 'vendor_liability_recovered') {
        $direction  = 'debit';
        $payer_type = 'vendor';
        $payer_id   = $vendor_id;
        $payee_type = 'platform';
        $payee_id   = 0;
    }

    $meta = self::with_trace_meta($meta, [
        'payout_id'   => $payout_id,
        'vendor_id'   => $vendor_id,
        'shipment_id' => $shipment_id,
        'order_id'    => $order_id,
        'amount'      => $amount,
    ], 'bank_payout_event_record');

    BankLedger::record([
        'event_type'     => $event_type,
        'event_status'   => 'posted',
        'order_id'       => max(0, $order_id),
        'shipment_id'    => max(0, $shipment_id),
        'return_case_id' => '',
        'vendor_id'      => $vendor_id,
        'customer_id'    => 0,
        'woo_refund_id'  => 0,
        'currency'       => self::currency(),
        'amount'         => round($amount, 4),
        'direction'      => $direction,
        'payer_type'     => $payer_type,
        'payer_id'       => $payer_id,
        'payee_type'     => $payee_type,
        'payee_id'       => $payee_id,
        'reason_code'    => sanitize_key($event_type),
        'reason_label'   => $reason_label,
        'source_system'  => 'bank_payouts',
        'source_ref'     => 'bank_payout:' . $payout_id,
        'meta_json'      => $meta,
    ]);
}
    /* =========================================================
     * CREATE REQUEST
     * ======================================================= */

    public static function create_request(int $vendor_id, float $amount = 0.0, string $kind = 'instant', int $requested_by = 0): int
    {
        global $wpdb;

        $vendor_id = max(0, $vendor_id);
        if ($vendor_id <= 0) return 0;

        $kind = sanitize_key($kind);
        if ($kind === '') $kind = 'instant';

        self::run_promotion_cycle();

        if (self::open_request_count($vendor_id) > 0) {
            return 0;
        }

        [$method, $dest] = self::payout_method($vendor_id);
        if (trim($dest) === '') {
            return 0;
        }

        $snapshot          = self::payout_snapshot($vendor_id, $kind);
        $truth             = is_array($snapshot['truth'] ?? null) ? $snapshot['truth'] : [];
        $withdrawable_now  = round((float) ($truth['withdrawable_now'] ?? 0), 4);
        $requested_raw     = round(max(0.0, $amount), 4);

        if ($requested_raw > 0.0 && $requested_raw - $withdrawable_now > 0.009) {
            return 0;
        }

        $gross = self::resolve_requested_amount($requested_raw, $withdrawable_now);
        $fee   = 0.0;
        $net   = $gross;

        if ($gross <= 0 || $net <= 0) {
            return 0;
        }

        if ($gross < self::min_payout_threshold()) {
            return 0;
        }

        if ($kind === 'instant') {
            $maxPerTx = self::max_instant_per_tx();
            if ($maxPerTx > 0 && $gross > $maxPerTx) {
                return 0;
            }

            $maxPerDay = self::max_instant_per_day();
            if ($maxPerDay > 0 && self::instant_requests_today($vendor_id) >= $maxPerDay) {
                return 0;
            }
        }

        $reference = 'cbank-req-' . $vendor_id . '-' . time() . '-' . wp_generate_password(6, false, false);
        $now       = self::now();

        $trace_context = self::build_trace_context([
            'vendor_id' => $vendor_id,
            'requested_by' => $requested_by,
        ]);

        $meta = [
            'request_origin'             => 'bank',
            'snapshot_truth'             => $truth,
            'requested_amount'           => $gross,
            'requested_amount_raw'       => $requested_raw,
            'request_mode'               => ($requested_raw > 0.0 ? 'explicit' : 'full_withdrawable'),
            'withdrawable_now_at_request'=> $withdrawable_now,
            'kind'                       => $kind,
            'created_via'                => is_admin() ? 'admin' : 'vendor',
        ];
        $meta = self::with_trace_meta($meta, $trace_context, 'payout_request_create');

        $ok = $wpdb->insert(
            Ledger::payouts_table(),
            [
                'vendor_id'          => $vendor_id,
                'currency'           => self::currency(),
                'kind'               => $kind,
                'status'             => 'requested',
                'created_at'         => $now,
                'status_updated_at'  => $now,
                'amount_gross'       => $gross,
                'fee'                => $fee,
                'amount_net'         => $net,
                'method'             => $method,
                'destination'        => $dest,
                'reference'          => $reference,
                'requested_by'       => $requested_by > 0 ? $requested_by : null,
                'meta'               => self::encode_meta($meta),
            ]
        );

        if (!$ok) {
            return 0;
        }

        $payout_id = (int) $wpdb->insert_id;
        if ($payout_id > 0) {
            $meta = self::with_trace_meta($meta, array_merge($trace_context, ['payout_id' => $payout_id]), 'payout_request_create');
            $wpdb->update($table = Ledger::payouts_table(), ['meta' => self::encode_meta($meta)], ['id' => $payout_id]);
        }

        do_action('caricove_bank_payout_requested', [
            'payout_id'     => $payout_id,
            'vendor_id'     => $vendor_id,
            'currency'      => self::currency(),
            'amount_gross'  => $gross,
            'fee'           => $fee,
            'amount_net'    => $net,
            'method'        => $method,
            'destination'   => $dest,
            'reference'     => $reference,
            'kind'          => $kind,
        ]);

        return $payout_id;
    }

    public static function ajax_instant_cashout_request(): void
    {
        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => 'Not logged in.'], 401);
        }

        check_ajax_referer('cc_sp_instant_cashout', 'nonce');

        $vendor_id = (int) get_current_user_id();
        $lock_key  = 'cc_sp_instant_req_lock_' . $vendor_id;

        if (get_transient($lock_key)) {
            wp_send_json_error(['message' => 'Please wait… request is already sending.'], 429);
        }

        set_transient($lock_key, 1, 30);
        self::ping();

        try {
            $amount = isset($_POST['amount']) ? round(max(0.0, (float) wp_unslash($_POST['amount'])), 4) : 0.0;
            $payout_id = self::create_request($vendor_id, $amount, 'instant', $vendor_id);

            delete_transient($lock_key);

            if ($payout_id <= 0) {
                wp_send_json_error(['message' => 'Could not create payout request.'], 400);
            }

            self::success();
            wp_send_json_success([
                'message'   => 'Request sent to admin for approval.',
                'payout_id' => $payout_id,
            ]);
        } catch (\Throwable $e) {
            self::set_error('Instant request exception: ' . $e->getMessage());
            delete_transient($lock_key);
            wp_send_json_error(['message' => 'Error sending request.'], 500);
        }
    }

    /* =========================================================
     * APPROVE / DENY / EXECUTE
     * ======================================================= */

    public static function approve(int $payout_id, int $admin_id = 0, string $note = ''): bool
    {
        global $wpdb;

        $table = Ledger::payouts_table();
        $row   = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $payout_id), ARRAY_A);

        if (!$row) return false;
        if ((string) ($row['status'] ?? '') !== 'requested') return false;

        $meta = self::decode_meta($row['meta'] ?? '');
        $meta['approved_at'] = self::now();
        $meta = self::with_trace_meta($meta, ['payout_id' => $payout_id, 'vendor_id' => (int) ($row['vendor_id'] ?? 0)], 'payout_approve');

        $ok = $wpdb->update(
            $table,
            [
                'status'            => 'approved',
                'status_updated_at' => self::now(),
                'decided_by'        => $admin_id > 0 ? $admin_id : null,
                'decided_at'        => self::now(),
                'decision_note'     => $note,
                'meta'              => self::encode_meta($meta),
            ],
            ['id' => $payout_id]
        );

        if ($ok === false) return false;

        do_action('caricove_bank_payout_approved', [
            'payout_id' => $payout_id,
            'vendor_id' => (int) ($row['vendor_id'] ?? 0),
            'admin_id'  => $admin_id,
            'note'      => $note,
        ]);

        return true;
    }

    public static function deny(int $payout_id, int $admin_id = 0, string $note = ''): bool
    {
        global $wpdb;

        $table = Ledger::payouts_table();
        $row   = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $payout_id), ARRAY_A);

        if (!$row) return false;
        if (!in_array((string) ($row['status'] ?? ''), ['requested', 'approved'], true)) return false;

        $meta = self::decode_meta($row['meta'] ?? '');
        $meta['denied_at'] = self::now();
        $meta = self::with_trace_meta($meta, ['payout_id' => $payout_id, 'vendor_id' => (int) ($row['vendor_id'] ?? 0)], 'payout_deny');

        $ok = $wpdb->update(
            $table,
            [
                'status'            => 'denied',
                'status_updated_at' => self::now(),
                'decided_by'        => $admin_id > 0 ? $admin_id : null,
                'decided_at'        => self::now(),
                'decision_note'     => $note,
                'meta'              => self::encode_meta($meta),
            ],
            ['id' => $payout_id]
        );

        if ($ok === false) return false;

        do_action('caricove_bank_payout_denied', [
            'payout_id' => $payout_id,
            'vendor_id' => (int) ($row['vendor_id'] ?? 0),
            'admin_id'  => $admin_id,
            'note'      => $note,
        ]);

        return true;
    }

    public static function execute(int $payout_id, int $admin_id = 0, string $note = ''): bool
    {
        global $wpdb;

        $table = Ledger::payouts_table();
        $row   = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $payout_id), ARRAY_A);

        if (!$row) return false;
        if (!in_array((string) ($row['status'] ?? ''), ['approved', 'requested', 'queued'], true)) return false;

        $vendor_id = (int) ($row['vendor_id'] ?? 0);
        if ($vendor_id <= 0) return false;

        self::run_promotion_cycle();

        [$method, $dest] = self::payout_method($vendor_id);
        if (trim($dest) === '') {
            $wpdb->update(
                $table,
                [
                    'status'            => 'failed',
                    'status_updated_at' => self::now(),
                    'error_text'        => 'No payout destination configured.',
                ],
                ['id' => $payout_id]
            );
            return false;
        }

        $kind      = sanitize_key((string) ($row['kind'] ?? 'instant'));
        $queueMeta = self::decode_meta($row['meta'] ?? '');
        $queueMeta = self::with_trace_meta($queueMeta, ['payout_id' => $payout_id, 'vendor_id' => $vendor_id], 'payout_execute');
        $snapshot  = self::payout_snapshot($vendor_id, $kind);
        $preTruth  = is_array($snapshot['truth'] ?? null) ? $snapshot['truth'] : [];

        $requested_gross = round((float) ($row['amount_gross'] ?? 0), 4);
        $requested_fee   = round((float) ($row['fee'] ?? 0), 4);
        $requested_net   = round((float) ($row['amount_net'] ?? 0), 4);

        if ($requested_gross <= 0.0 && isset($queueMeta['requested_amount'])) {
            $requested_gross = round((float) $queueMeta['requested_amount'], 4);
        }
        if ($requested_net <= 0.0) {
            $requested_net = $requested_gross;
        }

        $current_withdrawable = round((float) ($preTruth['withdrawable_now'] ?? 0), 4);

        if ($requested_net <= 0.0) {
            $wpdb->update(
                $table,
                [
                    'status'            => 'failed',
                    'status_updated_at' => self::now(),
                    'error_text'        => 'Requested amount is invalid.',
                ],
                ['id' => $payout_id]
            );
            return false;
        }

        if ($current_withdrawable <= 0.0) {
            $wpdb->update(
                $table,
                [
                    'status'            => 'failed',
                    'status_updated_at' => self::now(),
                    'error_text'        => 'Seller has no withdrawable balance.',
                ],
                ['id' => $payout_id]
            );
            return false;
        }

        if ($requested_net - $current_withdrawable > 0.009) {
            $queueMeta['execute_blocked_at'] = self::now();
            $queueMeta['execute_block_reason'] = 'requested_amount_exceeds_current_withdrawable';
            $queueMeta['current_withdrawable_when_blocked'] = $current_withdrawable;

            $wpdb->update(
                $table,
                [
                    'status'            => 'failed',
                    'status_updated_at' => self::now(),
                    'error_text'        => 'Current withdrawable balance is lower than the requested payout amount.',
                    'meta'              => self::encode_meta($queueMeta),
                ],
                ['id' => $payout_id]
            );
            return false;
        }

        $gross_before = $requested_gross;
        $fee_before   = $requested_fee;
        $net_before   = $requested_net;

        /*
         * Resolve shipment/order context for payout bank events.
         * For clean single-shipment tests, this lets the shipment financial story
         * see that the seller was actually paid.
         */
        $eventOrderId = 0;
        $eventShipmentId = 0;

        if (!empty($queueMeta['order_id'])) {
            $eventOrderId = (int) $queueMeta['order_id'];
        }
        if (!empty($queueMeta['shipment_id'])) {
            $eventShipmentId = (int) $queueMeta['shipment_id'];
        }

        if ($eventOrderId <= 0 || $eventShipmentId <= 0) {
            $sellerTable = Ledger::table();

            $latestPayableRow = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT order_id, shipment_id
                     FROM {$sellerTable}
                     WHERE vendor_id = %d
                       AND state IN ('available','paid')
                       AND net > 0
                     ORDER BY updated_at DESC, id DESC
                     LIMIT 1",
                    $vendor_id
                ),
                ARRAY_A
            );

            if (is_array($latestPayableRow)) {
                if ($eventOrderId <= 0) {
                    $eventOrderId = (int) ($latestPayableRow['order_id'] ?? 0);
                }
                if ($eventShipmentId <= 0) {
                    $eventShipmentId = (int) ($latestPayableRow['shipment_id'] ?? 0);
                }
            }
        }

        $queueMeta['queued_at']          = self::now();
        $queueMeta['pre_execute_truth']  = $preTruth;
        $queueMeta['queued_by_admin_id'] = $admin_id;
        $queueMeta['queue_note']         = $note;

        $updated = $wpdb->update(
            $table,
            [
                'status'            => 'queued',
                'status_updated_at' => self::now(),
                'amount_gross'      => $gross_before,
                'fee'               => $fee_before,
                'amount_net'        => $net_before,
                'method'            => $method,
                'destination'       => $dest,
                'decided_by'        => $admin_id > 0 ? $admin_id : null,
                'decided_at'        => self::now(),
                'decision_note'     => $note,
                'meta'              => self::encode_meta($queueMeta),
                'error_text'        => null,
            ],
            ['id' => $payout_id]
        );

        if ($updated === false) {
            return false;
        }

        do_action('caricove_bank_payout_queued', [
            'payout_id'     => $payout_id,
            'vendor_id'     => $vendor_id,
            'currency'      => self::currency(),
            'amount_gross'  => $gross_before,
            'fee'           => $fee_before,
            'amount_net'    => $net_before,
            'method'        => $method,
            'destination'   => $dest,
            'reference'     => (string) ($row['reference'] ?? ''),
            'kind'          => $kind,
        ]);

        $ledger_execution = self::execute_ledger_payout($vendor_id, $net_before, $current_withdrawable);

        if (empty($ledger_execution['ok'])) {
            $queueMeta['ledger_supports_exact_amount'] = (bool) ($ledger_execution['supports_exact'] ?? false);
            if (isset($ledger_execution['paid'])) {
                $queueMeta['ledger_returned_amount'] = round((float) $ledger_execution['paid'], 4);
            }

            $wpdb->update(
                $table,
                [
                    'status'            => 'failed',
                    'status_updated_at' => self::now(),
                    'error_text'        => (string) ($ledger_execution['error'] ?? 'Ledger execution failed.'),
                    'meta'              => self::encode_meta($queueMeta),
                ],
                ['id' => $payout_id]
            );

            do_action('caricove_bank_payout_failed', [
                'payout_id' => $payout_id,
                'vendor_id' => $vendor_id,
                'reason'    => 'ledger_execution_failed',
            ]);

            return false;
        }

        $executedTotal = round((float) ($ledger_execution['paid'] ?? 0), 4);
        $ledger_details = is_array($ledger_execution['details'] ?? null) ? $ledger_execution['details'] : [];
        $executed_cash_sources = array_values((array) ($ledger_details['cash_sources'] ?? []));
        $executed_offset_events = array_values((array) ($ledger_details['offset_events'] ?? []));

        if (!empty($executed_cash_sources)) {
            $firstCashSource = (array) $executed_cash_sources[0];
            if (!empty($firstCashSource['order_id'])) {
                $eventOrderId = (int) $firstCashSource['order_id'];
            }
            if (!empty($firstCashSource['shipment_id'])) {
                $eventShipmentId = (int) $firstCashSource['shipment_id'];
            }
        }

        $preAvailable    = round((float) ($preTruth['available'] ?? 0), 4);
        $preDebit        = round((float) ($preTruth['debit_exposure'] ?? 0), 4);
        $preWithdrawable = round((float) ($preTruth['withdrawable_now'] ?? 0), 4);
        $liabilityRecovered = 0.0;
        $actualGross = $executedTotal;
        $actualFee   = 0.0;
        $actualNet   = $actualGross;

        $sentMeta = $queueMeta;
        $sentMeta['executed_at']                 = self::now();
        $sentMeta['executed_total']              = $executedTotal;
        $sentMeta['liability_recovered']         = 0.0;
        $sentMeta['actual_amount_gross']         = $actualGross;
        $sentMeta['actual_fee']                  = $actualFee;
        $sentMeta['actual_amount_net']           = $actualNet;
        $sentMeta['ledger_supports_exact_amount']= (bool) ($ledger_execution['supports_exact'] ?? false);
        $sentMeta['executed_cash_sources']       = $executed_cash_sources;
        $sentMeta['executed_offset_events']      = $executed_offset_events;
        $sentMeta['actual_vs_snapshot']          = [
            'snapshot_gross'      => $gross_before,
            'actual_gross'        => $actualGross,
            'snapshot_fee'        => $fee_before,
            'actual_fee'          => $actualFee,
            'snapshot_net'        => $net_before,
            'actual_net'          => $actualNet,
            'executed_total'      => $executedTotal,
            'liability_recovered' => 0.0,
            'pre_available'       => $preAvailable,
            'pre_debit_exposure'  => $preDebit,
            'pre_withdrawable'    => $preWithdrawable,
        ];

        $done = $wpdb->update(
            $table,
            [
                'status'            => 'sent',
                'status_updated_at' => self::now(),
                'amount_gross'      => $actualGross,
                'fee'               => $actualFee,
                'amount_net'        => $actualNet,
                'method'            => $method,
                'destination'       => $dest,
                'meta'              => self::encode_meta($sentMeta),
                'error_text'        => null,
            ],
            ['id' => $payout_id]
        );

        if ($done === false) {
            return false;
        }

        if ($actualGross > 0) {
            self::record_payout_bank_event(
                'seller_payout_sent',
                $vendor_id,
                $payout_id,
                $actualGross,
                'Seller payout sent',
                [
                    'payout_id'             => $payout_id,
                    'kind'                  => $kind,
                    'reference'             => (string) ($row['reference'] ?? ''),
                    'snapshot_gross'        => $gross_before,
                    'executed_total'        => $executedTotal,
                    'actual_payout_gross'   => $actualGross,
                    'actual_payout_net'     => $actualNet,
                    'liability_recovered'   => 0.0,
                    'order_id'              => $eventOrderId,
                    'shipment_id'           => $eventShipmentId,
                    'cash_sources'          => $executed_cash_sources,
                    'offset_events'         => $executed_offset_events,
                ],
                $eventOrderId,
                $eventShipmentId
            );
        }

        do_action('caricove_bank_payout_completed', [
            'payout_id'     => $payout_id,
            'vendor_id'     => $vendor_id,
            'currency'      => self::currency(),
            'amount_gross'  => $actualGross,
            'fee'           => $actualFee,
            'amount_net'    => $actualNet,
            'method'        => $method,
            'destination'   => $dest,
            'reference'     => (string) ($row['reference'] ?? ''),
            'kind'          => $kind,
            'order_id'      => $eventOrderId,
            'shipment_id'   => $eventShipmentId,
            'cash_sources'  => $executed_cash_sources,
            'offset_events' => $executed_offset_events,
        ]);

        return true;
    }

    /* =========================================================
     * SHIPMENT WATCHER ABSORBED
     * ======================================================= */

    public static function on_meta_change($meta_id, $object_id, $meta_key, $_meta_value): void
    {
        if ($meta_key !== '_cc_shipment_status') return;

        $status = is_string($_meta_value) ? strtolower(trim($_meta_value)) : '';
        if ($status !== 'delivered') return;

        $shipment_id = (int) $object_id;
        if ($shipment_id <= 0) return;

        $order_id  = (int) get_post_meta($shipment_id, '_cc_shipment_order_id', true);
        $vendor_id = (int) get_post_meta($shipment_id, '_cc_shipment_vendor_id', true);

        if ($order_id <= 0 || $vendor_id <= 0) {
            return;
        }

        $verified = (string) get_post_meta($shipment_id, '_cc_shipment_delivery_code_verified', true);
        if ($verified !== '' && strtolower(trim($verified)) !== 'yes') {
            return;
        }

        $delivered_at = self::best_delivered_at($shipment_id);

        $unique_key = 'ship:' . $shipment_id
            . '|order:' . $order_id
            . '|vendor:' . $vendor_id
            . '|delivered';

        Ledger::handle_delivered(
            $unique_key,
            $shipment_id,
            $order_id,
            $vendor_id,
            $delivered_at
        );
    }

    private static function best_delivered_at(int $shipment_id): string
    {
        $t1 = (string) get_post_meta($shipment_id, '_cc_shipment_delivery_code_verified_at', true);
        if (self::is_valid_iso_or_mysql($t1)) {
            return self::to_mysql_datetime($t1);
        }

        $t2 = (string) get_post_meta($shipment_id, '_cc_shipment_last_status_change_at', true);
        if (self::is_valid_iso_or_mysql($t2)) {
            return self::to_mysql_datetime($t2);
        }

        return current_time('mysql');
    }

    private static function is_valid_iso_or_mysql(string $s): bool
    {
        $s = trim($s);
        if ($s === '') return false;
        $ts = strtotime($s);
        return $ts !== false && $ts > 0;
    }

    private static function to_mysql_datetime(string $s): string
    {
        $ts = strtotime($s);
        if (!$ts) return current_time('mysql');
        return date('Y-m-d H:i:s', $ts);
    }

    /* =========================================================
     * RUNNER HEALTH
     * ======================================================= */

    private static function ping(): void
    {
        update_option(self::OPT_LAST_PING, time(), false);
    }

    private static function success(): void
    {
        update_option(self::OPT_LAST_SUCCESS, time(), false);
        update_option(self::OPT_LAST_ERROR, '', false);
    }

    private static function set_error(string $msg): void
    {
        update_option(self::OPT_LAST_PING, time(), false);
        update_option(self::OPT_LAST_ERROR, $msg, false);
    }
}