<?php
namespace Caricove\Bank;
if (!defined('ABSPATH')) exit;

final class BankBalances {
    public static function table(): string {
        global $wpdb;
        return $wpdb->prefix . 'caricove_bank_balances';
    }

    public static function install(): void {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $table = self::table();
        $charset = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE {$table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            entity_type VARCHAR(20) NOT NULL,
            entity_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            pending_balance DECIMAL(20,2) NOT NULL DEFAULT 0.00,
            available_balance DECIMAL(20,2) NOT NULL DEFAULT 0.00,
            held_balance DECIMAL(20,2) NOT NULL DEFAULT 0.00,
            lifetime_credits DECIMAL(20,2) NOT NULL DEFAULT 0.00,
            lifetime_debits DECIMAL(20,2) NOT NULL DEFAULT 0.00,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY entity (entity_type, entity_id)
        ) {$charset};";
        dbDelta($sql);
    }

    public static function refresh_related(array $event): void {
        // Scaffold placeholder: in v1 we refresh platform and any known vendor/courier entity.
        self::upsert('platform', 0, self::snapshot_platform());
        if (!empty($event['vendor_id'])) self::upsert('vendor', (int) $event['vendor_id'], self::snapshot_vendor((int) $event['vendor_id']));
        if (!empty($event['courier_id'])) self::upsert('courier', (int) $event['courier_id'], self::snapshot_courier((int) $event['courier_id']));
    }

    public static function upsert(string $entityType, int $entityId, array $snapshot): void {
        global $wpdb;
        $table = self::table();
        $row = array_merge([
            'entity_type' => $entityType,
            'entity_id' => $entityId,
            'pending_balance' => 0,
            'available_balance' => 0,
            'held_balance' => 0,
            'lifetime_credits' => 0,
            'lifetime_debits' => 0,
            'updated_at' => current_time('mysql'),
        ], $snapshot);
        $wpdb->replace($table, $row);
    }

    public static function snapshot_platform(): array {
        $today = current_time('Y-m-d');
        $commissionToday = BankLedger::sum(['event_type' => 'shipment_earnings_created', 'date_from' => $today . ' 00:00:00']);
        return [
            'pending_balance' => 0,
            'available_balance' => $commissionToday,
            'held_balance' => 0,
            'lifetime_credits' => 0,
            'lifetime_debits' => 0,
            'updated_at' => current_time('mysql'),
        ];
    }

    public static function snapshot_vendor(int $vendorId): array {
        return [
            'pending_balance' => 0,
            'available_balance' => 0,
            'held_balance' => 0,
            'lifetime_credits' => 0,
            'lifetime_debits' => 0,
            'updated_at' => current_time('mysql'),
        ];
    }

    public static function snapshot_courier(int $courierId): array {
        return [
            'pending_balance' => 0,
            'available_balance' => 0,
            'held_balance' => 0,
            'lifetime_credits' => 0,
            'lifetime_debits' => 0,
            'updated_at' => current_time('mysql'),
        ];
    }

    public static function get(string $entityType, int $entityId = 0): array {
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare(
            'SELECT * FROM ' . self::table() . ' WHERE entity_type = %s AND entity_id = %d LIMIT 1',
            $entityType,
            $entityId
        ), ARRAY_A);
        return $row ?: [];
    }
}
