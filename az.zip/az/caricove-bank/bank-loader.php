<?php
if (!defined('ABSPATH')) exit;

define('CARICOVE_BANK_VERSION', '0.1.1');
define('CARICOVE_BANK_DIR', __DIR__);
define('CARICOVE_BANK_URL', content_url('mu-plugins/caricove-bank'));
define('CARICOVE_BANK_FILE', __FILE__);

$bank_files = [
    '/LedgerDoctrine.php',
    '/Ledger-inspector.php',
    '/BankEvents.php',
    '/BankLedger.php',
    '/BankBalances.php',
    '/BankAlerts.php',
    '/BankPaymentRails.php',
    '/BankProviderMirror.php',
    '/BankProviderEvents.php',
    '/BankDashboard.php',
    '/BankCore.php',
    '/PayoutObserver.php',
    '/BankPayouts.php',
    '/BankSellerLedger.php',

    '/vendor-wallet/VendorWalletUIHelpersTrait.php',
    '/vendor-wallet/VendorWalletUICurrentStateTrait.php',
    '/vendor-wallet/VendorWalletUIHistoryStateTrait.php',
    '/vendor-wallet/VendorWalletUICardPresenterTrait.php',
    '/vendor-wallet/VendorWalletUIModalPresenterTrait.php',
    '/vendor-wallet/VendorWalletUIRenderTrait.php',
    '/vendor-wallet/VendorWalletUISaveMethodTrait.php',
    '/vendor-wallet/VendorWalletUI.php',

    '/BankRefundCases.php',
    '/BankRefunds.php',
    '/BankRefundsActions.php',
    '/BankRefundsTable.php',
    '/BankRefundsView.php',
    '/CourierRecoverySourceBridge.php',
    '/courier-tabs/BankCourierPayoutRequestsTab.php',
    '/courier-tabs/BankCourierInstantPayoutRequestsTab.php',
    '/courier-tabs/BankCourierHeldQueueTab.php',
    '/courier-tabs/BankCourierForfeitedTab.php',
    '/courier-tabs/BankCourierRecoveryTab.php',
    '/courier-tabs/BankPlatformFrontedTab.php',
];

foreach ($bank_files as $relative) {
    $path = CARICOVE_BANK_DIR . $relative;
    if (file_exists($path)) {
        require_once $path;
    }
}

$adapter_files = [
    '/adapters/ShipmentAdapter.php',
    '/adapters/RefundAdapter.php',
    '/adapters/PayoutAdapter.php',
    '/adapters/CourierAdapter.php',
];

foreach ($adapter_files as $relative) {
    $path = CARICOVE_BANK_DIR . $relative;
    if (file_exists($path)) {
        require_once $path;
    }
}

if (class_exists('\Caricove\Bank\BankPaymentRails')) {
    \Caricove\Bank\BankPaymentRails::boot();
}

if (class_exists('\Caricove\Bank\BankProviderMirror')) {
    \Caricove\Bank\BankProviderMirror::boot();
}

if (class_exists('\Caricove\Bank\BankProviderEvents')) {
    \Caricove\Bank\BankProviderEvents::boot();
}

if (class_exists('\Caricove\Bank\BankCore')) {
    \Caricove\Bank\BankCore::instance();
}

add_action('init', static function () {
    if (class_exists('\Caricove\SellerPayouts\VendorWalletUI')) {
        (new \Caricove\SellerPayouts\VendorWalletUI())->register();
    }
}, 22);

if (class_exists('\Caricove\Bank\BankRefundsActions')) {
    add_action('init', ['\Caricove\Bank\BankRefundsActions', 'register'], 25);
}

if (class_exists('\Caricove\Bank\BankCourierPayoutRequestsTab')) {
    \Caricove\Bank\BankCourierPayoutRequestsTab::boot();
}

if (class_exists('\Caricove\Bank\BankCourierHeldQueueTab')) {
    \Caricove\Bank\BankCourierHeldQueueTab::boot();
}

if (class_exists('\Caricove\Bank\BankPlatformFrontedTab')) {
    \Caricove\Bank\BankPlatformFrontedTab::boot();
}

if (class_exists('\Caricove\Bank\BankCourierRecoveryTab')) {
    \Caricove\Bank\BankCourierRecoveryTab::boot();
}
