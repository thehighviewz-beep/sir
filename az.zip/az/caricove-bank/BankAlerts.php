<?php
namespace Caricove\Bank;
if (!defined('ABSPATH')) exit;

final class BankAlerts {
    public static function collect(): array {
        return [
            [
                'key' => 'duplicate_shipment_rows',
                'label' => 'Duplicate shipment payout rows',
                'count' => 0,
            ],
            [
                'key' => 'refund_without_seller_deduction',
                'label' => 'Refund without seller deduction',
                'count' => 0,
            ],
            [
                'key' => 'seller_deduction_without_refund',
                'label' => 'Seller deduction without refund',
                'count' => 0,
            ],
            [
                'key' => 'courier_pay_without_delivery_truth',
                'label' => 'Courier payable without delivery truth',
                'count' => 0,
            ],
            [
                'key' => 'available_before_clear',
                'label' => 'Shipment available before clearing',
                'count' => 0,
            ],
        ];
    }
}
