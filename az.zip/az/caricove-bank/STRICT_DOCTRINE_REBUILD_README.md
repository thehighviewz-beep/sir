# Caricove Bank strict doctrine rebuild — fresh baseline

Built from the uploaded older `for fixing.zip` bank folder. This is not based on the broken patched folder.

## New files
- `LedgerDoctrine.php` — strict validator for ledger rows.
- `Ledger-inspector.php` — admin Ledger Inspector with doctrine PASS/FAIL and explicit Force Promote testing.

## Loader
- `bank-loader.php` loads Doctrine and Inspector before the bank modules.

## Bank changes
- `BankSellerLedger.php`
  - disables pending reservation scars.
  - stops writing new `auto-target-*` money edges.
  - splits financial slices when an available row is partially consumed or paid, so slice totals match the row amount.
  - makes `list_for_vendor()` a pure reader.
  - adds trace context for new debit rows.
- `BankRefundCases.php`
  - adds terminal/idempotency helpers.
  - prevents Mark Received / status paths from downgrading final refunded cases.
- `BankRefundsActions.php`
  - one refund click processes sibling item cases in the same RCC return request.
  - does not copy clicked item amounts onto sibling cases.
  - keeps pre-return shipping-only flow single-case.
  - blocks Mark Received after item finality.
- `BankRefunds.php`
  - item refund commit is idempotent when posting already exists.
  - universe commit refuses already fully posted cases.
  - shipping/seller debit rows receive trace context.
- `BankPlatformFrontedTab.php`
  - includes `refunded` in the terminal guard.

## Wallet boundary
- Wallet remains reader-side. No ledger mutation was added.
- The return-balance modal no longer case-filters the shipment grouping.

## Test note
This package is meant for fresh test data. Old polluted test rows should still fail doctrine; that is expected.

## Install
Back up first. Replace:
`/wp-content/mu-plugins/caricove-bank/`
with the `caricove-bank` folder in this zip.
