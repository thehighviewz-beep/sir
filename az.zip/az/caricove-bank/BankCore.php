<?php
namespace Caricove\Bank;
if (!defined('ABSPATH')) exit;

final class BankCore {
    private static ?BankCore $instance = null;

    public static function instance(): BankCore {
        return self::$instance ??= new self();
    }

    private function __construct() {
        add_action('admin_init', [self::class, 'maybe_install']);
        add_action('admin_menu', [$this, 'register_admin_menu']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_assets']);
        add_action('rest_api_init', [$this, 'register_rest_routes']);
        add_action('init', [$this, 'boot_adapters'], 20);
        add_action('init', [$this, 'boot_observers'], 20);
        if (class_exists(__NAMESPACE__ . '\\BankPayouts')) {
            add_action('init', [BankPayouts::class, 'register'], 21);
        }
    }

    public static function maybe_install(): void {
        if (class_exists(__NAMESPACE__ . '\\Ledger') && method_exists(__NAMESPACE__ . '\\Ledger', 'maybe_install_schema_repairs')) {
            Ledger::maybe_install_schema_repairs();
        }

        $installed = get_option('caricove_bank_version');
        if ($installed === CARICOVE_BANK_VERSION) return;
        if (class_exists(__NAMESPACE__ . '\\BankLedger')) {
            BankLedger::install();
        }
        if (class_exists(__NAMESPACE__ . '\\BankBalances')) {
            BankBalances::install();
        }
        update_option('caricove_bank_version', CARICOVE_BANK_VERSION, false);
    }

    public function register_admin_menu(): void {
        if (!class_exists(__NAMESPACE__ . '\\BankDashboard')) {
            return;
        }

        add_menu_page(
            __('Caricove Bank', 'caricove'),
            __('Caricove Bank', 'caricove'),
            'manage_woocommerce',
            'caricove-bank',
            [BankDashboard::class, 'render_page'],
            'dashicons-chart-area',
            56
        );
    }

    public function enqueue_assets(string $hook): void {
        if ($hook !== 'toplevel_page_caricove-bank') return;
        wp_enqueue_style('caricove-bank', CARICOVE_BANK_URL . '/assets/bank.css', [], CARICOVE_BANK_VERSION);
        wp_enqueue_script('caricove-bank', CARICOVE_BANK_URL . '/assets/bank.js', ['jquery'], CARICOVE_BANK_VERSION, true);
        wp_localize_script('caricove-bank', 'CaricoveBank', [
            'restUrl' => esc_url_raw(rest_url('caricove-bank/v1')),
            'nonce'   => wp_create_nonce('wp_rest'),
        ]);
    }

    public function register_rest_routes(): void {
        if (!class_exists(__NAMESPACE__ . '\\BankDashboard')) {
            return;
        }

        register_rest_route('caricove-bank/v1', '/overview', [
            'methods'  => 'GET',
            'callback' => [BankDashboard::class, 'rest_overview'],
            'permission_callback' => fn() => current_user_can('manage_woocommerce'),
        ]);
        register_rest_route('caricove-bank/v1', '/ledger', [
            'methods'  => 'GET',
            'callback' => [BankDashboard::class, 'rest_ledger'],
            'permission_callback' => fn() => current_user_can('manage_woocommerce'),
        ]);
    }

    public function boot_adapters(): void {
        foreach (['ShipmentAdapter', 'RefundAdapter', 'PayoutAdapter', 'CourierAdapter'] as $adapter) {
            $fqcn = __NAMESPACE__ . '\\' . $adapter;
            if (class_exists($fqcn) && method_exists($fqcn, 'boot')) {
                $fqcn::boot();
            }
        }
    }

    public function boot_observers(): void {
        if (class_exists(__NAMESPACE__ . '\\PayoutObserver') && method_exists(PayoutObserver::class, 'boot')) {
            PayoutObserver::boot();
        }
    }
}
