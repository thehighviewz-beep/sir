<?php
namespace Caricove\Bank;

if (!defined('ABSPATH')) exit;

/**
 * Caricove Bank Provider Mirror — Phase 2C
 *
 * Read-only provider balance proof for the Platform Wallet.
 * This class never creates charges, refunds, transfers, payouts, or owner withdrawals.
 */
final class BankProviderMirror
{
    public const SNAPSHOT_OPTION = 'caricove_bank_provider_balance_snapshot_v1';
    public const LAST_ERROR_OPTION = 'caricove_bank_provider_balance_last_error_v1';
    public const ADMIN_SYNC_ACTION = 'caricove_bank_provider_balance_sync';
    public const ADMIN_SYNC_NONCE = 'caricove_bank_provider_balance_sync';

    public static function boot(): void
    {
        add_action('admin_post_' . self::ADMIN_SYNC_ACTION, [__CLASS__, 'handle_admin_sync']);
    }

    public static function can_manage(): bool
    {
        return current_user_can('manage_woocommerce') || current_user_can('manage_options');
    }

    public static function handle_admin_sync(): void
    {
        if (!self::can_manage()) {
            wp_die(esc_html__('You do not have permission to sync provider balances.', 'caricove'));
        }

        check_admin_referer(self::ADMIN_SYNC_NONCE);

        $result = self::sync_now();
        $tab = isset($_POST['redirect_tab']) ? sanitize_key((string) wp_unslash($_POST['redirect_tab'])) : 'payment_setup';
        if ($tab === '') {
            $tab = 'payment_setup';
        }

        $args = [
            'page' => 'caricove-bank',
            'tab' => $tab,
            'provider_sync' => !empty($result['ok']) ? 'synced' : 'failed',
        ];

        if (empty($result['ok'])) {
            $message = isset($result['message']) ? (string) $result['message'] : 'Provider balance sync failed.';
            $args['provider_sync_msg'] = rawurlencode(substr($message, 0, 220));
        }

        wp_safe_redirect(add_query_arg($args, admin_url('admin.php')));
        exit;
    }

    public static function sync_now(): array
    {
        $setup = (array) get_option('caricove_bank_payment_setup_v1', []);
        $provider = sanitize_key((string) ($setup['preferred_provider'] ?? 'not_selected'));
        $environment = sanitize_key((string) ($setup['provider_environment'] ?? 'test'));

        if ($provider === 'stripe') {
            return self::sync_stripe($environment);
        }
        $labels = [
            'mmg' => 'MMG',
            'card_gateway' => 'Card Gateway',
            'wipay' => 'WiPay',
            'republic_epay' => 'Republic EPay',
            'scotia_ecom' => 'Scotia eCom+',
            'paypal' => 'PayPal',
            'manual_bank' => 'Manual bank',
            'local_bank' => 'Local provider',
        ];
        $label = (string) ($labels[$provider] ?? 'Provider');
        $message = $provider === 'not_selected'
            ? 'Choose a payment provider/rail in Payment Setup or Guyana Rails before syncing a provider balance.'
            : $label . ' balance sync is not wired yet. For Guyana rails, cash proof stays locked until the MMG/card gateway adapter can verify provider balance or settlement proof.';
        self::store_error($provider, $environment, $message);

        return [
            'ok' => false,
            'provider' => $provider,
            'message' => $message,
        ];
    }

    public static function snapshot(): array
    {
        $defaults = self::default_snapshot();
        $snapshot = get_option(self::SNAPSHOT_OPTION, []);

        if (!is_array($snapshot) || empty($snapshot)) {
            $error = get_option(self::LAST_ERROR_OPTION, []);
            if (is_array($error) && !empty($error)) {
                $defaults['status'] = 'error';
                $defaults['status_label'] = 'Sync failed';
                $defaults['status_message'] = (string) ($error['message'] ?? 'Last provider balance sync failed.');
                $defaults['last_error_at'] = (string) ($error['created_at'] ?? '');
            }
            return $defaults;
        }

        $snapshot = wp_parse_args($snapshot, $defaults);

        $snapshot['provider'] = sanitize_key((string) ($snapshot['provider'] ?? '')) ?: 'unknown';
        $snapshot['label'] = sanitize_text_field((string) ($snapshot['label'] ?? 'Provider'));
        $snapshot['mode'] = sanitize_key((string) ($snapshot['mode'] ?? 'unknown'));
        $snapshot['status'] = sanitize_key((string) ($snapshot['status'] ?? 'unknown'));
        $snapshot['status_label'] = sanitize_text_field((string) ($snapshot['status_label'] ?? 'Unknown'));
        $snapshot['status_message'] = sanitize_text_field((string) ($snapshot['status_message'] ?? ''));
        $snapshot['available'] = max(0.0, (float) ($snapshot['available'] ?? 0));
        $snapshot['pending'] = max(0.0, (float) ($snapshot['pending'] ?? 0));
        $snapshot['withheld'] = max(0.0, (float) ($snapshot['withheld'] ?? 0));
        $snapshot['target_currency'] = strtoupper(sanitize_text_field((string) ($snapshot['target_currency'] ?? self::target_currency())));
        $snapshot['available_by_currency'] = self::sanitize_currency_map((array) ($snapshot['available_by_currency'] ?? []));
        $snapshot['pending_by_currency'] = self::sanitize_currency_map((array) ($snapshot['pending_by_currency'] ?? []));
        $snapshot['reserved_by_currency'] = self::sanitize_currency_map((array) ($snapshot['reserved_by_currency'] ?? []));
        $snapshot['synced_at'] = sanitize_text_field((string) ($snapshot['synced_at'] ?? 'Never'));
        $snapshot['synced_at_unix'] = max(0, (int) ($snapshot['synced_at_unix'] ?? 0));
        $snapshot['expires_at'] = sanitize_text_field((string) ($snapshot['expires_at'] ?? ''));
        $snapshot['request_id'] = sanitize_text_field((string) ($snapshot['request_id'] ?? ''));
        $snapshot['currency_policy'] = sanitize_text_field((string) ($snapshot['currency_policy'] ?? 'count_target_currency_only'));
        $snapshot['key_source'] = sanitize_text_field((string) ($snapshot['key_source'] ?? ''));

        $fresh = self::is_fresh($snapshot);
        $snapshot['fresh'] = $fresh;
        $snapshot['stale'] = !$fresh;

        if ($snapshot['status'] === 'ok' && $fresh) {
            $snapshot['connected'] = true;
            $snapshot['status_label'] = 'Synced';
            if ($snapshot['status_message'] === '') {
                $snapshot['status_message'] = 'Provider balance snapshot is fresh.';
            }
        } elseif ($snapshot['status'] === 'ok' && !$fresh) {
            $snapshot['connected'] = false;
            $snapshot['status'] = 'stale';
            $snapshot['status_label'] = 'Stale';
            $snapshot['status_message'] = 'Provider balance snapshot is stale. Sync again before trusting owner takeout.';
        } else {
            $snapshot['connected'] = false;
        }

        return $snapshot;
    }

    public static function default_snapshot(): array
    {
        return [
            'connected' => false,
            'fresh' => false,
            'stale' => true,
            'provider' => 'not_connected',
            'label' => 'Not connected',
            'mode' => 'not wired',
            'status' => 'not_wired',
            'status_label' => 'Not wired',
            'status_message' => 'Provider balance mirror has not synced real cash yet.',
            'available' => 0.0,
            'pending' => 0.0,
            'withheld' => 0.0,
            'target_currency' => self::target_currency(),
            'available_by_currency' => [],
            'pending_by_currency' => [],
            'reserved_by_currency' => [],
            'currency_policy' => 'count_target_currency_only',
            'synced_at' => 'Never',
            'synced_at_unix' => 0,
            'expires_at' => '',
            'request_id' => '',
            'key_source' => '',
        ];
    }

    public static function stripe_key_status(string $environment = ''): array
    {
        $environment = sanitize_key($environment ?: (string) ((array) get_option('caricove_bank_payment_setup_v1', []))['provider_environment'] ?? 'test');
        [$key, $source] = self::stripe_key($environment);

        return [
            'ready' => $key !== '',
            'source' => $source,
            'mode' => self::key_mode($key, $environment),
            'masked' => $key !== '' ? self::mask_key($key) : '',
        ];
    }

    public static function sync_button_html(string $redirect_tab = 'payment_setup', string $label = 'Sync Stripe Balance Now'): string
    {
        if (!self::can_manage()) {
            return '';
        }

        $action = esc_url(admin_url('admin-post.php'));
        $nonce = wp_nonce_field(self::ADMIN_SYNC_NONCE, '_wpnonce', true, false);
        $redirect_tab = sanitize_key($redirect_tab ?: 'payment_setup');

        return '<form method="post" action="' . $action . '" style="display:inline-flex;gap:10px;align-items:center;flex-wrap:wrap">'
            . '<input type="hidden" name="action" value="' . esc_attr(self::ADMIN_SYNC_ACTION) . '">'
            . '<input type="hidden" name="redirect_tab" value="' . esc_attr($redirect_tab) . '">'
            . $nonce
            . '<button type="submit" class="button button-primary">' . esc_html($label) . '</button>'
            . '<span style="color:#36506f;font-size:12px;line-height:1.35">Read-only: fetches balance proof only. No charges, refunds, payouts, or transfers.</span>'
            . '</form>';
    }

    private static function sync_stripe(string $environment): array
    {
        [$key, $key_source] = self::stripe_key($environment);

        if ($key === '') {
            $message = 'Stripe key missing. Add a read-only/restricted Stripe key to wp-config.php or server environment before syncing.';
            self::store_error('stripe', $environment, $message);
            return ['ok' => false, 'provider' => 'stripe', 'message' => $message];
        }

        $response = wp_remote_get('https://api.stripe.com/v1/balance', [
            'timeout' => 20,
            'headers' => [
                'Authorization' => 'Bearer ' . $key,
                'User-Agent' => 'CaricoveBankProviderMirror/2C',
            ],
        ]);

        if (is_wp_error($response)) {
            $message = 'Stripe balance sync failed: ' . $response->get_error_message();
            self::store_error('stripe', $environment, $message);
            return ['ok' => false, 'provider' => 'stripe', 'message' => $message];
        }

        $code = (int) wp_remote_retrieve_response_code($response);
        $body = (string) wp_remote_retrieve_body($response);
        $request_id = '';
        $headers = wp_remote_retrieve_headers($response);
        if (is_object($headers) && method_exists($headers, 'offsetGet')) {
            $request_id = (string) ($headers->offsetGet('request-id') ?: $headers->offsetGet('Request-Id') ?: '');
        } elseif (is_array($headers)) {
            $request_id = (string) ($headers['request-id'] ?? $headers['Request-Id'] ?? '');
        }

        $decoded = json_decode($body, true);
        if (!is_array($decoded)) {
            $message = 'Stripe returned a non-JSON balance response.';
            self::store_error('stripe', $environment, $message);
            return ['ok' => false, 'provider' => 'stripe', 'message' => $message];
        }

        if ($code < 200 || $code >= 300) {
            $stripe_message = (string) ($decoded['error']['message'] ?? ('HTTP ' . $code));
            $message = 'Stripe balance sync failed: ' . $stripe_message;
            self::store_error('stripe', $environment, $message, ['http_code' => $code, 'request_id' => $request_id]);
            return ['ok' => false, 'provider' => 'stripe', 'message' => $message];
        }

        $target_currency = self::target_currency();
        $available_by_currency = self::sum_stripe_balance_lines((array) ($decoded['available'] ?? []));
        $pending_by_currency = self::sum_stripe_balance_lines((array) ($decoded['pending'] ?? []));
        $reserved_by_currency = self::sum_stripe_balance_lines((array) ($decoded['connect_reserved'] ?? []));

        $target_key = strtolower($target_currency);
        $available = (float) ($available_by_currency[$target_key] ?? 0.0);
        $pending = (float) ($pending_by_currency[$target_key] ?? 0.0);
        $withheld = (float) ($reserved_by_currency[$target_key] ?? 0.0);

        $has_other_currency = self::has_non_target_currency($available_by_currency, $target_key)
            || self::has_non_target_currency($pending_by_currency, $target_key)
            || self::has_non_target_currency($reserved_by_currency, $target_key);

        $status_message = 'Stripe balance synced. Only ' . strtoupper($target_currency) . ' amounts are counted toward Platform Wallet.';
        if ($available <= 0 && $has_other_currency) {
            $status_message = 'Stripe balance synced, but no ' . strtoupper($target_currency) . ' available balance was found. Other currencies are shown as proof but do not unlock GYD spendable cash yet.';
        }

        $now = current_time('mysql');
        $expires = gmdate('Y-m-d H:i:s', time() + self::snapshot_max_age_seconds());

        $snapshot = [
            'connected' => true,
            'fresh' => true,
            'stale' => false,
            'provider' => 'stripe',
            'label' => 'Stripe',
            'mode' => !empty($decoded['livemode']) ? 'live' : 'test',
            'configured_environment' => $environment,
            'status' => 'ok',
            'status_label' => 'Synced',
            'status_message' => $status_message,
            'available' => max(0.0, $available),
            'pending' => max(0.0, $pending),
            'withheld' => max(0.0, $withheld),
            'target_currency' => strtoupper($target_currency),
            'available_by_currency' => $available_by_currency,
            'pending_by_currency' => $pending_by_currency,
            'reserved_by_currency' => $reserved_by_currency,
            'currency_policy' => 'count_target_currency_only',
            'synced_at' => $now,
            'synced_at_unix' => time(),
            'expires_at' => $expires,
            'request_id' => $request_id,
            'key_source' => $key_source,
            'key_mode' => self::key_mode($key, $environment),
            'raw_object' => sanitize_text_field((string) ($decoded['object'] ?? 'balance')),
        ];

        update_option(self::SNAPSHOT_OPTION, $snapshot, false);
        delete_option(self::LAST_ERROR_OPTION);

        return [
            'ok' => true,
            'provider' => 'stripe',
            'message' => $status_message,
            'snapshot' => $snapshot,
        ];
    }

    private static function stripe_key(string $environment): array
    {
        $environment = sanitize_key($environment ?: 'test');
        $candidates = [];

        if ($environment === 'live') {
            $candidates = [
                'CARICOVE_STRIPE_LIVE_RESTRICTED_KEY',
                'CARICOVE_STRIPE_LIVE_SECRET_KEY',
                'CARICOVE_STRIPE_BALANCE_KEY',
                'CARICOVE_STRIPE_SECRET_KEY',
                'STRIPE_LIVE_SECRET_KEY',
                'STRIPE_SECRET_KEY',
            ];
        } else {
            $candidates = [
                'CARICOVE_STRIPE_TEST_RESTRICTED_KEY',
                'CARICOVE_STRIPE_TEST_SECRET_KEY',
                'CARICOVE_STRIPE_BALANCE_KEY',
                'CARICOVE_STRIPE_SECRET_KEY',
                'STRIPE_TEST_SECRET_KEY',
                'STRIPE_SECRET_KEY',
            ];
        }

        foreach ($candidates as $name) {
            $value = self::constant_or_env($name);
            if ($value !== '') {
                return [$value, $name];
            }
        }

        return ['', ''];
    }

    private static function constant_or_env(string $name): string
    {
        if (defined($name) && is_scalar(constant($name))) {
            $value = trim((string) constant($name));
            if ($value !== '') {
                return $value;
            }
        }

        $env = getenv($name);
        if (is_string($env) && trim($env) !== '') {
            return trim($env);
        }

        if (isset($_ENV[$name]) && is_scalar($_ENV[$name]) && trim((string) $_ENV[$name]) !== '') {
            return trim((string) $_ENV[$name]);
        }

        return '';
    }

    private static function sum_stripe_balance_lines(array $lines): array
    {
        $totals = [];
        foreach ($lines as $line) {
            if (!is_array($line)) {
                continue;
            }
            $currency = strtolower(sanitize_text_field((string) ($line['currency'] ?? '')));
            if ($currency === '') {
                continue;
            }
            $amount_minor = (float) ($line['amount'] ?? 0);
            $amount_major = $amount_minor / self::currency_divisor($currency);
            if (!isset($totals[$currency])) {
                $totals[$currency] = 0.0;
            }
            $totals[$currency] += $amount_major;
        }

        foreach ($totals as $currency => $amount) {
            $totals[$currency] = round((float) $amount, 2);
        }

        ksort($totals);
        return $totals;
    }

    private static function sanitize_currency_map(array $map): array
    {
        $out = [];
        foreach ($map as $currency => $amount) {
            $code = strtolower(sanitize_key((string) $currency));
            if ($code === '') {
                continue;
            }
            $out[$code] = round(max(0.0, (float) $amount), 2);
        }
        ksort($out);
        return $out;
    }

    private static function has_non_target_currency(array $map, string $target_key): bool
    {
        foreach ($map as $currency => $amount) {
            if ((string) $currency !== $target_key && (float) $amount > 0) {
                return true;
            }
        }
        return false;
    }

    private static function currency_divisor(string $currency): int
    {
        $zero_decimal = [
            'bif','clp','djf','gnf','jpy','kmf','krw','mga','pyg','rwf','ugx','vnd','vuv','xaf','xof','xpf',
        ];
        return in_array(strtolower($currency), $zero_decimal, true) ? 1 : 100;
    }

    private static function target_currency(): string
    {
        if (function_exists('get_woocommerce_currency')) {
            $currency = (string) get_woocommerce_currency();
        } else {
            $currency = (string) get_option('woocommerce_currency', 'GYD');
        }
        $currency = strtoupper(preg_replace('/[^A-Z]/', '', strtoupper($currency)) ?: 'GYD');
        return $currency ?: 'GYD';
    }

    private static function snapshot_max_age_seconds(): int
    {
        if (defined('CARICOVE_BANK_PROVIDER_SNAPSHOT_MAX_AGE_SECONDS')) {
            $value = (int) constant('CARICOVE_BANK_PROVIDER_SNAPSHOT_MAX_AGE_SECONDS');
            if ($value > 0) {
                return $value;
            }
        }
        return 3600;
    }

    private static function is_fresh(array $snapshot): bool
    {
        if (($snapshot['status'] ?? '') !== 'ok') {
            return false;
        }

        $ts = (int) ($snapshot['synced_at_unix'] ?? 0);
        if ($ts <= 0) {
            $synced_at = (string) ($snapshot['synced_at'] ?? '');
            if ($synced_at === '' || $synced_at === 'Never') {
                return false;
            }

            $ts = strtotime($synced_at) ?: 0;
        }

        if ($ts <= 0) {
            return false;
        }

        return (time() - $ts) <= self::snapshot_max_age_seconds();
    }

    private static function key_mode(string $key, string $fallback): string
    {
        if (strpos($key, '_live_') !== false) {
            return 'live';
        }
        if (strpos($key, '_test_') !== false) {
            return 'test';
        }
        return sanitize_key($fallback ?: 'unknown');
    }

    private static function mask_key(string $key): string
    {
        $len = strlen($key);
        if ($len <= 10) {
            return str_repeat('•', max(4, $len));
        }
        return substr($key, 0, 7) . '…' . substr($key, -4);
    }

    private static function store_error(string $provider, string $environment, string $message, array $extra = []): void
    {
        $payload = array_merge([
            'provider' => sanitize_key($provider ?: 'unknown'),
            'environment' => sanitize_key($environment ?: 'unknown'),
            'message' => sanitize_text_field($message),
            'created_at' => current_time('mysql'),
        ], $extra);

        update_option(self::LAST_ERROR_OPTION, $payload, false);
    }
}
