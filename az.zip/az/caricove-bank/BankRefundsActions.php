<?php
namespace Caricove\Bank;

if (!defined('ABSPATH')) exit;

final class BankRefundsActions
{
    private static function has_explicit_fault_verdict(array $case, array $preview = []): bool
    {
        $resolved_party = sanitize_key((string) ($preview['resolved_fault_party'] ?? $case['resolved_fault_party'] ?? ''));
        if (in_array($resolved_party, ['seller', 'carrier'], true)) {
            return true;
        }

        $resolution_status = sanitize_key((string) ($preview['fault_resolution_status'] ?? $case['fault_resolution_status'] ?? ''));
        if ($resolution_status === 'resolved') {
            $shipping_party = sanitize_key((string) ($preview['shipping_liability_party'] ?? $case['shipping_liability_party'] ?? ''));
            return in_array($shipping_party, ['seller', 'carrier'], true);
        }

        return false;
    }

    public static function register(): void
    {
        add_action('wp_ajax_caricove_bank_refund_preview', [self::class, 'handle_preview']);
        add_action('wp_ajax_caricove_bank_refund_commit', [self::class, 'handle_refund']);
        add_action('wp_ajax_caricove_bank_refund_decline', [self::class, 'handle_decline']);
        add_action('wp_ajax_caricove_bank_refund_received_qty', [self::class, 'handle_received_qty']);
    }

    private static function resolve_fault_party_for_actions(array $case, array $preview = []): string
    {
        foreach (['resolved_fault_party', 'shipping_liability_party', 'initial_fault', 'fault', 'shipping_payer'] as $key) {
            $party = sanitize_key((string) ($preview[$key] ?? $case[$key] ?? ''));
            if (in_array($party, ['seller', 'carrier', 'customer'], true)) {
                return $party;
            }
            if (in_array($party, ['vendor', 'merchant'], true)) {
                return 'seller';
            }
            if (in_array($party, ['courier', 'shipping', 'logistics'], true)) {
                return 'carrier';
            }
            if (in_array($party, ['buyer', 'user', 'cx', 'none', 'clear'], true)) {
                return 'customer';
            }
        }
        return 'customer';
    }

    private static function is_pre_return_shipping_only_case(array $case, array $preview = []): bool
    {
        $mode = (string) ($preview['refund_execution_mode'] ?? $case['refund_execution_mode'] ?? '');
        $return_required = !empty($case['return_required']);
        $qty_received = (int) ($case['qty_received'] ?? 0);
        $item_received = ($qty_received > 0);
        $shipping_refund = (float) ($preview['outbound_shipping_refund_amount_customer'] ?? $case['outbound_shipping_refund_amount_customer'] ?? 0);
        $shipping_posted = trim((string) ($case['shipping_refund_posting_key'] ?? '')) !== '';
        $fault_party = self::resolve_fault_party_for_actions($case, $preview);

        return (
            $return_required
            && $mode !== 'never_received'
            && !$item_received
            && $qty_received <= 0
            && $shipping_refund > 0
            && !$shipping_posted
            && $fault_party === 'seller'
        );
    }

    public static function handle_refund(): void
    {
        self::guard();

        $case_id = sanitize_text_field($_POST['case_id'] ?? '');
        if ($case_id === '') {
            self::json_error('Missing case_id');
        }

        $case = BankRefundCases::get_case($case_id);
        if (!$case) {
            self::json_error('Refund case not found');
        }

        if (self::case_item_final($case)) {
            self::json_error('Refund already processed');
        }

        $base_overrides = self::collect_overrides($_POST, $case);
        $preview = BankRefunds::preview_refund($case, $base_overrides);
        $pre_return_shipping_only = self::is_pre_return_shipping_only_case($case, $preview);

        if ((string) ($preview['refund_execution_mode'] ?? $case['refund_execution_mode'] ?? '') === 'never_received' && !self::has_explicit_fault_verdict($case, $preview)) {
            self::json_error('Never received refunds require a resolved seller or courier fault verdict in tickets before execution.');
        }

        /* STRICT SINGLE-CASE ACTION: one refund button refunds only one case_id / order_item_id. */
        $cases_to_commit = [$case];

        $admin_note = sanitize_textarea_field((string) ($_POST['admin_note'] ?? 'Refund executed through Bank'));
        $results = [];
        $total_customer = 0.0;
        $total_item = 0.0;
        $total_shipping = 0.0;
        $modes = [];
        $first_error = '';

        foreach ($cases_to_commit as $case_to_commit) {
            $candidate_id = (string) ($case_to_commit['case_id'] ?? '');
            if ($candidate_id === '' || self::case_item_final($case_to_commit)) {
                continue;
            }

            $overrides = self::collect_overrides($_POST, $case_to_commit);

            // Never copy the clicked item's amount or shipping selection onto sibling cases.
            if ($candidate_id !== $case_id) {
                unset(
                    $overrides['refund_amount_requested'],
                    $overrides['refund_amount_approved'],
                    $overrides['item_refund_amount_customer'],
                    $overrides['outbound_shipping_refund_amount_customer'],
                    $overrides['shipping_refund_selected']
                );
            }

            $candidate_preview = BankRefunds::preview_refund($case_to_commit, $overrides);
            $candidate_pre_shipping = self::is_pre_return_shipping_only_case($case_to_commit, $candidate_preview);

            if ($candidate_pre_shipping) {
                if ($candidate_id !== $case_id) {
                    continue;
                }

                $shipping_only_amount = round((float) ($candidate_preview['outbound_shipping_refund_amount_customer'] ?? 0), 2);
                if ($shipping_only_amount <= 0) {
                    self::json_error('No outbound shipping refund is available for pre-return execution.');
                }

                $overrides['item_refund_amount_customer'] = 0.0;
                $overrides['refund_amount_requested'] = 0.0;
                $overrides['refund_amount_approved'] = 0.0;
                $overrides['outbound_shipping_refund_amount_customer'] = $shipping_only_amount;
                $overrides['shipping_refund_selected'] = 1;
                $overrides['item_received_flag'] = 0;
                $overrides['qty_received'] = 0;
                $overrides['qty_refundable'] = 0;
                $overrides['refund_execution_mode'] = 'return_required';

                $candidate_preview = BankRefunds::preview_refund($case_to_commit, $overrides);
                if ((float) ($candidate_preview['item_refund_amount_customer'] ?? 0) > 0) {
                    self::json_error('Pre-return shipping-only flow is still surfacing an item refund amount. Stop and fix BankRefunds preview gating first.');
                }
            } else {
                $item_amount = round((float) ($candidate_preview['item_refund_amount_customer'] ?? $candidate_preview['refund_amount'] ?? 0), 2);
                if ($item_amount <= 0) {
                    continue;
                }
                if ((int) ($case_to_commit['qty_received'] ?? 0) <= 0 && empty($case_to_commit['item_received_flag']) && !empty($case_to_commit['return_required'])) {
                    continue;
                }
            }

            if ((float) ($candidate_preview['customer_total_refund'] ?? 0) <= 0) {
                continue;
            }

            $result = method_exists(BankRefunds::class, 'commit_refund_universe')
                ? BankRefunds::commit_refund_universe($case_to_commit, $overrides)
                : BankRefunds::commit_refund($case_to_commit, $overrides);

            if (empty($result['success'])) {
                $first_error = (string) ($result['error'] ?? 'Refund failed');
                continue;
            }

            if ($candidate_pre_shipping) {
                BankRefundCases::mark_financial_state(
                    $candidate_id,
                    'shipping_posted',
                    [
                        'financial_txn_ref' => (string) ($result['shipping_refund_posting_key'] ?? $result['shipping_posting_key'] ?? ''),
                    ]
                );
                BankRefundCases::update_case($candidate_id, [
                    'shipping_posting_status' => 'posted',
                    'shipping_visibility_status' => 'visible',
                    'shipping_refund_selected' => 1,
                    'item_received_flag' => 0,
                    'qty_received' => 0,
                    'item_refund_amount_customer' => 0.0,
                    'seller_debit_exposure_amount' => 0.0,
                    'seller_debit_exposure_status' => '',
                    'seller_debit_exposure_posting_key' => '',
                ]);
            } else {
                BankRefundCases::update_case($candidate_id, [
                    'status' => 'refunded',
                    'admin_user_id' => get_current_user_id(),
                    'admin_note' => $admin_note !== '' ? $admin_note : 'Refund executed through Bank',
                    'admin_reviewed_at' => time(),
                    'item_refund_posting_key' => (string) ($result['item_refund_posting_key'] ?? ('refund:' . $candidate_id . ':item')),
                    'item_refund_amount_customer' => round((float) ($result['item_refund_amount_customer'] ?? $result['amount'] ?? 0), 2),
                    'refund_amount_approved' => round((float) ($result['item_refund_amount_customer'] ?? $result['amount'] ?? 0), 2),
                ]);
                BankRefundCases::mark_financial_state(
                    $candidate_id,
                    (string) ($result['financial_status'] ?? 'refund_posted'),
                    [
                        'financial_txn_ref' => (string) ($result['financial_txn_ref'] ?? $result['item_refund_posting_key'] ?? ''),
                        'refund_amount_approved' => round((float) ($result['item_refund_amount_customer'] ?? $result['amount'] ?? 0), 2),
                    ]
                );
                BankRefundCases::set_status(
                    $candidate_id,
                    'refunded',
                    [
                        'admin_user_id' => get_current_user_id(),
                        'admin_note'    => $admin_note !== '' ? $admin_note : 'Refund executed through Bank',
                    ]
                );
            }

            $results[] = ['case_id' => $candidate_id, 'result' => $result];
            $total_customer += round((float) ($result['customer_total_refund'] ?? $result['amount'] ?? 0), 2);
            $total_item += round((float) ($result['item_refund_amount_customer'] ?? 0), 2);
            $total_shipping += round((float) ($result['outbound_shipping_refund_amount_customer'] ?? 0), 2);
            $modes[] = (string) ($result['mode'] ?? 'mixed');
        }

        if (!$results) {
            self::json_error($first_error !== '' ? $first_error : 'No refund-ready cases were processed');
        }

        self::json_success([
            'mode'                         => count(array_unique($modes)) === 1 ? reset($modes) : 'batch',
            'batch_count'                  => count($results),
            'processed_cases'              => array_map(static fn($entry) => (string) ($entry['case_id'] ?? ''), $results),
            'amount'                       => round($total_customer, 2),
            'item_refund_amount_customer'  => round($total_item, 2),
            'outbound_shipping_refund_amount_customer' => round($total_shipping, 2),
            'customer_total_refund'        => round($total_customer, 2),
            'reload'                       => true,
        ]);
    }

    public static function handle_preview(): void
    {
        self::guard();

        $case_id = sanitize_text_field($_POST['case_id'] ?? '');
        if ($case_id === '') {
            self::json_error('Missing case_id');
        }

        $case = BankRefundCases::get_case($case_id);
        if (!$case) {
            self::json_error('Refund case not found');
        }

        $overrides = self::collect_overrides($_POST, $case);
        $preview   = BankRefunds::preview_refund($case, $overrides);
        $pre_return_shipping_only = self::is_pre_return_shipping_only_case($case, $preview);
        $requires_fault_verdict = ((string) ($preview['refund_execution_mode'] ?? $case['refund_execution_mode'] ?? '') === 'never_received' && !self::has_explicit_fault_verdict($case, $preview));

        if ($pre_return_shipping_only) {
            $shipping_only_amount = round((float) ($preview['outbound_shipping_refund_amount_customer'] ?? 0), 2);
            $shipping_party = (string) ($preview['shipping_liability_party'] ?? '');

            $preview['refund_amount'] = 0.0;
            $preview['item_refund_amount_customer'] = 0.0;
            $preview['customer_total_refund'] = $shipping_only_amount;
            $preview['customer_gets_back'] = $shipping_only_amount;
            $preview['item_received_flag'] = 0;
            $preview['qty_refundable'] = 0;
            $preview['seller_outcome_label'] = 'Shipping-only pre-return commit';
            $preview['seller_outcome_amount'] = 0.0;
            $preview['seller_impact'] = 0.0;
            $preview['reversal_amount'] = 0.0;
            $preview['debit_amount'] = 0.0;
            $preview['source_open_amount'] = 0.0;
            $preview['target_unwind_amount'] = 0.0;
            $preview['target_unwind_total'] = 0.0;
            $preview['commission_reversal'] = 0.0;
            $preview['commission_absorbed'] = 0.0;
            $preview['seller_debit_exposure_amount'] = 0.0;
            $preview['seller_shipping_impact'] = $shipping_party === 'seller' ? $shipping_only_amount : 0.0;
            $preview['courier_shipping_impact'] = $shipping_party === 'carrier' ? $shipping_only_amount : 0.0;
            $preview['shipping_liability_amount_internal'] = $shipping_party === 'seller' ? $shipping_only_amount : 0.0;
            $preview['caricove_pays_now'] = $shipping_only_amount;
            $preview['caricove_loss'] = $shipping_only_amount;
            $preview['mode'] = 'shipping_only';
            $preview['financial_mode'] = 'shipping_only';
        }

        self::json_success([
            'refund_amount'                     => round((float) ($preview['refund_amount'] ?? 0), 2),
            'item_refund_amount_customer'      => round((float) ($preview['item_refund_amount_customer'] ?? $preview['refund_amount'] ?? 0), 2),
            'outbound_shipping_refund_amount_customer' => round((float) ($preview['outbound_shipping_refund_amount_customer'] ?? 0), 2),
            'customer_total_refund'            => round((float) ($preview['customer_total_refund'] ?? $preview['customer_gets_back'] ?? 0), 2),
            'customer_gets_back'               => round((float) ($preview['customer_gets_back'] ?? 0), 2),
            'seller_outcome_label'             => (string) ($preview['seller_outcome_label'] ?? ''),
            'seller_outcome_amount'            => round((float) ($preview['seller_outcome_amount'] ?? 0), 2),
            'seller_shipping_impact'           => round((float) ($preview['seller_shipping_impact'] ?? 0), 2),
            'seller_debit_exposure_amount'     => round((float) ($preview['seller_debit_exposure_amount'] ?? 0), 2),
            'courier_shipping_impact'          => round((float) ($preview['courier_shipping_impact'] ?? 0), 2),
            'shipping_liability_party'         => (string) ($preview['shipping_liability_party'] ?? ''),
            'shipping_liability_amount_internal' => round((float) ($preview['shipping_liability_amount_internal'] ?? 0), 2),
            'return_shipping_cost_internal'    => round((float) ($preview['return_shipping_cost_internal'] ?? 0), 2),
            'commission_returned'              => round((float) ($preview['commission_reversal'] ?? 0), 2),
            'caricove_loss'                    => round((float) ($preview['caricove_loss'] ?? 0), 2),
            'caricove_pays_now'                => round((float) ($preview['caricove_pays_now'] ?? 0), 2),
            'mode'                             => (string) ($preview['mode'] ?? 'debit'),
            'refund_execution_mode'            => (string) ($preview['refund_execution_mode'] ?? ''),
            'item_received_flag'               => !empty($preview['item_received_flag']) ? 1 : 0,
            'return_required'                  => !empty($preview['return_required']) ? 1 : 0,
            'pre_return_shipping_only'          => $pre_return_shipping_only ? 1 : 0,
            'requires_fault_verdict'           => !empty($requires_fault_verdict) ? 1 : 0,
        ]);
    }

    public static function handle_decline(): void
    {
        self::guard();

        $case_id = sanitize_text_field($_POST['case_id'] ?? '');
        if ($case_id === '') {
            self::json_error('Missing case_id');
        }

        $case = BankRefundCases::get_case($case_id);
        if (!$case) {
            self::json_error('Case not found');
        }

        BankRefundCases::set_status(
            $case_id,
            'declined',
            [
                'admin_user_id' => get_current_user_id(),
                'admin_note'    => 'Refund declined',
            ]
        );

        self::json_success([
            'status' => 'declined',
        ]);
    }

    public static function handle_received_qty(): void
    {
        self::guard();

        $case_id = sanitize_text_field($_POST['case_id'] ?? '');
        $qty     = (int) ($_POST['qty_received'] ?? 0);

        if ($case_id === '') {
            self::json_error('Missing case_id');
        }

        $case = BankRefundCases::get_case($case_id);
        if (!$case) {
            self::json_error('Case not found');
        }
        if (self::case_item_final($case)) {
            self::json_error('This return item is already final and cannot be marked received again.');
        }

        $updated = BankRefundCases::set_received_qty(
            $case_id,
            $qty,
            [
                'seller_note' => sanitize_text_field($_POST['seller_note'] ?? ''),
            ]
        );

        if (!$updated) {
            self::json_error('Failed updating received qty');
        }

        self::json_success([
            'qty_received' => (int) ($updated['qty_received'] ?? 0),
        ]);
    }

    private static function case_item_final(array $case): bool
    {
        $status = sanitize_key((string) ($case['status'] ?? ''));
        $financial = sanitize_key((string) ($case['financial_status'] ?? ''));
        return trim((string) ($case['item_refund_posting_key'] ?? '')) !== ''
            || $status === 'refunded'
            || in_array($financial, ['refund_posted', 'reversal_posted', 'debit_posted', 'completed'], true);
    }

    private static function collect_overrides(array $src, array $case = []): array
    {
        $overrides = [];

        $item_refund = isset($src['item_refund_amount_customer'])
            ? round((float) $src['item_refund_amount_customer'], 2)
            : (isset($src['refund_amount_approved']) ? round((float) $src['refund_amount_approved'], 2) : null);
        if ($item_refund !== null && $item_refund >= 0) {
            $overrides['item_refund_amount_customer'] = $item_refund;
            $overrides['refund_amount_requested'] = $item_refund;
            $overrides['refund_amount_approved']  = $item_refund;
        }

        if (isset($src['outbound_shipping_refund_amount_customer'])) {
            $shipping = round((float) $src['outbound_shipping_refund_amount_customer'], 2);
            if ($shipping >= 0) {
                $overrides['outbound_shipping_refund_amount_customer'] = $shipping;
                $overrides['shipping_refund_selected'] = $shipping > 0 ? 1 : 0;
            }
        }

        if (isset($src['shipping_liability_party'])) {
            $party = sanitize_key((string) $src['shipping_liability_party']);
            if (in_array($party, ['seller', 'carrier'], true)) {
                $overrides['shipping_liability_party'] = $party;
            } elseif ($party === '' && !empty($case['shipping_liability_party'])) {
                $overrides['shipping_liability_party'] = (string) $case['shipping_liability_party'];
            }
        }

        if (isset($src['refund_execution_mode'])) {
            $mode = sanitize_key((string) $src['refund_execution_mode']);
            if (in_array($mode, ['never_received', 'return_required', 'returnless'], true)) {
                $overrides['refund_execution_mode'] = $mode;
            }
        }

        if (isset($src['item_received_flag'])) {
            $overrides['item_received_flag'] = !empty($src['item_received_flag']) ? 1 : 0;
        }

        if (isset($src['shipping_refund_selected']) && !isset($overrides['shipping_refund_selected'])) {
            $overrides['shipping_refund_selected'] = !empty($src['shipping_refund_selected']) ? 1 : 0;
        }

        if (isset($src['return_shipping_cost_internal'])) {
            $overrides['return_shipping_cost_internal'] = round((float) $src['return_shipping_cost_internal'], 2);
        }

        return $overrides;
    }

    private static function guard(): void
    {
        if (!current_user_can('manage_woocommerce')) {
            self::json_error('Unauthorized');
        }

        if (!check_ajax_referer('caricove_bank_refunds', 'nonce', false)) {
            self::json_error('Invalid nonce');
        }
    }

    private static function json_success(array $payload = []): void
    {
        wp_send_json_success($payload);
    }

    private static function json_error(string $message): void
    {
        wp_send_json_error(['message' => $message]);
    }
}
