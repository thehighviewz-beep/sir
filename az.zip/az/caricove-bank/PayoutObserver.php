<?php
namespace Caricove\Bank;
if (!defined('ABSPATH')) exit;

final class PayoutObserver {
    // CC_BANK_PAYOUT_TRACE_META_STRICT_V1

    public static function boot(): void {
        add_action('caricove_bank_funds_became_available', [self::class, 'on_funds_became_available'], 10, 1);
        add_action('caricove_bank_payout_requested',       [self::class, 'on_payout_requested'],       10, 1);
        add_action('caricove_bank_payout_approved',        [self::class, 'on_payout_approved'],        10, 1);
        add_action('caricove_bank_payout_queued',          [self::class, 'on_payout_queued'],          10, 1);
        add_action('caricove_bank_payout_completed',       [self::class, 'on_payout_completed'],       10, 1);
        add_action('caricove_bank_debit_offset_applied',   [self::class, 'on_debit_offset_applied'],   10, 1);
    }

    private static function money($v): float {
        return round((float)$v, 2);
    }

    private static function now(): string {
        return current_time('mysql');
    }

    private static function with_trace_meta(array $meta, array $payload = [], string $operation = 'payout_observer_event'): array {
        $existing = trim((string) ($payload['correlation_id'] ?? ($payload['trace_context']['correlation_id'] ?? '')));
        if ($existing === '') {
            $existing = 'payout-observer-' . substr(md5(wp_json_encode($payload) . '|' . microtime(true)), 0, 16);
        }
        $trace = [
            'correlation_id' => $existing,
            'command_source' => 'payout_observer',
            'trace_operation' => $operation,
            'payout_id' => (int) ($payload['payout_id'] ?? 0),
            'ledger_row_id' => (int) ($payload['ledger_row_id'] ?? 0),
            'shipment_id' => (int) ($payload['shipment_id'] ?? 0),
            'order_id' => (int) ($payload['order_id'] ?? 0),
            'vendor_id' => (int) ($payload['vendor_id'] ?? 0),
            'actor_user_id' => function_exists('get_current_user_id') ? (int) get_current_user_id() : 0,
            'captured_at' => self::now(),
        ];
        $meta['trace_context'] = array_merge(isset($meta['trace_context']) && is_array($meta['trace_context']) ? $meta['trace_context'] : [], $trace);
        $meta['trace_operation'] = $operation;
        $meta['correlation_id'] = $existing;
        return $meta;
    }

    public static function on_funds_became_available(array $payload): void {
        $now = self::now();
        $amount = self::money($payload['amount'] ?? ($payload['available_amount'] ?? 0));

        $meta = [
            'settlement_stage'  => 'payout_ready',
            'settlement_state'  => 'available',
            'settlement_reason' => 'Clearing window completed; seller funds are now eligible for payout request',
            'state_timestamp'   => $now,

            'shipment_id'       => (int)($payload['shipment_id'] ?? 0),
            'order_id'          => (int)($payload['order_id'] ?? 0),
            'vendor_id'         => (int)($payload['vendor_id'] ?? 0),
            'currency'          => (string)($payload['currency'] ?? 'GYD'),
            'available_amount'  => $amount,
            'pending_until'     => (string)($payload['pending_until'] ?? ''),
            'delivered_at'      => (string)($payload['delivered_at'] ?? ''),
            'ledger_row_id'     => (int)($payload['ledger_row_id'] ?? 0),
        ];

        $meta = self::with_trace_meta($meta, $payload, 'seller_funds_available');

        BankLedger::record([
            'event_type'      => 'seller_funds_available',
            'event_status'    => 'posted',
            'shipment_id'     => (int)($payload['shipment_id'] ?? 0),
            'order_id'        => (int)($payload['order_id'] ?? 0),
            'return_case_id'  => '',
            'vendor_id'       => (int)($payload['vendor_id'] ?? 0),
            'courier_id'      => 0,
            'customer_id'     => 0,
            'woo_refund_id'   => 0,
            'currency'        => (string)($payload['currency'] ?? 'GYD'),
            'amount'          => $amount,
            'direction'       => 'credit',
            'payer_type'      => 'platform',
            'payer_id'        => 0,
            'payee_type'      => 'vendor',
            'payee_id'        => (int)($payload['vendor_id'] ?? 0),
            'reason_code'     => 'seller_funds_available',
            'reason_label'    => 'Seller funds became available',
            'source_system'   => 'seller_payouts',
            'source_ref'      => (string)($payload['reference'] ?? $payload['source_ref'] ?? ('payout_complete:' . (int)($payload['payout_id'] ?? 0))),
            'meta_json'       => $meta,
        ]);
    }

    public static function on_payout_requested(array $payload): void {
        $now = self::now();

        $meta = [
            'settlement_stage'  => 'payout_request',
            'settlement_state'  => 'requested',
            'settlement_reason' => 'Vendor requested payout; awaiting admin review',
            'state_timestamp'   => $now,

            'payout_id'         => (int)($payload['payout_id'] ?? 0),
            'vendor_id'         => (int)($payload['vendor_id'] ?? 0),
            'currency'          => (string)($payload['currency'] ?? 'GYD'),
            'amount_gross'      => self::money($payload['amount_gross'] ?? 0),
            'fee'               => self::money($payload['fee'] ?? 0),
            'amount_net'        => self::money($payload['amount_net'] ?? 0),
            'method'            => (string)($payload['method'] ?? ''),
            'destination'       => (string)($payload['destination'] ?? ''),
            'reference'         => (string)($payload['reference'] ?? ''),
        ];

        $meta = self::with_trace_meta($meta, $payload, 'seller_payout_requested');

        BankLedger::record([
            'event_type'      => 'seller_payout_requested',
            'event_status'    => 'requested',
            'shipment_id'     => 0,
            'order_id'        => 0,
            'return_case_id'  => '',
            'vendor_id'       => (int)($payload['vendor_id'] ?? 0),
            'courier_id'      => 0,
            'customer_id'     => 0,
            'woo_refund_id'   => 0,
            'currency'        => (string)($payload['currency'] ?? 'GYD'),
            'amount'          => self::money($payload['amount_net'] ?? 0),
            'direction'       => 'debit',
            'payer_type'      => 'platform',
            'payer_id'        => 0,
            'payee_type'      => 'vendor',
            'payee_id'        => (int)($payload['vendor_id'] ?? 0),
            'reason_code'     => 'seller_payout_requested',
            'reason_label'    => 'Seller payout requested',
            'source_system'   => 'seller_payouts',
            'source_ref'      => 'payout_request:' . (int)($payload['payout_id'] ?? 0),
            'meta_json'       => $meta,
        ]);
    }

    public static function on_payout_approved(array $payload): void {
        $now = self::now();

        $meta = [
            'settlement_stage'  => 'payout_request',
            'settlement_state'  => 'approved',
            'settlement_reason' => 'Admin approved seller payout request',
            'state_timestamp'   => $now,

            'payout_id'         => (int)($payload['payout_id'] ?? 0),
            'vendor_id'         => (int)($payload['vendor_id'] ?? 0),
            'currency'          => (string)($payload['currency'] ?? 'GYD'),
            'amount_gross'      => self::money($payload['amount_gross'] ?? 0),
            'fee'               => self::money($payload['fee'] ?? 0),
            'amount_net'        => self::money($payload['amount_net'] ?? 0),
            'method'            => (string)($payload['method'] ?? ''),
            'destination'       => (string)($payload['destination'] ?? ''),
            'reference'         => (string)($payload['reference'] ?? ''),
            'approved_by'       => (int)($payload['approved_by'] ?? 0),
        ];

        $meta = self::with_trace_meta($meta, $payload, 'seller_payout_approved');

        BankLedger::record([
            'event_type'      => 'seller_payout_approved',
            'event_status'    => 'approved',
            'shipment_id'     => 0,
            'order_id'        => 0,
            'return_case_id'  => '',
            'vendor_id'       => (int)($payload['vendor_id'] ?? 0),
            'courier_id'      => 0,
            'customer_id'     => 0,
            'woo_refund_id'   => 0,
            'currency'        => (string)($payload['currency'] ?? 'GYD'),
            'amount'          => self::money($payload['amount_net'] ?? 0),
            'direction'       => 'debit',
            'payer_type'      => 'platform',
            'payer_id'        => 0,
            'payee_type'      => 'vendor',
            'payee_id'        => (int)($payload['vendor_id'] ?? 0),
            'reason_code'     => 'seller_payout_approved',
            'reason_label'    => 'Seller payout approved',
            'source_system'   => 'seller_payouts',
            'source_ref'      => 'payout_approval:' . (int)($payload['payout_id'] ?? 0),
            'meta_json'       => $meta,
        ]);
    }

    public static function on_payout_queued(array $payload): void {
        $now = self::now();

        $meta = [
            'settlement_stage'  => 'payout_execution',
            'settlement_state'  => 'queued',
            'settlement_reason' => 'Seller payout has been queued for execution',
            'state_timestamp'   => $now,

            'payout_id'         => (int)($payload['payout_id'] ?? 0),
            'vendor_id'         => (int)($payload['vendor_id'] ?? 0),
            'currency'          => (string)($payload['currency'] ?? 'GYD'),
            'amount_gross'      => self::money($payload['amount_gross'] ?? 0),
            'fee'               => self::money($payload['fee'] ?? 0),
            'amount_net'        => self::money($payload['amount_net'] ?? 0),
            'method'            => (string)($payload['method'] ?? ''),
            'destination'       => (string)($payload['destination'] ?? ''),
            'reference'         => (string)($payload['reference'] ?? ''),
            'kind'              => (string)($payload['kind'] ?? ''),
        ];

        $meta = self::with_trace_meta($meta, $payload, 'seller_payout_queued');

        BankLedger::record([
            'event_type'      => 'seller_payout_queued',
            'event_status'    => 'queued',
            'shipment_id'     => 0,
            'order_id'        => 0,
            'return_case_id'  => '',
            'vendor_id'       => (int)($payload['vendor_id'] ?? 0),
            'courier_id'      => 0,
            'customer_id'     => 0,
            'woo_refund_id'   => 0,
            'currency'        => (string)($payload['currency'] ?? 'GYD'),
            'amount'          => self::money($payload['amount_net'] ?? 0),
            'direction'       => 'debit',
            'payer_type'      => 'platform',
            'payer_id'        => 0,
            'payee_type'      => 'vendor',
            'payee_id'        => (int)($payload['vendor_id'] ?? 0),
            'reason_code'     => 'seller_payout_queued',
            'reason_label'    => 'Seller payout queued',
            'source_system'   => 'seller_payouts',
            'source_ref'      => 'payout_queue:' . (int)($payload['payout_id'] ?? 0),
            'meta_json'       => $meta,
        ]);
    }

    public static function on_payout_completed(array $payload): void {
        $ledger_row_id = (int) ($payload['ledger_row_id'] ?? 0);
        $amount = self::money($payload['amount'] ?? ($payload['amount_net'] ?? ($payload['amount_gross'] ?? 0)));
        if ($ledger_row_id <= 0 || $amount <= 0) {
            return;
        }

        $now = self::now();

        $meta = [
            'settlement_stage'  => 'payout_complete',
            'settlement_state'  => 'paid',
            'settlement_reason' => 'Seller payout completed',
            'state_timestamp'   => $now,

            'ledger_row_id'     => (int)($payload['ledger_row_id'] ?? 0),
            'shipment_id'       => (int)($payload['shipment_id'] ?? 0),
            'order_id'          => (int)($payload['order_id'] ?? 0),
            'vendor_id'         => (int)($payload['vendor_id'] ?? 0),
            'currency'          => (string)($payload['currency'] ?? 'GYD'),
            'amount'            => $amount,
            'payout_id'         => (int)($payload['payout_id'] ?? 0),
            'reference'         => (string)($payload['reference'] ?? ''),
            'kind'              => (string)($payload['kind'] ?? ''),
            'cash_sources'      => (array)($payload['cash_sources'] ?? []),
            'offset_events'     => (array)($payload['offset_events'] ?? []),

        ];

        $meta = self::with_trace_meta($meta, $payload, 'seller_payout_completed');

        BankLedger::record([
            'event_type'      => 'seller_payout_completed',
            'event_status'    => 'paid',
            'shipment_id'     => (int)($payload['shipment_id'] ?? 0),
            'order_id'        => (int)($payload['order_id'] ?? 0),
            'return_case_id'  => '',
            'vendor_id'       => (int)($payload['vendor_id'] ?? 0),
            'courier_id'      => 0,
            'customer_id'     => 0,
            'woo_refund_id'   => 0,
            'currency'        => (string)($payload['currency'] ?? 'GYD'),
            'amount'          => $amount,
            'direction'       => 'debit',
            'payer_type'      => 'platform',
            'payer_id'        => 0,
            'payee_type'      => 'vendor',
            'payee_id'        => (int)($payload['vendor_id'] ?? 0),
            'reason_code'     => 'seller_payout_completed',
            'reason_label'    => 'Seller payout completed',
            'source_system'   => 'seller_payouts',
            'source_ref'      => (string)($payload['source_ref'] ?? ''),
            'meta_json'       => $meta,
        ]);
    }

    public static function on_debit_offset_applied(array $payload): void {
        $now = self::now();
        $amount = self::money($payload['amount'] ?? ($payload['amount_net'] ?? ($payload['amount_gross'] ?? 0)));

        $meta = [
            'settlement_stage'  => 'recovery',
            'settlement_state'  => 'posted',
            'settlement_reason' => 'Available seller earnings were applied to debit exposure before payout',
            'state_timestamp'   => $now,

            'vendor_id'         => (int)($payload['vendor_id'] ?? 0),
            'currency'          => (string)($payload['currency'] ?? 'GYD'),
            'amount'            => $amount,
            'reference'         => (string)($payload['reference'] ?? ''),
        ];

        $meta = self::with_trace_meta($meta, $payload, 'seller_debit_offset_applied');

        BankLedger::record([
            'event_type'      => 'seller_debit_offset_applied',
            'event_status'    => 'posted',
            'shipment_id'     => 0,
            'order_id'        => 0,
            'return_case_id'  => '',
            'vendor_id'       => (int)($payload['vendor_id'] ?? 0),
            'courier_id'      => 0,
            'customer_id'     => 0,
            'woo_refund_id'   => 0,
            'currency'        => (string)($payload['currency'] ?? 'GYD'),
            'amount'          => $amount,
            'direction'       => 'credit',
            'payer_type'      => 'vendor',
            'payer_id'        => (int)($payload['vendor_id'] ?? 0),
            'payee_type'      => 'platform',
            'payee_id'        => 0,
            'reason_code'     => 'seller_debit_offset_applied',
            'reason_label'    => 'Seller debit offset applied',
            'source_system'   => 'seller_payouts',
            'source_ref'      => (string)($payload['reference'] ?? ''),
            'meta_json'       => $meta,
        ]);
    }
}
