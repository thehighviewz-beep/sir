<?php
namespace Caricove\Bank;

if (!defined('ABSPATH')) exit;

/**
 * Caricove Bank Provider Events — Phase 2D
 *
 * Signed provider-event inbox for future real money movement.
 * This class is intentionally read-only: it records provider proof only.
 * It does not create charges, refunds, transfers, payouts, withdrawals, or ledger money mutations.
 */
final class BankProviderEvents
{
    public const SCHEMA_VERSION = '2D.1';
    public const SCHEMA_OPTION = 'caricove_bank_provider_events_schema_v1';
    public const REST_NAMESPACE = 'caricove-bank/v1';
    public const STRIPE_ROUTE = '/stripe/webhook';
    public const SIGNATURE_TOLERANCE_SECONDS = 300;

    public static function boot(): void
    {
        add_action('admin_init', [__CLASS__, 'maybe_install']);
        add_action('rest_api_init', [__CLASS__, 'register_rest_routes']);
    }

    public static function table(): string
    {
        global $wpdb;
        return $wpdb->prefix . 'caricove_provider_events';
    }

    public static function maybe_install(): void
    {
        if (get_option(self::SCHEMA_OPTION) === self::SCHEMA_VERSION) {
            return;
        }
        self::install();
        update_option(self::SCHEMA_OPTION, self::SCHEMA_VERSION, false);
    }

    public static function install(): void
    {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $table = self::table();
        $charset = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE {$table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            provider VARCHAR(32) NOT NULL DEFAULT '',
            mode VARCHAR(16) NOT NULL DEFAULT '',
            provider_event_id VARCHAR(191) NOT NULL DEFAULT '',
            provider_event_type VARCHAR(120) NOT NULL DEFAULT '',
            event_status VARCHAR(24) NOT NULL DEFAULT 'received',
            signature_status VARCHAR(24) NOT NULL DEFAULT '',
            livemode TINYINT(1) NOT NULL DEFAULT 0,
            provider_account VARCHAR(191) NOT NULL DEFAULT '',
            object_id VARCHAR(191) NOT NULL DEFAULT '',
            object_type VARCHAR(120) NOT NULL DEFAULT '',
            order_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            shipment_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            vendor_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            courier_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            customer_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            currency VARCHAR(10) NOT NULL DEFAULT '',
            amount DECIMAL(20,2) NOT NULL DEFAULT 0.00,
            payment_intent_id VARCHAR(191) NOT NULL DEFAULT '',
            charge_id VARCHAR(191) NOT NULL DEFAULT '',
            refund_id VARCHAR(191) NOT NULL DEFAULT '',
            payout_id VARCHAR(191) NOT NULL DEFAULT '',
            transfer_id VARCHAR(191) NOT NULL DEFAULT '',
            balance_transaction_id VARCHAR(191) NOT NULL DEFAULT '',
            duplicate_count INT UNSIGNED NOT NULL DEFAULT 0,
            received_at DATETIME NOT NULL,
            last_seen_at DATETIME NOT NULL,
            processed_at DATETIME NULL,
            raw_sha256 CHAR(64) NOT NULL DEFAULT '',
            summary_json LONGTEXT NULL,
            created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
            PRIMARY KEY  (id),
            UNIQUE KEY provider_event (provider, provider_event_id),
            KEY provider_event_type (provider_event_type),
            KEY event_status (event_status),
            KEY signature_status (signature_status),
            KEY object_id (object_id),
            KEY order_id (order_id),
            KEY shipment_id (shipment_id),
            KEY vendor_id (vendor_id),
            KEY courier_id (courier_id),
            KEY customer_id (customer_id),
            KEY payment_intent_id (payment_intent_id),
            KEY charge_id (charge_id),
            KEY refund_id (refund_id),
            KEY payout_id (payout_id),
            KEY received_at (received_at)
        ) {$charset};";

        dbDelta($sql);
    }

    public static function register_rest_routes(): void
    {
        register_rest_route(self::REST_NAMESPACE, self::STRIPE_ROUTE, [
            'methods' => 'POST',
            'callback' => [__CLASS__, 'handle_stripe_webhook'],
            'permission_callback' => '__return_true',
        ]);
    }

    public static function webhook_url(string $provider = 'stripe'): string
    {
        if ($provider === 'stripe') {
            return rest_url(self::REST_NAMESPACE . self::STRIPE_ROUTE);
        }
        return rest_url(self::REST_NAMESPACE);
    }

    public static function stripe_webhook_secret_status(): array
    {
        [$secret, $source] = self::stripe_webhook_secret();
        return [
            'ready' => $secret !== '',
            'source' => $source,
            'masked' => $secret !== '' ? self::mask_secret($secret) : '',
        ];
    }

    public static function handle_stripe_webhook(\WP_REST_Request $request)
    {
        self::maybe_install();

        $payload = (string) $request->get_body();
        $signature_header = (string) $request->get_header('stripe-signature');
        [$secret, $secret_source] = self::stripe_webhook_secret();

        if ($secret === '') {
            return new \WP_Error(
                'caricove_stripe_webhook_secret_missing',
                'Stripe webhook secret is not configured. Add CARICOVE_STRIPE_WEBHOOK_SECRET or STRIPE_WEBHOOK_SECRET before enabling provider webhooks.',
                ['status' => 503]
            );
        }

        $verified = self::verify_stripe_signature($payload, $signature_header, $secret, self::SIGNATURE_TOLERANCE_SECONDS);
        if (empty($verified['ok'])) {
            return new \WP_Error(
                'caricove_stripe_webhook_signature_failed',
                (string) ($verified['message'] ?? 'Stripe webhook signature verification failed.'),
                ['status' => 400]
            );
        }

        $event = json_decode($payload, true);
        if (!is_array($event)) {
            return new \WP_Error('caricove_stripe_webhook_bad_json', 'Stripe webhook payload was not valid JSON.', ['status' => 400]);
        }

        $stored = self::record_stripe_event($event, [
            'raw_sha256' => hash('sha256', $payload),
            'signature_status' => 'verified',
            'signature_source' => $secret_source,
            'signature_timestamp' => (int) ($verified['timestamp'] ?? 0),
        ]);

        if (empty($stored['ok'])) {
            return new \WP_Error('caricove_provider_event_store_failed', (string) ($stored['message'] ?? 'Provider event could not be stored.'), ['status' => 500]);
        }

        return new \WP_REST_Response([
            'received' => true,
            'provider' => 'stripe',
            'event_id' => (string) ($stored['provider_event_id'] ?? ''),
            'duplicate' => !empty($stored['duplicate']),
            'record_id' => (int) ($stored['record_id'] ?? 0),
            'money_moved' => false,
        ], 200);
    }

    public static function record_stripe_event(array $event, array $context = []): array
    {
        global $wpdb;
        self::maybe_install();

        $event_id = sanitize_text_field((string) ($event['id'] ?? ''));
        $event_type = sanitize_text_field((string) ($event['type'] ?? ''));
        if ($event_id === '' || $event_type === '') {
            return ['ok' => false, 'message' => 'Stripe event is missing id or type.'];
        }

        $object = [];
        if (isset($event['data']['object']) && is_array($event['data']['object'])) {
            $object = (array) $event['data']['object'];
        }

        $metadata = [];
        if (isset($object['metadata']) && is_array($object['metadata'])) {
            $metadata = (array) $object['metadata'];
        }

        $currency = strtoupper(sanitize_text_field((string) self::first_value($object, ['currency'], '')));
        $amount = self::extract_amount($object, $currency);
        $object_type = sanitize_text_field((string) ($object['object'] ?? ''));
        $object_id = sanitize_text_field((string) ($object['id'] ?? ''));

        $ids = [
            'payment_intent_id' => self::extract_provider_id($object, $object_type, ['payment_intent'], 'payment_intent'),
            'charge_id' => self::extract_provider_id($object, $object_type, ['charge', 'latest_charge'], 'charge'),
            'refund_id' => self::extract_provider_id($object, $object_type, ['refund'], 'refund'),
            'payout_id' => self::extract_provider_id($object, $object_type, ['payout'], 'payout'),
            'transfer_id' => self::extract_provider_id($object, $object_type, ['transfer', 'destination_payment'], 'transfer'),
            'balance_transaction_id' => self::extract_provider_id($object, $object_type, ['balance_transaction'], 'balance_transaction'),
        ];

        if ($object_type === 'payment_intent') {
            $ids['payment_intent_id'] = $object_id;
        } elseif ($object_type === 'charge') {
            $ids['charge_id'] = $object_id;
        } elseif ($object_type === 'refund') {
            $ids['refund_id'] = $object_id;
        } elseif ($object_type === 'payout') {
            $ids['payout_id'] = $object_id;
        } elseif ($object_type === 'transfer') {
            $ids['transfer_id'] = $object_id;
        }

        $mode = !empty($event['livemode']) ? 'live' : 'test';
        $now = current_time('mysql');

        $summary = [
            'provider' => 'stripe',
            'event_id' => $event_id,
            'event_type' => $event_type,
            'object_id' => $object_id,
            'object_type' => $object_type,
            'mode' => $mode,
            'api_version' => sanitize_text_field((string) ($event['api_version'] ?? '')),
            'provider_account' => sanitize_text_field((string) ($event['account'] ?? '')),
            'metadata' => self::sanitize_metadata($metadata),
            'signature_status' => sanitize_key((string) ($context['signature_status'] ?? 'verified')),
            'signature_source' => sanitize_text_field((string) ($context['signature_source'] ?? '')),
            'signature_timestamp' => (int) ($context['signature_timestamp'] ?? 0),
            'raw_sha256' => sanitize_text_field((string) ($context['raw_sha256'] ?? '')),
            'money_moved_by_caricove' => false,
            'phase' => '2D_provider_event_inbox',
        ];

        $payload = [
            'provider' => 'stripe',
            'mode' => $mode,
            'provider_event_id' => $event_id,
            'provider_event_type' => $event_type,
            'event_status' => 'received',
            'signature_status' => sanitize_key((string) ($context['signature_status'] ?? 'verified')),
            'livemode' => !empty($event['livemode']) ? 1 : 0,
            'provider_account' => sanitize_text_field((string) ($event['account'] ?? '')),
            'object_id' => $object_id,
            'object_type' => $object_type,
            'order_id' => self::metadata_int($metadata, ['caricove_order_id', 'wc_order_id', 'woocommerce_order_id', 'order_id', 'order']),
            'shipment_id' => self::metadata_int($metadata, ['caricove_shipment_id', 'shipment_id', 'cc_shipment_id']),
            'vendor_id' => self::metadata_int($metadata, ['caricove_vendor_id', 'vendor_id', 'seller_id']),
            'courier_id' => self::metadata_int($metadata, ['caricove_courier_id', 'courier_id', 'driver_id']),
            'customer_id' => self::metadata_int($metadata, ['caricove_customer_id', 'customer_id', 'wp_user_id']),
            'currency' => $currency,
            'amount' => $amount,
            'payment_intent_id' => $ids['payment_intent_id'],
            'charge_id' => $ids['charge_id'],
            'refund_id' => $ids['refund_id'],
            'payout_id' => $ids['payout_id'],
            'transfer_id' => $ids['transfer_id'],
            'balance_transaction_id' => $ids['balance_transaction_id'],
            'duplicate_count' => 0,
            'received_at' => $now,
            'last_seen_at' => $now,
            'processed_at' => null,
            'raw_sha256' => sanitize_text_field((string) ($context['raw_sha256'] ?? '')),
            'summary_json' => wp_json_encode($summary),
            'created_by' => 0,
        ];

        $table = self::table();
        $existing = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$table} WHERE provider = %s AND provider_event_id = %s LIMIT 1",
            'stripe',
            $event_id
        ));

        if ($existing > 0) {
            $wpdb->query($wpdb->prepare(
                "UPDATE {$table}
                 SET duplicate_count = duplicate_count + 1,
                     last_seen_at = %s,
                     signature_status = %s,
                     raw_sha256 = %s
                 WHERE id = %d",
                $now,
                $payload['signature_status'],
                $payload['raw_sha256'],
                $existing
            ));

            return [
                'ok' => true,
                'duplicate' => true,
                'record_id' => $existing,
                'provider_event_id' => $event_id,
            ];
        }

        $inserted = $wpdb->insert($table, $payload);
        if (!$inserted) {
            return ['ok' => false, 'message' => 'Database insert failed for provider event.'];
        }

        return [
            'ok' => true,
            'duplicate' => false,
            'record_id' => (int) $wpdb->insert_id,
            'provider_event_id' => $event_id,
        ];
    }

    public static function summary(): array
    {
        global $wpdb;
        self::maybe_install();
        $table = self::table();
        $secret = self::stripe_webhook_secret_status();

        $total = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table}");
        $verified = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table} WHERE signature_status = %s", 'verified'));
        $latest_at = (string) $wpdb->get_var("SELECT MAX(received_at) FROM {$table}");
        $latest_type = (string) $wpdb->get_var("SELECT provider_event_type FROM {$table} ORDER BY id DESC LIMIT 1");
        $unprocessed = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table} WHERE event_status = %s", 'received'));
        $duplicates = (int) $wpdb->get_var("SELECT COALESCE(SUM(duplicate_count),0) FROM {$table}");

        return [
            'table' => $table,
            'stripe_endpoint' => self::webhook_url('stripe'),
            'stripe_secret_ready' => !empty($secret['ready']),
            'stripe_secret_source' => (string) ($secret['source'] ?? ''),
            'stripe_secret_masked' => (string) ($secret['masked'] ?? ''),
            'total_events' => $total,
            'verified_events' => $verified,
            'unprocessed_events' => $unprocessed,
            'duplicate_deliveries' => $duplicates,
            'latest_received_at' => $latest_at ?: 'Never',
            'latest_type' => $latest_type ?: 'None',
        ];
    }

    public static function recent(int $limit = 30): array
    {
        global $wpdb;
        self::maybe_install();
        $limit = max(1, min(200, $limit));
        $table = self::table();

        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$table} ORDER BY id DESC LIMIT %d",
                $limit
            ),
            ARRAY_A
        ) ?: [];
    }

    private static function verify_stripe_signature(string $payload, string $header, string $secret, int $tolerance): array
    {
        if ($payload === '') {
            return ['ok' => false, 'message' => 'Empty Stripe webhook payload.'];
        }
        if ($header === '') {
            return ['ok' => false, 'message' => 'Missing Stripe-Signature header.'];
        }

        $timestamp = 0;
        $signatures = [];
        foreach (explode(',', $header) as $part) {
            $piece = explode('=', trim($part), 2);
            if (count($piece) !== 2) {
                continue;
            }
            [$key, $value] = $piece;
            if ($key === 't') {
                $timestamp = (int) $value;
            } elseif ($key === 'v1') {
                $signatures[] = trim((string) $value);
            }
        }

        if ($timestamp <= 0 || empty($signatures)) {
            return ['ok' => false, 'message' => 'Stripe-Signature header is missing timestamp or v1 signature.'];
        }

        if ($tolerance > 0 && abs(time() - $timestamp) > $tolerance) {
            return ['ok' => false, 'message' => 'Stripe webhook timestamp is outside the accepted tolerance window.', 'timestamp' => $timestamp];
        }

        $expected = hash_hmac('sha256', $timestamp . '.' . $payload, $secret);
        foreach ($signatures as $sig) {
            if (hash_equals($expected, $sig)) {
                return ['ok' => true, 'timestamp' => $timestamp];
            }
        }

        return ['ok' => false, 'message' => 'No Stripe webhook signature matched the endpoint secret.', 'timestamp' => $timestamp];
    }

    private static function stripe_webhook_secret(): array
    {
        foreach (['CARICOVE_STRIPE_WEBHOOK_SECRET', 'STRIPE_WEBHOOK_SECRET'] as $name) {
            $value = self::constant_or_env($name);
            if ($value !== '') {
                return [$value, $name];
            }
        }
        return ['', ''];
    }

    private static function constant_or_env(string $name): string
    {
        if (defined($name) && is_scalar(constant($name))) {
            $value = trim((string) constant($name));
            if ($value !== '') {
                return $value;
            }
        }
        $env = getenv($name);
        if (is_string($env) && trim($env) !== '') {
            return trim($env);
        }
        if (isset($_ENV[$name]) && is_scalar($_ENV[$name]) && trim((string) $_ENV[$name]) !== '') {
            return trim((string) $_ENV[$name]);
        }
        return '';
    }

    private static function mask_secret(string $secret): string
    {
        $len = strlen($secret);
        if ($len <= 10) {
            return str_repeat('•', max(4, $len));
        }
        return substr($secret, 0, 6) . '…' . substr($secret, -4);
    }

    private static function sanitize_metadata(array $metadata): array
    {
        $out = [];
        foreach ($metadata as $key => $value) {
            $clean_key = sanitize_key((string) $key);
            if ($clean_key === '') {
                continue;
            }
            if (is_scalar($value) || $value === null) {
                $out[$clean_key] = sanitize_text_field((string) $value);
            }
        }
        ksort($out);
        return $out;
    }

    private static function metadata_int(array $metadata, array $keys): int
    {
        foreach ($keys as $key) {
            if (!isset($metadata[$key])) {
                continue;
            }
            $raw = preg_replace('/[^0-9]/', '', (string) $metadata[$key]);
            if ($raw !== '') {
                return max(0, (int) $raw);
            }
        }
        return 0;
    }

    private static function first_value(array $row, array $keys, $fallback = '')
    {
        foreach ($keys as $key) {
            if (array_key_exists($key, $row) && $row[$key] !== null && $row[$key] !== '') {
                return $row[$key];
            }
        }
        return $fallback;
    }

    private static function extract_provider_id(array $object, string $object_type, array $keys, string $type_if_object): string
    {
        if ($object_type === $type_if_object && !empty($object['id'])) {
            return sanitize_text_field((string) $object['id']);
        }
        foreach ($keys as $key) {
            if (empty($object[$key])) {
                continue;
            }
            if (is_array($object[$key]) && !empty($object[$key]['id'])) {
                return sanitize_text_field((string) $object[$key]['id']);
            }
            if (is_scalar($object[$key])) {
                return sanitize_text_field((string) $object[$key]);
            }
        }
        return '';
    }

    private static function extract_amount(array $object, string $currency): float
    {
        foreach (['amount_received', 'amount_captured', 'amount_refunded', 'amount_paid', 'amount'] as $key) {
            if (isset($object[$key]) && is_numeric($object[$key])) {
                return round(((float) $object[$key]) / self::currency_divisor($currency), 2);
            }
        }
        return 0.0;
    }

    private static function currency_divisor(string $currency): int
    {
        $zero_decimal = ['BIF','CLP','DJF','GNF','JPY','KMF','KRW','MGA','PYG','RWF','UGX','VND','VUV','XAF','XOF','XPF'];
        return in_array(strtoupper($currency), $zero_decimal, true) ? 1 : 100;
    }
}
